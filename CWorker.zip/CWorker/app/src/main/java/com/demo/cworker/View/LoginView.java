package com.demo.cworker.View;

import com.demo.cworker.View.BaseView;

/**
 * Created by
 */
public interface LoginView extends BaseView {
    void getData(String data);
}
