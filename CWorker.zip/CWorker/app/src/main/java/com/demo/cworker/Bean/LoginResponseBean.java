package com.demo.cworker.Bean;

/**
 * Description:
 * Created by GUZHENFU on 2017/5/16 15:09.
 */

public class LoginResponseBean {
    private String token;
    private long time;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }
}
