package com.demo.cworker.View;

import com.demo.cworker.View.BaseView;

/**
 * Created by
 */
public interface CheckEmailActivityView extends BaseView {
    void getData(String data);
}
