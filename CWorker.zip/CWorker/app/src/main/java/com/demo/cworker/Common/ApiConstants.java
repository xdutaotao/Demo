package com.demo.cworker.Common;

public class ApiConstants {
	public static final String BASE_URL = "http://363600.cicp.net:8080/api/";
	public static final String USER_REGISTER = "user/registerNewUser";
	public static final String USER_LOGIN = "user/theUserLogin";
	public static final String USER_CHECK_PHONE = "user/checkMobile";
}