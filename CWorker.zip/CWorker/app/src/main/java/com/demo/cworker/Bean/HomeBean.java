package com.demo.cworker.Bean;

/**
 * Description:
 * Created by GUZHENFU on 2017/5/16 12:42.
 */

public class HomeBean {
    private String url;
    private String text;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
