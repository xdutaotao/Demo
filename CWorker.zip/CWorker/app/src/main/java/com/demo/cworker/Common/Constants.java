package com.demo.cworker.Common;

/**
 * Description:
 * Created by GUZHENFU on 2017/5/16 16:45.
 */

public class Constants {
    public static final String TOKEN_KEY = "token_key";
    public static final String USER_INFO_KEY = "user_info_key";
    public static final String INTENT_KEY = "intent_key";
}
