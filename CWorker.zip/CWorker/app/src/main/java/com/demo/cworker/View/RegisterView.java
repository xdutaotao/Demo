package com.demo.cworker.View;

/**
 * Created by
 */
public interface RegisterView extends BaseView {
    void getData(String result);
}
