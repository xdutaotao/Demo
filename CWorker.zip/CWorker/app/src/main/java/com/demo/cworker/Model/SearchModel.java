package com.demo.cworker.Model;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Created by
 */
@Singleton
public class SearchModel extends BaseModel {
    @Inject
    public SearchModel() {
    }
}
