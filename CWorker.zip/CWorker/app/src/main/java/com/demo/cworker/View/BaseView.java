package com.demo.cworker.View;

public interface BaseView {
    void onFailure();
}