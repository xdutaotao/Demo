//
//  AppDelegate+OtherTask.h
//  shcem
//
//  Created by huangdeyu on 2016/12/9.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (OtherTask)
-(void)startTask;
@end
