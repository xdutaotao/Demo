//
//  CreatFlowPhotoTableViewCell.m
//  OA
//
//  Created by wangyu on 15/8/27.
//  Copyright (c) 2015年 wangyu. All rights reserved.
//

#import "CreatFlowPhotoTableViewCell.h"
#import "UIButton+WebCache.h"

@interface CreatFlowPhotoTableViewCell()

@property (assign,nonatomic) NSInteger imageWidth;
@property (nonatomic,strong) UIButton *addImageBT;

@end

@implementation CreatFlowPhotoTableViewCell

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self.contentView addSubview:self.addImageBT];
    }
    
    return self;
}

-(void)setShowAddImageBT:(BOOL)showAddImageBT{
    _showAddImageBT = showAddImageBT;
    self.addImageBT.hidden = !showAddImageBT;
}

-(UIButton*)addImageBT{
    if (!_addImageBT) {
        _addImageBT = [UIButton buttonWithType:UIButtonTypeCustom];
        _addImageBT.contentMode = UIViewContentModeScaleAspectFill;
        _addImageBT.backgroundColor = [UIColor clearColor];
        [_addImageBT setBackgroundImage:[UIImage imageNamed:@"plusImg"] forState:UIControlStateNormal];
        [_addImageBT addTarget:self action:@selector(addImageBTAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _addImageBT;
}

-(NSInteger)imageWidth{
    if (!_imageWidth) {
        _imageWidth = (ScreenWidth-10*5)/4;
    }
    return _imageWidth;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setImageArray:(NSArray *)imageArray{
    _imageArray = imageArray;
    [self removeAllButAddImageButton];
    
    for (int i=0; i<imageArray.count; i++) {
        UIButton *imageBT = [UIButton buttonWithType:UIButtonTypeCustom];
        imageBT.tag = 100+i;
        imageBT.frame = [self getButtonFrameWithTag:i];
        imageBT.imageView.contentMode = UIViewContentModeScaleAspectFit;
        [imageBT addTarget:self action:@selector(imageBTAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:imageBT];
        
        id image =  imageArray[i];
        if (![image isKindOfClass:[UIImage class]]) {
            NSString *urlString = [NSString stringWithFormat:@"%@%@",BANNERDOWNLOADURL,image];
            [imageBT sd_setBackgroundImageWithURL:[NSURL URLWithString:[urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"LoadFail"]];
        }else{
            [imageBT setBackgroundImage:image forState:UIControlStateNormal];
        }
    }
  
    self.addImageBT.frame = [self getButtonFrameWithTag:imageArray.count];
}

-(void)removeAllButAddImageButton{
    for (UIView* button in self.contentView.subviews) {
        if ([button isKindOfClass:[UIButton class]] && button != self.addImageBT) {
            [button removeFromSuperview];
        }
    }
}

-(CGRect)getButtonFrameWithTag:(NSInteger)tag{
    NSInteger margin = 10;
    NSInteger imageWidth = (ScreenWidth-margin*5)/4;
    NSInteger xMultiply = tag%4;
    NSInteger yMultiply = tag/4;
    NSInteger xOffset = margin+(imageWidth+margin)*xMultiply;
    NSInteger yoffset = margin+(imageWidth+margin)*yMultiply;
    
   return CGRectMake(xOffset, yoffset, imageWidth, imageWidth);
}

-(void)imageBTAction:(id)sender{
    UIButton *tempBT = (UIButton*)sender;
    if ([self.delegate respondsToSelector:@selector(CreatFlowPhotoTableViewCellDelegateWithButtonIndex:imageArray:)]) {
        [self.delegate CreatFlowPhotoTableViewCellDelegateWithButtonIndex:tempBT.tag-100 imageArray:self.imageArray];
    }
}

-(void)addImageBTAction:(id)sender{
    if ([self.delegate respondsToSelector:@selector(CreatFlowPhotoTableViewCellDelegateWithButtonIndex:imageArray:)]) {
        [self.delegate CreatFlowPhotoTableViewCellDelegateWithButtonIndex:0 imageArray:nil];
    }
}

@end



