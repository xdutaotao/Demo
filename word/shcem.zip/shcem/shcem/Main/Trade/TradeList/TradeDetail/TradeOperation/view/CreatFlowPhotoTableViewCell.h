//
//  CreatFlowPhotoTableViewCell.h
//  OA
//
//  Created by wangyu on 15/8/27.
//  Copyright (c) 2015年 wangyu. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger,CreatFlowPhotoTableViewCellOperationType) {
    CreatFlowPhotoTableViewCellOperationTypeScan = 0,
    CreatFlowPhotoTableViewCellOperationTypeDelete = 1,
};


@protocol CreatFlowPhotoTableViewCellDelegate <NSObject>

@optional

-(void)CreatFlowPhotoTableViewCellDelegateWithButtonIndex:(NSInteger)buttonIndex imageArray:(NSArray*)imageArray;

@end



@interface CreatFlowPhotoTableViewCell : UITableViewCell

@property (nonatomic,assign) BOOL showAddImageBT;
@property (nonatomic,strong) NSArray *imageArray;

@property (nonatomic ,weak) id<CreatFlowPhotoTableViewCellDelegate> delegate;


@end
