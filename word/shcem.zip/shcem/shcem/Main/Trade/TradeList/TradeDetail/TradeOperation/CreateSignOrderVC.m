//
//  CreateSignOrderVC.m
//  shcem
//
//  Created by xupeipei on 2016/12/16.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "CreateSignOrderVC.h"
#import "TPKeyboardAvoidingTableView.h"
#import <Masonry/Masonry.h>
#import "TPPasswordTextView.h"
#import "SHTradeService.h"
#import "SHConfirmReceiveHeaderCell.h"
#import "SHConfirmReceiveMiddleCell.h"
#import "SHConfirmReceiveBottomCell.h"
#import "CreatFlowPhotoTableViewCell.h"
#import "PhotoViewController.h"
#import "ELCImagePickerController.h"
#import "TradeDetaiHeaderCell.h"
#import "SHReceiveConfirmVC.h"
#import "UIImage+Custom.h"
#import "LijianhuiLB.h"

@interface CreateSignOrderVC ()<UITableViewDelegate,UITableViewDataSource,CreatFlowPhotoTableViewCellDelegate,PhotoViewControllerDelegate,ELCImagePickerControllerDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate>

@property (nonatomic,strong) NSArray *listArray;
@property (nonatomic,strong) NSMutableArray *imageMutArray;
@property (nonatomic,strong) NSMutableArray *imageIDMutArray;
@property (nonatomic,strong) TPKeyboardAvoidingTableView *dataTB;
@property (nonatomic,assign) NSInteger uploadCount;

@property (nonatomic,strong) SHGetBuyListModel *getBuyListModel;
@property (nonatomic,strong) SHOrderModel *orderModel;
@property (nonatomic,strong) SHConfirmModel *confirmModel;

@end

@implementation CreateSignOrderVC

-(id)initWithOrderModel:(SHOrderModel*)orderModel listArray:(NSArray*)listArray getBuyListModel:(SHGetBuyListModel*)getBuyListModel{
    if (self = [super init]) {
        self.orderModel = orderModel;
        
        for (NSInteger i=0; i<listArray.count; i++) {
            SHTradeGetListModel *tradeGetListModel = listArray[i];
            
            if (tradeGetListModel.TakenQuantity.integerValue != 0) {
                tradeGetListModel.customQuantity = tradeGetListModel.TakenQuantity;
            }else{
                tradeGetListModel.customQuantity = tradeGetListModel.Quantity;
            }
        }
        
        self.listArray = listArray;
        self.getBuyListModel = getBuyListModel;
    }
    return self;
}

-(void)Confirm{
    if (![self checkLoginStatus]) {
        [self toast:STR_TRADE_TOAST_AGAIN_LOGIN];
        return;
    }
    
    SHUserModel *userModel = [[SHUserManager sharedManager] getUserInfoDirect];
    NSDate *currentDate = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd+**+HH:mm:ss"];
    NSString *dateString = [dateFormatter stringFromDate:currentDate];
    NSMutableArray *ReceiptTakenQuantityList = [NSMutableArray arrayWithCapacity:0];
    
    BOOL effect = NO;
    for (NSInteger i=0; i<self.listArray.count; i++) {
        SHTradeGetListModel *tradeGetListModel = self.listArray[i];
        
        if (tradeGetListModel.customQuantity.integerValue == 0) {
            effect = YES;
        }
        
        NSDictionary *tempDic = @{
                                  @"DeliveryID":tradeGetListModel.DeliveryID,
                                  @"Quantity":tradeGetListModel.Quantity,
                                  @"TakenQuantity":tradeGetListModel.customQuantity
                                  };
        
        
        [ReceiptTakenQuantityList addObject:tempDic];
    }
    
    NSMutableArray *ReceiptFileListArray = [NSMutableArray arrayWithCapacity:0];
    
    for (NSString *fileID in self.imageIDMutArray) {
        NSDictionary *ReceiptFileListDic = @{
                                             @"OrderID":self.orderModel.OrderID,
                                             @"ReceiptID":@"0",
                                             @"CREATETIME":dateString,
                                             @"FileID":fileID
                                             };
        
        [ReceiptFileListArray addObject:ReceiptFileListDic];
    }
    
    if (effect) {
        [self toast:@"请输入有效的实收数量"];
        return;
    }
    
    SHQueryCondition * condition = [SHQueryCondition defaultCondition];
    condition.parameter = URL_PARAMETER_Confirm(@"0", self.orderModel.OrderID, @"20", userModel.UserCode, dateString, userModel.UserCode, dateString, ReceiptFileListArray, ReceiptTakenQuantityList);
    
    [self showProgress];
    [SHTradeService ConfirmServiceWithCondition:condition callback:^(NSError *err, SHConfirmModel *confirmModel) {
        [self hideProgress];
        if (err == nil) {
            [self alertTitle:@"操作成功" message:@"提交签收成功" cancelTitle:STR_ALERT_SURE];
        }else{
            [self toast:err.userInfo[@"NSLocalizedDescription"]];
        }
    }];
    
}


#pragma mark UIAlertViewDelegate
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    [[NSNotificationCenter defaultCenter] postNotificationName:TRADE_REFRESH_NOTIFICATION object:nil];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"提交签收";
    [self addeSubView];
    
}

-(TPKeyboardAvoidingTableView*)dataTB{
    if (!_dataTB) {
        _dataTB = [[TPKeyboardAvoidingTableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _dataTB.backgroundColor = BACKGROUNDCOLOR_CUSTOM;
        
        [_dataTB registerClass:[TradeDetaiHeaderCell class] forCellReuseIdentifier:NSStringFromClass([TradeDetaiHeaderCell class])];
        [_dataTB registerClass:[SHConfirmReceiveMiddleCell class] forCellReuseIdentifier:NSStringFromClass([SHConfirmReceiveMiddleCell class])];
        [_dataTB registerClass:[SHConfirmReceiveBottomCell class] forCellReuseIdentifier:NSStringFromClass([SHConfirmReceiveBottomCell class])];
        [_dataTB registerClass:[CreatFlowPhotoTableViewCell class] forCellReuseIdentifier:NSStringFromClass([CreatFlowPhotoTableViewCell class])];
        
        [_dataTB setDelegate:self];
        [_dataTB setDataSource:self];
    }
    return _dataTB;
}

-(NSInteger)countImageCellHeight:(NSInteger)imageCount{
    imageCount = imageCount;
    NSInteger margin = 15;
    NSInteger imageWidth = (ScreenWidth-margin*5)/4;
    NSInteger yMultiply = imageCount/4 + 1;
    NSInteger height = margin+(imageWidth+margin)*yMultiply;
    return height;
}

-(NSMutableArray*)imageMutArray{
    if (!_imageMutArray) {
        _imageMutArray = [[NSMutableArray alloc] initWithArray:self.getBuyListModel.ReceiptList];
    }
    return _imageMutArray;
}

-(NSMutableArray*)imageIDMutArray{
    if (!_imageIDMutArray) {
        _imageIDMutArray = [[NSMutableArray alloc] initWithCapacity:0];
    }
    return _imageIDMutArray;
}


-(void)addeSubView{
    [self.view addSubview:self.dataTB];
    
    [self.dataTB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.view.mas_top);
        make.bottom.mas_equalTo(self.view.mas_bottom).offset(-50);
        make.left.mas_equalTo(self.view.mas_left);
        make.right.mas_equalTo(self.view.mas_right);
    }];
    
    UIButton *cancelBT = [[UIButton alloc] initWithFrame:CGRectZero];
    cancelBT.backgroundColor = LIGHTGRAYf2;
    [cancelBT setTitleColor:BLACK_CUSTOM forState:UIControlStateNormal];
    cancelBT.titleLabel.font = [UIFont systemFontOfSize:16];
    [cancelBT setTitle:STR_ALERT_CANCEL forState:UIControlStateNormal];
    [self.view addSubview:cancelBT];
    [cancelBT addTarget:self action:@selector(cancelBTAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [cancelBT mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.view.mas_bottom).offset(-50);
        make.left.mas_equalTo(0);
        make.width.mas_equalTo(ScreenWidth/2);
        make.height.mas_equalTo(50);
    }];
    
    UIButton *confirmBT = [[UIButton alloc] initWithFrame:CGRectZero];
    confirmBT.backgroundColor = COLOR_NAV_RED;
    [confirmBT setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    confirmBT.titleLabel.font = [UIFont systemFontOfSize:16];
    [confirmBT setTitle:@"生成签收单" forState:UIControlStateNormal];
    [self.view addSubview:confirmBT];
    [confirmBT addTarget:self action:@selector(confirmButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [confirmBT mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.view.mas_bottom).offset(-50);
        make.left.mas_equalTo(self.view.mas_left);
        make.right.mas_equalTo(self.view.mas_right);
        make.height.mas_equalTo(50);
    }];
    
}

-(void)cancelBTAction:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)confirmButtonAction:(id)sender{
    BOOL effect = YES;
    for (NSInteger i=0; i<self.listArray.count; i++) {
        SHTradeGetListModel *tradeGetListModel = self.listArray[i];
        float customQuantity = tradeGetListModel.customQuantity.floatValue;
        float Quantity = tradeGetListModel.Quantity.floatValue;
        if (customQuantity <= 0||customQuantity > Quantity) {
            effect = NO;
            break;
        }
    }
    
    if (!effect) {
        [self toast:@"请输入有效的实收数量"];
        return;
    }
    
    if (self.imageMutArray.count == 0) {
        [self toast:@"请添加图片"];
    }else if(self.imageMutArray.count > 10){
        [self toast:@"最多添加10张图片"];
    }else{
        [self GetWordUrlWithReceipt];
    }
}

-(void)GetWordUrlWithReceipt{
    if (![self checkLoginStatus]) {
        [self toast:STR_TRADE_TOAST_AGAIN_LOGIN];
        return;
    }
    
    SHUserModel * userModel = [[SHUserManager sharedManager] getUserInfoDirect];
   
    
    NSDictionary *subDic = @{
                             @"OrderId":self.orderModel.OrderID,
                             @"TraderID":userModel.TraderID,
                             @"FirmId":userModel.FirmID,
                             };
    
    SHQueryCondition * condition = [SHQueryCondition defaultCondition];
    condition.parameter = @{@"json":@{@"ServiceName":@"Shcem.Trade.ServiceContract.IOrderService",
                                      @"MethodName":@"GetWordUrlWithReceipt",
                                      @"Userid":[[SHUserManager sharedManager] getUserId],
                                      @"Version":B_VERSION,
                                      @"Params":[NSJSONSerialization stringWithJSONObject:subDic]
                                      }};
    [self showProgress];
    [SHTradeService getLeadsTemplateListServiceWithCondition:condition callback:^(NSError *err, NSArray *dataArray) {
        [self hideProgress];
        if (err == nil) {
            SHReceiveConfirmVC *orderVC = [[SHReceiveConfirmVC alloc] initWithOrderModel:self.orderModel listArray:self.listArray getBuyListModel:self.getBuyListModel imageArray:self.imageMutArray];
            [self.navigationController pushViewController:orderVC animated:YES];
        }else{
            [self toast:err.userInfo[@"NSLocalizedDescription"]];
        }
        
    }];
}



#pragma mark - UIImagePickerControllerDelegate -

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    image = [UIImage fixOrientation:image];
    NSData * data =  UIImageJPEGRepresentation(image, 0.3);
    image = [UIImage imageWithData:data];
    [self.imageMutArray addObject:image];
    [self.dataTB reloadData];
    [picker dismissViewControllerAnimated:YES completion:nil];
}

-(void)showActionSheet{
        UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"提示"
                                                             delegate:self
                                                    cancelButtonTitle:@"取消"
                                               destructiveButtonTitle:@"拍照"
                                                    otherButtonTitles:@"相册",nil];
    
    [actionSheet showInView:self.view];
}


#pragma  mark  UIActionSheetDelegate

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(self.imageMutArray.count > 10){
        [self toast:@"最多添加10张图片"];
    }else{
        if (buttonIndex == 0) {
            [self openCamera];
        }else if(buttonIndex == 1){
            [self openPhotoAlbum];
        }
    }
}


-(void)openPhotoAlbum{
    // Create the image picker
    ELCImagePickerController *elcPicker = [[ELCImagePickerController alloc] initImagePicker];
    elcPicker.maximumImagesCount = 10-self.imageMutArray.count; //Set the maximum number of images to select, defaults to 4
    elcPicker.returnsOriginalImage = NO; //Only return the fullScreenImage, not the fullResolutionImage
    elcPicker.returnsImage = YES; //Return UIimage if YES. If NO, only return asset location information
    elcPicker.onOrder = YES; //For multiple image selection, display and return selected order of images
    elcPicker.imagePickerDelegate = self;
    
    //Present modally
    [self presentViewController:elcPicker animated:YES completion:nil];
    
}

#pragma mark - PhotoViewControllerDelegate -
-(void)PhotoViewControllerDeleteNumber:(NSInteger)number{
    [self.imageMutArray removeObjectAtIndex:number];
    [self.dataTB reloadData];
}

#pragma mark - ELCImagePickerControllerDelegate -


- (void)elcImagePickerController:(ELCImagePickerController *)picker didFinishPickingMediaWithInfo:(NSArray *)info{
    for ( NSInteger i= 0 ; i<info.count; i++) {
        NSDictionary *imageDic = info[i];
        UIImage *image = imageDic[UIImagePickerControllerOriginalImage];
        NSData * data =  UIImageJPEGRepresentation(image, 0.3);
        image = [UIImage imageWithData:data];
        [self.imageMutArray addObject:image];
    }
    
    [picker dismissViewControllerAnimated:YES completion:nil];
    [self.dataTB reloadData];
}

- (void)elcImagePickerControllerDidCancel:(ELCImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - CreatFlowPhotoTableViewCellDelegate -
-(void)CreatFlowPhotoTableViewCellDelegateWithButtonIndex:(NSInteger)buttonIndex imageArray:(NSArray *)imageArray{
    if (imageArray.count) {
        //        图片预览
        PhotoViewController *ViewController = [[PhotoViewController alloc] init];
        ViewController.delegate =self;
        ViewController.showDeleteButton = true;
        ViewController.viewIndex = buttonIndex;
        ViewController.imageArray = imageArray;
        UINavigationController *nv = [[UINavigationController alloc] initWithRootViewController:ViewController];
        [self presentViewController:nv animated:YES completion:nil];
    }else{
        //        添加图片
        [self showActionSheet];
    }
    
}


- (void)openCamera
{
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.delegate = self;
        controller.sourceType = UIImagePickerControllerSourceTypeCamera;
        [self presentViewController:controller animated:YES completion:NULL];
    }
}


#pragma mark - UITableViewDelegate -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case 0:
        {
            return 1;
        }
            break;
            
        case 1:
        {
            return self.listArray.count;
        }
            break;
            
        default:
        {
            return 1;
        }
            break;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 3;
}

-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if (section == 1) {
        UIView *sectionView = [[UIView alloc] init];
        sectionView.backgroundColor = [UIColor whiteColor];
        NSArray *tradeReceiveArray = @[
                                       @"交收单号",
                                       @"交收数量（吨）",
                                       @"实收数量（吨）",
                                       ];
        
        for (NSInteger i= 0; i<tradeReceiveArray.count; i++) {
            
            UILabel* QuantityTitleLB = [[UILabel alloc] initWithFrame:CGRectZero];
            QuantityTitleLB.font = [UIFont systemFontOfSize:14];
            QuantityTitleLB.textAlignment = NSTextAlignmentCenter;
            QuantityTitleLB.textColor = LIGHTGRAY_CUSTOM;
            QuantityTitleLB.text = tradeReceiveArray[i];
            [sectionView addSubview:QuantityTitleLB];
            [QuantityTitleLB mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(sectionView.mas_top);
                make.left.mas_equalTo(sectionView.mas_left).offset(ScreenWidth/3*(i%3));
                make.width.mas_equalTo(ScreenWidth/3);
                make.height.mas_equalTo(44);
            }];
        }
        
        return sectionView;
    }else{
        return nil;
    }
}

-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    if (section == 1) {
        UIView *sectionView = [[UIView alloc] init];
        sectionView.backgroundColor = [UIColor whiteColor];
        
        LijianhuiLB* CouponBalanceLB = [[LijianhuiLB alloc] initWithFrame:CGRectZero];
        CouponBalanceLB.font = [UIFont systemFontOfSize:13];
        CouponBalanceLB.textColor = COLOR_NAV_RED;
        CouponBalanceLB.numberOfLines = 0;
        CouponBalanceLB.layer.masksToBounds = YES;
        CouponBalanceLB.layer.cornerRadius = 5;
        CouponBalanceLB.lineBreakMode = NSLineBreakByCharWrapping;
        CouponBalanceLB.backgroundColor = LIGHTRED_CUSTOM;
        CouponBalanceLB.textInsets      = UIEdgeInsetsMake(10.f, 12.f, 10.f, 10.f);
        CouponBalanceLB.text = [NSString stringWithFormat:@"请至上海化交官网下载《货物签收单》，完整、准确填写并加盖公章、合同章等实物印章，拍照上传等待审核通过即可。"];
        [sectionView addSubview:CouponBalanceLB];
        [CouponBalanceLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(sectionView.mas_top).offset(10);
            make.left.mas_equalTo(sectionView.mas_left).offset(10);
            make.right.mas_equalTo(sectionView.mas_right).offset(-10);
            make.height.mas_equalTo(80);
        }];
        return sectionView;
    }else{
        return nil;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    switch (section) {
        case 1:
            return 44;
            break;
            
        default:
            return 10;
            break;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return section == 1? 100:0.01;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
        case 0:
        {
            return 44;
        }
            break;
            
        case 1:
        {
            return 44;
        }
            break;
            
        default:
        {
            return [self countImageCellHeight:self.imageMutArray.count];
        }
            break;
    }
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.section) {
        case 0:
        {
            TradeDetaiHeaderCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([TradeDetaiHeaderCell class])];
            cell.getBuyListModel = self.getBuyListModel;
            return cell;
        }
            break;
            
        case 1:
        {
            SHConfirmReceiveMiddleCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([SHConfirmReceiveMiddleCell class])];
            cell.tradeGetListModel = self.listArray[indexPath.row];
            return cell;
        }
            break;
            
        default:
        {
            CreatFlowPhotoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([CreatFlowPhotoTableViewCell class])];
            cell.delegate = self;
            [cell setImageArray:self.imageMutArray];
            return cell;
        }
            break;
    }
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
