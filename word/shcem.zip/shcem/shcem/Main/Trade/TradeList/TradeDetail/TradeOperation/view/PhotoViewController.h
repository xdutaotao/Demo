//
//  PhotoViewController.h
//  OA
//
//  Created by wangyu on 15/8/27.
//  Copyright (c) 2015年 wangyu. All rights reserved.
//
@protocol PhotoViewControllerDelegate <NSObject>

@optional

-(void)PhotoViewControllerDeleteNumber:(NSInteger)number;

@end


@interface PhotoViewController : UIViewController

@property (nonatomic ,weak) id<PhotoViewControllerDelegate> delegate;

@property (assign, nonatomic) BOOL showDeleteButton;

@property (strong, nonatomic) NSArray* imageArray;

@property (assign, nonatomic) NSInteger viewIndex;



@end
