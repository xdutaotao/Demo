//
//  PhotoViewController.m
//  OA
//
//  Created by wangyu on 15/8/27.
//  Copyright (c) 2015年 wangyu. All rights reserved.
//

#import "PhotoViewController.h"
#import "UIImageView+WebCache.h"

@interface PhotoViewController ()<UIScrollViewDelegate>


@property (strong, nonatomic)  UIScrollView *dataSV;
@property (nonatomic,strong) UIButton *rightBT;
@property (assign, nonatomic) NSInteger addTag;


@end

@implementation PhotoViewController

-(NSInteger)addTag{
    if (!_addTag) {
        _addTag = 100;
    }
 
    return _addTag;
}

-(UIScrollView*)dataSV{
    if (!_dataSV) {
        _dataSV = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 64, ScreenWidth, ScreenHeight-64)];
        _dataSV.pagingEnabled = true;
        _dataSV.delegate = self;
        _dataSV.backgroundColor = BACKGROUNDCOLOR_CUSTOM;
        _dataSV.showsHorizontalScrollIndicator = false;
    }
    return _dataSV;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"图片预览";
    [self.view addSubview:self.dataSV];
    self.automaticallyAdjustsScrollViewInsets = false;
    
    [self addRightButtonImageName:@"Delete" title:nil];
    
    UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doubleTap:)];
    doubleTap.numberOfTapsRequired = 2;
    [self.dataSV addGestureRecognizer:doubleTap];
    
    UITapGestureRecognizer *oneTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(backBTAction:)];
    [self.dataSV addGestureRecognizer:oneTap];
    self.dataSV.backgroundColor = BACKGROUNDCOLOR_CUSTOM;
    [oneTap requireGestureRecognizerToFail:doubleTap];
    
    [self addDeleteButton];
    
    [self addChiefView];
}

-(void)addDeleteButton{
    self.rightBT.hidden = !self.showDeleteButton;
}

-(void)addRightButtonImageName:(NSString *)imageName title:(NSString *)title{
    self.rightBT = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.rightBT setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.rightBT addTarget:self action:@selector(rightBTAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.rightBT setImageEdgeInsets:UIEdgeInsetsMake(5, 5, 5, 5)];
    
    if ([imageName isKindOfClass:[NSString class]]) {
        [self.rightBT setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
        self.rightBT.frame = CGRectMake(0, 0, 44, 44);
    }else{
        [self.rightBT setTitle:title forState:UIControlStateNormal];
        CGRect rightButtonRect = [title boundingRectWithSize:CGSizeMake(ScreenWidth/3,44) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14]} context:nil];
        CGSize rightButtonSize = rightButtonRect.size;
        self.rightBT.frame = CGRectMake(0, 0, rightButtonSize.width+10, rightButtonSize.height);
    }
    
    UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                       
                                                                                    target:nil action:nil];
    
    negativeSpacer.width = -10;
    
    
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:self.rightBT];
    self.navigationItem.rightBarButtonItems =@[negativeSpacer,rightItem];
}


-(void)addChiefView{
    for (NSInteger i=0; i<self.imageArray.count; i++) {
        
        UIScrollView *tempSV = [[UIScrollView alloc] initWithFrame:CGRectMake(ScreenWidth*i, 0, ScreenWidth, ScreenHeight-64)];
        tempSV.showsHorizontalScrollIndicator = NO;
        tempSV.showsVerticalScrollIndicator = NO;
        tempSV.delegate = self;
        tempSV.maximumZoomScale = 2;
        tempSV.tag = self.addTag + i;
        [self.dataSV addSubview:tempSV];
        
        id image =  self.imageArray[i];
        UIImageView *tempIV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight-64)];
        
        if (![image isKindOfClass:[UIImage class]]) {
            NSString *urlString = [NSString stringWithFormat:@"%@%@",BANNERDOWNLOADURL,image];
            [tempIV sd_setImageWithURL:[NSURL URLWithString:[urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] placeholderImage:[UIImage imageNamed:@"LoadFail"]];
        }else{
             [tempIV setImage:self.imageArray[i]];
        }
        
        tempIV.tag = 999;
        tempIV.contentMode = UIViewContentModeScaleAspectFit;
        [tempSV addSubview:tempIV];

    }
    
    [self.dataSV setContentSize:CGSizeMake(ScreenWidth*self.imageArray.count, ScreenHeight-64)];
    [self.dataSV setContentOffset:CGPointMake(ScreenWidth*self.viewIndex, 0)];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)doubleTap:(id)sender{
    UIScrollView *tempSV = [self.dataSV viewWithTag:self.addTag +self.viewIndex];
    
    if (tempSV.zoomScale >1) {
        
        [UIView animateWithDuration:0.3 animations:^{
            tempSV.zoomScale = 1;
            tempSV.scrollEnabled = YES;
        }];
        
    }else{
        [UIView animateWithDuration:0.3 animations:^{
            tempSV.zoomScale = 2;
            tempSV.scrollEnabled = YES;
        }];
    }
    
    [self centerContentNumber:self.viewIndex];
    
}

- (void)backBTAction:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)rightBTAction:(id)sender{
    if ([self.delegate respondsToSelector:@selector(PhotoViewControllerDeleteNumber:)]) {
        [self.delegate PhotoViewControllerDeleteNumber:self.viewIndex];
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
}


#pragma mark - UIScrollViewDelegate -

//计算viewindex
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    if (scrollView == self.dataSV) {
        
        self.viewIndex = scrollView.contentOffset.x/ScreenWidth;
    }
}

-(void)setViewIndex:(NSInteger)viewIndex{
    if (_viewIndex == viewIndex) {
        return;
    }
    
    _viewIndex = viewIndex;
    
    UIScrollView *tempSV = [self.dataSV viewWithTag:self.addTag+_viewIndex];
    if (tempSV.zoomScale >1) {
        
        [UIView animateWithDuration:0.3 animations:^{
            tempSV.zoomScale = 1;
            tempSV.scrollEnabled = YES;
        }];
    }
    
    [self centerContentNumber:_viewIndex];
}


//缩放控制

-(void)scrollViewDidZoom:(UIScrollView *)scrollView{

}

-(UIView*)viewForZoomingInScrollView:(UIScrollView *)scrollView{
    
    if (scrollView != self.dataSV) {
        return [scrollView viewWithTag:999];
    }else{
        return nil;
    }
    
}

- (void)centerContentNumber:(NSInteger)number
{
    UIScrollView *tempSV = [self.dataSV viewWithTag:self.addTag+number];
    UIImageView *tempIV = [tempSV viewWithTag:999];
    UIImage *tempImage = tempIV.image;
    
//    SV 尺寸
    float tempSVWidth = tempSV.frame.size.width;
    float tempSVHeight = tempSV.frame.size.height;
    
    
//    SV 内容尺寸
    float tempSViewControllerontentWidth = tempSV.contentSize.width;
    float tempSViewControllerontentHeight = tempSV.contentSize.height;
    
    
    
//    图片尺寸
    float tempImageWidth = tempImage.size.width;
    float tempImageHeight = tempImage.size.height;
    
    if (tempSViewControllerontentWidth && tempSViewControllerontentHeight && tempImageWidth && tempImageHeight) {
        
    }else{
        return;
    }
    
//    图片和SV比例
    float ratio = tempImageWidth/tempImageHeight;
    float tempSVRatio = tempSVWidth/tempSVHeight;
    
    
    float top = 0;
    float left = 0;
    
    if (ratio > tempSVRatio) {
//        计算实际高度
        float actualHeight = tempSViewControllerontentWidth/ratio;
        
        top = -(tempSViewControllerontentHeight - actualHeight)/2.0;
        
        if (actualHeight < tempSVHeight) {
            top += (tempSVHeight - actualHeight)/2.0;
        }
        
    }else{
        float actualWidth = tempSViewControllerontentHeight*ratio;
        
        left = -(tempSViewControllerontentWidth - actualWidth)/2.0;
        
        if (actualWidth < tempSVWidth) {
            left += (tempSVWidth - actualWidth)/2.0;
        }
    }
    
    tempSV.contentInset = UIEdgeInsetsMake(top, left, top, left);
    
}


@end



