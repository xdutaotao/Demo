//
//  CreateSignOrderVC.h
//  shcem
//
//  Created by xupeipei on 2017/3/21.
//  Copyright © 2017年 Shcem. All rights reserved.
//
#import "SHBaseViewController.h"
#import "SHOrderModel.h"
#import "SHGetBuyListModel.h"

@interface CreateSignOrderVC : SHBaseViewController

-(id)initWithOrderModel:(SHOrderModel*)orderModel listArray:(NSArray*)listArray getBuyListModel:(SHGetBuyListModel*)getBuyListModel;

@end
