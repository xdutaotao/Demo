//
//  SHBaseTabarController.m
//  Frey
//
//  Created by huangdeyu on 16/2/24.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import "SHBaseTabarController.h"
#import "SHTabBar.h"
#import "UITabBarItem+DYBadge.h"

@interface SHBaseTabarController ()<UITabBarControllerDelegate>
@end

@implementation SHBaseTabarController
-(instancetype)init{
    if (self = [super init]) {
       
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
     [self setValue:[[SHTabBar alloc] init] forKey:@"tabBar"];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateUnreadCount:) name:USER_UNREAD_COUNT_NOTIFICATION object:nil];
    [[SHUserManager sharedManager] updateUserInfo];
    self.delegate = self;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController{
    DLog(@"当前选中的控制器是:%@",viewController);
    if ([NSStringFromClass([viewController class]) isEqualToString:@"SHTradeVC"]) {
        ((SHTabBar *)self.tabBar).didSelectedCenterBtn = YES;
    }else{
        ((SHTabBar *)self.tabBar).didSelectedCenterBtn = NO;
    }
}
-(void)updateUnreadCount:(NSNotification *)notification{
    NSDictionary * dic = notification.object;
    if (dic) {
        NSInteger  num =  [dic[@"result"] integerValue];
        if (num > 0) {
            [self.tabBar.items[4] setBadgeValue:[NSString stringWithFormat:@"%ld",(long)num]];
        }else{
            [self.tabBar.items[4] setBadgeValue:nil];
        }
    }else{
        [self.tabBar.items[4] setBadgeValue:nil];
    }

}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
}

@end
