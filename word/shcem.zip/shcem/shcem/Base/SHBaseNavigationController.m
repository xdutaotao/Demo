//
//  SHBaseNavigationController.m
//  Frey
//
//  Created by huangdeyu on 16/6/23.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import "SHBaseNavigationController.h"

@interface SHBaseNavigationController ()

@end

@implementation SHBaseNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
