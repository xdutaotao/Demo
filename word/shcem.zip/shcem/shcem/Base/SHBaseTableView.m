//
//  SHBaseTableView.m
//  shcem
//
//  Created by huangdeyu on 2016/12/29.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHBaseTableView.h"
#import "SHRefreshHeader.h"
#import "SHLoadFailedView.h"
#import "SHHTTPManager.h"

@interface SHBaseTableView ()<SHLoadFailedViewDelegate>
@property(nonatomic,strong)SHLoadFailedView * loadFailedView;
@property(nonatomic,weak)NSMutableArray * models;
@property(nonatomic,weak)id<UITableViewDelegate,UITableViewDataSource,SHBaseTableViewDelegate> sourceController;
@end

@implementation SHBaseTableView


-(instancetype)initWithSource:(id<UITableViewDelegate,UITableViewDataSource,SHBaseTableViewDelegate>)source models:(NSMutableArray *)array frame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.delegate = source;
        self.dataSource = source;
        SHRefreshHeader * refreshHeader = [SHRefreshHeader  headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
        [refreshHeader setup];
        self.mj_header = refreshHeader;
        self.mj_footer =  [MJRefreshBackNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(footerRefresh)];
        self.models = array;
        self.sourceController = source;
        self.netSource = source;
        self.currentPage = 0;
        self.tableFooterView  = [UIView new];
    }
    return self;
}

-(void)getListWithPage:(NSInteger)page condition:(SHQueryCondition *) condition  pageSize:(NSInteger)pageSize successCallback:(void (^)(id objects))callback{
    
    [self hideLoadFailed];
    UIViewController * vc = (UIViewController *) self.sourceController;
    [vc showProgress];
    WS(weakSelf)
    [[SHHTTPManager sharedManager] queryWithCondition:condition andBlock:^(NSError *error, id responseObject) {
        [vc hideProgress];
        [weakSelf.mj_header endRefreshing];
        [weakSelf.mj_footer endRefreshing];
        if (error) {
            if (weakSelf.models.count == 0) {  //对于加载失败的情况，如果当前数据为空，则需要展示加载失败
                [weakSelf showLoadFaildWithTitle:@"数据加载失败\n下拉重新加载"];
            }else{
                [vc showError:error];
            }
            return;
        }
        if (page == 1) {
            weakSelf.currentPage = 1;
            [weakSelf.models removeAllObjects];
        }
        NSArray * arr = nil;
        if ([responseObject isKindOfClass:[NSDictionary class]]) {
            arr = [responseObject objectForKey:@"result"];
        }else{
            arr = responseObject;
        }
        if (weakSelf.models.count == 0 && ((NSArray *)arr).count == 0) {
            [weakSelf showLoadFaildWithTitle:@"数据为空"];
        }
        if (weakSelf.models.count > 0 && ((NSArray *)arr).count < pageSize) {
            [weakSelf.mj_footer endRefreshingWithNoMoreData];
        }
        weakSelf.currentPage = page;
        callback(arr);   //回调需要序列化和 reloadData
    }];
}

#pragma mark - private methods
-(void)showLoadFaildWithTitle:(NSString *)titles{
    if (![self containsSubView:self.loadFailedView]) {
        [self addSubview:self.loadFailedView];
        [self.loadFailedView showWithTitle:titles type:0];
    }
}
-(void)hideLoadFailed{
    [self.loadFailedView removeFromSuperview];
}

#pragma mark - refresh
-(void)headerRefresh{
   // [self.netSource loadDataWithType:0 page:1];
    [self.netSource loadDataWithPage:1];
}
-(void)footerRefresh{
  //  [self.netSource loadDataWithType:0 page:self.currentPage+1];
    [self.netSource loadDataWithPage:self.currentPage + 1];
}
#pragma mark - loadFailed delegate
-(void)loadFailedClicked{
    
}

#pragma mark - 初始化
-(SHLoadFailedView *)loadFailedView{
    if (!_loadFailedView) {
        _loadFailedView = [[SHLoadFailedView alloc] initWithFrame:self.bounds];
        _loadFailedView.delegate = self;
    }
    return _loadFailedView;
}

@end
