//
//  SHBaseTableView.h
//  shcem
//
//  Created by huangdeyu on 2016/12/29.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHHTTPManager.h"

@protocol  SHBaseTableViewDelegate <NSObject>

@required
-(void)loadDataWithPage:(NSInteger)page;

@end

@interface SHBaseTableView : UITableView
@property(nonatomic,weak) id<SHBaseTableViewDelegate> netSource;
@property(nonatomic,assign) NSInteger currentPage;
-(instancetype)initWithSource:(id<UITableViewDelegate,UITableViewDataSource>)source models:(NSMutableArray *)array frame:(CGRect)frame;
-(void)getListWithPage:(NSInteger)page condition:(SHQueryCondition *) condition  pageSize:(NSInteger)pageSize successCallback:(void (^)(id objects))callback;
@end
