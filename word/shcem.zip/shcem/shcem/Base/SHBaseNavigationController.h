//
//  SHBaseNavigationController.h
//  Frey
//
//  Created by huangdeyu on 16/6/23.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHBaseNavigationController : UINavigationController

@end
