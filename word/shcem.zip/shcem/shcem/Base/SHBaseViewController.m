//
//  SHBaseViewController.m
//  Frey
//
//  Created by huangdeyu on 16/2/25.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import "SHBaseViewController.h"
#import "SHTabBar.h"
#import "SHLoadFailedView.h"
#import "MobClick.h"
#import "BlackBGView.h"
#import "SHLoginVC.h"


@interface SHBaseViewController ()<SHLoadFailedViewDelegate,UIAlertViewDelegate>
@property(nonatomic,strong)SHLoadFailedView * loadFailedView;

@property(nonatomic,strong)UIAlertView *baseAlert;

@end

@implementation SHBaseViewController

-(void)dealloc{
    DLog(@"\n\n\n%@  释放了\n\n\n",[self class]);
}


-(BOOL)checkAuthority{
    SHUserModel * userModel = [[SHUserManager sharedManager] getUserInfoDirect];
    if (!userModel) {
        SHLoginVC * vc = [[SHLoginVC alloc] initWithEntryClass:NSStringFromClass([self class])];
        [self.navigationController pushViewController:vc animated:YES];
        return false;
    }else{
        NSInteger TradeAuthority = userModel.TradeAuthority;
        if (TradeAuthority == 0 || TradeAuthority == 1 || TradeAuthority == 2) {
            return true;
        }else{
            [self toast:@"权限不足！"];
            return false;
        }
    }
}

-(BOOL)checkLoginStatus{
    SHUserModel * userModel = [[SHUserManager sharedManager] getUserInfoDirect];
    if (userModel == nil) {
        return false;
    }else{
        return true;
    }
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:[NSString stringWithFormat:@"%@", [self class]]];
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:[NSString stringWithFormat:@"%@", [self class]]];
}

-(instancetype)init{
    if (self = [super init]) {
        self.onlyShowBackArray = YES;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    if (self.onlyShowBackArray) {
        UIBarButtonItem * barBtnItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"iconfont-fanhui"] style:UIBarButtonItemStylePlain target:self action:@selector(backBarBtnClicked)];
        self.navigationItem.leftBarButtonItem = barBtnItem;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(void)backBarBtnClicked{
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)popupSubview:(UIView*)subview edgeInsets:(UIEdgeInsets)edgeInsets{
    BlackBGView *bgView = [[BlackBGView alloc] initWithFrame:CGRectZero];
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    [keyWindow addSubview:bgView];
    [bgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(keyWindow).insets(UIEdgeInsetsMake(0, 0, 0, 0));
    }];
    
    [bgView addSubview:subview];
    
    [subview mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(bgView).insets(edgeInsets);
    }];
    
}

-(void)addRightButtonImageName:(NSString *)imageName title:(NSString *)title{
    UIButton *rightBT = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightBT setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [rightBT addTarget:self action:@selector(rightBTAction:) forControlEvents:UIControlEventTouchUpInside];
    [rightBT setImageEdgeInsets:UIEdgeInsetsMake(10, 10, 10, 10)];
    
    if ([imageName isKindOfClass:[NSString class]]) {
        [rightBT setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
        rightBT.frame = CGRectMake(0, 0, 44, 44);
    }else{
        [rightBT setTitle:title forState:UIControlStateNormal];
        CGRect rightButtonRect = [title boundingRectWithSize:CGSizeMake(ScreenWidth/3,44) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14]} context:nil];
        CGSize rightButtonSize = rightButtonRect.size;
        rightBT.frame = CGRectMake(0, 0, rightButtonSize.width+10, rightButtonSize.height);
    }
    
    UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                       
                                                                                   target:nil action:nil];
    
    negativeSpacer.width = -10;
    
    
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:rightBT];
    self.navigationItem.rightBarButtonItems =@[negativeSpacer,rightItem];
}

-(void)rightBTAction:(id)sender{
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"telprompt://%@", TELPHONEDEAL]];
    [[UIApplication sharedApplication] openURL:url];
}

-(void)pushVC:(Class)VC{
    UIViewController* pushVC = [[VC alloc] init];
    pushVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:pushVC animated:YES];
}

-(void)showLoadFailedWithTitle:(NSString *)title type:(SHLoadFailedStatus)type below:(UIView *)view{
    if (![self.view containsSubView:self.loadFailedView]) {
        [self.view insertSubview:self.loadFailedView belowSubview:view];
    }
    [self.loadFailedView showWithTitle:title type:type];
}
-(void)hideLoadFailedView{
    [self.loadFailedView removeFromSuperview];
}

-(void)alert{
    [self alertTitle:@"成功" message:@"操作成功" cancelTitle:@"确认"];
}

-(void)alertTitle:(NSString*)title message:(NSString*)message cancelTitle:(NSString*)cancelTitle{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:message delegate:self cancelButtonTitle:cancelTitle otherButtonTitles:nil];
    alert.tag = BaseAlertTag;
    [alert show];
}

#pragma mark UIAlertViewDelegate
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == BaseAlertTag) {
        [self.navigationController popToRootViewControllerAnimated:YES];
//        [self.navigationController popViewControllerAnimated:YES];
    }
}


#pragma mark - action
-(void)loadFailedClicked{
    
}

#pragma mark - 初始化
-(SHLoadFailedView *)loadFailedView{
    if (!_loadFailedView) {
        _loadFailedView = [[SHLoadFailedView alloc] initWithFrame:self.view.bounds];
        _loadFailedView.delegate = self;
    }
    return  _loadFailedView;
}

@end
