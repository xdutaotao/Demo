//
//  SHTabBar.m
//  Frey
//
//  Created by huangdeyu on 16/2/24.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import "SHTabBar.h"
#import <objc/runtime.h>
#import "Masonry.h"
#define MARGINSPACE 40      //靠近边界的距离
#define ITEMSPACE 75



@interface SHTabBar()
@property(nonatomic,strong)UIButton * centerBtn;
@end
@implementation SHTabBar

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self sharedInit];
    }
    return self;
}
- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self sharedInit];
    }
    return self;
}

-(void)sharedInit{
    if(SYSTEM_VERSION > 7.1){
        _didSelectedCenterBtn = NO;
        self.layer.borderColor = [UIColor clearColor].CGColor;
        self.layer.shadowColor = [UIColor colorWithWhite:0.8 alpha:1].CGColor;
        self.layer.shadowOffset = CGSizeMake(0, 0);
        self.layer.shadowRadius = 3.0;
        self.layer.shadowOpacity = 1.0;
        self.backgroundColor = [UIColor whiteColor];
        [self addCenter];
    }
}
-(void)addCenter{
    if (![self containsSubView:self.centerBtn]) {
        [self addSubview:self.centerBtn];
    }
}
-(void)centerBtnClicked:(UIButton *)btn{
    [((UITabBarController *)self.viewController) setSelectedIndex:2];
    btn.selected = YES;
}
-(void)layoutSubviews{
    [super layoutSubviews];
    DLog(@"重新布局");
    NSMutableArray * tabBarButtonItems = [NSMutableArray array];
    for (UIView * childView in self.subviews) {
        if ([childView isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
            [tabBarButtonItems addObject:childView];
        }
    }
    [tabBarButtonItems enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        UIView * view = obj;
        if (view.centerX < self.centerX) {
       //     view.centerX = MARGINSPACE +idx * ITEMSPACE;
        }else if(view.centerX > self.centerX){
        //    view.centerX = ScreenWidth-MARGINSPACE - (tabBarButtonItems.count - idx-1) * ITEMSPACE;
        }else{
            //[view removeFromSuperview];
            view.userInteractionEnabled = NO;
        }
    }];
    [self.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSString * str = NSStringFromClass([obj class]);
        if ([str isEqualToString:@"_UIBarBackground"] || [str isEqualToString:@"_UITabBarBackgroundView"] || [str isEqualToString:@"UIImageView"]) {
            [obj removeFromSuperview];
            *stop = YES;
        }
    }];
}


/*
 *
 Capturing touches on a subview outside the frame of its superview
 *
 */
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    if (!self.clipsToBounds && !self.hidden && self.alpha > 0) {
        UIView *result = [super hitTest:point withEvent:event];
        if (result) {
            return result;
        } else {
            for (UIView *subview in self.subviews.reverseObjectEnumerator) {
                CGPoint subPoint = [subview convertPoint:point fromView:self];
                result = [subview hitTest:subPoint withEvent:event];
                if (result) {
                    return result;
                }
            }
        }
    }
    return nil;
}
-(void)setDidSelectedCenterBtn:(BOOL)didSelectedCenterBtn{
    _didSelectedCenterBtn = didSelectedCenterBtn;
    if (didSelectedCenterBtn) {
        self.centerBtn.selected = YES;
    }else{
        self.centerBtn.selected = NO;
    }
}

#pragma mark - 初始化
-(UIButton *)centerBtn{
    if (!_centerBtn) {
        _centerBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_centerBtn setBackgroundImage:[UIImage imageNamed:@"order"] forState:UIControlStateNormal];
        [_centerBtn setBackgroundImage:[UIImage imageNamed:@"order_h"] forState:UIControlStateSelected];
        _centerBtn.frame = CGRectMake(0, 0, 60, 60);
        _centerBtn.center = CGPointMake(ScreenWidth *  .5, 9);
        [_centerBtn addTarget:self action:@selector(centerBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _centerBtn;
}

@end
