//
//  SHBaseViewController.h
//  Frey
//
//  Created by huangdeyu on 16/2/25.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHLoadFailedView.h"
@interface SHBaseViewController : UIViewController
@property(nonatomic,assign)BOOL onlyShowBackArray;
/**
 *  返回按钮点击
 */
-(void)backBarBtnClicked;

-(void)loadFailedClicked;

-(void)showLoadFailedWithTitle:(NSString *)title type:(SHLoadFailedStatus) type below:(UIView *)view;
-(void)hideLoadFailedView;

-(void)popupSubview:(UIView*)subview edgeInsets:(UIEdgeInsets)edgeInsets;
-(BOOL)checkAuthority;

-(BOOL)checkLoginStatus;
//添加导航栏右部按钮
-(void)addRightButtonImageName:(NSString *)imageName title:(NSString *)title;

//导航栏右按钮事件
-(void)rightBTAction:(id)sender;

// 入栈一个VC
-(void)pushVC:(Class)VC;

//弹出alert 默认点击返回 tag 9889
-(void)alert;

-(void)alertTitle:(NSString*)title message:(NSString*)message cancelTitle:(NSString*)cancelTitle;

@end
