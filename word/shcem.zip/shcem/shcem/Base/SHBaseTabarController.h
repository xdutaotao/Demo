//
//  SHBaseTabarController.h
//  Frey
//
//  Created by huangdeyu on 16/2/24.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHBaseTabarController : UITabBarController
@end
