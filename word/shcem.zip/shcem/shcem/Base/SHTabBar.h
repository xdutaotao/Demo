//
//  SHTabBar.h
//  Frey
//
//  Created by huangdeyu on 16/2/24.
//  Copyright © 2016年 shcem. All rights reserved.
//自定义tabBar 需要解决两个关键性问题：1、添加额外的按钮布局问题。 2、添加额外按钮,额外按钮超出tabBar 范围点击问题

#import <UIKit/UIKit.h>

@interface SHTabBar : UITabBar
@property(nonatomic,assign)BOOL didSelectedCenterBtn;
@end
