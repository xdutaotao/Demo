//
//  SHLoadFailedView.m
//  shcem
//
//  Created by huangdeyu on 2016/12/26.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHLoadFailedView.h"
#import "Masonry.h"

@interface SHLoadFailedView ()
@property(nonatomic,strong)UIButton * titleBtn;

@end

@implementation SHLoadFailedView
-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.titleBtn];
        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = NO;
        [self layout];
    }
    return self;
}
-(void)layout{
    [self.titleBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self);
    }];
}

-(void)showWithTitle:(NSString *)title type:(SHLoadFailedStatus)type{
    [self.titleBtn setTitle:title forState:UIControlStateNormal];
}

-(void)loadFailedClicked{
    [self.delegate loadFailedClicked];
}


#pragma mark - 初始化

-(UIButton *)titleBtn{
    if (!_titleBtn) {
        _titleBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        [_titleBtn.titleLabel setFont:[UIFont systemFontOfSize:FONT_DEFAULT]];
        _titleBtn.titleLabel.numberOfLines = 10;
        _titleBtn.titleLabel.textAlignment = NSTextAlignmentCenter;
        [_titleBtn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        [_titleBtn addTarget:self action:@selector(loadFailedClicked) forControlEvents:UIControlEventTouchUpInside];
    }
    return _titleBtn;
}

@end
