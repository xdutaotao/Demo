//
//  SHLoadFailedView.h
//  shcem
//
//  Created by huangdeyu on 2016/12/26.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger,SHLoadFailedStatus){
    SHLoadFailedStatusNoData = 0,
    SHLoadFailedStatusNoNetwork,
    SHLoadFailedStatusConnectFailed,
};

@protocol SHLoadFailedViewDelegate <NSObject>

@required
-(void)loadFailedClicked;

@end

@interface SHLoadFailedView : UIView
@property(nonatomic ,weak) id<SHLoadFailedViewDelegate> delegate;
-(void)showWithTitle:(NSString *)title type:(SHLoadFailedStatus) type;
@end
