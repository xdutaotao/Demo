//
//  SHTradeBreakBottomModel.m
//  shcem
//
//  Created by xupeipei on 2016/12/29.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHTradeBreakBottomModel.h"

@implementation SHTradeBreakBottomModel

@end
