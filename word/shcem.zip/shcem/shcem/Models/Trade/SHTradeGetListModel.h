//
//  SHTradeGetListModel.h
//  shcem
//
//  Created by xupeipei on 2016/12/16.
// copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHTradeGetListModel : NSObject

@property (nonatomic,copy) NSString * OrderID;
@property (nonatomic,copy) NSString * DeliveryID;
@property (nonatomic,copy) NSString * Quantity;
@property (nonatomic,copy) NSString * CategoryShow;
@property (nonatomic,copy) NSString * BrandShow;
@property (nonatomic,copy) NSString * TradeStatus;
@property (nonatomic,copy) NSString * TradeStatusShow;
@property (nonatomic,copy) NSString * LogisticsStatus;
@property (nonatomic,copy) NSString * BuyFee;
@property (nonatomic,copy) NSString * Amount;
@property (nonatomic,copy) NSString * StoreContactName;
@property (nonatomic,copy) NSString * Trader;
@property (nonatomic,copy) NSString * DelievryDateShow;
@property (nonatomic,copy) NSString * HistoryDeliveryID;
@property (nonatomic,copy) NSString * TakenQuantity;
@property (nonatomic,copy) NSString * DeliveryTypeShow;
@property (nonatomic,copy) NSString * GoodsType;
@property (nonatomic,copy) NSString * Price;
@property (nonatomic,copy) NSString * SourcePlaceShow;
@property (nonatomic,copy) NSString * StoreHouseShow;
@property (nonatomic,copy) NSString * MoreOrFew;
@property (nonatomic,copy) NSString * Address;
@property (nonatomic,copy) NSString * TradeUnitNumber;
@property (nonatomic,copy) NSString * SourcePlaceType;
@property (nonatomic,copy) NSString * AddressID;
@property (nonatomic,copy) NSString * BrandID;
@property (nonatomic,copy) NSString * BrandName;
@property (nonatomic,copy) NSString * CanOperate;
@property (nonatomic,copy) NSString * CargoAgentID;
@property (nonatomic,copy) NSString * CategoryLeafID;
@property (nonatomic,copy) NSString * CategoryLeafName;
@property (nonatomic,copy) NSString * ConformProduct;
@property (nonatomic,copy) NSString * CreditDeposit;
@property (nonatomic,copy) NSString * CreditFee;
@property (nonatomic,copy) NSString * DISABLED;
@property (nonatomic,copy) NSString * DealtQuantity;
@property (nonatomic,copy) NSString * DeliveryEndDate;
@property (nonatomic,copy) NSString * DeliveryPlace;
@property (nonatomic,copy) NSString * DeliveryPlaceId;
@property (nonatomic,copy) NSString * DeliveryStartDate;
@property (nonatomic,copy) NSString * DepositAlgr;
@property (nonatomic,copy) NSString * DepositRate;
@property (nonatomic,copy) NSString * Direction;
@property (nonatomic,copy) NSString * ExtraLogisticsCost;
@property (nonatomic,copy) NSString * FeeAlgr;
@property (nonatomic,copy) NSString * FeeRate;
@property (nonatomic,copy) NSString * FirmID;
@property (nonatomic,copy) NSString * FormatAnonymous;
@property (nonatomic,copy) NSString * FormatCargoAgent;
@property (nonatomic,copy) NSString * FormatCategoryBrand;
@property (nonatomic,copy) NSString * FormatCreateDate;
@property (nonatomic,copy) NSString * FormatDeliveryDate;
@property (nonatomic,copy) NSString * FormatDeliveryEndDate;
@property (nonatomic,copy) NSString * FormatDeliveryPlace;
@property (nonatomic,copy) NSString * FormatDeliveryStartDate;
@property (nonatomic,copy) NSString * FormatDepositRate;
@property (nonatomic,copy) NSString * FormatDepositRateInteger;
@property (nonatomic,copy) NSString * FormatDirection;
@property (nonatomic,copy) NSString * FormatExtraLogisticsCost;
@property (nonatomic,copy) NSString * FormatGoodsType;
@property (nonatomic,copy) NSString * FormatLeadsStatus;
@property (nonatomic,copy) NSString * FormatModifyDate;
@property (nonatomic,copy) NSString * FormatPackageStandard;
@property (nonatomic,copy) NSString * FormatPalletType;
@property (nonatomic,copy) NSString * FormatPettyCost;
@property (nonatomic,copy) NSString * FormatPettyCostRange;
@property (nonatomic,copy) NSString * FormatSettlementMethod;
@property (nonatomic,copy) NSString * FormatSourcePlaceType;
@property (nonatomic,copy) NSString * FormatTemplateDepositRateInteger;
@property (nonatomic,copy) NSString * FormatWHType;
@property (nonatomic,copy) NSString * FormatWareHouseContactDeliveryType;
@property (nonatomic,copy) NSString * ID;
@property (nonatomic,copy) NSString * IsRealName;
@property (nonatomic,copy) NSString * LeadsStatus;
@property (nonatomic,copy) NSString * MinQuantity;
@property (nonatomic,copy) NSString * MinWeight;
@property (nonatomic,copy) NSString * PackageStandard;
@property (nonatomic,copy) NSString * PalletType;
@property (nonatomic,copy) NSString * PaymentStatus;
@property (nonatomic,copy) NSString * PettyCeiling;
@property (nonatomic,copy) NSString * PettyCost;
@property (nonatomic,copy) NSString * PettyFloor;
@property (nonatomic,copy) NSString * REC_CREATEBY;
@property (nonatomic,copy) NSString * REC_CREATETIME;
@property (nonatomic,copy) NSString * REC_MODIFYBY;
@property (nonatomic,copy) NSString * REC_MODIFYTIME;
@property (nonatomic,copy) NSString * ResidualQuantity;
@property (nonatomic,copy) NSString * ResidualWeight;
@property (nonatomic,copy) NSString * SettlementMethod;
@property (nonatomic,copy) NSString * SourcePlaceID;
@property (nonatomic,copy) NSString * SourcePlaceName;
@property (nonatomic,copy) NSString * StoreHouseFN;
@property (nonatomic,copy) NSString * TakenTradeDeposit;
@property (nonatomic,copy) NSString * TakenTradeFee;
@property (nonatomic,copy) NSArray * TempPriceList;
@property (nonatomic,copy) NSString * TmpDepositAlgr;
@property (nonatomic,copy) NSString * TmpDepositRate;
@property (nonatomic,copy) NSString * TotalAvailableWeight;
@property (nonatomic,copy) NSString * TotalWeight;
@property (nonatomic,copy) NSString * TradeDeposit;
@property (nonatomic,copy) NSString * TradeDepositCalculate;
@property (nonatomic,copy) NSString * TradeFee;
@property (nonatomic,copy) NSString * TradeFeeCalculate;
@property (nonatomic,copy) NSString * TradeTmptId;
@property (nonatomic,copy) NSString * TradeUnit;
@property (nonatomic,copy) NSString * TraderID;
@property (nonatomic,copy) NSString * TraderName;
@property (nonatomic,copy) NSString * UserCode;
@property (nonatomic,copy) NSString * UserName;
@property (nonatomic,copy) NSString * WHAddress;
@property (nonatomic,copy) NSString * WHContactID;
@property (nonatomic,copy) NSString * WHGruopID;
@property (nonatomic,copy) NSString * WHType;
@property (nonatomic,copy) NSString * WareHouseContactDeliveryType;
@property (nonatomic,copy) NSString * WareHouseID;
//0: 自提；1:配送,2:转货权 
@property (nonatomic,copy) NSString * DeliveryType;

//交互
@property (nonatomic,copy) NSString * customQuantity;
@end
