//
//  SHMyInquerySubModel.h
//  shcem
//
//  Created by xupeipei on 2016/12/20.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHMyInquerySubModel : NSObject
@property(nonatomic,copy) NSString * BrandID;
@property(nonatomic,copy) NSString * CategoryLeafID;
@property(nonatomic,copy) NSString * DISABLED;
@property(nonatomic,copy) NSString * DealtQuantity;
@property(nonatomic,copy) NSString * DeliveryEndDate;
@property(nonatomic,copy) NSString * DeliveryPlaceId;
@property(nonatomic,copy) NSString * DeliveryStartDate;
@property(nonatomic,copy) NSString * DepositAlgr;
@property(nonatomic,copy) NSString * DepositRate;
@property(nonatomic,copy) NSString * Direction;
@property(nonatomic,copy) NSString * ExtraLogisticsCost;
@property(nonatomic,copy) NSString * FirmId;
@property(nonatomic,copy) NSString * FormatDepositRate;
@property(nonatomic,copy) NSString * FromatDeliveryEndDate;
@property(nonatomic,copy) NSString * FromatDeliveryStartDate;
@property(nonatomic,copy) NSString * GoodsType;
@property(nonatomic,copy) NSString * GoodsTypeShow;
@property(nonatomic,copy) NSString * ID;
@property(nonatomic,copy) NSString * IsRealName;
@property(nonatomic,copy) NSString * LeadsSort;
@property(nonatomic,copy) NSString * LeadsStatus;
@property(nonatomic,copy) NSString * LeadsStatusShow;
@property(nonatomic,copy) NSString * MinQuantity;
@property(nonatomic,copy) NSString * MinWeight;
@property(nonatomic,copy) NSString * PackageStandard;
@property(nonatomic,copy) NSString * PackageStandardShow;
@property(nonatomic,copy) NSString * PaymentStatus;
@property(nonatomic,copy) NSString * Price;
@property(nonatomic,copy) NSString * Quantity;
@property(nonatomic,copy) NSString * REC_CREATEBY;
@property(nonatomic,copy) NSString * REC_CREATETIME;
@property(nonatomic,copy) NSString * REC_CREATETIMEShow;
@property(nonatomic,copy) NSString * REC_MODIFYBY;
@property(nonatomic,copy) NSString * REC_MODIFYTIME;
@property(nonatomic,copy) NSString * ResidualWeight;
@property(nonatomic,copy) NSString * SettlementMethod;
@property(nonatomic,copy) NSString * SettlementMethodShow;
@property(nonatomic,copy) NSString * SourcePlaceID;
@property(nonatomic,copy) NSString * SourcePlaceShow;
@property(nonatomic,copy) NSString * StoreContactName;
@property(nonatomic,copy) NSString * StoreHouseId;
@property(nonatomic,copy) NSString * StoreHouseShow;
@property(nonatomic,copy) NSString * TotalWeight;
@property(nonatomic,copy) NSString * TradeTmptId;
@property(nonatomic,copy) NSString * TradeUnit;
@property(nonatomic,copy) NSString * TradeUnitNumber;

@end
