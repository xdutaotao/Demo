//
//  SHPayModel.h
//  shcem
//
//  Created by xupeipei on 2016/12/14.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHPayModel : NSObject

@property(nonatomic,copy) NSString * CouponFee;
@property(nonatomic,copy) NSString * Fee;
@property(nonatomic,copy) NSString * FirmBalance;
@property(nonatomic,copy) NSString * LateFee;
@property(nonatomic,copy) NSString * TakenMoney;

@end
