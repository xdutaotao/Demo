//
//  CustomScrollViewCellModel.h
//  shcem
//
//  Created by xupeipei on 2016/12/28.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CustomScrollViewCellModel : NSObject

@property(nonatomic,copy) NSString * title;
@property(nonatomic,copy) NSString * content;
@property(nonatomic,copy) NSString * paKey;
@property(nonatomic,copy) NSString * contentValue;
@property(nonatomic,copy) UIColor * contentColor;

@property(nonatomic,copy) NSAttributedString * attributedStringTitle;
//交互专用
@property(nonatomic,copy) NSString * TradeUnitNumber;
@property(nonatomic,copy) NSString * transString;

@end
