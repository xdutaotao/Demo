//
//  SHMyInquerySubModel.m
//  shcem
//
//  Created by xupeipei on 2016/12/20.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHMyInquerySubModel.h"

@implementation SHMyInquerySubModel

@end
