//
//  SHQueryModel.h
//  shcem
//
//  Created by xupeipei on 2016/12/14.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHQueryModel : NSObject

@property(nonatomic,copy) NSString *id;
@property(nonatomic,copy) NSString *DISABLED;
@property(nonatomic,copy) NSString *REC_CREATEBY;
@property(nonatomic,copy) NSString *REC_CREATETIME;
@property(nonatomic,copy) NSString *REC_MODIFYBY;
@property(nonatomic,copy) NSString *REC_MODIFYTIME;
@property(nonatomic,copy) NSString *OrderID;
@property(nonatomic,copy) NSString *Quantity;
@property(nonatomic,copy) NSString *Weight;
@property(nonatomic,copy) NSString *ProvinceID;
@property(nonatomic,copy) NSString *AreaID;
@property(nonatomic,copy) NSString *CityID;
@property(nonatomic,copy) NSString *ProvinceName;
@property(nonatomic,copy) NSString *AreaName;
@property(nonatomic,copy) NSString *OrderTotalQuantity;
@property(nonatomic,copy) NSString *CategoryShow;
@property(nonatomic,copy) NSString *BrandShow;
@property(nonatomic,copy) NSString *BrandID;
@property(nonatomic,copy) NSString *DeliveryID;


//交互
@property(nonatomic,copy) NSString *breakQuantity;
@end
