//
//  SHMySellModel.h
//  shcem
//
//  Created by xupeipei on 2016/12/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHMySellModel : NSObject
@property(nonatomic,copy) NSString * ID;
@property(nonatomic,copy) NSString * BrandID;
@property(nonatomic,copy) NSString * BrandName;
@property(nonatomic,copy) NSString * CanOperate;
@property(nonatomic,copy) NSString * CategoryLeafID;
@property(nonatomic,copy) NSString * CategoryLeafName;
@property(nonatomic,copy) NSString * ConformProduct;
@property(nonatomic,copy) NSString * DealtQuantity;
@property(nonatomic,copy) NSString * DeliveryEndDate;
@property(nonatomic,copy) NSString * DeliveryPlace;
@property(nonatomic,copy) NSString * DepositAlgr;
@property(nonatomic,copy) NSString * DepositRate;
@property(nonatomic,copy) NSString * Direction;
@property(nonatomic,copy) NSString * EndTime;
@property(nonatomic,copy) NSString * ExtraLogisticsCost;
@property(nonatomic,copy) NSString * Price;
@property(nonatomic,copy) NSString * GoodsType;
@property(nonatomic,copy) NSString * OrderId;
@property(nonatomic,copy) NSString * CategoryShow;
@property(nonatomic,copy) NSString * BrandShow;
@property(nonatomic,copy) NSString * Quantity;
@property(nonatomic,copy) NSString * LeadsStatus;
@property(nonatomic,copy) NSString * SourcePlaceShow;
@property(nonatomic,copy) NSString * DelievryDateShow;
@property(nonatomic,copy) NSString * TradeStatusShow;
@property(nonatomic,copy) NSString * SourcePlaceName;
@property(nonatomic,copy) NSString * FormatCreateDate;
@property(nonatomic,copy) NSString * FormatLeadsStatus;
@property(nonatomic,copy) NSString * TotalWeight;
@property(nonatomic,copy) NSString * UserCode;
@property(nonatomic,copy) NSString * SourcePlaceType;


@end
