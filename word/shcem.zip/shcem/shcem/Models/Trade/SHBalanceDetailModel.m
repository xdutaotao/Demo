//
//  SHBalanceDetailModel.m
//  shcem
//
//  Created by xupeipei on 2016/12/7.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHBalanceDetailModel.h"

@implementation SHBalanceDetailModel

@end
