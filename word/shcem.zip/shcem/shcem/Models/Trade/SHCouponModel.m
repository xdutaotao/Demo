//
//  SHCouponModel.m
//  shcem
//
//  Created by xupeipei on 2016/12/27.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHCouponModel.h"

@implementation SHCouponModel

@end
