//
//  SHConfirmModel.m
//  shcem
//
//  Created by xupeipei on 2016/12/16.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHConfirmModel.h"

@implementation SHConfirmModel

@end
