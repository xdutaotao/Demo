//
//  SHDistributionModel.m
//  shcem
//
//  Created by zhangsx on 2017/4/14.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "SHDistributionModel.h"

@implementation SHDistributionModel

@end
