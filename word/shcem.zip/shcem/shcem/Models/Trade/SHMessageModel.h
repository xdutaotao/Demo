//
//  SHMessageModel.h
//  shcem
//
//  Created by xupeipei on 2016/12/9.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHMessageModel : NSObject

@property(nonatomic,copy) NSString * recModifytime;
@property(nonatomic,copy) NSString * resultMsg;
@property(nonatomic,copy) NSString * messageID;
@property(nonatomic,copy) NSString * messageContent;
@property(nonatomic,copy) NSString * msgCode;

@end
