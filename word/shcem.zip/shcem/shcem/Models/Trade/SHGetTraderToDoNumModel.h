//
//  SHGetTraderToDoNumModel.h
//  shcem
//
//  Created by xupeipei on 2016/12/8.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHGetTraderToDoNumModel : NSObject

@property(nonatomic,copy) NSString * EnquiryCount;
@property(nonatomic,copy) NSString * NeedArrivalCount;
@property(nonatomic,copy) NSString * NeedDeliveryCount;
@property(nonatomic,copy) NSString * NeedPayCount;
@property(nonatomic,copy) NSString * NeedShortCount;
@property(nonatomic,copy) NSString * NeedSignCount;


//交互
@property(nonatomic,copy) NSString *userStatus;

@end
