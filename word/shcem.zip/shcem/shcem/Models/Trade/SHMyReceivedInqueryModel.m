//
//  SHMyReceivedInqueryModel.m
//  shcem
//
//  Created by xupeipei on 2017/1/5.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "SHMyReceivedInqueryModel.h"

@implementation SHMyReceivedInqueryModel

@end
