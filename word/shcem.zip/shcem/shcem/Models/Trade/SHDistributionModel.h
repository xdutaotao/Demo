//
//  SHDistributionModel.h
//  shcem
//
//  Created by zhangsx on 2017/4/14.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHDistributionModel : NSObject

@property(nonatomic,copy) NSString *id;
@property(nonatomic,copy) NSString *DISABLED;
@property(nonatomic,copy) NSString *REC_CREATETIME;
@property(nonatomic,copy) NSString *REC_MODIFYTIME;
@property(nonatomic,copy) NSString *OrderID;
@property(nonatomic,copy) NSString *Quantity;
@property(nonatomic,copy) NSString *Weight;
@property(nonatomic,copy) NSString *ProvinceID;
@property(nonatomic,copy) NSString *AreaID;
@property(nonatomic,copy) NSString *CityID;
@property(nonatomic,copy) NSString *ProvinceName;
@property(nonatomic,copy) NSString *AreaName;
@property(nonatomic,copy) NSString *CityName;
@property(nonatomic,copy) NSString *Freight;
@property(nonatomic,copy) NSString *SmallFee;
@property(nonatomic,copy) NSString *DeliveryStatus;
@property(nonatomic,copy) NSString *ProcessStatus;
@property(nonatomic,copy) NSString *MinQuantity;
@property(nonatomic,copy) NSString *Price;
@property(nonatomic,copy) NSString *BrandID;
@property(nonatomic,copy) NSString *CategoryLeafID;
@property(nonatomic,copy) NSString *SourcePlaceID;
@property(nonatomic,copy) NSString *OrderTotalQuantity;
@property(nonatomic,copy) NSString *OrderDeliveryQuantity;
@property(nonatomic,copy) NSString *OrderNoDeliveryQuantity;
@property(nonatomic,copy) NSString *TradeUnitNumber;
@property(nonatomic,copy) NSString *OrderTotalWeight;
@property(nonatomic,copy) NSString *OrderNoDeliveryWeight;
@property(nonatomic,copy) NSString *Remark;
@property(nonatomic,copy) NSString *Address;
@property(nonatomic,copy) NSString *ContactName;
@property(nonatomic,copy) NSString *ContactMobile;
@property(nonatomic,copy) NSString *FreightFee;
@end
