//
//  SHGetBuyListModel.h
//  shcem
//
//  Created by xupeipei on 2016/12/12.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHGetBuyListModel : NSObject

@property(nonatomic,copy) NSString * OrderId;
@property(nonatomic,copy) NSString * TradeDateShow;
@property(nonatomic,copy) NSString * CategoryShow;
@property(nonatomic,copy) NSString * BrandShow;
@property(nonatomic,copy) NSString * SourcePlaceShow;
@property(nonatomic,copy) NSString * StoreHouseShow;
@property(nonatomic,copy) NSString * Quantity;
@property(nonatomic,copy) NSString * Price;
@property(nonatomic,copy) NSString * Amount;
@property(nonatomic,copy) NSString * GoodsType;
@property(nonatomic,copy) NSString * Weight;
@property(nonatomic,copy) NSString * TradeUnitNumber;
@property(nonatomic,copy) NSString * DeliveryStartDate;
@property(nonatomic,copy) NSString * DelievryDateShow;
@property(nonatomic,copy) NSString * TradeStatusShow;
@property(nonatomic,copy) NSString * TwoDecimalFee;
@property(nonatomic,copy) NSString * FormatFeeRate;
@property(nonatomic,copy) NSString * QueryType;
@property(nonatomic,copy) NSArray * ButtonList;
@property(nonatomic,copy) NSArray * ReceiptList;
@property(nonatomic,copy) NSString * NoDeliveryQuantity;
@property(nonatomic,copy) NSString * BreakProFee;
@property(nonatomic,copy) NSString * BuyFee;
@property(nonatomic,copy) NSString * SellFee;
@property(nonatomic,copy) NSString * DeliveryWeight;
@property(nonatomic,copy) NSString * SourcePlaceType;
@property(nonatomic,copy) NSString * totalMoney;
@property(nonatomic,copy) NSString * SourcePlaceTypeShow;
@property(nonatomic,copy) NSString * IsDisplayRemaining;
@property(nonatomic,copy) NSString * NoDeliveryWeight;
@end

