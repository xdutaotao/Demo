//
//  CustomScrollViewCellModel.m
//  shcem
//
//  Created by xupeipei on 2016/12/28.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "CustomScrollViewCellModel.h"

@implementation CustomScrollViewCellModel

@end
