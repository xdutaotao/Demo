//
//  SHMyReceivedListModel.h
//  shcem
//
//  Created by xupeipei on 2016/12/20.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHMyReceivedListModel : NSObject

@property(nonatomic,copy) NSString * Address;
@property(nonatomic,copy) NSString * Amount;
@property(nonatomic,copy) NSString * BuyFee;
@property(nonatomic,copy) NSString * BrandShow;
@property(nonatomic,copy) NSString * CategoryShow;
@property(nonatomic,copy) NSString * DelievryDateShow;
@property(nonatomic,copy) NSString * DeliveryID;
@property(nonatomic,copy) NSString * DeliveryStatus;
@property(nonatomic,copy) NSString * DeliveryStatusShow;
@property(nonatomic,copy) NSString * DeliveryType;
@property(nonatomic,copy) NSString * DeliveryTypeShow;
@property(nonatomic,copy) NSString * GoodsType;
@property(nonatomic,copy) NSString * HistoryDeliveryID;
@property(nonatomic,copy) NSString * IsBtnShow;
@property(nonatomic,copy) NSString * LogisticsStatus;
@property(nonatomic,copy) NSString * LogisticsStatusShow;
@property(nonatomic,copy) NSString * MODIFYTIMEShow;
@property(nonatomic,copy) NSString * MoreOrFew;
@property(nonatomic,copy) NSString * OrderID;
@property(nonatomic,copy) NSString * Price;
@property(nonatomic,copy) NSString * Quantity;
@property(nonatomic,copy) NSString * SourcePlaceShow;
@property(nonatomic,copy) NSString * StoreContactName;
@property(nonatomic,copy) NSString * StoreHouseShow;
@property(nonatomic,copy) NSString * TakenQuantity;
@property(nonatomic,copy) NSString * TradeDateShow;
@property(nonatomic,copy) NSString * TradeStatus;
@property(nonatomic,copy) NSString * TradeStatusShow;
@property(nonatomic,copy) NSString * Trader;


@end
