//
//  SHMessageModel.m
//  shcem
//
//  Created by xupeipei on 2016/12/9.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHMessageModel.h"

@implementation SHMessageModel

@end
