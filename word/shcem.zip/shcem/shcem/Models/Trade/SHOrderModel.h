//
//  SHOrderModel.h
//  shcem
//
//  Created by xupeipei on 2016/12/14.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHOrderModel : NSObject

@property(nonatomic,copy) NSString * OrderID;
@property(nonatomic,copy) NSString * CategoryLeaf;
@property(nonatomic,copy) NSString * Brand;
@property(nonatomic,copy) NSString * TradeNumber;
@property(nonatomic,copy) NSString * Quantity;
@property(nonatomic,copy) NSString * TradeUnitNumber;
@property(nonatomic,copy) NSString * Price;
@property(nonatomic,copy) NSString * UserBalance;
@property(nonatomic,copy) NSString * UnitBuyDepositRate;
@property(nonatomic,copy) NSString * MinQuantity;
@property(nonatomic,copy) NSString * Direction;
@property(nonatomic,copy) NSString * TradeTmptId;
@property(nonatomic,copy) NSString * CategoryLeafID;
@property(nonatomic,copy) NSString * BrandID;
@property(nonatomic,copy) NSString * BuyTraderName;
@property(nonatomic,copy) NSString * GoodsType;
@property(nonatomic,copy) NSString * SourcePlace;

@property(nonatomic,copy) NSString * WHAddress;
@end
