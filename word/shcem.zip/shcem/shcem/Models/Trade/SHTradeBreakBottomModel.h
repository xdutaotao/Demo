//
//  SHTradeBreakBottomModel.h
//  shcem
//
//  Created by xupeipei on 2016/12/29.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHTradeBreakBottomModel : NSObject

@property(nonatomic,copy) NSString *quantity;
@property(nonatomic,copy) NSString *reason;
@property(nonatomic,copy) NSString *money;
@property(nonatomic,copy) NSString *unit;

@property(nonatomic,copy) NSString *breakNoDeliveryQuantity;

@end
