//
//  SHGetBuyListModel.m
//  shcem
//
//  Created by xupeipei on 2016/12/12.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHGetBuyListModel.h"

@implementation SHGetBuyListModel

-(NSString *)NoDeliveryWeight{
    
    NSDecimalNumber *_noDeliveryQuantity = [NSDecimalNumber decimalNumberWithString:_NoDeliveryQuantity];
    NSDecimalNumber *_tradeUnitNumber = [NSDecimalNumber decimalNumberWithString:_TradeUnitNumber];
    
    _NoDeliveryWeight=[NSString stringWithFormat:@"%@", [NSNumber numberWithDouble:(_noDeliveryQuantity.doubleValue*_tradeUnitNumber.doubleValue)]];
    
    return _NoDeliveryWeight;

}

@end
