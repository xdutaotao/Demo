//
//  SHHTTPRequestBody.h
//  shcem
//
//  Created by huangdeyu on 2016/12/12.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>
@class SHHTTPRequestBodyDetail;
@interface SHHTTPRequestBody : NSObject
@property(nonatomic,strong) SHHTTPRequestBodyDetail * json;
-(instancetype)initWithJson:(SHHTTPRequestBodyDetail *)data;
@end

@interface SHHTTPRequestBodyDetail : NSObject
@property(nonatomic,copy) NSString * MethodName;
@property(nonatomic,copy) NSString * Params;
@property(nonatomic,copy) NSString * ServiceName;
@property(nonatomic,copy) NSString * Userid;
@property(nonatomic,copy) NSString * Version;
@end
