//
//  SHHTTPRequestBody.m
//  shcem
//
//  Created by huangdeyu on 2016/12/12.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHHTTPRequestBody.h"

@implementation SHHTTPRequestBody
-(instancetype)initWithJson:(SHHTTPRequestBodyDetail *)data{
    if (self = [super init]) {
        self.json = data;
    }
    return self;
}
@end

@implementation SHHTTPRequestBodyDetail


@end
