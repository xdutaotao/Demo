//
//  SHHttpRetModel.h
//  Frey
//
//  Created by huangdeyu on 16/3/24.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface SHHttpRetModel : NSObject
@property(nonatomic,copy) NSString * CODE;
@property(nonatomic,copy) NSString * INFO;
@property(nonatomic,copy) NSString * DATA;
@end
