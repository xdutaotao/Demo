//
//  SHMallListModel.h
//  shcem
//
//  Created by huangdeyu on 2016/11/22.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHMallListModel : NSObject
@property(nonatomic,copy) NSString * FromatDeliveryStartDate;       //2016-11-29
@property(nonatomic,copy) NSString * CategoryShow;                      //LDPE薄膜
@property(nonatomic,copy) NSString * LeadsStatusShow;                  //有效
@property(nonatomic,copy) NSString * SettlementMethodShow;          //现货配送
@property(nonatomic,copy) NSString * SourcePlaceShow;                  //上海石化
@property(nonatomic,copy) NSString * FirmShowName;                     //武汉周黑鸭有限公司
@property(nonatomic,copy) NSString * GoodsTypeShow;                    //现货
@property(nonatomic,copy) NSString * BrandShow;                            //Q210
@property(nonatomic,copy) NSString * REC_CREATETIMEShow;           //2016-11-22 16:35
@property(nonatomic,assign) double  DealtQuantity;                   //15
@property(nonatomic,assign) double TradeUnitNumber;              //10
@property(nonatomic,assign) double MinQuantity;
@property(nonatomic,assign) double ResidualQuantity;
@property(nonatomic,assign) double TotalWeight;
@property(nonatomic,assign) double Price;
@property(nonatomic,assign) double ResidualWeight;
@property(nonatomic,assign) NSInteger ID;
@property (nonatomic, assign) NSInteger SourcePlaceType;    //1-国产  2-进口


@end
