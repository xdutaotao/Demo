//
//  SHHomeModel.m
//  shcem
//
//  Created by min on 16/11/22.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHHomeModel.h"

@implementation SHHomeModel

@end

@implementation SHHomeBannerModel

@end

@implementation SHHomeNoticeModel

@end

@implementation SHHomeNavModel

@end

@implementation SHHomeSearchModel

@end
