//
//  SHHomeModel.h
//  shcem
//
//  Created by min on 16/11/22.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHHomeModel : NSObject
@end

@interface SHHomeBannerModel : NSObject
@property (nonatomic, assign) NSInteger FileID;
@property (nonatomic, copy) NSString *InfoLinkId;
@end

@interface SHHomeNoticeModel : NSObject
@property (nonatomic, copy) NSString *InfoTitle;
@property (nonatomic, assign) NSInteger ID;
@end

@interface SHHomeNavModel : NSObject
@property (nonatomic, copy) UIImage *navImage;
@property (nonatomic, copy) NSString *navTitle;
@property (nonatomic, assign) NSInteger navCount;
@end

@interface SHHomeSearchModel : NSObject

@end


