//
//  SHOrderByLeadsModel.m
//  shcem
//
//  Created by xupeipei on 2016/11/25.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHOrderByLeadsModel.h"

@implementation SHOrderByLeadsModel

@end
