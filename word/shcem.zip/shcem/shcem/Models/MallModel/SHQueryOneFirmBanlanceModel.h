//
//  SHQueryOneFirmBanlanceModel.h
//  shcem
//
//  Created by xupeipei on 2016/11/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHQueryOneFirmBanlanceModel : NSObject

@property(nonatomic,copy) NSString * BALANCEFromS;
@property(nonatomic,copy) NSString * FBALANCEFromOra;
@property(nonatomic,copy) NSString * FIRMID;
@property(nonatomic,copy) NSString * FIRMNAME;
@property(nonatomic,copy) NSString * LASTBALANCEFromS;
@property(nonatomic,copy) NSString * USERBALANCEFromOra;
@property(nonatomic,copy) NSString * preSaleBALANCEFromS;
@property(nonatomic,copy) NSString * preSaleLASTBALANCEFromS;

@end
