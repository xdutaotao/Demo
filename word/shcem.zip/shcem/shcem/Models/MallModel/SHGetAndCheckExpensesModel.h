//
//  SHGetAndCheckExpensesModel.h
//  shcem
//
//  Created by xupeipei on 2016/11/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHGetAndCheckExpensesModel : NSObject


@property(nonatomic,copy) NSString * CouponBalance;
@property(nonatomic,copy) NSString * CreditBalance;
@property(nonatomic,copy) NSString * Deposit;
@property(nonatomic,copy) NSString * DepositAlgr;
@property(nonatomic,copy) NSString * DepositRate;
@property(nonatomic,copy) NSString * Fee;
@property(nonatomic,copy) NSString * FeeAlgr;
@property(nonatomic,copy) NSString * FeeRate;
@property(nonatomic,copy) NSString * FormatDepositRate;
@property(nonatomic,copy) NSString * FormatFeeRate;
@property(nonatomic,copy) NSString * FormatTotalBalance;
@property(nonatomic,copy) NSString * FormatTotalPayable;
@property(nonatomic,copy) NSString * FormatTwoDecimalDeposit;
@property(nonatomic,copy) NSString * FormatTwoDecimalFee;
@property(nonatomic,copy) NSString * IsBalanceEnough;
@property(nonatomic,copy) NSString * TotalBalance;
@property(nonatomic,copy) NSString * TotalPayable;
@property(nonatomic,copy) NSString * TwoDecimalDeposit;
@property(nonatomic,copy) NSString * TradeUnitNumber;
@property(nonatomic,copy) NSString * TwoDecimalFee;
@property(nonatomic,copy) NSString * UserBalance;

@property(nonatomic,copy) NSString * countWeight;
@property(nonatomic,copy) NSString * countBatch;
@property(nonatomic,copy) NSString * countMoney;
//用于cell交互
@property(nonatomic,copy) NSString *custrans;
@property(nonatomic,assign) BOOL  readeStatus;
@property(nonatomic,assign) BOOL  close;

@end
