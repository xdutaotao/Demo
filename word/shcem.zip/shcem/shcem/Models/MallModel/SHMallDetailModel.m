//
//  SHMallDetailModel.m
//  shcem
//
//  Created by xupeipei on 2016/11/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHMallDetailModel.h"

@implementation SHMallDetailModel

@end
