//
//  SHOrderByLeadsModel.h
//  shcem
//
//  Created by xupeipei on 2016/11/25.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHOrderByLeadsModel : NSObject

@property(nonatomic,copy) NSString * price;
@property(nonatomic,copy) NSString * number;

@end
