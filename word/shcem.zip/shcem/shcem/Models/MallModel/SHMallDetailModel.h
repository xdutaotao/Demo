//
//  SHMallDetailModel.h
//  shcem
//
//  Created by xupeipei on 2016/11/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHMallDetailModel : NSObject


@property(nonatomic,copy) NSString * BrandID;
@property(nonatomic,copy) NSString * Price;
@property(nonatomic,copy) NSString * CategoryLeafID;
@property(nonatomic,copy) NSString * TradeUnitNumber;
@property(nonatomic,copy) NSString * GoodsType;
@property(nonatomic,copy) NSString * FormatSettlementMethod;
@property(nonatomic,copy) NSString * ID;
@property(nonatomic,copy) NSString * FirmID;
@property(nonatomic,copy) NSString * leadID;
@property(nonatomic,copy) NSString * MinQuantity;
@property(nonatomic,copy) NSString * TwoDecimalDeposit;
@property(nonatomic,copy) NSString * AddressID;
@property(nonatomic,copy) NSString * ResidualQuantity;
@property(nonatomic,copy) NSString * UserCode;
@property(nonatomic,copy) NSString * FormatPackageStandard;
@property(nonatomic,copy) NSString * FormatLeadsStatus;
@property(nonatomic,copy) NSString * REC_CREATETIME;
@property(nonatomic,copy) NSString * FormatAnonymous;

@end

//
//{
//    AddressID = 122;
//    BrandID = 31;
//    BrandName = SM240;
//    CanOperate = 1;
//    CargoAgentID = 2;
//    CargoAgentSimpleName = "\U5317\U4eac\U9633\U5149\Uff08\U9752\U5c9b\Uff09";
//    CargoLinkMobile = "0532-80985887";
//    CargoLinkName = "\U8d75\U5a1f";
//    CategoryLeafID = 30;
//    CategoryLeafName = "PP\U5171\U805a\U6ce8\U5851";
//    ConformProduct = 0;
//    CreditDeposit = 0;
//    CreditFee = 0;
//    DISABLED = 0;
//    DealtQuantity = 0;
//    DeliveryEndDate = "2017-01-03 00:00:00";
//    DeliveryPlace = "\U65e0\U9521\U60e0\U5c71";
//    DeliveryPlaceId = 284;
//    DeliveryStartDate = "2017-01-03 00:00:00";
//    DepositAlgr = 2;
//    DepositRate = "0.015";
//    Direction = 0;
//    ExtraLogisticsCost = 1;
//    FeeAlgr = 0;
//    FeeRate = 0;
//    FirmID = 0100021;
//    FormatAnonymous = "\U5b9e\U540d";
//    FormatCargoAgent = "\U5317\U4eac\U9633\U5149\Uff08\U9752\U5c9b\Uff09-\U8d75\U5a1f-0532-80985887";
//    FormatCategoryBrand = "PP\U5171\U805a\U6ce8\U5851-SM240";
//    FormatCreateDate = "19:54";
//    FormatDeliveryDate = "2017/01/03";
//    FormatDeliveryEndDate = "2017/01/03";
//    FormatDeliveryPlace = "\U65e0\U9521\U60e0\U5c71";
//    FormatDeliveryStartDate = "2017/01/03";
//    FormatDepositRate = "1.5%";
//    FormatDepositRateInteger = 2;
//    FormatDirection = "\U5356";
//    FormatExtraLogisticsCost = 1;
//    FormatGoodsType = "\U73b0\U8d27";
//    FormatLeadsStatus = "\U6709\U6548";
//    FormatModifyDate = "19:54";
//    FormatPackageStandard = "25KG/\U888b";
//    FormatPalletType = "\U5176\U5b83";
//    FormatPettyCost = 0;
//    FormatPettyCostRange = "0-0";
//    FormatSettlementMethod = "\U6210\U4ea4\U65e5\U8d77\U56db\U65e5\U5185\U81ea\U63d0\U6216\U8f6c\U8d27\U6743";
//    FormatSourcePlaceType = "\U8fdb\U53e3";
//    FormatTemplateDepositRateInteger = 2;
//    FormatWHType = "\U4ed3\U5e93\U5730\U5740";
//    FormatWareHouseContactDeliveryType = 1;
//    GoodsType = 0;
//    ID = 13839;
//    IsRealName = 1;
//    LeadsCode = G1701030028;
//    LeadsStatus = 0;
//    MinQuantity = 3;
//    MinWeight = "4.125";
//    PackageStandard = 1;
//    PalletType = 0;
//    PaymentStatus = 1;
//    PettyCeiling = 0;
//    PettyCost = 0;
//    PettyFloor = 0;
//    Price = 40;
//    Quantity = 37;
//    "REC_CREATEBY" = 0000001425;
//    "REC_CREATETIME" = "2017-01-03 19:54:21";
//    "REC_MODIFYBY" = 0000001425;
//    "REC_MODIFYTIME" = "2017-01-03 19:54:21";
//    ResidualQuantity = 37;
//    ResidualWeight = "50.875";
//    SettlementMethod = 11;
//    SourcePlaceID = 50;
//    SourcePlaceName = "\U9a6c\U6765\U897f\U4e9a";
//    SourcePlaceType = 0;
//    StoreContactName = "\U5f20\U5efa\U4f1f-0510\Uff0d83300328";
//    StoreHouseFN = "\U65e0\U9521\U5e02\U65b0\U5929\U8054";
//    TakenTradeDeposit = 0;
//    TakenTradeFee = 0;
//    TmpDepositAlgr = 2;
//    TmpDepositRate = "0.015";
//    TotalAvailableWeight = "50.875";
//    TotalWeight = "50.875";
//    TradeDeposit = 0;
//    TradeDepositCalculate = 0;
//    TradeFee = 0;
//    TradeFeeCalculate = 0;
//    TradeTmptId = 1;
//    TradeUnit = 3;
//    TradeUnitNumber = "1.375";
//    TraderID = 010002100;
//    UserCode = 0000001425;
//    UserName = "\U6731\U5c0f\U4e8c";
//    WHAddress = "\U65e0\U9521\U60e0\U5c71\U6d1b\U793e\U9547\U98ce\U6768\U8def\Uff08\U65e0\U9521\U5929\U8054\Uff09";
//    WHContactID = 5626;
//    WHGruopID = 0;
//    WHType = 20;
//    WareHouseContactDeliveryType = 1;
//    WareHouseID = 126;
//}

