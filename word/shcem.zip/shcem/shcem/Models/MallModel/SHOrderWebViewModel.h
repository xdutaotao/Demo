//
//  SHOrderWebViewModel.h
//  shcem
//
//  Created by xupeipei on 2016/11/30.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHOrderWebViewModel : NSObject

@property(nonatomic,assign) float orderWebViewHeight;

@end
