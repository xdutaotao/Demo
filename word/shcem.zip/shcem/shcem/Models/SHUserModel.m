//
//  SHUserModel.m
//  shcem
//
//  Created by huangdeyu on 2016/11/22.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHUserModel.h"



@implementation SHUserModel
-(void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:_BankID forKey:@"BankID"];
    [aCoder encodeObject:_BankName forKey:@"BankName"];
    [aCoder encodeInteger:_BusinessType forKey:@"BusinessType"];
    [aCoder encodeObject:_FirmID forKey:@"FirmID"];
    [aCoder encodeObject:_FirmName forKey:@"FirmName"];
    [aCoder encodeObject:_FirmRegId forKey:@"FirmRegId"];
    [aCoder encodeInteger:_FirmType forKey:@"FirmType"];
    [aCoder encodeInteger:_ForceChangePwd forKey:@"ForceChangePwd"];
    [aCoder encodeInteger:_HasPaymentPwd forKey:@"HasPaymentPwd"];
    [aCoder encodeObject:_FullName forKey:@"FullName"];
    [aCoder encodeInteger:_IsFrozenFirm forKey:@"IsFrozenFirm"];
    [aCoder encodeInteger:_IsFrozenTrader forKey:@"IsFrozenTrader"];
    [aCoder encodeObject:_Mobile forKey:@"Mobile"];
    [aCoder encodeInteger:_TradeAuthority forKey:@"TradeAuthority"];
    [aCoder encodeObject:_TraderID forKey:@"TraderID"];
    [aCoder encodeObject:_TraderName forKey:@"TraderName"];
    [aCoder encodeObject:_TraderPassword forKey:@"TraderPassword"];
    [aCoder encodeObject:_TraderTemplate forKey:@"TraderTemplate"];
    [aCoder encodeObject:_UserCode forKey:@"UserCode"];
    [aCoder encodeObject:_UserEmail forKey:@"UserEmail"];
    [aCoder encodeInteger:_UserImg forKey:@"UserImg"];
    [aCoder encodeObject:_UserName forKey:@"UserName"];
    [aCoder encodeInteger:_UserType forKey:@"UserType"];
}
-(instancetype)initWithCoder:(NSCoder *)aDecoder{
    if (self = [super init]) {
        _BankID = [aDecoder decodeObjectForKey:@"BankID"];
        _BankName = [aDecoder decodeObjectForKey:@"BankName"];
        _BusinessType = [aDecoder decodeIntegerForKey:@"BusinessType"];
        _FirmID = [aDecoder decodeObjectForKey:@"FirmID"];
        _FirmName = [aDecoder decodeObjectForKey:@"FirmName"];
        _FirmRegId = [aDecoder decodeObjectForKey:@"FirmRegId"];
        _FirmType = [aDecoder decodeIntegerForKey:@"FirmType"];
        _ForceChangePwd = [aDecoder decodeIntegerForKey:@"ForceChangePwd"];
        _HasPaymentPwd = [aDecoder decodeIntegerForKey:@"HasPaymentPwd"];
        _FullName = [aDecoder decodeObjectForKey:@"FullName"];
        _IsFrozenFirm = [aDecoder decodeIntegerForKey:@"IsFrozenFirm"];
        _IsFrozenTrader = [aDecoder decodeIntegerForKey:@"IsFrozenTrader"];
        _Mobile = [aDecoder decodeObjectForKey:@"Mobile"];
        _TradeAuthority = [aDecoder decodeIntegerForKey:@"TradeAuthority"];
        _TraderID = [aDecoder decodeObjectForKey:@"TraderID"];
        _TraderName = [aDecoder decodeObjectForKey:@"TraderName"];
        _TraderPassword = [aDecoder decodeObjectForKey:@"TraderPassword"];
        _TraderTemplate = [aDecoder decodeObjectForKey:@"TraderTemplate"];
        _UserCode = [aDecoder decodeObjectForKey:@"UserCode"];
        _UserEmail = [aDecoder decodeObjectForKey:@"UserEmail"];
        _UserImg = [aDecoder decodeIntegerForKey:@"UserImg"];
        _UserName = [aDecoder decodeObjectForKey:@"UserName"];
        _UserType = [aDecoder decodeIntegerForKey:@"UserType"];
    }
    return self;
}
@end

@implementation SHTokenModel

@end
