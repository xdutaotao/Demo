//
//  SHMallListModel.m
//  shcem
//
//  Created by huangdeyu on 2016/11/22.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHMallListModel.h"

@implementation SHMallListModel

@end
