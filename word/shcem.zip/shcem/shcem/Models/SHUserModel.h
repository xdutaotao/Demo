//
//  SHUserModel.h
//  shcem
//
//  Created by huangdeyu on 2016/11/22.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHTokenModel : NSObject
@property(nonatomic,copy) NSString * token;
@end


//UserType:1 交易员, 0 浏览用户
//FirmType:0 管理员, 1 普通
//TradeAuthority:3 没有权限 0 卖 1 买  2 全部

@interface SHUserModel : NSObject<NSCoding>
@property(nonatomic,copy) NSString * BankID;
@property(nonatomic,copy) NSString * BankName;
@property(nonatomic,assign) NSInteger BusinessType;
@property(nonatomic,copy) NSString * FirmID;
@property(nonatomic,copy) NSString * FirmName;
@property(nonatomic,copy) NSString * FirmRegId;
@property(nonatomic,assign) NSInteger FirmType; 
@property(nonatomic,assign) NSInteger ForceChangePwd;
@property(nonatomic,copy) NSString * FullName;
@property(nonatomic,assign) NSInteger HasPaymentPwd;
@property(nonatomic,assign) NSInteger IsFrozenFirm;
@property(nonatomic,assign) NSInteger IsFrozenTrader;
@property(nonatomic,copy) NSString * Mobile;

// -1 游客 0卖家 1买家 2买卖家 3游客
@property(nonatomic,assign) NSInteger TradeAuthority;
@property(nonatomic,copy) NSString * TraderID;
@property(nonatomic,copy) NSString * TraderName;
@property(nonatomic,copy) NSString * TraderPassword;
@property(nonatomic,strong) NSArray * TraderTemplate;
@property(nonatomic,copy) NSString * UserCode;
@property(nonatomic,copy) NSString * UserEmail;
@property(nonatomic,assign) NSInteger UserImg;
@property(nonatomic,copy) NSString * UserName;
@property(nonatomic,assign) NSInteger UserType;
@end
