//
//  SHHttpRetModel.m
//  Frey
//
//  Created by huangdeyu on 16/3/24.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import "SHHttpRetModel.h"

@implementation SHHttpRetModel

@end
