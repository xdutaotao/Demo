//
//  AppDelegate+U_Share.m
//  shcem
//
//  Created by xupeipei on 2016/11/29.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "AppDelegate+U_Share.h"
#import "MobClick.h"
//#import "UMMobClick/MobClick.h"
#import "UMSocial.h"
#import "UMSocialWechatHandler.h"
#import "UMSocialQQHandler.h"
#import "UMSocialSinaSSOHandler.h"

@implementation AppDelegate (U_Share)


- (void)UMengTrack{
#ifdef DEBUG

    //    [MobClick setCrashReportEnabled:NO]; // 如果不需要捕捉异常，注释掉此行
    //   [MobClick setLogEnabled:YES];  // 打开友盟sdk调试，注意Release发布时需要注释掉此行,减少io消耗

    [MobClick startWithAppkey:UMENG_APPKEY reportPolicy:(ReportPolicy) REALTIME channelId:@"DEBUG"];
    
#else
    [MobClick startWithAppkey:UMENG_APPKEY reportPolicy:(ReportPolicy) BATCH channelId:nil];
    //   reportPolicy为枚举类型,可以为 REALTIME, BATCH,SENDDAILY,SENDWIFIONLY几种
    //   channelId 为NSString * 类型，channelId 为nil或@""时,默认会被被当作@"App Store"渠道
#endif
    [MobClick setAppVersion:XcodeAppVersion]; //参数为NSString * 类型,自定义app版本信息，如果不设置，默认从CFBundleVersion里取

}

- (void)UMengSocialTrack
{
    [UMSocialData setAppKey:UMENG_APPKEY];
    [UMSocialWechatHandler setWXAppId:@"wx76041ba8ebf7ffdf" appSecret:@"d7afffdeef2c864b8387152c37fa0f0c" url:@"http://www.umeng.com/social"];
    [UMSocialQQHandler setQQWithAppId:@"1105511482" appKey:@"c1wORGS9XFWOhz4Z" url:@"http://www.umeng.com/social"];
    [UMSocialSinaSSOHandler openNewSinaSSOWithAppKey:@"2031421337" secret:@"5ec152de4236228e4b8d57f122d98568" RedirectURL:@"http://sns.whalecloud.com/sina2/callback"];
} 








@end
