//
//  SHHTTPRequestBody.h
//  shcem
//
//  Created by huangdeyu on 2016/12/12.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#ifndef SHHTTPRequestBody_h
#define SHHTTPRequestBody_h

#define CACHE_USERINFO_KEY  @"save_user_data"

#define B_USER_SERVICE @"Shcem.Member.ServiceContract.IClientLoginService"
//用户名密码登陆
#define B_LOGIN_METHOD @"LoginForToken"
#define B_LOGIN_KEYS @[@"LoginName",@"Password"]
#define B_LOGIN_DEFALUT @{@"Platform":@"shcem.com",@"IsBackend":@NO,@"IsDynamicLogin":@NO,@"Origin":@"app"}

//用户名验证码登陆
#define B_CODE_LOGIN_KEYS @[@"LoginName"]
#define B_CODE_LOGIN_DEFALUT @{@"Platform":@"shcem.com",@"IsBackend":@NO,@"IsDynamicLogin":@YES,@"Origin":@"app"}
//获取用户信息
#define B_USER_INFO_METHOD @"GetUserInfo"
#define B_USER_INFO_KEYS @[@"Token"]
#define B_USER_INFO_DEFAULT @{@"IsRefresh":@YES}

//获取未读数量
#define B_UNREAD_MSG_SERVICE @"shcem.common.service.IPushMsgForAppService"
#define B_UNREAD_MSG_METHOD @"getUnReadMsgNum"
#define B_UNREAD_MSG_KEYS @[@"ReceiveNumber"]

//消息中心
#define B_MSG_METHOD @"getMessageHistoryList"
#define B_MSG_KEYS @[@"pageNo",@"pageSize",@"queryModel"]
#define B_MSG_DEFAULT @{@"orderFields":@[@{@"orderBy":@"mh.REC_MODIFYTIME",@"orderDesc":@YES}]}

//获取交易信息
#define B_USER_TRADE_INFO_SERVICE @"Shcem.Trade.ServiceContract.ILeadsService"
#define B_USER_TRADE_INFO_METHOD @"GetDaysInfo"
#define B_USER_TRADE_INFO_KEYS @[@"firmID",@"direction",@"queryDate"]

//账户钱
#define B_USER_MONEY_SERVICE @"shcem.finance.service.IBalanceMgrService"
#define B_USER_MONEY_METHOD @"queryOneFirmBanlance"
#define B_USER_MONEY_KEYS @[@"FIRMID"]

//检查手机号是否存在
#define B_CHECK_MOBILE_METHOD @"CheckExistUserMobile"
#define B_CHECK_MOBILE_KEYS @[@"MobileNo"]
#define B_CHECK_MOBILE_DEFALUT @{@"authkeyid":@"t_testuse"}

//获取验证码
#define B_MOBILE_CODE_SERVICE @"Shcem.CommonServiceContract.IVerifyCodeMobileService"
#define B_SEND_CODE_METHOD @"SendVerifyCode"
#define B_GET_CODE_KEYS @[@"Mobiles"]

//获取登陆验证码
#define B_GET_CODE_DEFAULT @{@"SmsCode":@"S0003",@"UserCode":@""}
//获取注册验证码
#define B_GET_REGISTER_DEFAULT @{@"SmsCode":@"S0001",@"UserCode":@""}
//获取重置密码验证码
#define B_GET_RESET_PWD_DEFAULT @{@"SmsCode":@"S0002",@"UserCode":@""}
//获取重置支付密码的验证码
#define B_GET_RESET_PAYMENT_PWD_DEFAULT @{@"SmsCode":@"S0016",@"UserCode":@""}
//检查验证码
#define B_CHECK_CODE_METHOD @"CheckVerifyCode"
#define B_CHECK_CODE_KEYS @[@"Mobile",@"VerifyCode"]
//检查登陆验证码
#define B_CHECK_CODE_DEFAULT @{@"SmsCode":@"S0003"}
//检查重设密码验证码
#define B_CHECK_RESET_PWD_CODE_DEFAULT @{@"SmsCode":@"S0002"}
//检查支付密码验证码
#define B_CHECK_RESET_PAYMENT_PWD_DEFAULT @{@"SmsCode":@"S0016"}
//注册验证码
#define B_CHECK_REGISTER_CODE_DEFAULT @{@"SmsCode":@"S0001"}
//注册
#define B_REGISTER_METHOD @"Register"
#define B_REGISTER_KEYS @[@"Mobile",@"VerifyCode",@"Password",@"ClientName",@"UserEmail"]
#define B_REGISTER_DEFAULT @{@"SmsCode":@"S0001",@"AppType":@1}

//重置密码
#define B_RESET_PWD_METHOD @"ForgetPwd"
#define B_RESET_PWD_KEYS @[@"Mobile",@"VerifyCode",@"NewPassword"]
#define B_RESET_PWD_DEFAULT @{@"SmsCode":@"S0002",@"AppType":@1}

//支付密码,服务是用户服务
#define B_PAYMENT_PWD_METHOD @"ChangePaymentPwd"
#define B_PAYMENT_PWD_KEYS @[@"UserCode",@"NewPassword"]

//重置支付密码，服务是验证码服务
#define B_RESET_PAYMENT_PWD_METHOD @"ForgetPaymentPwd"
#define B_RESET_PAYMENT_PWD_KEYS @[@"UserKey",@"Code",@"NewPassword"]
#define B_RESET_PAYMENT_PWD_DEFAULT @{@"Type":@1}

//设置头像
#define B_BAND_AVATAR_METHOD @"UpdateUserImage"
#define B_BAND_AVATAR_KES @[@"UserImg",@"Token"]


#endif /* SHHTTPRequestBody_h */
