//
//  SHNotificationKeys.h
//  shcem
//
//  Created by huangdeyu on 2016/12/9.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#ifndef SHNotificationKeys_h
#define SHNotificationKeys_h

#define USER_INFO_UPDATED_NOTIFICATION @"userInfoUpdatedNotification"

#define USER_UNREAD_COUNT_NOTIFICATION @"userUnreadCountNotification"

#define USER_TRADE_INFO_NOTIFICATION @"userTradeInfoNotification"

#define TRADE_REFRESH_NOTIFICATION @"TRADE_REFRESH_NOTIFICATION"

#define TRADE_COUPON_NOTIFICATION @"TRADE_COUPON_NOTIFICATION"

#define SEARCH_LIST_KEY  @"search_list_key"                //关键字搜索的key


#endif /* SHNotificationKeys_h */
