//
//  SHConfiguration.h
//  Frey
//
//  Created by huangdeyu on 16/2/24.
//  Copyright © 2016年 shcem. All rights reserved.
//

#ifndef SHConfiguration_h
#define SHConfiguration_h


#define isIPhone5               ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)

#define isIPhone4               ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 960), [[UIScreen mainScreen] currentMode].size) : NO)

#define isIPhone6               ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(750, 1334), [[UIScreen mainScreen] currentMode].size) : NO)

#define isIPhone6Plus           ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2208), [[UIScreen mainScreen] currentMode].size) : NO)

#ifdef DEBUG
#define DLog(fmt, ...) NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);
#else
#define DLog(...)
#endif


#define WEAK_SELF __weak typeof(self)weakSelf = self
#define STRONG_SELF __strong typeof(weakSelf)self = weakSelf

// 系统版本

#define SYSTEM_VERSION          [[[UIDevice currentDevice] systemVersion] floatValue]


#define WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;

#define ScreenHeight        [[UIScreen mainScreen] bounds].size.height
#define ScreenWidth         [[UIScreen mainScreen] bounds].size.width
#define NavgationBarHeight  64
#define TabbarHeight        49
#define StatusBarHeight     20



#define UMENG_APPKEY @"57038491e0f55ac4c5002201"



#endif

/* SHConfiguration_h */
