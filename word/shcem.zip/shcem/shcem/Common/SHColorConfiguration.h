//
//  SHColorConfiguration.h
//  Frey
//
//  Created by huangdeyu on 16/2/24.
//  Copyright © 2016年 shcem. All rights reserved.
//

#ifndef SHColorConfiguration_h
#define SHColorConfiguration_h

#define HexRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

#define HexRGBAlpha(rgbValue,a) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:(a)]

#define RGBCOLOR(r, g, b) [UIColor colorWithRed : (r) / 255.0 green : (g) / 255.0 blue : (b) / 255.0 alpha : 1]

#define RGBACOLOR(r, g, b, a) [UIColor colorWithRed : (r) / 255.0 green : (g) / 255.0 blue : (b) / 255.0 alpha : (a)]


#define COLOR_NAV_RED           HexRGB(0xea5251)
#define COLOR_LINE_DEFAULT      HexRGB(0xc9c9c9)
#define COLOR_LINE              RGBCOLOR(229, 229, 234)
#define LIGHTGRAYf2             HexRGB(0xf2f2f2)
#define BLACK_CUSTOM            HexRGB(0x333333)
#define BLUE_CUSTOM             HexRGB(0x2b94ff)
#define LIGHTRED_CUSTOM         HexRGB(0xfdefef)
#define YELLOW_CUSTOM           HexRGB(0xfe8832)
#define LIGHTGRAY_CUSTOM        HexRGB(0x999999)
#define RedColor_Custom         HexRGB(0xea5251)
#define GRAY_CUSTOM             HexRGB(0xbbbbbb)
#define GREEN_CUSTOM            HexRGB(0x00bb22)
#define GRAYf3_CUSTOM           HexRGB(0xf3f3f3)
#define BACKGROUNDCOLOR_CUSTOM  RGBCOLOR(240, 240, 240)

#define FONT_DEFAULT          14
#define WHITE               [UIColor whiteColor]
#define GRAY                [UIColor grayColor]

#define BaseAlertTag        9889

#endif /* SHColorConfiguration_h */
