//
//  SHConstant.m
//  shcem
//
//  Created by zhangsx on 2017/5/8.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "SHConstant.h"

@implementation SHConstant : NSObject

    NSInteger  *const ROLE_ADMIN=0;

    NSString *const QUERY_TYPE_OWN_LEADS=@"0";
    NSString *const QUERY_TYPE_ALL_LEADS=@"1";

@end
