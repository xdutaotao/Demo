//
//  SHCommonString.h
//  shcem
//
//  Created by min on 17/2/17.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#ifndef SHCommonString_h
#define SHCommonString_h



#define STR_ALERT_SURE                      @"确认"
#define STR_ALERT_CANCEL                    @"取消"



/*
 *首页
 */
#define STR_HOME_SEARCH_Placeholder         @"投放企业、牌号关键字查询"
#define STR_HOME_TOAST_NO_PREMISSION        @"没有权限"
#define STR_HOME_DETAIL_TITLE               @"报盘详情"
#define STR_HOME_ALERT_TITLE_REMINDER       @"提示"
#define STR_HOME_ALERT_MESSAGE_SNP          @"该盘为现货配送盘\n相关操作请登陆网站www.shcem.com"



/*
 *商城
 */





/*
 *交易
 */
#define TELPHONEDEAL                        @"021-51550771"
#define STR_TRADE_TOAST_AGAIN_LOGIN         @"请重新登录"
#define STR_TRADE_GOTOWEB_PICK              @"请登录网站进行提货通知相关操作"






/*
 *资讯
 */





/*
 *会员中心
 */
#define TELPHONE                            @"400-720-9209"

#define STR_MINE_TOAST_TELEPHONE            @"请输入正确的手机号码"
#define STR_MINE_TOAST_PASSWORD_PAY         @"请输入6位数密码"
#define STR_MINE_TOAST_PASSWORD_LOGIN       @"请输入6-18位密码"
#define STR_MINE_INPUT_CODE                 @"请输入验证码"
#define STR_MINE_CODE_TOAST                 @"请输入6位数验证码"
#define STR_MINE_TOAST_CODE_SEND            @"验证码已发送"
#define STR_MINE_TOAST_CODE_FAILURE         @"请输入正确的验证码"
#define STR_MINE_CHECK_FAILURE              @"校验失败"
#define STR_MINE_TOAST_LOGIN_SUCCESS        @"登录成功"
#define STR_MINE_TOAST_SEND_CODE            @"发送验证码成功"
#define STR_LOOKAFTERLOGIN                  @"请登录后查看"
#define STR_SHOW_CLICK_LOGIN                @"点击登录"
#define STR_MINE_INPUT_TEL                  @"请输入注册的手机号"
#define STR_MINE_INPUT_PASSWORD             @"请输入密码"
#define STR_MINE_INPUT_AGAIN_PASSWORD       @"请确认密码"
#define STR_MINE_TOAST_AGAIN_PASSWORD_WRONG @"确认密码不匹配"
#define STR_MINE_BUTTON_COMMIT              @"提交"





#endif /* SHCommonString_h */
