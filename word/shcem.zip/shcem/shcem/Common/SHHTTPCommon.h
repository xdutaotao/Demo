//
//  SHHTTPCommon.h
//  Frey
//
//  Created by huangdeyu on 16/3/23.
//  Copyright © 2016年 shcem. All rights reserved.
//

#ifndef SHHTTPCommon_h
#define SHHTTPCommon_h


#define SHCEM_NET_ERROR_DOMAIN  @"com.app.SHCEM"
#define USER_ID @"Userid": [[SHUserManager sharedManager] getUserId]

#define VERSION @"Version":@"Vlatest"
#define B_VERSION @"Vlatest"

#ifdef DEBUG

#define BaseURL                 @"https://appnativepost.uat.shcem.com/shcem"
#define WEBREQUESTURL           @"https://appnative.uat.shcem.com"       //uat 请求html
#define FMSREQUESTURL           @"https://fms.uat.shcem.com"
#define URL_INFO_DETAIL         @"https://inform.uat.shcem.com/Mobile/Index?QuotationID="    //UAT资讯详情url
#define BANNERCATEGORYID        @1879       //UAT 首页轮播ID
#define NOTICECATEGORYID        @1882       //UAT 公告ID

#else

#define BaseURL                 @"https://appnativepost.shcem.com/shcem"    //生产 URL
#define WEBREQUESTURL           @"https://appnative.shcem.com"       //生产 请求html
#define FMSREQUESTURL           @"https://fms.shcem.com"
#define URL_INFO_DETAIL         @"https://inform.shcem.com/Mobile/Index?QuotationID="
#define BANNERCATEGORYID        @1895                 //生产 首页轮播ID
#define NOTICECATEGORYID        @1885                 //生产 公告ID
#endif


#define BANNERNUM               @5          //首页轮播数
#define WEBMAINURL              @"/main.html"
#define WEBINFOURL              @"/info.html"
#define WEBINFODETAILURL        @"/info_detail.html"
#define WEBKCHARTDETAILURL      @"/chart_detail.html"
#define URL_ABOUT_US            @"/about_us.html"
#define URL_FUWU_TIAOKUAN       @"/login_agreement.html"
#define WEB_MEMBER_INFO         @"/member_info.html"
#define WEB_MEMBER_INFO_FAIL    @"/key?ID=-1"
#define WEB_TRADE_RULES         @"/rules/trade_rules_list.html"
#define WEB_GUESS                    @"/guess.html"
#define WEB_GUESS_TITLE            @"竞猜活动"
#define BANNERDOWNLOADURL       [FMSREQUESTURL stringByAppendingString:@"/mapi/file/dynamicimage?id="]          //UAT首页轮播url
#define UPLOAD_URL              [FMSREQUESTURL stringByAppendingString:@"/mapi/file/UploadFileFormDonet"]
#define SCANFILE                [FMSREQUESTURL stringByAppendingString:@"/mapi/file/dynamicimage"]
#define SCANFILEINFO            [FMSREQUESTURL stringByAppendingString:@"/mapi/file/FileInfos"]
#define JSPATCH_BASE_URL        @"https://appu.shcem.com/frey/publish/update/iOS"                               //热更新


//登陆服务
#define USER_SERVICE @"ServiceName":@"Shcem.Member.ServiceContract.IClientLoginService"
#define LOGIN_METHOD @"MethodName":@"LoginForToken"

#define URL_PARAMETER_LOGIN(loginNameK,passwordK) @{@"json":@{USER_SERVICE,LOGIN_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization  stringWithJSONObject:@{@"Platform":@"shcem.com",@"IsBackend":@NO,@"LoginName":loginNameK,@"Password":passwordK,@"IsDynamicLogin":@NO,@"Origin":@"app"}]}}
//检查手机号是否存在
#define CHECK_USER_EXITS_METHOD @"MethodName":@"CheckExistUserMobile"
#define URL_CHECK_MOBILE(KMobile) @{@"json":@{USER_SERVICE,CHECK_USER_EXITS_METHOD,USER_ID,VERSION,@"Params"}}

//获取用户信息
#define GETUSERINFO_METHOD  @"MethodName":@"GetUserInfo"
#define URL_PARAMETER_GETUSERINFO(Ktoken)  @{@"json":@{USER_SERVICE,GETUSERINFO_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization  stringWithJSONObject:@{@"Token":Ktoken,@"IsRefresh":@YES}]}}

//商城列表服务
#define MALL_LIST_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.ILeadsService"
#define MALL_LIST_METHOD @"MethodName":@"GetLeadsList"
#define URL_PARAMETER_MALL_LIST(keyWordK,leadsStatusK,pageIndexK,pageSizeK,orderByK,sortDirectK,categoryIdsK,sorcePlaceIdsK,deliveryPlacesIdsK,goodsTypesK,settlementMethodK,KdeliveryScope,KSourcePlaceType) @{@"json":@{MALL_LIST_SERVICE,MALL_LIST_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"KeyWords":keyWordK,@"LeadsStatusList":leadsStatusK,@"PageIndex":pageIndexK,@"PageSize":pageSizeK,@"OrderBy":orderByK,@"SortDirect":sortDirectK,@"CategorySpecialIds":categoryIdsK,@"SourcePlaceIds":sorcePlaceIdsK,@"DeliveryPlaceIds":deliveryPlacesIdsK,@"GoodsType":goodsTypesK,@"SettlementMethod":settlementMethodK,@"DeliveryScopeIds":KdeliveryScope,@"SourcePlaceType":KSourcePlaceType}]}}


//主页-轮播、公告，资讯图片
#define MAIN_BANNER_SERVICE @"ServiceName":@"Shcem.Inform.ServiceContract.IQueryInfoService"
#define MAIN_BANNER_METHOD @"MethodName":@"getTopInformList"

#define URL_PARAMETER_MAIN_BANNER(productId,appTypeId,categoryId,top) @{@"json":@{MAIN_BANNER_SERVICE,MAIN_BANNER_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"ProductID":productId, @"AppTypeID":appTypeId, @"CatogoryID":categoryId, @"Top":top}]}}

//获取商品详情
#define MALL_MallDetailInfo_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.ILeadsService"
#define MALL_MallDetailInfo_METHOD @"MethodName":@"GetLeadsDetailInfo"
#define URL_PARAMETER_MallDetailInfo(LeadsID) @{@"json":@{MALL_MallDetailInfo_SERVICE,MALL_MallDetailInfo_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"LeadsID":LeadsID}]}}


//检查费用
#define MALL_GetAndCheckExpenses_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.IExpensesService"
#define MALL_GetAndCheckExpenses_METHOD @"MethodName":@"GetAndCheckExpenses"
#define URL_PARAMETER_GetAndCheckExpenses(Quantity,Price,TmplID,TradeRole,CategoryID,BrandID,TradeUnitNumber,goodsType,FirmID,leadID) @{@"json":@{MALL_GetAndCheckExpenses_SERVICE,MALL_GetAndCheckExpenses_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"Quantity":Quantity,@"Price":Price,@"TmplID":TmplID,@"TradeRole":TradeRole,@"CategoryID":CategoryID,@"BrandID":BrandID,@"TradeUnitNumber":TradeUnitNumber,@"goodsType":goodsType,@"FirmID":FirmID,@"leadID":leadID}]}}

//提货通知
#define MALL_UpdateSellArrivalTime_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.IOrderService"
#define MALL_UpdateSellArrivalTime_METHOD @"MethodName":@"UpdateSellArrivalTime"
#define URL_PARAMETER_UpdateSellArrivalTime(OrderID,UserCode,QueryType,ButtonID) @{@"json":@{MALL_UpdateSellArrivalTime_SERVICE,MALL_UpdateSellArrivalTime_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"OrderID":OrderID,@"UserCode":UserCode,@"QueryType":QueryType,@"ButtonID":ButtonID}]}}

//创建询盘
#define MALL_CreateEnquiry_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.IEnquiryService"
#define MALL_CreateEnquiry_METHOD @"MethodName":@"CreateEnquiry"
#define URL_PARAMETER_CreateEnquiry(LeadsID,Price,Quantity,TraderID,FirmID,UserCode,FeeAmount,DepositAmount,PushStatus) @{@"json":@{MALL_CreateEnquiry_SERVICE,MALL_CreateEnquiry_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"LeadsID":LeadsID,@"Price":Price,@"Quantity":Quantity,@"TraderID":TraderID,@"FirmID":FirmID,@"UserCode":UserCode,@"FeeAmount":FeeAmount,@"DepositAmount":DepositAmount,@"PushStatus":PushStatus}]}}

//下单
#define MALL_OrderByLeads_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.IOrderService"
#define MALL_OrderByLeads_METHOD @"MethodName":@"OrderByLeads"
#define URL_PARAMETER_OrderByLeads(UserCode,Quantity,Price,TraderID,LeadsID,DepositAmount,FirmID,PushStatus) @{@"json":@{MALL_OrderByLeads_SERVICE,MALL_OrderByLeads_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"UserCode":UserCode,@"Quantity":Quantity,@"Price":Price,@"TraderID":TraderID,@"LeadsID":LeadsID,@"DepositAmount":DepositAmount,@"FirmID":FirmID,@"PushStatus":PushStatus}]}}

//查询余额
#define MALL_QueryOneFirmBanlance_SERVICE @"ServiceName":@"shcem.finance.service.IBalanceMgrService"
#define MALL_QueryOneFirmBanlance_METHOD @"MethodName":@"queryOneFirmBanlance"
#define URL_PARAMETER_QueryOneFirmBanlance(FIRMID) @{@"json":@{MALL_QueryOneFirmBanlance_SERVICE,MALL_QueryOneFirmBanlance_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"FIRMID":FIRMID}]}}

//获取未读角标
#define MALL_GetTraderToDoNum_SERVICE @"ServiceName":@"Shcem.Member.ServiceContract.IClientService"
#define MALL_GetTraderToDoNum_METHOD @"MethodName":@"GetTraderToDoNum"
#define URL_PARAMETER_GetTraderToDoNum(TraderId) @{@"json":@{MALL_GetTraderToDoNum_SERVICE,MALL_GetTraderToDoNum_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"TraderId":TraderId}]}}

//获取消息列表
#define MALL_GetMessageHistoryList_SERVICE @"ServiceName":@"shcem.common.service.IPushMsgForAppService"
#define MALL_GetMessageHistoryList_METHOD @"MethodName":@"getMessageHistoryList"
#define URL_PARAMETER_GetMessageHistoryList(orderFields,pageNo,pageSize,queryModel) @{@"json":@{MALL_GetMessageHistoryList_SERVICE,MALL_GetMessageHistoryList_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"orderFields":orderFields,@"pageNo":pageNo,@"pageSize":pageSize,@"queryModel":queryModel}]}}

//我的卖盘
#define MALL_GetSellList2_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.ILeadsService"
#define MALL_GetSellList2_METHOD @"MethodName":@"GetSellList"
#define URL_PARAMETER_GetSellList2(TraderID,FirmID,Direction,GoodsType,CategoryLeafID,BrandID,IsAnonymity,LeadsStatus,KeyWords,TradeTmptId,QueryType,PageIndex,PageSize,OrderBy,OrderByDirection) @{@"json":@{MALL_GetSellList2_SERVICE,MALL_GetSellList2_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"TraderID":TraderID,@"FirmID":FirmID,@"Direction":Direction,@"GoodsType":GoodsType,@"CategoryLeafID":CategoryLeafID,@"BrandID":BrandID,@"IsAnonymity":IsAnonymity,@"LeadsStatus":LeadsStatus,@"KeyWords":KeyWords,@"TradeTmptId":TradeTmptId,@"QueryType":QueryType,@"PageIndex":PageIndex,@"PageSize":PageSize,@"OrderBy":OrderBy,@"OrderByDirection":OrderByDirection}]}}


//查询订单信息
#define MALL_Query_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.IDeliverySinopecService"
#define MALL_Query_METHOD @"MethodName":@"Query"
#define URL_PARAMETER_Query(OrderID,DeliveryStatusList) @{@"json":@{MALL_Query_SERVICE,MALL_Query_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"OrderID":OrderID,@"DeliveryStatusList":DeliveryStatusList}]}}

//违约
#define MALL_BreachContract_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.IOrderService"
#define MALL_BreachContract_METHOD @"MethodName":@"BreachContract"
#define URL_PARAMETER_BreachContract(OrderID,DeliveryIDs,Quantity,QueryType,ButtonID,UserCode,Reason) @{@"json":@{MALL_BreachContract_SERVICE,MALL_BreachContract_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"OrderID":OrderID,@"DeliveryIDs":DeliveryIDs,@"Quantity":Quantity,@"QueryType":QueryType,@"ButtonID":ButtonID,@"UserCode":UserCode,@"Reason":Reason}]}}

//取消询盘
#define MALL_CancelEnquiry_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.IEnquiryService"
#define MALL_CancelEnquiry_METHOD @"MethodName":@"CancelEnquiry"
#define URL_PARAMETER_CancelEnquiry(enquiryID,userCode) @{@"json":@{MALL_CancelEnquiry_SERVICE,MALL_CancelEnquiry_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"enquiryID":enquiryID,@"userCode":userCode}]}}

//确认成交询盘
#define MALL_Order_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.IOrderService"
#define MALL_Order_METHOD @"MethodName":@"Order"
#define URL_PARAMETER_Order(Enquiry_ID,UserCode,LeadsID) @{@"json":@{MALL_Order_SERVICE,MALL_Order_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"Enquiry_ID":Enquiry_ID,@"UserCode":UserCode,@"LeadsID":LeadsID}]}}

//确认溢短
#define MALL_AffirmMoreOrFew_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.IDeliveryService"
#define MALL_AffirmMoreOrFew_METHOD @"MethodName":@"AffirmMoreOrFew"
#define URL_PARAMETER_AffirmMoreOrFew(TraderID,FirmID,UserCode,DeliveryID) @{@"json":@{MALL_AffirmMoreOrFew_SERVICE,MALL_AffirmMoreOrFew_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"TraderID":TraderID,@"FirmID":FirmID,@"UserCode":UserCode,@"DeliveryID":DeliveryID}]}}

//查询订单信息
#define MALL_GetOrderInfo_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.IOrderService"
#define MALL_GetOrderInfo_METHOD @"MethodName":@"GetOrderInfo"
#define URL_PARAMETER_GetOrderInfo(OrderID) @{@"json":@{MALL_GetOrderInfo_SERVICE,MALL_GetOrderInfo_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"OrderID":OrderID}]}}

// 订单支付
#define MALL_PayPrice_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.IOrderService"
#define MALL_PayPrice_METHOD @"MethodName":@"PayPrice"
#define URL_PARAMETER_PayPrice(OrderID,QueryType,PaymentPwd,HasCoupon,ButtonID,UserCode,CouponNumber) @{@"json":@{MALL_PayPrice_SERVICE,MALL_PayPrice_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"OrderID":OrderID,@"QueryType":QueryType,@"PaymentPwd":PaymentPwd,@"HasCoupon":HasCoupon,@"ButtonID":ButtonID,@"UserCode":UserCode,@"CouponNumber":CouponNumber}]}}


// 订单优惠券
#define MALL_CouponList_SERVICE @"ServiceName":@"Shcem.Member.ServiceContract.INewCouponService"
#define MALL_CouponList_METHOD @"MethodName":@"GetList"
#define URL_PARAMETER_CouponList(CouponTransStatus,PageSize,CouponType,TemplateID,TraderID,PageIndex,OrderID) @{@"json":@{MALL_CouponList_SERVICE,MALL_CouponList_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"CouponTransStatus":CouponTransStatus,@"PageSize":PageSize,@"CouponType":CouponType,@"TemplateID":TemplateID,@"TraderID":TraderID,@"PageIndex":PageIndex,@"OrderID":OrderID}]}}



// 不知道
#define MALL_GetReceiptFileList_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.IReceiptService"
#define MALL_GetReceiptFileList_METHOD @"MethodName":@"GetReceiptFileList"
#define URL_PARAMETER_GetReceiptFileList(OrderID) @{@"json":@{MALL_GetReceiptFileList_SERVICE,MALL_GetReceiptFileList_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"OrderID":OrderID}]}}

// 获取交收列表
#define MALL_GetList_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.IDeliveryService"
#define MALL_GetList_METHOD @"MethodName":@"GetList"
#define URL_PARAMETER_GetList(TraderID,FirmID,CategoryLeafID,BrandID,KeyWords,OrderID,QueryType,DeliveryStatus,PageIndex,PageSize,GoodsType,OrderBy,OrderByDirection) @{@"json":@{MALL_GetList_SERVICE,MALL_GetList_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"TraderID":TraderID,@"FirmID":FirmID,@"CategoryLeafID":CategoryLeafID,@"BrandID":BrandID,@"KeyWords":KeyWords,@"OrderID":OrderID,@"QueryType":QueryType,@"DeliveryStatus":DeliveryStatus,@"PageIndex":PageIndex,@"PageSize":PageSize,@"GoodsType":GoodsType,@"OrderBy":OrderBy,@"OrderByDirection":OrderByDirection}]}}

// 获取成交列表
#define URL_PARAMETER_GetList2(TraderID,FirmID,CategoryLeafID,BrandID,KeyWords,QueryType,DeliveryStatus,PageIndex,PageSize,GoodsType,OrderBy,OrderByDirection,TradeTmptId) @{@"json":@{MALL_GetList_SERVICE,MALL_GetList_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"TraderID":TraderID,@"FirmID":FirmID,@"CategoryLeafID":CategoryLeafID,@"BrandID":BrandID,@"KeyWords":KeyWords,@"QueryType":QueryType,@"DeliveryStatus":DeliveryStatus,@"PageIndex":PageIndex,@"PageSize":PageSize,@"GoodsType":GoodsType,@"OrderBy":OrderBy,@"OrderByDirection":OrderByDirection,@"TradeTmptId":TradeTmptId}]}}


// 我收到的询盘列表
#define MALL_GetReceiveList_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.IEnquiryService"
#define MALL_GetReceiveList_METHOD @"MethodName":@"GetReceiveList"
#define URL_PARAMETER_GetReceiveList(TraderID,FirmID,GoodsType,QueryType,PageIndex,PageSize,OrderBy,SortDirect) @{@"json":@{MALL_GetReceiveList_SERVICE,MALL_GetReceiveList_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"TraderID":TraderID,@"FirmID":FirmID,@"GoodsType":GoodsType,@"QueryType":QueryType,@"PageIndex":PageIndex,@"PageSize":PageSize,@"OrderBy":OrderBy,@"SortDirect":SortDirect}]}}


// 获取我的询盘列表
#define MALL_GetMyInquiryList_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.IEnquiryService"
#define MALL_GetMyInquiryList_METHOD @"MethodName":@"GetList"
#define URL_PARAMETER_GetMyInquiryList(TraderID,FirmID,GoodsType,CategoryLeafID,BrandID,IsAnonymity,LeadsStatus,KeyWords,QueryType,PageIndex,PageSize,RowCount,OrderBy,SortDirect) @{@"json":@{MALL_GetMyInquiryList_SERVICE,MALL_GetMyInquiryList_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject:@{@"TraderID":TraderID,@"FirmID":FirmID,@"GoodsType":GoodsType,@"CategoryLeafID":CategoryLeafID,@"BrandID":BrandID,@"IsAnonymity":IsAnonymity,@"LeadsStatus":LeadsStatus,@"KeyWords":KeyWords,@"QueryType":QueryType,@"PageIndex":PageIndex,@"PageSize":PageSize,@"RowCount":RowCount,@"OrderBy":OrderBy,@"SortDirect":SortDirect}]}}


// 提交签收
#define MALL_Confirm_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.IReceiptService"
#define MALL_Confirm_METHOD @"MethodName":@"Confirm"
#define URL_PARAMETER_Confirm(ID,OrderID,TradeState,CREATEBY,CREATETIME,MODIFYBY,MODIFYTIME,ReceiptFileList,ReceiptTakenQuantityList) @{@"json":@{MALL_Confirm_SERVICE,MALL_Confirm_METHOD,USER_ID,VERSION,@"Params":[NSJSONSerialization stringWithJSONObject2:@{@"ID":ID,@"OrderID":OrderID,@"TradeState":TradeState,@"CREATEBY":CREATEBY,@"CREATETIME":CREATETIME,@"MODIFYTIME":MODIFYTIME,@"MODIFYBY":MODIFYBY,@"MODIFYTIME":MODIFYTIME,@"ReceiptFileList":ReceiptFileList,@"ReceiptTakenQuantityList":ReceiptTakenQuantityList}]}}

//获取模板列表
#define MALL_GetLeadsTemplateList_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.ILeadsTemplateService"
#define MALL_GetLeadsTemplateList_METHOD @"MethodName":@"GetLeadsTemplateList"

//获取模板详情
#define MALL_GetLeadsTemplateDetail_SERVICE @"ServiceName":@"Shcem.Trade.ServiceContract.ILeadsTemplateService"
#define MALL_GetLeadsTemplateDetail_METHOD @"MethodName":@"GetLeadsTemplateDetail"


//发布报盘


#endif /* SHHTTPCommon_h */





