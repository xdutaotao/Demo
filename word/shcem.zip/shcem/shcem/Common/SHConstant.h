//
//  SHConstant.h
//  shcem
//
//  Created by zhangsx on 2017/5/8.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHConstant : NSObject

extern NSInteger   *const ROLE_ADMIN;

extern NSString *const QUERY_TYPE_OWN_LEADS;
extern NSString *const QUERY_TYPE_ALL_LEADS;

@end
