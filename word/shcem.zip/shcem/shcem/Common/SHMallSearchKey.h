//
//  SHMallSearchKey.h
//  shcem
//
//  Created by huangdeyu on 2016/12/2.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#ifndef SHMallSearchKey_h
#define SHMallSearchKey_h

#define Kkeywords @"keywords"
#define Kcategory @"category"
#define KsourcePlace @"sourcePlace"
#define KdelieveryPlace @"deliveryPlace"
#define KsellScope @"deliveryScope"
#define Ktype @"type"
#define Kstate @"state"
#define KdeliverType @"deliverType"
#define KsortDirection @"sortDirection"
#define KorderBy @"orderBy"
#define KSourcePlaceType @"SourcePlaceType"

#define KsourcePlaceValues @"sourcePlaceValues"
#define KdeliveryPlaceValues @"deliveryPlaceValues"
#define KKsellScopeValues @"deliveryScopeValues"


#endif /* SHMallSearchKey_h */
