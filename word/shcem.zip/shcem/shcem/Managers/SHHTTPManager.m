//
//  SHHTTPManager.m
//  Frey
//
//  Created by huangdeyu on 16/3/10.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import "SHHTTPManager.h"
#import "MJExtension.h"
#import "SHHttpRetModel.h"
#import "SHHTTPCommon.h"

@interface SHHTTPManager()
@property (strong) AFHTTPSessionManager * manager;
@end

@implementation SHHTTPManager
+(instancetype)sharedManager{
    static SHHTTPManager * client = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        client = [[SHHTTPManager alloc] init];
        client.manager = [AFHTTPSessionManager manager];
        [client.manager.requestSerializer setQueryStringSerializationWithBlock:^NSString * _Nonnull(NSURLRequest * _Nonnull request, id  _Nonnull parameters, NSError * _Nullable __autoreleasing * _Nullable error) {
            return  [NSJSONSerialization stringWithJSONObject:parameters];
        }];
        [client setCer];
      //  client.manager.requestSerializer.cachePolicy = NSURLRequestReturnCacheDataElseLoad;
    });
    return client;
}
-(void)setCer{
#ifdef DEBUG
    NSString * cerName = @"https";
#else
    NSString * cerName = @"httpspro";
#endif
    
    NSString *cerPath = [[NSBundle mainBundle] pathForResource:cerName ofType:@"cer"];
    NSData * certData =[NSData dataWithContentsOfFile:cerPath];
    NSSet * certSet = [[NSSet alloc] initWithObjects:certData, nil];
    AFSecurityPolicy *securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate];
    // 是否允许,NO-- 不允许无效的证书
    [securityPolicy setAllowInvalidCertificates:YES];
    // 设置证书
    [securityPolicy setPinnedCertificates:certSet];
    self.manager.securityPolicy = securityPolicy;
}

-(void)cancelTask:(NSURLSessionTask *)task{
    if (task.state == NSURLSessionTaskStateRunning || task.state == NSURLSessionTaskStateSuspended) {
        [task cancel];
    }
}

-(NSURLSessionDataTask *)queryWithCondition:(SHQueryCondition *)condition andBlock:(void (^)(NSError *, id))block{
    DLog(@"\n\n\n---------%@",[condition.parameter description]);
    [self addConditions:condition];
    switch (condition.requestType) {
        case HTTPGET:
            return [self.manager GET:condition.urlString parameters:condition.parameter progress:nil success:^(NSURLSessionDataTask * task, id responseObject) {
                
                NSError * error = [condition.parseObj checkResponse:responseObject];
                if (error) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        block(error,nil);
                    });
                }else{
                    NSDictionary * dic2 = [condition.parseObj dealResponse:responseObject];
                //    DLog(@"\n\n\n---------%@",responseObject);
                    dispatch_async(dispatch_get_main_queue(), ^{
                        block(nil,dic2);
                    });
                }
            } failure:^(NSURLSessionDataTask * task, NSError * error) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    if ( error.code != -999) {//如果任务不是因为取消而来的错误
                        block(error,nil);
                    }else{
                        //如果是请求超时，则添加重试
                    }
                });
            }];
            break;
        case HTTPPOST:
            return [self.manager POST:condition.urlString parameters:condition.parameter progress:nil success:^(NSURLSessionDataTask *  task, id  responseObject) {
                
                if (![CustomSettings sharedCustomSettings].logSendDataEnable) {
                    DLog(@"\n\n\n%@\n\n\n",condition.parameter);
                }
                NSError * error = [condition.parseObj checkResponse:responseObject];
                if (error) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                       block(error,nil);
                    });
                }
                else {
                    NSDictionary * dic2 = [condition.parseObj dealResponse:responseObject];
                    if ([CustomSettings sharedCustomSettings].logReceiveDataEnable) {
                        DLog(@"\n\n\n%@\n\n\n",dic2);
                    }
                    dispatch_async(dispatch_get_main_queue(), ^{
                            block(nil,dic2);
                    });
                }
                
            } failure:^(NSURLSessionDataTask *  task, NSError *  error) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    if ( error.code != -999) {//如果任务不是因为取消而来的错误
                        block(error,nil);
                    }else{
                        //如果请求超时，添加重试
                    }
                });
            }];
            break;
        default:
            break;
    }
}

-(NSURLSessionDataTask *)queryWithConditionSync:(SHQueryCondition *)condition andBlock:(void (^)(NSError *, id))block{
    DLog(@"\n\n\n---------%@",[condition.parameter description]);
    [self addConditions:condition];
    
    dispatch_queue_t queue = dispatch_queue_create("serial", nil);
    
    switch (condition.requestType) {
        case HTTPGET:
            return [self.manager GET:condition.urlString parameters:condition.parameter progress:nil success:^(NSURLSessionDataTask * task, id responseObject) {
                
                NSError * error = [condition.parseObj checkResponse:responseObject];
                if (error) {
                    dispatch_sync(queue, ^{block(error,nil);});
                }else{
                    NSDictionary * dic2 = [condition.parseObj dealResponse:responseObject];
                    dispatch_sync(queue, ^{block(nil,dic2);});
                    //    DLog(@"\n\n\n---------%@",responseObject);
                }
            } failure:^(NSURLSessionDataTask * task, NSError * error) {
                dispatch_sync(queue, ^{
                    if ( error.code != -999) {//如果任务不是因为取消而来的错误
                        block(error,nil);
                    }else{
                        //如果是请求超时，则添加重试
                    }
                });
            }];
            break;
        case HTTPPOST:
            return [self.manager POST:condition.urlString parameters:condition.parameter progress:nil success:^(NSURLSessionDataTask *  task, id  responseObject) {
                if (![CustomSettings sharedCustomSettings].logSendDataEnable) {
                    DLog(@"\n\n\n%@\n\n\n",condition.parameter);
                }
                NSError * error = [condition.parseObj checkResponse:responseObject];
                if (error) {
                    dispatch_sync(queue, ^{block(error,nil);});
                }else {
                    NSDictionary * dic2 = [condition.parseObj dealResponse:responseObject];
                    if ([CustomSettings sharedCustomSettings].logReceiveDataEnable) {
                        DLog(@"\n\n\n%@\n\n\n",dic2);
                    }
                    dispatch_sync(queue, ^{block(nil,dic2);});
                }
            } failure:^(NSURLSessionDataTask *  task, NSError *  error) {
                dispatch_sync(queue, ^{
                    if ( error.code != -999) {//如果任务不是因为取消而来的错误
                        block(error,nil);
                    }else{
                        //如果请求超时，添加重试
                    }
                });
            }];
            break;
        default:
            break;
    }
}





/**
 *  添加查询条件
 *
 *  @param condition 查询条件对象
 */
-(void)addConditions:(SHQueryCondition *)condition{
    self.manager.responseSerializer.acceptableContentTypes = condition.responseType; //设置响应类型
    if (self.manager.requestSerializer.timeoutInterval != condition.timeOut) {
         self.manager.requestSerializer.timeoutInterval = condition.timeOut;              //设置请求超时的时间
    }
    [condition.requestHeader enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
            [self.manager.requestSerializer setValue:obj forHTTPHeaderField:key];
    }];
}
-(NSURLSessionDownloadTask *)downloadWithUrl:(NSURL *)url
                                    filePath:(NSString *)filePath
                                    callBack:(void(^)(NSURLResponse *response, NSURL *filePath, NSError *error)) block{
    [self addConditions:nil];
    NSURLRequest * request = [NSURLRequest requestWithURL:url];
    NSURLSessionDownloadTask * task = [self.manager downloadTaskWithRequest:request progress:nil destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
        NSString * path = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
        NSString * file = [path stringByAppendingPathComponent:filePath];
        if ([[NSFileManager defaultManager] fileExistsAtPath:file]) {
            [[NSFileManager defaultManager] removeItemAtPath:file error:nil];
        }
        NSURL *documentsDirectoryURL = [[NSFileManager defaultManager] URLForDirectory:NSCachesDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:NO error:nil];
        return [documentsDirectoryURL URLByAppendingPathComponent:filePath];
    } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
        block(response,filePath,error);
        DLog(@"文件路径是%@",filePath);
    }];
    [task resume];
    return task;
}


-(NSURLSessionUploadTask *)uploadWithData:(NSData *)data
                                      url:(NSString *)u
                                 callback:(void(^)( id responseObject, NSError *error)) block{
    NSInteger timeInterval = [[NSDate date] timeIntervalSinceReferenceDate];
    NSString * fileName = [NSString stringWithFormat:@"%ld.jpg",(long)timeInterval];
    NSData * encodeData = [fileName dataUsingEncoding:NSASCIIStringEncoding];
    NSString * result = [encodeData base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    NSMutableURLRequest * request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:u]];
    request.HTTPMethod = @"POST";
    [request setValue:@"multipart/form-data;charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [request setValue:result forHTTPHeaderField:@"fileName"];
    request.HTTPBody = data;
    self.manager.responseSerializer.acceptableContentTypes =  [NSSet setWithObjects:@"application/json",nil];
    NSURLSessionUploadTask * task =  [self.manager uploadTaskWithStreamedRequest:request progress:^(NSProgress * _Nonnull uploadProgress) {
    } completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            block(responseObject,error);
        });
    }];
    [task resume];
    return task;
}

@end

@implementation SHResponseParser
+(instancetype)defaultParser{
    SHResponseParser  * parse = [[SHResponseParser alloc] init];
    return parse;
}
-(NSError *)checkResponse:(id)responseObject{
    NSError  * error = nil;
    if (!responseObject) {
        NSString * desc = NSLocalizedString(@"服务内部错误", @"");
        error = [NSError errorWithDomain:SHCEM_NET_ERROR_DOMAIN code:-1000 userInfo:@{NSLocalizedDescriptionKey:desc}];//code == -1000表示返回数据为空
    }else{
        SHHttpRetModel * model = [SHHttpRetModel mj_objectWithKeyValues:responseObject];
        if (model) {
            NSString * desc = nil;
            if (model.CODE!=nil&&[model.CODE indexOf:@"10012"] > -1) {   //权限不足,用户过期
                desc = NSLocalizedString(model.INFO, @"");
                [[SHUserManager sharedManager] logout];
            }else if(model.CODE!=nil&&[model.CODE indexOf:@"00000"] == -1){
                if(model.INFO && model.INFO.length > 0){//有错误报告
                    desc = NSLocalizedString(model.INFO, @"");
                }else{
                    desc = NSLocalizedString(@"请求失败", @"");
                }
            }
            else if(model.CODE==nil){
                desc = NSLocalizedString(model.INFO.length>0?model.INFO:@"请求失败", @"");
            }
            if (desc != nil) {
                error = [NSError errorWithDomain:SHCEM_NET_ERROR_DOMAIN code:-1001 userInfo:@{NSLocalizedDescriptionKey:desc}]; //-1001 表示操作错误
            }
        }
    }
    return error;
}
-(NSObject *)dealResponse:(id)responseObject{
    NSObject * returnDic = nil;
    if([responseObject isKindOfClass:[NSDictionary class]]){
        NSString * str = [responseObject objectForKey:@"DATA"];
        if(str && [str isKindOfClass:[NSString class]]){
            returnDic = [NSJSONSerialization objectWithJSONString:str];
        }
        if(!returnDic){
            returnDic = str;
        }
    }
    return returnDic;
}
@end
@interface SHQueryCondition()
@property(nonatomic,strong) SHResponseParser * parseObj;
@property(nonatomic,strong) SHHTTPRequestBody * parameterObj;
@end

@implementation SHQueryCondition

//默认查询条件的请求超时时间是10s  请求类型是post
+(instancetype)defaultCondition{
    SHQueryCondition * condition = [[SHQueryCondition alloc] init];
    return condition;
}
+(instancetype)defaultConditionWithService:(NSString *)service method:(NSString *)method parKeys:(NSArray *)keys parValues:(NSArray *)values defaultPars:(NSDictionary *) d{
    SHQueryCondition * condition = [[SHQueryCondition alloc] init];
    SHHTTPRequestBodyDetail * detail = [[SHHTTPRequestBodyDetail alloc] init];
    detail.MethodName = method;
    detail.ServiceName = service;
    detail.Userid = [[SHUserManager sharedManager] getUserId];
    detail.Version = B_VERSION;
    NSMutableDictionary * dic =  [NSMutableDictionary dictionary];
    if (d) {
        [dic addEntriesFromDictionary:d];
    }
    for (int i = 0; i < keys.count; i++) {
        [dic setObject:values[i] forKey:keys[i]];
    }
    detail.Params = [NSJSONSerialization stringWithJSONObject:dic];
    condition.parameterObj = [[SHHTTPRequestBody alloc] initWithJson:detail];
    DLog(@"%@",condition.parameter);
    return condition; 
}

-(instancetype)init{
    if (self = [super init]) {
        self.timeOut = 10;
        self.requestType = HTTPPOST;
        self.responseType = [NSSet setWithObjects:@"application/x-www-form-urlencoded", @"text/html",@"text/json" @"text/javascript",@"text/plain",nil];
        self.parseObj = [SHResponseParser defaultParser];
     //   self.requestHeader = @{@"Content-Type": @"application/x-www-form-urlencoded;charset=utf-8"};
        self.urlString = BaseURL;
        self.retryTimes = 3;
    }
    return self;
}
-(void)setParameterObj:(SHHTTPRequestBody *)parameterObj{
    _parameterObj = parameterObj;
    NSDictionary * dic = [parameterObj mj_keyValues];
    self.parameter = dic;
}
@end
