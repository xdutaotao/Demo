//
//  SHHTTPManager.h
//  Frey
//
//  Created by huangdeyu on 16/3/10.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"
#import  "SHHTTPRequestBody.h"
#import  "SHHTTPRequestBody2.h"
typedef NS_ENUM(NSInteger,RequestType){
    HTTPGET = 0,
    HTTPPOST
};

@class SHQueryCondition;
@interface SHHTTPManager : NSObject
+(instancetype)sharedManager;
-(void)cancelTask:(NSURLSessionTask *)task;
-(NSURLSessionDataTask *)queryWithCondition:(SHQueryCondition *) condition andBlock:(void(^)(NSError * error,id responseObject))block;
-(NSURLSessionDataTask *)queryWithConditionSync:(SHQueryCondition *) condition andBlock:(void(^)(NSError * error,id responseObject))block;
-(NSURLSessionDownloadTask *)downloadWithUrl:(NSURL *)url filePath:(NSString *)filePath callBack:(void(^)(NSURLResponse *response, NSURL *filePath, NSError *error)) block;
-(NSURLSessionUploadTask *)uploadWithData:(NSData *)data url:(NSString *)u callback:(void(^)( id responseObject, NSError *error)) block;
@end

@interface SHResponseParser : NSObject
+(instancetype)defaultParser;
-(NSDictionary *)dealResponse:(id)responseObject;
-(NSError *)checkResponse:(id)responseObject;
@end

@interface SHQueryCondition : NSObject
@property(nonatomic,assign) float  timeOut;                 //请求超时的时间
@property(nonatomic,assign) NSInteger retryTimes;
@property(nonatomic,strong) NSDictionary * requestHeader;   //请求头
@property(nonatomic,strong) NSSet * responseType;           //响应类型
@property(nonatomic,assign) RequestType requestType;        //请求类型 GET / POST
@property(nonatomic,copy) NSString * urlString;             //请求的URL
@property(nonatomic,strong) NSDictionary * parameter;       //请求的参数
@property(nonatomic,strong,readonly) SHResponseParser * parseObj;       //解析器
@property(nonatomic,strong,readonly) SHHTTPRequestBody * parameterObj;          //请求对象
+(instancetype)defaultCondition;
+(instancetype)defaultConditionWithService:(NSString *)service method:(NSString *)method parKeys:(NSArray *)keys parValues:(NSArray *)values defaultPars:(NSDictionary *) dic;
@end
