//
//  SHDBManager.h
//  Frey
//
//  Created by huangdeyu on 16/3/7.
//  Copyright © 2016年 shcem. All rights reserved.
//FMDB数据库的一些操作，线程安全的方式。
#define dbName @"crm"
#define dbNameAndType @"crm.db"

#import <Foundation/Foundation.h>
#import "FMDB.h"
@interface SHDBManager : NSObject
@property(atomic,strong) FMDatabaseQueue * dbQueue;
+ (instancetype) sharedManager;
-(void)openDB;
-(void)openDBWithName:(NSString *)name;
-(void)closeDB;

-(BOOL)isExistTable:(NSString *)tableName;

/**建表
 *dictionary:key是列名 value是列类型
 */
-(BOOL)createTable:(NSDictionary *)dictionary tableName:(NSString *)tableName;

-(BOOL)addColumn:(NSString *)columnName type:(NSString *)type tableName:(NSString *)tableName;

/**插入或更新单条数据，非事物操作
 *tableName:表名
 *dic:单条数据的列名和行名
 */
-(BOOL)insertOrUpdate:(NSString *)tableName dicName:(NSDictionary *)dic;

/**插入或更新多条数据，事物操作
 */
-(BOOL)insertOrUpdate:(NSString *)tableName arrayName:(NSArray *)array;

/**格式化查询语句
 */
-(NSArray *)findWithFormat:(NSString *)format,...;
-(NSArray *)findAllFromTable:(NSString *)tableName;

-(BOOL)clearTable:(NSString *)tableName;

-(BOOL)deleteTable:(NSString *)tableName withPrimaryKey:(NSInteger )pk;

-(BOOL)deleteFromTable:(NSString *)table withFormat:(NSString *)format,...;
@end
