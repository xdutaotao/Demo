//
//  SHUserManager.m
//  shcem
//
//  Created by huangdeyu on 2016/11/22.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHUserManager.h"
#import "SHLoginService.h"
#import "SHCacheManager.h"
#import "MJExtension.h"
#import "JPUSHService.h"
#define KToken @"token"

@interface SHUserManager ()
@property(nonatomic,copy) NSString * token;
@property(nonatomic,strong) SHUserModel * model;
@property(nonatomic,strong) NSDictionary * tradeInfoDicDirection0;
@property(nonatomic,strong) NSDictionary * tradeInfoDicDirection1;
@property(nonatomic,strong) NSDictionary * unreadCount;

@property(nonatomic,strong) NSURLSessionDataTask * userInfoTask;
@property(nonatomic,strong) NSURLSessionDataTask * tradeInfoTask;
@property(nonatomic,strong) NSURLSessionDataTask * unreadInfoTask;

@property(nonatomic,assign) BOOL isCacheUserInfo;
@end

@implementation SHUserManager
+(instancetype)sharedManager{
    static dispatch_once_t onceToken = 0;
    static SHUserManager * manager = nil;
    dispatch_once(&onceToken, ^{
        manager = [[SHUserManager alloc] init];
        manager.token = [[NSUserDefaults standardUserDefaults] stringForKey:KToken];
        manager.isCacheUserInfo = YES;
        if (manager.token) {
            manager.isAuthed = YES;
        }else{
            manager.isAuthed = NO;
        }
    });
    return  manager;
}
-(NSString *)getToken{
    NSString * t = self.token;
    if (!t) {
        t = [[NSUserDefaults standardUserDefaults] stringForKey:KToken];
    }
    return t;
}
-(NSString *)getUserId{
    return [self getToken]?self.token:@"usercode";
}
//登陆成功后需要开启用户相关的服务。
-(void)loginWithToken:(NSString *) token{
    self.token = token;
    self.isAuthed = YES;
    [[NSUserDefaults standardUserDefaults] setObject:token forKey:KToken];
    [self updateUserInfo];
}
-(void)logout{
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:KToken];
    self.token = nil;
    self.model = nil;
    self.isAuthed = NO;
    self.tradeInfoDicDirection0 = nil;
    self.tradeInfoDicDirection1 = nil;
    self.unreadCount = nil;
    self.isCacheUserInfo = YES;
    [[SHCacheManager shareInstance] saveTo:NSDocumentDirectory name:CACHE_USERINFO_KEY obj:nil callBack:^{
    }];
    if (self.userInfoTask) {
        [[SHHTTPManager sharedManager] cancelTask:self.userInfoTask];
    }
    if (self.tradeInfoTask) {
        [[SHHTTPManager sharedManager] cancelTask:self.tradeInfoTask];
    }
    if (self.unreadInfoTask) {
        [[SHHTTPManager sharedManager] cancelTask:self.unreadInfoTask];
    }
    [self postNotification];    //退出时，更新用户状态
}

-(void)getUserInfo{
    self.isCacheUserInfo = YES;
    if (self.isAuthed) {
        WS(weakSelf)
        DLog(@"读缓存");
        [[SHCacheManager shareInstance] loadFrom:NSDocumentDirectory name:CACHE_USERINFO_KEY callBack:^(id dic, NSError *err) {
            if (dic) {
                weakSelf.model = dic;
            }
            [weakSelf updateUserInfo];
        }];
    }
}

-(void)postNotification{
    [[NSNotificationCenter defaultCenter] postNotificationName:USER_INFO_UPDATED_NOTIFICATION object:self.model];
    [[NSNotificationCenter defaultCenter] postNotificationName:USER_TRADE_INFO_NOTIFICATION object:self.tradeInfoDicDirection0];
    [[NSNotificationCenter defaultCenter] postNotificationName:USER_TRADE_INFO_NOTIFICATION object:self.tradeInfoDicDirection1];
    [[NSNotificationCenter defaultCenter] postNotificationName:USER_UNREAD_COUNT_NOTIFICATION object:self.unreadCount];
    [self updatePushAlias];
}
-(void)updateAvatarWithID:(NSInteger)ID{
    self.model.UserImg = ID;
    [[SHCacheManager shareInstance] saveTo:NSDocumentDirectory name:CACHE_USERINFO_KEY obj:self.model callBack:^{
    }];
}
-(void)updatePaymentPwdWithStatus:(NSInteger)status{
    self.model.HasPaymentPwd = status;
    [[SHCacheManager shareInstance] saveTo:NSDocumentDirectory name:CACHE_USERINFO_KEY obj:self.model callBack:^{
    }];
}
-(void)updateUserInfo{
    if (!self.isAuthed) {
        return;
    }
    if (self.isCacheUserInfo) {
        if (self.model) {       //如果用户信息存在，广播一次，用于离线查看用的
            [self postNotification];
        }
        if (self.userInfoTask) {
             [[SHHTTPManager sharedManager] cancelTask:self.userInfoTask];
        }
        WS(weakSelf)
        self.userInfoTask = [SHLoginService getUserInfo:@[self.token] callback:^(NSError *err, SHUserModel *token) {
            if (!err) {
                self.isCacheUserInfo = NO;
                weakSelf.model = token;
                [[NSNotificationCenter defaultCenter] postNotificationName:USER_INFO_UPDATED_NOTIFICATION object:weakSelf.model];
                [weakSelf updatePushAlias];
                [weakSelf updateUnreadCount:^(NSError *err, id responseObject) {
                }];
                [weakSelf updateTradeInfo:^(NSError *err, id responseObject) {
                }];
                
            }
        }];
        return;
    }
    [self postNotification];
}
-(void)updateUnreadCount:(void (^)(NSError * err,id responseObject)) block{
    if (!self.model) {
        DLog(@"用户信息为空");
        return;
    }
    [SHLoginService getUnreadCount:@[self.model.Mobile] callback:^(NSError * err, NSDictionary *dic) {
        if(!err){
            self.unreadCount = dic;
        }
        [[NSNotificationCenter defaultCenter] postNotificationName:USER_UNREAD_COUNT_NOTIFICATION object:self.unreadCount];
    }];
}
-(void)clearUnReadCount{
    self.unreadCount = nil;
    [[NSNotificationCenter defaultCenter] postNotificationName:USER_UNREAD_COUNT_NOTIFICATION object:self.unreadCount];
}
-(void)updateBalance:(void (^)(NSError * err,id responseObject)) block{
    
}
-(void)updateTradeInfo:(void (^)(NSError * err,id responseObject)) block{
    if (!self.model) {
        DLog(@"用户信息为空");
        return;
    }
    NSDate * date = [NSDate date];
    NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy/MM/dd";
    NSString *  dateStr = [formatter stringFromDate:date];
    [SHLoginService getTradeInfo:@[self.model.FirmID,@0,dateStr] callback:^(NSError * err, NSDictionary *dic) {
     //   NSLog(@"交易方向为0的数据%@",dic);
        if (!err) {
            NSMutableDictionary * d0 = [dic mutableCopy];
            [d0 addEntriesFromDictionary:@{@"direction":@0}];
            self.tradeInfoDicDirection0 = d0;
            [[NSNotificationCenter defaultCenter] postNotificationName:USER_TRADE_INFO_NOTIFICATION object:self.tradeInfoDicDirection0];
        }
    }];
    [SHLoginService getTradeInfo:@[self.model.FirmID,@1,dateStr] callback:^(NSError * err, NSDictionary *dic) {
        if (!err) {
          //  NSLog(@"交易方向为1的数据%@",dic);
            NSMutableDictionary * d1 = [dic mutableCopy];
            [d1 addEntriesFromDictionary:@{@"direction":@1}];
            self.tradeInfoDicDirection1 = d1;
            [[NSNotificationCenter defaultCenter] postNotificationName:USER_TRADE_INFO_NOTIFICATION object:self.tradeInfoDicDirection1];
        }
    }];
}
-(void)updatePushInfo:(void (^)(NSError *, id))block{
    if (!self.model) {
        DLog(@"用户信息为空");
        return;
    }
}

-(void)updatePushAlias{
    NSString * alias = nil;
    if (self.model.Mobile) {
        alias = self.model.Mobile;
    }else{
        alias = @"customer";
    }
     [JPUSHService setAlias:alias callbackSelector:nil object:nil];
}

-(SHUserModel *)getUserInfoDirect{
    return self.model;
}
@end
