//
//  SHCacheManager.m
//  shcem
//
//  Created by huangdeyu on 2016/12/12.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHCacheManager.h"


static dispatch_queue_t  data_cache_queue() {
    static dispatch_queue_t cache_queue;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        cache_queue = dispatch_queue_create("com.shcem.app.cache.queue", DISPATCH_QUEUE_SERIAL);
    });
    
    return cache_queue;
}

@implementation SHCacheManager

+(instancetype)shareInstance{
    static  SHCacheManager * manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[SHCacheManager alloc] init];
        data_cache_queue();
    });
    return manager;
}

-(void)saveTo:(NSSearchPathDirectory)type name:(NSString *) name obj:(NSObject *)obj callBack:(void (^)()) callback{
    dispatch_async(data_cache_queue(), ^{
        NSString * path =  NSSearchPathForDirectoriesInDomains(type, NSUserDomainMask, YES)[0];
        NSString * filePath = [path stringByAppendingPathComponent:name];
        if (![[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
            [[NSFileManager defaultManager] createFileAtPath:filePath contents:nil attributes:nil];
        }
        if ([NSKeyedArchiver archiveRootObject:obj toFile:filePath]) {
            DLog(@"存储成功");
        }else{
            DLog(@"存储失败");
        }
        
        dispatch_async(dispatch_get_main_queue(), ^{
            callback();
        });
    });
}
-(void)loadFrom:(NSSearchPathDirectory)type name:(NSString *) name callBack:(void (^)(id dic,NSError * err)) callback{
    dispatch_async(data_cache_queue(), ^{
        NSString * path =  NSSearchPathForDirectoriesInDomains(type, NSUserDomainMask, YES)[0];
        NSString * filePath = [path stringByAppendingPathComponent:name];
        NSDictionary *dic =  [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
        dispatch_async(dispatch_get_main_queue(), ^{
            callback(dic,nil);
        });
    });
}
@end
