//
//  SHUserManager.h
//  shcem
//
//  Created by huangdeyu on 2016/11/22.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SHUserModel.h"

@interface SHUserManager : NSObject
@property(nonatomic,assign) BOOL isAuthed;

+(instancetype)sharedManager;
-(NSString *)getToken;
-(NSString *)getUserId;
-(void)loginWithToken:(NSString *)token;
-(void)logout;

-(void)getUserInfo;    //用于应用启动的时候更新数据，不需要回调和通知。
-(void)updateUserInfo;              //用户监控用户信息改变自动更新UI

-(void)updateAvatarWithID:(NSInteger)ID;
-(void)updatePaymentPwdWithStatus:(NSInteger)status;

-(void)updatePushAlias;

-(void)updateUnreadCount:(void (^)(NSError * err,id responseObject)) block;
-(void)clearUnReadCount;
-(void)updateBalance:(void (^)(NSError * err,id responseObject)) block;
-(void)updateTradeInfo:(void (^)(NSError * err,id responseObject)) block;
-(void)updatePushInfo:(void (^)(NSError * err,id responseObject)) block;
-(SHUserModel *)getUserInfoDirect;
@end
