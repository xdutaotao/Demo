//
//  SHLoopManager.m
//  shcem
//
//  Created by huangdeyu on 2016/12/9.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHLoopManager.h"
#import "AFNetworking.h"
#import "SHUserManager.h"

#define LOOP_MANAGER_INTERAVAL 30

@interface SHLoopManager ()
//@property(nonatomic,strong) NSTimer  * timer;
@end

@implementation SHLoopManager

+(instancetype)shareManager{
    static SHLoopManager * manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[SHLoopManager alloc] init];
    });
    return manager;
}

-(void)startWorking{
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];         //开始监听网络状态
    [[NSNotificationCenter defaultCenter]  addObserver:self selector:@selector(reachabilityChanged:) name:AFNetworkingReachabilityDidChangeNotification object:nil];
}

#pragma mark - 通知中心
-(void)reachabilityChanged:(NSNotification *) notification{
    NSDictionary * dic = notification.userInfo;
    NSInteger num = -1;
    if (dic) {
        num =[dic[AFNetworkingReachabilityNotificationStatusItem] integerValue];
    }
    if (num < 1) {
        DLog(@"当前网络状态不可用");
        return;
    }
    if (num == 1) {
        DLog(@"当前网络状态是 wwan");
    }else if(num > 1){
        DLog(@"当前网络状态是 wifi");
    }
    [[SHUserManager sharedManager] updateUserInfo];     //网络状态改变，且
}


-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
