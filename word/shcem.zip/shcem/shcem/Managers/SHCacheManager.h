//
//  SHCacheManager.h
//  shcem
//
//  Created by huangdeyu on 2016/12/12.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SHCacheManager : NSObject
+(instancetype)shareInstance;
-(void)saveTo:(NSSearchPathDirectory)type name:(NSString *) name obj:(NSObject *)obj callBack:(void (^)()) callback;
-(void)loadFrom:(NSSearchPathDirectory)type name:(NSString *) name callBack:(void (^)(id dic,NSError * err)) callback;
@end
