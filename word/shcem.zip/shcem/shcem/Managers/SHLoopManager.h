//
//  SHLoopManager.h
//  shcem
//
//  Created by huangdeyu on 2016/12/9.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHLoopManager : NSObject
+(instancetype)shareManager;
-(void)startWorking;
@end
