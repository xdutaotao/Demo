//
//  SHDBManager.m
//  Frey
//
//  Created by huangdeyu on 16/3/7.
//  Copyright © 2016年 shcem. All rights reserved.
//


#import "SHDBManager.h"
@implementation SHDBManager
+ (instancetype) sharedManager{
    static SHDBManager * manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[SHDBManager alloc] init];
    });
    return manager;
}

-(void)openDB{
    [self openDBWithName:nil];
}
-(void)openDBWithName:(NSString *)db{
    if (_dbQueue == nil) {
        NSString * docPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
        NSString * filePath = [docPath stringByAppendingPathComponent:dbNameAndType];
        _dbQueue = [[FMDatabaseQueue alloc] initWithPath:filePath];
        if (_dbQueue == nil) {
            DLog(@"打开数据库失败");
        }
    }
}
-(void)closeDB{
    [self.dbQueue close];
}

-(BOOL)isExistTable:(NSString *)tableName{
    __block BOOL ret = YES;
    [self.dbQueue inDatabase:^(FMDatabase *db) {
        ret = [db tableExists:tableName];
    }];
    return ret;
}

-(BOOL)createTable:(NSDictionary *)dictionary tableName:(NSString *)tableName{
    if (tableName == nil  || tableName.length == 0) {
        return NO;
    }
    __block BOOL ret = YES;
    [self.dbQueue inDatabase:^(FMDatabase *db) {
        NSString * queryStr = [NSMutableString   stringWithFormat:@"CREATE TABLE IF NOT EXISTS %@",tableName] ;
        NSString *jsonString = [self dicToStr:dictionary];
        queryStr = [NSString stringWithFormat:@"%@ (%@)",queryStr,jsonString];
        [db executeUpdate:queryStr];
    }];
    return ret;
}
-(BOOL)addColumn:(NSString *)columnName type:(NSString *)type tableName:(NSString *)tableName{
    if (tableName == nil  || tableName.length == 0) {
        return NO;
    }
    __block BOOL ret = YES;
    [self.dbQueue inDatabase:^(FMDatabase *db) {
        NSString * sqlStr = [NSString stringWithFormat:@"ALTER TABLE '%@' ADD COLUMN '%@' %@",tableName,columnName,type];
       ret =  [db executeUpdate:sqlStr];
    }];
    return ret;
}

-(BOOL)insertOrUpdate:(NSString *)tableName dicName:(NSDictionary *)dic{
    BOOL ret = YES;
    if (![self isExistTable:tableName]) {
        NSLog(@"%@表不存在",tableName);
        return NO;
    }
    [self.dbQueue inDatabase:^(FMDatabase *db) {
        NSString * queryStr = [NSString stringWithFormat:@"REPLACE INTO %@",tableName];
        NSMutableArray * keyArray = [NSMutableArray array];
        NSMutableArray * valueArray = [NSMutableArray array];
        NSMutableString * values = [NSMutableString string];
        for (NSString * key in dic) {
            [keyArray addObject:key];
            [valueArray addObject:dic[key]];
            [values appendString:@"?,"];
        }
        if (values.length > 1) {
            [values deleteCharactersInRange:NSMakeRange(values.length - 1, 1)];
        }
        NSString * keyString = [keyArray componentsJoinedByString:@","];
        queryStr = [NSString stringWithFormat:@"%@ (%@) VALUES (%@)",queryStr,keyString,values];
        [db executeUpdate:queryStr withArgumentsInArray:valueArray];
    }];
    return ret;
}
-(BOOL)insertOrUpdate:(NSString *)tableName arrayName:(NSArray *)array{
    BOOL ret = YES;
    if (![self isExistTable:tableName]) {
        NSLog(@"%@表不存在",tableName);
        return NO;
    }
    [self.dbQueue inTransaction:^(FMDatabase *db, BOOL *rollback) {
        for (NSDictionary * dic in array) {
            NSString * queryStr = [NSString stringWithFormat:@"REPLACE INTO %@",tableName];
            NSMutableArray * keyArray = [NSMutableArray array];
            NSMutableArray * valueArray = [NSMutableArray array];
            NSMutableString * values = [NSMutableString string];
            for (NSString * key in dic) {
                [keyArray addObject:key];
                [valueArray addObject:dic[key]];
                [values appendString:@"?,"];
            }
            if (values.length > 1) {
                [values deleteCharactersInRange:NSMakeRange(values.length - 1, 1)];
            }
            NSString * keyString = [keyArray componentsJoinedByString:@","];
            queryStr = [NSString stringWithFormat:@"%@ (%@) VALUES (%@)",queryStr,keyString,values];
            [db executeUpdate:queryStr withArgumentsInArray:valueArray];
            
        }
    }];
    return  ret;
}

-(NSArray *)findAllFromTable:(NSString *)tableName{
    return [self findWithFormat:@"SELECT * FROM %@",tableName];
}
-(NSArray *)findWithFormat:(NSString *)format,...{
    va_list ap;
    va_start(ap, format);
    NSString *string = [[NSString alloc] initWithFormat:format locale:[NSLocale currentLocale] arguments:ap];
    va_end(ap);
    __block NSMutableArray * list = [NSMutableArray array];
    [self.dbQueue inDatabase:^(FMDatabase *db) {
        FMResultSet * set = [db executeQuery:string];
        while (set.next) {
            NSMutableDictionary * dic = [NSMutableDictionary dictionary];
            for (int i = 0; i <set.columnCount; i++) {
                NSString * key = [set columnNameForIndex:i];
                id value = [set objectForColumnIndex:i];
                [dic setValue:value forKey:key];
            }
            [list addObject:dic];
        }
    }];
    return list;
}

-(BOOL)clearTable:(NSString *)tableName{
    __block BOOL ret = YES;
    [self.dbQueue inDatabase:^(FMDatabase *db) {
        ret = [db executeUpdate:[NSString stringWithFormat:@"DELETE FROM %@;",tableName]];
    }];
    return ret;
}

-(BOOL)deleteTable:(NSString *)tableName withPrimaryKey:(NSInteger )pk{
    __block BOOL ret = YES;
    [self.dbQueue inDatabase:^(FMDatabase *db) {
        ret = [db executeUpdate:[NSString stringWithFormat:@"DELETE FROM %@ WHERE ID = %ld",tableName,(long)pk]];
    }];
    return ret;
}

-(BOOL)deleteFromTable:(NSString *)table withFormat:(NSString *)format,...{
    va_list ap;
    va_start(ap, format);
    NSString *string = [[NSString alloc] initWithFormat:format locale:[NSLocale currentLocale] arguments:ap];
    va_end(ap);
    __block BOOL ret = YES;
    [self.dbQueue inDatabase:^(FMDatabase *db) {
        ret = [db executeUpdate:[NSString stringWithFormat:@"DELETE FROM %@ WHERE %@",table,string]];
    }];
    return ret ;
}

-(NSString * )dicToStr:(NSDictionary *)dictionary{
    NSData * jsonData = [NSJSONSerialization dataWithJSONObject:dictionary options:NSJSONWritingPrettyPrinted error:nil];
    NSString * jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    jsonString = [jsonString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    jsonString = [jsonString stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    jsonString = [jsonString stringByReplacingOccurrencesOfString:@" " withString:@""];
    jsonString = [jsonString stringByReplacingOccurrencesOfString:@"{" withString:@""];
    jsonString = [jsonString stringByReplacingOccurrencesOfString:@"}" withString:@""];
    jsonString = [jsonString stringByReplacingOccurrencesOfString:@"\"" withString:@""];
    jsonString = [jsonString stringByReplacingOccurrencesOfString:@":" withString:@" "];
    return jsonString;
}


@end
