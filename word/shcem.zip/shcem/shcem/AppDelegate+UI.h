//
//  AppDelegate+UI.h
//  shcem
//
//  Created by huangdeyu on 2016/11/21.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (UI)
-(void)setupUI;
-(void)toMain;
@end
