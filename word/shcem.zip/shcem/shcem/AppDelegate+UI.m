//
//  AppDelegate+UI.m
//  shcem
//
//  Created by huangdeyu on 2016/11/21.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "AppDelegate+UI.h"
#import "SHBaseTabarController.h"
#import "SHBaseNavigationController.h"
#import "SHHomeVC.h"
#import "SHMallVC.h"
#import "SHTradeVC.h"
#import "SHInfoVC.h"
#import "SHMineVC.h"
#import "SHLaunchVC.h"
#import "SHFirstWebVC.h"

@implementation AppDelegate (UI)
-(void)setupUI{
    self.window = [[UIWindow alloc] init];
    self.window.frame = [UIScreen mainScreen].bounds;
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    [self setupAppearance];
//    [self toMain];
    //引导页
    if (![[NSUserDefaults standardUserDefaults] boolForKey:@"showGuide1"]) {
      //  [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"showGuide1"];
      //  SHLaunchVC * guide = [[SHLaunchVC alloc] init];
      //  self.window.rootViewController = guide;
        [self toWebView];
        DLog(@"第一次启动");
    } else {
        DLog(@"不是第一次启动");
        [self toMain];
    }

}
#pragma mark - private methods

-(void)toMain{
    SHBaseTabarController * tab = [[SHBaseTabarController alloc] init];
    
    SHHomeVC * hvc = [[SHHomeVC alloc] init];
    UIImage * img = [UIImage imageNamed:@"Homea"];
    UIImage * imgOn = [[UIImage imageNamed:@"Homeb"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    hvc.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"首页" image:img selectedImage:imgOn];
    hvc.title = @"首页";
    [self addItemController:hvc toTabBarController:tab];
    
    SHMallVC * mvc = [[SHMallVC alloc] init];
    img = [UIImage imageNamed:@"Supplya"];
    imgOn = [[UIImage imageNamed:@"Supplyb"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    mvc.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"商城" image:img selectedImage:imgOn];
    mvc.title = @"商城";
    [self addItemController:mvc toTabBarController:tab];
    
    SHTradeVC * tvc = [[SHTradeVC   alloc] init];
    img = [UIImage imageNamed:@"Messagea"];
    imgOn = [[UIImage imageNamed:@"Messageb"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
 //   tvc.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"交易" image:img selectedImage:imgOn];
    tvc.onlyShowBackArray = false;
    tvc.title = @"交易";
    [self addItemController:tvc toTabBarController:tab];
    
    SHInfoVC * ivc = [[SHInfoVC alloc] init];
    img = [UIImage imageNamed:@"informationa"];
    imgOn = [[UIImage imageNamed:@"informationb"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    ivc.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"资讯" image:img selectedImage:imgOn];
    ivc.title = @"资讯";
    [self addItemController:ivc toTabBarController:tab];
    ivc.onlyShowBackArray = false;
    
    SHMineVC * mivc = [[SHMineVC alloc] init];
    img = [UIImage imageNamed:@"Minea"];
    imgOn = [[UIImage imageNamed:@"Mineb"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
     mivc.title = @"会员中心";
    mivc.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"我" image:img selectedImage:imgOn];
   mivc.onlyShowBackArray = false;
    [self addItemController:mivc toTabBarController:tab];
    
    self.window.rootViewController = tab;
}
- (void)addItemController:(UIViewController *)itemController toTabBarController:(UITabBarController *)tab {
    SHBaseNavigationController *nav = [[SHBaseNavigationController alloc] initWithRootViewController:itemController];
    nav.view.backgroundColor = [UIColor clearColor];
    tab.tabBar.tintColor = COLOR_NAV_RED;
    tab.tabBar.backgroundColor = HexRGB(0xf9f9f9);
    [tab addChildViewController:nav];
}


- (void)toWebView{
    SHFirstWebVC * vc = [[SHFirstWebVC alloc] init];
    self.window.rootViewController = vc;
}

-(void)setupAppearance{
    
    /*
     New behavior on iOS 7.
     Default is YES.
     You may force an opaque background by setting the property to NO.
     If the navigation bar has a custom background image, the default is inferred
     from the alpha values of the image—YES if it has any pixel with alpha < 1.0
     If you send setTranslucent:YES to a bar with an opaque custom background image
     it will apply a system opacity less than 1.0 to the image.
     If you send setTranslucent:NO to a bar with a translucent custom background image
     it will provide an opaque background for the image using the bar's barTintColor if defined, or black
     for UIBarStyleBlack or white for UIBarStyleDefault if barTintColor is nil.
     */
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageWithColor:[COLOR_NAV_RED colorWithAlphaComponent:0.99]] forBarMetrics:UIBarMetricsDefault];//如果颜色指定为不透明，则viewController 的坐标是从0,64 开始的，如果有一点透明，则是从0，0开始计算的。
    [[UINavigationBar appearance] setTintColor:[UIColor whiteColor]];
    [[UINavigationBar appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                          [UIColor whiteColor], NSForegroundColorAttributeName, [UIFont boldSystemFontOfSize:17], NSFontAttributeName, nil]];
}

@end
