//
//  AppDelegate+OtherTask.m
//  shcem
//
//  Created by huangdeyu on 2016/12/9.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "AppDelegate+OtherTask.h"
#import "SHLoopManager.h"
#import "SHUserManager.h"

@implementation AppDelegate (OtherTask)

-(void)startTask{
    [[SHUserManager sharedManager] getUserInfo]; //读缓存
    [[SHLoopManager  shareManager] startWorking];
}

@end
