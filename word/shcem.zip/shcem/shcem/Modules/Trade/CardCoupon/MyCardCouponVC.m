//
//  MyCardCouponVC.m
//  shcem
//
//  Created by xupeipei on 2016/12/8.
//  Copyright © 2016年 Shcem. All rights reserved.
//
#import "MyCardCouponVC.h"
#import <WebKit/WebKit.h>
#import <Masonry/Masonry.h>
#import "MyCardCouponVC.h"
#import "MyCardCouponCell.h"
#import "SHMallService.h"
#import "MJExtension.h"
#import "NSString+Format.h"
#import "MyCouponVC.h"
#import "MyCounterFeeVC.h"
#import "MyCardCouponModel.h"
#import "GetCouponVC.h"

@interface MyCardCouponVC ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong) UITableView *dataTB;
@property (nonatomic,strong) NSArray *dataArray;


@end

@implementation MyCardCouponVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的卡券";
    [self addSubView];
    
}


-(void)addSubView{
    [self.view addSubview:self.dataTB];
    
    [self.dataTB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.view.mas_top);
        make.bottom.mas_equalTo(self.view.mas_bottom);
        make.left.mas_equalTo(self.view.mas_left);
        make.right.mas_equalTo(self.view.mas_right);
    }];
}

-(NSArray*)dataArray{
    if (!_dataArray) {
        NSArray *originDataArray = @[@{@"title":@"优惠券",@"imageName":@"youhuiquan"},
                       @{@"title":@"手续费",@"imageName":@"shouxufei"},
                       @{@"title":@"兑换券",@"imageName":@"duihuanquan"},
                         ];
        
        _dataArray = (NSArray*)[MyCardCouponModel mj_objectArrayWithKeyValuesArray:originDataArray];
        
    }
    return _dataArray;
}

-(UITableView*)dataTB{
    if (!_dataTB) {
        _dataTB = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        [_dataTB setDelegate:self];
        [_dataTB setDataSource:self];
        _dataTB.backgroundColor = BACKGROUNDCOLOR_CUSTOM;
        [_dataTB registerClass:[MyCardCouponCell class] forCellReuseIdentifier:NSStringFromClass([MyCardCouponCell class])];
    }
    return _dataTB;
}

#pragma mark MyCardCouponCellDelegate

-(void)MyCardCouponCellButtonAction:(id)sender type:(NSInteger)type{
    if (type == 0) {
        [self pushVC:[MyCounterFeeVC class]];
    }else{
        [self pushVC:[MyCouponVC class]];
    }
}

-(void)rightBTAction:(id)sender{
    [self pushVC:[MyCardCouponVC class]];
}

-(void)pushVC:(Class)VC{
    UIViewController* pushVC = [[VC alloc] init];
    pushVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:pushVC animated:YES];
}

#pragma mark - UITableViewDelegate -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
   return self.dataArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MyCardCouponCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([MyCardCouponCell class])];
    cell.model = self.dataArray[indexPath.section];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
        case 0:
        {
            [self pushVC:[MyCouponVC class]];
        }
            break;
            
        case 1:
        {
            [self pushVC:[MyCounterFeeVC class]];
        }
            break;
            
        case 2:
        {
            [self pushVC:[GetCouponVC class]];
        }
            break;
            
        default:
            break;
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
