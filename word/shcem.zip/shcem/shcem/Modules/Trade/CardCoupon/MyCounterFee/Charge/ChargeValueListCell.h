//
//  ChargeValueListCell.h
//  shcem
//
//  Created by xupeipei on 2017/2/28.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChargeModel.h"

@protocol ChargeValueListCellDelegate <NSObject>

-(void)ChargeValueListCellDelegate:(id)sender;

@end

@interface ChargeValueListCell : UITableViewCell


@property (nonatomic,weak) id<ChargeValueListCellDelegate> delegate;
@property (nonatomic,strong) NSArray *modelArray;

@end
