//
//  MyCouponModel.h
//  shcem
//
//  Created by xupeipei on 2017/2/27.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyCouponModel : NSObject

@property (nonatomic, copy) NSString * ActivityID;
@property (nonatomic, copy) NSString * Amount;
@property (nonatomic, copy) NSString * CouponID;
@property (nonatomic, copy) NSString * CouponName;
@property (nonatomic, copy) NSString * CouponNumber;
@property (nonatomic, copy) NSString * CouponStatus;
@property (nonatomic, copy) NSString * CouponType;
@property (nonatomic, copy) NSString * CouponValidEndDate;
@property (nonatomic, copy) NSString * CouponValidStartDate;
@property (nonatomic, copy) NSString * DISABLED;
@property (nonatomic, copy) NSString * DeductibleAmount;
@property (nonatomic, copy) NSString * DeductionAmount;
@property (nonatomic, copy) NSString * ExchangeCode;
@property (nonatomic, copy) NSString * FirmID;
@property (nonatomic, copy) NSString * ID;
@property (nonatomic, copy) NSString * REC_CREATETIME;
@property (nonatomic, copy) NSString * REC_MODIFYBY;
@property (nonatomic, copy) NSString * REC_MODIFYTIME;
@property (nonatomic, copy) NSString * ReceiveDate;
@property (nonatomic, copy) NSString * RechargeAmount;
@property (nonatomic, copy) NSString * TraderID;
@property (nonatomic, copy) NSString * TransStatus;


@end
