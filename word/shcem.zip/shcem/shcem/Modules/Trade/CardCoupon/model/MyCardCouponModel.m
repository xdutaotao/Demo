//
//  MyCardCouponModel.m
//  shcem
//
//  Created by xupeipei on 2017/2/27.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "MyCardCouponModel.h"

@implementation MyCardCouponModel

@end
