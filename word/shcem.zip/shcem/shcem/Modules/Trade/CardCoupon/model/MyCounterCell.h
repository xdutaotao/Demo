//
//  MyCounterCell.h
//  shcem
//
//  Created by xupeipei on 2017/2/27.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyCouponModel.h"

@protocol MyCounterCellDelegate <NSObject>

-(void)MyCounterCellDelegate:(id)sender;

@end


@interface MyCounterCell : UITableViewCell

@property (nonatomic,strong)MyCouponModel *model;

@property (nonatomic,weak) id<MyCounterCellDelegate> delegate;

@end
