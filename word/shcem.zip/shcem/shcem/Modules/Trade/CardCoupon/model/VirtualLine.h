//
//  VirtualLine.h
//  shcem
//
//  Created by xupeipei on 2017/2/27.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VirtualLine : UIView

-(id)initWithFrame:(CGRect)frame color:(UIColor*)color;

@end
