//
//  MyCounterHeaderCell.h
//  shcem
//
//  Created by xupeipei on 2017/2/27.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MyCounterHeaderCellDelegate <NSObject>

-(void)MyCounterHeaderCellDelegate:(id)model type:(NSInteger)type;

@end

@interface MyCounterHeaderCell : UITableViewCell


@property (nonatomic,strong) NSString* totalMoney;

@property (nonatomic,weak) id<MyCounterHeaderCellDelegate> delegate;

@end
