//
//  MyCouponNumberModel.h
//  shcem
//
//  Created by xupeipei on 2017/2/27.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyCouponNumberModel : NSObject

@property(nonatomic,copy) NSString *Status;
@property(nonatomic,copy) NSString *Quantity;
@property(nonatomic,copy) NSString *StatusText;

@end
