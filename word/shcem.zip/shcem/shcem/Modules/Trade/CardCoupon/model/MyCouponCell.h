//
//  MyCouponCell.h
//  shcem
//
//  Created by xupeipei on 2017/2/27.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyCouponModel.h"

@interface MyCouponCell : UITableViewCell

@property (nonatomic,strong)MyCouponModel *model;

@end
