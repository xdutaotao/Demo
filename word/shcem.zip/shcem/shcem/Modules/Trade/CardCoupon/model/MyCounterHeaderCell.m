//
//  MyCounterHeaderCell.m
//  shcem
//
//  Created by xupeipei on 2017/2/27.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "MyCounterHeaderCell.h"
#import <Masonry/Masonry.h>
#import "NSString+Format.h"

@interface MyCounterHeaderCell()

@property (strong, nonatomic)  UILabel *balanceLB;
@property (strong, nonatomic)  UILabel *balanceTitleLB;

@property (strong, nonatomic)  UIView *horizontalLine;
@property (strong, nonatomic)  UIView *vertiacalLine;

@property (strong, nonatomic)  UIButton *detailBT;
@property (strong, nonatomic)  UIButton *chargeBT;


@end

@implementation MyCounterHeaderCell

-(void)setTotalMoney:(NSString *)totalMoney{
    _totalMoney = totalMoney;
    
    self.balanceLB.text = _totalMoney;
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        [self.contentView addSubview:self.balanceLB];
        [self.contentView addSubview:self.balanceTitleLB];

        [self.contentView addSubview:self.horizontalLine];
        [self.contentView addSubview:self.vertiacalLine];
        
        [self.contentView addSubview:self.detailBT];
        [self.contentView addSubview:self.chargeBT];
        
        [self layout];
       
    }
    return self;
}

-(void)layout{
    [self.balanceLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.contentView.mas_top).offset(30);
        make.left.mas_equalTo(self.contentView.mas_left);
        make.right.mas_equalTo(self.contentView.mas_right);
        make.height.mas_equalTo(40);
    }];
    
    [self.balanceTitleLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.balanceLB.mas_bottom);
        make.left.mas_equalTo(self.balanceLB.mas_left);
        make.right.mas_equalTo(self.balanceLB.mas_right);
        make.height.mas_equalTo(20);
    }];

    [self.horizontalLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.balanceTitleLB.mas_bottom).offset(10);
        make.left.mas_equalTo(self.contentView.mas_left);
        make.right.mas_equalTo(self.contentView.mas_right);
        make.height.mas_equalTo(1);
    }];
    
    [self.detailBT mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.horizontalLine.mas_bottom);
        make.left.mas_equalTo(self.contentView.mas_left);
        make.width.mas_equalTo(self.contentView.mas_width).dividedBy(2);
        make.bottom.mas_equalTo(self.contentView.mas_bottom);
    }];
    
    [self.chargeBT mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.detailBT.mas_top);
        make.left.mas_equalTo(self.detailBT.mas_right);
        make.size.mas_equalTo(self.detailBT);
    }];
    
    [self.vertiacalLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.detailBT.mas_top);
        make.left.mas_equalTo(self.detailBT.mas_right);
        make.bottom.mas_equalTo(self.contentView.mas_bottom);
        make.width.mas_equalTo(1);
    }];

}

-(UILabel*)balanceLB{
    if (!_balanceLB) {
        _balanceLB = [[UILabel alloc] initWithFrame:CGRectZero];
        _balanceLB.font = [UIFont boldSystemFontOfSize:30];
        _balanceLB.text = @"9999.99";
        _balanceLB.textAlignment = NSTextAlignmentCenter;
        _balanceLB.textColor = RedColor_Custom;
    }
    return _balanceLB;
}

-(UILabel*)balanceTitleLB{
    if (!_balanceTitleLB) {
        _balanceTitleLB = [[UILabel alloc] initWithFrame:CGRectZero];
        _balanceTitleLB.font = [UIFont systemFontOfSize:14];
        _balanceTitleLB.text = @"手续费账户余额(元)";
        _balanceTitleLB.textAlignment = NSTextAlignmentCenter;
        _balanceTitleLB.textColor = BLACK_CUSTOM;
        _balanceTitleLB.numberOfLines = 0;
    }
    return _balanceTitleLB;
}

-(UIView*)horizontalLine{
    if (!_horizontalLine) {
        _horizontalLine = [[UIView alloc] initWithFrame:CGRectZero];
        _horizontalLine.backgroundColor = LIGHTGRAYf2;
    }
    return _horizontalLine;
}

-(UIView*)vertiacalLine{
    if (!_vertiacalLine) {
        _vertiacalLine = [[UIView alloc] initWithFrame:CGRectZero];
        _vertiacalLine.backgroundColor = LIGHTGRAYf2;
    }
    return _vertiacalLine;
}

-(UIButton*)detailBT{
    if (!_detailBT) {
        _detailBT = [UIButton buttonWithType:UIButtonTypeCustom];
        [_detailBT setTitle:@"收支明细  " forState:UIControlStateNormal];
        [_detailBT.titleLabel setFont:[UIFont systemFontOfSize:14]];
        [_detailBT setTitleColor:BLUE_CUSTOM forState:UIControlStateNormal];
        [_detailBT addTarget:self action:@selector(detailBTAction:) forControlEvents:UIControlEventTouchUpInside];
        
        UIImageView *rightArrowIV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"blueRight"]];
        [_detailBT addSubview:rightArrowIV];
        [rightArrowIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(_detailBT.mas_centerY);
            make.left.mas_equalTo(_detailBT.mas_centerX).offset(30);
            make.size.mas_equalTo(CGSizeMake(18, 18));
        }];
    }
    return _detailBT;
}

-(UIButton*)chargeBT{
    if (!_chargeBT) {
        _chargeBT = [UIButton buttonWithType:UIButtonTypeCustom];
        [_chargeBT setTitle:@"立即充值  " forState:UIControlStateNormal];
        [_chargeBT.titleLabel setFont:[UIFont systemFontOfSize:14]];
        [_chargeBT setTitleColor:RedColor_Custom forState:UIControlStateNormal];
        [_chargeBT addTarget:self action:@selector(chargeBTAction:) forControlEvents:UIControlEventTouchUpInside];
        
        UIImageView *rightArrowIV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"redRight"]];
        [_chargeBT addSubview:rightArrowIV];
        [rightArrowIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(_chargeBT.mas_centerY);
            make.left.mas_equalTo(_chargeBT.mas_centerX).offset(30);
            make.size.mas_equalTo(CGSizeMake(18, 18));
        }];
    }
    return _chargeBT;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)detailBTAction:(id)sender {
    if ([self.delegate respondsToSelector:@selector(MyCounterHeaderCellDelegate:type:)]) {
        [self.delegate MyCounterHeaderCellDelegate:sender type:0];
    }
}

- (void)chargeBTAction:(id)sender {
    if ([self.delegate respondsToSelector:@selector(MyCounterHeaderCellDelegate:type:)]) {
        [self.delegate MyCounterHeaderCellDelegate:sender type:1];
    }
}

@end
