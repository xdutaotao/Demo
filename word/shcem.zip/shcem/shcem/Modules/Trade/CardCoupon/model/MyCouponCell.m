//
//  MyCouponCell.m
//  shcem
//
//  Created by xupeipei on 2017/2/27.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "MyCouponCell.h"
#import <Masonry/Masonry.h>
#import "VirtualLine.h"

@interface MyCouponCell()


@property (strong,nonatomic) UIImageView *leftBGIV;
@property (strong,nonatomic) UIImageView *rightBGIV;

@property (strong,nonatomic) UILabel *couponLB;
@property (strong,nonatomic) UILabel *priceLB;
@property (strong,nonatomic) UILabel *functionLB;
@property (strong,nonatomic) UIImageView *useStatusIV;
@property (strong,nonatomic) VirtualLine *virtualLine;
@property (strong,nonatomic) UILabel *effectiveDateLB;

@end

@implementation MyCouponCell

-(void)setModel:(MyCouponModel *)model{
    _model = model;
    
    switch (model.TransStatus.integerValue) {
        case 3:
            [self.leftBGIV setImage:[UIImage imageNamed:@"couponYellow"]];
            self.priceLB.textColor = YELLOW_CUSTOM;
            self.functionLB.textColor = BLACK_CUSTOM;
            self.useStatusIV.hidden = YES;
            break;
            
        case 5:
            [self.leftBGIV setImage:[UIImage imageNamed:@"couponGray"]];
            self.useStatusIV.image = [UIImage imageNamed:@"couponUsed"];
            self.priceLB.textColor = GRAY_CUSTOM;
            self.functionLB.textColor = GRAY_CUSTOM;
            self.useStatusIV.hidden = NO;
            break;
            
        case 10:
            [self.leftBGIV setImage:[UIImage imageNamed:@"couponGray"]];
            self.useStatusIV.image = [UIImage imageNamed:@"couponOverdue"];
            self.priceLB.textColor = GRAY_CUSTOM;
            self.functionLB.textColor = GRAY_CUSTOM;
            self.useStatusIV.hidden = NO;
            break;
            
        default:
            break;
    }
    
    NSString *title = [NSString stringWithFormat:@"%@元",model.Amount];
    NSMutableAttributedString *titleStr = [[NSMutableAttributedString alloc] initWithString:title];
    [titleStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:16] range:NSMakeRange(title.length-1,1)];
    
    self.priceLB.attributedText = titleStr;
    self.effectiveDateLB.text = [NSString stringWithFormat:@"有效期至：%@",[self proceeDateString:model.CouponValidEndDate]];
    
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.backgroundColor =[UIColor clearColor];
        
        self.leftBGIV = [[UIImageView alloc] initWithFrame:CGRectZero];
        [self.leftBGIV setImage:[UIImage imageNamed:@"couponRed"]];
        [self.contentView addSubview:self.leftBGIV];
        [self.leftBGIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top);
            make.left.mas_equalTo(self.contentView.mas_left).offset(10);
            make.size.mas_equalTo(CGSizeMake(36, 120));
        }];
        
        self.rightBGIV = [[UIImageView alloc] initWithFrame:CGRectZero];
        [self.rightBGIV setImage:[UIImage imageNamed:@"couponWhite"]];
        [self.contentView addSubview:self.rightBGIV];
        [self.rightBGIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.leftBGIV.mas_top);
            make.left.mas_equalTo(self.leftBGIV.mas_right);
            make.right.mas_equalTo(self.contentView.mas_right).offset(-10);
            make.bottom.mas_equalTo(self.leftBGIV.mas_bottom);
        }];
        
        self.couponLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.couponLB.font = [UIFont systemFontOfSize:18];
        self.couponLB.text = @"优惠券";
        self.couponLB.textAlignment = NSTextAlignmentCenter;
        self.couponLB.font = [UIFont systemFontOfSize:14];
        self.couponLB.textColor = [UIColor whiteColor];
        self.couponLB.numberOfLines = 0;
        self.couponLB.lineBreakMode = NSLineBreakByClipping;
        [self.contentView addSubview:self.couponLB];
        [self.couponLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.leftBGIV.mas_top);
            make.centerX.mas_equalTo(self.leftBGIV.mas_centerX);
            make.width.mas_equalTo(20);
            make.bottom.mas_equalTo(self.leftBGIV.mas_bottom);
        }];
        
        self.priceLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.priceLB.text = @"0元";
        self.priceLB.font = [UIFont systemFontOfSize:50];
        self.priceLB.textColor = YELLOW_CUSTOM;
        [self.contentView addSubview:self.priceLB];
        [self.priceLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top).offset(30);
            make.left.mas_equalTo(self.leftBGIV.mas_right).offset(5);
            make.width.mas_equalTo(110);
            make.height.mas_equalTo(40);
        }];
        
        self.functionLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.functionLB.font = [UIFont systemFontOfSize:14];
        self.functionLB.numberOfLines = 0;
        self.functionLB.textAlignment = NSTextAlignmentRight;
        self.functionLB.textColor = BLACK_CUSTOM;
        self.functionLB.text = @"仅抵用交易手续费\n每单仅可使用一张";
        [self.contentView addSubview:self.functionLB];
        [self.functionLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(self.priceLB.mas_centerY);
            make.left.mas_equalTo(self.priceLB.mas_right).offset(5);
            make.right.mas_equalTo(self.contentView.mas_right).offset(-20);
            make.height.mas_equalTo(self.priceLB.mas_height);
        }];
        
        self.useStatusIV = [[UIImageView alloc] initWithFrame:CGRectZero];
        [self.contentView addSubview:self.useStatusIV];
        [self.useStatusIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(self.contentView.mas_centerY);
            make.right.mas_equalTo(self.contentView.mas_right).offset(-20);
            make.size.mas_equalTo(CGSizeMake(93, 70));
        }];
        
        self.virtualLine = [[VirtualLine alloc] initWithFrame:CGRectZero];
        self.virtualLine.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:self.virtualLine];
        [self.virtualLine mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.rightBGIV.mas_top).offset(90);
            make.left.mas_equalTo(self.rightBGIV.mas_left).offset(10);
            make.right.mas_equalTo(self.rightBGIV.mas_right).offset(-10);
            make.height.mas_equalTo(2);
        }];

        
        self.effectiveDateLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.effectiveDateLB.font = [UIFont systemFontOfSize:12];
        self.effectiveDateLB.textColor = GRAY_CUSTOM;
        self.effectiveDateLB.numberOfLines = 0;
        self.effectiveDateLB.text = @"有效期至：2017-01-01";
        [self.contentView addSubview:self.effectiveDateLB];
        [self.effectiveDateLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.virtualLine.mas_bottom);
            make.centerX.mas_equalTo(self.rightBGIV.mas_centerX);
            make.bottom.mas_equalTo(self.contentView.mas_bottom);
        }];

    }
    
    return self;
}


-(NSString*)proceeDateString:(NSString*)string{
    if (string.length>10) {
        return [string substringToIndex:10];
    }
    return string;
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
