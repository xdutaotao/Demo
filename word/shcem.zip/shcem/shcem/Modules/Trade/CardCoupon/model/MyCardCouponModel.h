//
//  MyCardCouponModel.h
//  shcem
//
//  Created by xupeipei on 2017/2/27.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyCardCouponModel : NSObject

@property(nonatomic,copy) NSString *imageName;
@property(nonatomic,copy) NSString *title;

@end
