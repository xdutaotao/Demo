//
//  GetCouponCell.m
//  shcem
//
//  Created by xupeipei on 2017/2/16.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "GetCouponCell.h"
#import <Masonry/Masonry.h>

@interface GetCouponCell()<UITextFieldDelegate>

@property (nonatomic,strong) UILabel* titleLB;
@property (nonatomic,strong) UITextField* codeTF;
@property (nonatomic,strong) UIButton* confirmBT;

@property (nonatomic,strong) NSString* code;

@end

@implementation GetCouponCell

-(void)layout{
    [self.titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.contentView.mas_top).offset(20);
        make.left.mas_equalTo(self.contentView.mas_left).offset(10);
        make.right.mas_equalTo(self.contentView.mas_right).offset(-10);
        make.height.mas_equalTo(30);
    }];
    
    [self.codeTF mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.titleLB.mas_bottom).offset(10);
        make.left.mas_equalTo(self.titleLB.mas_left);
        make.right.mas_equalTo(self.titleLB.mas_right);
        make.height.mas_equalTo(44);
    }];

    
    [self.confirmBT mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.codeTF.mas_bottom).offset(20);
        make.left.mas_equalTo(self.codeTF.mas_left);
        make.right.mas_equalTo(self.codeTF.mas_right);
        make.height.mas_equalTo(self.codeTF);
    }];
}

-(UILabel*)titleLB{
    if (!_titleLB) {
        _titleLB = [[UILabel alloc] initWithFrame:CGRectZero];
        _titleLB.font = [UIFont systemFontOfSize:14];
        _titleLB.backgroundColor = [UIColor clearColor];
        _titleLB.textColor = [UIColor grayColor];
        _titleLB.text = @"请输入您收到的兑换码:";
    }
    
    return _titleLB;
}

-(UITextField*)codeTF{
    if (!_codeTF) {
        _codeTF = [[UITextField alloc] initWithFrame:CGRectZero];
        _codeTF.borderStyle = UITextBorderStyleRoundedRect;
        _codeTF.delegate = self;
    }
    return _codeTF;
}

-(UIButton*)confirmBT{
    if (!_confirmBT) {
        _confirmBT = [[UIButton alloc] initWithFrame:CGRectZero];
        [_confirmBT setTitle:@"提交 " forState:UIControlStateNormal];
        [_confirmBT setBackgroundColor:RedColor_Custom];
        _confirmBT.layer.masksToBounds = YES;
        _confirmBT.layer.cornerRadius = 5;
        [_confirmBT addTarget:self action:@selector(confirmBTAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _confirmBT;
}


-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.backgroundColor = [UIColor clearColor];
        
        [self.contentView addSubview:self.titleLB];
        [self.contentView addSubview:self.codeTF];
        [self.contentView addSubview:self.confirmBT];
        
        [self layout];
    }
    
    return self;
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    self.code = [textField.text stringByReplacingCharactersInRange:range withString:string];
    return YES;
}

-(void)confirmBTAction:(id)sender{
    if ([self.delegate respondsToSelector:@selector(GetCouponCellDelegate:)]) {
        [self.delegate GetCouponCellDelegate:self.code];
    }
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
