//
//  GetCouponCell.h
//  shcem
//
//  Created by xupeipei on 2017/2/16.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomScrollViewCellModel.h"

@protocol GetCouponCellDelegate <NSObject>

-(void)GetCouponCellDelegate:(id)sender;

@end

@interface GetCouponCell : UITableViewCell

@property (nonatomic,weak) id<GetCouponCellDelegate> delegate;

@end
