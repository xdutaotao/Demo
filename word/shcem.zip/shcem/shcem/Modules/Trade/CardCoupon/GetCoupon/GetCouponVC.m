//
//  GetCouponVC.m
//  shcem
//
//  Created by xupeipei on 2016/12/8.
//  Copyright © 2016年 Shcem. All rights reserved.
//
#import "GetCouponVC.h"
#import <WebKit/WebKit.h>
#import <Masonry/Masonry.h>
#import "GetCouponVC.h"
#import "GetCouponCell.h"
#import "SHMallService.h"
#import "MJExtension.h"
#import "NSString+Format.h"
#import "MyCouponVC.h"
#import "SHTradeService.h"
#import "MyCounterFeeVC.h"
#import "MyCardCouponModel.h"
#import "GetCouponVC.h"
#import "TPKeyboardAvoidingTableView.h"

@interface GetCouponVC ()<UITableViewDataSource,UITableViewDelegate,GetCouponCellDelegate>

@property (nonatomic,strong) TPKeyboardAvoidingTableView *dataTB;

@end

@implementation GetCouponVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的卡券";
    [self addSubView];
}


-(void)addSubView{
    [self.view addSubview:self.dataTB];
    
    [self.dataTB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.view.mas_top);
        make.bottom.mas_equalTo(self.view.mas_bottom);
        make.left.mas_equalTo(self.view.mas_left);
        make.right.mas_equalTo(self.view.mas_right);
    }];
}

-(TPKeyboardAvoidingTableView*)dataTB{
    if (!_dataTB) {
        _dataTB = [[TPKeyboardAvoidingTableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        [_dataTB setDelegate:self];
        [_dataTB setDataSource:self];

        _dataTB.separatorStyle = UITableViewCellSeparatorStyleNone;
        [_dataTB registerClass:[GetCouponCell class] forCellReuseIdentifier:NSStringFromClass([GetCouponCell class])];
    }
    return _dataTB;
}

#pragma mark GetCouponCellDelegate

-(void)GetCouponCellDelegate:(id)sender{
    [self ExchangeCouponByCode:sender];
}

-(void)ExchangeCouponByCode:(NSString*)code{
    if (![self checkLoginStatus]) {
        [self toast:STR_TRADE_TOAST_AGAIN_LOGIN];
        return;
    }
    
    if (code.length == 0) {
        [self toast:@"兑换码不能为空"];
        return;
    }
    
    SHUserModel * userModel = [[SHUserManager sharedManager] getUserInfoDirect];
    
    NSDictionary *subDic =@{
                            @"ExchangeCode":code,
                            @"TraderID":userModel.TraderID,
                            @"OptUserCode":userModel.UserCode,
                            };
    
    
    SHQueryCondition * condition = [SHQueryCondition defaultCondition];
    condition.parameter = @{@"json":@{@"ServiceName":@"Shcem.Member.ServiceContract.INewCouponService",
                                      @"MethodName":@"ExchangeCouponByCode",
                                      @"Userid":[[SHUserManager sharedManager] getUserId],
                                      @"Version":B_VERSION,
                                      @"Params":[NSJSONSerialization stringWithJSONObject:subDic]
                                      }};
    
    [self showProgress];
    [SHTradeService ExchangeCouponByCodeServiceWithCondition:condition callback:^(NSError *err, id responseObject) {
        [self hideProgress];
        if (err == nil) {
            [self alert];
        }else{
            [self toast:err.userInfo[@"NSLocalizedDescription"]];
        }

    }];
    
}


-(void)rightBTAction:(id)sender{
    [self pushVC:[GetCouponVC class]];
}

-(void)pushVC:(Class)VC{
    UIViewController* pushVC = [[VC alloc] init];
    pushVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:pushVC animated:YES];
}

#pragma mark - UITableViewDelegate -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 400;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    GetCouponCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([GetCouponCell class])];
    cell.delegate = self;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
