//
//  SHBalanceDetailVC.m
//  shcem
//
//  Created by xupeipei on 2016/12/8.
//  Copyright © 2016年 Shcem. All rights reserved.
//
#import "SHBalanceDetailVC.h"
#import <WebKit/WebKit.h>
#import <Masonry/Masonry.h>
#import "SHBalanceDetailVC.h"
#import "SHBalanceDetailTableViewCell.h"
#import "SHMallService.h"
#import "MJExtension.h"
#import "NSString+Format.h"

@interface SHBalanceDetailVC ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong) UITableView *dataTB;
@property (strong,nonatomic) NSArray *dataArray;

@end

@implementation SHBalanceDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"资金详情";
    [self addSubView];
    
    [self queryOneFirmBanlance];
}

-(void)queryOneFirmBanlance{
    if (![self checkLoginStatus]) {
        return;
    }
    
    SHUserModel *userModel = [[SHUserManager sharedManager] getUserInfoDirect];
    SHQueryCondition * condition = [SHQueryCondition defaultCondition];
    condition.parameter = URL_PARAMETER_QueryOneFirmBanlance(userModel.FirmID);
    DLog(@"%@",condition.parameter);
    [self showProgress];
    [SHMallService queryOneFirmBanlanceModelWithCondition:condition callback:^(NSError *err, SHQueryOneFirmBanlanceModel *queryOneFirmBanlanceModel) {
        [self hideProgress];
        if (err == nil) {
            [self reSetDataArray:queryOneFirmBanlanceModel];
            [self.dataTB reloadData];
        }else{
            [self toast:err.userInfo[@"NSLocalizedDescription"]];
        }
    }];
}

-(NSArray*)dataArray{
    if (!_dataArray) {
        _dataArray = [[NSArray alloc] init];
    }
    return _dataArray;
}

-(void)reSetDataArray:(SHQueryOneFirmBanlanceModel*)queryOneFirmBanlanceModel{
    NSMutableArray *tempMutArray = [NSMutableArray arrayWithCapacity:0];
    NSArray *keyArray =@[
                         @{@"title":@" 资金账户余额（元）",@"paKey":@"USERBALANCEFromOra"},
                         @{@"title":@" 现货可用授信额度（元）",@"paKey":@"BALANCEFromS"},
                         @{@"title":@" 预售可用授信额度（元）",@"paKey":@"preSaleBALANCEFromS"}
                         ];
    
    for (NSInteger i=0; i<keyArray.count; i++) {
        NSDictionary *tempDic = keyArray[i];
        NSString *money = [queryOneFirmBanlanceModel valueForKey:tempDic[@"paKey"]];
        
        SHBalanceDetailModel *tempModel = [[SHBalanceDetailModel alloc] init];
        tempModel.title = tempDic[@"title"];
        tempModel.money = [NSString keepTwoDecimalPlaces:money];
        
        [tempMutArray addObject:tempModel];
    }
    
    self.dataArray = tempMutArray;
    [self.dataTB reloadData];
    
}

-(void)addSubView{
    [self.view addSubview:self.dataTB];
    
    [self.dataTB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.view.mas_top);
        make.bottom.mas_equalTo(self.view.mas_bottom);
        make.left.mas_equalTo(self.view.mas_left);
        make.right.mas_equalTo(self.view.mas_right);
    }];
}

-(UITableView*)dataTB{
    if (!_dataTB) {
        _dataTB = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _dataTB.backgroundColor = BACKGROUNDCOLOR_CUSTOM;
        [_dataTB setDelegate:self];
        [_dataTB setDataSource:self];
    }
    return _dataTB;
}

-(void)rightBTAction:(id)sender{
    [self pushVC:[SHBalanceDetailVC class]];
}

-(void)pushVC:(Class)VC{
    UIViewController* pushVC = [[VC alloc] init];
    pushVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:pushVC animated:YES];
}

#pragma mark - UITableViewDelegate -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.dataArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return section == 0? 0.01f:10;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 160;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    SHBalanceDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:SHBalanceDetailTableViewCellReuseIdentifier];
    if (!cell) {
        cell = [[SHBalanceDetailTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SHBalanceDetailTableViewCellReuseIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    cell.balanceDetailModel = self.dataArray[indexPath.section];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
