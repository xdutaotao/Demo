//
//  SHFirstWebVC.m
//  shcem
//
//  Created by guzhenfu on 17/6/8.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "SHFirstWebVC.h"
#import <AFNetworking/AFNetworking.h>
#import "AppDelegate+UI.h"

@interface SHFirstWebVC ()

@property (nonatomic,strong) UIWebView * webView;
@end

@implementation SHFirstWebVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.webView];
    
  //  [_webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://case.youzewang.com/api/lotteryFirst.php"]]];
    [self loadData];
}
- (void)loadData{
    WS(weakSelf);
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    [manager.requestSerializer setValue:@"text/html" forHTTPHeaderField:@"content-type"];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/html", nil];
    [manager GET:@"http://case.youzewang.com/api/lotteryFirst.php" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        DLog(@"请求成功");
        NSNumber * num = [responseObject objectForKey:@"status"];
        if (num) {
            NSInteger numInt = [num integerValue];
            if (numInt == 1) {          //进入网页
                NSString * urlStr = [responseObject objectForKey:@"url"];
                [weakSelf.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:urlStr]]];
            }else{
                [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"showGuide1"];
                AppDelegate * appDelegate = ( AppDelegate *)[UIApplication sharedApplication].delegate;
                [appDelegate toMain];
            }
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        DLog(@"请求失败");
    }];
}

#pragma mark - 初始化

- (UIWebView *)webView{
    if (!_webView) {
        _webView = [[UIWebView alloc] initWithFrame:self.view.bounds];
    }
    return _webView;
}

@end
