//
//  SHLaunchContentVC.m
//  shcem
//
//  Created by huangdeyu on 2017/1/5.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "SHLaunchContentVC.h"
#import "AppDelegate+UI.h"

@interface SHLaunchContentVC ()
@property(nonatomic,assign) NSInteger index;
@property(nonatomic,strong) UIImageView * bg;
@property(nonatomic,strong) UIImageView * fontView1;
@property(nonatomic,strong) UIImageView * fontView2;
@property(nonatomic,strong) UIImageView * fontView3;

@property(nonatomic,strong) UIButton * button;
@end

@implementation SHLaunchContentVC

-(instancetype)initWithIndex:(NSInteger)index{
    if (self = [super init]) {
        self.index = index;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = RGBCOLOR(arc4random() % 255, arc4random() % 255, arc4random() % 255);
    self.view.tag = self.index;
    DLog(@"当前加载的页面的tag是%ld..-------------",(long)self.index);
    [self addImages];
    [self setupAinmate];
}

-(void)addImages{
    NSString * bgImageName = [NSString stringWithFormat:@"launch_bg%ld.jpg",(long)self.index+1];
    self.bg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:bgImageName]];
    self.bg.frame = self.view.bounds;
    [self.view addSubview:self.bg];
    NSString * font1Name = [NSString stringWithFormat:@"lead%ld_1",(long)self.index+1];
    self.fontView1 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:font1Name]];
    self.fontView1.frame = self.view.bounds;
    [self.view addSubview:self.fontView1];
    
    NSString * font2Name = [NSString stringWithFormat:@"lead%ld_2",(long)self.index+1];
    self.fontView2 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:font2Name]];
    self.fontView2.frame = self.view.bounds;
    [self.view addSubview:self.fontView2];
    
    NSString * font3Name = [NSString stringWithFormat:@"lead%ld_3",(long)self.index+1];
    self.fontView3 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:font3Name]];
    self.fontView3.frame = self.view.bounds;
    [self.view addSubview:self.fontView3];
    DLog(@"页面名字是%@，%@，%@",font1Name,font2Name,font3Name);
    if (self.index == 2) {
        [self.view addSubview:self.button];
    }
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if (self.block) {
        DLog(@"当前页是%ld",(long)self.view.tag);
        self.block(self.view.tag);
    }
    [self startAnimate];
}
#pragma mark - 手势
-(void)imageClicked:(UIButton *)gesture{
    AppDelegate * appDelegate = ( AppDelegate *)[UIApplication sharedApplication].delegate;
    [appDelegate toMain];
}
-(void)startAnimate{
    switch (self.index) {
        case 0:
            [self animateFirst];
            break;
        case 1:
            [self animateSecond];
            break;
        case 2:
            [self animateThird];
            break;
        default:
            break;
    }
}
-(void)animateFirst{
    [UIView animateKeyframesWithDuration:1 delay:0.2 options:UIViewKeyframeAnimationOptionCalculationModeLinear animations:^{
        [UIView addKeyframeWithRelativeStartTime:0 relativeDuration:0.8 animations:^{
            self.fontView1.alpha = 1;
            self.fontView1.transform = CGAffineTransformIdentity;
        }];
        [UIView addKeyframeWithRelativeStartTime:0.2 relativeDuration:0.8 animations:^{
            self.fontView2.alpha = 1;
            self.fontView2.transform= CGAffineTransformIdentity;
        }];
        [UIView addKeyframeWithRelativeStartTime:0.7 relativeDuration:0.3 animations:^{
            self.fontView3.alpha = 1;
        }];
    } completion:^(BOOL finished) {
    }];
}
-(void)animateSecond{

    [UIView animateKeyframesWithDuration:1 delay:0 options:UIViewKeyframeAnimationOptionCalculationModeLinear animations:^{
        [UIView addKeyframeWithRelativeStartTime:0 relativeDuration:0.8 animations:^{
            self.fontView1.alpha = 1;
            self.fontView1.transform = CGAffineTransformIdentity;
        }];
        [UIView addKeyframeWithRelativeStartTime:0.2 relativeDuration:0.8 animations:^{
            self.fontView2.alpha = 1;
            self.fontView2.transform= CGAffineTransformIdentity;
        }];
        [UIView addKeyframeWithRelativeStartTime:0.7 relativeDuration:0.3 animations:^{
            self.fontView3.alpha = 1;
        }];
    } completion:^(BOOL finished) {
    }];
}
-(void)animateThird{

    [UIView animateKeyframesWithDuration:1 delay:0 options:UIViewKeyframeAnimationOptionCalculationModeLinear animations:^{
        [UIView addKeyframeWithRelativeStartTime:0 relativeDuration:0.8 animations:^{
            self.fontView1.alpha = 1;
            self.fontView1.transform = CGAffineTransformIdentity;
        }];
        [UIView addKeyframeWithRelativeStartTime:0.2 relativeDuration:0.8 animations:^{
            self.fontView2.alpha = 1;
            self.fontView2.transform= CGAffineTransformIdentity;
        }];
        [UIView addKeyframeWithRelativeStartTime:0.7 relativeDuration:0.3 animations:^{
            self.fontView3.alpha = 1;
            self.button.alpha = 1;
        }];
    } completion:^(BOOL finished) {
    }];
}
-(void)setupAinmate{
    switch (self.index) {
        case 0:
            self.fontView1.alpha = 0;
            self.fontView1.transform  = CGAffineTransformMakeTranslation(-100, 0);
            self.fontView2.alpha = 0;
            self.fontView2.transform  = CGAffineTransformMakeTranslation(-100, 0);
            self.fontView3.alpha = 0;
            break;
        case 1:
            self.fontView1.alpha = 0;
            self.fontView1.transform  = CGAffineTransformMakeTranslation(0, -50);
            self.fontView2.alpha = 0;
            self.fontView2.transform  = CGAffineTransformMakeTranslation(0, -50);
            self.fontView3.alpha = 0;
            break;
        case 2:
            self.fontView1.alpha = 0;
            self.fontView2.alpha = 0;
            self.fontView3.alpha = 0;
            self.button.alpha= 0;
            break;
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - 初始化
-(UIButton *)button{
    if (!_button) {
        _button = [UIButton buttonWithType:UIButtonTypeSystem];
        _button.frame = CGRectMake(0, 0, 180, 45);
        _button.center = CGPointMake(self.view.centerX, self.view.height - 80);
        _button.layer.borderColor = COLOR_NAV_RED.CGColor;
        _button.layer.borderWidth = 1.5;
        _button.titleLabel.font = [UIFont systemFontOfSize:22];
        [_button setTitleColor:COLOR_NAV_RED forState:UIControlStateNormal];
        [_button setTitle:@"立即体验" forState:UIControlStateNormal];
        [_button addTarget:self action:@selector(imageClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _button;
}


@end
