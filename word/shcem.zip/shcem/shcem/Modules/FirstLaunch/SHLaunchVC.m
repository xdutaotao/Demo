//
//  SHLaunchVC.m
//  shcem
//
//  Created by huangdeyu on 2017/1/5.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "SHLaunchVC.h"
#import "SHLaunchContentVC.h"

@interface SHLaunchVC ()<UIPageViewControllerDelegate,UIPageViewControllerDataSource>
@property(nonatomic,strong)UIPageViewController * subPageVC;
@property(nonatomic,copy) NSArray<SHLaunchContentVC *> * vcs;
@property(nonatomic,strong) UIPageControl * pageControl;
@property(nonatomic,assign) NSInteger currentPage;
@end

@implementation SHLaunchVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self addChildViewController:self.subPageVC];
    [self.view addSubview:self.subPageVC.view];
    [self.view addSubview:self.pageControl];
    [self.subPageVC didMoveToParentViewController:self];
    [self addViews];
}

-(void)addViews{
    NSMutableArray * arr = [NSMutableArray array];
    for (int i = 0; i < 3; i++) {
        SHLaunchContentVC * vc = [[SHLaunchContentVC alloc] initWithIndex:i];
        [arr addObject:vc];
        WS(weakSelf)
        vc.block = ^(NSInteger index){
            [weakSelf.pageControl setCurrentPage:index];
        };
    }
    self.vcs = [arr mutableCopy];;
    [self.subPageVC setViewControllers:@[self.vcs[0]] direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
}
#pragma mark - delegate
// Sent when a gesture-initiated transition begins.
- (void)pageViewController:(UIPageViewController *)pageViewController willTransitionToViewControllers:(NSArray<UIViewController *> *)pendingViewControllers NS_AVAILABLE_IOS(6_0){
}
// Sent when a gesture-initiated transition ends. The 'finished' parameter indicates whether the animation finished, while the 'completed' parameter indicates whether the transition completed or bailed out (if the user let go early).
- (void)pageViewController:(UIPageViewController *)pageViewController didFinishAnimating:(BOOL)finished previousViewControllers:(NSArray<UIViewController *> *)previousViewControllers transitionCompleted:(BOOL)completed{

}
- (nullable UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController{
    UIViewController * vc = nil;
    for (int i = 0; i < 3; i++) {
        if ([self.vcs[i] isEqual:viewController]) {
            if (i == 0) {
                return vc;
            }else{
                vc = self.vcs[i-1];
            }
        }
    }
    return vc;
}
- (nullable UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController{
    UIViewController * vc = nil;
    for (int i = 0; i < 3; i++) {
        if ([self.vcs[i] isEqual:viewController]) {
            if (i == 2) {
                return vc;
            }else{
                vc = self.vcs[i+1];
            }
        }
    }
    return vc;
}

#pragma mark - 初始化
-(UIPageViewController *)subPageVC{
    if (!_subPageVC) {
        _subPageVC = [[UIPageViewController alloc] initWithTransitionStyle:UIPageViewControllerTransitionStyleScroll navigationOrientation:UIPageViewControllerNavigationOrientationHorizontal options:nil];
        _subPageVC.view.frame = self.view.bounds;
        _subPageVC.delegate = self;
        _subPageVC.dataSource = self;
    }
    return  _subPageVC;
}
-(UIPageControl *)pageControl{
    if (!_pageControl) {
        _pageControl = [[UIPageControl alloc] init];
        _pageControl.numberOfPages = 3;
        _pageControl.currentPage = 0;
        _pageControl.pageIndicatorTintColor = COLOR_NAV_RED;
        _pageControl.center = CGPointMake(self.view.centerX, self.view.height - 30);
    }
    return _pageControl;
}
@end
