//
//  SHLoginVC.h
//  Frey
//
//  Created by huangdeyu on 16/4/1.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHLoginVC : SHBaseViewController
-(instancetype)initWithEntryClass:(NSString *)className;
@property (nonatomic, assign) BOOL isBackMine;
@end
