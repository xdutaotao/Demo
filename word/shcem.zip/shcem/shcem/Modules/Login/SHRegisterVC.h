//
//  SHRegisterVC.h
//  Frey
//
//  Created by huangdeyu on 16/4/1.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHBaseViewController.h"
@interface SHRegisterVC : SHBaseViewController
-(instancetype)initWithEntryClassName:(NSString *)name  andType:(NSInteger)type;
@end
