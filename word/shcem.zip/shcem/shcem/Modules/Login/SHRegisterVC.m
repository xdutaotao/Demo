//
//  SHRegisterVC.m
//  Frey
//
//  Created by huangdeyu on 16/4/1.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import "SHRegisterVC.h"
#import "SHLoginCell.h"
#import "SHRegisterCell.h"
#import "SHLoginService.h"

@interface SHRegisterVC ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong) NSArray * imgs;
@property(nonatomic,strong) NSArray * placeHolders;
@property(nonatomic,strong) NSArray * keyboardType;
@property(nonatomic,strong) NSArray * securyType;

@property(nonatomic,copy) NSString * phoneNum;
@property(nonatomic,copy) NSString * verifyCode;
@property(nonatomic,copy) NSString * sms;
@property(nonatomic,copy) NSString *userName;
@property(nonatomic,copy) NSString * pwd;
@property(nonatomic,copy) NSString * verifyPwd;
@end

@implementation SHRegisterVC
-(instancetype)initWithEntryClassName:(NSString *)name andType:(NSInteger)type{
    if (self = [super init]) {
    }
    return self;
}
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.hidesBottomBarWhenPushed  = YES;
        self.title = @"注册";
        self.imgs = @[@"registerPhone",@"",@"registerMail",@"loginUserlogo",@"loginPwdLogo",@"loginVerifyPwd"];
        self.placeHolders = @[@"请输入需要注册的手机号",STR_MINE_INPUT_CODE,@"邮箱(可选)",@"用户名",@"密码",@"确认密码"];
        self.keyboardType = @[@(UIKeyboardTypeNumberPad),@(UIKeyboardTypeNumberPad),@(UIKeyboardTypeASCIICapable),@(UIKeyboardTypeASCIICapable),@(UIKeyboardTypeASCIICapable),@(UIKeyboardTypeASCIICapable)];
        self.securyType = @[@NO,@NO,@NO,@NO,@YES,@YES];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.tableView];
    UITapGestureRecognizer * gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
    [self.view addGestureRecognizer:gesture];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textfieldDidEditing:) name:UITextFieldTextDidChangeNotification object:nil];
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark -通知中心
-(void)textfieldDidEditing:(NSNotification *)notification{
    UITextField * textField = notification.object;
    DLog(@"当前编辑的文本tag是%ld",(long)textField.tag);
    switch (textField.tag) {
        case 0:
            if(textField.text.length > 11){
                textField.text = [textField.text substringToIndex:11];
            }
            self.phoneNum = textField.text;
            break;
        case 1:
            if (textField.text.length > 6) {
                textField.text = [textField.text substringToIndex:6];
            }
            self.verifyCode = textField.text;
            break;
        case 2:
            self.sms = textField.text;
            break;
        case 3:
            self.userName = textField.text;
            break;
        case 4:
            self.pwd = textField.text;
            break;
        case 5:
            self.verifyPwd = textField.text;
            break;
        default:
            break;
    }
}
-(BOOL)verifyInput{
    if (self.phoneNum.length < 11) {
        [self toast:STR_MINE_TOAST_TELEPHONE];
        return NO;
    }
    if (self.verifyCode.length < 6) {
        [self toast:STR_MINE_TOAST_CODE_FAILURE];
        return NO;
    }
    if (self.sms.length > 0 && ![self.sms isEmail]) {
        [self toast:@"请输入正确的邮箱账号"];
        return NO;
    }
    if (self.userName.length == 0) {
        [self toast:@"用户名不能为空"];
        return NO;
    }
    if (self.pwd.length < 6) {
        [self toast:STR_MINE_TOAST_PASSWORD_LOGIN];
        return NO;
    }
    if (![self.verifyPwd isEqualToString:self.pwd]) {
        [self toast:STR_MINE_TOAST_AGAIN_PASSWORD_WRONG];
        return NO;
    }
    
    return YES;
}


#pragma mark - tableView delegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 6;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row != 1) {
        SHLoginCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        [cell loadWithLogo:self.imgs[indexPath.row] placeHolder:self.placeHolders[indexPath.row] andTextfieldTag:indexPath.row keyboardType:[self.keyboardType[indexPath.row] integerValue] secure:[self.securyType[indexPath.row] integerValue]];
        return cell;
    }
    SHRegisterCell * registerCell = [tableView dequeueReusableCellWithIdentifier:@"cell1"];
    [registerCell setPlaceHolder:STR_MINE_INPUT_CODE andTag:indexPath.row];
    [registerCell setSelectionStyle:UITableViewCellSelectionStyleNone];
    [registerCell.button addTarget:self action:@selector(getCodeClicked:) forControlEvents:UIControlEventTouchUpInside];
    return registerCell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 10;
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    [self.view endEditing:YES];
}
#pragma mark - action
-(void)submitClicked:(UIButton *)btn{
    DLog(@"提交按钮点击");
    if ([self verifyInput]) {
        WS(weakSelf)
        if (!self.sms) {
            self.sms = @"";
        }
        [self showProgress];
        [SHLoginService registerWithCode:@[self.phoneNum,self.verifyCode,self.pwd,self.userName,self.sms] callback:^(NSError *err, NSDictionary *dic) {
            [self hideProgress];
            if (err) {
                NSString * str = err.localizedDescription;
                if ([str isEqualToString:STR_MINE_CHECK_FAILURE]) {
                    str = STR_MINE_TOAST_CODE_FAILURE;
                }
                [weakSelf toast:str];
                return;
            }
            [weakSelf toast:@"注册成功"];
            [weakSelf runAfterSecs:0.5 block:^{
                [weakSelf.navigationController popViewControllerAnimated:YES];
            }];
        }];
    }
}
-(void)getCodeClicked:(UIButton *)btn{
    if(![self.phoneNum isPhoneNumber]){
        [self toast:STR_MINE_TOAST_TELEPHONE];
        return;
    }
    SHRegisterCell *cell = (SHRegisterCell *) btn.superview;
    [self showProgress];
    [SHLoginService checkExistMobile:@[self.phoneNum] callback:^(NSError *err, NSDictionary *dic) {
        if (err) {//证明没有被注册过，才能注册
            [SHLoginService getRegisterCode:@[self.phoneNum] callback:^(NSError *e, NSDictionary *dic) {
                [self hideProgress];
                if (e) {
                    [self showError:e];
                    [cell stopTimer];
                    return;
                }
                [self toast:STR_MINE_TOAST_CODE_SEND];
                [cell startTimer];
            }];
        }else{
            [self hideProgress];
           // [self showError:err];
            [self toast:[NSString stringWithFormat:@"此账号已在%@注册，可直接登录",dic] duration:2];
        }
    }];
    
}
-(void)tapAction:(UITapGestureRecognizer *)gesture{
    [self.view endEditing:YES];
}

#pragma mark - 初始化

-(UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds];
        [_tableView registerClass:[SHLoginCell class] forCellReuseIdentifier:@"cell"];
        [_tableView registerClass:[SHRegisterCell class] forCellReuseIdentifier:@"cell1"];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.showsVerticalScrollIndicator = NO;
        
        UIView * footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 1, ScreenWidth, 80)];
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setTitle:STR_MINE_BUTTON_COMMIT forState:UIControlStateNormal];
        UIImage * img = [UIImage imageWithColor:COLOR_NAV_RED];
        [btn setBackgroundImage:img forState:UIControlStateNormal];
        btn.layer.cornerRadius = 5.0;
        btn.layer.masksToBounds = YES;
        btn.frame = CGRectMake(0, 0, ScreenWidth - 30, 40);
        btn.center = footerView.center;
        [btn addTarget:self action:@selector(submitClicked:) forControlEvents:UIControlEventTouchUpInside];
        [footerView addSubview:btn];
        _tableView.tableFooterView = footerView;
    }
    return _tableView;
}


@end
