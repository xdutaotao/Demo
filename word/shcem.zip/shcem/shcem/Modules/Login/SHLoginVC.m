//
//  SHLoginVC.m
//  Frey
//
//  Created by huangdeyu on 16/4/1.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import "SHLoginVC.h"
#import "SHLoginHeaderView.h"
#import "SHLoginFooterView.h"
#import "SHLoginCell.h"
#import "MJExtension.h"
#import "SHRegisterVC.h"
#import "SHLoginSectionView.h"
#import "SHLoginService.h"
#import "SHUserManager.h"
#import "SHRegisterCell.h"
#import "SHChangePwdVC.h"
#import "SHHomeWebVC.h"
#import "SHMineVC.h"

@interface SHLoginVC ()<UITableViewDataSource,UITableViewDelegate,SHLoginFooterProtocol,SHLoginSectionViewDelegate>
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong) SHLoginHeaderView * headerView;
@property(nonatomic,strong) SHLoginFooterView * footView;
@property(nonatomic,strong) SHLoginSectionView * sectionView;
@property(nonatomic,copy) NSString * entryClassName;


@property(nonatomic,copy) NSString * userName;
@property(nonatomic,copy) NSString * password;
@property(nonatomic,copy) NSString * verifyCode;

@property(nonatomic,assign) BOOL loginStatus;    // 0：表示用户名密码登陆  1：验证码登陆
@end

@implementation SHLoginVC
-(instancetype)initWithEntryClass:(NSString *)className{
    if (self = [super init]) {
        self.hidesBottomBarWhenPushed = YES;
        self.entryClassName = className;
        _loginStatus = NO;
        self.isBackMine = NO;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.tableView];
    self.tableView.tableHeaderView = self.headerView;
    self.tableView.tableFooterView = self.footView;
    UITapGestureRecognizer * gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapOn:)];
    [self.view addGestureRecognizer:gesture];
    self.title = @"会员登录";
    [self removeOtherController];
}
-(void)removeOtherController{
    NSMutableArray * array = [self.navigationController.viewControllers mutableCopy];
    for (NSInteger i = array.count - 2; i>=0; i--) {
        NSString * str = NSStringFromClass([array[i] class]);
        if(![str isEqualToString:self.entryClassName]){
            [array removeObject:array[i]];
        }else{
            break;
        }
    }
    [self.navigationController setViewControllers:array];
}
#pragma mark - viewAppear&viewDissappear
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textFieldChanged:) name:UITextFieldTextDidChangeNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textBeginEdited:) name:UITextFieldTextDidBeginEditingNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textEndEdited:) name:UITextFieldTextDidEndEditingNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
-(void)tapOn:(UIGestureRecognizer *)gesture{
    [self.view endEditing:YES];
}

#pragma mark - 接口
-(void)login{
    if (![self.userName isPhoneNumber]) {
        [self toast:STR_MINE_TOAST_TELEPHONE];
        return;
    }
    if (!self.loginStatus) {   //用户名密码登陆
        if(self.password.length < 6){
            [self toast:STR_MINE_TOAST_PASSWORD_LOGIN];
            return;
        }
        [self showProgress];
        [SHLoginService checkExistMobile:@[self.userName] callback:^(NSError *err, NSDictionary *dic) {
            if (err) {
                [self hideProgress];
                [self showError:err];
            }else{
                [SHLoginService loginWithPara:@[self.userName,self.password] callback:^(NSError *err, SHTokenModel *token) {
                    [self hideProgress];
                    [self dealWithResponseWithToken:token error:err];
                }];
            }
        }];

    }else{
        if (self.verifyCode.length < 6) {
            [self toast:STR_MINE_CODE_TOAST];
            return;
        }
        [self showProgress];
        [SHLoginService verifyCode:@[self.userName,self.verifyCode] callback:^(NSError *err, NSDictionary *dic) {
            if (err) {
                [self hideProgress];
                NSString * str = err.localizedDescription;
                if ([str isEqualToString:STR_MINE_CHECK_FAILURE]) {
                    str = STR_MINE_TOAST_CODE_FAILURE;
                }
                [self toast:str];
                return;
            }
            DLog(@"验证成功的内容是%@",dic);
            [SHLoginService loginWithCode:@[self.userName] callback:^(NSError *err, SHTokenModel *token) {
                [self hideProgress];
                [self dealWithResponseWithToken:token error:err];
            }];
        }];
    }
}
-(void)dealWithResponseWithToken:(SHTokenModel *)token error:(NSError *) err{
    if (err) {
        [self showError:err];
        return;
    }
    [self toast:STR_MINE_TOAST_LOGIN_SUCCESS];
    [[SHUserManager sharedManager] loginWithToken:token.token];
    if(self.isBackMine == YES){
        [self runAfterSecs:1.0 block:^{
            SHMineVC *mineVC = [[SHMineVC alloc] init];
            [self.navigationController popToViewController:mineVC animated:YES];
        }];
    } else {
        [self runAfterSecs:1.0 block:^{
            [self.navigationController popViewControllerAnimated:YES];
        }];
    }
    DLog(@"登陆成功,当前token是%@",token.token);
}

#pragma mark - 文本框监听
-(void)textFieldChanged:(NSNotification *)notification{
    UITextField * textField = notification.object;
    switch (textField.tag) {
        case 0:{
            DLog(@"监听手机号");
            if (textField.text.length > 11) {
                textField.text = [textField.text substringToIndex:11];
            }
            self.userName = textField.text;
        }
            break;
        case 1:
            self.password = textField.text;
            DLog(@"监听密码");
            break;
        case 2:
            if (textField.text.length > 6) {
                textField.text = [textField.text substringToIndex:6];
            }
            self.verifyCode = textField.text;
            DLog(@"%@",textField.text);
            break;
        default:
            break;
    }
}

-(void)textBeginEdited:(NSNotification *)notification{
    //UITextField * textField = notification.object;
    [self.headerView changeToSmall];
    DLog(@"当前的偏移量是%@",  NSStringFromCGPoint(self.tableView.contentOffset));
    [self.tableView setContentOffset:CGPointMake(0, 20) animated:YES];
  //  [self.navigationController setNavigationBarHidden:YES animated:YES];
    DLog(@"开始编辑");
}
-(void)textEndEdited:(NSNotification *)notiication{
    [self.headerView changeToBig];
    [self.tableView setContentOffset:CGPointMake(0, -64) animated:YES];
//    [self.navigationController setNavigationBarHidden:NO animated:YES];
}
#pragma mark - tableView delegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 2;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == 0) {
        SHLoginCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [cell loadWithType:indexPath.row];
        return cell;
    }
    if (!self.loginStatus) {
        SHLoginCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [cell loadWithType:indexPath.row];
        return cell;
    }
    SHRegisterCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell1"];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    [cell.button addTarget:self action:@selector(getCodeClicked:) forControlEvents:UIControlEventTouchUpInside];
    [cell setPlaceHolder:STR_MINE_INPUT_CODE andTag:2];
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPathP{
    return 50;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 40;
}
-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    return self.sectionView;
}
#pragma mark - 获取验证码
-(void)getCodeClicked:(UIButton *)btn{
    if (![self.userName isPhoneNumber]) {
        [self toast:STR_MINE_TOAST_TELEPHONE];
        return;
    }
    SHRegisterCell *cell = (SHRegisterCell *) btn.superview;
    [self showProgress];
    [SHLoginService checkExistMobile:@[self.userName] callback:^(NSError *err, NSDictionary *dic) {
        if (err) {
            [self hideProgress];
            [self showError:err];
        }else{
            [SHLoginService getLoginCocd:@[self.userName] callback:^(NSError *err, NSDictionary *dic) {
                [self hideProgress];
                [cell startTimer];
                if (err) {
                    [self showError:err];
                    [cell stopTimer];
                    return;
                }
                if (dic) {
                    DLog(@"获取验证码的返回是%@",dic);
                }
                [self toast:STR_MINE_TOAST_SEND_CODE];
            }];
        }
    }];
}
#pragma mark - 登录注册点击
-(void)loginOrRegisterClicked:(UIButton *)button{
    [self.view endEditing:YES];
    if (button.tag == 0) {
        [self login];
        return;
    }
    SHRegisterVC * vc = [[SHRegisterVC alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}
-(void)protocolClicked{
    SHHomeWebVC * vc = [[SHHomeWebVC alloc] initWithUrl:[WEBREQUESTURL stringByAppendingString:URL_FUWU_TIAOKUAN] title:@"隐私条款" imageName:@"share_blank"];
    [self.navigationController pushViewController:vc animated:YES];
}
#pragma mark - 忘记密码点击
-(void)sectionbtnsClicked:(UIButton *)btn{
    [self.view endEditing:YES];
    NSInteger tag = btn.tag;
    if (tag == 0) {
        SHChangePwdVC * vc = [[SHChangePwdVC alloc] initWithType:0];
        vc.title = @"忘记密码";
        [self.navigationController  pushViewController:vc animated:YES];
    }else{
        self.loginStatus = !self.loginStatus;
        if (self.loginStatus) {
            [btn setTitle:@"用户名登录" forState:UIControlStateNormal];
        }else{
             [btn setTitle:@"验证码登录" forState:UIControlStateNormal];
        }
    }
}

#pragma mark - setter
-(void)setLoginStatus:(BOOL)loginStatus{
    _loginStatus = loginStatus;
    NSIndexPath * indexPath = [NSIndexPath indexPathForRow:1 inSection:0];
    [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
}

#pragma mark - 初始化
-(UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
        [_tableView registerClass:[SHLoginCell class] forCellReuseIdentifier:@"cell"];
        [_tableView registerClass:[SHRegisterCell class] forCellReuseIdentifier:@"cell1"];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.scrollEnabled = NO;

    }
    return _tableView;
}
-(SHLoginHeaderView *)headerView{
    if (!_headerView) {
        _headerView = [[SHLoginHeaderView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenWidth * .5 - 40)];
    }
    return _headerView;
}
-(SHLoginFooterView *)footView{
    if (!_footView) {
        _footView = [[SHLoginFooterView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 200)];
        _footView.delegate = self;
    }
    return _footView;
}
-(SHLoginSectionView *)sectionView{
    if (!_sectionView) {
        _sectionView = [[SHLoginSectionView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 30)];
        _sectionView.delegate = self;
    }
    return _sectionView;
}

@end
