//
//  SHInfoVC.h
//  shcem
//
//  Created by huangdeyu on 2016/11/21.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHWebView.h"

@interface SHInfoVC : SHBaseViewController

@property (nonatomic, copy) SHWebView *infoWebView;
@property(nonatomic,strong) NSString *infoID;

@end
