//
//  SHInfoVC.m
//  shcem
//
//  Created by huangdeyu on 2016/11/21.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHInfoVC.h"
#import "SHHomeWebVC.h"

@interface SHInfoVC ()<SHWebViewDelegate>

@property(nonatomic, strong) UISearchBar *searchBar;
@property (nonatomic, copy) NSString *infoHomeUrlStr;
@property (nonatomic, assign) BOOL isFirst;




@end

@implementation SHInfoVC

- (instancetype)init
{
    self = [super init];
    if (self) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveAction:) name:@"INFO_TITLE" object:nil];
        self.isFirst = YES;
    }
    return self;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"search"] style:UIBarButtonItemStylePlain target:self action:@selector(infoSearch)];
    
    [self.view addSubview:self.infoWebView];
    
    
    
}
- (void)receiveAction:(id)sender{
    self.infoHomeUrlStr = [NSString stringWithFormat:@"%@", [sender valueForKey:@"object"]];
    if(self.isFirst == YES) {
    } else {
        [self.infoWebView refreshWebViewWithUrl:[sender valueForKey:@"object"]];
    }
}

- (void)infoSearch{
    DLog(@"搜索");
}

-(void)setInfoID:(NSString *) infoID{
    _infoID=infoID;
}

#pragma mark - webviewDelegate
- (void)webViewLoadUrl:(NSString *)url{
    DLog(@"资讯中的url：%@", url);

    if([url isEqualToString:[WEBREQUESTURL stringByAppendingString:WEBINFOURL]]){
        
    }
    else if([[url componentsSeparatedByString:@"?"][0] isEqualToString:[WEBREQUESTURL stringByAppendingString:WEBINFODETAILURL]]){
        DLog(@"跳入到资讯详情页");
        [self.infoWebView.webView stopLoading];
        NSString *strUrl = [URL_INFO_DETAIL stringByAppendingString:[url componentsSeparatedByString:@"="][1]];
        SHHomeWebVC *webVC = [[SHHomeWebVC alloc] initWithUrl:strUrl title:@"资讯详情" imageName:@"share_blank"];
        [self.navigationController pushViewController:webVC animated:YES];
    }
    else if ([[url componentsSeparatedByString:@"?"][0] isEqualToString:[WEBREQUESTURL stringByAppendingString:WEBKCHARTDETAILURL]]){
        [self.infoWebView.webView stopLoading];
        SHHomeWebVC *webVC = [[SHHomeWebVC alloc] initWithUrl:url title:@"走势详情" imageName:@"phone"];
        [self.navigationController pushViewController:webVC animated:YES];
    }
}
- (void)webViewStartLoad{
    [self.infoWebView.progressView startLoading];
    [self showNetworkIndicator];
}
- (void)webViewFinishLoad{
    [self.infoWebView.progressView endLoading];
    [self hideNetworkIndicator];
   // [self.infoWebView.delegate webViewLoadUrl:@"https://appnative.uat.shcem.com/info_detail.html?ID=15532"];

}
- (void)webViewFailLoad{
//    [self.infoWebView.failView showInView:self.infoWebView withType:0 tips:@"加载失败"];
    [self.infoWebView.progressView endLoading];
    [self hideNetworkIndicator];
}

#pragma mark - 初始化
- (SHWebView *)infoWebView{
    if(!_infoWebView){
        NSString *urlStr;
        if(self.infoHomeUrlStr){
            urlStr = self.infoHomeUrlStr;
        } else {
            urlStr = [WEBREQUESTURL stringByAppendingString:WEBINFOURL];
        }
        self.isFirst = NO;
        _infoWebView = [[SHWebView alloc] initWithFrame:self.view.bounds url:urlStr refresh:NO height:YES];
        _infoWebView.delegate = self;
        _infoWebView.webView.scrollView.scrollEnabled = YES;
    }
    return _infoWebView;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}



@end
