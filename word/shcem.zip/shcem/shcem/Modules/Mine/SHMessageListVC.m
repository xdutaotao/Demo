//
//  SHMessageListVC.m
//  shcem
//
//  Created by huangdeyu on 2016/12/14.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHMessageListVC.h"
#import "SHMsgListCell.h"
#import "SHLoginService.h"
#import "SHRefreshHeader.h"
#import "SHBaseTableView.h"
@interface SHMessageListVC ()<UITableViewDelegate,UITableViewDataSource,SHBaseTableViewDelegate>
@property(nonatomic,strong) SHBaseTableView * tableView;
@property(nonatomic,strong) NSMutableArray * list;
//@property(nonatomic,assign) NSInteger pageIndex;
@end

@implementation SHMessageListVC
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.hidesBottomBarWhenPushed  = YES;
        self.list = [NSMutableArray array];
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"消息中心";
    [self.view addSubview:self.tableView];
    [self.tableView.mj_header beginRefreshing];
    [[SHUserManager sharedManager] clearUnReadCount];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


#pragma mark - tableView delegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.list.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    SHMsgListCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    NSDictionary * dic = self.list[indexPath.row];
    NSString * msg = dic[@"messageContent"];
    NSString * datestr = dic[@"recModifytime"];
    if (datestr.length > 10) {
        datestr = [datestr substringToIndex:(datestr.length - 2)];
    }
    [cell loadData:msg dateStr:datestr];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 120;
}
-(void)loadDataWithPage:(NSInteger)page{
    SHUserModel * userInfo = [[SHUserManager sharedManager] getUserInfoDirect];
    SHQueryCondition *condition =    [SHQueryCondition defaultConditionWithService:B_UNREAD_MSG_SERVICE method:B_MSG_METHOD parKeys:B_MSG_KEYS parValues:@[@(page),@15,@{@"ReceiveNumber":userInfo.Mobile,@"IsSend":@1}] defaultPars:B_MSG_DEFAULT];
    WS(weakSelf)
    [self.tableView getListWithPage:page condition:condition pageSize:15 successCallback:^(id objects) {
        [weakSelf.list addObjectsFromArray:objects];
        [weakSelf.tableView reloadData];
    }];
}
#pragma mark - 初始化

-(SHBaseTableView *)tableView{
    if (!_tableView) {
        _tableView = [[SHBaseTableView alloc] initWithSource:self models:self.list frame:self.view.bounds];
        [_tableView registerClass:[SHMsgListCell class] forCellReuseIdentifier:@"cell"];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _tableView;
}


@end
