//
//  SHChangePaymentPwdVC.m
//  shcem
//
//  Created by huangdeyu on 2016/12/15.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHChangePaymentPwdVC.h"
#import "SHLoginCell.h"
#import "SHRegisterCell.h"
#import "SHLoginService.h"

@interface SHChangePaymentPwdVC ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong) NSArray * imgs;
@property(nonatomic,strong) NSArray * placeHolders;
@property(nonatomic,strong) NSArray * keyboardType;
@property(nonatomic,strong) NSArray * secureTypel;

@property(nonatomic,copy) NSString * phoneNum;
@property(nonatomic,copy) NSString * verifyCode;
@property(nonatomic,copy) NSString * pwd;
@property(nonatomic,copy) NSString * verifyPwd;
@end

@implementation SHChangePaymentPwdVC


- (instancetype)init
{
    self = [super init];
    if (self) {
        self.hidesBottomBarWhenPushed  = YES;
        self.title = @"修改支付密码";
        self.imgs = @[@"loginUserlogo",@"",@"loginPwdLogo",@"loginVerifyPwd"];
        self.placeHolders = @[@"",STR_MINE_INPUT_CODE,STR_MINE_TOAST_PASSWORD_PAY,STR_MINE_INPUT_AGAIN_PASSWORD];
        self.keyboardType = @[@(UIKeyboardTypeNumberPad),@(UIKeyboardTypeNumberPad),@(UIKeyboardTypeNumberPad),@(UIKeyboardTypeNumberPad)];
        self.secureTypel = @[@NO,@NO,@YES,@YES];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.tableView];
    UITapGestureRecognizer * gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
    [self.view addGestureRecognizer:gesture];
    self.phoneNum = [[SHUserManager   sharedManager] getUserInfoDirect].Mobile;
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textfieldDidEditing:) name:UITextFieldTextDidChangeNotification object:nil];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark -通知中心
-(void)textfieldDidEditing:(NSNotification *)notification{
    UITextField * textField = notification.object;
    DLog(@"当前编辑的文本tag是%ld",(long)textField.tag);
    switch (textField.tag) {
        case 0:
            if(textField.text.length > 11){
                textField.text = [textField.text substringToIndex:11];
            }
            self.phoneNum = textField.text;
            break;
        case 1:
            if (textField.text.length > 6) {
                textField.text = [textField.text substringToIndex:6];
            }
            self.verifyCode = textField.text;
            break;
        case 2:
            if(textField.text.length > 6){
                textField.text = [textField.text substringToIndex:6];
            }
            self.pwd = textField.text;
            break;
        case 3:
            if(textField.text.length > 6){
                textField.text = [textField.text substringToIndex:6];
            }
            self.verifyPwd = textField.text;
            break;
        default:
            break;
    }
}
-(BOOL)verifyInput{
    if (self.phoneNum.length < 11) {
        [self toast:STR_MINE_TOAST_TELEPHONE];
        return NO;
    }
    if (self.verifyCode.length < 6) {
        [self toast:STR_MINE_TOAST_CODE_FAILURE];
        return NO;
    }
    if (self.pwd.length < 6) {
        [self toast:STR_MINE_TOAST_PASSWORD_PAY];
        return NO;
    }
    if (![self.verifyPwd isEqualToString:self.pwd]) {
        [self toast:STR_MINE_TOAST_AGAIN_PASSWORD_WRONG];
        return NO;
    }
    
    return YES;
}


#pragma mark - tableView delegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 4;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row != 1) {
        SHLoginCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        [cell loadWithLogo:self.imgs[indexPath.row] placeHolder:self.placeHolders[indexPath.row] andTextfieldTag:indexPath.row keyboardType:[self.keyboardType[indexPath.row] integerValue] secure:[self.secureTypel[indexPath.row] integerValue]];
        return cell;
    }
    SHRegisterCell * registerCell = [tableView dequeueReusableCellWithIdentifier:@"cell1"];
    [registerCell setPlaceHolder:STR_MINE_INPUT_CODE andTag:indexPath.row];
    [registerCell setSelectionStyle:UITableViewCellSelectionStyleNone];
    [registerCell.button addTarget:self action:@selector(getCodeClicked:) forControlEvents:UIControlEventTouchUpInside];
    return registerCell;
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    [self.view endEditing:YES];
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 10;
}
#pragma mark - action
-(void)submitClicked:(UIButton *)btn{
    if ([self verifyInput]) {
        [self showProgress];
        [SHLoginService resetPaymentPwd:@[self.phoneNum,self.verifyCode,self.pwd] callback:^(NSError *err, NSDictionary *dic) {
            [self hideProgress];
            if (err) {
          //      [self showError:err];
                NSString * str = err.localizedDescription;
                if ([str isEqualToString:STR_MINE_CHECK_FAILURE]) {
                    str = STR_MINE_TOAST_CODE_FAILURE;
                }
                [self toast:str];
                return;
            }
            [self toast:@"重置支付密码成功"];
            [self runAfterSecs:0.5 block:^{
                [self.navigationController popViewControllerAnimated:YES];
            }];
        }];
    }
    DLog(@"提交按钮点击");
}
-(void)getCodeClicked:(UIButton *)btn{
    if(![self.phoneNum isPhoneNumber]){
        [self toast:STR_MINE_TOAST_TELEPHONE];
        return;
    }
    SHRegisterCell *cell = (SHRegisterCell *) btn.superview;
    [self showProgress];
//    [SHLoginService checkExistMobile:@[self.phoneNum] callback:^(NSError *err, NSDictionary *dic) {
//        if (err) {
//            [self hideProgress];
//            [self showError:err];
//        }else{
            [SHLoginService getResetPaymentPwd:@[self.phoneNum] callback:^(NSError *err, NSDictionary *dic) {
                [self hideProgress];
                [cell startTimer];
                if (err) {
                    [self showError:err];
                    [cell stopTimer];
                    return;
                }
                [self toast:STR_MINE_TOAST_CODE_SEND];
            }];
 //       }
//    }];
    
}
-(void)tapAction:(UITapGestureRecognizer *)gesture{
    [self.view endEditing:YES];
}

#pragma mark - 初始化

-(UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds];
        [_tableView registerClass:[SHLoginCell class] forCellReuseIdentifier:@"cell"];
        [_tableView registerClass:[SHRegisterCell class] forCellReuseIdentifier:@"cell1"];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.showsVerticalScrollIndicator = NO;
        
        UIView * footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 1, ScreenWidth, 80)];
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setTitle:STR_MINE_BUTTON_COMMIT forState:UIControlStateNormal];
        UIImage * img = [UIImage imageWithColor:COLOR_NAV_RED];
        [btn setBackgroundImage:img forState:UIControlStateNormal];
        btn.layer.cornerRadius = 5.0;
        btn.layer.masksToBounds = YES;
        btn.frame = CGRectMake(0, 0, ScreenWidth - 30, 45);
        btn.center = footerView.center;
        [btn addTarget:self action:@selector(submitClicked:) forControlEvents:UIControlEventTouchUpInside];
        [footerView addSubview:btn];
        _tableView.tableFooterView = footerView;
    }
    return _tableView;
}


@end
