//
//  SHMessageListVC.h
//  shcem
//
//  Created by huangdeyu on 2016/12/14.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHMessageListVC : SHBaseViewController

@end
