//
//  SHMineVC.m
//  shcem
//
//  Created by huangdeyu on 2016/11/21.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHMineVC.h"
#import "SHUserHeaderView.h"
#import "SHUserSection0Cell.h"
#import "SHUserSection1Cell.h"
#import "SHAppInfo.h"
#import "SHLoginVC.h"
#import "SHPhotoPicker.h"
#import "SHHomeWebVC.h"
#import "SHChangePwdVC.h"
#import "SHMessageListVC.h"
#import "SHSetPaymentPwdVC.h"
#import "SHChangePaymentPwdVC.h"
#import "SHHTTPManager.h"
#import "SHLoginService.h"
#import "NSString+Format.h"


@interface SHMineVC ()<UITableViewDelegate,UITableViewDataSource,SHUserHeaderViewDelegate,UIActionSheetDelegate>
@property(nonatomic,strong) UITableView * tableView;
@property(nonatomic,strong) SHUserHeaderView * tableHeaderView;
@property(nonatomic,strong) SHPhotoPicker * photoPicker;
@property(nonatomic,strong) NSArray * titles;
@property(nonatomic,strong) NSMutableArray * details;
@property(nonatomic,strong) NSArray * imgNames;
@property(nonatomic,strong) NSArray * types;

@property(nonatomic,copy) NSString * sellCount;
@property(nonatomic,copy) NSString * buyCount;
@end

@implementation SHMineVC

-(instancetype)init{
    if (self = [super init]) {
        self.titles = @[@"交易商",@"交易商编码",@"我的消息",@"修改密码",@"设置/修改支付密码",@"关于我们",@"联系客服",@"当前版本"];
        self.details = [@[@"-",@"-",@"您有0条未读消息",@"修改密码",@"支付密码设置/修改",@"关于上海化交",TELPHONE,[SHAppInfo appVersion]] mutableCopy] ;
        self.imgNames  = @[@"user_trader",@"user_trader_code",@"user_msg",@"user_pwd",@"user_pay_pwd",@"user_aboutus",@"user_contact",@"user_update"];
        self.types = @[@0,@0,@2,@2,@2,@2,@2,@1];
        self.sellCount = @"0";
        self.buyCount = @"0";
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.tableView];
    self.tableView.tableHeaderView = self.tableHeaderView;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateUserInfoNotification:) name:USER_INFO_UPDATED_NOTIFICATION object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateUnreadCount:) name:USER_UNREAD_COUNT_NOTIFICATION object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateTradeInfo:) name:USER_TRADE_INFO_NOTIFICATION object:nil];
    [[SHUserManager sharedManager] updateUserInfo];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}
-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
}
-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
#pragma mark - notification center
-(void)updateUserInfoNotification:(NSNotification *) notification{
    [self updateUI];
}
-(void)updateUnreadCount:(NSNotification *)notification{
    NSDictionary * dic = notification.object;
    NSMutableAttributedString * attStr = nil;
    if (dic) {
        attStr = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"您有%@条未读消息",dic[@"result"]]];
         [attStr setAttributes:@{NSForegroundColorAttributeName :[UIColor redColor]} range:NSMakeRange(2, attStr.length - 7)];
     //   self.details[2] = [NSString stringWithFormat:@"您有%@条未读消息",dic[@"result"]];
    }else{
        attStr =  [[NSMutableAttributedString alloc] initWithString:@"您有0条未读消息"];
        [attStr setAttributes:@{NSForegroundColorAttributeName :[UIColor redColor]} range:NSMakeRange(2, attStr.length - 7)];
    }
    self.details[2] = attStr;
     NSIndexPath * indexpath = [NSIndexPath indexPathForRow:2 inSection:1];
    [self.tableView reloadRowsAtIndexPaths:@[indexpath] withRowAnimation:UITableViewRowAnimationFade];
}
-(void)updateTradeInfo:(NSNotification *)notification{
    NSDictionary  * dic = notification.object;
    if (dic) {
        if ( [dic[@"direction"] integerValue] == 0) {//卖家
            self.sellCount = [NSString keepOneDecimalPlaces:dic[@"OrderWeight"]];
            if (!self.sellCount) {
                self.sellCount = @"0";
            }
        }else{
            self.buyCount = [NSString keepOneDecimalPlaces:dic[@"OrderWeight"]];
            if (!self.buyCount) {
                self.buyCount = @"0";
            }
        }
    }else{
        self.sellCount = @"0";
        self.buyCount = @"0";
    }
    [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationFade];

    DLog(@"更新交易信息：%@",notification.object);
}
#pragma mark - private methods
-(void)updateUI{
    NSString  * footName = STR_SHOW_CLICK_LOGIN;
    self.details[0] = @"-";
    self.details[1] = @"-";
    [self.tableHeaderView updateUserName:nil];
    [self.tableHeaderView  updateUserAvatar:nil];
    if ([SHUserManager sharedManager].isAuthed) {
        footName = @"退出";
        SHUserModel * userInfo = [[SHUserManager sharedManager] getUserInfoDirect];
        [self.tableHeaderView updateUserName:userInfo.Mobile];
        [self.tableHeaderView updateUserAvatar:[NSString stringWithFormat:@"%@%ld",BANNERDOWNLOADURL,(long)userInfo.UserImg]];
        if (userInfo.FirmID.length == 0) {
             self.details[0] = @"-";
        }else{
            self.details[1] = userInfo.FirmID;
        }
        if (userInfo.FirmName.length == 0) {
            self.details[1] = @"-";
        }else{
            self.details[0] = userInfo.FirmName;
        }
    }
    [self.tableView.tableFooterView.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj isKindOfClass:[UIButton class]]) {
            [(UIButton *)obj setTitle:footName forState:UIControlStateNormal];
            *stop = YES;
        }
    }];
    NSIndexPath * indexpath = [NSIndexPath indexPathForRow:0 inSection:1];
    NSIndexPath * indexpath1 = [NSIndexPath indexPathForRow:1 inSection:1];
    [self.tableView reloadRowsAtIndexPaths:@[indexpath,indexpath1] withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark - tableView delegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSArray * arr = @[@60,@50];
    return [arr[indexPath.section] integerValue];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSArray * arr = @[@1,@8];
    return [arr[section] integerValue];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        SHUserSection0Cell * cell  = [tableView dequeueReusableCellWithIdentifier:@"SHUserSection0Cell"];
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        [cell loadBuyData:self.buyCount];
        [cell loadSellData:self.sellCount];
        return cell;
    }
    SHUserSection1Cell * cell = [tableView dequeueReusableCellWithIdentifier:@"SHUserSection1Cell"];
    [cell updateWithImg:self.imgNames[indexPath.row] title:self.titles[indexPath.row] detailTitle:self.details[indexPath.row] type:[self.types[indexPath.row] integerValue]];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 2://消息点击
        {
            if ([SHUserManager sharedManager].isAuthed) {
                SHMessageListVC *list = [[SHMessageListVC alloc] init];
                [self.navigationController pushViewController:list animated:YES];
            }else{
                [self toast:STR_LOOKAFTERLOGIN];
            }
        }
            break;
        case 3://修改密码点击
        {
            if ([SHUserManager sharedManager].isAuthed) {
                SHChangePwdVC * vc = [[SHChangePwdVC alloc] initWithType:1];
                vc.title = @"修改密码";
                [self.navigationController pushViewController:vc animated:YES];
            }else{
                [self toast:@"只能修改当前已登录账号密码"];
            }
        }
            break;
        case 4://支付密码点击
        {
            if ([SHUserManager sharedManager].isAuthed) {
                SHUserModel * userInfo = [[SHUserManager sharedManager] getUserInfoDirect];
                if(!userInfo.HasPaymentPwd){
                    SHSetPaymentPwdVC * vc = [[SHSetPaymentPwdVC alloc] init];
                  //  self.modalPresentationStyle
                    [self presentViewController:vc animated:YES completion:nil];
                }else{
                    SHChangePaymentPwdVC * vc = [[SHChangePaymentPwdVC alloc] init];
                    [self.navigationController pushViewController:vc animated:YES];
                }

            }else{
                [self toast:STR_LOOKAFTERLOGIN];
            }
        }
            break;
        case 5://关于我们点击
        {
            SHHomeWebVC * vc = [[SHHomeWebVC alloc] initWithUrl:[WEBREQUESTURL stringByAppendingString:URL_ABOUT_US] title:@"关于我们" imageName:@"share_blank"];
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
        case 6://联系客服点击
        {
            NSMutableString * str=[[NSMutableString alloc] initWithFormat:@"tel:%@",self.details[6]];
            UIWebView * callWebview = [[UIWebView alloc] init];
            [callWebview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:str]]];
            [self.view addSubview:callWebview];
        }
            break;
        default:
            break;
    }
}

#pragma mark - header delegate
-(void)userBtnClickedWithTag:(NSInteger)btntag{
    if ([SHUserManager sharedManager].isAuthed) {
        if(btntag == 0){
            UIActionSheet * actionSheet = [[UIActionSheet alloc] initWithTitle:STR_HOME_ALERT_TITLE_REMINDER delegate:self cancelButtonTitle:STR_ALERT_CANCEL destructiveButtonTitle:nil otherButtonTitles:@"相册",@"拍照",nil];
            [actionSheet showInView:self.view];
        } else {
            SHUserModel * userInfo = [[SHUserManager sharedManager] getUserInfoDirect];
            if(userInfo.FirmID && userInfo.FirmID.length > 0) {
                
                DLog(@"失效的token是%@", [[SHUserManager sharedManager]getToken]);
                DLog(@"失效的FIRMid是%@", userInfo.FirmID);

                
                NSString *theFooterUrl = [NSString stringWithFormat:@"?ID=%@&token=%@", userInfo.FirmID, [[SHUserManager sharedManager]getToken]];
                NSString *url = [[WEBREQUESTURL stringByAppendingString:WEB_MEMBER_INFO] stringByAppendingString:theFooterUrl];
                SHHomeWebVC * vc = [[SHHomeWebVC alloc] initWithUrl:url title:@"会员资料" imageName:nil];
                vc.isNeedRefresh = NO;
                [self.navigationController pushViewController:vc animated:YES];
            } else {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:STR_HOME_ALERT_TITLE_REMINDER message:@"您当前没有所属企业\n请尽快到www.shcem.com完成企业认证" delegate:self cancelButtonTitle:nil otherButtonTitles:STR_ALERT_SURE, nil];
                [alert show];
            }
        }
        return;
    }
    SHLoginVC * vc = [[SHLoginVC alloc] initWithEntryClass:NSStringFromClass([self class])];
    [self.navigationController pushViewController:vc animated:YES];
}
#pragma mark - action sheet
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex NS_DEPRECATED_IOS(2_0, 8_3) __TVOS_PROHIBITED{
    UIImagePickerControllerSourceType type = UIImagePickerControllerSourceTypePhotoLibrary;
    DLog(@"%ld",(long)buttonIndex);

    switch(buttonIndex){
        case 0:
            type = UIImagePickerControllerSourceTypePhotoLibrary;
            break;
        case 1:
             type = UIImagePickerControllerSourceTypeCamera;
            break;
        default:
            type = 2;
            break;
    }
    
    if(type < 2 && [UIImagePickerController isSourceTypeAvailable:type]){
        [self.photoPicker showOnPickerViewControllerSourceType:type onViewController:self allowsEditing:YES compled:^(UIImage *image, NSDictionary *editingInfo) {
            DLog(@"图片大小是%f,%f",image.size.width,image.size.height);
            UIImage * img = [UIImage resizeImage:image toSize:CGSizeMake(500, 500)];
            NSData * data =  UIImageJPEGRepresentation(img, 0.5);
            DLog(@"压缩后图片大小是%f,%f,%ld",img.size.width,img.size.height,(unsigned long)data.length);
            [self showProgress];
            WS(weakSelf)
            [[SHHTTPManager  sharedManager] uploadWithData:data url:UPLOAD_URL callback:^(id responseObject, NSError *error) {
                if(error){
                    [weakSelf hideProgress];
                    [weakSelf showError:error];
                    return;
                }
                NSDictionary * dic = [NSJSONSerialization objectWithJSONString:[responseObject objectForKey:@"data"]]  ;
                NSString * token = [[SHUserManager sharedManager] getToken];
                [SHLoginService setUserAvatar:@[dic[@"Id"],token] callback:^(NSError *err, NSDictionary *d) {
                    [weakSelf hideProgress];
                    if(err){
                        [weakSelf showError:err];
                        return;
                    }
                    [weakSelf.tableHeaderView updateUserAvatar:dic[@"SourceUrl"]];
                    [[SHUserManager sharedManager] updateAvatarWithID:[dic[@"Id"] integerValue]];//更新头像后需要重新更新缓存
                    [weakSelf toast:@"文件上传成功"];
                    
                }];
                DLog(@"图片上传结果：%@",responseObject);
            }];
        }];
    }


}

#pragma mark - 登陆按钮点击
-(void)loginBtnClicked:(UIButton *)btn{
    if ([SHUserManager sharedManager].isAuthed) {
        UIAlertController * alertVC = [UIAlertController alertControllerWithTitle:STR_HOME_ALERT_TITLE_REMINDER message:@"确定要退出吗?" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction * action = [UIAlertAction actionWithTitle:STR_ALERT_SURE style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [[SHUserManager sharedManager] logout];
            [self updateUI];
        }];
        UIAlertAction * action1 = [UIAlertAction actionWithTitle:STR_ALERT_CANCEL style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        }];
        [alertVC addAction:action];
        [alertVC addAction:action1];
        [self presentViewController:alertVC animated:YES completion:^{
        }];
        return;
    }
    SHLoginVC * vc = [[SHLoginVC alloc] initWithEntryClass:NSStringFromClass([self class])];
    [self.navigationController pushViewController:vc animated:YES];
}
#pragma mark - 初始化

-(UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds];
        [_tableView registerClass:[SHUserSection0Cell class] forCellReuseIdentifier:@"SHUserSection0Cell"];
        [_tableView registerClass:[SHUserSection1Cell class] forCellReuseIdentifier:@"SHUserSection1Cell"];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.backgroundColor = HexRGB(0xf3f3f3);
        
        UIView * footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 80)];
        footerView.backgroundColor = HexRGB(0xf3f3f3);
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setTitle:STR_SHOW_CLICK_LOGIN forState:UIControlStateNormal];
        UIImage * img = [UIImage imageWithColor:COLOR_NAV_RED];
        [btn setBackgroundImage:img forState:UIControlStateNormal];
        btn.layer.cornerRadius = 5.0;
        btn.layer.masksToBounds = YES;
        btn.frame = CGRectMake(0, 0, ScreenWidth - 30, 40);
        btn.center = footerView.center;
        [btn addTarget:self action:@selector(loginBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [footerView addSubview:btn];
        _tableView.tableFooterView = footerView;
    }
    return _tableView;
}
-(SHUserHeaderView *)tableHeaderView{
    if (!_tableHeaderView) {
        _tableHeaderView = [[SHUserHeaderView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, 80)];
        _tableHeaderView.delegate = self;
        _tableHeaderView.backgroundColor = [UIColor whiteColor];
    }
    return _tableHeaderView;
}
-(SHPhotoPicker *)photoPicker{
    if (!_photoPicker) {
        _photoPicker = [[SHPhotoPicker alloc] init];
    }
    return _photoPicker;
}

@end
