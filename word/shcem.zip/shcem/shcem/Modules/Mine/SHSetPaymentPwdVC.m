//
//  SHSetPaymentPwdVC.m
//  shcem
//
//  Created by huangdeyu on 2016/12/14.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHSetPaymentPwdVC.h"
#import "SHSetPaymentView.h"
#import "SHLoginService.h"
#import "SHSetPaymentAnimator.h"

@interface SHSetPaymentPwdVC ()<SHSetPaymentViewDelegate,UIViewControllerTransitioningDelegate>
@property(nonatomic,strong) SHSetPaymentView * paymentView;
@property(nonatomic,strong) UITextField * textField;
@property(nonatomic,copy) NSString * pwd;
@end

@implementation SHSetPaymentPwdVC
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.transitioningDelegate = self;
        self.modalPresentationStyle = UIModalPresentationCustom;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [HexRGB(0x000) colorWithAlphaComponent:0.5];
    [self.view addSubview:self.paymentView];
    [self.view addSubview:self.textField];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textfiledDidChanged:) name:UITextFieldTextDidChangeNotification object:nil];
}
-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark -transition 
- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source{
    return [[SHSetPaymentAnimator alloc] initWithTransitionType:UINavigationControllerOperationPush];
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed{
    return  [[SHSetPaymentAnimator alloc] initWithTransitionType:UINavigationControllerOperationPop];
}

#pragma mark - notification
-(void)textfiledDidChanged:(NSNotification *)notification{
    UITextField * textfield = notification.object;
    self.pwd = textfield.text;
    if (textfield.text.length > 6) {
        textfield.text = [textfield.text substringToIndex:6];
        self.pwd = textfield.text;
        return;
    }
    [self.paymentView updateHiddenWithStr:textfield.text];
}

#pragma mark - delegate
-(void)btnClicked:(UIButton *)btn{
    if (btn.tag == 0) {
        [self dismissViewControllerAnimated:YES completion:nil];
        [self.view endEditing:YES];
        return;
    }
    if (self.pwd.length < 6) {
        [self toast:STR_MINE_TOAST_PASSWORD_PAY];
        return;
    }
    SHUserModel * userInfo = [[SHUserManager sharedManager] getUserInfoDirect];
    [SHLoginService setPaymentPwd:@[userInfo.UserCode,self.pwd] callback:^(NSError *err, NSDictionary *dic) {
        if (err) {
            [self showError:err];
            return;
        }
        [[SHUserManager sharedManager] updatePaymentPwdWithStatus:1];
        [self toast:@"设置支付密码成功"];
        [self runAfterSecs:0.5 block:^{
            [self dismissViewControllerAnimated:YES completion:nil];
        }];
    }];
}

#pragma mark - 初始化
-(SHSetPaymentView *)paymentView{
    if (!_paymentView) {
        _paymentView = [[SHSetPaymentView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth - 40, 180)];
        _paymentView.center = CGPointMake(self.view.centerX, self.view.centerY - 50);
        _paymentView.delegate = self;
    }
    return _paymentView;
}
-(UITextField *)textField{
    if (!_textField) {
        _textField = [[UITextField alloc] init];
        [_textField becomeFirstResponder];
        _textField.keyboardType = UIKeyboardTypeNumberPad;
        _textField.hidden = YES;
    }
    return _textField;
}
@end
