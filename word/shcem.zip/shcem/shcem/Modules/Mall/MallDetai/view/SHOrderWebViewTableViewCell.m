//
//  SHOrderWebViewTableViewCell.m
//  shcem
//
//  Created by xupeipei on 2016/11/23.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHOrderWebViewTableViewCell.h"
#import <Masonry/Masonry.h>
#import <WebKit/WebKit.h>


@interface SHOrderWebViewTableViewCell()<WKNavigationDelegate>

@property (strong,nonatomic) WKWebView *orderWebView;

@end


@implementation SHOrderWebViewTableViewCell

-(void)dealloc{
    [self.orderWebView.scrollView removeObserver:self forKeyPath:@"contentSize"];
}

-(void)setMallDetailModel:(SHMallDetailModel *)mallDetailModel{
    _mallDetailModel = mallDetailModel;
    
    NSString * token = [[SHUserManager sharedManager] getToken];
    NSString *urlString = [NSString stringWithFormat:@"%@/mall_inquiry.html?ID=%@&token=%@",WEBREQUESTURL,self.mallDetailModel.ID,token];
    NSURLRequest *request =[NSURLRequest requestWithURL:[NSURL URLWithString:urlString]];
    [self.orderWebView loadRequest:request];
}


-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self.contentView addSubview:self.orderWebView];
        [self.orderWebView.scrollView addObserver:self forKeyPath:@"contentSize" options:NSKeyValueObservingOptionNew context:nil];
        
        [self.orderWebView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top);
            make.left.mas_equalTo(self.contentView.mas_left);
            make.right.mas_equalTo(self.contentView.mas_right);
            make.bottom.mas_equalTo(self.contentView.mas_bottom);
        }];
    }
    return self;
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(nullable void *)context
{
    if ([keyPath isEqualToString:@"contentSize"]) {
        if (self.orderWebViewModel.orderWebViewHeight != self.orderWebView.scrollView.contentSize.height) {
            self.orderWebViewModel.orderWebViewHeight = self.orderWebView.scrollView.contentSize.height;
        }
    }
}


-(WKWebView*)orderWebView{
    if (!_orderWebView) {
        _orderWebView = [[WKWebView alloc] initWithFrame:CGRectZero];
        _orderWebView.navigationDelegate = self;
        _orderWebView.scrollView.scrollEnabled = NO;
    }
    return _orderWebView;
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation{
    
}

- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation{
    
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{

}

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation{
    
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
