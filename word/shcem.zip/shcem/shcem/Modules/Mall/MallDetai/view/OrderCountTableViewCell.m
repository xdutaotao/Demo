//
//  OrderCountTableViewCell.m
//  shcem
//
//  Created by xupeipei on 2016/11/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "OrderCountTableViewCell.h"
#import <Masonry/Masonry.h>
#import "NSString+Format.h"

@interface OrderCountTableViewCell()

@property (strong,nonatomic) UILabel *moneyLB;
@property (strong,nonatomic) UILabel *totalLB;
@property (strong,nonatomic) UILabel *numberLB;
@property (strong,nonatomic) UILabel *numberUnitLB;
@property (strong,nonatomic) UILabel *publishLB;
@property (strong,nonatomic) UILabel *zhongshihuaLB;
@property (strong,nonatomic) UILabel *balanceLB;
@property (strong,nonatomic) UIButton *readeBT;

@end

@implementation OrderCountTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        self.totalLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.totalLB.font = [UIFont systemFontOfSize:14];
        self.totalLB.text = @"共批吨";
        self.totalLB.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:self.totalLB];
        
        [self.totalLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top);
            make.left.mas_equalTo(self.contentView.mas_left);
            make.size.mas_equalTo(CGSizeMake(ScreenWidth/2-10, 30));
        }];
        
        self.moneyLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.moneyLB.font = [UIFont systemFontOfSize:14];
        self.moneyLB.text = @"合计:";
        self.moneyLB.textColor = [UIColor redColor];
        [self.contentView addSubview:self.moneyLB];
        
        [self.moneyLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top);
            make.left.mas_equalTo(self.totalLB.mas_right).offset(10);
            make.size.mas_equalTo(self.totalLB);
        }];
        
        self.numberLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.numberLB.text = @"保证金金额:";
        self.numberLB.textAlignment = NSTextAlignmentRight;
        self.numberLB.textColor = [UIColor redColor];
        self.numberLB.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:self.numberLB];
        
        [self.numberLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.totalLB.mas_bottom);
            make.left.mas_equalTo(self.totalLB.mas_left);
            make.size.mas_equalTo(self.totalLB);
        }];
        
        self.numberUnitLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.numberUnitLB.text = @"保证金收费标准:";
        self.numberUnitLB.textColor = [UIColor redColor];
        self.numberUnitLB.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:self.numberUnitLB];
        
        [self.numberUnitLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.numberLB.mas_top);
            make.left.mas_equalTo(self.numberLB.mas_right).offset(10);
            make.size.mas_equalTo(self.numberLB);
        }];
        
        self.zhongshihuaLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.zhongshihuaLB.textColor = [UIColor redColor];
        self.zhongshihuaLB.text = @"成交当日 23:45 之前必须完成运费支付，否则按违约处理";
        self.zhongshihuaLB.textAlignment = NSTextAlignmentCenter;
        self.zhongshihuaLB.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:self.zhongshihuaLB];
        
        [self.zhongshihuaLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.numberLB.mas_bottom);
            make.left.mas_equalTo(self.contentView.mas_left).offset(10);
            make.right.mas_equalTo(self.contentView.mas_right);
            make.height.mas_equalTo(20);
        }];
        
        self.balanceLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.balanceLB.text = @"资金账户余额";
        self.balanceLB.textAlignment = NSTextAlignmentCenter;
        self.balanceLB.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:self.balanceLB];
        
        [self.balanceLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.zhongshihuaLB.mas_bottom);
            make.left.mas_equalTo(self.contentView.mas_left).offset(10);
            make.right.mas_equalTo(self.contentView.mas_right);
            make.height.mas_equalTo(20);
        }];
        
        NSString *publishString = @"我已阅读《现货交易规则》并同意";
        self.publishLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.publishLB.text = publishString;
        self.publishLB.font = [UIFont systemFontOfSize:12];
        self.publishLB.numberOfLines = 0;
        [self.contentView addSubview:self.publishLB];
        
        [self.publishLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.balanceLB.mas_bottom);
            make.centerX.mas_equalTo(self.contentView.mas_centerX).offset(20);
            make.size.mas_equalTo(CGSizeMake(200, 20));
        }];
        
        self.readeBT = [[UIButton alloc] initWithFrame:CGRectZero];
        [self.readeBT setImage:[UIImage imageNamed:@"check"] forState:UIControlStateNormal];
        [self.readeBT addTarget:self action:@selector(readeButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:self.readeBT];
        
        [self.readeBT mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.publishLB.mas_top);
            make.right.mas_equalTo(self.publishLB.mas_left).offset(-10);
            make.size.mas_equalTo(CGSizeMake(20, 20));
        }];

    }
    
    return self;

}

-(void)setIsZhongshihua:(BOOL)isZhongshihua{
    _isZhongshihua = isZhongshihua;
    
    if (isZhongshihua) {
        self.zhongshihuaLB.hidden = false;
    }else{
        self.zhongshihuaLB.hidden = true;
        
        [self.zhongshihuaLB mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.numberLB.mas_bottom);
            make.left.mas_equalTo(self.contentView.mas_left).offset(10);
            make.right.mas_equalTo(self.contentView.mas_right);
            make.height.mas_equalTo(0);
        }];
        
        [self needsUpdateConstraints];
    }
}


-(void)setGoodsType:(NSString *)goodsType{
    _goodsType = goodsType;
    
    self.publishLB.text = [NSString stringWithFormat:@"我已阅读《%@交易规则》并同意",goodsType];
}

-(void)setGetAndCheckExpensesModel:(SHGetAndCheckExpensesModel *)getAndCheckExpensesModel{
    _getAndCheckExpensesModel = getAndCheckExpensesModel;
    
    if (_getAndCheckExpensesModel.readeStatus == YES) {
        [self.readeBT setImage:[UIImage imageNamed:@"checked"] forState:UIControlStateNormal];
    }else{
        [self.readeBT setImage:[UIImage imageNamed:@"check"] forState:UIControlStateNormal];
    }
    
    self.balanceLB.text = [NSString stringWithFormat:@"资金账户余额:%@",[NSString keepTwoDecimalPlaces:getAndCheckExpensesModel.custrans]];
    self.totalLB.text = [NSString stringWithFormat:@"共%@批%@吨",getAndCheckExpensesModel.countBatch,getAndCheckExpensesModel.countWeight];
    self.moneyLB.text = [NSString stringWithFormat:@"合计:%@元",[NSString keepTwoDecimalPlaces:getAndCheckExpensesModel.countMoney]];
    self.numberLB.text = [NSString stringWithFormat:@"保证金金额:%@元",[NSString keepTwoDecimalPlaces:getAndCheckExpensesModel.Deposit]];
    self.numberUnitLB.text = [NSString stringWithFormat:@"保证金收费标准:%@",getAndCheckExpensesModel.FormatDepositRate];
    
}


-(void)readeButtonAction:(id)sender{
    self.getAndCheckExpensesModel.readeStatus = !self.getAndCheckExpensesModel.readeStatus;
    
    if (self.getAndCheckExpensesModel.readeStatus == YES) {
        [self.readeBT setImage:[UIImage imageNamed:@"checked"] forState:UIControlStateNormal];
    }else{
        [self.readeBT setImage:[UIImage imageNamed:@"check"] forState:UIControlStateNormal];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
