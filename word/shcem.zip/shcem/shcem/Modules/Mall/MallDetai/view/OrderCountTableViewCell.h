//
//  OrderCountTableViewCell.h
//  shcem
//
//  Created by xupeipei on 2016/11/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHGetAndCheckExpensesModel.h"

@interface OrderCountTableViewCell : UITableViewCell

@property (nonatomic,assign) BOOL isZhongshihua;
@property (nonatomic,strong) NSString *goodsType;
@property (nonatomic,strong) SHGetAndCheckExpensesModel *getAndCheckExpensesModel;


@end
