//
//  SHOrderViewTableViewCell.m
//  shcem
//
//  Created by xupeipei on 2016/11/23.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHOrderViewTableViewCell.h"
#import <Masonry/Masonry.h>

@interface SHOrderViewTableViewCell()<UITextFieldDelegate>

@property (strong,nonatomic) UILabel *priceLB;
@property (strong,nonatomic) UILabel *priceUnitLB;
@property (strong,nonatomic) UITextField *priceTF;
@property (strong,nonatomic) UILabel *numberLB;
@property (strong,nonatomic) UILabel *numberUnitLB;

@property (strong,nonatomic) UITextField *numberTF;
@property (strong,nonatomic) UILabel *publishLB;
@property (strong,nonatomic) UISwitch *publishSwitch;


@property (nonatomic,strong) SHOrderViewModel *orderViewModel;
@property (nonatomic,assign) SHOrderVCType orderVCType;

@end


@implementation SHOrderViewTableViewCell


-(void)setOrderViewModel:(SHOrderViewModel *)orderViewModel orderVCType:(SHOrderVCType)orderVCType{
    self.orderViewModel = orderViewModel;
    self.orderVCType = orderVCType;
    
    if (self.orderVCType == SHOrderVCTypeInquery && [self.orderViewModel.goodsType isEqual:@"0"]) {
        self.publishLB.hidden = false;
        self.publishSwitch.hidden = false;
    }else{
        self.publishLB.hidden = true;
        self.publishSwitch.hidden = true;
    }
    
    
}

-(void)setOrderViewModel:(SHOrderViewModel *)orderViewModel{
    _orderViewModel = orderViewModel;
    
    if (_orderViewModel.orderVCType != 0) {
        self.priceTF.text = _orderViewModel.price;
        self.priceTF.userInteractionEnabled = NO;
    }
}


-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        self.priceLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.priceLB.textColor = [UIColor grayColor];
        self.priceLB.font = [UIFont systemFontOfSize:14];
        self.priceLB.text = @"成交价格";
        [self.contentView addSubview:self.priceLB];
        
        [self.priceLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top).offset(5);
            make.left.mas_equalTo(self.contentView.mas_left).offset(15);
            make.size.mas_equalTo(CGSizeMake(80, 44));
        }];
        
        self.priceUnitLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.priceUnitLB.textColor = [UIColor grayColor];
        self.priceUnitLB.font = [UIFont systemFontOfSize:14];
        self.priceUnitLB.text = @"元/吨";
        [self.contentView addSubview:self.priceUnitLB];
        
        [self.priceUnitLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.priceLB.mas_top);
            make.right.mas_equalTo(self.contentView.mas_right);
            make.size.mas_equalTo(CGSizeMake(80, 44));
        }];
        
        self.priceTF = [[UITextField alloc] initWithFrame:CGRectZero];
        self.priceTF.layer.borderWidth = 1.0f;
        self.priceTF.layer.cornerRadius = 5;
        self.priceTF.delegate = self;
        self.priceTF.textAlignment = NSTextAlignmentCenter;
        self.priceTF.keyboardType = UIKeyboardTypeNumberPad;
        self.priceTF.layer.borderColor = [UIColor grayColor].CGColor;
        [self.contentView addSubview:self.priceTF];
        
        [self.priceTF mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.priceLB.mas_top).offset(7);
            make.left.mas_equalTo(self.priceLB.mas_right);
            make.right.mas_equalTo(self.priceUnitLB.mas_left).offset(-10);
            make.height.mas_equalTo(30);
        }];
        
        self.numberLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.numberLB.text = @"成交数量";
        self.numberLB.textColor = [UIColor grayColor];
        self.numberLB.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:self.numberLB];
        
        [self.numberLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.priceLB.mas_bottom);
            make.left.mas_equalTo(self.priceLB.mas_left);
            make.size.mas_equalTo(CGSizeMake(80, 44));
        }];
        
        self.numberUnitLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.numberUnitLB.text = @"批";
        self.numberUnitLB.textColor = [UIColor grayColor];
        self.numberUnitLB.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:self.numberUnitLB];
        
        [self.numberUnitLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.numberLB.mas_top);
            make.right.mas_equalTo(self.contentView.mas_right);
            make.size.mas_equalTo(CGSizeMake(80, 44));
        }];
        
        self.numberTF = [[UITextField alloc] initWithFrame:CGRectZero];
        self.numberTF.layer.borderWidth = 1.0f;
        self.numberTF.layer.cornerRadius = 5;
        self.numberTF.delegate = self;
        self.numberTF.textAlignment = NSTextAlignmentCenter;
        self.numberTF.keyboardType = UIKeyboardTypeNumberPad;
        self.numberTF.layer.borderColor = [UIColor grayColor].CGColor;
        [self.contentView addSubview:self.numberTF];
        
        [self.numberTF mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.numberLB.mas_top).offset(7);
            make.left.mas_equalTo(self.priceLB.mas_right);
            make.right.mas_equalTo(self.priceUnitLB.mas_left).offset(-10);
            make.height.mas_equalTo(30);
        }];
        
        NSString *publishString = @"同时发布给条件符合的报盘（相同产地、品类牌号、仓库地址、交收方式、交货日期、交易单位、保证金比例、货代、买家提货附加费、配送范围）";
        CGRect rect = [publishString boundingRectWithSize:CGSizeMake(ScreenWidth-100, 9999) options:NSStringDrawingUsesFontLeading|NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:16]} context:nil];
        
        self.publishLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.publishLB.text = publishString;
        self.publishLB.font = [UIFont systemFontOfSize:12];
        self.publishLB.numberOfLines = 0;
        [self.contentView addSubview:self.publishLB];
        
        [self.publishLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.numberLB.mas_bottom).offset(-10);
            make.left.mas_equalTo(self.numberLB.mas_left);
            make.size.mas_equalTo(rect.size);
        }];
        
        self.publishSwitch = [[UISwitch alloc] initWithFrame:CGRectZero];
        [self.publishSwitch addTarget:self action:@selector(publishSwitchEventValueChanged:) forControlEvents:UIControlEventValueChanged];
        [self.contentView addSubview:self.publishSwitch];
        
        [self.publishSwitch mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.numberLB.mas_bottom).offset(10);
            make.left.mas_equalTo(self.publishLB.mas_right).offset(10);
            make.size.mas_equalTo(CGSizeMake(80, 40));
        }];

    }
    
    return self;
    
}

-(BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    if (textField == self.priceTF) {
        self.orderViewModel.price = self.priceTF.text;
    }else{
        self.orderViewModel.number = self.numberTF.text;
    }
    
    return YES;
}


-(void)publishSwitchEventValueChanged:(id)sender{
    
    UISwitch *paSwitch = (UISwitch*)sender;
    self.orderViewModel.pushStatus = paSwitch.isOn? 1:0;
    
}


- (void)awakeFromNib {
    [super awakeFromNib];

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
