//
//  SHOrderViewTableViewCell.h
//  shcem
//
//  Created by xupeipei on 2016/11/23.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHOrderViewModel.h"
#import "SHOrderVC.h"

@interface SHOrderViewTableViewCell : UITableViewCell

-(void)setOrderViewModel:(SHOrderViewModel *)orderViewModel orderVCType:(SHOrderVCType)orderVCType;

@end
