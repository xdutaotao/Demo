//
//  SHOrderWebViewTableViewCell.h
//  shcem
//
//  Created by xupeipei on 2016/11/23.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHMallDetailModel.h"
#import "SHOrderWebViewModel.h"

@interface SHOrderWebViewTableViewCell : UITableViewCell

@property (strong,nonatomic) SHMallDetailModel *mallDetailModel;
@property (nonatomic,strong) SHOrderWebViewModel *orderWebViewModel;

@end
