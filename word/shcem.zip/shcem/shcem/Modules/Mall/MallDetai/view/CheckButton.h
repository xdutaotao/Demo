//
//  CheckButton.h
//  shcem
//
//  Created by xupeipei on 2016/12/29.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CheckButton : UIButton

@property (nonatomic,assign) BOOL check;

@end
