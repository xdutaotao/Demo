
//
//  SHMallVC.m
//  shcem
//
//  Created by huangdeyu on 2016/11/21.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHMallVC.h"
#import "SHMallDetaiVC.h"
#import "SHRefreshHeader.h"
#import "SHMallService.h"
#import "SHMallListCellTableViewCell.h"
#import "SHMallSearchView.h"
#import "SHMallSearchListView.h"
#import "SHMallConditionTitleView.h"
#import "SHMallChooseVC.h"
#import "SHMallSearchKey.h"
#import "SHCacheManager.h"
#import "SHMessageListVC.h"
#import "SHBaseTableView.h"
#import "MJExtension.h"
#import "SHLoginVC.h"


@interface SHMallVC ()<UITableViewDelegate,UITableViewDataSource,SHBaseTableViewDelegate,SHMallSearchViewDelegate,SHMallSearchListViewDelegate,SHMallConditionTitleViewDelegate,SHMallChooseVCDelegate>
@property(nonatomic,strong)SHBaseTableView * tableView;
@property(nonatomic,strong)SHMallSearchView * searchView;                       //导航栏
@property(nonatomic,strong)SHMallConditionTitleView * conditionTitleView;   //导航栏下面的筛选条件视图
@property(nonatomic,strong)SHMallSearchListView * searchListView;

@property(nonatomic,strong) NSMutableArray<SHMallListModel *> * models;

@property(nonatomic,strong) NSMutableArray * searchHistory;             //搜索历史
@property(nonatomic,copy) NSString * currentSearchKeywords;
@property(nonatomic,strong) NSMutableDictionary * searchConditions; //本地查询条件
@end

@implementation SHMallVC

#pragma mark - system circle
-(instancetype)init{
    if (self = [super init]) {
        self.models = [NSMutableArray array];
        self.searchHistory = [NSMutableArray array];
        [self setupSearchConditions];
        self.onlyShowBackArray  = NO;
    }
    return  self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //隐藏导航栏
    self.fd_prefersNavigationBarHidden = YES;
    [self.view addSubview:self.tableView];
    [self.view addSubview:self.searchView];
    [self.view addSubview:self.conditionTitleView];
    self.needReaload = YES;
    [self loadLocalConditions];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateUnreadCount:) name:USER_UNREAD_COUNT_NOTIFICATION object:nil];
}
-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    [self.view endEditing:YES];
}
#pragma mark - 通知
-(void)updateUnreadCount:(NSNotification *)notification{
    DLog(@"商城页面清除未读数量");
    NSDictionary * dic = notification.object;
    if (dic) {
        NSInteger  num =  [dic[@"result"] integerValue];
        if (num > 0) {
            [self.searchView updateMsg:YES];
        }else{
            [self.searchView updateMsg:NO];
        }
    }else{
        [self.searchView updateMsg:NO];
    }
}

-(void)setSearchText{
    if (self.showSearch) {
        [self.searchView setText:self.showSearch];
    }
    self.searchConditions[Kkeywords] =  self.showSearch;          //关键字
}
#pragma mark - setter
-(void)setNeedReaload:(BOOL)needReaload{
    _needReaload = needReaload;
    if (_needReaload) {
        [self.tableView.mj_header beginRefreshing];
    }
    [self updateConditionsStatus];
}
//更新筛选的颜色状态
-(void)updateConditionsStatus{
    NSInteger count = 0;
    if (((NSArray *)self.searchConditions[Kcategory]).count > 0) {
        count++;
    }
    if (![self.searchConditions[Ktype] isEqual:@(-1)]) {
        count++;
    }
    if (![self.searchConditions[Kstate] isEqual:@(-1)]) {
        count++;
    }
    if (![self.searchConditions[KdeliverType] isEqual:@(-1)]) {
        count++;
    }
    if (((NSArray *)self.searchConditions[KsourcePlace]).count > 0) {
        count++;
    }
    if (((NSArray *)self.searchConditions[KdelieveryPlace]).count > 0) {
        count++;
    }
    if (((NSArray *)self.searchConditions[KsellScope]).count > 0) {
        count++;
    }
    if (![self.searchConditions[KSourcePlaceType] isEqual:@(-1)]) {
        count++;
    }
    [self.conditionTitleView updateConditionsWithCount:count];
}

#pragma mark - load local data
-(void)loadLocalConditions{
    [[SHCacheManager shareInstance] loadFrom:NSDocumentDirectory name:SEARCH_LIST_KEY callBack:^(id dic, NSError *err) {
        if (dic) {
            self.searchHistory = [dic mutableCopy];
            if(self.searchHistory.count == 0) {
                [self.searchListView searchHide];
            }
        }
    }];
}
-(void)setupSearchConditions{
    if(!self.searchConditions){
        self.searchConditions = [NSMutableDictionary  dictionary];
        DLog(@"查询条件的内存地址是：%p",self.searchConditions);
    }
    self.searchConditions[Kkeywords] = @"";          //关键字
    self.searchConditions[Kcategory] = @[];           //分类 HDPE,LDPE
    self.searchConditions[KsourcePlace] = @[];       //产地
    self.searchConditions[KdelieveryPlace] = @[];   //交货地
    self.searchConditions[KsellScope] = @[];          //配送范围
    self.searchConditions[Ktype] = @(-1);             //0现货，1预售   -1 全部
    self.searchConditions[Kstate] = @(-1);            //-1：全部  0:有效，这个传给服务的居然是个数组，我靠怎么玩，这边我会处理一下，在上传的时候包装成数组，在做UI的时候以单值传递
    self.searchConditions[KdeliverType] = @(-1); //交收方式:配送，自提，转货权
    self.searchConditions[KsortDirection] = @(1);// 0：从低到高，时间从远到近    1：从高到低，时间由近及远
    self.searchConditions[KorderBy] = @(1);       //1 :按时间排序 2:按价格排序
    self.searchConditions[KsellScope] = @[];        //配送范围
    self.searchConditions[KSourcePlaceType] = @(-1);     //国产进口，
    
    self.searchConditions[KsourcePlaceValues] = @[@"全部"];
    self.searchConditions[KdeliveryPlaceValues] = @[@"全部"];
    self.searchConditions[KKsellScopeValues] = @[@"全部"];
}

#pragma mark - tableView delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return  80;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return  self.models.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    SHMallListCellTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([SHMallListCellTableViewCell class])];
    if (!cell) {
        cell = [[SHMallListCellTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([SHMallListCellTableViewCell class])];
    }
    [cell setSelectionStyle:UITableViewCellSelectionStyleDefault];
    [cell loadData:self.models[indexPath.row]];
    return  cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (![SHUserManager sharedManager].isAuthed) {
        [self shouldBeLogin];
    }else{
        SHMallDetaiVC *mallDetaiVC = [[SHMallDetaiVC alloc] initWithMallListModel:self.models[indexPath.row]];
        mallDetaiVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:mallDetaiVC  animated:YES];
    }
    
}
-(void)loadDataWithPage:(NSInteger)page{
    //这个arr是因为服务数据问题，才做特殊处理的
    NSArray * arr = nil;
    if ([self.searchConditions[Kstate] integerValue] == -1) {
        arr = @[];
    }else{
        arr = @[self.searchConditions[Kstate]];
    }
    SHQueryCondition * condition = [SHQueryCondition defaultCondition];
    condition.parameter = URL_PARAMETER_MALL_LIST(self.searchConditions[Kkeywords], arr, @(page), @15, self.searchConditions[KorderBy], self.searchConditions[KsortDirection], self.searchConditions[Kcategory], self.searchConditions[KsourcePlace], self.searchConditions[KdelieveryPlace], self.searchConditions[Ktype], self.searchConditions[KdeliverType],self.searchConditions[KsellScope],self.searchConditions[KSourcePlaceType]);
    DLog(@"%@",condition);
    WS(weakSelf)
    [self.tableView getListWithPage:page condition:condition pageSize:15 successCallback:^(id objects) {
        NSArray * array = [SHMallListModel mj_objectArrayWithKeyValuesArray:objects];
        [weakSelf.models addObjectsFromArray:array];
        [weakSelf.tableView reloadData];
        [self.searchListView searchShow];
    }];
}

#pragma mark -导航栏点击
-(void)navBtnClicked:(UIButton *)btn{
    if(btn.tag == 1){
        if ([SHUserManager sharedManager].isAuthed) {
            SHUserModel * userModel = [[SHUserManager sharedManager] getUserInfoDirect];
            NSInteger TradeAuthority = userModel.TradeAuthority;
            if (TradeAuthority !=0 && TradeAuthority !=1 && TradeAuthority !=2) {
                [self toast:STR_HOME_TOAST_NO_PREMISSION];
                return;
            }
            SHMessageListVC * vc = [[SHMessageListVC alloc] init];
            [self.navigationController pushViewController:vc animated:YES];
        }else{
            [self shouldBeLogin];
        }
    }else{
        [self.searchView setText:self.currentSearchKeywords];
        [self hideTableView];
    }
}
-(void)showTableView{
    self.tabBarController.tabBar.hidden = YES;
    self.currentSearchKeywords = [self.searchView searchStr];
    [self.searchListView showInView:self.view];
    [self.searchListView loadData:self.searchHistory];
}
-(void)hideTableView{
    self.tabBarController.tabBar.hidden = NO;
    [self.searchListView hide];
}
//点击搜索
-(void)searchKeyboardClicked{
    NSString * str = [self.searchView searchStr];
    [self mallSearchTouchSearchKeyboardOrHistoryCellToSearchWithString:str];
}

- (void)mallSearchTouchSearchKeyboardOrHistoryCellToSearchWithString:(NSString *)str{
    self.searchConditions[Kkeywords] = str;
    [self.tableView.mj_header beginRefreshing];
    if (str.length > 0  && ![self.searchHistory containsObject:str]) {
        if (self.searchHistory.count < 10) {
            [self.searchHistory insertObject:str atIndex:0];
        }else{
            [self.searchHistory removeLastObject];
            [self.searchHistory insertObject:str atIndex:0];
        }
        [[SHCacheManager shareInstance] saveTo:NSDocumentDirectory name:SEARCH_LIST_KEY obj:self.searchHistory callBack:^{
        }];
    }
    [self hideTableView];
}

#pragma mark - SHMallSearchListViewDelegate
//选中一个cell
-(void)searchOverWith:(NSString *)str{
    //搜索结果在这里面显示
    [self.searchView setText:str];
    [self mallSearchTouchSearchKeyboardOrHistoryCellToSearchWithString:str];
}
-(void)clearBtnClicked{
    if (self.searchHistory.count > 0) {
        self.searchHistory = [NSMutableArray array];
        [self.searchListView loadData:self.searchHistory];
        [[SHCacheManager shareInstance] saveTo:NSDocumentDirectory name:SEARCH_LIST_KEY obj:self.searchHistory callBack:^{
        }];
    }
    [self.searchListView searchHide];
}
- (void)searchHistoryScroll{
    [self.searchView.textField resignFirstResponder];
}


#pragma mark 条件栏点击
-(void)timeOrPriceClicked:(UIButton *)btn sortType:(SHMallConditionStyle)type{//默认是时间降
    switch (btn.tag) {
        case 10:
            DLog(@"时间");
            self.searchConditions[KorderBy] = @(1);
            break;
        case 11:
            DLog(@"价格");
            self.searchConditions[KorderBy] = @(2);
            break;
        default:
            break;
    }
    switch (type) {
        case highToLow:
            DLog(@"降序");
            self.searchConditions[KsortDirection] = @(1);
            break;
        case lowToHigh:
            self.searchConditions[KsortDirection] = @(0);
            DLog(@"升顺");
        default:
            break;
    }
    [self.tableView.mj_header beginRefreshing];
}
-(void)chooseClicked:(UIButton *)btn{
    //   SHMallChooseVC * vc = [[SHMallChooseVC alloc] init];
    SHMallChooseVC * vc = [[SHMallChooseVC alloc] initWithCurrentChooseDatas:self.searchConditions];
    vc.delegate = self;
    [self presentViewController:vc animated:YES completion:nil];
}

//上个页面的重置点击
-(void)resetClicked{
    [self setupSearchConditions];
}

- (void)shouldBeLogin{
    SHLoginVC * vc = [[SHLoginVC alloc] initWithEntryClass:NSStringFromClass([self class])];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma  mark - 初始化
-(SHBaseTableView *)tableView{
    if (!_tableView) {
        _tableView  = [[SHBaseTableView alloc] initWithSource:self models:self.models frame:CGRectMake(0, NavgationBarHeight - StatusBarHeight + 50, ScreenWidth, ScreenHeight - NavgationBarHeight + StatusBarHeight - 50)];
        [_tableView registerClass:[SHMallListCellTableViewCell class] forCellReuseIdentifier:NSStringFromClass([SHMallListCellTableViewCell class])];
    }
    return _tableView;
}
-(SHMallSearchView *) searchView{
    if(!_searchView){
        _searchView = [[SHMallSearchView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, NavgationBarHeight)];
        _searchView.delegate = self;
    }
    return _searchView;
}
-(SHMallSearchListView *)searchListView{
    if(!_searchListView){
        _searchListView = [[SHMallSearchListView alloc] initWithFrame:CGRectMake(0, NavgationBarHeight, ScreenWidth, ScreenHeight - NavgationBarHeight)];
        _searchListView.delegate = self;
    }
    return  _searchListView;
}
-(SHMallConditionTitleView *)conditionTitleView{
    if (!_conditionTitleView) {
        _conditionTitleView = [[SHMallConditionTitleView alloc] initWithFrame:CGRectMake(0, NavgationBarHeight, ScreenWidth, 50)];
        _conditionTitleView.delegate = self;
    }
    return  _conditionTitleView;
}

@end
