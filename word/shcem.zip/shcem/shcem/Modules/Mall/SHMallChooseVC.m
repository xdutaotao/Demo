//
//  SHMallChooseVC.m
//  shcem
//
//  Created by huangdeyu on 2016/11/23.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHMallChooseVC.h"
#import "SHChooseView.h"
#import "SHMallVC.h"
#import "SHMallChooseDetailVC.h"
#import "SHScreenAnimator.h"
@interface SHMallChooseVC ()<SHChooseViewDelegate>
@property(nonatomic,strong) SHChooseView * chooseView;
@property(nonatomic,strong) NSDictionary * datas;
@property(nonatomic,strong) NSMutableDictionary  * currentSelectConditions;
@end

@implementation SHMallChooseVC
-(instancetype)init{
    if(self = [super init]){
        self.transitioningDelegate = self;
        self.modalPresentationStyle = UIModalPresentationCustom;
        self.hasUserAction = NO;
    }
    return self;
}
-(instancetype)initWithCurrentChooseDatas:(NSMutableDictionary *)dictionary{
    if (self = [super init]) {
        self.transitioningDelegate = self;
        self.modalPresentationStyle = UIModalPresentationCustom;
        self.currentSelectConditions = dictionary;
        DLog(@"查询条件的内存地址是：%p",self.currentSelectConditions);
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.6];
    [self.view addSubview:self.chooseView];
    __block typeof(self) weakself = self;
    [self loadChooseConditionFromCache:^(NSError *err, NSDictionary *dic) {
        weakself.datas = dic;
        [weakself.chooseView loadData:dic selectedDatas:self.currentSelectConditions];
    }];
}
-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)hideChooseView{
    self.chooseView.frame =CGRectMake(ScreenWidth, 0,ScreenWidth - 50 , ScreenHeight);
}
-(void)showChooseView{
       self.chooseView.frame = CGRectMake(50, 0, ScreenWidth - 50, ScreenHeight);
}

-(void)loadChooseConditionFromCache:(void(^)(NSError * err,NSDictionary * dic)) block{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString * filepath = [[NSBundle mainBundle] pathForResource:@"data" ofType:@"json"];
        NSData * jsonDatav = [[NSData alloc] initWithContentsOfFile:filepath];
        NSError * err = nil;
        NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:jsonDatav options:NSJSONReadingMutableLeaves error:&err];
        if (err) {
            DLog(@"%@",err.debugDescription);
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            block(err,dic);
        });
    });
}
#pragma mark - public methods
//产地，交货地，配送范围有更改的话，需要更新UI
-(void)reloadSection1{
  //  DLog(@"需要更新UI");
    [self.chooseView reloadSection1];
}

#pragma mark - 转场控制
- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source{
    return [[SHScreenAnimator alloc] initWithAnimatorType:UINavigationControllerOperationPush];
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed{
    return [[SHScreenAnimator alloc] initWithAnimatorType:UINavigationControllerOperationPop];
}

//- (nullable id <UIViewControllerInteractiveTransitioning>)interactionControllerForPresentation:(id <UIViewControllerAnimatedTransitioning>)animator;
//
//- (nullable id <UIViewControllerInteractiveTransitioning>)interactionControllerForDismissal:(id <UIViewControllerAnimatedTransitioning>)animator;

//- (nullable UIPresentationController *)presentationControllerForPresentedViewController:(UIViewController *)presented presentingViewController:(nullable UIViewController *)presenting sourceViewController:(UIViewController *)source NS_AVAILABLE_IOS(8_0);

#pragma mark - delegate
-(void)selectWithIndex:(NSInteger)index contents:(NSArray *)contents key:(NSString *)key{
    DLog(@"当前点选的是%ld",(long)index);
    NSArray * titles = @[@"产地",@"交货地",@"配送范围"];
    SHMallChooseDetailVC * vc = [[SHMallChooseDetailVC alloc] initWithData:contents currentSelectedIDs:self.currentSelectConditions keys:key title:titles[index]];
  //  [self.navigationController pushViewController:vc animated:YES];
    [self presentViewController:vc animated:YES completion:nil];
}
-(void)bottmBtnClicked:(NSInteger)tag{
    if (tag == 0) { //重置点击
        [self.delegate resetClicked];
        DLog(@"点击了重置");
    }else{             //确认点击
        DLog(@"点击了确认");
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}
-(void)navBackClicked{
    [self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark - 初始化
-(SHChooseView *) chooseView{
    if (!_chooseView) {
        _chooseView = [[SHChooseView alloc] initWithFrame:CGRectMake(ScreenWidth, 0,ScreenWidth - 50 , ScreenHeight)];
        _chooseView.delegate = self;
    }
    return  _chooseView;
}
@end
