//
//  SHMallChooseDetailVC.m
//  shcem
//
//  Created by huangdeyu on 2016/11/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHMallChooseDetailVC.h"
#import "SHChooseDetailAnimator.h"
#import "SHChooseDetailView.h"


@interface SHMallChooseDetailVC ()<SHChooseDetailViewDelegate>
@property(nonatomic,strong) SHChooseDetailView * chooseListView;
@property(nonatomic,strong) NSMutableDictionary  * currentSelectedDic;
@property(nonatomic,strong) NSArray * listDatas;
@property(nonatomic,copy) NSString * key;
@property(nonatomic,copy) NSString * navTitle;
@end

@implementation SHMallChooseDetailVC
-(instancetype)init{
    if (self = [super init]) {
        self.transitioningDelegate = self;
        self.modalPresentationStyle = UIModalPresentationCustom;
    }
    return self;
}
-(instancetype)initWithData:(NSArray *)datas currentSelectedIDs:(NSMutableDictionary *)dic keys:(NSString *)key title:(NSString *)title{
    if (self = [super init]) {
        self.transitioningDelegate = self;
        self.modalPresentationStyle = UIModalPresentationCustom;
        self.currentSelectedDic = dic;
        self.listDatas = datas;
        self.key = key;
        self.navTitle = title;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
   // self.view.backgroundColor = [UIColor brownColor];
    [self.view addSubview:self.chooseListView];
    NSString * valuesString = [NSString stringWithFormat:@"%@Values",self.key];
    [self.chooseListView loadDatas:self.listDatas currentSelectArr:self.currentSelectedDic[self.key] currentSelectedTitles:self.currentSelectedDic[valuesString]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
#pragma mark - public methods 
-(void)showChooseView{
    self.chooseListView.frame = CGRectMake(50, 0, ScreenWidth - 50, ScreenHeight);
}
-(void)hideChooseView{
    self.chooseListView.frame = CGRectMake(ScreenWidth, 0, ScreenWidth - 50, ScreenHeight);
}
#pragma mark - 转场控制
- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source{
    return [[SHChooseDetailAnimator alloc] initWithAnimatorType:UINavigationControllerOperationPush];
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed{
    return [[SHChooseDetailAnimator alloc] initWithAnimatorType:UINavigationControllerOperationPop];
}
#pragma mark - delegate
-(void)navBackClicked{
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)updateSelectedWithArr:(NSArray *)arr titles:(NSArray *)titles{
    self.currentSelectedDic[self.key] = arr;
    NSString * valuesString = [NSString stringWithFormat:@"%@Values",self.key];
    self.currentSelectedDic[valuesString] = titles;
    DLog(@"当前选中的标题是:%@",self.currentSelectedDic[valuesString]);
}
#pragma mark - 初始化
-(SHChooseDetailView *)chooseListView{
    if (!_chooseListView) {
        _chooseListView = [[SHChooseDetailView alloc] initWithFrame:CGRectMake(ScreenWidth, 0, ScreenWidth - 50, ScreenHeight) withTitle:self.navTitle];
        _chooseListView.delegate = self;
    }
    return _chooseListView;
}

@end
