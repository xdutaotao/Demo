//
//  MallDetaiVC.h
//  shcem
//
//  Created by xupeipei on 2016/11/22.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHBaseViewController.h"
#import "SHMallListModel.h"


@interface SHMallDetaiVC : SHBaseViewController

//从首页跳转过来
-(id)initWithUrl:(NSString*)url;

//从商城跳转及搜索列表跳转
-(id)initWithMallListModel:(SHMallListModel*)mallListModel;


@end
