//
//  SHMallChooseVC.h
//  shcem
//
//  Created by huangdeyu on 2016/11/23.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SHMallChooseVCDelegate <NSObject>

@required
-(void)resetClicked;

@end


@interface SHMallChooseVC : UIViewController<UIViewControllerTransitioningDelegate>
@property(nonatomic,weak)id<SHMallChooseVCDelegate>delegate;
@property(nonatomic,assign) BOOL hasUserAction;         //如果有用户操作
-(instancetype)initWithCurrentChooseDatas:(NSMutableDictionary *)dictionary;
-(void)showChooseView;
-(void)hideChooseView;
-(void)reloadSection1;

@end
