//
//  SHMallChooseDetailVC.h
//  shcem
//
//  Created by huangdeyu on 2016/11/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHMallChooseDetailVC : UIViewController<UIViewControllerTransitioningDelegate>
-(instancetype)initWithData:(NSArray *)data currentSelectedIDs:(NSMutableDictionary *)dic  keys:(NSString *)key title:(NSString *)title;
-(void)showChooseView;
-(void)hideChooseView;
@end
