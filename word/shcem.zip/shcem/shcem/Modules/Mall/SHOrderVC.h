//
//  OrderVC.h
//  shcem
//
//  Created by xupeipei on 2016/11/22.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHBaseViewController.h"
#import "SHMallDetailModel.h"


typedef NS_ENUM(NSInteger, SHOrderVCType) {
    SHOrderVCTypeInquery = 0,
    SHOrderVCTypeOrder = 1,
};

@interface SHOrderVC : SHBaseViewController

-(id)initWithSHMallDetailModel:(SHMallDetailModel*)mallDetailModel businessType:(SHOrderVCType)orderVCType;

@end
