//
//  OrderVC.m
//  shcem
//
//  Created by xupeipei on 2016/11/22.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHOrderVC.h"
#import <WebKit/WebKit.h>
#import <Masonry/Masonry.h>
#import "SHOrderWebViewTableViewCell.h"
#import "SHOrderViewTableViewCell.h"
#import "OrderCountTableViewCell.h"
#import "TPKeyboardAvoidingTableView.h"
#import "SHOrderWebViewModel.h"
#import "SHMallService.h"
#import "SHOrderSuccessPopupView.h"

static NSString *CountViewTableViewCellReuseIdentifier = @"CountViewTableViewCell";

@interface SHOrderVC ()<UITableViewDataSource,UITableViewDelegate,SHOrderSuccessPopupViewDelegate>

@property (strong,nonatomic) TPKeyboardAvoidingTableView *dataTB;
@property (strong,nonatomic) UIButton *nextStepButton;
@property (strong,nonatomic) UIButton *lastStepButton;
@property (strong,nonatomic) UIButton *confirmButton;

@property (assign,nonatomic) BOOL quantityNotUserInteractionEnabled;
@property (assign,nonatomic) SHOrderVCType orderVCType;
@property (assign,nonatomic) BOOL shouldSubmit;
@property (assign,nonatomic) BOOL isZhongshihua;

@property (strong,nonatomic) SHMallDetailModel *mallDetailModel;
@property (strong,nonatomic) SHOrderViewModel *orderViewModel;
@property (strong,nonatomic) SHOrderWebViewModel  *orderWebViewModel;

@property (strong,nonatomic) SHGetAndCheckExpensesModel *getAndCheckExpensesModel;
@property (strong,nonatomic) SHCreateEnquiryModel *createEnquiryModel;
@property (strong,nonatomic) SHQueryOneFirmBanlanceModel *queryOneFirmBanlanceModel;
@property (strong,nonatomic) SHOrderByLeadsModel *orderByLeadsModel;

@end

@implementation SHOrderVC

-(id)initWithSHMallDetailModel:(SHMallDetailModel*)mallDetailModel businessType:(SHOrderVCType)orderVCType{
    if (self = [super init]) {
        self.mallDetailModel = mallDetailModel;
        self.orderVCType = orderVCType;
    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.orderWebViewModel addObserver:self forKeyPath:@"orderWebViewHeight" options:NSKeyValueObservingOptionNew context:nil];
    
    [self addSubView];
    [self queryOneFirmBanlance];
}


-(void)getGAndCheckExpenses{
    if (![self checkLoginStatus]) {
        return;
    }
    
    SHQueryCondition * condition = [SHQueryCondition defaultCondition];
    condition.parameter = URL_PARAMETER_GetAndCheckExpenses(_orderViewModel.number, _orderViewModel.price, @"1", @"1", _mallDetailModel.CategoryLeafID, _mallDetailModel.BrandID, _mallDetailModel.TradeUnitNumber, _mallDetailModel.GoodsType, _mallDetailModel.FirmID, _mallDetailModel.ID);
    
    [self showProgress];
    [SHMallService getGetAndCheckExpensesWithCondition:condition callback:^(NSError *err, SHGetAndCheckExpensesModel *getAndCheckExpensesModel) {
        [self hideProgress];
        if (err == nil) {
            float price = [self.orderViewModel.price floatValue];
            float number = [self.orderViewModel.number floatValue];
            float TradeUnitNumber = [self.mallDetailModel.TradeUnitNumber floatValue];
            
            getAndCheckExpensesModel.countBatch = self.orderViewModel.number;
            getAndCheckExpensesModel.countWeight = [NSString stringWithFormat:@"%g",number*TradeUnitNumber];
            getAndCheckExpensesModel.countMoney = [NSString stringWithFormat:@"%g",price*number*TradeUnitNumber];
            
            self.getAndCheckExpensesModel = getAndCheckExpensesModel;
            [self.view sendSubviewToBack:self.nextStepButton];
            [self.dataTB reloadData];
        }else{
            [self toast:err.userInfo[@"NSLocalizedDescription"]];
        }
        
    }];
}

-(void)createEnquiry{
    if (![self checkLoginStatus]) {
        return;
    }
    
    SHUserModel * userModel = [[SHUserManager sharedManager] getUserInfoDirect];
    NSString *pushStatus =  [NSString stringWithFormat:@"%ld",(long)_orderViewModel.pushStatus];
    
    SHQueryCondition * condition = [SHQueryCondition defaultCondition];
    condition.parameter = URL_PARAMETER_CreateEnquiry(self.mallDetailModel.ID, _orderViewModel.price, _orderViewModel.number, userModel.TraderID, userModel.FirmID, userModel.UserCode,@"0", _getAndCheckExpensesModel.TwoDecimalDeposit, pushStatus);
    
    [self showProgress];
    self.shouldSubmit = YES;
    [SHMallService createEnquiryWithCondition:condition callback:^(NSError *err, SHCreateEnquiryModel *createEnquiryModel) {
        [self hideProgress];
        if (err == nil) {
            self.createEnquiryModel = createEnquiryModel;
            [self queryOneFirmBanlance];
        }else{
            [self toast:err.userInfo[@"NSLocalizedDescription"]];
        }
        
    }];
}


-(void)orderByLeads{
    if (![self checkLoginStatus]) {
        return;
    }
    
    SHUserModel * userModel = [[SHUserManager sharedManager] getUserInfoDirect];
    NSString *pushStatus =  [NSString stringWithFormat:@"%ld",(long)_orderViewModel.pushStatus];
    
    SHQueryCondition * condition = [SHQueryCondition defaultCondition];
    condition.parameter = URL_PARAMETER_OrderByLeads(userModel.UserCode, _orderViewModel.number, self.mallDetailModel.Price, userModel.TraderID, self.mallDetailModel.ID, _getAndCheckExpensesModel.TwoDecimalDeposit, userModel.FirmID, pushStatus);
    
    [self showProgress];
    self.shouldSubmit = YES;
    [SHMallService orderByLeadsModelWithCondition:condition callback:^(NSError *err, SHOrderByLeadsModel *orderByLeadsModel) {
        [self hideProgress];
        if (err == nil) {
            self.orderByLeadsModel = orderByLeadsModel;
            [self queryOneFirmBanlance];
        }else{
            [self toast:err.userInfo[@"NSLocalizedDescription"]];
        }
    }];
    
}

-(void)queryOneFirmBanlance{
    if (![self checkLoginStatus]) {
        return;
    }
    
    SHUserModel * userModel = [[SHUserManager sharedManager] getUserInfoDirect];
    
    SHQueryCondition * condition = [SHQueryCondition defaultCondition];
    condition.parameter = URL_PARAMETER_QueryOneFirmBanlance(userModel.FirmID);
    [self showProgress];
    [SHMallService queryOneFirmBanlanceModelWithCondition:condition callback:^(NSError *err, SHQueryOneFirmBanlanceModel *queryOneFirmBanlanceModel) {
        [self hideProgress];
        if (err == nil) {
            self.queryOneFirmBanlanceModel = queryOneFirmBanlanceModel;
            
            if (self.shouldSubmit) {
                [self popupOrderSuccessView];
            }
            
        }else{
            [self toast:err.userInfo[@"NSLocalizedDescription"]];
        }
    }];
}


-(void)setOrderVCType:(SHOrderVCType)orderVCType{
    _orderVCType = orderVCType;
    
    if (_orderVCType == SHOrderVCTypeInquery) {
        self.title = @"询盘";
    }else{
        self.title = @"下单";
    }
    
}

-(void)popupOrderSuccessView{
    SHOrderSuccessPopupView *orderSuccessPopupView = [[SHOrderSuccessPopupView alloc] initWithFrame:self.view.frame];
    orderSuccessPopupView.titleString = self.orderVCType == SHOrderVCTypeOrder? @"下单提交成功":@"询盘提交成功";
    orderSuccessPopupView.queryOneFirmBanlanceModel = self.queryOneFirmBanlanceModel;
    orderSuccessPopupView.getAndCheckExpensesModel = self.getAndCheckExpensesModel;
    orderSuccessPopupView.delegate = self;
    [self.view addSubview:orderSuccessPopupView];
}


-(void)addSubView{
    [self.view addSubview:self.dataTB];
    
    [self.dataTB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.view.mas_top);
        make.bottom.mas_equalTo(self.view.mas_bottom).offset(-50);
        make.left.mas_equalTo(self.view.mas_left);
        make.right.mas_equalTo(self.view.mas_right);
    }];
    
    [self.view addSubview:self.nextStepButton];
    [self.view addSubview:self.lastStepButton];
    [self.view addSubview:self.confirmButton];
    
    [self.view bringSubviewToFront:self.nextStepButton];
}

-(TPKeyboardAvoidingTableView*)dataTB{
    if (!_dataTB) {
        _dataTB = [[TPKeyboardAvoidingTableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _dataTB.backgroundColor = BACKGROUNDCOLOR_CUSTOM;
        [_dataTB setDelegate:self];
        [_dataTB setDataSource:self];
        
        [_dataTB registerClassCustom:[SHOrderWebViewTableViewCell class]];
        [_dataTB registerClassCustom:[SHOrderViewTableViewCell class]];
        [_dataTB registerClassCustom:[OrderCountTableViewCell class]];
    }
    return _dataTB;
}


-(UIButton*)nextStepButton{
    if (!_nextStepButton) {
        _nextStepButton = [[UIButton alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height-50, ScreenWidth, 50)];
        _nextStepButton.backgroundColor = COLOR_NAV_RED;
        _nextStepButton.titleLabel.textColor = [UIColor whiteColor];
        [_nextStepButton setTitle: @"下一步" forState:UIControlStateNormal];
        
        [_nextStepButton addTarget:self action:@selector(nextStepButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _nextStepButton;
}

-(UIButton*)lastStepButton{
    if (!_lastStepButton) {
        _lastStepButton = [[UIButton alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height-50, ScreenWidth/2, 50)];
        _lastStepButton.backgroundColor = LIGHTGRAY_CUSTOM;
        _lastStepButton.titleLabel.textColor = [UIColor whiteColor];
        [_lastStepButton setTitle: @"上一步" forState:UIControlStateNormal];
        
        [_lastStepButton addTarget:self action:@selector(lastStepButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _lastStepButton;
}

-(UIButton*)confirmButton{
    if (!_confirmButton) {
        _confirmButton = [[UIButton alloc] initWithFrame:CGRectMake(ScreenWidth/2, self.view.frame.size.height-50, ScreenWidth/2, 50)];
        _confirmButton.backgroundColor = COLOR_NAV_RED;
        _confirmButton.titleLabel.textColor = [UIColor whiteColor];
        [_confirmButton setTitle: @"确认提交" forState:UIControlStateNormal];
        
        [_confirmButton addTarget:self action:@selector(confirmButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _confirmButton;
}

-(SHOrderViewModel*)orderViewModel{
    if (!_orderViewModel) {
        _orderViewModel = [[SHOrderViewModel alloc] init];
        if (self.orderVCType == SHOrderVCTypeInquery) {
            _orderViewModel.goodsType = self.mallDetailModel.GoodsType;
        }else{
            _orderViewModel.goodsType = self.mallDetailModel.GoodsType;
            _orderViewModel.price = self.mallDetailModel.Price;
            _orderViewModel.orderVCType = self.orderVCType;
        }
    }
    return _orderViewModel;
}


-(SHOrderWebViewModel*)orderWebViewModel{
    if (!_orderWebViewModel) {
        _orderWebViewModel = [[SHOrderWebViewModel alloc] init];
    }
    return _orderWebViewModel;
}

-(void)nextStepButtonAction:(id)sender{
    
    NSInteger price = [self.orderViewModel.price integerValue];
    if (self.orderVCType == SHOrderVCTypeInquery && price!=0 &&  price >= [self.mallDetailModel.Price floatValue]) {
        [self toast:@"询盘价格需小于卖盘价格"];
        return;
    }
    
    NSInteger number = [self.orderViewModel.number integerValue];
    if (number < [self.mallDetailModel.MinQuantity floatValue] || number == 0) {
        [self toast:@"数量需大于等于最小交收量"];
        return;
    }
    
    if (number > [self.mallDetailModel.ResidualQuantity floatValue] || number == 0) {
        [self toast:@"数量需小于等于可售量"];
        return;
    }

    self.quantityNotUserInteractionEnabled = YES;
    [self getGAndCheckExpenses];
    
}

-(void)lastStepButtonAction:(id)sender{
    self.quantityNotUserInteractionEnabled = NO;
    [self.view bringSubviewToFront:self.nextStepButton];
    self.getAndCheckExpensesModel = nil;
    [self.dataTB reloadData];
}

-(void)confirmButtonAction:(id)sender{
    if (!self.getAndCheckExpensesModel.readeStatus) {
        NSString *type = [self.mallDetailModel.GoodsType isEqual:@"1"]? @"预售":@"现货";
        [self  toast:[NSString stringWithFormat:@"请确认已阅读并同意《%@交易规则》",type]];
        return;
    }
    
    if (self.orderVCType == SHOrderVCTypeInquery) {
        [self createEnquiry];
    }else{
        [self orderByLeads];
    }
}

-(BOOL)isZhongshihua{
    return [self.mallDetailModel.FormatSettlementMethod  isEqual:@"现货配送"]? true:false;
}

#pragma mark - SHOrderSuccessPopupViewDelegate -

-(void)SHOrderSuccessPopupViewDelegate:(id)model{
    [self.navigationController popToRootViewControllerAnimated:YES];
}


#pragma mark - UITableViewDelegate -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.getAndCheckExpensesModel? 3:2;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return section == 0? 0.01:10;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section) {
        case 0:
        {
            return self.orderWebViewModel.orderWebViewHeight;
        }
            break;
            
        case 1:
        {
            
//            现货询盘
            if (self.orderVCType == SHOrderVCTypeInquery && [self.mallDetailModel.GoodsType isEqual:@"0"]) {
                return 170;
            }else{
                return 105;
            }
            
        }
            break;
            
        default:
        {
            return [self isZhongshihua]? 130:110;
        }
            break;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.section) {
        case 0:
        {
            SHOrderWebViewTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([SHOrderWebViewTableViewCell class])];
            cell.mallDetailModel = self.mallDetailModel;
            cell.orderWebViewModel = self.orderWebViewModel;
            
            return cell;
        }
            break;
            
        case 1:
        {
            SHOrderViewTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([SHOrderViewTableViewCell class])];
            cell.userInteractionEnabled = !self.quantityNotUserInteractionEnabled;
            [cell setOrderViewModel:self.orderViewModel orderVCType:self.orderVCType];
            return cell;
        }
            break;
            
        default:
        {
            OrderCountTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([OrderCountTableViewCell class])];
            cell.isZhongshihua = [self isZhongshihua];
            cell.goodsType = [self.mallDetailModel.GoodsType isEqual:@"1"]? @"预售":@"现货";
            self.getAndCheckExpensesModel.custrans = self.queryOneFirmBanlanceModel.USERBALANCEFromOra;
            cell.getAndCheckExpensesModel = self.getAndCheckExpensesModel;
            return cell;
        }
            break;
    }
  
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark KVO

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(nullable void *)context
{
    if ([keyPath isEqualToString:@"orderWebViewHeight"]) {
        [self.dataTB reloadData];
    }
}

-(void)dealloc{
    [self.orderWebViewModel removeObserver:self forKeyPath:@"orderWebViewHeight"];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
