//
//  MallDetaiVC.m
//  shcem
//
//  Created by xupeipei on 2016/11/22.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHMallDetaiVC.h"
#import <WebKit/WebKit.h>
#import <Masonry/Masonry.h>
#import "SHOrderVC.h"
#import "SHMallService.h"
#import "SHLoginVC.h"
#import "NSString+Format.h"

@interface SHMallDetaiVC ()

@property (strong,nonatomic) WKWebView *mallDetailWebView;
@property (strong,nonatomic) UIButton *inqueryButton;
@property (strong,nonatomic) UIButton *orderButton;
@property (strong,nonatomic) UIButton *connectButton;


@property (strong,nonatomic) NSString *url;
@property (strong,nonatomic) SHMallListModel *mallListModel;

@property (strong,nonatomic) SHMallDetailModel *mallDetailModel;

@end

@implementation SHMallDetaiVC

-(id)initWithUrl:(NSString*)url{
    if (self = [super init]) {
        self.url = url;
    }
    return self;
}

-(id)initWithMallListModel:(SHMallListModel *)mallListModel{
    if (self = [super init]) {
        self.mallListModel = mallListModel;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"报盘信息";
    self.automaticallyAdjustsScrollViewInsets = false;
    
    [self getSHMallService];
}

-(void)getSHMallService{
    
    SHQueryCondition * condition = [SHQueryCondition defaultCondition];
    condition.parameter = URL_PARAMETER_MallDetailInfo([self countID]);
    
    [self showProgress];
    [SHMallService getMallDetailWithCondition:condition callback:^(NSError *err, SHMallDetailModel *mallDetailModel) {
        [self hideProgress];
        self.mallDetailModel = mallDetailModel;
        [self addSubView];
        [self addBottomButton];
    }];
}

-(void)addBottomButton{
    SHUserModel * userModel = [[SHUserManager sharedManager] getUserInfoDirect];
    BOOL leadsStatus = [self.mallDetailModel.FormatLeadsStatus isEqual:@"有效"]? true:false;
    BOOL isMine= [userModel.UserCode isEqual:self.mallDetailModel.UserCode]? true:false;
    
//    报盘有效并且不是本机构发盘可以进行询盘下单操作
    if (leadsStatus && !isMine) {
        [self.view addSubview:self.orderButton];
        [self.view addSubview:self.inqueryButton];
        
        [self.inqueryButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.view.mas_bottom).offset(-50);
            make.left.mas_equalTo(self.view.mas_left);
            make.size.mas_equalTo(CGSizeMake(ScreenWidth/2, 50));
        }];
        
        [self.orderButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.view.mas_bottom).offset(-50);
            make.left.mas_equalTo(self.inqueryButton.mas_right);
            make.size.mas_equalTo(self.inqueryButton);
        }];
        
    }else{
        [self.view addSubview:self.connectButton];
        [self.connectButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.mallDetailWebView.mas_bottom);
            make.left.mas_equalTo(self.view.mas_left);
            make.right.mas_equalTo(self.view.mas_right);
            make.height.mas_equalTo(50);
        }];
       
    }
}

-(void)addSubView{
    [self addRightButtonImageName:@"phone" title:nil];
    [self.view addSubview:self.mallDetailWebView];
    
    [self.mallDetailWebView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.view.mas_top).offset(64);
        make.left.mas_equalTo(self.view.mas_left);
        make.right.mas_equalTo(self.view.mas_right);
        make.bottom.mas_equalTo(self.view.mas_bottom).offset(-50);
    }];
}

-(WKWebView*)mallDetailWebView{
    if (!_mallDetailWebView) {
        _mallDetailWebView = [[WKWebView alloc] initWithFrame:CGRectZero];
       
        NSString *tempUrlString = self.url? self.url:[self countUrlString];
        NSURLRequest *request =[NSURLRequest requestWithURL:[NSURL URLWithString:tempUrlString]];
        [_mallDetailWebView loadRequest:request];
        
        DLog(@"%@",tempUrlString);
    }
    return _mallDetailWebView;
}


-(NSString*)countUrlString{
    NSString * token = [[SHUserManager sharedManager] getToken];
    NSString *REC_CREATETIMEShow = [self.mallDetailModel.REC_CREATETIME substringToIndex:10];
    NSDictionary *tempDic = @{
                              @"FirmShowName":self.mallListModel.FirmShowName,
                              @"REC_CREATETIMEShow":REC_CREATETIMEShow,
                              };
    
    NSString *jsonString = [NSJSONSerialization stringWithJSONObject:tempDic];
    NSString *jsonString2 = [jsonString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    NSString *urlString = [NSString stringWithFormat:@"%@/main_detail.html?ID=%@&JSON=%@&token=%@",WEBREQUESTURL,self.mallDetailModel.ID,jsonString2,token];
    return urlString;
}

-(NSString*)countID{
    if (self.url) {
        return [NSString getParamValueFromUrl:self.url paramName:@"ID"];
    }else{
        return [NSString stringWithFormat:@"%ld",(long)self.mallListModel.ID];
    }
}

-(UIButton*)connectButton{
    if (!_connectButton) {
        _connectButton = [[UIButton alloc] initWithFrame:CGRectZero];
        _connectButton.backgroundColor = COLOR_NAV_RED;
        _connectButton.titleLabel.textColor = [UIColor whiteColor];
        [_connectButton setTitle: @"联系客服" forState:UIControlStateNormal];
        [_connectButton addTarget:self action:@selector(connectButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _connectButton;
}


-(UIButton*)orderButton{
    if (!_orderButton) {
        _orderButton = [[UIButton alloc] initWithFrame:CGRectZero];
        _orderButton.backgroundColor = COLOR_NAV_RED;
        _orderButton.titleLabel.textColor = RGBCOLOR(224, 58, 64);
        _orderButton.titleLabel.font = [UIFont boldSystemFontOfSize:16];
        [_orderButton setTitle: @"下单" forState:UIControlStateNormal];
        
        [_orderButton addTarget:self action:@selector(orderButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _orderButton;
}

-(UIButton*)inqueryButton{
    if (!_inqueryButton) {
        _inqueryButton = [[UIButton alloc] initWithFrame:CGRectZero];
        _inqueryButton.backgroundColor = RGBCOLOR(50, 138, 232);
        _inqueryButton.titleLabel.textColor = [UIColor whiteColor];
        _inqueryButton.titleLabel.font = [UIFont boldSystemFontOfSize:16];
        [_inqueryButton setTitle: @"询盘" forState:UIControlStateNormal];
        
        [_inqueryButton addTarget:self action:@selector(inqueryButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    return _inqueryButton;
}

-(void)orderButtonAction:(id)sender{
    if (![self verifyAuth]) {
        return;
    }
    
    if(!self.mallDetailModel){
        return;
    }
    
    SHOrderVC *orderVC = [[SHOrderVC alloc] initWithSHMallDetailModel:self.mallDetailModel businessType:SHOrderVCTypeOrder];
    [self.navigationController pushViewController:orderVC animated:YES];
}

-(void)inqueryButtonAction:(id)sender{
    if (![self verifyAuth]) {
        return;
    }
    
    SHOrderVC *orderVC = [[SHOrderVC alloc] initWithSHMallDetailModel:self.mallDetailModel businessType:SHOrderVCTypeInquery];
    [self.navigationController pushViewController:orderVC animated:YES];
}

-(BOOL)verifyAuth{
    SHUserModel * userModel = [[SHUserManager sharedManager] getUserInfoDirect];
    if (!userModel) {
        if (!userModel) {
            [self toast:@"请登录"];
        }
        return NO;
    }
    
#ifdef REALEASE
    if (![self tradeTimeJudge]) {
        [self toast:@"交易时间为9:00-16:30"];
        return NO;
    }
#endif
    
   
    
    NSInteger TradeAuthority = userModel.TradeAuthority;
    switch (TradeAuthority){
            //0:卖
        case 0:
             [self toast:@"很抱歉，您所在的企业还未开通购买权限"];
            return NO;
            break;
            //1:买
        case 1:
            return YES;
            break;
            //2: 全部
        case 2:
            return YES;
            break;
            
        default:
        {
            [self toast:STR_HOME_TOAST_NO_PREMISSION];
            return NO;
        }
            break;
    }
    
}

-(BOOL)tradeTimeJudge{
    NSDate *nowDate = [NSDate date];
    NSDate *beginDate = [self getCustomDateWithHour:9 minute:0];
    NSDate *endDate = [self getCustomDateWithHour:16 minute:30];
    
    if ([nowDate compare:beginDate] ==NSOrderedAscending)
    {
        return NO;
    }
    
    if ([nowDate compare:endDate] == NSOrderedDescending)
    {
        return NO;
    }
    
    return YES;
}

- (NSDate *)getCustomDateWithHour:(NSInteger)hour minute:(NSInteger)minute
{
    //获取当前时间
    NSDate *currentDate = [NSDate date];
    NSCalendar *currentCalendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    
    NSInteger unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitWeekday | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond;
    
    NSDateComponents *currentComps = [currentCalendar components:unitFlags fromDate:currentDate];
    
    //设置当天的某个点
    NSDateComponents *resultComps = [[NSDateComponents alloc] init];
    [resultComps setYear:[currentComps year]];
    [resultComps setMonth:[currentComps month]];
    [resultComps setDay:[currentComps day]];
    [resultComps setHour:hour];
    [resultComps setMinute:minute];
    
    NSCalendar *resultCalendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    return [resultCalendar dateFromComponents:resultComps];
}

-(void)connectButtonAction:(id)sender{
    [self rightBTAction:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
