//
//  SHMallVC.h
//  shcem
//
//  Created by huangdeyu on 2016/11/21.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHMallVC : SHBaseViewController
@property(nonatomic,copy) NSString *showSearch;

@property(nonatomic,assign) BOOL needReaload;

@end
