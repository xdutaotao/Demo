//
//  ResultViewController.h
//  CustomTransition
//
//  Created by min on 2016/12/5.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHResultViewController : SHBaseViewController


- (void)initWithImageUrlArray:(NSArray *)imgs;

@end
