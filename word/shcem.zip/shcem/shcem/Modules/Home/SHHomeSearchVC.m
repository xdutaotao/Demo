//
//  SHHomeSearchVC.m
//  shcem
//
//  Created by min on 16/11/22.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHHomeSearchVC.h"
#import "SHMallSearchListView.h"
#import "SHMallVC.h"
#import "SHCacheManager.h"
#import "SHHTTPManager.h"
#import "SHBannerService.h"
#import "SHBaseTableView.h"
#import "SHMallListModel.h"
#import "SHMallListCellTableViewCell.h"
#import "SHRefreshHeader.h"
#import "SHLoginVC.h"
#import "SHMallDetaiVC.h"
#import "MJExtension.h"


@interface SHHomeSearchVC ()<UISearchBarDelegate, SHMallSearchListViewDelegate, UITableViewDelegate, UITableViewDataSource, SHBaseTableViewDelegate>

@property (nonatomic, strong) UISearchBar *searchBar;
@property (nonatomic, strong) NSString *searchText;
@property(nonatomic,strong)SHMallSearchListView * searchListView;
@property (nonatomic, strong) NSMutableArray *arrayHistory; //搜索历史记录
@property (nonatomic, strong) SHBaseTableView *searchTableView;
@property(nonatomic,strong) NSMutableArray<SHMallListModel *> * models;



@end

@implementation SHHomeSearchVC

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.arrayHistory = [NSMutableArray array];
        self.models = [NSMutableArray array];
        self.hidesBottomBarWhenPushed = YES;
        self.onlyShowBackArray = NO;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = WHITE;
    self.navigationItem.titleView = self.searchBar;
    for (UIView *view in self.searchBar.subviews) {
        if ([view isKindOfClass:NSClassFromString(@"UIView")] && view.subviews.count > 0) {
            [[view.subviews objectAtIndex:0] removeFromSuperview];
            break;
        }
    }
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:STR_ALERT_CANCEL style:UIBarButtonItemStylePlain target:self action:@selector(goBack)];
    [self.navigationItem setHidesBackButton:YES];
    
    [self.view addSubview:self.searchTableView];
    [self.searchListView showInView:self.view];
    [self loadSearchHistoryConditions];
}

#pragma mark - viewWillAppear
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.searchBar resignFirstResponder];
}

#pragma mark - 缓存中取搜索历史记录
- (void)loadSearchHistoryConditions{
    [[SHCacheManager shareInstance] loadFrom:NSDocumentDirectory name:SEARCH_LIST_KEY callBack:^(id dic, NSError *err) {
        if(dic){
            self.arrayHistory = [dic mutableCopy];
            if(self.arrayHistory.count == 0){
                [self.searchListView searchHide];
            }
            [self showTableView];
        }
    }];
}



#pragma mark - searchBarDelegate
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.searchBar resignFirstResponder];
}
- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    [self.searchBar resignFirstResponder];
    [self showTableView];
    return YES;
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    [self touchSearchBarOrCellThenGoToSearch];
}
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    self.searchText = searchText;
}

//点击历史搜索cell，出发搜索事件
- (void)touchSearchBarOrCellThenGoToSearch{
    [self.searchBar resignFirstResponder];
    DLog(@"%@", self.searchText);
    if(self.searchText.length > 0) {
        [self.searchTableView.mj_header beginRefreshing];
        if(![self.arrayHistory containsObject:self.searchText]) {
            if(self.arrayHistory.count < 10) {
                [self.arrayHistory insertObject:self.searchText atIndex:0];
            } else {
                [self.arrayHistory removeLastObject];
                [self.arrayHistory insertObject:self.searchText atIndex:0];
            }
            [[SHCacheManager shareInstance] saveTo:NSDocumentDirectory name:SEARCH_LIST_KEY obj:self.arrayHistory callBack:^{
                
            }];
        }
    }
}

#pragma mark - SHMallSearchListViewDelegate
- (void)clearBtnClicked{
    if(self.arrayHistory.count > 0) {
        self.arrayHistory = [NSMutableArray array];
        [self.searchListView loadData:self.arrayHistory];
        [[SHCacheManager shareInstance] saveTo:NSDocumentDirectory name:SEARCH_LIST_KEY obj:self.arrayHistory callBack:^{
            
        }];
    }
    [self.searchListView searchHide];
}
-(void)searchOverWith:(NSString *)str{
    self.searchText = str;
    self.searchBar.text = str;
    [self touchSearchBarOrCellThenGoToSearch];
}
- (void)searchHistoryScroll{
    [self.searchBar resignFirstResponder];
}

#pragma mark - 点击事件
- (void)goBack{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)showTableView{
    [self.searchListView loadData:self.arrayHistory];
    if(![self.view containsSubView:self.searchListView]){
        [self.view addSubview:self.searchListView];
    }
}
-(void)hideTableView{
    [self.searchListView hide];
}


#pragma mark - 搜索结果展示列表
- (void)showSearchList{
    if(![self.view containsSubView:self.searchTableView]){
        [self.view addSubview:self.searchTableView];
    }
}
- (void)hideSearchList{
    [self.searchTableView removeFromSuperview];
}
#pragma mark - loadSearchRequest
- (void)loadDataWithPage:(NSInteger)page{
    SHQueryCondition *condition = [SHQueryCondition defaultCondition];
    condition.parameter = URL_PARAMETER_MALL_LIST(self.searchText, @[], @(page), @15, @1, @1, @[], @[], @[], @(-1), @(-1), @[], @(-1));
    WS(weakSelf);
    [self.searchTableView getListWithPage:page condition:condition pageSize:15 successCallback:^(id objects) {
        [self hideTableView];
        NSArray * array = [SHMallListModel mj_objectArrayWithKeyValuesArray:objects];
        [weakSelf.models addObjectsFromArray:array];
        [weakSelf.searchTableView reloadData];
        [self.searchListView searchShow];
    }];
}

#pragma mark - 搜索结果列表tableviewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return  80;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return  self.models.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    SHMallListCellTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([SHMallListCellTableViewCell class])];
    if (!cell) {
        cell = [[SHMallListCellTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([SHMallListCellTableViewCell class])];
    }
    [cell loadData:self.models[indexPath.row]];
    return  cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (![SHUserManager sharedManager].isAuthed) {
        SHLoginVC * vc = [[SHLoginVC alloc] initWithEntryClass:NSStringFromClass([self class])];
        [self.navigationController pushViewController:vc animated:YES];
    }else{
        SHMallDetaiVC *mallDetaiVC = [[SHMallDetaiVC alloc] initWithMallListModel:self.models[indexPath.row]];
        mallDetaiVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:mallDetaiVC  animated:YES];
    }
}


#pragma mark - 初始化
- (UISearchBar *)searchBar{
    if(!_searchBar){
        _searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 40)];
        _searchBar.placeholder = STR_HOME_SEARCH_Placeholder;
        _searchBar.delegate = self;
        _searchBar.tintColor = COLOR_NAV_RED;
        [_searchBar becomeFirstResponder];
    }
    return _searchBar;
}
-(SHMallSearchListView *)searchListView{
    if(!_searchListView){
        _searchListView = [[SHMallSearchListView alloc] initWithFrame:CGRectMake(0, NavgationBarHeight, ScreenWidth, ScreenHeight - NavgationBarHeight)];
        _searchListView.delegate = self;
    }
    return  _searchListView;
}
- (SHBaseTableView *)searchTableView{
    if(!_searchTableView) {
        _searchTableView = [[SHBaseTableView alloc] initWithSource:self models:self.models frame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
        [_searchTableView registerClass:[SHMallListCellTableViewCell class] forCellReuseIdentifier:NSStringFromClass([SHMallListCellTableViewCell class])];
    }
    return _searchTableView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}



@end
