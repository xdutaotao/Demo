//
//  SHHomeSearchVC.h
//  shcem
//
//  Created by min on 16/11/22.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHHomeSearchVC : SHBaseViewController

@end
