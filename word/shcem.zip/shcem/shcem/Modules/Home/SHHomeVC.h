//
//  SHHomeVC.h
//  shcem
//
//  Created by huangdeyu on 2016/11/21.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHBaseViewController.h"

@protocol InfoMenuSelectDelegate <NSObject>

- (void)infoSelectUrl:(NSString *)url;

@end

@interface SHHomeVC : UIViewController


@property (nonatomic, weak)id<InfoMenuSelectDelegate>delegate;



//单元测试
@property (nonatomic, assign) BOOL testBannerRequest;

- (BOOL)isRightUrl:(NSString *)string;
- (BOOL)isRightWithRequestBannerUrl:(BOOL)banner;

@end
