//
//  SHHomeWebVC.m
//  shcem
//
//  Created by min on 16/11/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHHomeWebVC.h"
#import "SHWebView.h"
#import "SHPicView.h"
#import "SHResultViewController.h"
#import "PresentTransitioning.h"
#import "DismissTransitioning.h"
#import "InteractionTransition.h"
#import "PresentationInteractionTransition.h"
#import <SafariServices/SafariServices.h>
#import "UMSocial.h"
#import "SHLoginVC.h"



@interface SHHomeWebVC ()<SHWebViewDelegate, UIViewControllerTransitioningDelegate, UIAlertViewDelegate>

@property(nonatomic, strong) NSString *urlString;
@property (nonatomic, copy) SHWebView *webView;
@property (nonatomic, strong) SHPicView *picView;

@property (nonatomic, strong) PresentTransitioning *presentTransitioning;   //点击图片显示大图的转场动画
@property (nonatomic, strong) DismissTransitioning *dismissTransitioning;
@property (nonatomic, strong) InteractionTransition *interactionTransition;
@property (nonatomic, strong) PresentationInteractionTransition *presentationInteraction;
@property (nonatomic, strong) SHResultViewController *Resultvc;
@property (nonatomic, copy) NSString *rightBarImage;
@property (nonatomic, copy) NSString *shareTitle;
@property (nonatomic, copy) NSString *shareUrl;


@end

@implementation SHHomeWebVC

- (instancetype)initWithUrl:(NSString *)urlString title:(NSString *)title imageName:(NSString *)imageName
{
    if(self = [super init]){
        self.hidesBottomBarWhenPushed = YES;
        self.title = title;
        NSCharacterSet *set = [NSCharacterSet URLQueryAllowedCharacterSet];
        urlString = [urlString stringByAddingPercentEncodingWithAllowedCharacters:set];
        self.urlString = urlString;
        self.rightBarImage = imageName;
        self.isNeedRefresh = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = WHITE;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:self.rightBarImage] style:UIBarButtonItemStylePlain target:self action:@selector(rightBarButton)];
    [self.view addSubview:self.webView];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.picView removeFromSuperview];
}

- (void)backBarBtnClicked{
    if([self.webView.webView canGoBack]){
        [self.webView.webView goBack];
    } else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}


#pragma mark - webViewDelegate
- (void)webViewLoadUrl:(NSString *)url{
    self.urlString = url;
    
    if([url isEqualToString:[WEBREQUESTURL stringByAppendingString:WEB_MEMBER_INFO_FAIL]]){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:STR_HOME_ALERT_TITLE_REMINDER message:@"用户信息已过期，请重新登录" delegate:self cancelButtonTitle:nil otherButtonTitles:STR_ALERT_SURE, nil];
        [alert show];
    }
    DLog(@"hahahahhaha%@", url);
    
//    if([url rangeOfString:@"/rules/"].location != NSNotFound) {
//        [self.webView.progressView startLoading];
//    }
}

- (void)webViewStartLoad{
    [self.webView.progressView startLoading];
    [self showNetworkIndicator];
}
- (void)webViewFinishLoad{
    [self.webView.progressView endLoading];
    [self hideNetworkIndicator];

        [self.webView.webView evaluateJavaScript:@"document.title" completionHandler:^(id _Nullable result, NSError * _Nullable error) {
            self.shareTitle = result;
            self.shareUrl = self.urlString;
        }];
}
- (void)webViewFailLoad{
    NSString *str = self.urlString;
    if ([str rangeOfString:@"tel:"].location != NSNotFound){
        NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"telprompt://%@", TELPHONE]];
        [[UIApplication sharedApplication] openURL:url];
        return;
    }else if([[str substringFromIndex:(str.length - 3)] isEqualToString:@"jpg"] || [[str substringFromIndex:(str.length - 3)] isEqualToString:@"png"]){
        DLog(@"图片的");
        [self presentViewController:self.interactionTransition.viewController animated:YES completion:^{
            [self.Resultvc initWithImageUrlArray:[NSArray arrayWithObject:self.urlString]];
        }];
        return;
    } else if ([str indexOf:@"jpg"] || [str indexOf:@"png"]){
        [self presentViewController:self.interactionTransition.viewController animated:YES completion:^{
            [self.Resultvc initWithImageUrlArray:[NSArray arrayWithObject:self.urlString]];
        }];
    } else if ([[str componentsSeparatedByString:@"?id="][0] isEqualToString:SCANFILE]){
        [self presentViewController:self.interactionTransition.viewController animated:YES completion:^{
            [self.Resultvc initWithImageUrlArray:[NSArray arrayWithObject:self.urlString]];
        }];
    } else {
        [self.webView.failView showInView:self.webView withType:0 tips:@"加载失败"];
    }
    [self.webView.progressView endLoading];
    [self hideNetworkIndicator];
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    SHLoginVC * vc  = [[SHLoginVC alloc] initWithEntryClass:@"SHMineVC"];
    vc.isBackMine = YES;
    [self.navigationController pushViewController:vc animated:YES];
}



#pragma mark - 初始化
- (SHWebView *)webView{
    if(!_webView){
        _webView = [[SHWebView alloc] initWithFrame:self.view.bounds url:self.urlString refresh:self.isNeedRefresh height:NO];
        _webView.delegate = self;
        _webView.webView.scrollView.scrollEnabled = YES;
    }
    return _webView;
}

- (void)webviewWithImageShow:(NSArray *)imgs imageUrl:(NSArray *)imageUrls{
    self.picView = [[SHPicView alloc]initWithFrame:self.view.bounds withImgs:nil withImgUrl:imageUrls];
    self.picView.eventBlock = ^(NSString *event){
    };
    [self.navigationController.view addSubview:self.picView];
    
}


#pragma mark - 点击事件
- (void)rightBarButton{
    if([self.rightBarImage isEqualToString:@"phone"]){
        [self showCallAlert];
        return;
    }
    
    



    if([self.rightBarImage isEqualToString:@"share_blank"]){
    
        
        DLog(@"点击分享");
        
        NSString *qqShareUrl=self.shareUrl;
        NSString *wechatShareUrl=self.shareUrl;
        NSString *wechatTimelineShareUrl=self.shareUrl;
        NSString *title=@"上海化交";
        NSString *shareText=@"";
        
        if([self.title isEqualToString:WEB_GUESS_TITLE]){
            
            self.shareTitle=@"上海化交-风云竞猜";
            self.shareUrl=[WEBREQUESTURL stringByAppendingString:WEB_GUESS];
            qqShareUrl=[self.shareUrl stringByAppendingString:[NSString stringWithFormat:@"?from=qq&type=ios"]];
            wechatShareUrl=[self.shareUrl stringByAppendingString:[NSString stringWithFormat:@"?from=wechat&type=ios"]];
            wechatTimelineShareUrl=[self.shareUrl stringByAppendingString:[NSString stringWithFormat:@"?from=wechatTimeline&type=ios"]];
             shareText=self.shareTitle;
        }
        else{
            self.shareTitle=@"上海化交-新闻资讯";
             shareText=self.shareTitle;
        }
                
        [UMSocialData defaultData].extConfig.title = title;
        //qq的url
        [UMSocialData defaultData].extConfig.qqData.url = qqShareUrl;
        //微信发送朋友url
        [UMSocialData defaultData].extConfig.wechatSessionData.url = wechatShareUrl;
        //微信朋友圈url
        [UMSocialData defaultData].extConfig.wechatTimelineData.url = wechatTimelineShareUrl;
        [UMSocialSnsService presentSnsIconSheetView:self
                                       appKey:UMENG_APPKEY
                                       shareText:shareText
                                       shareImage:[UIImage imageNamed:@"shcem_icon"]
                                       shareToSnsNames:@[UMShareToWechatSession,UMShareToWechatTimeline,UMShareToSina,UMShareToQQ]
                                       delegate:(id)self
         ];
    }
}







-(void)didFinishGetUMSocialDataInViewController:(UMSocialResponseEntity *)response
{
    //根据`responseCode`得到发送结果,如果分享成功
    if(response.responseCode == UMSResponseCodeSuccess)
    {
        //得到分享到的平台名
        DLog(@"share to sns name is %@",[[response.data allKeys] objectAtIndex:0]);
    }
}
-(void)showCallAlert{
    NSString*number = TELPHONEDEAL;
    NSMutableString * str=[[NSMutableString alloc] initWithFormat:@"tel://%@", number];
    UIWebView * callWebview = [[UIWebView alloc] init];
    [callWebview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:str]]];
    [self.view addSubview:callWebview];
}


#pragma mark - 点击图片自定义转场
- (PresentTransitioning *)presentTransitioning {
    if (!_presentTransitioning) {
        _presentTransitioning = [[PresentTransitioning alloc] init];
    }
    return _presentTransitioning;
}

- (DismissTransitioning *)dismissTransitioning {
    if (!_dismissTransitioning) {
        _dismissTransitioning = [[DismissTransitioning alloc] init];
    }
    return _dismissTransitioning;
}

- (InteractionTransition *)interactionTransition {
    if (!_interactionTransition) {
        _interactionTransition = [[InteractionTransition alloc] init];
        _interactionTransition.viewController = self.presentationInteraction.destinationViewController;
        _interactionTransition.currentController = self;
    }
    return _interactionTransition;
}

- (PresentationInteractionTransition *)presentationInteraction {
    if (!_presentationInteraction) {
        _presentationInteraction = [[PresentationInteractionTransition alloc] init];
        _presentationInteraction.viewController = self;
        self.Resultvc = [[SHResultViewController alloc] init];
        self.Resultvc.transitioningDelegate = self;
        self.Resultvc.modalPresentationStyle = UIModalPresentationCustom;
        _presentationInteraction.destinationViewController = self.Resultvc;
    }
    return _presentationInteraction;
}

- (id<UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source {
    self.presentTransitioning.from = CGRectMake(ScreenWidth / 2, ScreenHeight / 2, 0, 0);
    return self.presentTransitioning;
}
- (id<UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    self.dismissTransitioning.to = CGRectMake(ScreenWidth / 2, ScreenHeight / 2, 0, 0);
    return self.dismissTransitioning;
}

- (id<UIViewControllerInteractiveTransitioning>)interactionControllerForPresentation:(id<UIViewControllerAnimatedTransitioning>)animator {
    return self.presentationInteraction.comleted ? self.presentationInteraction : nil;
}

- (id<UIViewControllerInteractiveTransitioning>)interactionControllerForDismissal:(id<UIViewControllerAnimatedTransitioning>)animator {
    
    return self.interactionTransition.comleted ? self.interactionTransition : nil;
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}



@end
