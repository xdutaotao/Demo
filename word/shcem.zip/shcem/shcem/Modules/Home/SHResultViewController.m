//
//  ResultViewController.m
//  CustomTransition
//
//  Created by min on 2016/12/5.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import "SHResultViewController.h"
#import "SHPicView.h"

@interface SHResultViewController ()
@property (nonatomic, strong) SHPicView *picView;

@end

@implementation SHResultViewController



- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)initWithImageUrlArray:(NSArray *)imgs{
    __weak SHResultViewController *weakSelf = self;
    self.picView = [[SHPicView alloc]initWithFrame:self.view.bounds withImgs:nil withImgUrl:imgs];
    self.picView.eventBlock = ^(NSString *event){
//        NSLog(@"触发事件%@",event);
        if([event isEqualToString:@"单击"]){
            [weakSelf tapView];
        }
    };
    [self.view addSubview:self.picView];
}


- (void)tapView {
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    
}



@end
