//
//  SHHomeVC.m
//  shcem
//
//  Created by huangdeyu on 2016/11/21.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHHomeVC.h"
#import "SDCycleScrollView.h"
#import "SHHomeSearchVC.h"
#import <AFNetworking/AFNetworking.h>
#import "SHBannerService.h"
#import "TXScrollLabelView.h"
#import "SHHomeCollectionViewCell.h"
#import "SHHomeWebVC.h"
#import "SHRefreshHeader.h"
#import "SHWebView.h"
#import "SHUserManager.h"
#import "SHLoginVC.h"
#import "SHBalanceDetailVC.h"
#import "SHTradeListViewController.h"
#import "SHMessageListVC.h"
#import "SHHomeNavSearchView.h"
#import "TradeSwipeListVC.h"
#import "SHMallDetaiVC.h"

#define kBanner     @"kBanner"


@interface SHHomeVC ()<SDCycleScrollViewDelegate, UICollectionViewDelegate, UICollectionViewDataSource, UIWebViewDelegate, SHWebViewDelegate, UIScrollViewDelegate, SHHomeNavSearchDelegate, UIScrollViewDelegate>

@property(nonatomic, strong) UISearchBar *searchBar;
@property (nonatomic, copy) UIScrollView *scrollView;
@property(nonatomic,strong)SDCycleScrollView * circleScrollView;
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, copy) NSMutableArray *menuArray;    //导航仪表盘 文字
@property (nonatomic, strong) NSMutableArray *menuImageArray;   //导航仪表盘 图片
@property (nonatomic, strong) NSMutableArray *menuNumberArray;  //导航仪表盘 数字
@property(nonatomic,strong) NSMutableArray<SHHomeBannerModel *> * modelBanner;
@property (nonatomic, strong) NSArray *arrayBanner;  //轮播图
@property (nonatomic, strong) NSString *noticeStr;  //公告标题
@property (nonatomic, strong) UIView  *noticeView;   //公告view
@property(nonatomic,strong) NSMutableArray<SHHomeNoticeModel *> * modelNotice;
@property (nonatomic, strong) NSMutableArray *arrayNotice;  //公告
@property (nonatomic, strong) NSString *webUrl;
@property (nonatomic, copy) SHWebView *myWebView;
@property (nonatomic, strong) TXScrollLabelView  *noticeScrollView;
@property (nonatomic, strong) NSMutableArray *arrayMutableBanner;
@property (nonatomic, strong) NSMutableArray *arrayMutableFileID;
@property (nonatomic, copy) NSString *theToken;
@property (nonatomic, assign) NSInteger TradeAuthority;
@property (nonatomic, strong) SHHomeNavSearchView *navSearchView;
@property (nonatomic, strong) UIView *statusView;

@end

@implementation SHHomeVC
- (instancetype)init{
    self = [super init];
    if (self) {
        self.menuArray = [[NSMutableArray alloc] initWithObjects:@"现货资源", @"我的交易", @"我的询盘", @"交易规则", @"化交价格", @"竞猜活动", @"化交报告", @"资金详情", nil];
        self.menuImageArray = [[NSMutableArray alloc] initWithObjects:@"list_1", @"list_2", @"list_3", @"rules", @"list_5", @"guess", @"list_7", @"list_8", nil];
        self.menuNumberArray = [[NSMutableArray alloc] initWithObjects:@"", @"", @"", @"", @"", @"1", @"", @"2", nil];
        self.modelBanner = [NSMutableArray array];
        self.arrayMutableBanner = [NSMutableArray array];
        self.arrayNotice = [NSMutableArray array];
        self.modelNotice = [NSMutableArray array];
        self.arrayMutableFileID = [NSMutableArray array];
    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];

    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.navigationController.navigationBar.hidden = YES;
    self.fd_prefersNavigationBarHidden = YES;
    [self.view addSubview:self.scrollView];
    [self.scrollView addSubview:self.statusView];
    [self.scrollView addSubview:self.circleScrollView];
    [self.scrollView addSubview:self.collectionView];
    [self.view addSubview:self.navSearchView];

    
    [self readBannerFromCache];
    [self requestNoticeData];
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status) {
            case AFNetworkReachabilityStatusReachableViaWiFi:
            case AFNetworkReachabilityStatusReachableViaWWAN:
                if (self.arrayBanner.count == 0) {
                    [self requestBannerData];
                }
                break;
            case AFNetworkReachabilityStatusNotReachable:
                [self hideProgress];
            default:
                break;
        }
    }];
}

-(void)viewDidUnload{
    
    self.noticeScrollView=nil;
    
}


#pragma mark - viewAppear
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.theToken = [[SHUserManager sharedManager]getToken];
    self.TradeAuthority = [[SHUserManager sharedManager] getUserInfoDirect].TradeAuthority;
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self.myWebView.webView evaluateJavaScript:@"javascript:removeState()" completionHandler:^(id _Nullable result, NSError * _Nullable error) {
        
    }];
}

-(void)viewDidDisappear:(BOOL)animated{
    self.noticeScrollView=nil;
}


#pragma mark - Request
- (void)requestBannerData{
    SHQueryCondition *condition = [SHQueryCondition defaultCondition];
    condition.parameter = URL_PARAMETER_MAIN_BANNER(@0, @0, BANNERCATEGORYID, BANNERNUM);
    [SHBannerService bannerWithCondition:condition callback:^(NSError *err, NSArray<SHHomeBannerModel *> *list) {
        if (err) {
            [self showError:err];
            return;
        }
        [self.modelBanner addObjectsFromArray:list];
        for (int i = 0; i < self.modelBanner.count; i++) {
            [self loadBannerData:self.modelBanner[i]];
        }
    }];
}
- (void)loadBannerData:(SHHomeBannerModel *)model{
    NSDictionary *bannerDictionary = [[NSDictionary alloc] init];
    if(model.FileID && model.InfoLinkId) {
        self.testBannerRequest = YES;
        NSString *bannerStr = [BANNERDOWNLOADURL stringByAppendingFormat:@"%ld", (long)model.FileID];
        bannerDictionary = @{@"FileID":bannerStr,@"InfoLinkId":model.InfoLinkId};
        [self.arrayMutableBanner addObject:bannerDictionary];
        [self.arrayMutableFileID addObject:bannerStr];
        self.circleScrollView.imageURLStringsGroup = self.arrayMutableFileID;
        self.arrayBanner = self.arrayMutableBanner;
        [self saveBannerData];
    } else {
        self.testBannerRequest = NO;
    }
}


- (void)requestNoticeData{
    
    [self showProgress];
    [self.scrollView addSubview:self.noticeView];
    self.myWebView.frame = CGRectMake(0, self.noticeView.origin.y + self.noticeView.height, ScreenWidth,self.view.height);
    [self.scrollView addSubview:self.myWebView];
    SHQueryCondition *condition = [SHQueryCondition defaultCondition];
    condition.parameter = URL_PARAMETER_MAIN_BANNER(@0, @0, NOTICECATEGORYID, @1);
    

    __weak typeof(self) weakSelf = self;
    __weak typeof(self.noticeScrollView) weekNoticeScrollView=self.noticeScrollView;
    
    [SHNoticeService noticeWithCondition:condition callback:^(NSError *err, NSArray<SHHomeNoticeModel *> *noticeList) {
        [weakSelf hideProgress];
        if (err) {
            [weakSelf showError:err];
            [weakSelf.scrollView.mj_header endRefreshing];
            return;
        }
        
        [weakSelf.modelNotice removeAllObjects];
        [weakSelf.modelNotice addObjectsFromArray:noticeList];
        
        for (int i = 0; i < weakSelf.modelNotice.count; i++) {
            [weakSelf loadNoticeData:weakSelf.modelNotice[i]];
        }
        
        [weakSelf.scrollView.mj_header endRefreshing];
        
        if (weakSelf.arrayNotice.count == 0) {
            weakSelf.noticeView.frame = CGRectMake(0, weakSelf.collectionView.origin.y + weakSelf.collectionView.height, ScreenWidth, 0);
            weakSelf.myWebView.frame = CGRectMake(0, weakSelf.collectionView.origin.y + weakSelf.collectionView.height, ScreenWidth,weakSelf.view.height);
        }
        else  {
            weakSelf.noticeStr = [weakSelf.arrayNotice[0] valueForKey:@"InfoTitle"];
           
            
            //__strong TXScrollLabelView * selfTXScrollLabelView=weakSelf.noticeScrollView;
            
            weekNoticeScrollView.scrollTitle = weakSelf.noticeStr;
            
            [weekNoticeScrollView beginScrolling];
            
        }
        
        
    }];

}

-(void)dealloc{
    DLog(@"test%s",__func__);
}


- (void)loadNoticeData:(SHHomeNoticeModel *)model{
    NSDictionary *dic = [[NSDictionary alloc] init];
    NSString *str = [URL_INFO_DETAIL stringByAppendingString:[NSString stringWithFormat:@"%ld", (long)model.ID]];
    dic = @{@"InfoTitle": model.InfoTitle, @"noticeURL": str};
    [self.arrayNotice addObject:dic];
}


#pragma mark - 轮播图数据缓存
-(void)saveBannerData{
    NSString * path = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
    NSString * filePath = [path stringByAppendingPathComponent:kBanner];
    if (![[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        [[NSFileManager defaultManager] createFileAtPath:filePath contents:nil attributes:nil];
    }
    if (self.arrayBanner) {
        if ([NSKeyedArchiver archiveRootObject:self.arrayBanner toFile:filePath]) {
            DLog(@"保存成功");
        }else{
            DLog(@"保存失败");
        }
    }
}
-(void)readBannerFromCache{
    NSString * path = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
    NSString * filePath = [path stringByAppendingPathComponent:kBanner];
    self.arrayBanner = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
    NSMutableArray * datas = [NSMutableArray array];
    [self.arrayBanner enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSDictionary * dic = obj;
        [datas addObject:[dic valueForKey:@"FileID"]];
    }];
    self.circleScrollView.imageURLStringsGroup = datas;
    [self requestBannerData];//从缓存加载完成后再从网络上查询一次。
}


#pragma mark - 下拉刷新
- (void)headerRefresh{
    if(self.arrayBanner.count == 0){
        [self requestBannerData];
    }
    [self.arrayNotice removeAllObjects];
    [self requestNoticeData];
    [_myWebView refreshWebViewWithUrl:[WEBREQUESTURL stringByAppendingString:WEBMAINURL]];
    DLog(@"end");
}

#pragma mark - 点击事件
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index{
    if (index < self.arrayBanner.count) {
        NSString *str = [self.arrayBanner[index] valueForKey:@"InfoLinkId"];
        SHHomeWebVC * bannerDetailVC = [[SHHomeWebVC alloc] initWithUrl:str title:@"资讯详情" imageName:@"share_blank"];
        [self.navigationController pushViewController:bannerDetailVC animated:YES];
    }
}

- (void)touchNoticeAction{
    if([self.arrayNotice[0] valueForKey:@"noticeURL"]){
        SHHomeWebVC * noticeDetailVC = [[SHHomeWebVC alloc] initWithUrl:[self.arrayNotice[0] valueForKey:@"noticeURL"] title:@"公告详情" imageName:@"share_blank"];
        [self.navigationController pushViewController:noticeDetailVC animated:YES];
    }
}

#pragma mark - collectionviewCellDelegate/Datasource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.menuArray.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    SHHomeCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    [cell loadCellData:self.menuArray[indexPath.row] withNumber:self.menuNumberArray[indexPath.row] withImage:self.menuImageArray[indexPath.row]];
    return cell;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    switch (indexPath.row) {

        case 2:
        {
            if(self.theToken){
                self.TradeAuthority=[[SHUserManager sharedManager] getUserInfoDirect].TradeAuthority;
                if(self.TradeAuthority == -1 || self.TradeAuthority == 0 || self.TradeAuthority == 3) {
                    [self toast:STR_HOME_TOAST_NO_PREMISSION];
                }
                else if(self.TradeAuthority == 1 || self.TradeAuthority == 2) {
                    [self goToOrderDetailList:@"9" withTitle:@"我的询盘"];
                }
            }
            else {
                [self shouldBeLogin];
                return;
            }
        }
            break;
        case 3:
        {
            SHHomeWebVC * vc = [[SHHomeWebVC alloc] initWithUrl:[WEBREQUESTURL stringByAppendingString:WEB_TRADE_RULES] title:@"交易规则" imageName:@"share_blank"];
            vc.isNeedRefresh = NO;
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
        case 4:
            [[NSNotificationCenter defaultCenter] postNotificationName:@"INFO_TITLE" object:[[WEBREQUESTURL stringByAppendingString:WEBINFOURL] stringByAppendingString:@"?title=InfoPrice"]];
            break;
        case 5:
            {
                if(self.theToken){
                    NSString *url=[WEBREQUESTURL stringByAppendingString:WEB_GUESS];
                
                    url=[url stringByAppendingString:[NSString stringWithFormat:@"?traderID=%@",[[SHUserManager sharedManager] getUserInfoDirect].TraderID]];
                    url=[url stringByAppendingString:[NSString stringWithFormat:@"&UserCode=%@",[[SHUserManager sharedManager] getUserInfoDirect].UserCode]];
                    url=[url stringByAppendingString:[NSString stringWithFormat:@"&TraderName=%@",[[SHUserManager sharedManager] getUserInfoDirect].TraderName]];
                    url=[url stringByAppendingString:[NSString stringWithFormat:@"&Mobile=%@",[[SHUserManager sharedManager] getUserInfoDirect].Mobile]];
                    url=[url stringByAppendingString:[NSString stringWithFormat:@"&token=%@",self.theToken]];
                   
                    SHHomeWebVC * vc = [[SHHomeWebVC alloc] initWithUrl:url title:WEB_GUESS_TITLE imageName:@"share_blank"];
                    vc.isNeedRefresh = NO;
                    [self.navigationController pushViewController:vc animated:YES];
                }
                else
                    [self shouldBeLogin];
            }
            break;
        case 6:
            [[NSNotificationCenter defaultCenter] postNotificationName:@"INFO_TITLE" object:[[WEBREQUESTURL stringByAppendingString:WEBINFOURL] stringByAppendingString:@"?title=InfoReport"]];
            break;
        case 7:
            if (![SHUserManager sharedManager].isAuthed) {
                [self shouldBeLogin];
                return;
            }
            SHUserModel * userModel = [[SHUserManager sharedManager] getUserInfoDirect];
            NSInteger TradeAuthority = userModel.TradeAuthority;
            if (TradeAuthority !=0 && TradeAuthority !=1 && TradeAuthority !=2) {
                [self toast:STR_HOME_TOAST_NO_PREMISSION];
                return;
            }
            SHBalanceDetailVC *balanceDetail = [[SHBalanceDetailVC alloc] init];
            [self.navigationController pushViewController:balanceDetail animated:YES];
            break;
    }
    NSArray * arr = @[@1,@2,@"",@"",@3,@"",@3,@""];
    [self.tabBarController setSelectedIndex:[arr[indexPath.row] integerValue]];
}

#pragma mark - scrollviewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    //通过偏移量控制顶部搜索框透明度
    CGFloat contentOffSetY = scrollView.contentOffset.y;
    if(contentOffSetY >= 0 && contentOffSetY < StatusBarHeight){
        self.navSearchView.hidden = NO;
        [self.navSearchView setViewColorWithColor:[UIColor clearColor]];
        self.navSearchView.alpha = 1;
        self.navSearchView.textField.alpha = 0.4;
        self.navSearchView.textField.textColor = WHITE;
        self.navSearchView.textPlaceholder.textColor = WHITE;
        self.navSearchView.textLeftView.image = [UIImage imageNamed:@"Magnifier-white"];
    } else if (contentOffSetY >= StatusBarHeight && contentOffSetY <= ((157 * ScreenWidth) / 375 - 64)){
        self.navSearchView.hidden = NO;
        [self.navSearchView setViewColorWithColor:COLOR_NAV_RED];
        self.navSearchView.alpha = contentOffSetY / ((157 * ScreenWidth) / 375 - 64);
        self.navSearchView.textField.alpha = contentOffSetY / ((157 * ScreenWidth) / 375 - 64);
        self.navSearchView.textField.textColor = WHITE;
        self.navSearchView.textPlaceholder.textColor = RGBCOLOR(196, 196, 196);
        self.navSearchView.textLeftView.image = [UIImage imageNamed:@"Magnifier"];
    } else if (contentOffSetY > ((157 * ScreenWidth) / 375 - 64)){
        self.navSearchView.hidden = NO;
        [self.navSearchView setViewColorWithColor:COLOR_NAV_RED];
        self.navSearchView.alpha = 1;
        self.navSearchView.textField.alpha = 1;
        self.navSearchView.textField.textColor = [UIColor grayColor];
        self.navSearchView.textPlaceholder.textColor = RGBCOLOR(196, 196, 196);
        self.navSearchView.textLeftView.image = [UIImage imageNamed:@"Magnifier"];
    } else if (contentOffSetY < 0){
        self.navSearchView.hidden = YES;
    }
}

#pragma mark - 初始化
- (UIScrollView *)scrollView{
    if(!_scrollView){
        _scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
        SHRefreshHeader *refreshHeader = [SHRefreshHeader headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
        [refreshHeader setup];
        _scrollView.mj_header = refreshHeader;
        _scrollView.contentSize = CGSizeMake(ScreenWidth, 1024);
        _scrollView.delegate = self;
    }
    return _scrollView;
}
- (UIView *)statusView{
    if(!_statusView){
        _statusView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, StatusBarHeight)];
        _statusView.backgroundColor = [UIColor blackColor];
    }
    return _statusView;
}
-(SDCycleScrollView *)circleScrollView{
    if (!_circleScrollView) {
        CGFloat height = (233 * ScreenWidth) / 495;
        DLog(@"轮播图的高度%.f", height);
        _circleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, StatusBarHeight, ScreenWidth, height) delegate:self placeholderImage:[UIImage imageNamed:@"placeHolder"]];
        _circleScrollView.pageControlAliment = SDCycleScrollViewPageContolAlimentCenter;
        _circleScrollView.currentPageDotColor = COLOR_NAV_RED;
        _circleScrollView.autoScrollTimeInterval = 3;
        
        //顶部加渐变
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 80)];
        [_circleScrollView addSubview:view];
        CAGradientLayer *gradientLayer = [CAGradientLayer layer];
        gradientLayer.frame = CGRectMake(0, 0, ScreenWidth, 80);
        [view.layer addSublayer:gradientLayer];
        gradientLayer.startPoint = CGPointMake(0, 0);
        gradientLayer.endPoint = CGPointMake(0, 1);
        gradientLayer.colors = @[(__bridge id)[UIColor blackColor].CGColor,
                                 (__bridge id)[UIColor clearColor ].CGColor];
        gradientLayer.locations = @[@(0.0f), @(1.0f)];
        view.alpha = 0.8;
    }
    return _circleScrollView;
}
- (UICollectionView *)collectionView{
    if(!_collectionView){
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.itemSize = CGSizeMake(ScreenWidth / 4  - 20, ScreenWidth / 4 - 20);
        layout.sectionInset = UIEdgeInsetsMake(0.f, 10, 0, 10);
        
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, self.circleScrollView.height + StatusBarHeight, ScreenWidth, (ScreenWidth / 4  - 20) * 2 + 10) collectionViewLayout:layout];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.backgroundColor = WHITE;
        _collectionView.scrollEnabled=NO;
        //注册单元格，头部，尾部视图
        [_collectionView registerClass:[SHHomeCollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
    }
    return _collectionView;
}

- (UIView *)noticeView{
    if(!_noticeView){
        _noticeView = [[UIView alloc] initWithFrame:CGRectMake(0, self.collectionView.origin.y + self.collectionView.height + 10, ScreenWidth, 40)];
        
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(25, 13, 50, 14)];
        [_noticeView addSubview:imageView];
        imageView.image = [UIImage imageNamed:@"main_announce"];
        
        UIView *theView = [[UIView alloc] initWithFrame:CGRectMake(80, 0, ScreenWidth - 70, 40)];
        [self.noticeView addSubview:theView];
        
        
        self.noticeScrollView = [TXScrollLabelView scrollWithTitle:@"  " type:3 velocity:3 options:UIViewAnimationOptionTransitionFlipFromTop];
        self.noticeScrollView.frame = CGRectMake(0, 0, ScreenWidth, 40);
        [theView addSubview:self.noticeScrollView];
        self.noticeScrollView.tx_centerX  = ScreenWidth * 0.5;
        self.noticeScrollView.scrollInset = UIEdgeInsetsMake(0, 10, 0, 10);
        self.noticeScrollView.scrollSpace = 10;
        self.noticeScrollView.font = [UIFont systemFontOfSize:13];
        self.noticeScrollView.textAlignment = NSTextAlignmentLeft;
        self.noticeScrollView.scrollTitleColor = [UIColor blackColor];
        self.noticeScrollView.backgroundColor = [UIColor whiteColor];
        self.noticeScrollView.layer.cornerRadius = 5;
        
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 1)];
        [_noticeView addSubview:lineView];
        lineView.backgroundColor = COLOR_LINE;

        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = self.noticeScrollView.bounds;
        button.backgroundColor = [UIColor clearColor];
        [theView addSubview:button];
        [button addTarget:self action:@selector(touchNoticeAction) forControlEvents:UIControlEventTouchUpInside];
        
      
    }
    return _noticeView;
}

- (SHWebView *)myWebView{
    if(!_myWebView){
        NSString *str = [WEBREQUESTURL stringByAppendingString:WEBMAINURL];
        NSString *strToken = [NSString stringWithFormat:@"?token=%@", self.theToken];
        _myWebView = [[SHWebView alloc] initWithFrame:CGRectMake(0, self.noticeView.origin.y + self.noticeView.height, ScreenWidth,self.view.height) url:[str stringByAppendingString:strToken] refresh:NO height:YES];
        _myWebView.delegate = self;
        _myWebView.webView.scrollView.scrollEnabled = NO;
    }
    return _myWebView;
}
- (SHHomeNavSearchView *)navSearchView{
    if(!_navSearchView){
        _navSearchView = [[SHHomeNavSearchView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 64)];
        _navSearchView.delegate = self;
        [self.navSearchView setViewColorWithColor:[UIColor clearColor]];
        self.navSearchView.alpha = 1;
    }
    return _navSearchView;
}


#pragma mark - SHWebViewDelegate

-(WKWebView *)webView:(WKWebView *)webView createWebViewWithConfiguration:(WKWebViewConfiguration *)configuration forNavigationAction:(WKNavigationAction *)navigationAction windowFeatures:(WKWindowFeatures *)windowFeatures
{
    if (!navigationAction.targetFrame.isMainFrame) {
        [webView loadRequest:navigationAction.request];
    }
    return nil;
}


- (void)webViewLoadUrl:(NSString *)url{
    if([url isEqualToString:[WEBREQUESTURL stringByAppendingString:WEBMAINURL]]){
//        decisionHandler(WKNavigationActionPolicyCancel);
    }
    else if ([url isEqualToString:[WEBREQUESTURL stringByAppendingString:@"/key?ID=-1"]]){
        [self.myWebView.webView stopLoading];
        [self.tabBarController setSelectedIndex:1];
    }
    else if([[url componentsSeparatedByString:@"?"][0] isEqualToString:[WEBREQUESTURL stringByAppendingString:@"/mall_detail.html"]]) {
        
        [self.myWebView.webView stopLoading];
        
        if(self.theToken) {
            
            if([[url componentsSeparatedByString:@"token"][1] isEqualToString:@"=(null)"]) {
                url=[[url substringToIndex:url.length - 6] stringByAppendingString:self.theToken];
            }
            
            SHMallDetaiVC *mallDetailVC = [[SHMallDetaiVC alloc] initWithUrl:url];
            mallDetailVC.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:mallDetailVC animated:YES];
            
        } else {
            [self shouldBeLogin];
        }
        
    }
    else if ([url isEqualToString:[WEBREQUESTURL stringByAppendingString:@"/key?ID=-2"]]){
        [self.myWebView.webView stopLoading];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:STR_HOME_ALERT_TITLE_REMINDER
                                                                    message:STR_HOME_ALERT_MESSAGE_SNP
                                                                    delegate:self
                                                                    cancelButtonTitle:nil
                                                                    otherButtonTitles:STR_ALERT_SURE, nil];
        [alert show];
    }
}
- (void)webViewStartLoad{
    [self.myWebView.progressView startLoading];
    [self showNetworkIndicator];
}
- (void)webViewFinishLoad{
    [self.myWebView.progressView endLoading];
    [self hideNetworkIndicator];
    
    _scrollView.contentSize = CGSizeMake(ScreenWidth, self.scrollView.height+self.statusView.height+self.circleScrollView.height+self.collectionView.height+2);
    self.scrollView.height=self.myWebView.frame.size.height<self.scrollView.height?self.myWebView.frame.size.height:self.scrollView.height;
}

- (void)webViewFailLoad{
//    [self.myWebView.failView showInView:self.myWebView withType:0 tips:@"加载失败"];
    [self.myWebView.progressView endLoading];
    [self hideNetworkIndicator];
}

- (void)shouldBeLogin{
    SHLoginVC *login = [[SHLoginVC alloc] initWithEntryClass:NSStringFromClass([self class])];
    [self.navigationController pushViewController:login animated:YES];
}
- (void)goToOrderDetailList:(NSString *)type withTitle:(NSString *)title{
    TradeListVCInitModel *tradeListVCInitModel = [[TradeListVCInitModel alloc] init];    tradeListVCInitModel.tradeStatusArray = @[];
    tradeListVCInitModel.sellStatus = 0;
    tradeListVCInitModel.title =  @"我的询盘";
    tradeListVCInitModel.tradeType = [@"9" intValue];
    tradeListVCInitModel.queryType = @[@"1",@"1",@"1"];
    tradeListVCInitModel.goodsTypeArray = @[@"0",@"1",@"21"];
    tradeListVCInitModel.TradeTmptIdArray = @[@"0",@"1",@"0"];
    
    TradeSwipeListVC *pushVC = [[TradeSwipeListVC alloc] initWithTradeListVCInitModel:tradeListVCInitModel];
    pushVC.hidesBottomBarWhenPushed = YES;
    pushVC.title = @"我的询盘";
    [self.navigationController pushViewController:pushVC animated:YES];
}

#pragma mark - homeNavSearchDelegate
- (void)homeSearchClick:(UIButton *)button{
    SHHomeSearchVC *searchVC = [[SHHomeSearchVC alloc]init];
    [self.navigationController pushViewController:searchVC animated:YES];
}
- (void)homeNavMessageClick{
    if ([SHUserManager sharedManager].isAuthed) {
        SHUserModel * userModel = [[SHUserManager sharedManager] getUserInfoDirect];
        NSInteger TradeAuthority = userModel.TradeAuthority;
        if (TradeAuthority !=0 && TradeAuthority !=1 && TradeAuthority !=2) {
            [self toast:STR_HOME_TOAST_NO_PREMISSION];
            return;
        }
        SHMessageListVC * vc = [[SHMessageListVC alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }else{
        [self shouldBeLogin];
    }
}

#pragma -mark 单元测试
- (BOOL)isRightUrl:(NSString *)string{
    if(string.length > 10) {
        return YES;
    } else {
        return NO;
    }
}
- (BOOL)isRightWithRequestBannerUrl:(BOOL)banner{
    if(banner == YES) {
        return YES;
    } else {
        return NO;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
