//
//  SHHomeWebVC.h
//  shcem
//
//  Created by min on 16/11/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SHHomeWebVC : SHBaseViewController

- (instancetype)initWithUrl:(NSString *)urlString title:(NSString *)title imageName:(NSString *)imageName;
@property (nonatomic, assign) BOOL isNeedRefresh;



@end
