//
//  UIViewController+SH.m
//  Frey
//
//  Created by huangdeyu on 16/2/24.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import "UIViewController+SH.h"
#import "MBProgressHUD.h"

@implementation UIViewController (SH)
-(void)clearAllBgColor{
    for (UIView * subView in self.view.subviews) {
        subView.backgroundColor = [UIColor clearColor];
    }
}
- (void)showNetworkIndicator{
    UIApplication* app=[UIApplication sharedApplication];
    app.networkActivityIndicatorVisible=YES;
}
- (void)hideNetworkIndicator{
    UIApplication* app=[UIApplication sharedApplication];
    app.networkActivityIndicatorVisible=NO;
}

- (void)showProgress{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
}

- (void)hideProgress{
    
    
   // [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
 [MBProgressHUD hideHUDForView:self.view animated:YES];
}

-(void)showError:(NSError *)error{
    if (error) {
        if ([error.domain isEqualToString:NSURLErrorDomain]) {
            switch (error.code) {
                case -1009:
                    [self toast:@"网络连接失败"];
                    break;
                case -999:
                    DLog(@"任务被取消");
                    break;
                default:
                    [self toast:@"连接服务器失败"];
                    break;
            }
        }
        else if([error.domain isEqualToString:SHCEM_NET_ERROR_DOMAIN]){
            if (error.localizedDescription.length > 10) {
                [self toast:error.localizedDescription duration:2.5];
            }else{
                [self toast:error.localizedDescription];
            }
        }else{
            [self toast:@"连接服务器失败"];
        }
    }
}


- (void)toast:(NSString *)text{
    if (text == nil || text.length == 0 ) {
        text = @"服务器未返回数据";
    }
    [self toast:text duration:1.5];
}

- (void)toast:(NSString *)text duration:(NSTimeInterval)duration{
   // if ([MBProgressHUD HUDForView:self.view] == nil) {
        MBProgressHUD* hud=[MBProgressHUD showHUDAddedTo:self.view animated:YES];
        hud.userInteractionEnabled = NO;
        hud.detailsLabel.font = [UIFont systemFontOfSize:14];
        hud.detailsLabel.text = [NSString  stringWithFormat:@" %@ ",text];
        hud.margin=10.f;
        hud.removeFromSuperViewOnHide=YES;
        hud.mode=MBProgressHUDModeText;
        [hud hideAnimated:YES afterDelay:duration];
  //  }
}

- (void)runInMainQueue:(void (^)())queue{
    dispatch_async(dispatch_get_main_queue(), queue);
}

- (void)runInGlobalQueue:(void (^)())queue{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), queue);
}

- (void)runAfterSecs:(float)secs block:(void (^)())block{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(secs * NSEC_PER_SEC)), dispatch_get_main_queue(), block);
}
@end
