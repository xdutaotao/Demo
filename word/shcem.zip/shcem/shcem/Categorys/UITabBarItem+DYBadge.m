//
//  UITabBarItem+DYBadge.m
//  Frey
//
//  Created by huangdeyu on 16/5/23.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import "UITabBarItem+DYBadge.h"
#import <objc/runtime.h>

@interface UITabBarItem()
@property(nonatomic,strong) UIView * redPotView;
@end

@implementation UITabBarItem (DYBadge)
+(void)load{
    Method sourceMethod  = class_getInstanceMethod([self class], @selector(setBadgeValue:));
    Method exchangeMethod = class_getInstanceMethod([self class], @selector(dy_setBadgeValue:));
    method_exchangeImplementations(sourceMethod, exchangeMethod);
}
#pragma mark - 关联对象
static char * redPointKey;
-(void)setRedPotView:(UIView *)redPotView{
    objc_setAssociatedObject(self, redPointKey, redPotView, OBJC_ASSOCIATION_RETAIN);
}
-(UIView *)redPotView{
    return objc_getAssociatedObject(self, redPointKey);
}


-(void) dy_setBadgeValue:(NSString *)value{
    if ([value isEqualToString:@""]) {
        UIView * bgView = [self valueForKey:@"_view"];
        if (!self.redPotView) {
            self.redPotView = [[UIView alloc] init];
            self.redPotView.backgroundColor = [UIColor redColor];
            self.redPotView.frame = CGRectMake(0, 0, 8, 8);
            self.redPotView.center = CGPointMake(bgView.frame.size.width * 0.5 + 15, bgView.center.y-15);
            self.redPotView.layer.cornerRadius = 4;
            self.redPotView.layer.masksToBounds = YES;
        }else{
            [self.redPotView removeFromSuperview];
        }
        [bgView addSubview:self.redPotView];
    }else{
        [self dy_setBadgeValue:value];
    }
}

-(void)listAllProperty{
    unsigned int numIvars; //成员变量个数
    Ivar *vars = class_copyIvarList([self class], &numIvars);
    NSString *key=nil;
    for(int i = 0; i < numIvars; i++) {
        Ivar thisIvar = vars[i];
        key = [NSString stringWithUTF8String:ivar_getName(thisIvar)];  //获取成员变量的名字
        NSLog(@"variable name :%@", key);
        key = [NSString stringWithUTF8String:ivar_getTypeEncoding(thisIvar)]; //获取成员变量的数据类型
        NSLog(@"variable type :%@", key);
    }
    free(vars);
}

@end
