//
//  CustomSettings.m
//  shcem
//
//  Created by xupeipei on 2017/3/14.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "CustomSettings.h"



@implementation CustomSettings

+(CustomSettings*)sharedCustomSettings{
    
    static CustomSettings *defaultInstance = nil;
    static dispatch_once_t predicate;
    
    dispatch_once(&predicate, ^{
        defaultInstance = [[self alloc] init];
    });
    
    return defaultInstance;
    
}

-(void)setChangeDescriptionEnable:(BOOL)changeDescriptionEnable{
    _changeDescriptionEnable = changeDescriptionEnable;
    
    [NSDictionary changeDescription];
    [NSArray changeDescription];
    [NSObject changeDescription];
}


@end
