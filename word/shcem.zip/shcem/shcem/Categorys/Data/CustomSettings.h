//
//  CustomSettings.h
//  shcem
//
//  Created by xupeipei on 2017/3/14.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSArray+changeDescription.h"
#import "NSDictionary+changeDescription.h"
#import "NSObject+changeDescription.h"

@interface CustomSettings : NSObject

+(CustomSettings*)sharedCustomSettings;

//打开或关闭方法 po [CustomSettings sharedCustomSettings].logSendDataEnable = true/false
//是否打印请求发送数据
@property (nonatomic,assign) BOOL logSendDataEnable;
//是否打印请求返回数据
@property (nonatomic,assign) BOOL logReceiveDataEnable;
//是否将对象Log的Unicode编码为中文编码 包括NSArray NSDictionary NSObject
@property (nonatomic,assign) BOOL changeDescriptionEnable;

@end
