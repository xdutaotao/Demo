//
//  NSObject+changeDescription.m
//  shcem
//
//  Created by xupeipei on 2017/3/13.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "NSObject+changeDescription.h"
#import <objc/runtime.h>

@implementation NSObject (changeDescription)

+(void)load{
#ifdef DEBUG
    [self changeDescription];
#endif
}

+(void)changeDescription{
    Method m1 = class_getInstanceMethod([self class], @selector(description));
    Method m2 = class_getInstanceMethod([self class], @selector(my_description));
    method_exchangeImplementations(m1, m2);
}

-(NSString *)my_description {
    NSString *className = NSStringFromClass([self class]);
    if ([className hasSuffix:@"Model"]) {
        NSMutableDictionary *dictionary = [NSMutableDictionary dictionary];
        
        uint count;
        objc_property_t *properties = class_copyPropertyList([self class], &count);
        
        for (int i = 0; i<count; i++) {
            objc_property_t property = properties[i];
            NSString *name = @(property_getName(property));
            id value = [self valueForKey:name]?:@"nil";
            [dictionary setObject:value forKey:name];
        }
        
        free(properties);
        NSString *desString = [NSString stringWithFormat:@"<%@: %p> -- %@",[self class],self,dictionary];
        return desString;

    }else{
        return [self my_description];
    }
}

@end
