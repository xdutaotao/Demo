//
//  NSArray+changeDescription.m
//  shcem
//
//  Created by xupeipei on 2017/3/13.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "NSArray+changeDescription.h"
#import <objc/runtime.h>

@implementation NSArray (changeDescription)

+(void)load{
#ifdef DEBUG
    [self changeDescription];
#endif
}

+(void)changeDescription{
    Method m1 = class_getInstanceMethod([self class], @selector(description));
    Method m2 = class_getInstanceMethod([self class], @selector(my_description));
    method_exchangeImplementations(m1, m2);
    
    Method m3 = class_getInstanceMethod([self class], @selector(descriptionWithLocale:));
    Method m4 = class_getInstanceMethod([self class], @selector(my_descriptionWithLocale:));
    method_exchangeImplementations(m3, m4);
}

-(NSString*)my_description{
    NSString *desc = [self my_description];
    desc = [NSString stringWithCString:[desc cStringUsingEncoding:NSUTF8StringEncoding] encoding:NSNonLossyASCIIStringEncoding];
    return desc? desc:[self my_description];
}

-(NSString*)my_descriptionWithLocale:(id)locale{
    NSString *desc = [self my_descriptionWithLocale:locale];
    desc = [NSString stringWithCString:[desc cStringUsingEncoding:NSUTF8StringEncoding] encoding:NSNonLossyASCIIStringEncoding];
    return desc? desc:[self my_descriptionWithLocale:locale];
}


@end
