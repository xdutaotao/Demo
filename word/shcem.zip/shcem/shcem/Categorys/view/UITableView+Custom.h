//
//  UITableView+Custom.h
//  shcem
//
//  Created by xupeipei on 2017/3/15.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableView (Custom)

-(void)registerClassCustom:(Class)cellClass;

@end
