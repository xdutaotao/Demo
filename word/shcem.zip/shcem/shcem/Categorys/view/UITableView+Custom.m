//
//  UITableView+Custom.m
//  shcem
//
//  Created by xupeipei on 2017/3/15.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "UITableView+Custom.h"

@implementation UITableView (Custom)

+(void)load{
    [[UITableView appearance] setBackgroundColor:BACKGROUNDCOLOR_CUSTOM];
}

-(void)registerClassCustom:(Class)cellClass{
    [self registerClass:[cellClass class] forCellReuseIdentifier:NSStringFromClass([cellClass class])];
}

@end
