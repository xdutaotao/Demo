//
//  UIViewController+Custom.m
//  shcem
//
//  Created by xupeipei on 2017/3/17.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "UIViewController+Custom.h"
#import <objc/runtime.h>

@implementation UIViewController (Custom)

+(void)load{
#ifdef DEBUG
    [self changeFunction];
#endif
}

+(void)changeFunction{
    Method m1 = class_getInstanceMethod([self class], @selector(viewWillAppear:));
    Method m2 = class_getInstanceMethod([self class], @selector(my_viewWillAppear:));
    method_exchangeImplementations(m1, m2);
    
    Method m3 = class_getInstanceMethod([self class], NSSelectorFromString(@"dealloc"));
    Method m4 = class_getInstanceMethod([self class], @selector(my_dealloc));
    method_exchangeImplementations(m3, m4);
}


-(void)my_viewWillAppear:(BOOL)animated{
    DLog(@"\n\n\n%@   显示了\n\n\n",NSStringFromClass([self class]));
    [self my_viewWillAppear:animated];
}

-(void)my_dealloc{
    DLog(@"\n\n\n%@   释放了\n\n\n",NSStringFromClass([self class]));
    [self my_dealloc];
}

@end
