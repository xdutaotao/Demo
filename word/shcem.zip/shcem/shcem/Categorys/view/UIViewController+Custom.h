//
//  UIViewController+Custom.h
//  shcem
//
//  Created by xupeipei on 2017/3/17.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (Custom)

@end
