//
//  NSString+Format.h
//  shcem
//
//  Created by xupeipei on 2016/12/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Format)

//保留1位小数 并且去掉末尾的0
+(NSString*)keepOneDecimalPlaces:(NSString*)paString;
//保留两位小数
+(NSString*)keepTwoDecimalPlaces:(NSString*)paString;

+(NSString*)keepSixDecimalPlaces:(NSString*)paString;

+(NSString *)countNumAndChangeformat:(NSString *)num;

+ (NSString *)getParamValueFromUrl:(NSString *)url paramName:(NSString *)paramName;

@end
