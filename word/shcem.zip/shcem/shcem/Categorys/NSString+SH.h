//
//  NSString+SH.h
//  Frey
//
//  Created by huangdeyu on 16/2/24.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import <Foundation/Foundation.h>
//数字
#define NUM @"0123456789"
//字母
#define ALPHA @"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
//数字和字母
#define ALPHANUM @"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"

@interface NSString (SH)
/**将字典以合理的方式显示出来
 */
+(NSString *)logDic:(NSDictionary *)dic;

/**汉语转拼音
 */
- (NSString *)transformToPinyin;
/**这个汉语转拼音效果更佳
 */
-(NSString*)transform;
- (BOOL)isAllEngNumAndSpecialSign;

- (NSInteger) indexOf:(NSString *)text;
- (NSString *) stringFromMD5;
- (BOOL)isEmpty;
- (NSDate * )toDateWithFormat:(NSString*)formatStr;
- (NSComparisonResult)versionStringCompare:(NSString *)other;

- (BOOL)isLetterOrNumber;

- (BOOL)isLetter;

- (BOOL)isNumber;

- (BOOL)isEmail;

- (BOOL)isPhoneNumber;

- (BOOL)isUrl;

-(NSString *)timeDistance;
@end
