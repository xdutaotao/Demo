//
//  NSJSONSerialization+SH.h
//  Frey
//
//  Created by huangdeyu on 16/2/24.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSJSONSerialization (SH)
+ (nullable NSString *)stringWithJSONObject:(nonnull id)JSONObject;
+ (nullable id)objectWithJSONString:(nonnull NSString *)JSONString;
+ (nullable id)objectWithJSONData:(nonnull NSData *)JSONData;

+ (nullable NSString *)stringWithJSONObject2:(nonnull id)JSONObject;
@end
