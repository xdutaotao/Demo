//
//  NSString+Format.m
//  shcem
//
//  Created by xupeipei on 2016/12/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "NSString+Format.h"

@implementation NSString (Format)

+(NSString*)keepOneDecimalPlaces:(NSString*)paString{
    if (![paString isKindOfClass:[NSString class]]) {
        return @"0";
    }
    
    double paFloat = [paString doubleValue];
    double paFloat2 = floor(paFloat*10+0.5)/10;
    NSString *desString = [NSString stringWithFormat:@"%.1lf", paFloat2];
    desString = [NSString stringWithFormat:@"%g", desString.doubleValue];
    return desString;
}

+(NSString*)keepTwoDecimalPlaces:(NSString*)paString{
    double paFloat = [paString doubleValue];
    double paFloat2 = floor(paFloat*100+0.5)/100;
    NSString *desString = [NSString stringWithFormat:@"%.2lf", paFloat2];
    return desString;
}

+(NSString*)keepSixDecimalPlaces:(NSString*)paString{
    double paFloat = [paString doubleValue];
    NSString *desString = [NSString stringWithFormat:@"%.6lf", paFloat];
    return desString;
}


+(NSString *)countNumAndChangeformat:(NSString *)num
{
    if (![num isKindOfClass:[NSString class]]) {
        return @"";
    }
    
    //整数
    NSString* str11;
    //小数点之后的数字
    NSString* str22;
    
    if ([num containsString:@"."]) {
        NSArray* array = [num componentsSeparatedByString:@"."];
        
        str11 = array[0];
        str22 = array[1];
        
    }else{
        
        str11 = num;
    }
    
    
    int count = 0;
    long long int a = str11.longLongValue;
    while (a != 0)
    {
        count++;
        a /= 10;
    }
    NSMutableString *string = [NSMutableString stringWithString:str11];
    NSMutableString *newstring = [NSMutableString string];
    while (count > 3) {
        count -= 3;
        NSRange rang = NSMakeRange(string.length - 3, 3);
        NSString *str = [string substringWithRange:rang];
        [newstring insertString:str atIndex:0];
        [newstring insertString:@"," atIndex:0];
        [string deleteCharactersInRange:rang];
    }
    [newstring insertString:string atIndex:0];
    
    if ([num containsString:@"."]) {
        //包含小数点
        //返回的数字
        NSString* str33;
        
        if (str22.length>0) {
            //小数点后面有数字
            str33 = [NSString stringWithFormat:@"%@.%@",newstring,str22];
        }else{
            //没有数字
            str33 = [NSString stringWithFormat:@"%@",newstring];
        }
        return str33;
        
    }else{
        
        //不包含小数点
        return newstring;
    }
    
}

+ (NSString *)getParamValueFromUrl:(NSString *)url paramName:(NSString *)paramName
{
    if (![paramName hasSuffix:@"="]) {
        paramName = [NSString stringWithFormat:@"%@=", paramName];
    }
    
    NSString *str = nil;
    NSRange   start = [url rangeOfString:paramName];
    if (start.location != NSNotFound) {
        // confirm that the parameter is not a partial name match
        unichar  c = '?';
        if (start.location != 0) {
            c = [url characterAtIndex:start.location - 1];
        }
        if (c == '?' || c == '&' || c == '#') {
            NSRange     end = [[url substringFromIndex:start.location + start.length] rangeOfString:@"&"];
            NSUInteger  offset = start.location + start.length;
            str = end.location == NSNotFound ?
            [url substringFromIndex:offset] :
            [url substringWithRange:NSMakeRange(offset, end.location)];
            str = [str stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        }
    }
    return str;
}

@end
