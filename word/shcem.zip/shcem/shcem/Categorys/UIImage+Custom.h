//
//  UIImage+addtions.h
//  OA
//
//  Created by wangyu on 15/11/25.
//  Copyright © 2015年 wangyu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Custom)

//修复图片方向问题
+(UIImage *)fixOrientation:(UIImage *)aImage;

//根据颜色构建图片
+(UIImage *)createImageWithColor:(UIColor *)color;



@end
