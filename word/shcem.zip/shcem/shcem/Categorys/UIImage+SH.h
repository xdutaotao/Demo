//
//  UIImage+SH.h
//  Frey
//
//  Created by huangdeyu on 16/2/24.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (SH)
+ (UIImage *)resizeImage:(UIImage *)image toSize:(CGSize)newSize;

+ (UIImage *)roundImage:(UIImage *)image toSize:(CGSize)size radius:(float)radius;

+ (UIImage *)imageWithColor:(UIColor *)color;

+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size radius:(CGFloat)radius;
@end
