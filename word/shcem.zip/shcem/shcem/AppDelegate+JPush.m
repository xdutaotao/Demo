//
//  AppDelegate+JPush.m
//  shcem
//
//  Created by huangdeyu on 2016/12/28.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "AppDelegate+JPush.h"
#import "SHBaseTabarController.h"
#import "SHInfoVC.h"
#import "SHHomeWebVC.h"
// iOS10注册APNs所需头 件
#ifdef NSFoundationVersionNumber_iOS_9_x_Max
#import <UserNotifications/UserNotifications.h>
#endif
#define JPUSH_APP_KEY @"8cafe832a02419772f7e8d21"

@implementation AppDelegate (JPush)

-(void)setupJPushWithOptions:(NSDictionary *)launchOptions{
    // Required
    // notice: 3.0.0及以后版本注册可以这样写，也可以继续 旧的注册 式
    JPUSHRegisterEntity * entity = [[JPUSHRegisterEntity alloc] init];
    entity.types = JPAuthorizationOptionAlert|JPAuthorizationOptionBadge|JPAuthorizationOptionSound;
    if ([[UIDevice currentDevice].systemVersion floatValue] >= 8.0) {
        // 可以添加 定义categories
        // NSSet<UNNotificationCategory *> *categories for iOS10 or later
        // NSSet<UIUserNotificationCategory *> *categories for iOS8 and iOS9
    }
    [JPUSHService registerForRemoteNotificationConfig:entity delegate:self];
    //channel 渠道默认是 app store
    //apsForProduction  0:开发证书 1:生产证书
#ifdef DEBUG
    [JPUSHService setupWithOption:launchOptions appKey:JPUSH_APP_KEY
                          channel:@"UAT"
                 apsForProduction:0
            advertisingIdentifier:nil];
#else
    [JPUSHService setLogOFF];
    [JPUSHService setupWithOption:launchOptions appKey:JPUSH_APP_KEY
                          channel:@"App Store"
                 apsForProduction:1
            advertisingIdentifier:nil];
    
#endif
    
    //2.1.9版本新增获取registration id block接口。
    [JPUSHService registrationIDCompletionHandler:^(int resCode, NSString *registrationID) {
        if(resCode == 0){
            DLog(@"registrationID获取成功：%@",registrationID);
        }
        else{
            DLog(@"registrationID获取失败，code：%d",resCode);
        }
    }];



}

// iOS 10 Support
- (void)jpushNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(NSInteger)
                                                                                                                                                 )completionHandler {
    NSDictionary * userInfo = notification.request.content.userInfo;
    
    UNNotificationRequest *request = notification.request; // 收到推送的请求
    UNNotificationContent *content = request.content; // 收到推送的消息内容
    
    NSNumber *badge = content.badge;  // 推送消息的角标
    NSString *body = content.body;    // 推送消息体
    UNNotificationSound *sound = content.sound;  // 推送消息的声音
    NSString *subtitle = content.subtitle;  // 推送消息的副标题
    NSString *title = content.title;  // 推送消息的标题
    
    if([notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
        [JPUSHService handleRemoteNotification:userInfo];
        DLog(@"iOS10 前台收到远程通知:%@", userInfo);
        [[SHUserManager sharedManager] updateUnreadCount:^(NSError *err, id responseObject) {
        }];
       // [rootViewController addNotificationCount];
        
    }
    else {
        // 判断为本地通知
        DLog(@"iOS10 前台收到本地通知:{\nbody:%@，\ntitle:%@,\nsubtitle:%@,\nbadge：%@，\nsound：%@，\nuserInfo：%@\n}",body,title,subtitle,badge,sound,userInfo);
    }
    completionHandler(UNNotificationPresentationOptionBadge|UNNotificationPresentationOptionSound|UNNotificationPresentationOptionAlert); // 需要执行这个方法，选择是否提醒用户，有Badge、Sound、Alert三种类型可以设置
}
// iOS 10 Support
- (void)jpushNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)
                                                                                                                                                            ())completionHandler {
    NSDictionary * userInfo = response.notification.request.content.userInfo;
    UNNotificationRequest *request = response.notification.request; // 收到推送的请求
    UNNotificationContent *content = request.content; // 收到推送的消息内容
    
    NSNumber *badge = content.badge;  // 推送消息的角标
    NSString *body = content.body;    // 推送消息体
    UNNotificationSound *sound = content.sound;  // 推送消息的声音
    NSString *subtitle = content.subtitle;  // 推送消息的副标题
    NSString *title = content.title;  // 推送消息的标题
    
    if([response.notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
        [JPUSHService handleRemoteNotification:userInfo];
        DLog(@"iOS10 收到远程通知:%@", userInfo);
        [[SHUserManager sharedManager] updateUnreadCount:^(NSError *err, id responseObject) {
        }];
        
        
        if([userInfo valueForKey:@"infoid"] !=nil){
        
            SHBaseTabarController *baseTabBar = (SHBaseTabarController *)self.window.rootViewController;
            SHHomeWebVC *webVC = [[SHHomeWebVC alloc] initWithUrl:[NSString stringWithFormat:@"%@%@",URL_INFO_DETAIL,[userInfo valueForKey:@"infoid"]] title:@"资讯详情" imageName:@"share_blank"];
            [baseTabBar.viewControllers[baseTabBar.selectedIndex] pushViewController:webVC animated:YES];
        
        }
        // [rootViewController addNotificationCount];
    }else {
        // 判断为本地通知
        DLog(@"iOS10 收到本地通知:{\nbody:%@，\ntitle:%@,\nsubtitle:%@,\nbadge：%@，\nsound：%@，\nuserInfo：%@\n}",body,title,subtitle,badge,sound,userInfo);
    }
    completionHandler();  // 系统要求执行这个方法
}




@end
