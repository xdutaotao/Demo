//
//  AppDelegate+U_Share.h
//  shcem
//
//  Created by xupeipei on 2016/11/29.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (U_Share)


-(void)UMengTrack;

- (void)UMengSocialTrack;



@end
