//
//  SHRefreshHeader.m
//  shcem
//
//  Created by huangdeyu on 2016/11/22.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHRefreshHeader.h"
#import "Masonry.h"

@interface SHRefreshHeader()
@property(nonatomic,strong) UIImageView * arrowView;
@property(nonatomic,strong) UIActivityIndicatorView * loadingView;
@property(nonatomic,strong)  UILabel *lastUpdatedTimeLabel;
@property(nonatomic,strong) UILabel * stateLabel;
@property(nonatomic,strong)UIImageView * bgImageView;

@end

@implementation SHRefreshHeader

-(void)setup{
    self.height += 20;
    [self insertSubview:self.bgImageView atIndex:0];
    self.bgImageView.frame = CGRectMake(ScreenWidth* 0.5 - 111, 0, 223, 33);
    self.lastUpdatedTimeLabel.frame = CGRectMake(0, 50, ScreenWidth, 15);
    self.stateLabel.frame = CGRectMake(0, 35, ScreenWidth, 15);
    self.arrowView.frame = CGRectMake(ScreenWidth*0.5 - 80, 30, 15, 40);
    self.loadingView.center = self.arrowView.center;
}
-(void)prepare{
    [super prepare];
    self.activityIndicatorViewStyle = UIActivityIndicatorViewStyleGray;
}
- (void)setState:(MJRefreshState)state
{
    MJRefreshCheckState
    // 重新设置key（重新显示时间）
    self.lastUpdatedTimeKey = self.lastUpdatedTimeKey;
    // 根据状态做事情
    if (state == MJRefreshStateIdle) {
        self.stateLabel.text = @"下拉可以刷新";
        if (oldState == MJRefreshStateRefreshing) {
            self.arrowView.transform = CGAffineTransformIdentity;
            [UIView animateWithDuration:MJRefreshSlowAnimationDuration animations:^{
                self.loadingView.alpha = 0.0;
            } completion:^(BOOL finished) {
                // 如果执行完动画发现不是idle状态，就直接返回，进入其他状态
                if (self.state != MJRefreshStateIdle) return;
                self.loadingView.alpha = 1.0;
                [self.loadingView stopAnimating];
                self.arrowView.hidden = NO;
            }];
        } else {
            [self.loadingView stopAnimating];
            self.arrowView.hidden = NO;
            [UIView animateWithDuration:MJRefreshFastAnimationDuration animations:^{
                self.arrowView.transform = CGAffineTransformIdentity;
            }];
        }
    } else if (state == MJRefreshStatePulling) {
        self.stateLabel.text = @"松开立即刷新";
        [self.loadingView stopAnimating];
        self.arrowView.hidden = NO;
        [UIView animateWithDuration:MJRefreshFastAnimationDuration animations:^{
            self.arrowView.transform = CGAffineTransformMakeRotation(0.000001 - M_PI);
        }];
    } else if (state == MJRefreshStateRefreshing) {
        self.stateLabel.text = @"正在刷新中...";
        self.loadingView.alpha = 1.0; // 防止refreshing -> idle的动画完毕动作没有被执行
        [self.loadingView startAnimating];
        self.arrowView.hidden = YES;
    }
    [self layoutIfNeeded];
}

#pragma mark key的处理
- (void)setLastUpdatedTimeKey:(NSString *)lastUpdatedTimeKey
{
    [super setLastUpdatedTimeKey:lastUpdatedTimeKey];
    // 如果label隐藏了，就不用再处理
    if (self.lastUpdatedTimeLabel.hidden) return;
    NSDate *lastUpdatedTime = [[NSUserDefaults standardUserDefaults] objectForKey:lastUpdatedTimeKey];
    // 如果有block
    if (self.lastUpdatedTimeText) {
        self.lastUpdatedTimeLabel.text = self.lastUpdatedTimeText(lastUpdatedTime);
        return;
    }
    if (lastUpdatedTime) {
        // 1.获得年月日
        NSCalendar *calendar = [self currentCalendar];
        NSUInteger unitFlags = NSCalendarUnitYear| NSCalendarUnitMonth | NSCalendarUnitDay |NSCalendarUnitHour |NSCalendarUnitMinute;
        NSDateComponents *cmp1 = [calendar components:unitFlags fromDate:lastUpdatedTime];
        NSDateComponents *cmp2 = [calendar components:unitFlags fromDate:[NSDate date]];
        
        // 2.格式化日期
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        if ([cmp1 day] == [cmp2 day]) { // 今天
            formatter.dateFormat = @"今天 HH:mm";
        } else if ([cmp1 year] == [cmp2 year]) { // 今年
            formatter.dateFormat = @"MM-dd HH:mm";
        } else {
            formatter.dateFormat = @"yyyy-MM-dd HH:mm";
        }
        NSString *time = [formatter stringFromDate:lastUpdatedTime];
        // 3.显示日期
        self.lastUpdatedTimeLabel.text = [NSString stringWithFormat:@"最后更新：%@", time];
    } else {
        self.lastUpdatedTimeLabel.text = @"最后更新：无记录";
    }
    [self layoutIfNeeded];
}
- (NSCalendar *)currentCalendar {
    if ([NSCalendar respondsToSelector:@selector(calendarWithIdentifier:)]) {
        return [NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian];
    }
    return [NSCalendar currentCalendar];
}


#pragma mark -初始化
-(UIImageView *)arrowView{
    if (!_arrowView) {
        UIImage *image = [UIImage imageNamed:@"arrow"];
        UIImageView *arrowView = [[UIImageView alloc] initWithImage:image];
        //   arrowView.contentMode = UIViewContentModeScaleAspectFit;
        [self addSubview:_arrowView = arrowView];
    }
    return _arrowView;
}

- (UIActivityIndicatorView *)loadingView
{
    if (!_loadingView) {
        UIActivityIndicatorView *loadingView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:self.activityIndicatorViewStyle];
        loadingView.hidesWhenStopped = YES;
        [self addSubview:_loadingView = loadingView];
    }
    return _loadingView;
}
- (UILabel *)lastUpdatedTimeLabel
{
    if (!_lastUpdatedTimeLabel) {
        [self addSubview:_lastUpdatedTimeLabel = [[UILabel alloc] init] ];
        [_lastUpdatedTimeLabel setFont:[UIFont systemFontOfSize:12]];
        [_lastUpdatedTimeLabel setTextColor:[UIColor lightGrayColor]];
        _lastUpdatedTimeLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _lastUpdatedTimeLabel;
}
-(UILabel *)stateLabel{
    if (!_stateLabel) {
        _stateLabel = [[UILabel alloc] init];
        [self addSubview:_stateLabel];
        //  _stateLabel.textColor = [UIColor grayColor];
        [_stateLabel setFont:[UIFont systemFontOfSize:13]];
        _stateLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _stateLabel;
}
-(UIImageView *)bgImageView{
    if (!_bgImageView) {
        _bgImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"hiddenImage"]];
    }
    return _bgImageView;
}

@end
