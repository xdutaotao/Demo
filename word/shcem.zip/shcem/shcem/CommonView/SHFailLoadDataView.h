//
//  SHFailLoadDataView.h
//  Frey
//
//  Created by huangdeyu on 16/3/30.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHFailLoadDataView : UIView
/**
 *type : 显示类型,0:加载失败。1：暂无数据。
*/
//-(void)showWithType:(NSInteger)type tips:(NSString *)tips;


-(void)showInView:(UIView *)view withType:(NSInteger)type tips:(NSString *)tips;
-(void)hideView;
-(void)showWithType:(NSInteger)type tips:(NSString *)tips;
@end
