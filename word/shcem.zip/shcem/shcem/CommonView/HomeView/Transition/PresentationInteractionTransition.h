//
//  PresentationInteractionTransition.h
//  CustomTransition
//
//  Created by yan on 2016/12/7.
//  Copyright © 2016年 yan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PresentationInteractionTransition : UIPercentDrivenInteractiveTransition

@property (nonatomic, strong) UIViewController *viewController;
@property (nonatomic, strong) UIViewController *destinationViewController;
@property (nonatomic, assign, readonly) BOOL comleted;

@end
