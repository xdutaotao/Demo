//
//  DismissTransitioning.h
//  CustomTransition
//
//  Created by yan on 2016/12/5.
//  Copyright © 2016年 yan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface DismissTransitioning : NSObject <UIViewControllerAnimatedTransitioning>

@property (nonatomic, assign) CGRect to;

@end
