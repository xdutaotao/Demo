//
//  InteractionTransition.m
//  CustomTransition
//
//  Created by yan on 2016/12/7.
//  Copyright © 2016年 yan. All rights reserved.
//

#import "InteractionTransition.h"

@interface InteractionTransition ()

@property (nonatomic, assign) CGPoint start;
@property (nonatomic, assign) CGFloat percent;

@end

@implementation InteractionTransition

- (void)setViewController:(UIViewController *)viewController {
    _viewController = viewController;
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panView:)];
    [viewController.view addGestureRecognizer:pan];
}

- (void)panView:(UIPanGestureRecognizer *)gestureRecognizer {
    switch (gestureRecognizer.state) {
        case UIGestureRecognizerStateBegan: {
            self.start = [gestureRecognizer translationInView:gestureRecognizer.view];
            _comleted = YES;
            [self.viewController dismissViewControllerAnimated:YES completion:^{
                
            }];
            break;
        }
        case UIGestureRecognizerStateChanged: {
            CGPoint point = [gestureRecognizer translationInView:gestureRecognizer.view];
            self.percent = (point.y - self.start.y) / 200;
            self.percent = fminf(fmaxf(self.percent, 0.0f), 1.0f);
            [self updateInteractiveTransition:self.percent];
            CGFloat scale = 0.9 + self.percent / 10;
            self.currentController.view.layer.transform = CATransform3DMakeScale(scale, scale, scale);
            break;
        }
        case UIGestureRecognizerStateCancelled: {
            _comleted = NO;
            [self cancelInteractiveTransition];
            break;
        }
        case UIGestureRecognizerStateEnded: {
            _comleted = NO;
            if (self.percent > 0.5f) {
                [self finishInteractiveTransition];
                [UIView animateWithDuration:0.3 animations:^{
                    self.currentController.view.layer.transform = CATransform3DMakeScale(1.0, 1.0, 1.0);
                }];
            } else {
                [self cancelInteractiveTransition];
                [UIView animateWithDuration:0.3 animations:^{
                    self.currentController.view.layer.transform = CATransform3DMakeScale(0.9, 0.9, 0.9);
                }];
            }
            self.percent = 0.0f;
            break;
        }
        default:
            break;
    }
}

@end
