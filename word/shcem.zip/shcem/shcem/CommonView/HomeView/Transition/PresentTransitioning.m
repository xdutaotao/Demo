//
//  PresentTransitioning.m
//  CustomTransition
//
//  Created by yan on 2016/12/5.
//  Copyright © 2016年 yan. All rights reserved.
//

#import "PresentTransitioning.h"

@interface PresentTransitioning ()

@end

@implementation PresentTransitioning


- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.3;
}

- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    UIViewController *fromVC = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    UIViewController *toVC = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
//    UIView * containerView = [transitionContext containerView];
    UIView *toView = toVC.view;
    UIView *snapshot = [toVC.view snapshotViewAfterScreenUpdates:YES];
    UIView *viewBg = [[UIView alloc] initWithFrame:toVC.view.bounds];
    viewBg.alpha = 0.0;
    viewBg.backgroundColor = [UIColor blackColor];
    snapshot.frame = self.from;
    snapshot.backgroundColor = [UIColor blackColor];
    CGRect finalFrame = [transitionContext finalFrameForViewController:toVC];
    toView.hidden = YES;
    toView.backgroundColor = [UIColor blackColor];
    [transitionContext.containerView addSubview:toView];
    [transitionContext.containerView addSubview:viewBg];
    [transitionContext.containerView addSubview:snapshot];
    [UIView animateKeyframesWithDuration:[self transitionDuration:transitionContext] delay:0 options:UIViewKeyframeAnimationOptionCalculationModeCubic animations:^{
        snapshot.frame = finalFrame;
        viewBg.alpha = 0.7;
        if (![transitionContext isInteractive]) {
            fromVC.view.layer.transform = CATransform3DMakeScale(0.9, 0.9, 0.9);
        }
    } completion:^(BOOL finished) {
        toView.hidden = NO;
        [snapshot removeFromSuperview];
        [viewBg removeFromSuperview];
        [transitionContext completeTransition:![transitionContext transitionWasCancelled]];
    }];
//    [containerView addSubview:toVC.view];
//    toVC.view.backgroundColor = [UIColor colorWithWhite:0.8 alpha:0.6];
//    toVC.view.alpha = 0;
//    [UIView animateWithDuration:[self transitionDuration:transitionContext] animations:^{
//        toVC.view.alpha = 1;
//        [(ResultViewController *)toVC showPic];
//    } completion:^(BOOL finished) {
//         [transitionContext completeTransition:![transitionContext transitionWasCancelled]];
//    }];
}

@end
