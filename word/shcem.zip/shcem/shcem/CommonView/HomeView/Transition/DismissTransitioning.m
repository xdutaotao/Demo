//
//  DismissTransitioning.m
//  CustomTransition
//
//  Created by yan on 2016/12/5.
//  Copyright © 2016年 yan. All rights reserved.
//

#import "DismissTransitioning.h"

@implementation DismissTransitioning

- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.3;
}

- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    UIViewController *toVC = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    UIViewController *fromVC = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    UIView *fromView = fromVC.view;
    UIView *snapshot = [fromVC.view snapshotViewAfterScreenUpdates:YES];
    UIView *viewBg = [[UIView alloc] initWithFrame:fromVC.view.bounds];
    viewBg.backgroundColor = [UIColor blackColor];
    viewBg.alpha = 0.7f;
    snapshot.frame = fromView.frame;
    snapshot.backgroundColor = [UIColor blackColor];
    fromView.hidden = YES;
    [transitionContext.containerView addSubview:fromView];
    [transitionContext.containerView addSubview:viewBg];
    [transitionContext.containerView addSubview:snapshot];
    [UIView animateKeyframesWithDuration:[self transitionDuration:transitionContext] delay:0 options:UIViewKeyframeAnimationOptionCalculationModeCubic animations:^{
        if (![transitionContext isInteractive]) {
            toVC.view.layer.transform = CATransform3DMakeScale(1.0, 1.0, 1.0);
        }
        viewBg.alpha = 0.0f;
        snapshot.frame = self.to;
    } completion:^(BOOL finished) {
        fromView.hidden = NO;
        [snapshot removeFromSuperview];
        [viewBg removeFromSuperview];
        [transitionContext completeTransition:![transitionContext transitionWasCancelled]];
    }];
}


@end
