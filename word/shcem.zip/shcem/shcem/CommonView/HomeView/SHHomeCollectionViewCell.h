//
//  SHHomeCollectionViewCell.h
//  shcem
//
//  Created by min on 16/11/23.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHHomeCollectionViewCell : UICollectionViewCell

@property (nonatomic, strong) UIImageView *navImageView;
@property (nonatomic, strong) UILabel *navLabel;
@property (nonatomic, strong) NSString *navNumber;

- (void)loadCellData:(NSString *)title withNumber:(NSString *)number withImage:(NSString *)imageName;

@end
