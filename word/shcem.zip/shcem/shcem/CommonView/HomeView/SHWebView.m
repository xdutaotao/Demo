//
//  SHWebView.m
//  shcem
//
//  Created by min on 16/11/29.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHWebView.h"


@interface SHWebView()<WKNavigationDelegate, WKUIDelegate>

@property (nonatomic, copy) NSString *urlString;
@property (nonatomic, assign) BOOL isRefresh;
@property (nonatomic, assign) BOOL isNeedHeight;


@end

@implementation SHWebView

- (instancetype)initWithFrame:(CGRect)frame url:(NSString *)urlString refresh:(BOOL)isRefresh height:(BOOL)isNeedHeight
{
    if (self = [super initWithFrame:frame]) {
        self.urlString = urlString;
        self.isRefresh = isRefresh;
        self.isNeedHeight = isNeedHeight;
        [self addSubview:self.webView];
        [self.webView.subviews[0] addSubview:self.progressView];
    }
    return self;
}


#pragma mark - WKNavigationDelegate
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation{
    [self.delegate webViewStartLoad];
}
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
    [self.delegate webViewFinishLoad];
    if(self.isNeedHeight){
        [webView.scrollView addObserver:self forKeyPath:@"contentSize" options:NSKeyValueObservingOptionNew context:nil];
    }
    [self.webView.scrollView.mj_header endRefreshing];
    
    //h5页面，获取页面中图片的url
    NSString *js = @"function addImgClickEvent() { \
    var imgs = document.getElementsByTagName('img'); \
    for (var i = 0; i < imgs.length; ++i) { \
    var img = imgs[i]; \
    img.onclick = function () { \
    window.location.href = 'hyb-image-preview:' + this.src; \
    }; \
    } \
    }";
    // 注入JS代码
    [webView evaluateJavaScript:js completionHandler:^(id _Nullable result, NSError * _Nullable error) {
        
    }];
    // 执行所注入的JS代码
    [webView evaluateJavaScript:@"addImgClickEvent();" completionHandler:^(id _Nullable result, NSError * _Nullable error) {
        
    }];
    
    
}
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error{
    [self.delegate webViewFailLoad];
    DLog(@"加载失败%@", error);
}
-(void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler
{
    decisionHandler(WKNavigationActionPolicyAllow);
    //获取原始图片的URL
    if([navigationAction.request.URL.scheme hasPrefix:@"hyb-image-preview"]){
        NSString *src = [navigationAction.request.URL.absoluteString stringByReplacingOccurrencesOfString:@"hyb-image-preview" withString:@""];
        if(src.length > 0){
            NSString *srcStr = [src substringFromIndex:1];
            if([[srcStr substringFromIndex:(srcStr.length - 3)] isEqualToString:@"jpg"] || [[srcStr substringFromIndex:(srcStr.length - 3)] isEqualToString:@"png"]){
                [self.delegate webViewLoadUrl:srcStr];
            }
            else if([srcStr indexOf:@"jpg"] || [srcStr indexOf:@"png"]){
                [self.delegate webViewLoadUrl:srcStr];
            }
            else {
                NSString *str =  [src componentsSeparatedByString:@"id="][1];
                NSString *strUrl = [BANNERDOWNLOADURL stringByAppendingString:str];
                [self.delegate webViewLoadUrl:strUrl];
            }
        }
        return;
    } else {
        NSString * url = [NSString stringWithFormat:@"%@", navigationAction.request.URL];
        [self.delegate webViewLoadUrl:url];
    }
}




#pragma mark - 观察者计算webview高度，针对首页
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context{
    if(self.isNeedHeight){
        if ([keyPath isEqualToString:@"contentSize"]) {
            [self.webView evaluateJavaScript:@"document.body.offsetHeight" completionHandler:^(id Result, NSError * error) {
                //            DLog(@"Result->%@", Result);
                [self webView:self.webView theHeight:[Result floatValue]];
                

            }];
        }
    }
}
- (void)dealloc{
    if(self.isNeedHeight){
        [self.webView.scrollView removeObserver:self forKeyPath:@"contentSize"];
    }
}
- (void)webView:(WKWebView *)webView theHeight:(CGFloat)height{
    CGRect newFrame = webView.frame;
    newFrame.size.height = height;
    webView.frame = newFrame;
}

#pragma mark - WKUIDelegate 解决alert弹出问题
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler{
    completionHandler();
    UIAlertView *customAlert = [[UIAlertView alloc] initWithTitle:nil message:message delegate:nil cancelButtonTitle:STR_ALERT_SURE otherButtonTitles:nil];
    [customAlert show];
}






#pragma mark - 刷新
- (void)refreshWebViewWithUrl:(NSString *)url{
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]];
}
- (void)refreshAction{
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.urlString]]];
}


#pragma mark - 初始化
- (WKWebView *)webView{
    if(!_webView){
        _webView = [[WKWebView alloc] initWithFrame:self.bounds];
        _webView.navigationDelegate = self;
        _webView.UIDelegate = self;
        [_webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.urlString]]];
        
        if(self.isRefresh){
            SHRefreshHeader *refreshHeader = [SHRefreshHeader headerWithRefreshingTarget:self refreshingAction:@selector(refreshAction)];
            [refreshHeader setup];
            _webView.scrollView.mj_header = refreshHeader;
        }
    }
    return _webView;
}
- (SHActivityProgressView *)progressView{
    if(!_progressView){
        _progressView = [[SHActivityProgressView alloc] initWithFrame:CGRectMake(0, 0, 10, 5)];
    }
    return _progressView;
}
-(SHFailLoadDataView *)failView{
    if (!_failView) {
        _failView = [[SHFailLoadDataView alloc] initWithFrame:self.bounds];
    }
    return _failView;
}




@end
