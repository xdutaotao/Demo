//
//  SHHomeNavSearchView.m
//  shcem
//
//  Created by min on 17/2/17.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "SHHomeNavSearchView.h"

@interface SHHomeNavSearchView ()<UITextFieldDelegate>


@property (nonatomic, strong) UIButton *msgBtn;
@property (nonatomic, strong) UIView *statusView;
@property (nonatomic, strong) UIColor *thenavBackColor;


@end


@implementation SHHomeNavSearchView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.alpha = self.backAlpha;
        [self addSubview:self.statusView];
        [self addSubview:self.textField];
        [self addSubview:self.textLeftView];
        [self addSubview:self.textPlaceholder];
        [self addSubview:self.msgBtn];
    }
    return self;
}

- (void)setViewColorWithColor:(UIColor *)color{
    self.backgroundColor = color;
    self.thenavBackColor = color;
}

#pragma mark - 点击事件
- (void)searchMsgClick{
    DLog(@"点击了消息");
    [self.delegate homeNavMessageClick];
}
- (void)searchBarClicked:(UIButton*)button{
    [self.delegate homeSearchClick:button];
}

#pragma mark - 初始化

-(UITextField *)textField{
    if (!_textField) {
        _textField = [[UITextField alloc] initWithFrame:CGRectMake(10, StatusBarHeight + 7, ScreenWidth - 50, 30)];
        _textField.backgroundColor = WHITE;
        _textField.alpha = 0.4;
        _textField.layer.cornerRadius = 3.0;
        _textField.layer.masksToBounds = YES;
        [_textField setFont:[UIFont systemFontOfSize:14]];

        UIView *view = [[UIView alloc] initWithFrame:_textField.bounds];
        [_textField addSubview:view];
        [view.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([obj isKindOfClass:[UITextField class]]) {
                obj.userInteractionEnabled =NO;
                *stop = YES;
            }
        }];
        UIButton * buttonOnSearch = [UIButton buttonWithType:UIButtonTypeSystem];
        buttonOnSearch.frame = _textField.bounds;
        [_textField addSubview:buttonOnSearch];
        [buttonOnSearch addTarget:self action:@selector(searchBarClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _textField;
}
- (UIImageView *)textLeftView{
    if(!_textLeftView){
        _textLeftView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Magnifier-white"]];
        _textLeftView.frame = CGRectMake(19, self.textField.origin.y+9, 13, 13);
    }
    return _textLeftView;
}
- (UILabel *)textPlaceholder{
    if(!_textPlaceholder){
        _textPlaceholder = [[UILabel alloc] initWithFrame:CGRectMake(40, self.textField.origin.y, self.textField.width - 60, self.textField.height)];
        _textPlaceholder.text = STR_HOME_SEARCH_Placeholder;
        _textPlaceholder.textColor = WHITE;
        _textPlaceholder.font = [UIFont systemFontOfSize:14];
    }
    return _textPlaceholder;
}


- (UIButton *)msgBtn{
    if(!_msgBtn){
        _msgBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _msgBtn.frame = CGRectMake(ScreenWidth - 40, _textField.origin.y, 40, 40);
        [_msgBtn setImage:[UIImage imageNamed:@"message"] forState:UIControlStateNormal];
             _msgBtn.imageEdgeInsets = UIEdgeInsetsMake(-5, 0, 5, 0);
        [_msgBtn addTarget:self action:@selector(searchMsgClick) forControlEvents:UIControlEventTouchUpInside];
    }
    return _msgBtn;
}
- (UIView *)statusView{
    if(!_statusView) {
        _statusView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, StatusBarHeight)];
        _statusView.backgroundColor = self.thenavBackColor;
    }
    return _statusView;
}




@end
