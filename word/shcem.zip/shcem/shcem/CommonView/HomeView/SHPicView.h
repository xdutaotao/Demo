//
//  SHPicView.h
//  shcem
//
//  Created by min on 16/12/12.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SDWebImageManager.h"
#import "UIImageView+WebCache.h"

@class XHPicView;

typedef void(^XHPicBlock)(NSString *event);

@interface SHPicView : UIView

@property (nonatomic,copy) XHPicBlock eventBlock;

-(instancetype)initWithFrame:(CGRect)frame withImgs:(NSArray *)imgs withImgUrl:(NSArray *)imgUrls;

@end

@class PicCell;

typedef void(^HiddenBlcok)(NSString *gest);

@interface PicCell : UICollectionViewCell

@property (nonatomic,copy) HiddenBlcok myBlock;

-(void)createUIWithImage:(UIImage *)image ImgUrl:(NSString *)imageUrl;

@end

