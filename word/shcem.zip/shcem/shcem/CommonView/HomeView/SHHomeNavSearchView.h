//
//  SHHomeNavSearchView.h
//  shcem
//
//  Created by min on 17/2/17.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SHHomeNavSearchDelegate <NSObject>

- (void)homeSearchClick:(UIButton*)button;
- (void)homeNavMessageClick;

@end

@interface SHHomeNavSearchView : UIView

@property (nonatomic, strong) UIColor *navBackColor;
@property (nonatomic, assign) CGFloat backAlpha;
@property (nonatomic, strong) UITextField *textField;
@property (nonatomic, strong) UILabel *textPlaceholder;
@property (nonatomic, strong) UIImageView *textLeftView;


- (void)setViewColorWithColor:(UIColor *)color;

@property (nonatomic, weak)id<SHHomeNavSearchDelegate> delegate;

@end
