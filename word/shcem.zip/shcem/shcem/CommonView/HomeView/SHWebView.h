//
//  SHWebView.h
//  shcem
//
//  Created by min on 16/11/29.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import "SHActivityProgressView.h"
#import "SHFailLoadDataView.h"
#import "SHRefreshHeader.h"


@protocol SHWebViewDelegate <NSObject>

- (void)webViewLoadUrl:(NSString *)url;
- (void)webViewStartLoad;
- (void)webViewFinishLoad;
- (void)webViewFailLoad;

@end


@interface SHWebView : UIView

@property (nonatomic, copy) WKWebView *webView;
@property(nonatomic,strong) SHActivityProgressView * progressView;
@property(nonatomic,strong)SHFailLoadDataView * failView;

- (instancetype)initWithFrame:(CGRect)frame url:(NSString *)urlString refresh:(BOOL)isRefresh height:(BOOL)isNeedHeight;
- (void)refreshWebViewWithUrl:(NSString *)url;

@property(nonatomic, weak)id<SHWebViewDelegate>delegate;

@end
