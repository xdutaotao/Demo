//
//  SHHomeCollectionViewCell.m
//  shcem
//
//  Created by min on 16/11/23.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHHomeCollectionViewCell.h"

@interface SHHomeCollectionViewCell()

@property (nonatomic, strong) UIView *BGView;
@property (nonatomic, strong) UILabel *redLabel;

@end

@implementation SHHomeCollectionViewCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.BGView];
        [self.BGView addSubview:self.navImageView];
        [self.BGView addSubview:self.navLabel];
//        [self.BGView addSubview:self.redLabel];
        
    }
    return self;
}

- (void)loadCellData:(NSString *)title withNumber:(NSString *)number withImage:(NSString *)imageName{
    self.navLabel.text = title;
    self.navImageView.image = [UIImage imageNamed:imageName];
    if([number isEqualToString:@""]){
        _redLabel.hidden = YES;
    } else{
        _redLabel.hidden = NO;
        _redLabel.text = number;
    }

}


- (UIView *)BGView{
    if(!_BGView){
        _BGView = [[UIView alloc] initWithFrame:self.bounds];
    }
    return _BGView;
}


- (UILabel *)navLabel{
    if(!_navLabel){
        _navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, _BGView.height - 15, _BGView.width, 15)];
        _navLabel.font = [UIFont systemFontOfSize:11];
        _navLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _navLabel;
}
- (UIImageView *)navImageView{
    if(!_navImageView){
        _navImageView = [[UIImageView alloc] initWithFrame:CGRectMake(5+15 / 2, 10, (self.height - 15 - 10), (self.height - 15 - 10))];
        _navImageView.layer.cornerRadius = 22;
        _navImageView.image = [UIImage imageNamed:@"list_7"];
    }
    return _navImageView;
}
- (UILabel *)redLabel{
    if(!_redLabel){
        _redLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.navImageView.width + self.navImageView.origin.x - 10, self.navImageView.origin.y, 15, 15)];
        _redLabel.backgroundColor = [UIColor redColor];
        _redLabel.layer.cornerRadius = 15/2;
        _redLabel.layer.masksToBounds = YES;
        _redLabel.textAlignment = NSTextAlignmentCenter;
        
        _redLabel.textColor = WHITE;
        _redLabel.font = [UIFont systemFontOfSize:12];
    }
    return _redLabel;
}



@end
