//
//  SHDragableBtnView.h
//  Frey
//
//  Created by huangdeyu on 16/3/4.
//  Copyright © 2016年 shcem. All rights reserved.
//一个可自由拖动的按钮

#import <UIKit/UIKit.h>

@interface SHDragableBtnView : UIView
-(instancetype)initWithImage:(UIImage *)image;
@end
