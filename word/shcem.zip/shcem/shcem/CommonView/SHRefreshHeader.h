//
//  SHRefreshHeader.h
//  shcem
//
//  Created by huangdeyu on 2016/11/22.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface SHRefreshHeader : MJRefreshHeader
/** 利用这个block来决定显示的更新时间文字 */
@property (copy, nonatomic) NSString *(^lastUpdatedTimeText)(NSDate *lastUpdatedTime);
/** 显示上一次刷新时间的label */
@property (nonatomic, readonly) UILabel *lastUpdatedTimeLabel;  //刷新时间文字

@property(nonatomic,readonly) UILabel * stateLabel;     //状态文字

@property (nonatomic, readonly,strong) UIImageView *arrowView;   //对外的接口
/** 菊花的样式 */
@property (assign, nonatomic) UIActivityIndicatorViewStyle activityIndicatorViewStyle;

-(void)setup;
@end
