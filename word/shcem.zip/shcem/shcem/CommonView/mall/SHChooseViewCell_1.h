//
//  SHChooseViewCell_1.h
//  shcem
//
//  Created by huangdeyu on 2016/11/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SHChooseViewCell_1Delegate <NSObject>

@required
-(NSObject *)updateSelectedIDs:(UIButton *)btn;

-(void)setSelectIDS:(NSObject *)obj withIndex:(NSInteger)index;

@end

@interface SHChooseViewCell_1 : UITableViewCell
@property(nonatomic,weak) id<SHChooseViewCell_1Delegate> delegate;
-(void)loadData:(NSArray<NSDictionary *> *)values title:(NSString *)title startId:(NSInteger)startID btnStatus:(NSObject *)obj;
@end
