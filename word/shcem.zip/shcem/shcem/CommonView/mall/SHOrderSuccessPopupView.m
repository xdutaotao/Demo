//
//  SHOrderSuccessPopupView.m
//  shcem
//
//  Created by xupeipei on 2016/12/1.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHOrderSuccessPopupView.h"
#import <Masonry/Masonry.h>
#import "NSString+Format.h"

@interface SHOrderSuccessPopupView()

@property (nonatomic,strong) UILabel *titleLB;
@property (nonatomic,strong) UILabel *detaiLB;

@end

@implementation SHOrderSuccessPopupView


-(id)initWithFrame:(CGRect)frame{
    if (self =  [super initWithFrame:frame]) {
        self.backgroundColor = RGBACOLOR(0, 0, 0, 0.3);
        
        UIView *chiefView = [[UIView alloc] initWithFrame:CGRectZero];
        chiefView.backgroundColor = [UIColor whiteColor];
        chiefView.layer.masksToBounds = YES;
        chiefView.layer.cornerRadius = 5;
        [self addSubview:chiefView];
        
        [chiefView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.mas_equalTo(self);
            make.height.mas_equalTo(200);
            make.left.mas_equalTo(self.mas_left).offset(30);
            make.right.mas_equalTo(self.mas_right).offset(-30);
        }];
        
        UIImageView *rightIV = [[UIImageView alloc] initWithFrame:CGRectZero];
        rightIV.image = [UIImage imageNamed:@"right_circle"];
        [chiefView addSubview:rightIV];
        
        [rightIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(chiefView.bottom).offset(10);
            make.centerX.mas_equalTo(chiefView);
            make.size.mas_equalTo(CGSizeMake(30, 30));
        }];
        
        self.titleLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.titleLB.text = @"下单成功";
        self.titleLB.font = [UIFont systemFontOfSize:16];
        self.titleLB.textAlignment = NSTextAlignmentCenter;
        [chiefView addSubview:self.titleLB];
        
        [self.titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(chiefView.top).offset(50);
            make.left.mas_equalTo(chiefView.mas_left);
            make.right.mas_equalTo(chiefView.mas_right);
            make.height.mas_equalTo(30);
        }];
        
        UIView *horizontalView = [[UIView alloc] initWithFrame:CGRectZero];
        horizontalView.backgroundColor = [UIColor lightGrayColor];
        [chiefView addSubview:horizontalView];
        
        [horizontalView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(chiefView.top).offset(80);
            make.left.mas_equalTo(chiefView.mas_left).offset(30);
            make.right.mas_equalTo(chiefView.mas_right).offset(-30);
            make.height.mas_equalTo(1);
        }];

        self.detaiLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.detaiLB.text = @"扣款总金额元\n保证金金额元\n当前资金账户余额元";
        self.detaiLB.numberOfLines = 0;
        self.detaiLB.font = [UIFont systemFontOfSize:14];
        self.detaiLB.textAlignment = NSTextAlignmentCenter;
        [chiefView addSubview:self.detaiLB];
        
        [self.detaiLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(chiefView.top).offset(80);
            make.left.mas_equalTo(chiefView.mas_left);
            make.right.mas_equalTo(chiefView.mas_right);
            make.height.mas_equalTo(80);
        }];
        
        UIButton *closeBT = [[UIButton alloc] initWithFrame:CGRectZero];
        closeBT.backgroundColor = COLOR_NAV_RED;
        closeBT.titleLabel.textColor = [UIColor whiteColor];
        [closeBT setTitle: @"关闭" forState:UIControlStateNormal];
        [closeBT addTarget:self action:@selector(closeButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [chiefView addSubview:closeBT];
        
        [closeBT mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(chiefView.top).offset(160);
            make.left.mas_equalTo(chiefView.mas_left);
            make.right.mas_equalTo(chiefView.mas_right);
            make.height.mas_equalTo(40);
        }];
    }
    
    return self;
}

-(void)closeButtonAction:(id)sender{
    if ([self.delegate respondsToSelector:@selector(SHOrderSuccessPopupViewDelegate:)]) {
        if(_isNavigate){
            [self.delegate SHOrderSuccessPopupViewDelegate:@"YES"];
        }
        else{
            [self.delegate SHOrderSuccessPopupViewDelegate:@"NO"];
        }
    }
}

-(void)setGetAndCheckExpensesModel:(SHGetAndCheckExpensesModel *)getAndCheckExpensesModel{
    _getAndCheckExpensesModel = getAndCheckExpensesModel;
    
    NSString *Deposit = [NSString keepTwoDecimalPlaces:_getAndCheckExpensesModel.Deposit];
    NSString *UserBalance = [NSString keepTwoDecimalPlaces:_queryOneFirmBanlanceModel.USERBALANCEFromOra];
    NSString *UserBalance2 = [NSString countNumAndChangeformat:UserBalance];
    self.titleLB.text = self.titleString;
    
    NSString *detailString=nil;
    if(_isUsingContent){
        detailString=_contentString;
    }else{
        detailString= [NSString stringWithFormat:@"扣款总金额%@元\n保证金金额%@元\n当前资金账户余额%@元",Deposit,Deposit,UserBalance2];
    }
    
    
    
    self.detaiLB.text = detailString;
}

-(void)setCustomTitle:(NSString *)customTitle {
    self.titleLB.text=customTitle;
}

-(void)setCustomContent:(NSString *)customTitle {
    self.detaiLB.text=customTitle;
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
