//
//  SHScreenAnimator.h
//  shcem
//
//  Created by huangdeyu on 2016/11/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHScreenAnimator : NSObject<UIViewControllerAnimatedTransitioning>
-(instancetype)initWithAnimatorType:(UINavigationControllerOperation)type;
@end
