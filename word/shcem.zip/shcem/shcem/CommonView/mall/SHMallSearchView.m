//
//  SHMallSearchView.m
//  shcem
//
//  Created by huangdeyu on 2016/11/23.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHMallSearchView.h"
#import "Masonry.h"

@interface SHMallSearchView ()<UITextFieldDelegate>

@property(nonatomic,strong)UIButton * msgView;
@property(nonatomic,strong)UIButton * cancelBtn;
@property(nonatomic,strong)UILabel * msgLabel;
@property(nonatomic,strong) UIView * whiteCircle;
@end

@implementation SHMallSearchView


-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.textField];
        [self addSubview:self.cancelBtn];
         [self addSubview:self.msgView];
        [self addSubview:self.whiteCircle];
        [self addSubview:self.msgLabel];
        self.backgroundColor = COLOR_NAV_RED;
        [self layout];
    }
    return self;
}
-(void)layout{
    [self.msgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self).offset(-5);
        make.centerY.equalTo(self).offset(5);
        make.width.equalTo(@30);
        make.height.equalTo(@40);
    }];
    [self.msgLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.msgView);
        make.top.equalTo(self.msgView.mas_bottom).offset(-10);
    }];
    [self.textField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(10);
        make.right.equalTo(self.msgView.mas_left).offset(-5);
        make.centerY.equalTo(self).offset(10);
        make.height.equalTo(@30);
    }];
    [self.cancelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self).offset(-13);
        make.centerY.equalTo(self).offset(10);
    }];
    [self.whiteCircle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.msgView).offset(-3);
        make.top.equalTo(self.msgView).offset(5);
        make.height.equalTo(@10);
        make.width.equalTo(@10);
    }];
}
-(void)updateMsg:(BOOL)msg{
    if (msg) {
        self.whiteCircle.hidden = NO;
    }else{
        self.whiteCircle.hidden = YES;
    }
}
#pragma mark - public methods
-(void)showTableView{
    [UIView animateKeyframesWithDuration:0.5 delay:0 options:UIViewKeyframeAnimationOptionCalculationModeLinear animations:^{
        [UIView addKeyframeWithRelativeStartTime:0 relativeDuration:0.3 animations:^{
            self.msgView.transform = CGAffineTransformMakeScale(0, 0);
            self.msgLabel.transform = CGAffineTransformMakeScale(0, 0);
            self.whiteCircle.transform = CGAffineTransformMakeScale(0, 0);
        }];
        [UIView addKeyframeWithRelativeStartTime:0.3 relativeDuration:0.3 animations:^{
            self.cancelBtn.transform = CGAffineTransformMakeScale(1, 1);
        }];
        [UIView addKeyframeWithRelativeStartTime:0 relativeDuration:0.6 animations:^{
            self.textField.width = ScreenWidth - 70;
        }];
    } completion:^(BOOL finished) {
    }];
    [self.delegate showTableView];
}

-(void)hideTableView{
    [UIView animateKeyframesWithDuration:0.5 delay:0 options:UIViewKeyframeAnimationOptionCalculationModeLinear animations:^{
        [UIView addKeyframeWithRelativeStartTime:0.3 relativeDuration:0.6 animations:^{
            self.msgView.transform = CGAffineTransformMakeScale(1, 1);
            self.msgLabel.transform = CGAffineTransformMakeScale(1, 1);
            self.whiteCircle.transform = CGAffineTransformMakeScale(1, 1);
        }];
        [UIView addKeyframeWithRelativeStartTime:0 relativeDuration:0.3 animations:^{
            self.cancelBtn.transform = CGAffineTransformMakeScale(0, 0);
        }];
        [UIView addKeyframeWithRelativeStartTime:0 relativeDuration:0.6 animations:^{
            self.textField.width = ScreenWidth - 50;
        }];
    } completion:^(BOOL finished) {
    }];
    [self.delegate hideTableView];
}
-(void)setText:(NSString *)text{
    self.textField.text =text;
}
-(NSString *)searchStr{
    return self.textField.text;
}


#pragma mark - action
-(void)btnClicked:(UIButton *)btn{
    switch (btn.tag) {
        case 0:
            [self endEditing:YES];
            [self hideTableView];
            DLog(@"当前点击的是取消");
            break;
        case 1:
            DLog(@"当前点击的是消息");
            break;
        default:
            break;
    }
    [self.delegate navBtnClicked:btn];
}
#pragma mark - textfiled delegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    DLog(@"开始编辑键盘");
    [self showTableView];
    return  YES;
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self hideTableView];
    [self.delegate searchKeyboardClicked];
    return  YES;
}

#pragma mark - 初始化
-(UITextField *)textField{
    if (!_textField) {
        _textField = [[UITextField alloc] init];
        _textField.backgroundColor = [UIColor whiteColor];
        _textField.textColor = [UIColor grayColor];
        _textField.tintColor = COLOR_NAV_RED;
        _textField.placeholder = STR_HOME_SEARCH_Placeholder;
        _textField.layer.cornerRadius = 3.0;
        _textField.layer.masksToBounds = YES;
        _textField.leftView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Magnifier"]];
        _textField.leftView.width = 30;
        _textField.leftView.contentMode = UIViewContentModeCenter;
        [_textField setFont:[UIFont systemFontOfSize:14]];
        _textField.leftViewMode = UITextFieldViewModeAlways;
        _textField.delegate = self;
        _textField.returnKeyType = UIReturnKeySearch;
        _textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    }
    return _textField;
}
-(UIButton *)msgView{
    if (!_msgView) {
        _msgView = [UIButton buttonWithType:UIButtonTypeCustom];
        [_msgView setImage:[UIImage imageNamed:@"message"] forState:UIControlStateNormal];
        [_msgView addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
        _msgView.tag = 1;
    }
    return _msgView;
}
-(UIButton *)cancelBtn{
    if (!_cancelBtn) {
        _cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_cancelBtn setTitle:STR_ALERT_CANCEL forState:UIControlStateNormal];
        [_cancelBtn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [_cancelBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _cancelBtn.tag = 0;
  //      _cancelBtn.hidden = YES;
        [_cancelBtn.titleLabel setFont:[UIFont systemFontOfSize:16]];
        _cancelBtn.transform = CGAffineTransformMakeScale(0, 0);
    }
    return _cancelBtn;
}
-(UILabel *)msgLabel{
    if (!_msgLabel) {
        _msgLabel = [[UILabel alloc] init];
        _msgLabel.text = @"消息";
        [_msgLabel setFont:[UIFont systemFontOfSize:10]];
        _msgLabel.textColor = [UIColor whiteColor];
    }
    return _msgLabel;
}
-(UIView *)whiteCircle{
    if (!_whiteCircle) {
        _whiteCircle = [[UIView alloc] init];
        _whiteCircle.backgroundColor = [UIColor whiteColor];
        _whiteCircle.layer.cornerRadius = 5.0;
        _whiteCircle.layer.masksToBounds = YES;
        _whiteCircle.hidden = YES;
    }
    return _whiteCircle;
}
@end
