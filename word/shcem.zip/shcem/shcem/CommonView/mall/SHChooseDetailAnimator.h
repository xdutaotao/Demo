//
//  SHChooseDetailAnimator.h
//  shcem
//
//  Created by huangdeyu on 2016/11/29.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHChooseDetailAnimator : NSObject<UIViewControllerAnimatedTransitioning>
-(instancetype)initWithAnimatorType:(UINavigationControllerOperation)type;
@end
