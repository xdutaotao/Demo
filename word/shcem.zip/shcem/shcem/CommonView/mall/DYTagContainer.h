//
//  DYTagContainer.h
//  DYTag
//
//  Created by huangdeyu on 16/1/21.
//  Copyright © 2016年 huangdeyu. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol DYTagContainerDelegate<NSObject>
@required
-(void)ChooseTags:(NSInteger)tag;
-(void)frameChanged:(CGFloat)frameHeight;
@end

@interface DYTagContainer : UIView


@property(nonatomic,strong) NSMutableArray * buttontags;

@property(nonatomic,weak) id<DYTagContainerDelegate> delegate;
/**这个titles 指的是一个字典数组，字典数组中的tag字段表示button的tag
 *name 字段表示button 的title
 */
-(instancetype)initWithFrame:(CGRect)frame titles:(NSArray *)titles;
/**添加一个标签
 *
 */
-(void)addTitle:(id)title;

-(void)removeTitle:(id)title;

-(void)addSomeTitles:(NSArray *)titles;
-(void)removeSomeTitles:(NSArray *)titles;
-(void)removeAll;
-(void)addDefault;
@end
