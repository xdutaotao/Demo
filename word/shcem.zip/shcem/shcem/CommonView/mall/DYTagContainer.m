//
//  DYTagContainer.m
//  DYTag
//
//  Created by huangdeyu on 16/1/21.
//  Copyright © 2016年 huangdeyu. All rights reserved.
//

#import "DYTagContainer.h"
#import "DYCustomBtn.h"
#define SW ([UIScreen mainScreen].bounds.size.width)
#define SH ([UIScreen mainScreen].bounds.size.height)
#define SELFWIDTH self.frame.size.width
#define DEFAULTTAGVALUE   100000001
@interface DYTagContainer()

@end

@implementation DYTagContainer

-(instancetype)initWithFrame:(CGRect)frame titles:(NSArray *)titles{
    if (self = [super initWithFrame:frame]) {
        [self setup];
        if (titles == nil || titles.count == 0) {
            self.height = 0;
           
        }else{
            [titles enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                NSDictionary * dic = obj;
                NSString * titleName = [dic objectForKey:@"name"];
                NSNumber * buttonTag = [dic objectForKey:@"tag"];
                DYCustomBtn * customBtn = [DYCustomBtn buttonWithType:UIButtonTypeCustom];
                [customBtn setupWithTitle:titleName andOrgin:CGPointMake(0, 0) andMaxWidth:frame.size.width];    //先初始化为0，0位置，再计算位置。
                customBtn.tag = [buttonTag integerValue];
                [customBtn addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
                [self addSubview:customBtn];
                [self.buttontags addObject:customBtn];
            }];
            [self caculatePos];
        }
    }
    return self;
}
-(void)setup{
    self.backgroundColor = HexRGB(0xf0f1f5);
    self.buttontags = [NSMutableArray array];
//    self.defaultValue = @{@"name":@"全部",@"tag":@(-1)};
}
-(void)addDefault{
    DYCustomBtn * customBtn = [DYCustomBtn buttonWithType:UIButtonTypeCustom];
    [customBtn setupWithTitle:@"全部" andOrgin:CGPointMake(0, 0) andMaxWidth:self.frame.size.width];    //先初始化为0，0位置，再计算位置。
    customBtn.tag = DEFAULTTAGVALUE;
    [customBtn addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:customBtn];
    [self.buttontags addObject:customBtn];
    [self caculatePos];
}

-(void)addTitle:(id)title{
    NSDictionary * dic = title;
    NSString * titleName = [dic objectForKey:@"name"];
    NSNumber * buttonTag = [dic objectForKey:@"tag"];
    DYCustomBtn * customBtn = [DYCustomBtn buttonWithType:UIButtonTypeCustom];
    [customBtn setupWithTitle:titleName andOrgin:CGPointMake(0, 0) andMaxWidth:self.frame.size.width];    //先初始化为0，0位置，再计算位置。
    customBtn.tag = [buttonTag integerValue];
    [customBtn addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:customBtn];
    [self.buttontags addObject:customBtn];
    for (int i = 0; i < self.buttontags.count; i++) {
        UIButton * btn = self.buttontags[i];
        if (btn.tag == DEFAULTTAGVALUE) {
            [btn removeFromSuperview];
            [self.buttontags removeObjectAtIndex:i];
            break;
        }
    }
    [self caculatePos];
}
-(void)addSomeTitles:(NSArray *)titles{
    [titles enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSDictionary * dic = obj;
        NSString * titleName = [dic objectForKey:@"name"];
        NSNumber * buttonTag = [dic objectForKey:@"tag"];
       
        DYCustomBtn * customBtn = [DYCustomBtn buttonWithType:UIButtonTypeCustom];
        [customBtn setupWithTitle:titleName andOrgin:CGPointMake(0, 0) andMaxWidth:self.frame.size.width];    //先初始化为0，0位置，再计算位置。
        customBtn.tag = [buttonTag integerValue];
        [customBtn addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:customBtn];
        [self.buttontags addObject:customBtn];
        for (int i = 0; i < self.buttontags.count; i++) {
            UIButton * btn = self.buttontags[i];
            if (btn.tag == DEFAULTTAGVALUE) {
                [btn removeFromSuperview];
                [self.buttontags removeObjectAtIndex:i];
                break;
            }
        }

    }];
    [self caculatePos];
}

-(void)removeSomeTitles:(NSArray *)titles{
    [titles enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSDictionary * tagDic = obj;
        NSNumber * tagNum = [tagDic objectForKey:@"tag"];
        NSInteger tagValue = [tagNum integerValue];
        for (int i = 0; i < self.buttontags.count;i++) {
            DYCustomBtn * btn = self.buttontags[i];
            if (btn.tag == tagValue) {
                [btn removeFromSuperview];
                [self.buttontags removeObjectAtIndex:i];
                break;
            }
        }
        if (self.buttontags.count == 0) {
            [self addDefault];
        }
    }];
    [self caculatePos];
}

-(void)removeTitle:(id)title{
    NSDictionary * tagDic = title;
    NSNumber * tagNum = [tagDic objectForKey:@"tag"];
    NSInteger tagValue = [tagNum integerValue];
    for (int i = 0; i < self.buttontags.count;i++) {
        DYCustomBtn * btn = self.buttontags[i];
        if (btn.tag == tagValue) {
            [btn removeFromSuperview];
            [self.buttontags removeObjectAtIndex:i];
            break;
        }
    }
    if (self.buttontags.count == 0) {
        [self addDefault];
    }
    [self caculatePos];
}
-(void)removeAll{
    [self.buttontags enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        UIButton * button = obj;
        [button removeFromSuperview];
    }];
    self.buttontags = [NSMutableArray array];
    [self addDefault];
//    [UIView animateWithDuration:0.5 animations:^{
//        self.height = 0;
//    }];
}

-(void)caculatePos{
    float heightPos = 12; //距离最上面的距离
    float widthPos = 0;
    float spaceHor = 5;     //水平间隔
    float spaceVer = 8;     //竖直间隔
    for (int i = 0; i < self.buttontags.count; i++) {
        DYCustomBtn * button = self.buttontags[i];
        button.isArranged = NO;
    }
    for (int i = 0; i < self.buttontags.count; i++) {
        DYCustomBtn * buttonI = self.buttontags[i];
        if (!buttonI.isArranged) {
            buttonI.isArranged = YES;
            [UIView animateWithDuration:0.5 animations:^{
                 buttonI.frame = CGRectMake(5, heightPos, buttonI.frame.size.width, buttonI.frame.size.height);
            }];
           
            widthPos = buttonI.frame.size.width + spaceHor + 5;
            float testHeight = buttonI.frame.size.height;
            for (int k = i+1; k < self.buttontags.count ; k++) {
                DYCustomBtn * buttonK = self.buttontags[k];
                if (!buttonK.isArranged) {
                    if (buttonK.frame.size.width + widthPos < self.frame.size.width) {
                        buttonK.isArranged = YES;
                        [UIView animateWithDuration:0.5 animations:^{
                             buttonK.frame = CGRectMake(widthPos, heightPos, buttonK.frame.size.width, buttonK.frame.size.height);
                        }];
                        widthPos += buttonK.frame.size.width + spaceHor;
                    }
                }
            }
            heightPos += testHeight  + spaceVer;
        }
    }
    if (heightPos == 12.0) {
        heightPos = 0;
    }
    [UIView animateWithDuration:0.5 animations:^{
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, heightPos);
    }];
    [self.delegate frameChanged:self.frame.size.height];
    
}

#pragma mark -action
-(void)buttonClicked:(UIButton *)button{
    NSLog(@"当前选中的tag是%ld",(long)button.tag);
    if (button.tag == DEFAULTTAGVALUE) {
        return;
    }
    for (int i = 0; i < self.buttontags.count;i++) {
        DYCustomBtn * btn = self.buttontags[i];
        if (btn.tag == button.tag) {
            [btn removeFromSuperview];
            [self.buttontags removeObjectAtIndex:i];
            break;
        }
    }
    if (self.buttontags.count == 0) {
        [self addDefault];
    }
    [self caculatePos];
    [self.delegate ChooseTags:button.tag];

}

@end
