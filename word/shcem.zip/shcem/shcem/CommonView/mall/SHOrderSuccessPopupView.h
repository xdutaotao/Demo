//
//  SHOrderSuccessPopupView.h
//  shcem
//
//  Created by xupeipei on 2016/12/1.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHGetAndCheckExpensesModel.h"
#import "SHQueryOneFirmBanlanceModel.h"

@protocol SHOrderSuccessPopupViewDelegate <NSObject>

-(void)SHOrderSuccessPopupViewDelegate:(id)model;

@end

@interface SHOrderSuccessPopupView : UIView


@property (nonatomic ,weak) id<SHOrderSuccessPopupViewDelegate> delegate;

@property (nonatomic,strong) SHGetAndCheckExpensesModel *getAndCheckExpensesModel;
@property (nonatomic,strong) SHQueryOneFirmBanlanceModel *queryOneFirmBanlanceModel;


@property (nonatomic,strong) NSString *titleString;
@property (nonatomic,strong) NSString *contentString;
@property (nonatomic,strong) NSString *customTitle;
@property (nonatomic,strong) NSString *customContent;
@property (nonatomic,assign) BOOL isUsingContent;
@property (nonatomic,assign) BOOL isNavigate;

@end
