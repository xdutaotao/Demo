//
//  SHChooseViewNavView.m
//  shcem
//
//  Created by huangdeyu on 2016/11/28.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHChooseViewNavView.h"

@interface SHChooseViewNavView ()
@property(nonatomic,strong) UIButton * backBtn;
@property(nonatomic,strong) UILabel * title;
@end

@implementation SHChooseViewNavView

-(instancetype)initWithFrame:(CGRect)frame andTitle:(NSString *)title{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = COLOR_NAV_RED;
        [self addSubview:self.backBtn];
        [self addSubview:self.title];
        self.title.text = title;
        [self layout];
    }
    return self;
}
-(void)layout{
    self.backBtn.frame = CGRectMake(0, 0, 80, self.height);
    self.title.frame = CGRectMake(0, StatusBarHeight, self.width, self.height - StatusBarHeight);
}
-(void)btnClicked{
    [self.delegate navBackClicked];
}
#pragma mark - 初始化
-(UIButton *)backBtn{
    if (!_backBtn) {
        _backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_backBtn setImage:[UIImage imageNamed:@"iconfont-fanhui"] forState:UIControlStateNormal];
        [_backBtn addTarget:self action:@selector(btnClicked) forControlEvents:UIControlEventTouchUpInside];
        [_backBtn setImageEdgeInsets:UIEdgeInsetsMake(10, -20, -10, 20)];
    }
    return   _backBtn;
}
-(UILabel *)title{
    if (!_title) {
        _title  = [[UILabel alloc] init];
        [_title setFont:[UIFont systemFontOfSize:16]];
        _title.textColor = [UIColor whiteColor];
        _title.textAlignment = NSTextAlignmentCenter;
        
    }
    return _title;
}
@end
