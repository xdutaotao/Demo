//
//  SHMallListCellTableViewCell.h
//  shcem
//
//  Created by huangdeyu on 2016/11/22.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
@class SHMallListModel;
@interface SHMallListCellTableViewCell : UITableViewCell
-(void)loadData:(SHMallListModel *)model;
@end
