//
//  SHChooseView.m
//  shcem
//
//  Created by huangdeyu on 2016/11/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHChooseView.h"
#import "SHChooseViewCell_1.h"
#import "SHChooseViewNavView.h"
#import "SHMallSearchKey.h"
@interface SHChooseView ()<UITableViewDelegate,UITableViewDataSource,SHChooseViewCell_1Delegate,SHChooseViewNavViewDelegate>
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong)SHChooseViewNavView * navView;
@property(nonatomic,strong) UIButton * resetBtn;
@property(nonatomic,strong) UIButton * sureBtn;

@property(nonatomic,strong)NSArray<NSArray *> * datas;//section 0 的数据
@property(nonatomic ,strong)NSArray * titles;                   //section 0 的标题
@property(nonatomic,strong)NSMutableArray * selectedIDs;           //section 0 被选中的

@property(nonatomic,strong)NSMutableDictionary * lastSelectedDic;   //controller传递过来的数据
@property(nonatomic,strong) NSDictionary * json;            //controller传过来的Json

@property(nonatomic,strong)NSArray * sectionTitles;         //section 1 的标题
@property(nonatomic,strong)NSArray * sectionContents;   //section 1 的内容
@property(nonatomic,strong)NSArray * detailTexts;

@end

@implementation SHChooseView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        [self addSubview:self.tableView];
        [self addSubview:self.resetBtn];
        [self addSubview:self.sureBtn];
        [self addSubview:self.navView];
        [self setupUI];
        self.titles = @[@"分类",@"类型",@"状态",@"交收方式",@"进口/国产"];         //section 0 的标题
        self.sectionTitles = @[@"产地",@"交货地",@"配送范围"];       //section 1的标题
    }
    return self;
}
-(void)setupUI{
    self.tableView.frame = CGRectMake(0, NavgationBarHeight, self.width, self.height - NavgationBarHeight - 40);
    self.resetBtn.frame = CGRectMake(0, self.height - 40, self.width * .5, 40);
    self.sureBtn.frame = CGRectMake(self.width * .5, self.height - 40, self.width * .5, 40);
}

-(void)loadData:(NSDictionary *)dic selectedDatas:(NSMutableDictionary *)selectedDic{
    
    self.lastSelectedDic = selectedDic;
    self.json = dic;
    DLog(@"查询条件的内存地址是：%p",self.lastSelectedDic);
    NSArray * leavel = [dic objectForKey:Kcategory];                      //分类
    NSArray * type = [dic objectForKey:Ktype];                              //现货 预售
    NSArray * state = [dic objectForKey:Kstate];                            //状态：有效，成交
    NSArray * deliverType = [dic objectForKey:KdeliverType];          //交收方式
    NSArray * sourcePlaceType = [dic objectForKey:KSourcePlaceType];
    self.datas = @[leavel,type,state,deliverType,sourcePlaceType];

    NSArray * sourcePlace = [dic objectForKey:KsourcePlace];
    NSArray * deliveryPlace = [dic objectForKey:KdelieveryPlace];
    NSArray * lastPlace = [dic objectForKey:KsellScope];          //配送范围的字段 暂时没有
    self.sectionContents = @[sourcePlace,deliveryPlace,lastPlace];
    
    NSArray * sourcePlaceTitles = [self.lastSelectedDic objectForKey:KsourcePlaceValues];
    NSArray * deliverplaceTitles = [self.lastSelectedDic objectForKey:KdeliveryPlaceValues];
    NSArray * sellScopeTitles = [self.lastSelectedDic objectForKey:KKsellScopeValues];
    
    self.detailTexts = @[[self getTitlesWithArray:sourcePlaceTitles],[self getTitlesWithArray:deliverplaceTitles],[self getTitlesWithArray:sellScopeTitles]];
    
    [self updateSelected];
}
-(void)updateSelected{
    NSObject * leavelSelected = [self.lastSelectedDic objectForKey:Kcategory];
    NSObject * typeSelected = [self.lastSelectedDic objectForKey:Ktype];
    NSObject * stateSelected = [self.lastSelectedDic objectForKey:Kstate];
    NSObject * deliverTypeSelected = [self.lastSelectedDic objectForKey:KdeliverType];
    NSObject * sourcePlaceType = [self.lastSelectedDic objectForKey:KSourcePlaceType];
    self.selectedIDs = [@[leavelSelected,typeSelected,stateSelected,deliverTypeSelected,sourcePlaceType] mutableCopy];
    [self.tableView reloadData];
}
-(NSString * )getTitlesWithArray:(NSArray *)arr{
    if (arr.count == 1) {
        return arr[0];
    }
    __block NSString * str = nil;
    [arr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if(idx == 1){
            str = [NSString stringWithFormat:@"%@",obj];
        }else if(idx > 1){
            str = [NSString stringWithFormat:@"%@,%@",str,obj];
        }
        
    }];
    return str;
}

-(void)reloadSection1{
    DLog(@"更新section1");
    NSArray * sourcePlaceTitles = [self.lastSelectedDic objectForKey:KsourcePlaceValues];
    NSArray * deliverplaceTitles = [self.lastSelectedDic objectForKey:KdeliveryPlaceValues];
    NSArray * sellScopeTitles = [self.lastSelectedDic objectForKey:KKsellScopeValues];
    
    self.detailTexts = @[[self getTitlesWithArray:sourcePlaceTitles],[self getTitlesWithArray:deliverplaceTitles],[self getTitlesWithArray:sellScopeTitles]];
    [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:1] withRowAnimation:UITableViewRowAnimationFade];
}
#pragma mark - tableView delegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if(section == 0){
        return self.datas.count;
    }
    return self.sectionContents.count;
    
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.section == 0){
        SHChooseViewCell_1 * cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([SHChooseViewCell_1 class])];
        if (!cell) {
            cell = [[SHChooseViewCell_1 alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([SHChooseViewCell_1 class])];
        }
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        cell.delegate = self;
        [cell loadData:self.datas[indexPath.row] title:self.titles[indexPath.row] startId:(indexPath.row + 1) * 1000 btnStatus:self.selectedIDs[indexPath.row]];
        return cell;
    }else{
        UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
            cell.detailTextLabel.textColor = COLOR_NAV_RED;
            [cell.detailTextLabel setFont:[UIFont systemFontOfSize:12]];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            [cell.textLabel setFont:[UIFont systemFontOfSize:15]];
        }
        cell.textLabel.text = self.sectionTitles[indexPath.row];
        cell.detailTextLabel.text = self.detailTexts[indexPath.row];
        
        if ([cell.detailTextLabel.text isEqualToString:@"全部"]) {
            cell.detailTextLabel.textColor = [UIColor grayColor];
        }else{
            cell.detailTextLabel.textColor = COLOR_NAV_RED;
        }
        return cell;
    }
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return 80 + 35 * ((self.datas[indexPath.row].count - 1) / 3);
    }
    return 40;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 0;
    }
    return 20;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSArray * keys = @[KsourcePlace,KdelieveryPlace,KsellScope];
    if(indexPath.section == 1){
        [self.delegate selectWithIndex:indexPath.row contents:self.sectionContents[indexPath.row] key:keys[indexPath.row]];
    }
}

#pragma mark - cell  委托
-(NSObject *)updateSelectedIDs:(UIButton *)btn{
    if (btn.tag % 1000 == 999) { //证明是点击的是全部，
        return self.selectedIDs[(btn.tag + 1) / 1000 - 1];
    }
    return self.selectedIDs[btn.tag / 1000 -1];
}
-(void)setSelectIDS:(NSObject *)obj withIndex:(NSInteger)index{
    self.selectedIDs[index] = obj;
    switch (index) {
        case 0:
            self.lastSelectedDic[Kcategory] = obj;
            break;
        case 1:
            self.lastSelectedDic[Ktype] = obj;
            break;
        case 2:
            self.lastSelectedDic[Kstate] = obj;
            break;
        case 3:
            self.lastSelectedDic[KdeliverType] = obj;
            break;
        case 4:
            self.lastSelectedDic[KSourcePlaceType] = obj;
            break;
        default:
            break;
    }
}
#pragma mark - target
-(void)bottomBtnClicked:(UIButton *)btn{
    [self.delegate bottmBtnClicked:btn.tag];
    if (btn.tag == 0) {
        self.detailTexts = @[@"全部",@"全部",@"全部"];
        [self updateSelected];
    }
  //   [self loadData:self.json selectedDatas:self.lastSelectedDic];
}
#pragma mark - nav clicked
-(void)navBackClicked{
    [self.delegate navBackClicked];
}
#pragma mark - 初始化
-(UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] init];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [UIView new];
        [_tableView registerClass:[SHChooseViewCell_1 class] forCellReuseIdentifier:NSStringFromClass([SHChooseViewCell_1 class])];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _tableView;
}
-(UIButton *)resetBtn{
    if (!_resetBtn) {
        _resetBtn = [UIButton buttonWithType:UIButtonTypeCustom];
     //   _resetBtn.backgroundColor = HexRGB(0xf9f9f9);
        [_resetBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_resetBtn setTitle:@"重置" forState:UIControlStateNormal];
        [_resetBtn setBackgroundImage:[UIImage imageWithColor:HexRGB(0xf9f9f9)] forState:UIControlStateNormal];
        _resetBtn.tag = 0;
        [_resetBtn addTarget:self action:@selector(bottomBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _resetBtn;
}
-(UIButton *)sureBtn{
    if (!_sureBtn) {
        _sureBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_sureBtn setTitle:STR_ALERT_SURE forState:UIControlStateNormal];
        [_sureBtn setBackgroundImage:[UIImage imageWithColor:COLOR_NAV_RED] forState:UIControlStateNormal];
        [_sureBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _sureBtn.tag = 1;
        [_sureBtn addTarget:self action:@selector(bottomBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _sureBtn;
}
-(SHChooseViewNavView *)navView{
    if (!_navView) {
        _navView = [[SHChooseViewNavView alloc] initWithFrame:CGRectMake(0, 0, self.width, NavgationBarHeight) andTitle:@"筛选"];
        _navView.delegate = self;
    }
    return _navView;
}
@end
