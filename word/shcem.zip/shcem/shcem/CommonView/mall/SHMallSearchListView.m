//
//  UIMallSearchListView.m
//  shcem
//
//  Created by huangdeyu on 2016/11/23.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHMallSearchListView.h"


@interface SHMallSearchListView ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong)NSMutableArray * datasArray;
@property (nonatomic, strong) UIView * footerBtn;

@end

@implementation SHMallSearchListView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = WHITE;
        self.tableView.frame  = self.bounds;
        [self addSubview:self.tableView];
    }
    return self;
}
-(void)loadData:(NSMutableArray *)data{
    self.datasArray = [NSMutableArray array];
    self.datasArray = data;
    [self.tableView reloadData];
}
#pragma mark - 当前页面展示与隐藏
-(void)showInView:(UIView *)view{
    if (![view containsSubView:self]) {
        [view addSubview:self];
    }
}
-(void)hide{
    [self removeFromSuperview];
}

#pragma mark - 搜索tableview和清除的button展示与隐藏
-(void)searchShow{
    if(![self containsSubView:self.tableView]){
        self.tableView.frame = self.bounds;
        [self addSubview:self.tableView];
    }
    self.footerBtn.hidden = NO;
}
- (void)searchHide{
    [self.tableView removeFromSuperview];
    self.footerBtn.hidden = YES;
}

#pragma mark - tableDelegate
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
        [cell.textLabel setFont:[UIFont systemFontOfSize:FONT_DEFAULT]];
        [cell.textLabel setTextColor:BLACK_CUSTOM];
    }
    if(indexPath.row < self.datasArray.count){
        cell.textLabel.text = self.datasArray[indexPath.row];
    }
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self.delegate searchOverWith:self.datasArray[indexPath.row]];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.datasArray.count;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UILabel * label = [[UILabel alloc] initWithFrame:CGRectMake(20, 0, ScreenWidth, 40)];
    label.text = @"   历史记录";
    label.textColor = HexRGB(0x999999);
    label.layer.shadowColor = [UIColor lightGrayColor].CGColor;
    label.layer.shadowOffset = CGSizeMake(1, 1);
    label.layer.shadowRadius = 2.0;
    label.layer.shadowOpacity = 0.8;
    label.backgroundColor = [UIColor whiteColor];
    return label;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 50;
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    [self endEditing:YES];
    [self.superview endEditing:YES];
    [self.delegate searchHistoryScroll];
}

-(void)clearBtnClicked:(UIButton *)btn{
    [self.delegate clearBtnClicked];
}

#pragma mark - 初始化
-(UITableView  *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] init];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = self.footerBtn;
    }
    return _tableView;
}
- (UIView *)footerBtn{
    if(!_footerBtn){
        _footerBtn = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 50)];
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setImage:[UIImage imageNamed:@"trash"] forState:UIControlStateNormal];
        btn.imageEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 10);
        [btn setTitle:@"清除搜索历史" forState:UIControlStateNormal];
        btn.layer.cornerRadius = 5.0;
        btn.layer.borderColor = COLOR_NAV_RED.CGColor;
        btn.layer.borderWidth = 1.0;
        [btn setTitleColor:COLOR_NAV_RED forState:UIControlStateNormal];
        btn.frame = CGRectMake(0, 0, 150, 30);
        [btn.titleLabel setFont:[UIFont systemFontOfSize:FONT_DEFAULT]];
        [_footerBtn addSubview:btn];
        btn.center = _footerBtn.center;
        [btn addTarget:self action:@selector(clearBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _footerBtn;
}

@end
