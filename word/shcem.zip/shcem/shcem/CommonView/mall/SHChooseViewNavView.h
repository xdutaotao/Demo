//
//  SHChooseViewNavView.h
//  shcem
//
//  Created by huangdeyu on 2016/11/28.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SHChooseViewNavViewDelegate <NSObject>

@required
-(void)navBackClicked;

@end

@interface SHChooseViewNavView : UIView
@property(nonatomic,weak) id<SHChooseViewNavViewDelegate>  delegate;
-(instancetype)initWithFrame:(CGRect)frame andTitle:(NSString *)title;
@end
