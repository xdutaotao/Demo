//
//  SHChooseViewCell_1.m
//  shcem
//
//  Created by huangdeyu on 2016/11/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHChooseViewCell_1.h"

@interface SHChooseViewCell_1 ()
@property(nonatomic,strong) NSMutableArray<UIButton *> * btns;
@property(nonatomic,strong) UILabel * title;
@end

@implementation SHChooseViewCell_1

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.btns = [NSMutableArray array];
        [self addSubview:self.title];
    }
    return  self;
}
-(void)loadData:(NSArray<NSDictionary *> *)values title:(NSString *)title startId:(NSInteger)startID btnStatus:(NSObject *)status{
    [self.btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [obj removeFromSuperview];
    }];
    self.btns  = [NSMutableArray array];
    [values enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSInteger tag = [[obj objectForKey:@"valueId"] integerValue] + startID;         //根据valueId  设置tag和对应的行数（+1000）决定
        UIButton * btn = [self setUpBtn:[obj objectForKey:@"name"] tag:tag];            //生成按钮
        [self.btns addObject:btn];
        if ([status isKindOfClass:[NSArray class]]) {       //如果是数组，表明它是多选
            if ([((NSArray *)status)containsObject:[NSNumber numberWithInteger:tag - startID]]) {   //如果数组里包含对应的ID 则设为选中
                btn.selected = YES;
                [self setSelectedWithBtn:btn];
            }
            if(((NSArray *)status).count == 0 && (tag - startID) == -1){    //如果数组为空 且 当前tag  = -1 表示是全部，则被选中
                [btn setSelected:YES];
                [self setSelectedWithBtn:btn];
            }
        }else{
            NSNumber * num = ( NSNumber *)status;           //非数组状态，是单选
            NSInteger numInt = [num integerValue];
            if (numInt == (tag - startID)) {
                [btn setSelected:YES];
                [self setSelectedWithBtn:btn];
            }
        }
    }];
    self.title.text = title;
    [self layout];
}

-(void)layout{
    self.title.frame = CGRectMake(20, 0, ScreenWidth  -50, 25);
    float leftMargin = 20;
    float betweenMarginX = 10;
    float betweenMarginY = 10;
    float btnWidth = (ScreenWidth - 50 - leftMargin * 2 - betweenMarginX * 2) / 3.0;
    float btnWidth1 = (ScreenWidth - 50 - leftMargin * 2 - betweenMarginX) * .5;
    float btnHeight = 25;
    [self.btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSInteger currentLine = idx / 3;
        obj.frame = CGRectMake(leftMargin + (btnWidth + betweenMarginX) * (idx % 3), 25 + betweenMarginY + (betweenMarginY + btnHeight) * currentLine, btnWidth, btnHeight);
        if (self.btns.count % 3 == 2 && currentLine == self.btns.count / 3) {
             obj.frame = CGRectMake(leftMargin + (btnWidth1 + betweenMarginX) * (idx % 3), 25 + betweenMarginY + (betweenMarginY + btnHeight) * currentLine, btnWidth1, btnHeight);
        }
    }];
}
-(void)setSelectedWithBtn:(UIButton *)btn{
    btn.backgroundColor = [UIColor clearColor];
    [btn setTitleColor:COLOR_NAV_RED forState:UIControlStateSelected];
    btn.layer.borderColor = COLOR_NAV_RED.CGColor;
}
-(void)btnClicked:(UIButton *)btn{
    NSObject * obj =   [self.delegate updateSelectedIDs:btn];           //通过委托获取当前选中的按钮
    if ([obj isKindOfClass:[NSArray class]]) {//多选项
        DLog(@"点击的是多选项");
        [self dealWithMoreSelectedWithBtn:btn];
        NSMutableArray * arr = [NSMutableArray array];
        __block NSInteger  index = 0;
        [self.btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if (obj.isSelected) {
                NSInteger tag = 0;
                if(obj.tag % 1000 == 999){
                    tag = -1;
                    *stop = YES;
                    index = (obj.tag + 1) / 1000 - 1;
                    return;     //这边添加个return 是因为 stop 也会在真个逻辑走完后 再结束循环
                }else{
                    tag = obj.tag % 1000;
                    index = obj.tag / 1000 -1;
                }
                [arr addObject:@(tag)];
            }
        }];
        obj = [arr copy];
        [self.delegate setSelectIDS:obj withIndex:index];
        DLog(@"%@",obj);
    }else{                          //单选项
        DLog(@"点击的是单选向");
        [self dealWithSingleSelectedWithBtn:btn];
        [self.btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if (obj.isSelected) {
                //需要回调
                if (obj.tag % 1000 == 999) {
                    NSInteger index = (obj.tag + 1) / 1000 -1;
                    [self.delegate setSelectIDS:@(-1) withIndex:index];
                }else{
                    NSInteger index = obj.tag / 1000 - 1;
                    NSInteger tag = obj.tag % 1000;
                    [self.delegate setSelectIDS:@(tag) withIndex:index];
                }
                *stop = YES;
            }
        }];
    }
}
-(void)dealWithMoreSelectedWithBtn:(UIButton *)btn {
    
    if (btn.tag % 1000 == 999) { //如果点的是全部
        if (btn.isSelected) {  //如果当前是选中状态
            return;
        }else{
            btn.selected = YES;
            [self setSelectedWithBtn:btn];
            [self.btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if (obj.tag != btn.tag) {
                    obj.selected = NO;
                    obj.backgroundColor = [UIColor colorWithWhite:0.9 alpha:0.8];
                    obj.layer.borderColor = [UIColor clearColor].CGColor;
                }
            }];
        }
    }else{      //如果点的不是全部
        btn.selected = !btn.selected;   //更改状态
        if (btn.selected) {
            btn.backgroundColor = [UIColor clearColor];
            [btn setTitleColor:COLOR_NAV_RED forState:UIControlStateSelected];
            btn.layer.borderColor = COLOR_NAV_RED.CGColor;
        }else{
            btn.backgroundColor = [UIColor colorWithWhite:0.9 alpha:0.8];
            btn.layer.borderColor = [UIColor clearColor].CGColor;
        }
        if (btn.selected) {//如果是被选中了，需要把全部选择去掉
            [self.btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if (obj.tag % 1000 == 999) {
                    obj.selected = NO;
                    obj.backgroundColor = [UIColor colorWithWhite:0.9 alpha:0.8];
                    obj.layer.borderColor = [UIColor clearColor].CGColor;
                    * stop = YES;
                }
            }];
        }else{ //如果是被取消选中了，需要判断全部按钮，如果都处于未被选中状态，需要勾选全部
            [self.btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if (obj.selected) {
                    *stop = YES;
                }
                if (idx == self.btns.count -1) {
                    self.btns[0].selected = YES;
                    [self setSelectedWithBtn:self.btns[0]];
                }
            }];
        }
    
    }

}
-(void)dealWithSingleSelectedWithBtn:(UIButton *)btn{
    if(btn.tag % 1000 == 999 ){//当前点选的是全部
        if (btn.selected) {
            return;
        }else{
            btn.selected = YES;
            [self setSelectedWithBtn:btn];
            [self.btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if (obj.tag != btn.tag) {
                    obj.selected = NO;
                    obj.backgroundColor = [UIColor colorWithWhite:0.9 alpha:0.8];
                    obj.layer.borderColor = [UIColor clearColor].CGColor;
                }
            }];
        }
    }else{
        btn.selected = !btn.selected;
        if (btn.selected) {
            btn.backgroundColor = [UIColor clearColor];
            [btn setTitleColor:COLOR_NAV_RED forState:UIControlStateSelected];
            btn.layer.borderColor = COLOR_NAV_RED.CGColor;
            [self.btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if (obj.tag != btn.tag) {
                    obj.selected = NO;
                    obj.backgroundColor = [UIColor colorWithWhite:0.9 alpha:0.8];
                    obj.layer.borderColor = [UIColor clearColor].CGColor;
                }
            }];
        }else{
            btn.backgroundColor = [UIColor colorWithWhite:0.9 alpha:0.8];
            btn.layer.borderColor = [UIColor clearColor].CGColor;
            [self.btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if (obj.isSelected) {
                    *stop = YES;
                }
                if (idx == self.btns.count - 1) {
                    self.btns[0].selected = YES;
                    [self setSelectedWithBtn:self.btns[0]];
                }
            }];
        }

    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

-(UIButton *)setUpBtn:(NSString *)titel tag:(NSInteger)tag{
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.layer.cornerRadius = 3.0;
    btn.backgroundColor = [UIColor colorWithWhite:0.9 alpha:0.8];
    btn.layer.masksToBounds = YES;
    [btn.titleLabel setFont:[UIFont systemFontOfSize:13]];
    [btn setTitleColor:COLOR_NAV_RED forState:UIControlStateSelected];
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btn setTitle:titel forState:UIControlStateNormal];
    btn.tag = tag;
    [btn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
    [btn setImage:[UIImage imageNamed:@"choosed"] forState:UIControlStateSelected];
    btn.layer.borderWidth = 1.0;
    btn.layer.cornerRadius = 3.0;
    btn.layer.masksToBounds = YES;
    btn.layer.borderColor = [UIColor clearColor].CGColor;
    if (btn.selected) {
        btn.backgroundColor = [UIColor clearColor];
        [btn setTitleColor:COLOR_NAV_RED forState:UIControlStateSelected];
        btn.layer.borderColor = COLOR_NAV_RED.CGColor;
    }
    [self addSubview:btn];

    return  btn;
}

-(UILabel *)title{
    if (!_title) {
        _title  = [[UILabel alloc] init];
        [_title  setFont:[UIFont systemFontOfSize:15]];
        _title.textColor = [UIColor blackColor];
        _title.text = @"这是标题";
    }
    return _title;
}

@end
