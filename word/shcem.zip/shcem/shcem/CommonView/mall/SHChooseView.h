//
//  SHChooseView.h
//  shcem
//
//  Created by huangdeyu on 2016/11/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SHChooseViewDelegate <NSObject>

@required
-(void)selectWithIndex:(NSInteger)index contents:(NSArray *)contents key:(NSString *)key;           //点选的是产地，交货地，配送范围
-(void)bottmBtnClicked:(NSInteger)tag;
-(void)navBackClicked;
@end

@interface SHChooseView : UIView
@property(nonatomic,weak) id<SHChooseViewDelegate> delegate;
-(void)loadData:(NSDictionary *)dic selectedDatas:(NSMutableDictionary *)selectedDic;
-(void)reloadSection1;
@end
