//
//  SHChooseDetailCell.h
//  shcem
//
//  Created by huangdeyu on 2016/11/30.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHChooseDetailCell : UITableViewCell
@property(nonatomic,assign) BOOL status;        //状态，选中和未选中
-(void)loadTitle:(NSString *)title status:(BOOL)status;
@end
