//
//  SHMallListCellTableViewCell.m
//  shcem
//
//  Created by huangdeyu on 2016/11/22.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHMallListCellTableViewCell.h"
#import "Masonry.h"
#import "SHMallListModel.h"


@interface SHMallListCellTableViewCell()
@property(nonatomic,strong)UIView * bgView;
@property(nonatomic,strong)UILabel * goodsTypeView;
@property (nonatomic, strong) UILabel *sourcePlaceView;
@property(nonatomic,strong)UILabel * seriesView;
@property(nonatomic,strong)UILabel * timeView;
@property(nonatomic,strong)UILabel * priceView;
@property(nonatomic,strong)UILabel * weightView;
@property(nonatomic,strong)UILabel * statusView;
@end

@implementation SHMallListCellTableViewCell


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.bgView];
        [self.contentView addSubview:self.goodsTypeView];
        [self.contentView addSubview:self.sourcePlaceView];
        [self.contentView addSubview:self.seriesView];
        [self.contentView addSubview:self.timeView];
        [self.contentView addSubview:self.priceView];
        [self.contentView addSubview:self.weightView];
        [self.contentView addSubview:self.statusView];
        [self layout];
    }
    return self;
}
-(void)layout{
    [self.bgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.contentView);
    }];
    [self.goodsTypeView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@15);
        make.left.equalTo(@15);
        make.height.equalTo(@19);
        make.width.equalTo(@38);
    }];
    [self.sourcePlaceView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.goodsTypeView);
        make.left.equalTo(self.goodsTypeView.mas_right).offset(6);
        make.width.equalTo(@38);
        make.height.equalTo(@19);
    }];
    [self.seriesView mas_makeConstraints:^(MASConstraintMaker *make) {
      //  make.baseline.equalTo(self.goodsTypeView);
        make.centerY.equalTo(self.goodsTypeView);
        make.left.equalTo(self.sourcePlaceView.mas_right).offset(6);
        make.right.equalTo(self).offset(-60);
    }];
    [self.timeView mas_makeConstraints:^(MASConstraintMaker *make) {
        //make.baseline.equalTo(self.goodsTypeView);
          make.centerY.equalTo(self.goodsTypeView);
        make.right.equalTo(self.contentView.mas_right).offset(-15);
    }];
    [self.priceView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.contentView.mas_bottom).offset(-15);
        make.left.equalTo(@15);
    }];
    [self.weightView mas_makeConstraints:^(MASConstraintMaker *make) {
      //  make.baseline.equalTo(self.priceView);
        make.centerY.equalTo(self.priceView);
        make.left.equalTo(self.priceView.mas_right).offset(15);
        make.right.equalTo(self).offset(-60);
    }];
    [self.statusView mas_makeConstraints:^(MASConstraintMaker *make) {
       // make.baseline.equalTo(self.priceView);
        make.centerY.equalTo(self.priceView);
        make.right.equalTo(self.contentView.mas_right).offset(-15);
    }];
}
-(void)loadData:(SHMallListModel *)model{
    self.goodsTypeView.text =  model.GoodsTypeShow;
    if([model.GoodsTypeShow isEqualToString:@"现货"]){
        self.goodsTypeView.layer.backgroundColor  = COLOR_NAV_RED.CGColor;
        self.goodsTypeView.textColor = [UIColor whiteColor];
    }else{
        self.goodsTypeView.layer.backgroundColor = [UIColor clearColor].CGColor;
        self.goodsTypeView.textColor = COLOR_NAV_RED;
    }
    if(model.SourcePlaceType == 1) {
        self.sourcePlaceView.layer.backgroundColor = HexRGB(0x2b94ff).CGColor;
        self.sourcePlaceView.text = @"国产";
    } else if (model.SourcePlaceType == 0) {
        self.sourcePlaceView.layer.backgroundColor = HexRGB(0xfe8832).CGColor;
        self.sourcePlaceView.text = @"进口";
    }
    self.seriesView.text = [NSString stringWithFormat:@"%@ - %@ - %@",model.CategoryShow,model.BrandShow,model.SourcePlaceShow];
    self.timeView.text = [model.REC_CREATETIMEShow timeDistance];;
 
    self.priceView.text = [NSString stringWithFormat:@"%@元/吨", [NSNumber numberWithFloat:model.Price].stringValue];
  //  double price = model.DealtQuantity * model.TradeUnitNumber + model.ResidualQuantity * model.TradeUnitNumber;
    double price = model.ResidualWeight;
    NSNumber * priceNum = [NSNumber numberWithDouble:price];
    self.weightView.text = [NSString stringWithFormat:@"%@吨  |  %@", priceNum,model.FirmShowName];
    self.statusView.text = model.LeadsStatusShow;
    if([model.LeadsStatusShow isEqualToString:@"有效"]){
        self.statusView.textColor = HexRGB(0x2b94ff);
    }else if([model.LeadsStatusShow isEqualToString:@"成交"]){
        self.statusView.textColor = HexRGB(0x00b400);
    }else{
        self.statusView.textColor = HexRGB(0x999999);
    }
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

#pragma mark - 初始化
-(UIView *)bgView{
    if (!_bgView) {
        _bgView = [[UIView alloc] init];
       // _bgView.backgroundColor = [UIColor lightGrayColor];
    }
    return _bgView;
}
-(UILabel *)goodsTypeView{
    if (!_goodsTypeView) {
        _goodsTypeView = [[UILabel alloc] init];
        _goodsTypeView.layer.cornerRadius = 5.0;
        _goodsTypeView.layer.masksToBounds = YES;
        _goodsTypeView.layer.borderColor = COLOR_NAV_RED.CGColor;
        _goodsTypeView.layer.borderWidth = 1.0;
        [_goodsTypeView setFont:[UIFont systemFontOfSize:12]];
        [_goodsTypeView setTextAlignment:NSTextAlignmentCenter];
        
    }
    return _goodsTypeView;
}
- (UILabel *)sourcePlaceView{
    if(!_sourcePlaceView){
        _sourcePlaceView = [[UILabel alloc] init];
        _sourcePlaceView.layer.cornerRadius = 5.0;
        _sourcePlaceView.layer.masksToBounds = YES;
        _sourcePlaceView.font = [UIFont systemFontOfSize:12];
        _sourcePlaceView.textAlignment = NSTextAlignmentCenter;
        _sourcePlaceView.textColor = WHITE;
    }
    return _sourcePlaceView;
}
-(UILabel *)seriesView{
    if (!_seriesView) {
        _seriesView = [[UILabel alloc] init];
        _seriesView.textColor = BLACK_CUSTOM;
        [_seriesView setFont:[UIFont systemFontOfSize:14]];
    }
    return _seriesView;
}
-(UILabel *)timeView{
    if (!_timeView) {
        _timeView = [[UILabel alloc] init];
        _timeView.textColor = HexRGB(0x999999);
        [_timeView setTextAlignment:NSTextAlignmentCenter];
        [_timeView setFont:[UIFont systemFontOfSize:10]];
    }
    return _timeView;
}
-(UILabel *)priceView{
    if (!_priceView) {
        _priceView = [[UILabel alloc] init];
        _priceView.textColor = COLOR_NAV_RED;
        [_priceView setFont:[UIFont systemFontOfSize:16]];
    }
    return _priceView;
}
-(UILabel *)weightView{
    if(!_weightView){
        _weightView = [[UILabel alloc] init];
        _weightView.textColor =HexRGB(0x999999);
        [_weightView setFont:[UIFont systemFontOfSize:12]];
    }
    return _weightView;
}
-(UILabel *)statusView{
    if (!_statusView) {
        _statusView =[[UILabel alloc] init];
        _statusView.textColor = [UIColor blueColor];
        [_statusView setFont:[UIFont systemFontOfSize:12]];
    }
    return _statusView;
}


@end
