//
//  SHScreenAnimator.m
//  shcem
//
//  Created by huangdeyu on 2016/11/24.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHScreenAnimator.h"
#import "SHMallChooseVC.h"
#import "SHMallVC.h"
#import "SHBaseTabarController.h"
#import "SHBaseNavigationController.h"

@interface SHScreenAnimator ()
@property(nonatomic,assign)UINavigationControllerOperation animatorType;
@end

@implementation SHScreenAnimator

-(instancetype)initWithAnimatorType:(UINavigationControllerOperation)type{
    if (self = [super init]) {
        self.animatorType = type;
    }
    return self;
}

-(NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext{
    if (self.animatorType == UINavigationControllerOperationPop) {
        return 0.4;
    }
    return  0.5;
}
-(void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext{
    switch (self.animatorType) {
        case UINavigationControllerOperationPush:
            [self pushWithContext:transitionContext];
            break;
        case  UINavigationControllerOperationPop:
            [self popWithContext:transitionContext];
        default:
            break;
    }
}

-(void)pushWithContext:(id<UIViewControllerContextTransitioning>) context{
    UIViewController * fromVC   = [context viewControllerForKey:UITransitionContextFromViewControllerKey];
    UIViewController * toVC = [context viewControllerForKey:UITransitionContextToViewControllerKey];
    UIView * containView = [context containerView];
    [containView addSubview:toVC.view];
    toVC.view.alpha = 0.3;
    [UIView animateWithDuration:[self transitionDuration:context] animations:^{
        toVC.view.alpha = 1;
        if ([toVC isKindOfClass:[SHMallChooseVC class]]) {
            [(SHMallChooseVC *)toVC showChooseView];
        }
        
        fromVC.view.transform = CGAffineTransformMakeScale(0.95, 0.95);
    } completion:^(BOOL finished) {
        [context completeTransition:![context transitionWasCancelled]];
        if ([context transitionWasCancelled]) {
            
        }
    }];
}
-(void)popWithContext:(id<UIViewControllerContextTransitioning>)context{
    UIViewController * fromVC   = [context viewControllerForKey:UITransitionContextFromViewControllerKey];
     UIViewController * toVC = [context viewControllerForKey:UITransitionContextToViewControllerKey];
    [UIView animateWithDuration:[self transitionDuration:context] animations:^{
        if ([fromVC isKindOfClass:[SHMallChooseVC class]]) {
            [(SHMallChooseVC *)fromVC hideChooseView];
        }
        fromVC.view.alpha = 0;
        toVC.view.transform = CGAffineTransformIdentity;
    }completion:^(BOOL finished) {
        if ([context transitionWasCancelled]) {
            [context completeTransition:NO];
        }else{
            [context completeTransition:YES];
            if ([toVC isKindOfClass:[SHBaseTabarController class]]) {
                SHBaseTabarController * tabVC = (SHBaseTabarController *)toVC;
                SHBaseNavigationController * nav = (SHBaseNavigationController *)tabVC.selectedViewController;
                ((SHMallVC *)nav.topViewController).needReaload = YES;
            }
        }
    }];
}
//// This is a convenience and if implemented will be invoked by the system when the transition context's completeTransition: method is invoked.
//- (void)animationEnded:(BOOL) transitionCompleted{
//}
@end
