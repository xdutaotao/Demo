//
//  SHMallSearchView.h
//  shcem
//
//  Created by huangdeyu on 2016/11/23.
//  Copyright © 2016年 Shcem. All rights reserved.
//导航栏

#import <UIKit/UIKit.h>

@protocol SHMallSearchViewDelegate <NSObject>

@required
-(void)navBtnClicked:(UIButton *)btn;
-(void)showTableView;
-(void)hideTableView;
-(void)searchKeyboardClicked;
@end

@interface SHMallSearchView : UIView
@property(nonatomic,strong)UITextField * textField;
@property(nonatomic,weak)id<SHMallSearchViewDelegate> delegate;
-(void)showTableView;
-(void)hideTableView;
-(void)setText:(NSString *)text;
-(NSString *)searchStr;
-(void)updateMsg:(BOOL)msg;
@end
