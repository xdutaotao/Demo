//
//  SHChooseDetailView.h
//  shcem
//
//  Created by huangdeyu on 2016/11/29.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SHChooseDetailViewDelegate <NSObject>

@required
-(void)navBackClicked;
-(void)updateSelectedWithArr:(NSArray *)arr titles:(NSArray *)titles;
@end

@interface SHChooseDetailView : UIView
@property(nonatomic,weak) id<SHChooseDetailViewDelegate> delegate;
-(void)loadDatas:(NSArray *)datas currentSelectArr:(NSArray *)arr currentSelectedTitles:(NSArray *)titles;
-(instancetype)initWithFrame:(CGRect)frame withTitle:(NSString *)title;
@end
