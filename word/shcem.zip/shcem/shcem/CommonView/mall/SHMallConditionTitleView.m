//
//  SHMallConditionTitleView.m
//  shcem
//
//  Created by huangdeyu on 2016/11/23.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHMallConditionTitleView.h"
#import "Masonry.h"

@interface SHMallConditionTitleView ()
@property(nonatomic,strong) UIButton * timeSortBtn;
@property(nonatomic,strong) UIButton * priceSortBtn;
@property(nonatomic,strong) UIButton * chooseBtn;
@property(nonatomic,strong) UIImage * currentImg;
@property(nonatomic,strong) UIImage * upDownImg;
@property(nonatomic,strong) UIImage * upImg;
@property(nonatomic,strong) UIImage * downImg;
@end

@implementation SHMallConditionTitleView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.upImg = [UIImage imageNamed:@"up_h_down"];
        self.downImg = [UIImage imageNamed:@"up_down_h"];
        self.upDownImg = [UIImage imageNamed:@"up_down"];
        self.currentImg = self.downImg;
        [self addSubview:self.timeSortBtn];
        [self addSubview:self.priceSortBtn];
        [self addSubview:self.chooseBtn];
        self.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1];
        self.btnStyle = highToLow;
        [self layout];
    }
    return self;
}
-(void)layout{
    [self.timeSortBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self);
        make.bottom.equalTo(self).offset(-0.5);
        make.left.equalTo(self);
        make.width.equalTo(@(self.width / 3.0));
    }];
    
    [self.priceSortBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self);
        make.bottom.equalTo(self).offset(-0.5);
        make.width.equalTo(@(self.width / 3.0));
        make.left.equalTo(self.timeSortBtn.mas_right);
    }];
    [self.chooseBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self);
        make.bottom.equalTo(self).offset(-0.5);
        make.width.equalTo(@(self.width / 3.0));
        make.right.equalTo(self);
    }];
    
}

#pragma mark - action
-(void)btnClicked:(UIButton *)btn{
    if (btn.isSelected) {
        //如果是选中的按钮需要改变的是它的排序方式
        self.btnStyle++;
        if(self.btnStyle > 1){
            self.btnStyle = 0;
            self.currentImg = self.downImg;
        }else{
            self.currentImg = self.upImg;
        }
    }else{
        self.btnStyle = highToLow;
        self.currentImg = self.downImg;
        [self.timeSortBtn setSelected:NO];
        [self.priceSortBtn setSelected:NO];
        [btn setSelected:YES];
    }
    DLog(@"当前选择的排序是%ld",(long)self.btnStyle);
     [btn setImage:self.currentImg forState:UIControlStateSelected];
    [self.delegate timeOrPriceClicked:btn sortType:self.btnStyle];
}
-(void)chooseBtnClicked:(UIButton *)btn{
    DLog(@"点击了筛选");
    [self.delegate chooseClicked:btn];
}
-(void)updateConditionsWithCount:(NSInteger)count{
    if (count > 0) {
        NSString * title = [NSString stringWithFormat:@"筛选(%ld)",(long)count];
        [self.chooseBtn setTitle:title forState:UIControlStateNormal];
        [_chooseBtn setTitleColor:COLOR_NAV_RED forState:UIControlStateNormal];
        _chooseBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 30, 0, -30);
        _chooseBtn.titleEdgeInsets = UIEdgeInsetsMake(0, -30, 0, 30);
    }else{
        [self.chooseBtn setTitle:@"筛选" forState:UIControlStateNormal];
        [_chooseBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _chooseBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 25, 0, -25);
        _chooseBtn.titleEdgeInsets = UIEdgeInsetsMake(0, -25, 0, 25);
    }
}

#pragma mark - 初始化
-(UIButton *)timeSortBtn{
    if (!_timeSortBtn) {
        _timeSortBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_timeSortBtn setBackgroundColor:[UIColor whiteColor]];
        [_timeSortBtn.titleLabel setFont:[UIFont systemFontOfSize:14]];
        [_timeSortBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_timeSortBtn setTitleColor:COLOR_NAV_RED forState:UIControlStateSelected];
        [_timeSortBtn setTitle:@"时间" forState:UIControlStateNormal];
        [_timeSortBtn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [_timeSortBtn setSelected:YES];
        [_timeSortBtn setImage:self.upDownImg forState:UIControlStateNormal];
        [_timeSortBtn setImage:self.downImg forState:UIControlStateSelected];
        _timeSortBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 20, 0, -20);
        _timeSortBtn.titleEdgeInsets = UIEdgeInsetsMake(0, -20, 0, 20);
        _timeSortBtn.tag = 10;
    }
    return _timeSortBtn;
}
-(UIButton *)priceSortBtn{
    if (!_priceSortBtn) {
        _priceSortBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_priceSortBtn setBackgroundColor:[UIColor whiteColor]];
        [_priceSortBtn.titleLabel setFont:[UIFont systemFontOfSize:14]];
        [_priceSortBtn setTitle:@"价格" forState:UIControlStateNormal];
        [_priceSortBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_priceSortBtn setTitleColor:COLOR_NAV_RED forState:UIControlStateSelected];
        [_priceSortBtn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
        _priceSortBtn.tag = 11;
        [_priceSortBtn setImage:self.upDownImg forState:UIControlStateNormal];
        [_priceSortBtn setImage:self.downImg forState:UIControlStateSelected];
        _priceSortBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 20, 0, -20);
        _priceSortBtn.titleEdgeInsets = UIEdgeInsetsMake(0, -20, 0, 20);
    }
    return _priceSortBtn;
}
-(UIButton *)chooseBtn{
    if (!_chooseBtn) {
        _chooseBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_chooseBtn setBackgroundColor:[UIColor whiteColor]];
        [_chooseBtn.titleLabel setFont:[UIFont systemFontOfSize:14]];
        [_chooseBtn setTitle:@"筛选" forState:UIControlStateNormal];
        [_chooseBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_chooseBtn setTitleColor:COLOR_NAV_RED forState:UIControlStateHighlighted];
        [_chooseBtn addTarget:self action:@selector(chooseBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [_chooseBtn setImage:[UIImage imageNamed:@"choose"] forState:UIControlStateNormal];
        _chooseBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 25, 0, -25);
        _chooseBtn.titleEdgeInsets = UIEdgeInsetsMake(0, -25, 0, 25);
        _chooseBtn.tag = 12;
    }
    return _chooseBtn;
}

@end
