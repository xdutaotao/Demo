//
//  SHChooseDetailCell.m
//  shcem
//
//  Created by huangdeyu on 2016/11/30.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHChooseDetailCell.h"
#import "Masonry.h"

@interface SHChooseDetailCell ()
@property(nonatomic,strong) UILabel * title;
@property(nonatomic,strong) UIImageView * selectedImage;

@end

@implementation SHChooseDetailCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.title];
        [self.contentView addSubview:self.selectedImage];
        [self layout];
    }
    return  self;
}
-(void)layout{
    [self.title mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.contentView);
        make.left.equalTo(self.contentView.mas_left).offset(20);
    }];
    [self.selectedImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.contentView);
        make.right.equalTo(self.contentView.mas_right).offset(-10);
    }];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}
-(void)loadTitle:(NSString *)title status:(BOOL)status{
    self.title.text = title;
    self.status = status;
}

#pragma mark - setter
-(void)setStatus:(BOOL)status{
    _status = status;
    if (status) {
        self.selectedImage.hidden = NO;
        self.title.textColor = COLOR_NAV_RED;
    }else{
        self.title.textColor = BLACK_CUSTOM;
        self.selectedImage.hidden = YES;
    }
}

#pragma mark - 初始化
-(UILabel *)title{
    if (!_title) {
        _title = [[UILabel alloc] init];
        [_title setFont:[UIFont systemFontOfSize:14]];
    }
    return _title;
}
-(UIImageView *)selectedImage{
    if (!_selectedImage) {
        UIImage * img = [UIImage imageNamed:@"choosed"];
        _selectedImage = [[UIImageView alloc] initWithImage:img];
    }
    return _selectedImage;
}

@end
