//
//  SHChooseDetailView.m
//  shcem
//
//  Created by huangdeyu on 2016/11/29.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHChooseDetailView.h"
#import "SHChooseDetailCell.h"
#import "SHChooseViewNavView.h"

@interface SHChooseDetailView ()<UITableViewDelegate,UITableViewDataSource,SHChooseViewNavViewDelegate>
@property(nonatomic,strong) UITableView * tableView;
@property(nonatomic,strong) SHChooseViewNavView * navView;
@property(nonatomic,strong) NSArray * datas;
@property(nonatomic,strong) NSMutableArray * currentSelectArr;
@property(nonatomic,strong) NSMutableArray * currentSelectTitles;
@property(nonatomic,strong) NSMutableArray<NSString *> * sectionTitles;
@property(nonatomic,copy) NSString * title;
@end

@implementation SHChooseDetailView
-(instancetype)initWithFrame:(CGRect)frame withTitle:(NSString *)title{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        self.title = title;
        [self addSubview:self.tableView];
        [self addSubview:self.navView];
    }
    return self;
}
-(void)loadDatas:(NSArray *)data currentSelectArr:(NSArray *)arr currentSelectedTitles:(NSArray *)titles{
    self.datas = data;
    self.currentSelectTitles = [titles mutableCopy];
    self.currentSelectArr = [arr mutableCopy];
    [self dealWithSectionTitles];
    [self.tableView reloadData];
}
-(void)dealWithSectionTitles{
    self.sectionTitles = [NSMutableArray array];
    [self.datas enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSDictionary * dic = obj;
        NSString * name = [dic objectForKey:@"name"];
        [self.sectionTitles addObject:name];
    }];
}

#pragma mark - tableView delegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.datas.count;
}
-(NSArray<NSString *> *)sectionIndexTitlesForTableView:(UITableView *)tableView{
    return self.sectionTitles;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 40;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 20;
}
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return self.sectionTitles[section];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSDictionary * dic = self.datas[section];
    NSArray * arr = [dic objectForKey:@"data"];
    return  arr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    SHChooseDetailCell * cell = [tableView dequeueReusableCellWithIdentifier:@"SHChooseDetailCell"];
    if (!cell) {
        cell = [[SHChooseDetailCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"SHChooseDetailCell"];
    }
    NSDictionary * dic = self.datas[indexPath.section];
    NSArray * arr = [dic objectForKey:@"data"];
    NSDictionary * d2 = arr[indexPath.row];
    __block   BOOL status = NO;
    [self.currentSelectArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj isEqual:[d2 objectForKey:@"valueId"]]) {
            status = YES;
            *stop = YES;
        }
    }];
     [cell loadTitle:[d2 objectForKey:@"value"] status:status];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    SHChooseDetailCell * cell = [tableView cellForRowAtIndexPath:indexPath];
    cell.status = !cell.status;
    
    NSDictionary * dic = self.datas[indexPath.section];
    NSArray * arr = [dic objectForKey:@"data"];
    NSDictionary * d2 = arr[indexPath.row];
    NSNumber * valueId =[d2 objectForKey:@"valueId"];
    NSString * value = [d2 objectForKey:@"value"];
    if (cell.status) {//如果处于选中状态需要更新，已选中的内容
        if (![self.currentSelectArr containsObject:valueId]) {
            [self.currentSelectArr addObject:valueId];
            [self.currentSelectTitles addObject:value];
        }
    }else{
        if ([self.currentSelectArr containsObject:valueId]) {
            [self.currentSelectArr removeObject:valueId];
            [self.currentSelectTitles removeObject:value];
        }
    }
    [self.delegate updateSelectedWithArr:self.currentSelectArr titles:self.currentSelectTitles];
    DLog(@"当前选择的数组是%@",self.currentSelectArr);
}
#pragma mark - nav delegate
-(void)navBackClicked{
    [self.delegate navBackClicked];
}


#pragma mark - 初始化
-(UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, NavgationBarHeight, self.width, self.height - NavgationBarHeight)];
        [_tableView registerClass:[SHChooseDetailCell class] forCellReuseIdentifier:@"SHChooseDetailCell"];
        _tableView.delegate = self;
        _tableView.dataSource = self;
    }
    return _tableView;
}
-(SHChooseViewNavView *)navView{
    if (!_navView) {
        _navView = [[SHChooseViewNavView alloc] initWithFrame:CGRectMake(0, 0, self.width, NavgationBarHeight) andTitle:self.title];
        _navView.delegate = self;
    }
    return _navView;
}
@end
