//
//  SHMallConditionTitleView.h
//  shcem
//
//  Created by huangdeyu on 2016/11/23.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef NS_ENUM(NSInteger,SHMallConditionStyle){
    highToLow = 0,          //价格从高到低，时间从近到远
    lowToHigh           //价格从低到高，时间由远及近
};

@protocol SHMallConditionTitleViewDelegate  <NSObject>

@required
-(void)timeOrPriceClicked:(UIButton *)btn sortType:(SHMallConditionStyle)type;
-(void)chooseClicked:(UIButton *)btn;
@end

@interface SHMallConditionTitleView : UIView
@property(nonatomic,weak) id<SHMallConditionTitleViewDelegate> delegate;
@property(nonatomic,assign) SHMallConditionStyle  btnStyle;
-(void)updateConditionsWithCount:(NSInteger)count;
@end
