//
//  UIMallSearchListView.h
//  shcem
//
//  Created by huangdeyu on 2016/11/23.
//  Copyright © 2016年 Shcem. All rights reserved.
//点击搜索框出来的列表项

#import <UIKit/UIKit.h>

@protocol SHMallSearchListViewDelegate <NSObject>

@required
-(void)searchOverWith:(NSString *)str;
-(void)clearBtnClicked;
- (void)searchHistoryScroll;
@end

@interface SHMallSearchListView : UIView
@property(nonatomic,weak) id<SHMallSearchListViewDelegate> delegate;
-(void)loadData:(NSMutableArray *)data;
-(void)showInView:(UIView *)view;
-(void)hide;
- (void)searchShow;
- (void)searchHide;
@end
