//
//  SHActivityProgressView.h
//  Frey
//
//  Created by huangdeyu on 16/3/3.
//  Copyright © 2016年 shcem. All rights reserved.
//一个webView网络加载的loading

#import <UIKit/UIKit.h>

@interface SHActivityProgressView : UIView
@property(nonatomic,strong) CAGradientLayer * mLayer;
@property(nonatomic,strong) NSTimer * timer;
-(void)startLoading;
-(void)endLoading;
@end
