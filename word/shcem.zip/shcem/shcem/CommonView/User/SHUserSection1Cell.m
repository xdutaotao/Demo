//
//  SHUserSection1Cell.m
//  shcem
//
//  Created by huangdeyu on 2016/12/8.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHUserSection1Cell.h"
#import "Masonry.h"

@interface SHUserSection1Cell ()
@property(nonatomic,strong)UIImageView * img;
@property(nonatomic,strong)UILabel * leftTitle;
@property(nonatomic,strong)UILabel * detailLabel;
@property(nonatomic,strong) UIImageView * lineView;
@end

@implementation SHUserSection1Cell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self addSubview:self.img];
        [self addSubview:self.leftTitle];
        [self addSubview:self.detailLabel];
        [self addSubview:self.lineView];
        [self layout];
    }
    return self;
}

-(void)layout{
    [self.img mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(15);
        make.centerY.equalTo(self);
    }];
    [self.leftTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.img.mas_right).offset(5);
        make.centerY.equalTo(self);
    }];
    [self.detailLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.right.equalTo(self).offset(-35);
        make.width.greaterThanOrEqualTo(@25);
        make.height.greaterThanOrEqualTo(@25);
    }];
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(15);
        make.right.equalTo(self);
        make.bottom.equalTo(self);
        make.height.equalTo(@0.3);
    }];
}

-(void)updateWithImg:(NSString *)imgName title:(NSString *)title detailTitle:(NSString *)detailTitle type:(SHUserListDetailStyle) style{
    self.img.image = [UIImage imageNamed:imgName];
    self.leftTitle.text = title;
    
    switch (style) {
        case SHUserListDetailStyleNormal:{
            if ([detailTitle isKindOfClass:[NSMutableAttributedString class]]) {
                self.detailLabel.attributedText = (NSMutableAttributedString *)detailTitle;
            }else{
                self.detailLabel.text = detailTitle;
            }
            self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            self.selectionStyle = UITableViewCellSelectionStyleDefault;
            _detailLabel.backgroundColor = [UIColor clearColor];
            [self.detailLabel mas_updateConstraints:^(MASConstraintMaker *make) {
                make.right.equalTo(self).offset(-35);
            }];
        }
            break;
        case SHUserListDetailStyleTrader:{
            self.accessoryType = UITableViewCellAccessoryNone;
            self.selectionStyle = UITableViewCellSelectionStyleNone;
            _detailLabel.backgroundColor = BACKGROUNDCOLOR_CUSTOM;
            if (detailTitle.length > 1) {
                self.detailLabel.text = [NSString stringWithFormat:@" %@   ",detailTitle];
            }else{
                self.detailLabel.text = detailTitle;
            }
            [self.detailLabel mas_updateConstraints:^(MASConstraintMaker *make) {
                make.right.equalTo(self).offset(-10);
            }];
        }
            break;
        case SHUserListDetailStyleSub:{
            self.detailLabel.text = detailTitle;
            self.accessoryType = UITableViewCellAccessoryNone;
            self.selectionStyle = UITableViewCellSelectionStyleNone;
            _detailLabel.backgroundColor = [UIColor clearColor];
             self.detailLabel.width = 14 * detailTitle.length;
            [self.detailLabel mas_updateConstraints:^(MASConstraintMaker *make) {
                make.right.equalTo(self).offset(-28);
            }];
        }
            break;
        default:
            break;
    }
}

#pragma mark - 初始化
-(UIImageView *)img{
    if (!_img) {
        _img = [[UIImageView alloc] init];
    }
    return _img;
}
-(UILabel *)leftTitle{
    if (!_leftTitle) {
        _leftTitle = [[UILabel alloc] init];
        [_leftTitle setFont:[UIFont systemFontOfSize:14]];
        [_leftTitle setTextColor:BLACK_CUSTOM];
    }
    return _leftTitle;
}
-(UILabel *)detailLabel{
    if (!_detailLabel) {
        _detailLabel = [[UILabel alloc] init];
        [_detailLabel setFont:[UIFont systemFontOfSize:12]];
        [_detailLabel setTextColor:HexRGB(0xc9c9c9)];
        _detailLabel.textAlignment = NSTextAlignmentCenter;
        
        _detailLabel.layer.cornerRadius = 12;
        _detailLabel.layer.masksToBounds = YES;
    }
    return _detailLabel;
}
-(UIImageView *)lineView{
    if (!_lineView) {
        _lineView = [[UIImageView alloc] init];
        //_lineView.backgroundColor = BACKGROUNDCOLOR_CUSTOM;
        _lineView.image = [UIImage imageWithColor:[COLOR_LINE_DEFAULT colorWithAlphaComponent:0.8]];
    }
    return _lineView;
}

@end
