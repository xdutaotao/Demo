//
//  SHSetPaymentView.h
//  shcem
//
//  Created by huangdeyu on 2016/12/14.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SHSetPaymentViewDelegate <NSObject>

@required
-(void)btnClicked:(UIButton *)btn;

@end

@interface SHSetPaymentView : UIView
@property(nonatomic,weak) id<SHSetPaymentViewDelegate> delegate;

-(void)updateHiddenWithStr:(NSString *)str;
@end
