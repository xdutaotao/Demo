//
//  SHUserHeaderView.m
//  shcem
//
//  Created by huangdeyu on 2016/12/8.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHUserHeaderView.h"
#import "Masonry.h"
#import "SDWebImage/UIButton+WebCache.h"

@interface SHUserHeaderView ()
@property(nonatomic,strong)UIButton * avatarBtn;
@property (nonatomic, strong) UILabel *userNameLabel;
@property(nonatomic,strong)UIButton * userNameBtn;
@property(nonatomic,strong)UILabel * welcomeLabel;
@property (nonatomic, strong) UIImageView *rightImage;
@end

@implementation SHUserHeaderView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.avatarBtn];
        [self addSubview:self.userNameLabel];
        [self addSubview:self.rightImage];
        [self addSubview:self.userNameBtn];
        [self addSubview:self.welcomeLabel];
        [self layout];
    }
    return self;
}
-(void)layout{
    [self.avatarBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.left.equalTo(self.mas_left).offset(20);
        make.width.equalTo(@(self.height - 20));
        make.height.equalTo(@(self.height - 20));
    }];
    [self.userNameBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.avatarBtn.mas_right).offset(20);
        make.width.equalTo(@(ScreenWidth - self.userNameBtn.left));
        make.height.equalTo(@(self.height));
    }];
    [self.userNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.avatarBtn.mas_right).offset(20);
        make.centerY.equalTo(self).offset(-10);
    }];
    [self.welcomeLabel   mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.avatarBtn.mas_right).offset(20);
        make.centerY.equalTo(self).offset(10);
    }];
    [self.rightImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(@(self.width - 30));
        make.centerY.equalTo(self);
    }];

}
-(void)btnClicked:(UIButton *)btn{
    [self.delegate userBtnClickedWithTag:btn.tag];
    if (btn.tag == 0) {
        DLog(@"当前点击的是头像");
    }else{
        DLog(@"当前点击的是用户名");
    }
}
-(void)updateUserName:(NSString *)name{
    if (!name) {
        name = STR_SHOW_CLICK_LOGIN;
    }
    self.userNameLabel.text = name;
}
-(void)updateUserAvatar:(NSString *)avatar{
    if (!avatar) {
        [_avatarBtn setBackgroundImage:[UIImage imageNamed:@"user_header"] forState:UIControlStateNormal];
        return;
    }
    DLog(@"头像URL是%@",avatar);
    [self.avatarBtn sd_setBackgroundImageWithURL:[NSURL URLWithString:avatar] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"user_header"]];
}

#pragma mark - 初始化
-(UIButton *)avatarBtn{
    if (!_avatarBtn) {
        _avatarBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_avatarBtn  addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
        _avatarBtn.tag = 0;
        [_avatarBtn setBackgroundImage:[UIImage imageNamed:@"user_header"] forState:UIControlStateNormal];
        _avatarBtn.layer.masksToBounds = YES;
        _avatarBtn.layer.cornerRadius = (self.height - 20) * .5;
    }
    return _avatarBtn;
}
- (UILabel *)userNameLabel{
    if(!_userNameLabel){
        _userNameLabel = [[UILabel alloc] init];
        [_userNameLabel setTextColor:BLACK_CUSTOM];
        [_userNameLabel setText:@"用户未登录"];
        _userNameLabel.font = [UIFont systemFontOfSize:16];
    }
    return _userNameLabel;
}
-(UIButton *)userNameBtn{
    if (!_userNameBtn) {
        _userNameBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_userNameBtn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
        _userNameBtn.tag = 1;
    }
    return _userNameBtn;
}
-(UILabel *)welcomeLabel{
    if (!_welcomeLabel) {
        _welcomeLabel = [[UILabel alloc] init];
        _welcomeLabel.text = @"您好! 欢迎光临上海化交网";
        _welcomeLabel.textColor = HexRGB(0x999999);
        [_welcomeLabel setFont:[UIFont systemFontOfSize:12]];
    }
    return _welcomeLabel;
}
- (UIImageView *)rightImage{
    if(!_rightImage){
        _rightImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"arrow_right"]];
    }
    return _rightImage;
}



@end
