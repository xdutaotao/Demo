//
//  SHUserHeaderView.h
//  shcem
//
//  Created by huangdeyu on 2016/12/8.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SHUserHeaderViewDelegate <NSObject>

@required
-(void)userBtnClickedWithTag:(NSInteger)btntag;

@end

@interface SHUserHeaderView : UIView
@property(nonatomic,weak) id<SHUserHeaderViewDelegate> delegate;
-(void)updateUserName:(NSString *)name;
-(void)updateUserAvatar:(NSString *)avatar;
@end
