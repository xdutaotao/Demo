//
//  SHSetPaymentView.m
//  shcem
//
//  Created by huangdeyu on 2016/12/14.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHSetPaymentView.h"
#import "Masonry.h"

@interface SHSetPaymentView ()
@property(nonatomic,strong) UILabel * title;
@property(nonatomic,strong)  NSMutableArray<UIView *> * pwdView;
@property(nonatomic,strong) NSMutableArray<UIView *> * blackPointView;
@property(nonatomic,strong) UIView * lineView;
@property(nonatomic,strong) UIButton * cancelBtn;
@property(nonatomic,strong) UIButton * sureBtn;
@end

@implementation SHSetPaymentView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        self.layer.cornerRadius = 4.0;
        self.layer.masksToBounds = YES;
        self.clipsToBounds = YES;
        
        self.pwdView = [NSMutableArray array];
        self.blackPointView = [NSMutableArray array];
        [self addPwd];
        
        [self addSubview:self.title];
        [self addSubview:self.cancelBtn];
        [self addSubview:self.sureBtn];
        [self addSubview:self.lineView];
        [self layout];
    }
    return self;
}

-(void)addPwd{
    for (int i = 0; i < 6; i++) {
        UIView * v = [[UIView alloc] init];
        v.layer.borderColor = COLOR_LINE_DEFAULT.CGColor;
        v.layer.borderWidth = 0.5;
        [self.pwdView addObject:v];
        [self addSubview:v];
        
        UIView * vp = [[UIView alloc] init];
        vp.backgroundColor = [UIColor blackColor];
        vp.layer.cornerRadius = 5;
        vp.layer.masksToBounds = YES;
        [self.blackPointView addObject:vp];
        vp.hidden = YES;
        [self addSubview:vp];
    }
}

-(void)layout{
    [self.title mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self);
        make.top.equalTo(self).offset(15);
    }];
    [self.cancelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self);
        make.width.equalTo(@(self.width * .5));
        make.height.equalTo(@40);
        make.bottom.equalTo(self);
    }];
    [self.sureBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self);
        make.width.equalTo(@(self.width * .5));
        make.height.equalTo(@40);
        make.bottom.equalTo(self);
    }];
    CGFloat width = 40.0;
    if (isIPhone5) {
        width = 40.0;
    }
    if (isIPhone6 || isIPhone6Plus) {
        width = 50.0;
    }
    for (int i = 0; i < 6; i++) {
        [self.pwdView[i] mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.equalTo(@(width));
            make.height.equalTo(@(width));
            make.bottom.equalTo(self).offset(-65);
            make.centerX.equalTo(self.mas_centerX).offset(-width * 2.5 +  width * i);
        }];
        [self.blackPointView[i] mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.equalTo(@10);
            make.height.equalTo(@10);
            make.center.equalTo(self.pwdView[i]);
        }];
    }
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@(width * 6));
        make.height.equalTo(@(width));
        make.centerX.equalTo(self);
        make.bottom.equalTo(self).offset(-65);
    }];
}

-(void)updateHiddenWithStr:(NSString *)str{
    for (int i = 0; i < 6; i++) {
        if (i < str.length) {
            self.blackPointView[i].hidden = NO;
        }else{
            self.blackPointView[i].hidden = YES;
        }
    }
}

#pragma mark - action
-(void)btnClicked:(UIButton *)btn{
    [self.delegate btnClicked:btn];
}

#pragma mark - 初始化

-(UILabel *)title{
    if (!_title) {
        _title = [[UILabel alloc] init];
        _title.text = @"设置支付密码";
        [_title setFont:[UIFont systemFontOfSize:FONT_DEFAULT]];
    }
    return _title;
}

-(UIButton *)cancelBtn{
    if (!_cancelBtn) {
        _cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_cancelBtn setBackgroundImage:[UIImage imageWithColor:BACKGROUNDCOLOR_CUSTOM] forState:UIControlStateNormal];
        [_cancelBtn setTitle:STR_ALERT_CANCEL forState:UIControlStateNormal];
        [_cancelBtn setTitleColor:BLACK_CUSTOM forState:UIControlStateNormal];
        _cancelBtn.tag = 0;
        [_cancelBtn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _cancelBtn;
}

-(UIButton *)sureBtn{
    if (!_sureBtn) {
        _sureBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_sureBtn setBackgroundImage:[UIImage imageWithColor:COLOR_NAV_RED] forState:UIControlStateNormal];
        [_sureBtn setTitle:STR_ALERT_SURE forState:UIControlStateNormal];
        _sureBtn.tag = 1;
        [_sureBtn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _sureBtn;
}
-(UIView *)lineView{
    if (!_lineView) {
        _lineView = [[UIView alloc] init];
        _lineView.layer.borderWidth = 0.5;
        _lineView.layer.borderColor = COLOR_LINE_DEFAULT.CGColor;
    }
    return _lineView;
}

@end
