//
//  SHUserSection1Cell.h
//  shcem
//
//  Created by huangdeyu on 2016/12/8.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger,SHUserListDetailStyle){
    SHUserListDetailStyleTrader = 0,
    SHUserListDetailStyleSub,
    SHUserListDetailStyleNormal
};

@interface SHUserSection1Cell : UITableViewCell
-(void)updateWithImg:(NSString *)imgName title:(NSString *)title detailTitle:(NSString *)detailTitle type:(SHUserListDetailStyle) style;
@end
