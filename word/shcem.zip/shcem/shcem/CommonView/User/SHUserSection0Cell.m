//
//  SHUserSection0Cell.m
//  shcem
//
//  Created by huangdeyu on 2016/12/8.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHUserSection0Cell.h"

@interface SHUserSection0Cell ()
@property(nonatomic,strong)UILabel * leftLabel;
@property(nonatomic,strong)UILabel * rightLabel;
@end

@implementation SHUserSection0Cell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.leftLabel];
        [self.contentView addSubview:self.rightLabel];
        self.contentView.backgroundColor = RGBCOLOR(240, 240, 240);
        [self layout];
    }
    return self;
}
-(void)layout{
    self.leftLabel.frame = CGRectMake(0, 5, ScreenWidth * .5 - 0.5, 50);
    self.rightLabel.frame = CGRectMake(ScreenWidth * .5 + 0.5, 5, ScreenWidth * .5, 50);
}
-(void)loadSellData:(NSString *)data{
    NSString * str = [NSString stringWithFormat:@"已卖%@吨",data];
    NSMutableAttributedString * attStr = [[NSMutableAttributedString alloc] initWithString:str];
    [attStr setAttributes:@{NSForegroundColorAttributeName :[UIColor redColor],NSFontAttributeName:[UIFont systemFontOfSize:18]} range:NSMakeRange(2, attStr.length - 3)];
    _leftLabel.attributedText = attStr;
}
-(void)loadBuyData:(NSString *)data{
    NSString * str = [NSString stringWithFormat:@"已买%@吨",data];
    NSMutableAttributedString * attStr = [[NSMutableAttributedString alloc] initWithString:str];
    [attStr setAttributes:@{NSForegroundColorAttributeName :[UIColor redColor],NSFontAttributeName:[UIFont systemFontOfSize:18]} range:NSMakeRange(2, attStr.length - 3)];
    _rightLabel.attributedText = attStr;
}

#pragma mark - 初始化
-(UILabel *)leftLabel{
    if (!_leftLabel) {
        _leftLabel = [[UILabel alloc] init];
        NSMutableAttributedString  * attStr = [[NSMutableAttributedString alloc] initWithString:@"已卖0吨"];
        [attStr setAttributes:@{NSForegroundColorAttributeName :[UIColor redColor],NSFontAttributeName:[UIFont systemFontOfSize:18]} range:NSMakeRange(2, attStr.length - 3)];
        _leftLabel.textAlignment = NSTextAlignmentCenter;
        _leftLabel.backgroundColor = [UIColor whiteColor];
        [_leftLabel setFont:[UIFont systemFontOfSize:14]];
        [_leftLabel setTextColor:BLACK_CUSTOM];
        _leftLabel.attributedText = attStr;
    }
    return _leftLabel;
}
-(UILabel *)rightLabel{
    if (!_rightLabel) {
        _rightLabel = [[UILabel alloc] init];
        _rightLabel.textAlignment = NSTextAlignmentCenter;
        NSMutableAttributedString * attStr = [[NSMutableAttributedString alloc] initWithString:@"已买0吨"];
        [attStr setAttributes:@{NSForegroundColorAttributeName :[UIColor redColor],NSFontAttributeName:[UIFont systemFontOfSize:18]} range:NSMakeRange(2, attStr.length - 3)];
        
        _rightLabel.backgroundColor = [UIColor whiteColor];
        [_rightLabel setFont:[UIFont systemFontOfSize:14]];
        [_rightLabel setTextColor:BLACK_CUSTOM];
        _rightLabel.attributedText = attStr;
    }
    return _rightLabel;
}


@end
