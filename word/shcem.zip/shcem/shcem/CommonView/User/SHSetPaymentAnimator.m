//
//  SHSetPaymentAnimator.m
//  shcem
//
//  Created by huangdeyu on 2016/12/15.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHSetPaymentAnimator.h"

@interface SHSetPaymentAnimator ()
@property(nonatomic,assign) UINavigationControllerOperation type;
@end

@implementation SHSetPaymentAnimator

-(instancetype)initWithTransitionType:(UINavigationControllerOperation)type{
    if (self = [super init]) {
        self.type = type;
    }
    return self;
}
- (NSTimeInterval)transitionDuration:(nullable id <UIViewControllerContextTransitioning>)transitionContext{
    return 0.3;
}
- (void)animateTransition:(id <UIViewControllerContextTransitioning>)transitionContext{
    if (self.type == UINavigationControllerOperationPush) {
        [self presentWithContext:transitionContext];
    }else{
        [self dismissWithContext:transitionContext];
    }
}

-(void)presentWithContext:(id <UIViewControllerContextTransitioning>)transitionContext{
    //UIView * fromView = [transitionContext viewForKey:UITransitionContextFromViewKey];
    UIView * toView = [transitionContext viewForKey:UITransitionContextToViewKey];
    UIView *containerView = [transitionContext containerView];
    [containerView addSubview:toView];
    toView.alpha = 0;
    [UIView animateWithDuration:[self transitionDuration:transitionContext] animations:^{
        toView.alpha = 1;
    }completion:^(BOOL finished) {
        [transitionContext completeTransition:![transitionContext transitionWasCancelled]];
    }];
}
-(void)dismissWithContext:(id <UIViewControllerContextTransitioning>)transitionContext{
    UIView * fromView = [transitionContext viewForKey:UITransitionContextFromViewKey];
    //UIView * toView = [transitionContext viewForKey:UITransitionContextToViewKey];
   // UIView *containerView = [transitionContext containerView];
    [UIView animateWithDuration:[self transitionDuration:transitionContext] animations:^{
        fromView.alpha = 0;
    }completion:^(BOOL finished) {
        if ([transitionContext transitionWasCancelled]) {
            [transitionContext completeTransition:NO];
        }else{
            [transitionContext completeTransition:YES];
        }
    }];
}

@end
