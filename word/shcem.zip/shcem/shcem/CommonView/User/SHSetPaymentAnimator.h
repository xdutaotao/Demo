//
//  SHSetPaymentAnimator.h
//  shcem
//
//  Created by huangdeyu on 2016/12/15.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHSetPaymentAnimator : NSObject<UIViewControllerAnimatedTransitioning>
-(instancetype)initWithTransitionType:(UINavigationControllerOperation)type;
@end
