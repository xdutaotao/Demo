//
//  SHMsgListCell.m
//  shcem
//
//  Created by huangdeyu on 2016/12/14.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHMsgListCell.h"
#import "Masonry.h"

@interface SHMsgListCell ()
@property(nonatomic,strong)UIImageView * bgView;
@property(nonatomic,strong)UIView * lineView;
@property(nonatomic,strong)UILabel * msgLabel;
@property(nonatomic,strong) UILabel * dateLabel;
@end

@implementation SHMsgListCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self addSubview:self.bgView];
        [self addSubview:self.lineView];
        [self addSubview:self.msgLabel];
        [self addSubview:self.dateLabel];
        [self layout];
    }
    return self;
}
-(void)layout{
    [self.bgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self).insets(UIEdgeInsetsMake(2, 2, 2, 2));
    }];
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(@1);
        make.right.equalTo(self.bgView.mas_right).offset(-5);
        make.left.equalTo(self.bgView.mas_left).offset(5);
        make.bottom.equalTo(self.bgView.mas_bottom).offset(-30);
    }];
    [self.msgLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.bgView).offset(20);
        make.right.equalTo(self.bgView).offset(-20);
        make.top.equalTo(self.bgView).offset(10);
        make.bottom.equalTo(self.lineView.mas_top).offset(-10);
    }];
    [self.dateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.lineView).offset(5);
        make.bottom.equalTo(self.bgView).offset(-8);
        make.right.equalTo(self.bgView).offset(-13);
    }];
}

-(void)loadData:(NSString *)title dateStr:(NSString *)dateStr{
    self.msgLabel.text = title;
    self.dateLabel.text = dateStr;
}

#pragma mark - 初始化
-(UIImageView *)bgView{
    if (!_bgView) {
        _bgView = [[UIImageView alloc] init];
        _bgView.backgroundColor = [UIColor whiteColor];
//        _bgView.layer.shadowColor = [UIColor lightGrayColor].CGColor;
//        _bgView.layer.shadowOffset = CGSizeMake(0, 5);
//        _bgView.layer.shadowRadius = 3.0;
//        _bgView.layer.shadowOpacity = 1.0;
        UIImage * img = [UIImage imageNamed:@"msg_bg"];
        img = [img resizableImageWithCapInsets:UIEdgeInsetsMake(10, 10, 10, 10) resizingMode:UIImageResizingModeStretch];
        _bgView.image = img;
    }
    return _bgView;
}
-(UIView *)lineView{
    if (!_lineView) {
        _lineView = [[UIView alloc] init];
        _lineView.backgroundColor = BACKGROUNDCOLOR_CUSTOM;
    }
    return _lineView;
}
-(UILabel *)msgLabel{
    if (!_msgLabel) {
        _msgLabel = [[UILabel alloc] init];
        _msgLabel.numberOfLines = 10;
        [_msgLabel setFont:[UIFont systemFontOfSize:FONT_DEFAULT]];
        _msgLabel.textColor = BLACK_CUSTOM;
        //_msgLabel.text = @"成交：您的SG-3询盘已成交，成交单号为CJ1612010059，详情请登录化交网站查询。";
    }
    return _msgLabel;
}
-(UILabel *)dateLabel{
    if (!_dateLabel) {
        _dateLabel = [[UILabel alloc] init];
        [_dateLabel setFont:[UIFont systemFontOfSize:12]];
        _dateLabel.textColor = BLACK_CUSTOM;
        _dateLabel.text = @"2016-12-01 10:23";
    }
    return _dateLabel;
}

@end
