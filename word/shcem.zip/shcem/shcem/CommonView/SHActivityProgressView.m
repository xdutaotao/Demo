//
//  SHActivityProgressView.m
//  Frey
//
//  Created by huangdeyu on 16/3/3.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import "SHActivityProgressView.h"

@interface SHActivityProgressView()
@property(nonatomic,assign)CGFloat  percent;
@end

@implementation SHActivityProgressView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.mLayer = [[CAGradientLayer alloc] init];
        self.mLayer.colors =  @[(__bridge id)[UIColor whiteColor].CGColor,(__bridge id)COLOR_NAV_RED.CGColor];
        self.mLayer.startPoint = CGPointMake(0, .5);
        self.mLayer.endPoint = CGPointMake(1, .5);
        self.mLayer.frame = CGRectMake(0, 0, self.width, self.height);
        self.mLayer.cornerRadius = 2.0;
        [self.layer addSublayer:self.mLayer];
    }
    return self;
}

-(void)startLoading{
    self.mLayer.frame =  CGRectMake(0, 0, self.width, self.height);
    [self.layer addSublayer:self.mLayer];
    self.alpha = 1;
    [self startTimer];
}

-(void)endLoading{
    [self timerStop];
    self.width = ScreenWidth;
    self.mLayer.frame =  CGRectMake(0, 0, self.width, self.height);
    [UIView animateWithDuration:0.5 animations:^{
        self.alpha = 0;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}

-(void)startTimer{
    self.timer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(timerGo) userInfo:nil repeats:YES];
    self.percent = 0;
}
-(void)timerGo{
    //DLog(@"定时器在走");
    if (self.percent < 0.7) {
        self.percent += 0.01;
        self.width = ScreenWidth * self.percent;
        self.mLayer.frame =  CGRectMake(0, 0, self.width, self.height);
    }
   
}
-(void)timerStop{
    self.percent = 0;
    [self.timer invalidate];
    self.timer = nil;
}

@end
