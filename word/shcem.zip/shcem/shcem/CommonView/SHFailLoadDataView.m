//
//  SHFailLoadDataView.m
//  Frey
//
//  Created by huangdeyu on 16/3/30.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import "SHFailLoadDataView.h"
#import "Masonry.h"

@interface SHFailLoadDataView()
@property(nonatomic,strong)UIImageView * imageView;
@property(nonatomic,strong)UIImage * loadFailedImage;
@property(nonatomic,strong)UIImage * loadNoDataImage;
@property(nonatomic,strong)UILabel * tipsLabel;


@end

@implementation SHFailLoadDataView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.imageView];
        [self addSubview:self.tipsLabel];
        self.backgroundColor = [UIColor whiteColor];

        self.userInteractionEnabled = NO;
        [self layout];
    }
    return self;
}
-(void)showWithType:(NSInteger)type tips:(NSString *)tips{
    if (type == 0) {
        self.imageView.image = self.loadFailedImage;
    }else{
        self.imageView.image = self.loadNoDataImage;
    }
    self.tipsLabel.text = tips;
}
-(void)layout{
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.mas_centerX);
        make.centerY.equalTo(self.mas_centerY).offset(-40);
    }];
    [self.tipsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.mas_centerX);
        make.top.equalTo(self.imageView.mas_bottom).offset(20);
    }];
}
-(void)showInView:(UIView *)view withType:(NSInteger)type tips:(NSString *)tips{
    [self showWithType:type tips:tips];
    [view addSubview:self];
}
-(void)hideView{
    [self removeFromSuperview];
}
#pragma mark - 初始化
-(UIImageView *)imageView{
    if (!_imageView) {
        _imageView = [[UIImageView alloc] init];
    }
    return _imageView;
}
-(UIImage *)loadFailedImage{
    if (!_loadFailedImage) {
        _loadFailedImage = [UIImage imageNamed:@"failToNet"];
    }
    return _loadFailedImage;
}
-(UIImage *)loadNoDataImage{
    if (!_loadNoDataImage) {
        _loadNoDataImage = [UIImage imageNamed:@"failTosearch"];
    }
    return _loadNoDataImage;
}
-(UILabel *)tipsLabel{
    if (!_tipsLabel) {
        _tipsLabel = [[UILabel alloc] init];
        [_tipsLabel setTextColor:[UIColor lightGrayColor]];
        _tipsLabel.textAlignment = NSTextAlignmentCenter;
        _tipsLabel.numberOfLines  = 3;
        [_tipsLabel setFont:[UIFont systemFontOfSize:13]];
    }
    return _tipsLabel;
}

@end
