//
//  SHBalanceDetailTableViewCell.m
//  shcem
//
//  Created by xupeipei on 2016/12/7.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHBalanceDetailTableViewCell.h"
#import <Masonry/Masonry.h>
#import "NSString+Format.h"

@interface SHBalanceDetailTableViewCell()

@property (strong,nonatomic) UILabel *titleLB;
@property (strong,nonatomic) UILabel *timeLB;

@end


@implementation SHBalanceDetailTableViewCell

-(void)setBalanceDetailModel:(SHBalanceDetailModel *)balanceDetailModel{
    _balanceDetailModel = balanceDetailModel;
    
    self.titleLB.text = balanceDetailModel.title;
    NSString *title = [NSString keepTwoDecimalPlaces:balanceDetailModel.money];
    
    self.timeLB.text = [NSString countNumAndChangeformat:title];
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.titleLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.titleLB.text = @"资金账户余额（元）";
        self.titleLB.font = [UIFont systemFontOfSize:16];
        [self.contentView addSubview:self.titleLB];
        [self.titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top);
            make.left.mas_equalTo(self.contentView.mas_left);
            make.right.mas_equalTo(self.contentView.mas_right);
            make.height.mas_equalTo(40);
        }];
        
        UIView *horizontalLine = [[UIView alloc] initWithFrame:CGRectZero];
        [horizontalLine setBackgroundColor:[UIColor lightGrayColor]];
        horizontalLine.alpha = 0.3;
        [self.contentView addSubview:horizontalLine];
        [horizontalLine mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.titleLB.mas_bottom);
            make.left.mas_equalTo(self.contentView);
            make.right.mas_equalTo(self.contentView);
            make.height.mas_equalTo(1);
        }];
        
        self.timeLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.timeLB.textAlignment = NSTextAlignmentCenter;
        self.timeLB.text = @"0.00";
        self.timeLB.font = [UIFont systemFontOfSize:30];
        self.timeLB.textColor = COLOR_NAV_RED;
        [self.contentView addSubview:self.timeLB];
        [self.timeLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(horizontalLine.mas_bottom);
            make.left.mas_equalTo(self.contentView.mas_left);
            make.right.mas_equalTo(self.contentView.mas_right);
            make.bottom.mas_equalTo(self.contentView.mas_bottom);
        }];
    }
    
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}


@end
