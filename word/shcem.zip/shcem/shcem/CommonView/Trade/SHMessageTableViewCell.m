//
//  SHMessageTableViewCell.m
//  shcem
//
//  Created by xupeipei on 2016/12/7.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHMessageTableViewCell.h"
#import <Masonry/Masonry.h>

@interface SHMessageTableViewCell()

@property (strong,nonatomic) UILabel *titleLB;
@property (strong,nonatomic) UILabel *timeLB;

@end


@implementation SHMessageTableViewCell

-(void)setMessageModel:(SHMessageModel *)messageModel{
    _messageModel = messageModel;
    
    self.timeLB.text = messageModel.recModifytime;
    self.titleLB.text = messageModel.messageContent;
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.titleLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.titleLB.text = @"消息内容";
        self.titleLB.numberOfLines = 0;
        self.titleLB.lineBreakMode = NSLineBreakByCharWrapping;
        [self.contentView addSubview:self.titleLB];
        [self.titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top);
            make.left.mas_equalTo(self.contentView.mas_left);
            make.right.mas_equalTo(self.contentView.mas_right);
            make.height.mas_equalTo(80);
        }];
        
        UIView *horizontalLine = [[UIView alloc] initWithFrame:CGRectZero];
        [horizontalLine setBackgroundColor:[UIColor lightGrayColor]];
        [self.contentView addSubview:horizontalLine];
        [horizontalLine mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.titleLB.mas_bottom);
            make.left.mas_equalTo(self.contentView);
            make.right.mas_equalTo(self.contentView);
            make.height.mas_equalTo(1);
        }];
        
        self.timeLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.timeLB.textAlignment = NSTextAlignmentRight;
        self.timeLB.text = @"消息时间";
        [self.contentView addSubview:self.timeLB];
        [self.timeLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(horizontalLine.mas_bottom);
            make.left.mas_equalTo(self.contentView.mas_left);
            make.right.mas_equalTo(self.contentView.mas_right);
            make.height.mas_equalTo(40);
        }];
    }
    
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}


@end
