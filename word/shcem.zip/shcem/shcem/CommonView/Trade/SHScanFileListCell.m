//
//  SHScanFileListCell.m
//  shcem
//
//  Created by xupeipei on 2016/12/28.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHScanFileListCell.h"
#import <Masonry/Masonry.h>
#import "UIButton+WebCache.h"


@interface SHScanFileListCell()


@end

@implementation SHScanFileListCell

-(void)setFileArray:(NSArray *)fileArray{
    _fileArray = fileArray;
    
    for (NSInteger i=0; i<fileArray.count; i++) {
        NSDictionary *tempDic = fileArray[i];
        NSString *fileInfo = tempDic[@"fileInfo"];
        
        UIButton *tempBT = [[UIButton alloc] initWithFrame:CGRectZero];
        [tempBT setTag:100+i];
        tempBT.imageView.contentMode = UIViewContentModeScaleAspectFit;
        [tempBT addTarget:self action:@selector(imageButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:tempBT];
        [tempBT mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top).offset(i/3*120);
            make.left.mas_equalTo(self.contentView.mas_left).offset(ScreenWidth/3*(i%3));
            make.width.mas_equalTo(ScreenWidth/3);
            make.height.mas_equalTo(120);
        }];
        
        if ([fileInfo hasSuffix:@".pdf"]) {
            [tempBT setImage:[UIImage imageNamed:@"Homea"] forState:UIControlStateNormal];
        }else{
            [tempBT sd_setImageWithURL:[NSURL URLWithString:fileArray[i][@"fileUrl"]] forState:UIControlStateNormal];
        }
    }
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)imageButtonAction:(id)sender{
    UIButton *tempBT = (UIButton*)sender;
    
    if ([self.delegate respondsToSelector:@selector(SHScanFileListCellEvent:)]) {
        [self.delegate SHScanFileListCellEvent:tempBT.tag-100];
    }
    
}




- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
