//
//  SHScanCountListTableViewCell.m
//  
//
//  Created by xupeipei on 2016/12/16.
//
//

#import "SHScanCountListTableViewCell.h"

@implementation SHScanCountListTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
