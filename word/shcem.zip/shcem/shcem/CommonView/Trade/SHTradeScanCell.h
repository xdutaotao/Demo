//
//  SHTradeScanCell.h
//  shcem
//
//  Created by xupeipei on 2016/12/28.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHTradeGetListModel.h"
static NSString *SHTradeScanCellReuseIdentifier = @"SHTradeScanCell";

@interface SHTradeScanCell : UITableViewCell

@property(nonatomic,strong) SHTradeGetListModel *tradeGetListModel;

@end
