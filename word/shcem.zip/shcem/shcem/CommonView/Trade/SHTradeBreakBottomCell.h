//
//  SHTradeBreakBottomCell.h
//  shcem
//
//  Created by xupeipei on 2016/12/29.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHTradeBreakBottomModel.h"
#import "SHGetBuyListModel.h"

static NSString *SHTradeBreakBottomCellReuseIdentifier = @"SHTradeBreakBottomCell";

@protocol SHTradeBreakBottomCellDelegate <NSObject>

-(void)SHTradeBreakBottomCellEvent:(NSInteger)index;

@end


@interface SHTradeBreakBottomCell : UITableViewCell

@property (nonatomic,strong) SHGetBuyListModel *getBuyListModel;
@property (nonatomic,strong) NSArray *fileArray;
@property (nonatomic,strong) SHTradeBreakBottomModel *tradeBreakBottomModel;
@property (nonatomic ,weak) id<SHTradeBreakBottomCellDelegate> delegate;

@end
