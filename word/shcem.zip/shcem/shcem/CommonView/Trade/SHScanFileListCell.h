//
//  SHScanFileListCell.h
//  shcem
//
//  Created by xupeipei on 2016/12/28.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
static NSString *SHScanFileListCellReuseIdentifier = @"SHScanFileListCell";

@protocol SHScanFileListCellDelegate <NSObject>

-(void)SHScanFileListCellEvent:(NSInteger)index;

@end

@interface SHScanFileListCell : UITableViewCell

@property (nonatomic,strong) NSArray *fileArray;

@property (nonatomic ,weak) id<SHScanFileListCellDelegate> delegate;

@end
