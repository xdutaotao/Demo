//
//  SHTradeScanCell.m
//  shcem
//
//  Created by xupeipei on 2016/12/28.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHTradeScanCell.h"
#import <Masonry/Masonry.h>

@interface SHTradeScanCell()

@property (nonatomic,strong) UILabel* loopLB;
@property (nonatomic,strong) UILabel* loopLB1;
@property (nonatomic,strong) UILabel* loopLB2;

@end

@implementation SHTradeScanCell

-(void)setTradeGetListModel:(SHTradeGetListModel *)tradeGetListModel{
    _tradeGetListModel = tradeGetListModel;
    
    self.loopLB.text = tradeGetListModel.DeliveryID;
    self.loopLB1.text = tradeGetListModel.Quantity;
    self.loopLB2.text = tradeGetListModel.TakenQuantity;
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        UILabel *loopLB = [[UILabel alloc] initWithFrame:CGRectZero];
        loopLB.text = @"交收单号";
        loopLB.textAlignment = NSTextAlignmentCenter;
        loopLB.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:loopLB];
        [loopLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top).offset(10);
            make.left.mas_equalTo(self.contentView.mas_left).offset(0);
            make.width.mas_equalTo(ScreenWidth/3);
            make.height.mas_equalTo(20);
        }];
        
        self.loopLB = loopLB;
        
        UILabel *loopLB1 = [[UILabel alloc] initWithFrame:CGRectZero];
        loopLB1.text = @"交收数量";
        loopLB1.textAlignment = NSTextAlignmentCenter;
        loopLB1.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:loopLB1];
        [loopLB1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top).offset(10);
            make.left.mas_equalTo(self.contentView.mas_left).offset(ScreenWidth/3*1);
            make.width.mas_equalTo(ScreenWidth/3);
            make.height.mas_equalTo(20);
        }];
        
        self.loopLB1 = loopLB1;
        
        UILabel *loopLB2 = [[UILabel alloc] initWithFrame:CGRectZero];
        loopLB2.text = @"实收数量";
        loopLB2.textAlignment = NSTextAlignmentCenter;
        loopLB2.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:loopLB2];
        [loopLB2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top).offset(10);
            make.left.mas_equalTo(self.contentView.mas_left).offset(ScreenWidth/3*2);
            make.width.mas_equalTo(ScreenWidth/3);
            make.height.mas_equalTo(20);
        }];
        
        self.loopLB2 = loopLB2;
    }
    
    return self;
}



- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
