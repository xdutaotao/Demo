//
//  SHConfirmPayFreightHeaderCell.m
//  shcem
//
//  Created by huangdeyu on 2017/3/29.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "SHConfirmPayFreightHeaderCell.h"

@interface SHConfirmPayFreightHeaderCell()

@property (nonatomic,strong) NSArray *tradePayArray;

@end

@implementation SHConfirmPayFreightHeaderCell

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}


-(void)setGetFeeInfoModel:(GetFeeInfoModel *) getFeeInfoModel{
    _getFeeInfoModel =getFeeInfoModel;
    
    if(!getFeeInfoModel){
        return;
    }
    
    
    for (NSInteger i= 0; i<self.tradePayArray.count; i++) {
        NSDictionary *loopDic = self.tradePayArray[i];
        NSString *loopTitle = loopDic[@"title"];
        NSString *loopSubContent = loopDic[@"subCotent"];
        
        UILabel* QuantityTitleLB = [[UILabel alloc] initWithFrame:CGRectZero];
        QuantityTitleLB.font = [UIFont systemFontOfSize:16];
        QuantityTitleLB.textColor = [UIColor darkGrayColor];
        QuantityTitleLB.text = loopTitle;
        [self.contentView addSubview:QuantityTitleLB];
        [QuantityTitleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top).offset(44*i);
            make.left.mas_equalTo(self.contentView.mas_left).offset(10);
            make.width.mas_equalTo(120);
            make.height.mas_equalTo(44);
        }];
        
        UILabel* QuantityLB = [[UILabel alloc] initWithFrame:CGRectZero];
        QuantityLB.font = [UIFont systemFontOfSize:16];
        [self.contentView addSubview:QuantityLB];
        [QuantityLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(QuantityTitleLB.mas_top);
            make.left.mas_equalTo(QuantityTitleLB.mas_right);
            make.right.mas_equalTo(self.contentView.mas_right).offset(-10);
            make.height.mas_equalTo(QuantityTitleLB);
        }];
        
      
        QuantityLB.text = [NSString stringWithFormat:@"%@%@",[_getFeeInfoModel valueForKey:loopDic[@"paKey"]],loopSubContent];
        
    }
    
}


-(NSArray*)tradePayArray{
    if (!_tradePayArray) {
        _tradePayArray = @[
                           @{@"title":@"运费",@"paKey":@"TotalFreight",@"subCotent":@"元"},
                           @{@"title":@"小单费",@"paKey":@"TotalSmallFee",@"subCotent":@"元"},
                           @{@"title":@"扣款总额",@"paKey":@"TotalFee",@"subCotent":@"元"},
                           ];
    }
    return _tradePayArray;
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}


@end
