//
//  LijianhuiLB.m
//  shcem
//
//  Created by xupeipei on 2017/1/10.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "LijianhuiLB.h"

@implementation LijianhuiLB

- (instancetype)init {
    if (self = [super init]) {
        _textInsets = UIEdgeInsetsZero;
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        _textInsets = UIEdgeInsetsZero;
    }
    return self;
}

- (void)drawTextInRect:(CGRect)rect {
    [super drawTextInRect:UIEdgeInsetsInsetRect(rect, _textInsets)];
}

@end
