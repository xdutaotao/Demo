//
//  SHOrderDetailListCell.h
//  shcem
//
//  Created by xupeipei on 2016/12/28.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomScrollViewCellModel.h"
static NSString *SHOrderDetailListCellReuseIdentifier = @"SHOrderDetailListCell";

@interface SHOrderDetailListCell : UITableViewCell

@property (nonatomic,strong) CustomScrollViewCellModel *tradeDetailListModel;

@end
