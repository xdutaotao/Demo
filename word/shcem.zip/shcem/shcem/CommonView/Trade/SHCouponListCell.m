//
//  SHCouponListCell.m
//  shcem
//
//  Created by xupeipei on 2016/12/27.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHCouponListCell.h"
#import <Masonry/Masonry.h>

@interface SHCouponListCell()

@property (nonatomic,strong) UIImageView *selectIV;
@property (nonatomic,strong) UILabel* QuantityTitleLB;
@property (nonatomic,strong) UILabel* QuantityLB;

@end

@implementation SHCouponListCell

-(void)setCellSelect:(NSInteger)cellSelect{
    _cellSelect = cellSelect;
    
    if (cellSelect) {
        [self.selectIV setImage:[UIImage imageNamed:@"radio_checked"]];
    }else{
        [self.selectIV setImage:[UIImage imageNamed:@"radio_normal"]];
    }
}

-(void)setCouponModel:(SHCouponModel *)couponModel{
    _couponModel = couponModel;
    self.QuantityTitleLB.text = [NSString stringWithFormat:@"￥%@",_couponModel.Amount];
    self.QuantityLB.text = [NSString stringWithFormat:@"%@/%@",[self formatString:_couponModel.CouponValidStartDate],[self formatString:_couponModel.CouponValidEndDate]];
    
}

-(NSString*)formatString:(NSString*)unFormattedString{
    if (unFormattedString.length>=10) {
        return [unFormattedString substringToIndex:10];
    }
    
    return unFormattedString;
}


-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        {
            self.selectionStyle = UITableViewCellSelectionStyleNone;
            
            self.QuantityTitleLB = [[UILabel alloc] initWithFrame:CGRectZero];
            self.QuantityTitleLB.font = [UIFont systemFontOfSize:14];
            self.QuantityTitleLB.textColor = [UIColor darkGrayColor];
            self.QuantityTitleLB.text = @"数量";
            [self.contentView addSubview:self.QuantityTitleLB];
            [self.QuantityTitleLB mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(self.contentView.mas_top);
                make.bottom.mas_equalTo(self.contentView.mas_bottom);
                make.left.mas_equalTo(self.contentView.mas_left).offset(10);
                make.width.mas_equalTo(100);
            }];
            
            self.QuantityLB = [[UILabel alloc] initWithFrame:CGRectZero];
            self.QuantityLB.font = [UIFont systemFontOfSize:14];
            self.QuantityLB.text = @"时间";
            [self.contentView addSubview:self.QuantityLB];
            [self.QuantityLB mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(self.QuantityTitleLB.mas_top);
                make.left.mas_equalTo(self.QuantityTitleLB.mas_right);
                make.right.mas_equalTo(self.contentView.mas_right).offset(-40);
                make.height.mas_equalTo(self.QuantityTitleLB);
            }];
            
            self.selectIV = [[UIImageView alloc] initWithFrame:CGRectZero];
            [self.selectIV setImage:[UIImage imageNamed:@"radio_normal"]];
            [self.contentView addSubview:self.selectIV];
            [self.selectIV mas_makeConstraints:^(MASConstraintMaker *make) {
                make.centerY.mas_equalTo(self.contentView.mas_centerY);
                make.right.mas_equalTo(self.contentView.mas_right).offset(-10);
                make.size.mas_equalTo(CGSizeMake(20, 20));
            }];
        }
        
    }
    
    return self;
}



- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
