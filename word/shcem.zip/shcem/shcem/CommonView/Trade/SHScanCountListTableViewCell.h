//
//  SHScanCountListTableViewCell.h
//  
//
//  Created by xupeipei on 2016/12/16.
//
//

#import <UIKit/UIKit.h>
static NSString *SHScanCountListTableViewCellReuseIdentifier = @"SHScanCountListTableViewCell";

@interface SHScanCountListTableViewCell : UITableViewCell

@end
