//
//  SHTradePaySuccessCell.m
//  shcem
//
//  Created by xupeipei on 2017/1/4.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "SHTradePaySuccessCell.h"
#import <Masonry/Masonry.h>
#import "SHGetBuyListModel.h"
#import "NSString+Format.h"

@interface SHTradePaySuccessCell()

@property (nonatomic,strong) NSArray *tradePayArray;
@property (nonatomic,strong) SHGetBuyListModel *getBuyListModel;
@property (nonatomic,strong) SHPayModel *payModel;

@end

@implementation SHTradePaySuccessCell

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier getBuyListModel:(SHGetBuyListModel*)getBuyListModel payModel:(SHPayModel *)payModel{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.getBuyListModel = getBuyListModel;
        self.payModel = payModel;
        
        UILabel* goodsTypeLB = [[UILabel alloc] initWithFrame:CGRectZero];
        goodsTypeLB.text = [self.getBuyListModel.GoodsType isEqual:@"0"]? @"现货":@"预售";;
        goodsTypeLB.textAlignment = NSTextAlignmentCenter;
        goodsTypeLB.layer.masksToBounds = YES;
        goodsTypeLB.layer.cornerRadius = 5;
        goodsTypeLB.backgroundColor = [UIColor redColor];
        goodsTypeLB.textColor = [UIColor whiteColor];
        goodsTypeLB.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:goodsTypeLB];
        [goodsTypeLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.top).offset(10);
            make.left.mas_equalTo(self.contentView.mas_left).offset(10);
            make.width.mas_equalTo(40);
            make.height.mas_equalTo(20);
        }];
        
        UILabel* productNameLB = [[UILabel alloc] initWithFrame:CGRectZero];
        productNameLB.font = [UIFont systemFontOfSize:16];
        productNameLB.text = [NSString stringWithFormat:@"%@%@%@",_getBuyListModel.CategoryShow,_getBuyListModel.BrandShow,_getBuyListModel.SourcePlaceShow];
        [self.contentView addSubview:productNameLB];
        [productNameLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(goodsTypeLB.mas_top);
            make.left.mas_equalTo(goodsTypeLB.mas_right).offset(10);
            make.right.mas_equalTo(self.contentView.mas_right).offset(-10);
            make.height.mas_equalTo(20);
        }];
        
        for (NSInteger i= 0; i<self.tradePayArray.count; i++) {
            NSDictionary *loopDic = self.tradePayArray[i];
            NSString *loopTitle = loopDic[@"title"];
            NSString *loopSubContent = loopDic[@"subCotent"];
            
            UILabel* QuantityTitleLB = [[UILabel alloc] initWithFrame:CGRectZero];
            QuantityTitleLB.font = [UIFont systemFontOfSize:16];
            QuantityTitleLB.textColor = [UIColor darkGrayColor];
            QuantityTitleLB.text = loopTitle;
            [self.contentView addSubview:QuantityTitleLB];
            [QuantityTitleLB mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(goodsTypeLB.mas_bottom).offset(40*i);
                make.left.mas_equalTo(goodsTypeLB.mas_left);
                make.width.mas_equalTo(120);
                make.height.mas_equalTo(40);
            }];
            
            UILabel* QuantityLB = [[UILabel alloc] initWithFrame:CGRectZero];
            QuantityLB.font = [UIFont systemFontOfSize:16];
            [self.contentView addSubview:QuantityLB];
            [QuantityLB mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(QuantityTitleLB.mas_top);
                make.left.mas_equalTo(QuantityTitleLB.mas_right);
                make.right.mas_equalTo(self.contentView.mas_right);
                make.height.mas_equalTo(QuantityTitleLB);
            }];
            
            if (i == 5) {
                QuantityLB.text = [NSString stringWithFormat:@"%@%@",[_payModel valueForKey:loopDic[@"paKey"]],loopSubContent];
            }else if(i == 6){
               double TakenMoney =   _payModel.TakenMoney.doubleValue;
                double CouponFee =   _payModel.CouponFee.doubleValue;
                double BuyFee =   _getBuyListModel.BuyFee.doubleValue;
                double desDouble =   TakenMoney + BuyFee - CouponFee;
                NSString *desString =  [NSString keepTwoDecimalPlaces:[NSString stringWithFormat:@"%lf",desDouble]];
                QuantityLB.text = [NSString stringWithFormat:@"%@元",desString];
                QuantityLB.textColor = [UIColor redColor];
            }else if(i==7){
                NSString *money = [NSString keepTwoDecimalPlaces:[_payModel valueForKey:loopDic[@"paKey"]]];
                QuantityLB.text = [NSString stringWithFormat:@"%@元",money];
                QuantityLB.textColor = [UIColor redColor];
            }else{
                QuantityLB.text = [NSString stringWithFormat:@"%@%@",[_getBuyListModel valueForKey:loopDic[@"paKey"]],loopSubContent];
            }
        }
        
    }
    
    return self;
}


-(NSArray*)tradePayArray{
    if (!_tradePayArray) {
        _tradePayArray = @[
                           @{@"title":@"成交数量",@"paKey":@"Weight",@"subCotent":@"吨"},
                           @{@"title":@"成交单价",@"paKey":@"Price",@"subCotent":@"元/吨"},
                           @{@"title":@"总货款",@"paKey":@"Amount",@"subCotent":@"元"},
                           @{@"title":@"手续费",@"paKey":@"BuyFee",@"subCotent":@"元"},
                           @{@"title":@"手续费标准",@"paKey":@"FormatFeeRate",@"subCotent":@""},
                           @{@"title":@"优惠券抵用",@"paKey":@"CouponFee",@"subCotent":@"元"},
                           @{@"title":@"扣款总额",@"paKey":@"totalMoney",@"subCotent":@"元"},
                           @{@"title":@"账户余额",@"paKey":@"FirmBalance",@"subCotent":@"元"},
                           ];
    }
    return _tradePayArray;
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
