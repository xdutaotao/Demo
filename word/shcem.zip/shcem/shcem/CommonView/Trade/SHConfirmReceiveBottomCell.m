//
//  SHConfirmReceiveBottomCell.m
//  shcem
//
//  Created by xupeipei on 2016/12/19.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHConfirmReceiveBottomCell.h"
#import <Masonry/Masonry.h>
#import "LijianhuiLB.h"

@interface SHConfirmReceiveBottomCell()

@end


@implementation SHConfirmReceiveBottomCell

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        LijianhuiLB* CouponBalanceLB = [[LijianhuiLB alloc] initWithFrame:CGRectZero];
        CouponBalanceLB.font = [UIFont systemFontOfSize:13];
        CouponBalanceLB.textColor = COLOR_NAV_RED;
        CouponBalanceLB.numberOfLines = 0;
        CouponBalanceLB.layer.masksToBounds = YES;
        CouponBalanceLB.layer.cornerRadius = 5;
        CouponBalanceLB.lineBreakMode = NSLineBreakByCharWrapping;
        CouponBalanceLB.backgroundColor = LIGHTRED_CUSTOM;
        CouponBalanceLB.textInsets      = UIEdgeInsetsMake(10.f, 12.f, 10.f, 10.f);
        CouponBalanceLB.text = [NSString stringWithFormat:@"请至上海化交官网下载《货物签收单》，完整、准确填写并加盖公章、合同章等实物印章，拍照上传等待审核通过即可。"];
        [self.contentView addSubview:CouponBalanceLB];
        [CouponBalanceLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top).offset(10);
            make.left.mas_equalTo(self.contentView.mas_left).offset(10);
            make.right.mas_equalTo(self.contentView.mas_right).offset(-10);
            make.height.mas_equalTo(80);
        }];
        
    }
    
    return self;
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
