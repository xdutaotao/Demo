//
//  SHCancelAllLeadsConfirmDialogVC.h
//  shcem
//
//  Created by zhangsx on 2017/5/8.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CancelLeadsDelegate<NSObject>

-(void)cancelOwnLeads;
-(void)cancelAllLeads;
-(void)toastLocal:(NSString *)message;
-(void)hideProgressLocal;
-(void)viewWillAppearLocal;

@end

@interface SHCancelAllLeadsConfirmDialogVC : UIView

@property(nonatomic,weak)id<CancelLeadsDelegate>delegate;
@property(nonatomic,assign) BOOL isOnlyCancelOwnLeads;

@end
