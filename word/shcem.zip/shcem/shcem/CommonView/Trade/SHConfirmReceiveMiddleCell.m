//
//  SHConfirmReceiveMiddleCell.m
//  shcem
//
//  Created by xupeipei on 2016/12/19.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHConfirmReceiveMiddleCell.h"
#import <Masonry/Masonry.h>

@interface SHConfirmReceiveMiddleCell()<UITextFieldDelegate>

@property (nonatomic, strong) UILabel *orderIDLB;
@property (nonatomic, strong) UILabel *QuantityLB;
@property (nonatomic, strong) UITextField *countTF;

@end

@implementation SHConfirmReceiveMiddleCell

-(void)setTradeGetListModel:(SHTradeGetListModel *)tradeGetListModel{
    _tradeGetListModel = tradeGetListModel;
    
    self.orderIDLB.text = tradeGetListModel.DeliveryID;
    self.QuantityLB.text = tradeGetListModel.Quantity;
    self.countTF.text = tradeGetListModel.customQuantity;
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        self.orderIDLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.orderIDLB.font = [UIFont systemFontOfSize:14];
        self.orderIDLB.numberOfLines = 0;
        self.orderIDLB.lineBreakMode = NSLineBreakByCharWrapping;
        self.orderIDLB.textAlignment = NSTextAlignmentCenter;
        self.orderIDLB.textColor = LIGHTGRAY_CUSTOM;
        [self.contentView addSubview:self.orderIDLB];
        [self.orderIDLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top);
            make.left.mas_equalTo(self.contentView.mas_left);
            make.width.mas_equalTo(self.contentView.mas_width).dividedBy(3);
            make.height.mas_equalTo(44);
        }];
        
        self.QuantityLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.QuantityLB.font = [UIFont systemFontOfSize:14];
        self.QuantityLB.textColor = LIGHTGRAY_CUSTOM;
        self.QuantityLB.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:self.QuantityLB];
        [self.QuantityLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top);
            make.left.mas_equalTo(self.orderIDLB.mas_right);
            make.width.mas_equalTo(self.contentView.mas_width).dividedBy(3);
            make.height.mas_equalTo(44);
        }];
        
        self.countTF = [[UITextField alloc] initWithFrame:CGRectZero];
        self.countTF.borderStyle = UITextBorderStyleRoundedRect;
        self.countTF.keyboardType = UIKeyboardTypeDecimalPad;
        self.countTF.font = [UIFont systemFontOfSize:14];
        self.countTF.delegate = self;
        self.countTF.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:self.countTF];
        [self.countTF mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(self.contentView.mas_centerY);
            make.left.mas_equalTo(self.QuantityLB.mas_right);
            make.width.mas_equalTo(self.contentView.mas_width).dividedBy(3).offset(-10);
            make.height.mas_equalTo(30);
        }];
        
    }
    
    return self;
}

#pragma mark UITextFieldDelegate

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    NSString * customQuantity = [textField.text stringByReplacingCharactersInRange:range withString:string];
    BOOL judgeNumber = [self judgeNumber:customQuantity];
    if (!judgeNumber) {
        return false;
    }else{
        self.tradeGetListModel.customQuantity = customQuantity;
        return YES;
    }
}

- (BOOL)judgeNumber:(NSString*)number
{
    NSRange range = [number rangeOfString:@"."];
    
    if (range.length) {
        //    小数
        if (number.length-range.location<=7 && range.location<10) {
            return YES;
        }else{
            return NO;
        }
    }else{
        //        整数
        if (number.length >9) {
            return NO;
        }else{
            return YES;
        }
    }
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
