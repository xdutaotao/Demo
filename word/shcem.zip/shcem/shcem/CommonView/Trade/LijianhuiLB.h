//
//  LijianhuiLB.h
//  shcem
//
//  Created by xupeipei on 2017/1/10.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LijianhuiLB : UILabel

@property (nonatomic, assign) UIEdgeInsets textInsets;

@end
