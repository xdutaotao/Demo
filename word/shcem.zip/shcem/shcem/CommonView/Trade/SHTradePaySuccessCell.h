//
//  SHTradePaySuccessCell.h
//  shcem
//
//  Created by xupeipei on 2017/1/4.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHGetBuyListModel.h"
#import "SHPayModel.h"

static NSString *SHTradePaySuccessCellReuseIdentifier = @"SHTradePaySuccessCell";

@interface SHTradePaySuccessCell : UITableViewCell

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier getBuyListModel:(SHGetBuyListModel*)getBuyListModel payModel:(SHPayModel*)payModel;

@end
