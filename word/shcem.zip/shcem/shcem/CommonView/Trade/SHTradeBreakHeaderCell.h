//
//  SHTradeBreakHeaderCell.h
//  shcem
//
//  Created by xupeipei on 2016/12/29.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHGetBuyListModel.h"
static NSString *SHTradeBreakHeaderCellReuseIdentifier = @"SHTradeBreakHeaderCell";

@interface SHTradeBreakHeaderCell : UITableViewCell

@property (nonatomic,strong) SHGetBuyListModel *getBuyListModel;

@end
