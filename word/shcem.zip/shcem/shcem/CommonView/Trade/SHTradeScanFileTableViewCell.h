//
//  SHTradeScanFileTableViewCell.h
//  shcem
//
//  Created by xupeipei on 2016/12/16.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
static NSString *SHTradeScanFileTableViewCellReuseIdentifier = @"SHTradeScanFileTableViewCell";

@interface SHTradeScanFileTableViewCell : UITableViewCell

@end
