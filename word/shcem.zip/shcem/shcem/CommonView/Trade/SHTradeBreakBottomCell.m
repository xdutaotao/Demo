//
//  SHTradeBreakBottomCell.m
//  shcem
//
//  Created by xupeipei on 2016/12/29.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHTradeBreakBottomCell.h"
#import <Masonry/Masonry.h>
#import "NSString+Format.h"

@interface SHTradeBreakBottomCell()<UITextViewDelegate>

@property (nonatomic,strong) UILabel* countValueLB;
@property (nonatomic,strong) UILabel* moneyLB;
@property (nonatomic,strong) UITextField *countTF;
@property (nonatomic,strong) UITextView *reasonTextView;
@property (nonatomic,strong) UILabel *tipsLB;

@end

@implementation SHTradeBreakBottomCell

-(void)dealloc{
    
    [self.tradeBreakBottomModel removeObserver:self forKeyPath:@"quantity"];
}

-(void)setTradeBreakBottomModel:(SHTradeBreakBottomModel *)tradeBreakBottomModel{
    _tradeBreakBottomModel = tradeBreakBottomModel;
    
    [self.tradeBreakBottomModel addObserver:self forKeyPath:@"quantity" options:NSKeyValueObservingOptionNew context:nil];
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(nullable void *)context
{
    if ([keyPath isEqualToString:@"quantity"] ) {
        double total = ([_tradeBreakBottomModel.quantity integerValue])*[self.getBuyListModel.TradeUnitNumber floatValue];
        double money = total*[self.getBuyListModel.BreakProFee floatValue]*[self.getBuyListModel.Price floatValue];
        
        NSString *moneyString = [NSString keepTwoDecimalPlaces:[NSString stringWithFormat:@"%lf",money]];
        self.countTF.text = _tradeBreakBottomModel.quantity;
        self.countValueLB.text = [NSString stringWithFormat:@"批%g吨",total];
        self.moneyLB.text = [NSString stringWithFormat:@"%@元",moneyString];
    }
    
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        UILabel* countLB = [[UILabel alloc] initWithFrame:CGRectZero];
        countLB.font = [UIFont systemFontOfSize:14];
        countLB.textColor = LIGHTGRAY_CUSTOM;
        countLB.text = @"申请违约数量:";
        [self.contentView addSubview:countLB];
        [countLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top).offset(10);
            make.left.mas_equalTo(self.contentView.mas_left).offset(10);
            make.width.mas_equalTo(120);
            make.height.mas_equalTo(40);
        }];
        
        
        self.countValueLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.countValueLB.font = [UIFont systemFontOfSize:14];
        self.countValueLB.textColor = BLACK_CUSTOM;
        self.countValueLB.text = @"批/吨";
        [self.contentView addSubview:self.countValueLB];
        [self.countValueLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(countLB.mas_top);
            make.right.mas_equalTo(self.contentView.mas_right).offset(-10);
            make.width.mas_equalTo(100);
            make.height.mas_equalTo(40);
        }];
        
        self.countTF = [[UITextField alloc] initWithFrame:CGRectZero];
        self.countTF.borderStyle = UITextBorderStyleRoundedRect;
        self.countTF.textColor = BLACK_CUSTOM;
        self.countTF.layer.borderColor = RGBCOLOR(226, 226, 226).CGColor;
        [self.contentView addSubview:self.countTF];
        self.countTF.userInteractionEnabled = NO;
        [self.countTF mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.countValueLB.mas_top).offset(5);
            make.right.mas_equalTo(self.countValueLB.mas_left).offset(-10);
            make.width.mas_equalTo(40);
            make.height.mas_equalTo(30);
        }];
        
        UILabel* reasonLB = [[UILabel alloc] initWithFrame:CGRectZero];
        reasonLB.font = [UIFont systemFontOfSize:14];
        reasonLB.textColor = LIGHTGRAY_CUSTOM;
        reasonLB.text = @"违约理由:";
        [self.contentView addSubview:reasonLB];
        [reasonLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(countLB.mas_bottom);
            make.left.mas_equalTo(countLB.mas_left);
            make.width.mas_equalTo(80);
            make.height.mas_equalTo(40);
        }];
        
        self.reasonTextView = [[UITextView alloc] initWithFrame:CGRectZero];
        self.reasonTextView.layer.borderWidth = 1;
        self.reasonTextView.textColor = BLACK_CUSTOM;
        self.reasonTextView.layer.masksToBounds = YES;
        self.reasonTextView.layer.cornerRadius = 5;
        self.reasonTextView.delegate = self;
        self.reasonTextView.layer.borderColor = RGBCOLOR(226, 226, 226).CGColor;
        [self.contentView addSubview:self.reasonTextView];
        [self.reasonTextView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(reasonLB.mas_top);
            make.left.mas_equalTo(self.countTF.mas_left);
            make.right.mas_equalTo(self.contentView.mas_right).offset(-10);
            make.height.mas_equalTo(80);
        }];
        
        
        UILabel* moneyTitle = [[UILabel alloc] initWithFrame:CGRectZero];
        moneyTitle.font = [UIFont systemFontOfSize:14];
        moneyTitle.textColor = LIGHTGRAY_CUSTOM;
        moneyTitle.text = @"预计违约金额:";
        [self.contentView addSubview:moneyTitle];
        [moneyTitle mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.reasonTextView.mas_bottom);
            make.left.mas_equalTo(reasonLB.mas_left);
            make.width.mas_equalTo(200);
            make.height.mas_equalTo(40);
        }];
        
        self.moneyLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.moneyLB.font = [UIFont systemFontOfSize:14];
        self.moneyLB.textColor = COLOR_NAV_RED;
        self.moneyLB.text = @"0.00元";
        [self.contentView addSubview:self.moneyLB];
        [self.moneyLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(moneyTitle.mas_top);
            make.left.mas_equalTo(moneyTitle.mas_right);
            make.right.mas_equalTo(self.contentView.mas_right).offset(-10);
            make.height.mas_equalTo(40);
        }];
        
        self.tipsLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.tipsLB.font = [UIFont systemFontOfSize:14];
        self.tipsLB.textAlignment = NSTextAlignmentCenter;
        self.tipsLB.backgroundColor = RGBCOLOR(252, 235, 235);
        self.tipsLB.textColor = COLOR_NAV_RED;
        self.tipsLB.layer.masksToBounds = YES;
        self.tipsLB.layer.cornerRadius = 5;
        self.tipsLB.text = @"该金额仅供参考，扣除金额以实际为准";
        [self.contentView addSubview:self.tipsLB];
        [self.tipsLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(moneyTitle.mas_bottom);
            make.left.mas_equalTo(self.contentView.mas_left).offset(10);
            make.right.mas_equalTo(self.contentView.mas_right).offset(-10);
            make.height.mas_equalTo(40);
        }];

    }
    
    return self;
}

#pragma mark UITextViewDelegate

-(void)textViewDidEndEditing:(UITextView *)textView{
    self.tradeBreakBottomModel.reason = textView.text;
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
