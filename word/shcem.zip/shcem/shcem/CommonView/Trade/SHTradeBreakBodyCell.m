//
//  SHTradeBreakBodyCell.m
//  shcem
//
//  Created by xupeipei on 2016/12/29.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHTradeBreakBodyCell.h"
#import <Masonry/Masonry.h>
#import "CheckButton.h"

@interface SHTradeBreakBodyCell()<UITextFieldDelegate>

@property (nonatomic,strong) UILabel* LB1;
@property (nonatomic,strong) UILabel* LB2;
@property (nonatomic,strong) UILabel* LB3;

@property (nonatomic,strong) UILabel* LB5;
@property (nonatomic,strong) UITextField* noTF;
@property (nonatomic,strong) CheckButton* breakBT;

@property (nonatomic,strong) NSString* NoDeliveryQuantity;
@property (nonatomic,strong) NSString* breakNoDeliveryQuantity;

@end


@implementation SHTradeBreakBodyCell


-(void)setQueryArray:(NSArray *)queryArray{
    _queryArray = queryArray;
    
    self.NoDeliveryQuantity = self.getBuyListModel.NoDeliveryQuantity;
    
    for (NSInteger i=0; i<queryArray.count; i++) {
        SHQueryModel *temoModel = queryArray[i];
        
        float weight = temoModel.Quantity.integerValue * self.getBuyListModel.TradeUnitNumber.floatValue;
        
        UILabel* LB5 = [[UILabel alloc] initWithFrame:CGRectZero];
        LB5.font = [UIFont systemFontOfSize:14];
        LB5.textColor = BLACK_CUSTOM;
        LB5.textAlignment = NSTextAlignmentCenter;
        LB5.text = [NSString stringWithFormat:@"%@批/%g吨",temoModel.Quantity,weight];
        [self.contentView addSubview:LB5];
        [LB5 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.LB3.mas_bottom).offset(i*44);
            make.left.mas_equalTo(self.LB3.mas_left);
            make.size.mas_equalTo(self.LB3);
        }];
        
        UILabel* LB4 = [[UILabel alloc] initWithFrame:CGRectZero];
        LB4.font = [UIFont systemFontOfSize:14];
        LB4.textColor = BLACK_CUSTOM;
        LB4.textAlignment = NSTextAlignmentCenter;
        LB4.lineBreakMode = NSLineBreakByCharWrapping;
        LB4.numberOfLines = 0;
        LB4.text = temoModel.DeliveryID;
        [self.contentView addSubview:LB4];
        [LB4 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(LB5.mas_top);
            make.left.mas_equalTo(self.LB2.mas_left).offset(5);
            make.right.mas_equalTo(self.LB2.mas_right).offset(-5);
            make.height.mas_equalTo(self.LB3.mas_height);
        }];
        
        CheckButton *breakBT = [[CheckButton alloc] initWithFrame:CGRectZero];
        [breakBT setImage:[UIImage imageNamed:@"check"] forState:UIControlStateNormal];
        [breakBT addTarget:self action:@selector(breakBTAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:breakBT];
        [breakBT setTag:100+i];
        [breakBT mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(self.LB1.mas_centerX);
            make.centerY.mas_equalTo(LB4.mas_centerY);
            make.size.mas_equalTo(CGSizeMake(20, 20));
        }];
    }
    
    if (self.getBuyListModel.NoDeliveryQuantity.integerValue > 0) {
        NSInteger offsetHeight = (queryArray.count+1)*44;
        
        float weight =  self.getBuyListModel.NoDeliveryQuantity.integerValue * self.getBuyListModel.TradeUnitNumber.floatValue;
        
        self.LB5 = [[UILabel alloc] initWithFrame:CGRectZero];
        self.LB5.font = [UIFont systemFontOfSize:14];
        self.LB5.textColor = BLACK_CUSTOM;
        self.LB5.textAlignment = NSTextAlignmentCenter;
        self.LB5.text = [NSString stringWithFormat:@"批/%g吨",weight];
        [self.contentView addSubview:self.LB5];
        [self.LB5 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.LB3.mas_top).offset(offsetHeight);
            make.right.mas_equalTo(self.LB3.mas_right);
            make.width.mas_equalTo(self.LB3.mas_width).offset(-30);
            make.height.mas_equalTo(self.LB3.mas_height);
        }];
        
        
        self.noTF = [[UITextField alloc] initWithFrame:CGRectZero];
        self.noTF.delegate = self;
        self.noTF.textAlignment = NSTextAlignmentCenter;
        self.noTF.text = self.getBuyListModel.NoDeliveryQuantity;
        self.noTF.keyboardType = UIKeyboardTypeNumberPad;
        self.noTF.layer.borderWidth = 1;
        self.noTF.layer.borderColor = [UIColor lightGrayColor].CGColor;
        [self.contentView addSubview:self.noTF];
        [self.noTF mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(self.LB5.mas_centerY);
            make.right.mas_equalTo(self.LB5.mas_left);
            make.width.mas_equalTo(30);
            make.height.mas_equalTo(30);
        }];
        
        self.noTF.userInteractionEnabled = _queryArray.count>0? YES:NO;
        
        UILabel* LB4 = [[UILabel alloc] initWithFrame:CGRectZero];
        LB4.font = [UIFont systemFontOfSize:14];
        LB4.textColor = BLACK_CUSTOM;
        LB4.textAlignment = NSTextAlignmentCenter;
        LB4.text = @"未申请交收";
        [self.contentView addSubview:LB4];
        [LB4 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.LB5.mas_top);
            make.left.mas_equalTo(self.LB2.mas_left);
            make.size.mas_equalTo(self.LB3);
        }];
        
        self.breakBT = [[CheckButton alloc] initWithFrame:CGRectZero];
        [self.breakBT setTag:9999];
        [self.breakBT setImage:[UIImage imageNamed:@"check"] forState:UIControlStateNormal];
        [self.breakBT addTarget:self action:@selector(breakBTAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:self.breakBT];
        [self.breakBT mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(self.LB1.mas_centerX);
            make.centerY.mas_equalTo(LB4.mas_centerY);
            make.size.mas_equalTo(CGSizeMake(20, 20));
        }];
    }
    
    [self addLine];
}

-(void)addLine{
    NSInteger horiNumber = self.getBuyListModel.NoDeliveryQuantity.integerValue > 0? self.queryArray.count+3:self.queryArray.count+2;
    if (horiNumber<3) {
        horiNumber = 3;
    }
    
    for (NSInteger i=0; i<horiNumber; i++) {
        float horizontaOffset = 44*i;
        
        UIView *horizontalLine = [[UIView alloc] initWithFrame:CGRectZero];
        [horizontalLine setBackgroundColor:[UIColor lightGrayColor]];
        [self.contentView addSubview:horizontalLine];
        [horizontalLine mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top).offset(horizontaOffset);
            make.left.mas_equalTo(self.contentView.mas_left).offset(10);
            make.right.mas_equalTo(self.contentView.mas_right).offset(-10);
            make.height.mas_equalTo(1);
        }];
    }
    
    for (NSInteger i=0; i<4; i++) {
        float  verticalOffset= (ScreenWidth-20)/3*i+10.5;
        
        UIView *verticalLine = [[UIView alloc] initWithFrame:CGRectZero];
        [verticalLine setBackgroundColor:[UIColor lightGrayColor]];
        [self.contentView addSubview:verticalLine];
        [verticalLine mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.contentView.mas_left).offset(verticalOffset);
            make.top.mas_equalTo(self.contentView.mas_top);
            make.bottom.mas_equalTo(self.contentView.mas_bottom);
            make.width.mas_equalTo(1);
        }];
    }

}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.LB1 = [[UILabel alloc] initWithFrame:CGRectZero];
        self.LB1.font = [UIFont systemFontOfSize:14];
        self.LB1.textColor = BLACK_CUSTOM;
        self.LB1.textAlignment = NSTextAlignmentCenter;
        self.LB1.text = @"申请违约";
        [self.contentView addSubview:self.LB1];
        [self.LB1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top);
            make.left.mas_equalTo(self.contentView.mas_left);
            make.width.mas_equalTo(self.contentView).dividedBy(3);
            make.height.mas_equalTo(44);
        }];
        
        self.LB2 = [[UILabel alloc] initWithFrame:CGRectZero];
        self.LB2.font = [UIFont systemFontOfSize:14];
        self.LB2.textColor = BLACK_CUSTOM;
        self.LB2.textAlignment = NSTextAlignmentCenter;
        self.LB2.text = @"交收号";
        
        [self.contentView addSubview:self.LB2];
        [self.LB2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.LB1.mas_top);
            make.left.mas_equalTo(self.LB1.mas_right);
            make.width.mas_equalTo(self.contentView).dividedBy(3);
            make.height.mas_equalTo(44);
        }];
        
        self.LB3 = [[UILabel alloc] initWithFrame:CGRectZero];
        self.LB3.font = [UIFont systemFontOfSize:14];
        self.LB3.textColor = BLACK_CUSTOM;
        self.LB3.textAlignment = NSTextAlignmentCenter;
        self.LB3.text = @"数量";
        [self.contentView addSubview:self.LB3];
        [self.LB3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.LB1.mas_top);
            make.left.mas_equalTo(self.LB2.mas_right);
            make.width.mas_equalTo(self.contentView).dividedBy(3);
            make.height.mas_equalTo(44);
        }];

    }
    return self;
}

-(void)breakBTAction:(id)sender{
    CheckButton *tempBT = (CheckButton*)sender;
    NSInteger index = tempBT.tag;
    
    if (tempBT.check == true) {
        tempBT.check = false;
        [tempBT setImage:[UIImage imageNamed:@"check"] forState:UIControlStateNormal];
    }else{
        tempBT.check = true;
        [tempBT setImage:[UIImage imageNamed:@"checked"] forState:UIControlStateNormal];
    }
    
    if (index == 9999) {
        if (tempBT.check) {
            self.breakNoDeliveryQuantity = self.noTF.text;
        }else{
            self.breakNoDeliveryQuantity = @"0";
        }
    }else{
        NSInteger realIndex = index-100;
        SHQueryModel *query = self.queryArray[realIndex];
        
        if (tempBT.check == true) {
            query.breakQuantity = query.Quantity;
        }else{
            query.breakQuantity = @"0";
        }
    }
    
    [self countTotal];
}


-(void)countTotal{
    
    NSInteger total = 0;
    for (NSInteger i=0; i<self.queryArray.count; i++) {
        SHQueryModel *query = self.queryArray[i];
        total+= query.breakQuantity.integerValue;
    }
    
    if (!self.breakNoDeliveryQuantity) {
        self.breakNoDeliveryQuantity = @"0";
    }
    
    if (self.breakBT.check) {
        total += self.noTF.text.integerValue;
    }
    
    self.tradeBreakBottomModel.quantity = [NSString stringWithFormat:@"%ld",(long)total];
    self.tradeBreakBottomModel.breakNoDeliveryQuantity = self.breakNoDeliveryQuantity;
   
}

-(BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    if (textField.text.integerValue > self.getBuyListModel.NoDeliveryQuantity.integerValue ) {
        textField.text = @"0";
    }
    
    float kk = textField.text.integerValue * self.getBuyListModel.TradeUnitNumber.floatValue;
    self.LB5.text = [NSString stringWithFormat:@"批/%g吨",kk];
    self.breakNoDeliveryQuantity = textField.text;
    [self countTotal];
    return YES;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

