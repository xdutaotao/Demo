//
//  SHCancelAllLeadsConfirmDialogVC.m
//  shcem
//
//  Created by zhangsx on 2017/5/8.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import "SHCancelAllLeadsConfirmDialogVC.h"

@interface SHCancelAllLeadsConfirmDialogVC ()

@property (nonatomic,strong)  UIButton *cancelOwnLeadsBT;
@property (nonatomic,strong)  UIButton *cancelAllLeadsBT;
@property (nonatomic,assign)  BOOL isCancelAllLeads;

@end

@implementation SHCancelAllLeadsConfirmDialogVC

-(id)initWithFrame:(CGRect)frame{
    
    if (self =  [super initWithFrame:frame]) {
        
        [self setBackgroudColor];
        UIView *centralView=[self setCentralView];
        [self setTitle:centralView];
        if(_isOnlyCancelOwnLeads)
            [self setConfirmDescription:centralView content:@"您是否确定取消所有的报盘?"];
        else
             [self setSelectCancelAllLeadsOrCancelOwnLeadsList:centralView];
        [self setCancelButton:centralView];
        [self setConfirmButton:centralView];
    }
    return self;
}


-(void)setBackgroudColor{
    self.backgroundColor = RGBACOLOR(0, 0, 0, 0.3);
}

-(UIView *)setCentralView{

    UIView *centralView = [[UIView alloc] initWithFrame:CGRectZero];
    centralView.backgroundColor = [UIColor whiteColor];
    centralView.layer.masksToBounds = YES;
    centralView.layer.cornerRadius = 5;
    [self addSubview:centralView];
    [centralView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(self);
        make.height.mas_equalTo(200);
        make.left.mas_equalTo(self.mas_left).offset(30);
        make.right.mas_equalTo(self.mas_right).offset(-30);
    }];
    
    
    return centralView;
    
}

-(void)setTitle:(UIView *) centralView{
    
    UILabel *titleLB = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLB.text = @"撤销报盘";
    titleLB.font = [UIFont boldSystemFontOfSize:16];
    titleLB.textColor=[UIColor whiteColor];
    titleLB.textAlignment = NSTextAlignmentCenter;
    titleLB.backgroundColor=RedColor_Custom;
    [centralView addSubview:titleLB];
    [titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(centralView.top);
        make.left.mas_equalTo(centralView.mas_left);
        make.right.mas_equalTo(centralView.mas_right);
        make.height.mas_equalTo(40);
    }];

}

-(void)setSelectCancelAllLeadsOrCancelOwnLeadsList:(UIView *) centralView{
    
        _cancelOwnLeadsBT = [[UIButton alloc] initWithFrame:CGRectZero];
        _cancelOwnLeadsBT.titleLabel.textColor = [UIColor whiteColor];
        _cancelOwnLeadsBT.imageEdgeInsets = UIEdgeInsetsMake(12, 12, 12, 12);
        [_cancelOwnLeadsBT setImage:[UIImage imageNamed:@"radio_checked"] forState:UIControlStateNormal];
        [_cancelOwnLeadsBT addTarget:self action:@selector(changeCancelOwnLeadsButtonImageAction:) forControlEvents:UIControlEventTouchUpInside];
        [centralView addSubview:_cancelOwnLeadsBT];
        [_cancelOwnLeadsBT mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(centralView.mas_top).offset(50);
            make.left.mas_equalTo(centralView.mas_left).offset(10);
            make.width.mas_equalTo(44);
            make.height.mas_equalTo(44);
        }];
    
        UILabel *cancelOwnLeadsLB = [[UILabel alloc] initWithFrame:CGRectZero];
        cancelOwnLeadsLB.font = [UIFont systemFontOfSize:14];
        cancelOwnLeadsLB.text=@"仅撤销自己的报盘";
        [centralView addSubview:cancelOwnLeadsLB];
        [cancelOwnLeadsLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_cancelOwnLeadsBT.mas_top);
            make.left.mas_equalTo(_cancelOwnLeadsBT.mas_right).offset(10);
            make.width.mas_equalTo(150);
            make.height.mas_equalTo(44);
        }];
        
    
    _cancelAllLeadsBT = [[UIButton alloc] initWithFrame:CGRectZero];
    _cancelAllLeadsBT.titleLabel.textColor = [UIColor whiteColor];
    _cancelAllLeadsBT.imageEdgeInsets = UIEdgeInsetsMake(12, 12, 12, 12);
    [_cancelAllLeadsBT setImage:[UIImage imageNamed:@"radio_normal"] forState:UIControlStateNormal];
    [_cancelAllLeadsBT addTarget:self action:@selector(changeCancelAllLeadsButtonImageAction:) forControlEvents:UIControlEventTouchUpInside];
    [centralView addSubview:_cancelAllLeadsBT];
    [_cancelAllLeadsBT mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(centralView.mas_top).offset(100);
        make.left.mas_equalTo(centralView.mas_left).offset(10);
        make.width.mas_equalTo(44);
        make.height.mas_equalTo(44);
    }];
    
    
    UILabel *cancelAllLeadsLB = [[UILabel alloc] initWithFrame:CGRectZero];
    cancelAllLeadsLB.font = [UIFont systemFontOfSize:14];
    cancelAllLeadsLB.text=@"撤销所有的报盘";
    [centralView addSubview:cancelAllLeadsLB];
    [cancelAllLeadsLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_cancelAllLeadsBT.mas_top);
        make.left.mas_equalTo(_cancelAllLeadsBT.mas_right).offset(10);
        make.width.mas_equalTo(100);
        make.height.mas_equalTo(44);
    }];
}


-(void)setConfirmDescription:(UIView *) centralView content:(NSString *)content{
    
    UILabel *confirmDescriptionLB = [[UILabel alloc] initWithFrame:CGRectZero];
    confirmDescriptionLB.font = [UIFont systemFontOfSize:16];
    confirmDescriptionLB.text=content;
    [centralView addSubview:confirmDescriptionLB];
    [confirmDescriptionLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(centralView.mas_top).offset(50);
        make.centerX.mas_equalTo(centralView);
        make.centerY.mas_equalTo(centralView);
        make.height.mas_equalTo(44);
    }];
}

-(void)setCancelButton:(UIView *) centralView{
    
    UIButton *cancelBT = [[UIButton alloc] initWithFrame:CGRectZero];
    cancelBT.backgroundColor = GRAY_CUSTOM;
    cancelBT.titleLabel.textColor = [UIColor whiteColor];
    cancelBT.titleLabel.font=[UIFont boldSystemFontOfSize:16];
    [cancelBT setTitle: @"取消" forState:UIControlStateNormal];
    [cancelBT addTarget:self action:@selector(cancelButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [centralView addSubview:cancelBT];
    [cancelBT mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(centralView.top).offset(160);
        make.left.mas_equalTo(centralView.mas_left);
        make.width.mas_equalTo(ScreenWidth/2-30);
        make.height.mas_equalTo(40);
    }];
}

-(void)setConfirmButton:(UIView *) centralView{
    UIButton *confirmBT = [[UIButton alloc] initWithFrame:CGRectZero];
    confirmBT.backgroundColor = RedColor_Custom;
    confirmBT.titleLabel.textColor = [UIColor whiteColor];
    confirmBT.titleLabel.font=[UIFont boldSystemFontOfSize:16];
    [confirmBT setTitle: @"确定" forState:UIControlStateNormal];
    [confirmBT addTarget:self action:@selector(confirmButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [centralView addSubview:confirmBT];
    [confirmBT mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(centralView.top).offset(160);
        make.left.mas_equalTo(ScreenWidth/2-30);
        make.width.mas_equalTo(ScreenWidth/2-30);
        make.height.mas_equalTo(40);
    }];
}

-(void)setCloseButton:(UIView *) centralView{
    UIButton *closeBT = [[UIButton alloc] initWithFrame:CGRectZero];
    closeBT.backgroundColor = RedColor_Custom;
    closeBT.titleLabel.textColor = [UIColor whiteColor];
    closeBT.titleLabel.font=[UIFont boldSystemFontOfSize:16];
    [closeBT setTitle: @"关闭" forState:UIControlStateNormal];
    [closeBT addTarget:self action:@selector(closeButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [centralView addSubview:closeBT];
    [closeBT mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(centralView.top).offset(160);
        make.left.mas_equalTo(centralView.mas_left);
        make.width.mas_equalTo(ScreenWidth-30);
        make.height.mas_equalTo(40);

    }];
}

-(void)changeCancelOwnLeadsButtonImageAction:(id)sender{
     _isCancelAllLeads=NO;
     [_cancelOwnLeadsBT setImage:[UIImage imageNamed:@"radio_checked"] forState:UIControlStateNormal];
     [_cancelAllLeadsBT setImage:[UIImage imageNamed:@"radio_normal"] forState:UIControlStateNormal];
}

-(void)changeCancelAllLeadsButtonImageAction:(id)sender{
    _isCancelAllLeads=YES;
    [_cancelAllLeadsBT setImage:[UIImage imageNamed:@"radio_checked"] forState:UIControlStateNormal];
    [_cancelOwnLeadsBT setImage:[UIImage imageNamed:@"radio_normal"] forState:UIControlStateNormal];
}

-(void)cancelButtonAction:(id)sender{
    [self removeFromSuperview];
}

-(void)confirmButtonAction:(id)sender{
    if(_isCancelAllLeads)
        [self.delegate cancelAllLeads];
    else
        [self.delegate cancelOwnLeads];
    
    [self closeConfirmDialog];
    [self openFinishConfirmDialog];
}

-(void)closeButtonAction:(id)sender{

    [self removeFromSuperview];
    [self.delegate viewWillAppearLocal];
}

-(void)openFinishConfirmDialog{

    UIView *centralView=[self setCentralView];
    [self setTitle:centralView];
   
    [self setConfirmDescription:centralView content:@"撤销成功"];
    [self setCloseButton:centralView];
}


-(void)closeConfirmDialog{
    [self.delegate hideProgressLocal];
    //[self.delegate toastLocal:@"撤销成功"];
    [self removeAllSubviews];
    //[self.delegate viewWillAppearLocal];
}



- (void)viewDidLoad {
    //[super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    //[super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
