//
//  SHTradeBreakBodyCell.h
//  shcem
//
//  Created by xupeipei on 2016/12/29.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHGetBuyListModel.h"
#import "SHQueryModel.h"
#import "SHTradeBreakBottomCell.h"

static NSString *SHTradeBreakBodyCellReuseIdentifier = @"SHTradeBreakBodyCell";

@protocol SHTradeBreakBodyCellDelegate <NSObject>

-(void)SHTradeBreakBodyCellEvent:(NSInteger)index;

@end


@interface SHTradeBreakBodyCell : UITableViewCell
@property (nonatomic,assign) NSInteger cellHeight;

@property (nonatomic,strong) SHTradeBreakBottomModel *tradeBreakBottomModel;
@property (nonatomic,strong) SHGetBuyListModel *getBuyListModel;
@property (nonatomic,strong) NSArray *queryArray;
@property (nonatomic ,weak) id<SHTradeBreakBodyCellDelegate> delegate;

@end
