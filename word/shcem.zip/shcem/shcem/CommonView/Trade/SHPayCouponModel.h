//
//  SHPayCouponModel.h
//  shcem
//
//  Created by xupeipei on 2016/12/27.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHPayCouponModel : NSObject

//是否开启手续费
@property(nonatomic,copy) NSString *hasCoupon;

//优惠券券码
@property(nonatomic,copy) NSString *CouponNumber;

//优惠券张数
@property(nonatomic,copy) NSString *recoreds;

//cell密码
@property(nonatomic,copy) NSString *passWord;

//手续费余额
@property(nonatomic,copy) NSString *CouponBalance;

@end
