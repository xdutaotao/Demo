//
//  SHCouponListCell.h
//  shcem
//
//  Created by xupeipei on 2016/12/27.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHCouponModel.h"


@interface SHCouponListCell : UITableViewCell

@property (nonatomic,strong) SHCouponModel *couponModel;

@property (nonatomic,assign) NSInteger cellSelect;


@end
