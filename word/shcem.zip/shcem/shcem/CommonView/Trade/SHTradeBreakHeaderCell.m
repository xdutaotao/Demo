//
//  SHTradeBreakHeaderCell.m
//  shcem
//
//  Created by xupeipei on 2016/12/29.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHTradeBreakHeaderCell.h"
#import <Masonry/Masonry.h>

@interface SHTradeBreakHeaderCell()

@property (nonatomic,strong) UILabel* goodsTypeLB;
@property (nonatomic,strong) UILabel* productNameLB;
@property (nonatomic,strong) UILabel* hadSendTitleLB;
@property (nonatomic,strong) UILabel* hadSendLB;
@property (nonatomic,strong) UILabel* allowApplyCountLB;
@property (nonatomic,strong) UILabel* allowApplyCountTitleLB;
@property (nonatomic,strong) UILabel* allowApplyInfoTitleLB;

@end


@implementation SHTradeBreakHeaderCell

-(void)setGetBuyListModel:(SHGetBuyListModel *)getBuyListModel{
    _getBuyListModel = getBuyListModel;
    
    NSInteger hasSend = _getBuyListModel.Quantity.integerValue - _getBuyListModel.NoDeliveryQuantity.integerValue;
    float hasSendWeight = hasSend * _getBuyListModel.TradeUnitNumber.floatValue;
    
    self.goodsTypeLB.text = [getBuyListModel.GoodsType isEqual:@"0"]? @"现货":@"预售";
    self.productNameLB.text = [NSString stringWithFormat:@"%@%@%@",_getBuyListModel.CategoryShow,_getBuyListModel.BrandShow,_getBuyListModel.SourcePlaceShow];
    self.hadSendLB.text = [NSString stringWithFormat:@"%ld批%g吨",(long)hasSend,hasSendWeight];
    self.allowApplyCountLB.text = [NSString stringWithFormat:@"%@批%@吨",_getBuyListModel.Quantity,_getBuyListModel.Weight];

}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.goodsTypeLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.goodsTypeLB.textAlignment = NSTextAlignmentCenter;
        self.goodsTypeLB.layer.masksToBounds = YES;
        self.goodsTypeLB.layer.cornerRadius = 5;
        self.goodsTypeLB.backgroundColor = COLOR_NAV_RED;
        self.goodsTypeLB.textColor = [UIColor whiteColor];
        self.goodsTypeLB.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:self.goodsTypeLB];
        [self.goodsTypeLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.top).offset(15);
            make.left.mas_equalTo(self.contentView.mas_left).offset(10);
            make.width.mas_equalTo(40);
            make.height.mas_equalTo(20);
        }];
        
        self.productNameLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.productNameLB.font = [UIFont systemFontOfSize:16];
        [self.contentView addSubview:self.productNameLB];
        [self.productNameLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top);
            make.left.mas_equalTo(self.goodsTypeLB.mas_right).offset(10);
            make.right.mas_equalTo(self.contentView.mas_right).offset(-10);
            make.height.mas_equalTo(50);
        }];
        
        self.hadSendTitleLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.hadSendTitleLB.font = [UIFont systemFontOfSize:14];
        self.hadSendTitleLB.textColor = HexRGB(0x999999);
        self.hadSendTitleLB.text = @"已发提货委托书数量:";
        [self.contentView addSubview:self.hadSendTitleLB];
        [self.hadSendTitleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.productNameLB.mas_bottom);
            make.left.mas_equalTo(self.goodsTypeLB.mas_left);
            make.width.mas_equalTo(200);
            make.height.mas_equalTo(40);
        }];
        
        self.hadSendLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.hadSendLB.font = [UIFont systemFontOfSize:14];
        self.hadSendLB.textColor = BLUE_CUSTOM;
        [self.contentView addSubview:self.hadSendLB];
        [self.hadSendLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.hadSendTitleLB.mas_top);
            make.left.mas_equalTo(self.hadSendTitleLB.mas_right);
            make.right.mas_equalTo(self.productNameLB.mas_right);
            make.height.mas_equalTo(self.hadSendTitleLB);
        }];
        
        
        self.allowApplyCountTitleLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.allowApplyCountTitleLB.font = [UIFont systemFontOfSize:14];
        self.allowApplyCountTitleLB.textColor = HexRGB(0x999999);
        self.allowApplyCountTitleLB.text = @"可申请违约数量:";
        [self.contentView addSubview:self.allowApplyCountTitleLB];
        [self.allowApplyCountTitleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.hadSendTitleLB.mas_bottom);
            make.left.mas_equalTo(self.hadSendTitleLB.mas_left);
            make.width.mas_equalTo(200);
            make.height.mas_equalTo(40);
        }];
        
        self.allowApplyCountLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.allowApplyCountLB.font = [UIFont systemFontOfSize:14];
        self.allowApplyCountLB.textColor = BLACK_CUSTOM;
        [self.contentView addSubview:self.allowApplyCountLB];
        [self.allowApplyCountLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.allowApplyCountTitleLB.mas_top);
            make.left.mas_equalTo(self.allowApplyCountTitleLB.mas_right);
            make.right.mas_equalTo(self.productNameLB.mas_right);
            make.height.mas_equalTo(self.allowApplyCountTitleLB);
        }];
        
        self.allowApplyInfoTitleLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.allowApplyInfoTitleLB.font = [UIFont systemFontOfSize:14];
        self.allowApplyInfoTitleLB.textColor = HexRGB(0x999999);
        self.allowApplyInfoTitleLB.text = @"可申请违约信息:";
        [self.contentView addSubview:self.allowApplyInfoTitleLB];
        [self.allowApplyInfoTitleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.allowApplyCountTitleLB.mas_bottom);
            make.left.mas_equalTo(self.allowApplyCountTitleLB.mas_left);
            make.width.mas_equalTo(200);
            make.height.mas_equalTo(40);
        }];
        
    }
    
    return self;
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
