//
//  SHConfirmReceiveHeaderCell.m
//  shcem
//
//  Created by xupeipei on 2016/12/19.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHConfirmReceiveHeaderCell.h"
#import <Masonry/Masonry.h>

@implementation SHConfirmReceiveHeaderCell

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UILabel* productNameLB = [[UILabel alloc] initWithFrame:CGRectZero];
        productNameLB.font = [UIFont systemFontOfSize:16];
        productNameLB.text = @"溢短调整";
        [self.contentView addSubview:productNameLB];
        [productNameLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top);
            make.left.mas_equalTo(self.contentView.mas_left).offset(10);
            make.right.mas_equalTo(self.contentView.mas_right).offset(-10);
            make.height.mas_equalTo(44);
        }];
        
    }
    
    return self;
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
