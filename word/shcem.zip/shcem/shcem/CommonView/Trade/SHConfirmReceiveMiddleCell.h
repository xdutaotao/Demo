//
//  SHConfirmReceiveMiddleCell.h
//  shcem
//
//  Created by xupeipei on 2016/12/19.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHTradeGetListModel.h"


@interface SHConfirmReceiveMiddleCell : UITableViewCell

@property (nonatomic, strong) SHTradeGetListModel *tradeGetListModel;

@end
