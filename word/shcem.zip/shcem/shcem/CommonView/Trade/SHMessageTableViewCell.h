//
//  SHMessageTableViewCell.h
//  shcem
//
//  Created by xupeipei on 2016/12/8.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SHMessageModel.h"
static NSString *SHMessageTableViewCellReuseIdentifier = @"SHMessageTableViewCell";

@interface SHMessageTableViewCell : UITableViewCell

@property (nonatomic,strong) SHMessageModel * messageModel;

@end
