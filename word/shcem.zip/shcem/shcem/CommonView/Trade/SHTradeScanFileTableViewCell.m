//
//  SHTradeScanFileTableViewCell.m
//  shcem
//
//  Created by xupeipei on 2016/12/16.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHTradeScanFileTableViewCell.h"

@implementation SHTradeScanFileTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
