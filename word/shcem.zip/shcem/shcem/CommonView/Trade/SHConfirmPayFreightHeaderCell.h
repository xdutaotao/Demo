//
//  SHConfirmPayFreightHeaderCell.h
//  shcem
//
//  Created by huangdeyu on 2017/3/29.
//  Copyright © 2017年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GetFeeInfoModel.h"

@interface SHConfirmPayFreightHeaderCell : UITableViewCell

@property (nonatomic,strong) GetFeeInfoModel *getFeeInfoModel;

@end
