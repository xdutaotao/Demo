//
//  SHOrderDetailListCell.m
//  shcem
//
//  Created by xupeipei on 2016/12/28.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHOrderDetailListCell.h"
#import <Masonry/Masonry.h>

@interface SHOrderDetailListCell()

@property (nonatomic,strong) UILabel* QuantityTitleLB;
@property (nonatomic,strong) UILabel* QuantityLB;

@end

@implementation SHOrderDetailListCell

-(void)setTradeDetailListModel:(CustomScrollViewCellModel *)tradeDetailListModel{
    _tradeDetailListModel = tradeDetailListModel;
    
    self.QuantityTitleLB.text = tradeDetailListModel.title;
    self.QuantityLB.text = tradeDetailListModel.content;
    self.QuantityLB.textColor = tradeDetailListModel.contentColor;
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        self.QuantityTitleLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.QuantityTitleLB.font = [UIFont systemFontOfSize:14];
        self.QuantityTitleLB.textColor = [UIColor grayColor];
        self.QuantityTitleLB.text = @"数量";
        self.QuantityTitleLB.numberOfLines = 0;
        [self.contentView addSubview:self.QuantityTitleLB];
        [self.QuantityTitleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top);
            make.bottom.mas_equalTo(self.contentView.mas_bottom);
            make.left.mas_equalTo(self.contentView.mas_left).offset(10);
            make.width.mas_equalTo(100);
        }];
        
        self.QuantityLB = [[UILabel alloc] initWithFrame:CGRectZero];
        self.QuantityLB.font = [UIFont systemFontOfSize:14];
        self.QuantityLB.text = @"时间";
        self.QuantityLB.numberOfLines = 0;
        [self.contentView addSubview:self.QuantityLB];
        [self.QuantityLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.QuantityTitleLB.mas_top);
            make.left.mas_equalTo(self.QuantityTitleLB.mas_right).offset(10);
            make.right.mas_equalTo(self.contentView.mas_right).offset(-10);
            make.height.mas_equalTo(self.QuantityTitleLB);
        }];
    }
    
    return self;
}



- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
