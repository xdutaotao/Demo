//
//  SHLoginSectionView.m
//  shcem
//
//  Created by huangdeyu on 2016/12/8.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "SHLoginSectionView.h"
#import "Masonry.h"

@interface SHLoginSectionView ()
@property(nonatomic,strong) UIButton * forgetBtn;
@property(nonatomic,strong) UIButton * verifyBtn;
@end

@implementation SHLoginSectionView


-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.forgetBtn];
        [self addSubview:self.verifyBtn];
        [self layout];
    }
    return self;
}
-(void)layout{
    [self.forgetBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(15);
        make.centerY.equalTo(self);
    }];
    [self.verifyBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self).offset(-15);
        make.centerY.equalTo(self);
    }];
}

#pragma mark - action

-(void)btnClicked:(UIButton *)btn{
    [self.delegate sectionbtnsClicked:btn];
}

#pragma mark - 初始化

-(UIButton *)forgetBtn{
    if (!_forgetBtn) {
        _forgetBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_forgetBtn setTitle:@"忘记密码？" forState:UIControlStateNormal];
        [_forgetBtn setTitleColor:COLOR_NAV_RED forState:UIControlStateNormal];
        [_forgetBtn.titleLabel setFont:[UIFont systemFontOfSize:14]];
        _forgetBtn.tag = 0;
        [_forgetBtn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _forgetBtn;
}

-(UIButton *)verifyBtn{
    if (!_verifyBtn) {
        _verifyBtn  = [UIButton buttonWithType:UIButtonTypeCustom];
        [_verifyBtn setTitle:@"验证码登录" forState:UIControlStateNormal];
        [_verifyBtn setTitleColor:COLOR_NAV_RED forState:UIControlStateNormal];
        [_verifyBtn.titleLabel setFont:[UIFont systemFontOfSize:14]];
        _verifyBtn.tag = 1;
        [_verifyBtn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _verifyBtn;
}

@end
