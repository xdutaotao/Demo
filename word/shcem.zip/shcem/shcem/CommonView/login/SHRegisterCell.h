//
//  SHRegisterCell.h
//  Frey
//
//  Created by huangdeyu on 16/4/1.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHRegisterCell : UITableViewCell
-(void)setPlaceHolder:(NSString *)placeHolder andTag:(NSInteger)tag;
@property(nonatomic,strong)UIButton * button;
@property(nonatomic,strong)UITextField * textField;
-(void)startTimer;
-(void)stopTimer;
@end
