//
//  SHLoginHeaderView.h
//  Frey
//
//  Created by huangdeyu on 16/4/1.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHLoginHeaderView : UIView
-(void)changeToSmall;
-(void)changeToBig;
@end
