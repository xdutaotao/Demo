//
//  SHLoginCell.h
//  Frey
//
//  Created by huangdeyu on 16/4/1.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHLoginCell : UITableViewCell
@property(nonatomic,assign) BOOL  isLogin;
-(void)loadWithType:(NSInteger)type;
-(void)loadWithLogo:(NSString *)logo placeHolder:(NSString *)holder andTextfieldTag:(NSInteger)tag keyboardType:(UIKeyboardType)type secure:(BOOL)secure;
@end
