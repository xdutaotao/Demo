//
//  SHLoginSectionView.h
//  shcem
//
//  Created by huangdeyu on 2016/12/8.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SHLoginSectionViewDelegate <NSObject>

@required
-(void)sectionbtnsClicked:(UIButton *)btn;

@end

@interface SHLoginSectionView : UIView

@property(nonatomic,weak) id<SHLoginSectionViewDelegate> delegate;
@end
