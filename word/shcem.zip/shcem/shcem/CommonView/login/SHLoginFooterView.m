//
//  SHLoginFooterView.m
//  Frey
//
//  Created by huangdeyu on 16/4/1.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import "SHLoginFooterView.h"
#import "Masonry.h"

@interface SHLoginFooterView()
@property(nonatomic,strong)UIButton * loginBtn;
@property(nonatomic,strong)UIButton * registerBtn;
@property(nonatomic,strong)UILabel * protocolLabel;
@end

@implementation SHLoginFooterView


-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
     //   self.backgroundColor = [UIColor lightGrayColor];
        [self addSubview:self.loginBtn];
        [self addSubview:self.registerBtn];
        [self addSubview:self.protocolLabel];
        [self layout];
    }
    return self;
}
-(void)layout{
  
    [self.loginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).offset(1);
        make.right.equalTo(self).offset(-15);
        make.left.equalTo(self).offset(15);
        make.height.equalTo(@40);
    }];
    [self.registerBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).offset(50);
        make.right.equalTo(self).offset(-15);
        make.left.equalTo(self).offset(15);
        make.height.equalTo(@40);
    }];

    [self.protocolLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.registerBtn.mas_bottom).offset(10);
        make.centerX.equalTo(self.mas_centerX);
        make.width.mas_equalTo(self.width - 30);
    }];

}
#pragma mark - 按钮点击
-(void)btnClicked:(UIButton *)button{
    [self.delegate loginOrRegisterClicked:button];
}
#pragma mark - 许可协议点击
-(void)tapOn:(UIGestureRecognizer *)gesture{
    DLog(@"点击许可协议");
    [self.delegate protocolClicked];
}


#pragma mark - 初始化

-(UIButton *)loginBtn{
    if (!_loginBtn) {
        _loginBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        [_loginBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_loginBtn setTitle:@"登录" forState:UIControlStateNormal];
        [_loginBtn.titleLabel setFont:[UIFont systemFontOfSize:18]];
        [_loginBtn setBackgroundColor:COLOR_NAV_RED];
        _loginBtn.layer.cornerRadius = 3.0;
        _loginBtn.layer.masksToBounds = YES;

        [_loginBtn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
        _loginBtn.tag = 0;
    }
    return _loginBtn;
}
-(UIButton *)registerBtn{
    if (!_registerBtn) {
        _registerBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        [_registerBtn setTitle:@"注册" forState:UIControlStateNormal];
        [_registerBtn setTitleColor:COLOR_NAV_RED forState:UIControlStateNormal];
        [_registerBtn setBackgroundColor:[UIColor whiteColor]];
        _registerBtn.layer.borderColor = COLOR_NAV_RED.CGColor;
        _registerBtn.layer.borderWidth = 1.0;
        _registerBtn.layer.cornerRadius = 3.0;
        [_registerBtn.titleLabel setFont:[UIFont systemFontOfSize:18]];
        _registerBtn.layer.masksToBounds = YES;
        [_registerBtn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
        _registerBtn.tag = 1;
    }
    return _registerBtn;
}
-(UILabel *)protocolLabel{
    if (!_protocolLabel) {
        _protocolLabel = [[UILabel alloc] init];
        [_protocolLabel setFont:[UIFont systemFontOfSize:14]];
        _protocolLabel.numberOfLines = 2;
        
        NSMutableAttributedString *attString = [[NSMutableAttributedString alloc] initWithString:@"轻触上面的“登录或注册”按钮，即表示您同意《上海化交软件许可及服务协议》"];
        [attString setAttributes:@{NSForegroundColorAttributeName:COLOR_NAV_RED,NSUnderlineStyleAttributeName:[NSNumber numberWithLong:NSUnderlineStyleSingle] } range:NSMakeRange(21, attString.length - 21)];

        _protocolLabel.attributedText = attString;
        UITapGestureRecognizer * tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapOn:)];
        _protocolLabel.userInteractionEnabled = YES;
        [_protocolLabel addGestureRecognizer:tapGesture];
    }
    return _protocolLabel;
}
@end
