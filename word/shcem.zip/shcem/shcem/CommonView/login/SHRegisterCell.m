//
//  SHRegisterCell.m
//  Frey
//
//  Created by huangdeyu on 16/4/1.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import "SHRegisterCell.h"
#import "Masonry.h"

@interface SHRegisterCell()<UITextFieldDelegate>
@property(nonatomic,strong)NSTimer * timer;
@property(nonatomic,assign)NSInteger count;
@property(nonatomic,strong) UIImageView * imgView;
@end

@implementation SHRegisterCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self addSubview:self.textField];
        [self addSubview:self.button];
        [self addSubview:self.imgView];
    }
    return self;
}
-(void)setPlaceHolder:(NSString *)placeHolder andTag:(NSInteger)tag{
    self.textField.tag = tag;
    self.textField.placeholder = placeHolder;
    [self layout];
}
-(void)layout{
    [self.button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.mas_centerY);
        make.right.equalTo(self).offset(-15);
    }];
    [self.textField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(45);
        make.right.equalTo(self);
        make.centerY.equalTo(self.mas_centerY);
    }];
    [self.imgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(15);
        make.centerY.equalTo(self);
    }];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self endEditing:YES];
    return YES;
}
//#pragma mark - 按钮点击
//-(void)btnClicked:(UIButton *)button{
//    //button.enabled = NO;
//    //[self startTimer];
//    if (self.cellBtnClickedBlock) {
//        self.cellBtnClickedBlock(self.textField.text);
//    }
//    
//}
#pragma mark - 定时器
-(void)startTimer{
    if (self.timer) {
        [self.timer invalidate];
        self.timer = nil;
    }
    self.button.enabled = NO;
    [self.button setTitle:@"  倒计时60s  " forState:UIControlStateNormal];
    self.count = 60;
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(timerGo) userInfo:nil repeats:YES];
}
-(void)timerGo{
    self.count--;
    [self.button setTitle:[NSString stringWithFormat:@"  倒计时%lds  ",(long)self.count] forState:UIControlStateNormal];
    if (self.count == 0) {
        [self stopTimer];
        [self.button setTitle:@"  获取验证码  " forState:UIControlStateNormal];
        self.button.enabled = YES;
    }
}
-(void)stopTimer{
    if (self.timer) {
        [self.timer invalidate];
        self.timer = nil;
        self.button.enabled = YES;
        [_button setTitle:@"  获取验证码  " forState:UIControlStateNormal];
    }
}

#pragma mark - 初始化
-(UITextField *)textField{
    if (!_textField) {
        _textField = [[UITextField alloc] init];
        _textField.keyboardType = UIKeyboardTypeNumberPad;
        _textField.delegate = self;
        _textField.returnKeyType = UIReturnKeyDone;
        [_textField setFont:[UIFont systemFontOfSize:14]];
    }
    return _textField;
}

-(UIButton *)button{
    if (!_button) {
        _button = [UIButton buttonWithType:UIButtonTypeCustom];
        [_button setTitle:@"  获取验证码  " forState:UIControlStateNormal];
        [_button.titleLabel setFont:[UIFont systemFontOfSize:14]];
        _button.layer.borderWidth = 1.0;
        _button.layer.borderColor = COLOR_NAV_RED.CGColor;
        _button.layer.cornerRadius = 3.0;
        _button.layer.masksToBounds = YES;
      //  _button.hidden = YES;
        [_button setTitleColor:COLOR_NAV_RED forState:UIControlStateNormal];
      //  [_button addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _button;
}
-(UIImageView *)imgView{
    if (!_imgView) {
        _imgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"verifyCode"]];
    }
    return _imgView;
}

@end
