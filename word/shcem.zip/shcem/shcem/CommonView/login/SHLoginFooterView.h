//
//  SHLoginFooterView.h
//  Frey
//
//  Created by huangdeyu on 16/4/1.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SHLoginFooterProtocol <NSObject>

@required
-(void)loginOrRegisterClicked:(UIButton *)button;

-(void)protocolClicked;

@end

@interface SHLoginFooterView : UIView
@property(nonatomic,weak) id<SHLoginFooterProtocol> delegate;
@end
