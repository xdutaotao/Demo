//
//  SHLoginCell.m
//  Frey
//
//  Created by huangdeyu on 16/4/1.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import "SHLoginCell.h"
#import "Masonry.h"

@interface SHLoginCell()<UITextFieldDelegate>
@property(nonatomic,strong)UIImageView * logo;
@property(nonatomic,strong)UITextField * textField;
@end

@implementation SHLoginCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self addSubview:self.logo];
        [self addSubview:self.textField];
        [self layout];
    }
    return self;
}
-(void)loadWithType:(NSInteger)type{
    if (type == 0) {
        _logo.image = [UIImage imageNamed:@"loginUserlogo"];
        _logo.contentMode = UIViewContentModeCenter;
        _textField.placeholder = STR_MINE_INPUT_TEL;
        _textField.tag = type;
        _textField.keyboardType = UIKeyboardTypeNumberPad;

    }else{
        _logo.image = [UIImage imageNamed:@"loginPwdLogo"];
        _logo.contentMode = UIViewContentModeCenter;
        _textField.placeholder = STR_MINE_INPUT_PASSWORD;
        _textField.secureTextEntry = YES;
        _textField.tag = type;
    }
}
-(void)loadWithLogo:(NSString *)logo placeHolder:(NSString *)holder andTextfieldTag:(NSInteger)tag keyboardType:(UIKeyboardType)type secure:(BOOL)secure{
    _logo.image = [UIImage imageNamed:logo];
    _logo.contentMode = UIViewContentModeCenter;
    if (holder.length == 0) {
        _textField.text = [[SHUserManager sharedManager] getUserInfoDirect].Mobile;
        _textField.userInteractionEnabled = NO;
    }else{
        _textField.placeholder = holder;
        _textField.userInteractionEnabled = YES;
    }
    
    _textField.tag = tag;
    _textField.keyboardType = type;
    if(secure){
        _textField.secureTextEntry = YES;
    }
}

-(void)layout{
    [self.logo mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(15);
        make.centerY.equalTo(self.contentView.mas_centerY);
    }];
    [self.textField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self).offset(45);
        make.centerY.equalTo(self.contentView.mas_centerY);
        make.right.equalTo(self.contentView);
        make.height.equalTo(self);
    }];
}
#pragma mark - textField 委托

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self endEditing:YES];
    return YES;
}
#pragma mark - logo
-(UIImageView *)logo{
    if (!_logo) {
        _logo = [[UIImageView alloc ] init];
    }
    return _logo;
}
-(UITextField *)textField{
    if (!_textField) {
        _textField = [[UITextField alloc] init];
        _textField.keyboardType = UIKeyboardTypeASCIICapable;
        _textField.delegate = self;
        _textField.returnKeyType = UIReturnKeyDone;
      //  [_textField setFont:[UIFont systemFontOfSize:14]];
        [_textField setFont:[UIFont systemFontOfSize:15]];
    }
    return _textField;
}

@end
