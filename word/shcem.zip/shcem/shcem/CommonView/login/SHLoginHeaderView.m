//
//  SHLoginHeaderView.m
//  Frey
//
//  Created by huangdeyu on 16/4/1.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import "SHLoginHeaderView.h"

@interface SHLoginHeaderView  ()
@property(nonatomic,strong) UIImageView * imageView;
@end

@implementation SHLoginHeaderView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"loginLogo"]];
        _imageView.contentMode = UIViewContentModeCenter;
        [self addSubview:_imageView];
        _imageView.frame = self.bounds;
    }
    return self;
}

-(void)changeToSmall{
    [UIView animateWithDuration:0.3 animations:^{
        _imageView.transform = CGAffineTransformMakeScale(0.4, 0.4);
        _imageView.center = CGPointMake(self.centerX, self.centerY + 40);
    }];
}
-(void)changeToBig{
    [UIView animateWithDuration:0.3 animations:^{
        self.imageView.transform = CGAffineTransformIdentity;
        self.imageView.center = self.center;
    }];
}

@end
