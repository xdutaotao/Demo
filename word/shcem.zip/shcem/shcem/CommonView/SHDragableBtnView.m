//
//  SHDragableBtnView.m
//  Frey
//
//  Created by huangdeyu on 16/3/4.
//  Copyright © 2016年 shcem. All rights reserved.
//

#import "SHDragableBtnView.h"
#define PUBLISHBTNX  @"kPublishBtnX"
#define PUBLISHBTNY @"kPublishBtnY"
@interface SHDragableBtnView()
@property(nonatomic,strong) UIButton * button;
@property(nonatomic,strong) UIDynamicAnimator  * animator;
@property(nonatomic,assign) CGPoint startPos;
@end

@implementation SHDragableBtnView

-(instancetype)initWithImage:(UIImage *)image{
    if (self = [super init]) {
        [self addSubview:self.button];
       
        [self.button setBackgroundImage:image forState:UIControlStateNormal];
        self.animator = [[UIDynamicAnimator alloc] initWithReferenceView:self.superview];
         NSUserDefaults * userDefault = [NSUserDefaults standardUserDefaults];
        self.startPos = CGPointMake( [userDefault floatForKey:PUBLISHBTNX],  [userDefault floatForKey:PUBLISHBTNY]);
        self.frame = CGRectMake(self.startPos.x - 40, self.startPos.y - 48, 80, 96);
        self.button.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
    }
    return self;
}

#pragma mark - 拖动事件
-(void)gestureComing:(UIGestureRecognizer *)gesture{
    static CGPoint beginPoint;// = [gesture locationInView:self.view];
    switch (gesture.state) {
        case UIGestureRecognizerStateBegan:
            [self.animator removeAllBehaviors];
            beginPoint = [gesture locationInView:self.superview];
            
            break;
        case UIGestureRecognizerStateChanged:
        {
            CGPoint dragPoint = [gesture locationInView:self.superview];
            self.center = CGPointMake(self.center.x + (dragPoint.x - beginPoint.x)* 1.0, self.center.y + (dragPoint.y - beginPoint.y) * 1.0);//乘以0.9的目的是拖动延后的效果
            beginPoint = dragPoint;
            
        }
            
            break;
        case UIGestureRecognizerStateEnded:{
            [self.animator removeAllBehaviors];
            CGPoint targetPos = self.center;
            if (targetPos.y < 200 || targetPos.y > self.superview.frame.size.height - 200 ) {
                if (targetPos.y < 200) {
                    targetPos.y = self.frame.size.height * 0.5;
                }else{
                    targetPos.y= self.superview.frame.size.height -TabbarHeight - self.frame.size.height * 0.5;
                }
                if (targetPos.x < self.frame.size.width * 0.5) {
                    targetPos.x = self.frame.size.width * 0.5;
                }if (targetPos.x > self.superview.frame.size.width - self.frame.size.width * 0.5) {
                    targetPos.x  = self.superview.frame.size.width - self.frame.size.width * 0.5;
                }
            }else {
                if (targetPos.x < self.superview.frame.size.width * 0.5) {
                    targetPos.x = self.frame.size.width * 0.5;
                }else{
                    targetPos.x = self.superview.frame.size.width - self.frame.size.width * 0.5;
                }
            }
            NSUserDefaults * userDefault = [NSUserDefaults standardUserDefaults];
            [userDefault setFloat:targetPos.x forKey:PUBLISHBTNX];
            [userDefault setFloat:targetPos.y forKey:PUBLISHBTNY];
            UISnapBehavior * snapBehaivor = [[UISnapBehavior alloc] initWithItem:self snapToPoint:targetPos];
            snapBehaivor.damping = 1.0;
            [self.animator addBehavior:snapBehaivor];
        }
            break;
        default:
            break;
    }

}

#pragma mark - 点击事件
-(void)buttonClicked:(UIButton *)button{
    NSLog(@"点击事件");
}
#pragma mark - 初始化
-(UIButton *) button{
    if (!_button) {
        _button = [UIButton buttonWithType:UIButtonTypeSystem];
        [_button addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
        UIPanGestureRecognizer * panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(gestureComing:)];
        [_button addGestureRecognizer:panGesture];
    }
    return _button;
}
@end
