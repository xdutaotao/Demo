//
//  AppDelegate.m
//  shcem
//
//  Created by huangdeyu on 2016/11/21.
//  Copyright © 2016年 Shcem. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+UI.h"
#import "AppDelegate+U_Share.h"
//#import "AppDelegate+JSPatch.h"
#import "AppDelegate+OtherTask.h"
#import "AppDelegate+JPush.h"
#import "SHBaseTabarController.h"
#import "SHHomeWebVC.h"
#import "SHLoginVC.h"

@interface AppDelegate ()
@end
@implementation AppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [self UMengTrack];
    [self UMengSocialTrack];
    [self setupUI];
    [self startTask];
    [self setupJPushWithOptions:launchOptions];
    
    return YES;
}
- (void)applicationWillResignActive:(UIApplication *)application {
}
- (void)applicationDidEnterBackground:(UIApplication *)application {
    DLog(@"应用进入后台");
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
}
- (void)applicationWillEnterForeground:(UIApplication *)application {
    DLog(@"应用进入前台");
    
    [application setApplicationIconBadgeNumber:0];
    [application cancelAllLocalNotifications];
    [[SHUserManager sharedManager] updateUnreadCount:^(NSError *err, id responseObject) {
    }];
}
- (void)applicationDidBecomeActive:(UIApplication *)application {

}
- (void)applicationWillTerminate:(UIApplication *)application {
}

- (void)application:(UIApplication *)application
didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    /// Required - 注册 DeviceToken
    [JPUSHService registerDeviceToken:deviceToken];
}
- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    //Optional
    DLog(@"did Fail To Register For Remote Notifications With Error: %@", error);
}
-(void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(nonnull void (^)(UIBackgroundFetchResult))completionHandler{
    // Required, iOS 7 Support
    [JPUSHService handleRemoteNotification:userInfo];
    completionHandler(UIBackgroundFetchResultNewData);
    DLog(@"ios7即以上系统收到通知");
    [[SHUserManager sharedManager] updateUnreadCount:^(NSError *err, id responseObject) {
    }];
}
-(void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo{
    // Required,For systems with less than or equal to iOS6
    [JPUSHService handleRemoteNotification:userInfo];
}

- (BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void (^)(NSArray *restorableObjects))restorationHandler{
    
    NSString *theToken=[[SHUserManager sharedManager]getToken];
    SHBaseTabarController *baseTabBar = (SHBaseTabarController *)self.window.rootViewController;
    NSString *url=[WEBREQUESTURL stringByAppendingString:WEB_GUESS];
    
    if(theToken){
        NSMutableDictionary *queryDic=[NSMutableDictionary alloc];
        NSString * queryStr= userActivity.webpageURL.query;
        NSArray *queryArray=[queryStr componentsSeparatedByString:@"&"];
    
        if(queryArray!=nil&&queryArray.count>0){
        
            queryDic=[queryDic initWithCapacity:queryArray.count];
        
            for(int i=0;i<queryArray.count;i++){
                NSArray * queryKeyAndValue=[queryArray[i] componentsSeparatedByString:@"="];
                if(queryKeyAndValue.count==2)
                    [queryDic setValue:queryKeyAndValue[1] forKey:queryKeyAndValue[0]];
            }
            
            url=[url stringByAppendingString:[NSString stringWithFormat:@"?traderID=%@",[[SHUserManager sharedManager] getUserInfoDirect].TraderID]];
            url=[url stringByAppendingString:[NSString stringWithFormat:@"&UserCode=%@",[[SHUserManager sharedManager] getUserInfoDirect].UserCode]];
            url=[url stringByAppendingString:[NSString stringWithFormat:@"&TraderName=%@",[[SHUserManager sharedManager] getUserInfoDirect].TraderName]];
            url=[url stringByAppendingString:[NSString stringWithFormat:@"&Mobile=%@",[[SHUserManager sharedManager] getUserInfoDirect].Mobile]];
            url=[url stringByAppendingString:[NSString stringWithFormat:@"&from=%@",[queryDic valueForKey:@"from"]]];
            url=[url stringByAppendingString:[NSString stringWithFormat:@"&type=%@",[queryDic valueForKey:@"type"]]];
            url=[url stringByAppendingString:[NSString stringWithFormat:@"&token=%@",theToken]];
            
            SHHomeWebVC * webVC = [[SHHomeWebVC alloc] initWithUrl:url title:WEB_GUESS_TITLE imageName:@"share_blank"];
            [baseTabBar.viewControllers[baseTabBar.selectedIndex] pushViewController:webVC animated:YES];
        }
    }
    else{
        SHLoginVC *login = [[SHLoginVC alloc] initWithEntryClass:NSStringFromClass([self class])];
        [baseTabBar.viewControllers[baseTabBar.selectedIndex] pushViewController:login animated:YES];
    }
    DLog(@"testApplink:%@",url);
    
    return YES;
}


-(NSArray *)getSeparatedArrayByString:(NSString *) separatedStr queryStr:(NSString *)queryStr{
    
    NSArray *queryArray=[queryStr componentsSeparatedByString:separatedStr];
    
    return queryArray;
}


@end
