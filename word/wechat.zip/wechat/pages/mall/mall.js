

const app = getApp()

var list = [];

Page({
  data: {
    imgUrls: [],
    indicatorDots: true,
    autoplay: true,
    interval: 3000,
    duration: 1000,
    currentTab: 0,
    // indicator-dots:true

    motto: 'Hello World',
    userInfo: {},
    list: [
    ],

    isHideLoadMore: true,
    pageIndex: 0,

    myRank: '',
    myName: '',
    myScore: '',
    myAvatar: ''
  },

  getScore: function(){
    var that = this;
    wx.request({
      url: app.globalData.url + '/index.php?g=Api&m=CommonApi&a=getDayScoreBillboard',
      data: {
        page: that.data.pageIndex
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: 'GET',
      success: function (res) {
        console.log(res.data)
        if (that.data.pageIndex == 0) {
          that.setData({
            list: res.data,
            isHideLoadMore: true
          })

          res.data.forEach(function(item){
            if (item.m_id == app.globalData.userAllInfo.m_id){
              console.log(item.m_id);
              that.setData({
                myRank : item.rank,
                myName : item.nickname,
                myScore: item.score,
                myAvatar : item.avatar
              })

              
            }
          })

        } else {
          that.setData({
            list: that.data.list.concat(res.data),
            isHideLoadMore: true
          })
        }

        if (res.data && res.data.length > 0)
          that.data.pageIndex++;
      }
    });

  },

  onLoad: function () {
    var that = this;


    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo
      })
    }

    that.getScore();

  },
  

  onReachBottom: function(){
    var that = this;
    console.log("333333")

    this.setData({
      isHideLoadMore: false
    })


    that.getScore()
  },


  goSecondTab: function () {
    wx.redirectTo({
      url: '../main/main'
    });

  },

  goFourthTab: function () {
    wx.redirectTo({
      url: '../order/order'
    });
  },

  goFirstTab: function () {
    wx.redirectTo({
      url: '../index/index'
    });
  }


})