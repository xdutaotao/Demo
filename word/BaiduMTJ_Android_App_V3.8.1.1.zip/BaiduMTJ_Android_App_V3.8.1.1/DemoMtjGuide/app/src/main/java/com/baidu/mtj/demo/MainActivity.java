/*
 * Copyright (C) 2016 Baidu, Inc. All Rights Reserved.
 */
package com.baidu.mtj.demo;

import com.baidu.mobstat.StatService;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends Activity {

    private static String[] ITEM_DATAS = {
            "基础统计", "页面统计", "事件统计", "Fragment统计", "Webview统计", "完整统计"
    };

    private ListView mLv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        StatService.setDebugOn(true);
        findViewAndSetData();
    }

    private void findViewAndSetData() {
        mLv = (ListView) findViewById(R.id.listview);
        mLv.setOnItemClickListener(mOnItemClickListener);
        mLv.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, ITEM_DATAS));
    }

    private AdapterView.OnItemClickListener mOnItemClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Class<?> cls = null;
            switch (position) {
                case 0:
                    cls = BasicActivity.class;
                    break;
                case 1:
                    cls = PageActivity.class;
                    break;
                case 2:
                    cls = EventActivity.class;
                    break;
                case 3:
                    cls = FragActivity.class;
                    break;
                case 4:
                    cls = WebviewActivity.class;
                    break;
                case 5:
                    cls = CompleteActivity.class;
                    break;
                default:
                    break;
            }

            Intent intent = new Intent(MainActivity.this, cls);
            startActivity(intent);
        }
    };

}
