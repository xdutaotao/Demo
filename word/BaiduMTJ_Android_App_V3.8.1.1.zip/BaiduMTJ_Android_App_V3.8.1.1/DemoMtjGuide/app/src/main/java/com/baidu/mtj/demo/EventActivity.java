/*
 * Copyright (C) 2016 Baidu, Inc. All Rights Reserved.
 */
package com.baidu.mtj.demo;

import com.baidu.mobstat.StatService;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.HashMap;

public class EventActivity extends Activity {
    private Button mEventStartBtn;
    private Button mEventEndBtn;
    private Button mEventDurationBtn;
    private Button mEventCountBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.event);

        findViewAndSetData();
    }

    private void findViewAndSetData() {
        mEventStartBtn = (Button) findViewById(R.id.btn_event_start);
        mEventStartBtn.setOnClickListener(mOnClickListener);
        mEventEndBtn = (Button) findViewById(R.id.btn_event_end);
        mEventEndBtn.setOnClickListener(mOnClickListener);
        mEventDurationBtn = (Button) findViewById(R.id.btn_event_duration);
        mEventDurationBtn.setOnClickListener(mOnClickListener);
        mEventCountBtn = (Button) findViewById(R.id.btn_event_count);
        mEventCountBtn.setOnClickListener(mOnClickListener);
    }

    private View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v == mEventStartBtn) {
                // 事件时长统计，开始；
                StatService.onEventStart(EventActivity.this, "event001", "label001");
            } else if (v == mEventEndBtn) {
                // 事件时长统计，结束，eventId和eventLabel需要与开始的一致；支持事件多参，具体见下面
                StatService.onEventEnd(EventActivity.this, "event001", "label001");
            } else if (v == mEventDurationBtn) {
                // 自定义时长统计；支持事件多参，具体见下面
                StatService.onEventDuration(EventActivity.this, "event001", "label001", 10);
            } else if (v == mEventCountBtn) {
                // 事件次数统计；新版本已支持多参数，通过hashmap传入，其它相关事件接口也支持;相关多参数需要在web端先配置，具体见api接口说明
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("city", "shanghai");
                hashMap.put("count", "10");
                hashMap.put("price", "3");
                StatService.onEvent(EventActivity.this, "event001", "label001", 1, hashMap);
            }
        }
    };
}
