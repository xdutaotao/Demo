/*
 * Copyright (C) 2016 Baidu, Inc. All Rights Reserved.
 */
package com.baidu.mtj.demo;

import com.baidu.mobstat.StatService;

import android.app.Activity;
import android.os.Bundle;

public class AnotherPageActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.another_page);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 页面埋点
        StatService.onPageStart(this, "AnotherPageActivity");
    }

    @Override
    protected void onPause() {
        super.onPause();
        // 配对页面埋点，与start的页面名称要一致
        StatService.onPageEnd(this, "AnotherPageActivity");
    }

}
