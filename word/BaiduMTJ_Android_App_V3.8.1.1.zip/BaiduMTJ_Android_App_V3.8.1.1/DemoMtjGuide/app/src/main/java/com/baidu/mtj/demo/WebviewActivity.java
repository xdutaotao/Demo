/*
 * Copyright (C) 2016 Baidu, Inc. All Rights Reserved.
 */
package com.baidu.mtj.demo;

import com.baidu.mobstat.StatService;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

public class WebviewActivity extends Activity {

    private WebView mWebview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.webview);

        findViewAndSetData();

        // 绑定webview，支持h5埋点的关键步骤
        // 如需支持h5统计，需要将 assets/mobstat.js 拷贝到工程目录下
        StatService.bindJSInterface(this, mWebview);
    }

    private void findViewAndSetData() {
        mWebview = (WebView) findViewById(R.id.webview);
    }

    @Override
    protected void onStart() {
        super.onStart();

        mWebview.loadUrl("file:///android_asset/mobstat.html");
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }
}
