/*
 * Copyright (C) 2016 Baidu, Inc. All Rights Reserved.
 */
package com.baidu.mtj.demo;

import com.baidu.mobstat.StatService;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class BasicActivity extends Activity {

    private Button mDebugBtn;
    private Button mExceptionBtn;
    private Button mChannelBtn;
    private Button mIntegrateBtn;
    private Button mInvokeExceptionBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.basic);

        findViewAndSetData();
    }

    private void findViewAndSetData() {
        mDebugBtn = (Button) findViewById(R.id.btn_debug);
        mDebugBtn.setOnClickListener(mOnClickListener);
        mExceptionBtn = (Button) findViewById(R.id.btn_exception);
        mExceptionBtn.setOnClickListener(mOnClickListener);
        mChannelBtn = (Button) findViewById(R.id.btn_channel);
        mChannelBtn.setOnClickListener(mOnClickListener);
        mIntegrateBtn = (Button) findViewById(R.id.btn_one_code_integrate);
        mIntegrateBtn.setOnClickListener(mOnClickListener);
        mInvokeExceptionBtn = (Button) findViewById(R.id.btn_invoke_exception);
        mInvokeExceptionBtn.setOnClickListener(mOnClickListener);
    }

    private void stat() {
        // 如果没有页面和事件埋点，此代码必须设置，否则无法完成接入
        // 设置发送策略，建议使用 APP_START
        // 发送策略，取值 取值 APP_START、SET_TIME_INTERVAL、ONCE_A_DAY
        // 备注，SET_TIME_INTERVAL与ONCE_A_DAY，如果APP退出或者进程死亡，则不会定时发送
        // 建议此代码不要在Application中设置，否则可能因为进程重启等造成启动次数高，具体见web端sdk帮助中心
        // StatService.setSendLogStrategy(this, SendStrategyEnum.APP_START, 1, false);

        // setSendLogStrategy已经@deprecated，建议使用新的start接口
        // 如果没有页面和自定义事件统计埋点，此代码一定要设置，否则无法完成统计
        // 进程第一次执行此代码，会导致发送上次缓存的统计数据；若无上次缓存数据，则发送空启动日志
        // 由于多进程等可能造成Application多次执行，建议此代码不要埋点在Application中，否则可能造成启动次数偏高
        // 建议此代码埋点在统计路径触发的第一个页面中，若可能存在多个则建议都埋点
        StatService.start(this);
    }

    private View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v == mChannelBtn) {
                // 设置渠道，建议通过manifest.xml配置
                StatService.setAppChannel(BasicActivity.this, "Baidu Market", true);
            } else if (v == mExceptionBtn) {
                // 打开异常收集开关，默认收集java层异常，如果有嵌入SDK提供的so库，则可以收集native crash异常
                StatService.setOn(BasicActivity.this, StatService.EXCEPTION_LOG);
            } else if (v == mIntegrateBtn) {
                stat();
            } else if (v == mDebugBtn) {
                // 打开调试开关，正式版本请关闭，以免影响性能
                StatService.setDebugOn(true);
            } else if (v == mInvokeExceptionBtn) {
                float value = 100 / 0;
                Log.e(BasicActivity.this.getClass().getSimpleName(), value + "");
            }
        }
    };
}
