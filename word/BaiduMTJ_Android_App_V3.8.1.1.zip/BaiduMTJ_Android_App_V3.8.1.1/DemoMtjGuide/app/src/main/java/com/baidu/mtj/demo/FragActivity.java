/*
 * Copyright (C) 2016 Baidu, Inc. All Rights Reserved.
 */
package com.baidu.mtj.demo;

import com.baidu.mobstat.StatService;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.ListFragment;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

public class FragActivity extends FragmentActivity {

    public static String[] array = { "text1", "text2", "text3", "text4",
                                     "text5", "text6", "text7", "text8"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.frag);

        findViewAndSetData();
    }

    private void findViewAndSetData() {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        TitlesFragment titleFragment = new TitlesFragment();
        transaction.add(R.id.titles, titleFragment, "titleFragment");
        transaction.commit();
    }

    public static class TitlesFragment extends ListFragment {

        private ArrayAdapter<String> adapter;

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            return super.onCreateView(inflater, container, savedInstanceState);
        }

        @Override
        public void onPause() {
            super.onPause();
            // 页面埋点
            StatService.onPause(this);
        }

        @Override
        public void onResume() {
            super.onResume();
            // 页面埋点
            StatService.onResume(this);
        }

        @Override
        public void onDestroy() {
            super.onDestroy();
        }

        @Override
        public void onActivityCreated(Bundle savedInstanceState) {
            super.onActivityCreated(savedInstanceState);
            adapter = new ArrayAdapter<String>(getActivity(),
                                               android.R.layout.simple_list_item_1, array);
            setListAdapter(adapter);
        }

        @Override
        public void onListItemClick(ListView l, View v, int position, long id) {
            super.onListItemClick(l, v, position, id);

            FragmentManager manager = getActivity().getSupportFragmentManager();
            FragmentTransaction transaction = manager.beginTransaction();
            DetailsFragment detailFragment = new DetailsFragment();
            transaction.replace(R.id.details, detailFragment, "detailFragment");

            String item = adapter.getItem(position);
            Bundle args = new Bundle();
            args.putString("item", item);
            detailFragment.setArguments(args);

            transaction.commit();
        }
    }

    public static class DetailsFragment extends Fragment {

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
        }

        public String getShownString() {
            return getArguments().getString("item");
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            if (container == null) {
                return null;
            }

            ScrollView scroller = new ScrollView(getActivity());
            TextView text = new TextView(getActivity());

            int padding = (int) TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP, 4, getActivity()
                                                            .getResources().getDisplayMetrics());
            text.setPadding(padding, padding, padding, padding);
            scroller.addView(text);

            text.setText("content is:" + getShownString());
            return scroller;
        }

        @Override
        public void onResume() {
            super.onResume();
            // 页面埋点
            StatService.onPageStart(getActivity(), "details" + getShownString());
        }

        @Override
        public void onPause() {
            super.onPause();
            // 页面埋点
            StatService.onPageEnd(getActivity(), "details" + getShownString());
        }

        @Override
        public void onDestroy() {
            super.onDestroy();
        }
    }

}


