/*
 * Copyright (C) 2016 Baidu, Inc. All Rights Reserved.
 */
package com.baidu.mtj.demo;

import com.baidu.mobstat.SendStrategyEnum;
import com.baidu.mobstat.StatService;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CompleteActivity extends Activity {

    private Button mEventBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.complete);

        findViewAndSetData();

        stat();
    }

    private void findViewAndSetData() {
        mEventBtn = (Button) findViewById(R.id.btn_event);
        mEventBtn.setOnClickListener(mOnClickListener);
    }

    private void stat() {
        // 打开调试开关，正式版本请关闭，以免影响性能
        StatService.setDebugOn(true);

        // 设置APP_KEY，APP_KEY是从mtj官网获取，建议通过manifest.xml配置
        StatService.setAppKey("a9e2ad84a2");
        // 设置渠道，建议通过manifest.xml配置
        StatService.setAppChannel(this, "Baidu Market", true);
        // 打开异常收集开关，默认收集java层异常，如果有嵌入SDK提供的so库，则可以收集native crash异常
        StatService.setOn(this, StatService.EXCEPTION_LOG);

        // 如果没有页面和事件埋点，此代码必须设置，否则无法完成接入
        // 设置发送策略，建议使用 APP_START
        // 发送策略，取值 取值 APP_START、SET_TIME_INTERVAL、ONCE_A_DAY
        // 备注，SET_TIME_INTERVAL与ONCE_A_DAY，如果APP退出或者进程死亡，则不会发送
        // 建议此代码不要在Application中设置，否则可能因为进程重启等造成启动次数高，具体见web端sdk帮助中心
        StatService.setSendLogStrategy(this, SendStrategyEnum.APP_START, 1, false);
    }

    private View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v == mEventBtn) {
                // 自定义事件埋点
                StatService.onEvent(CompleteActivity.this, "event001", "label001");
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        // 页面埋点
        StatService.onPageStart(this, "CompleteActivity");
    }

    @Override
    protected void onPause() {
        super.onPause();
        // 配对页面埋点，与start的页面名称要一致
        StatService.onPageEnd(this, "CompleteActivity");
    }
}
