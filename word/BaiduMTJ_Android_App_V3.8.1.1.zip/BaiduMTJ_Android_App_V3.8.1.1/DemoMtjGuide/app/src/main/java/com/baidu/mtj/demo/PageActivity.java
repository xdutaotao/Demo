/*
 * Copyright (C) 2016 Baidu, Inc. All Rights Reserved.
 */
package com.baidu.mtj.demo;

import com.baidu.mobstat.StatService;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class PageActivity extends Activity {

    private Button mNextPageBtn;
    private Button mPrePageBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page);

        findViewAndSetData();
    }

    private void findViewAndSetData() {
        mNextPageBtn = (Button) findViewById(R.id.btn_next);
        mNextPageBtn.setOnClickListener(mOnClickListener);
        mPrePageBtn = (Button) findViewById(R.id.btn_pre);
        mPrePageBtn.setOnClickListener(mOnClickListener);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 页面埋点，需要使用Activity的引用，以便代码能够统计到具体页面名
        StatService.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // 页面结束埋点，需要使用Activity的引用，以便代码能够统计到具体页面名
        StatService.onPause(this);
    }

    private View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v == mNextPageBtn) {
                Intent intent = new Intent(PageActivity.this, AnotherPageActivity.class);
                startActivityForResult(intent, 0);
            } else if (v == mPrePageBtn) {
                PageActivity.this.finish();
            }
        }
    };
}
