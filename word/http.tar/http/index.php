<?php

echo phpinfo();
/*

$router = array("hello", "world");
$router_cb = array();

for ($i = 0; $i < count($router); $i++) {
	$file = $router[$i] . ".php";
	require_once($file);
	$router_cb[$router[$i]] = $router[$i] . "_entry";
}

$func = $router_cb[$_GET['a']];
$func();
 */

?>
