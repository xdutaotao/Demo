create database if not exists rss;

use rss;

create table if not exists account (
	id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	openid CHAR(32) NOT NULL,
	nick VARCHAR(128) NOT NULL default "*",
	unionid CHAR(32) NOT NULL default 0,
	session CHAR(64) NOT NULL,
	expires TIMESTAMP NOT NULL,
	PRIMARY KEY(id),
	UNIQUE KEY(openid)
);

