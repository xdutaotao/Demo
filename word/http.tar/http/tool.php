<?php

function log_print($txt)
{
	error_log($txt, 3, "/http/php.log");
}

function http_get($url)
{
	$headers = NULL;
	$body = NULL;
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL, $url);
	curl_setopt($curl, CURLOPT_HEADER, 1);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	$data = curl_exec($curl);
	$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
	if ($status == '200') {
		$header_size = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
		$headers = substr($data, 0, $header_size);
		$body = substr($data, $header_size);
	}
	curl_close($curl);
	return array($status, $headers, $body);
}

function mysql_querysafe($conn, $sql)
{
	$result = mysqli_query($conn, $sql);
	if (!$result)
		die("数据库查询失败" . $sql . ":" . mysqli_error($conn));
	return $result;
}

function mysql_start()
{
	$mysql_conn = new mysqli("localhost", "root", "root");
	if ($mysql_conn->connect_error) {
		die("连接失败: " . $mysql_conn->connect_error);
	}
	mysql_querysafe($mysql_conn, "set names utf8");
	return $mysql_conn;
}

function mysql_stop($conn)
{
	mysqli_close($conn);
}


?>
