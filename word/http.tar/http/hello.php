<?php

function hello_entry() {
	echo "hello\n";
}

?>
