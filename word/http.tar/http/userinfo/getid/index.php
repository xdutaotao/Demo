<?php

require_once "../../tool.php";

log_print("=========================++++++++++++++++++++++\n");
log_print(print_r($_GET,TRUE));

$appid = "wx738bb0a8533b90b3";
$secret = "63cf77f077dfcef07b70d82772e23972";

$url = sprintf('https://api.weixin.qq.com/sns/jscode2session?appid=%s&secret=%s&js_code=%s&grant_type=authorization_code', $appid, $secret, $_GET['code']);
$get = http_get($url);
if ($get[0] != 200) {
	http_response_code($get[0]);
	return ;
}

$headers = $get[1];
$body = $get[2];
$req = json_decode($body);

log_print(print_r($req,TRUE));

$uid = 0;
$openid = $req->openid;
$session_key = $req->session_key;
$expire = $req->expires_in;
$mysql = mysql_start();

$q_uid = sprintf("select id from rss.account where openid='%s';", $openid);
$ret = mysql_querysafe($mysql, $q_uid);
$row = mysqli_fetch_assoc($ret);
$t=time() + intval($expire);
if (!$row) {
	$q = sprintf("insert into rss.account (openid, session, expires) values ('%s','%s',from_unixtime('%s'));", $openid, $session_key, $t);
	mysql_querysafe($mysql, $q);
	$q = sprintf("select last_insert_id();");
	$ret = mysql_querysafe($mysql, $q);
	$row = mysqli_fetch_assoc($ret);
	$uid = $row['last_insert_id()'];
} else {
	$uid = $row['id'];
	$q = sprintf("update rss.account set session='%s',expires=from_unixtime('%s') where id='%s';", $session_key, $t, $uid);
	mysql_querysafe($mysql, $q);
}
mysql_stop($mysql);


$ack->uid = $uid;
$ack->openid = $openid;

echo json_encode($ack);

?>
