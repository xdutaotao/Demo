<?php
require_once "../../tool.php";

function decryptData($encryptedData, $iv, $sessionKey, &$data) {
	if (strlen($sessionKey) != 24) {
		return 1;
	}
	$aesKey=base64_decode($sessionKey);
	if (strlen($iv) != 24) {
		return 2;
	}
	$aesIV=base64_decode($iv);
	$aesCipher=base64_decode($encryptedData);
	$result=openssl_decrypt( $aesCipher, "AES-128-CBC", $aesKey, 1, $aesIV);
	$dataObj=json_decode( $result );
	if( $dataObj  == NULL ) {
		return 3;
	}
	$data = $dataObj;
	return 0;
}

log_print("=========================getinfo++++++++++++++++++++++\n");
log_print(print_r($_GET,TRUE));


$req = json_decode($_GET['param']);
$uid = $_GET['uid'];

$mysql = mysql_start();
$ret = mysql_querysafe($mysql, sprintf("select session from rss.account where id='%s'", $uid));
$row = mysqli_fetch_assoc($ret);
if (!$row) {
	http_response_code(400);
	die ("incorrect uid");
}

$dat = $req->encryptedData;
$iv = $req->iv;
$sessionKey = $row['session'];
decryptData($dat, $iv, $sessionKey, $out);

mysql_querysafe($mysql, sprintf("update rss.account set nick='%s' where id='%s'", $out->nickName, $uid));

mysql_stop($mysql);

$ack->$uid = $out->nickName;

echo json_encode($ack);

?>
