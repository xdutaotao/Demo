<?php

function world_entry() {
	echo "world\n";
}


?>
