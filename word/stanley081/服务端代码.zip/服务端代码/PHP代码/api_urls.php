<?php include("includes/header.php");

$file_path = 'http://'.$_SERVER['SERVER_NAME'] . dirname($_SERVER['REQUEST_URI']).'/';
?>
<div class="row">
      <div class="col-sm-12 col-xs-12">
     	 	<div class="card">
		        <div class="card-header">
		          示例 API url
		        </div>
       			    <div class="card-body no-padding">
         		
         			 <pre><code class="html"><b>最新音乐</b><br><?php echo $file_path."api.php?latest"?><br><br><b>分类列表</b><br><?php echo $file_path."api.php?cat_list"?><br><br><b>歌手列表</b><br><?php echo $file_path."api.php?artist_list"?><br><br><b>音乐列表ID</b><br><?php echo $file_path."api.php?cat_id=1"?><br><br><b>音乐列表歌手名称</b><br><?php echo $file_path."api.php?artist_name=Pritam"?><br><br><b>单曲</b><br><?php echo $file_path."api.php?mp3_id=4"?><br><br><b>App 详情</b><br><?php echo $file_path."api.php"?></code></pre>
       		
       				</div>
          	</div>
        </div>
</div>
    <br/>
    <div class="clearfix"></div>
        
<?php include("includes/footer.php");?>       
