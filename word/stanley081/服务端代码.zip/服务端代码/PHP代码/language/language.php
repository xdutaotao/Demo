<?php
	  $client_lang = array();
	  
	  $client_lang['1'] = "请输入用户名...";
	   
	  $client_lang['2'] ="请输入密码...";
  
	  $client_lang['3'] ="已发送信息.";
	   
	  $client_lang['4'] ="请输入正确的用户名或密码.";
	   
	  $client_lang['5'] ="没有发送..";
	   
	  $client_lang['6'] ="密码已发送你的电子邮件..";
	   
	  $client_lang['7'] ="电子邮件发送错误，请在试一次";
	   
	  $client_lang['8'] ="电子邮件地址不在我们数据库中..";
		
	  $client_lang['9'] = "请输入电子邮件地址..";


	  $client_lang['10'] = "添加成功...";

	  $client_lang['11'] = "更新成功...";

	  $client_lang['12'] = "删除成功...";

	  $client_lang['13'] = "启用成功...";

	  $client_lang['14'] = "禁用成功...";

	  $client_lang['15'] = "请选择壁纸图片...";


	   
	   
	  
?>
