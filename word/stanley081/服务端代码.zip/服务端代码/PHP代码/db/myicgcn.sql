-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 2017-07-11 22:40:50
-- 服务器版本： 5.6.35-log
-- PHP Version: 7.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myicgcn`
--

-- --------------------------------------------------------

--
-- 表的结构 `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `username`, `password`, `email`, `image`) VALUES
(1, 'admin', 'admin', '18481281315@163.com', 'profile.png');

-- --------------------------------------------------------

--
-- 表的结构 `tbl_artist`
--

CREATE TABLE `tbl_artist` (
  `id` int(11) NOT NULL,
  `artist_name` varchar(255) NOT NULL,
  `artist_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tbl_artist`
--

INSERT INTO `tbl_artist` (`id`, `artist_name`, `artist_image`) VALUES
(12, '朴树', '55401_1.png'),
(13, '庄心妍', '35824_1.png'),
(14, '汪峰', '87866_1.jpg'),
(15, '乔小刀', '27590_1.jpg'),
(16, '慕容晓晓', '81024_1.jpg'),
(17, '王绎龙', '59933_1.jpg'),
(18, '朗朗', '21984_1.jpg'),
(19, '侯旭', '13458_265991350.jpg'),
(20, '刘涛', '22412_1.jpg'),
(21, '周杰伦', '13071_1、.jpg'),
(22, '杨紫', '78251_1.jpg'),
(23, '古力娜扎', '63458_1.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `tbl_category`
--

CREATE TABLE `tbl_category` (
  `cid` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tbl_category`
--

INSERT INTO `tbl_category` (`cid`, `category_name`) VALUES
(8, '华语音乐'),
(9, '流行音乐'),
(10, '摇滚音乐'),
(11, '民歌民谣'),
(12, '电子音乐'),
(13, '原生大碟'),
(14, 'DJ舞曲');

-- --------------------------------------------------------

--
-- 表的结构 `tbl_mp3`
--

CREATE TABLE `tbl_mp3` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `mp3_type` varchar(255) NOT NULL,
  `mp3_title` varchar(100) NOT NULL,
  `mp3_url` text NOT NULL,
  `mp3_thumbnail` varchar(255) NOT NULL,
  `mp3_duration` varchar(255) NOT NULL,
  `mp3_artist` text NOT NULL,
  `mp3_description` text NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tbl_mp3`
--

INSERT INTO `tbl_mp3` (`id`, `cat_id`, `mp3_type`, `mp3_title`, `mp3_url`, `mp3_thumbnail`, `mp3_duration`, `mp3_artist`, `mp3_description`, `status`) VALUES
(15, 8, 'server_url', '平凡之路', 'http://osvpm3gw6.bkt.clouddn.com/%E6%9C%B4%E6%A0%91%20-%20%E5%B9%B3%E5%87%A1%E4%B9%8B%E8%B7%AF.mp3', '27774_1.jpg', '5:02', '朴树', '<p>徘徊着的 在路上的<br />\r\n你要走吗 via via<br />\r\n易碎的 骄傲着<br />\r\n那也曾是我的模样<br />\r\n沸腾着的 不安着的<br />\r\n你要去哪 via via<br />\r\n谜一样的 沉默着的<br />\r\n故事你真的在听吗<br />\r\n我曾经跨过山和大海<br />\r\n也穿过人山人海<br />\r\n我曾经拥有着一切<br />\r\n转眼都飘散如烟<br />\r\n我曾经失落失望失掉所有方向<br />\r\n直到看见平凡才是唯一的答案<br />\r\n当你仍然 还在幻想<br />\r\n你的明天 via via<br />\r\n她会好吗 还是更烂<br />\r\n对我而言是另一天<br />\r\n我曾经毁了我的一切<br />\r\n只想永远地离开<br />\r\n我曾经堕入无边黑暗<br />\r\n想挣扎无法自拔<br />\r\n我曾经像你像他像那野草野花<br />\r\n绝望着 也渴望着 也哭也笑平凡着<br />\r\n向前走 就这么走<br />\r\n就算你被给过什么<br />\r\n向前走 就这么走<br />\r\n就算你被夺走什么<br />\r\n向前走 就这么走<br />\r\n就算你会错过什么<br />\r\n向前走 就这么走<br />\r\n就算你会<br />\r\n我曾经跨过山和大海<br />\r\n也穿过人山人海<br />\r\n我曾经拥有着一切<br />\r\n转眼都飘散如烟<br />\r\n我曾经失落失望失掉所有方向<br />\r\n直到看见平凡才是唯一的答案<br />\r\n我曾经毁了我的一切<br />\r\n只想永远地离开<br />\r\n我曾经堕入无边黑暗<br />\r\n想挣扎无法自拔<br />\r\n我曾经像你像他像那野草野花<br />\r\n绝望着 也渴望着 也哭也笑平凡着<br />\r\n我曾经跨过山和大海<br />\r\n也穿过人山人海<br />\r\n我曾经问遍整个世界<br />\r\n从来没得到答案<br />\r\n我不过像你像他像那野草野花<br />\r\n冥冥中这是我 唯一要走的路啊<br />\r\n时间无言 如此这般<br />\r\n明天已在 hia hia<br />\r\n风吹过的 路依然远<br />\r\n你的故事讲到了哪</p>\r\n', 1),
(16, 8, 'server_url', '那些花儿', 'http://osvpm3gw6.bkt.clouddn.com/%E6%9C%B4%E6%A0%91%20-%20%E9%82%A3%E4%BA%9B%E8%8A%B1%E5%84%BF.mp3', '57232_1.jpeg', '4:54', '朴树', '<p>那片笑声让我想起我的那些花儿<br />\r\n在我生命每个角落静静为我开着<br />\r\n我曾以为我会永远守在她身旁<br />\r\n今天我们已经离去在人海茫茫<br />\r\n她们都老了吧 她们在哪里呀<br />\r\n幸运的是我曾陪她们开放<br />\r\n啦&hellip;&hellip; 想她<br />\r\n啦&hellip;&hellip; 她还在开吗<br />\r\n啦&hellip;&hellip; 去呀<br />\r\n她们已经被风吹走散落在天涯<br />\r\n（朴树哼唱）<br />\r\n有些故事还没讲完那就算了吧<br />\r\n那些心情在岁月中已经难辨真假<br />\r\n如今这里荒草丛生没有了鲜花<br />\r\n好在曾经拥有你们的春秋和冬夏<br />\r\n她们都老了吧 她们在哪里呀<br />\r\n幸运的是我曾陪她们开放<br />\r\n啦&hellip;&hellip; 想她<br />\r\n啦&hellip;&hellip; 她还在开吗<br />\r\n啦&hellip;&hellip; 去呀<br />\r\n她们已经被风带走散落在天涯<br />\r\n啦&hellip;&hellip; （朴树哼唱）<br />\r\n啦&hellip;&hellip; （朴树哼唱）<br />\r\n啦&hellip;&hellip; （朴树哼唱）<br />\r\n（朴树哼唱）<br />\r\n你们就像被风吹走插在了天涯<br />\r\n她们都老了吧 她们还在开吗<br />\r\n我们就这样各自奔天涯</p>\r\n', 1),
(17, 8, 'server_url', '白桦林', 'http://osvpm3gw6.bkt.clouddn.com/%E6%9C%B4%E6%A0%91%20-%20%E7%99%BD%E6%A1%A6%E6%9E%97.mp3', '67788_1.jpg', '4:08', '朴树', '<p>静静的村庄飘着白的雪<br />\r\n阴霾的天空下鸽子飞翔<br />\r\n白桦树刻着那两个名字<br />\r\n他们发誓相爱用尽这一生<br />\r\n有一天战火烧到了家乡<br />\r\n小伙子拿起枪奔赴边疆<br />\r\n心上人你不要为我担心<br />\r\n等着我回来在那片白桦林<br />\r\n天空依然阴霾依然有鸽子在飞翔<br />\r\n谁来证明那些没有墓碑的爱情和生命<br />\r\n雪依然在下那村庄依然安详<br />\r\n年轻的人们消逝在白桦林<br />\r\n噩耗声传来在那个午后<br />\r\n心上人战死在远方沙场<br />\r\n她默默来到那片白桦林<br />\r\n朴树《白桦林》<br />\r\n朴树《白桦林》<br />\r\n望眼欲穿地每天守在那里<br />\r\n她说他只是迷失在远方<br />\r\n他一定会来来这片白桦林<br />\r\n天空依然阴霾依然有鸽子在飞翔<br />\r\n谁来证明那些没有墓碑的爱情和生命<br />\r\n雪依然在下那村庄依然安详<br />\r\n年轻的人们消逝在白桦林<br />\r\n长长的路呀就要到尽头<br />\r\n那姑娘已经是白发苍苍<br />\r\n她时常听他在枕边呼唤<br />\r\n&quot;来吧亲爱的来这片白桦林&quot;<br />\r\n在死的时候她喃喃地说<br />\r\n&quot;我来了等着我在那片白桦林&quot;</p>\r\n', 1),
(18, 8, 'server_url', '逃', 'http://osvpm3gw6.bkt.clouddn.com/%E4%BE%AF%E6%97%AD%20-%20%E9%80%83.mp3', '75409_c999ad7d15e4991bc300217dc65c0c9b.png', '3:58', '侯旭', '<p>这个深夜有谁陪我买醉<br />\r\n尝下这杯孤独我会想谁<br />\r\n我才知道我回忆的回忆的<br />\r\n回忆的全是你<br />\r\n只剩下我自己 狼狈<br />\r\n记不清这是第几夜不归<br />\r\n残留的几分真情我会给谁<br />\r\n我才知道我想念的想念的<br />\r\n想念的全是你<br />\r\n却留下我自己 心碎<br />\r\n我好想逃 却逃不掉<br />\r\n放弃你是最痛苦的煎熬<br />\r\n我好想逃 却逃不掉<br />\r\n想抱着你 哪怕只有一秒<br />\r\n记不清这是第几夜不归<br />\r\n残留的几分真情我会给谁<br />\r\n我才知道我想念的想念的<br />\r\n想念的全是你<br />\r\n却留下我自己 心碎<br />\r\n我好想逃 却逃不掉<br />\r\n放弃你是最痛苦的煎熬<br />\r\n我好想逃 却逃不掉<br />\r\n想抱着你 哪怕只有一秒<br />\r\n我好想逃 却逃不掉<br />\r\n放弃你是最痛苦的煎熬<br />\r\n我好想逃 却逃不掉<br />\r\n想抱着你 哪怕只有一秒<br />\r\n我好想逃 却逃不掉<br />\r\n放弃你是最痛苦的煎熬<br />\r\n我好想逃 却逃不掉<br />\r\n想抱着你 哪怕只有一秒</p>\r\n', 1),
(19, 8, 'server_url', '走着走着就散了', 'http://osvpm3gw6.bkt.clouddn.com/%E5%BA%84%E5%BF%83%E5%A6%8D%20-%20%E8%B5%B0%E7%9D%80%E8%B5%B0%E7%9D%80%E5%B0%B1%E6%95%A3%E4%BA%86%20.mp3', '62461_1.jpg', '4:28', '庄心妍', '<p>习惯人群中找你的影子 回想那些幸福的日子<br />\r\n但其实我明白 我和从前的我<br />\r\n已经分开很远很远<br />\r\n寂寞世界中的两颗心 寂寞城市中的每个人<br />\r\n我们相遇相拥 相互猜测怀疑<br />\r\n一边微笑一边流泪<br />\r\n那些激情后的陌生 被利用的信任<br />\r\n累觉不爱的心 任性错过的人<br />\r\n伤痕累累才懂 认真我就输了<br />\r\n有些人走着走着就散了<br />\r\n有些事看着看着就淡了<br />\r\n有多少无人能懂的不快乐<br />\r\n就有多少无能为力的不舍<br />\r\n有些人想着想着就忘了<br />\r\n有些梦做着做着就醒了<br />\r\n才发现从前是我太天真<br />\r\n现实又那么残忍<br />\r\n寂寞世界中的两颗心 寂寞城市中的每个人<br />\r\n我们相遇相拥 相互猜测怀疑<br />\r\n一边微笑一边流泪<br />\r\n那些激情后的陌生 被利用的信任<br />\r\n累觉不爱的心 任性错过的人<br />\r\n伤痕累累才懂 认真我就输了<br />\r\n有些人走着走着就散了<br />\r\n有些事看着看着就淡了<br />\r\n有多少无人能懂的不快乐<br />\r\n就有多少无能为力的不舍<br />\r\n有些人想着想着就忘了<br />\r\n有些梦做着做着就醒了<br />\r\n才发现从前是我太天真<br />\r\n现实又那么残忍<br />\r\n有些人想着想着就忘了<br />\r\n有些梦做着做着就醒了<br />\r\n才发现从前是我太天真<br />\r\n现实却那么残忍</p>\r\n', 1),
(20, 8, 'server_url', '以后的以后', 'http://osvpm3gw6.bkt.clouddn.com/%E5%BA%84%E5%BF%83%E5%A6%8D%20-%20%E4%BB%A5%E5%90%8E%E7%9A%84%E4%BB%A5%E5%90%8E.mp3', '75870_1.jpg', '5:00', '庄心妍', '<p>风决定要走 云怎么挽留<br />\r\n曾经抵死纠缠放空的手<br />\r\n情缘似流水 覆水总难收<br />\r\n我还站在你离开 离开的路口<br />\r\n你既然无心 我也该放手<br />\r\n何必痴痴傻傻纠缠不休<br />\r\n是情深缘浅 留一生遗憾<br />\r\n还是情浅缘深 一辈子怨偶<br />\r\n没有我以后 一个人少喝点酒<br />\r\n窗台外的衣服有没有人来收<br />\r\n以后的以后 你是谁的某某某<br />\r\n若是再见 只会让人更难受<br />\r\n没有你以后 一个人四处旅游<br />\r\n在某时某地交上三两个朋友<br />\r\n以后的以后 我牵着别人衣袖<br />\r\n若是有缘再见 也要学会笑着问候<br />\r\n你既然无心 我也该放手<br />\r\n何必痴痴傻傻纠缠不休<br />\r\n是情深缘浅 留一生遗憾<br />\r\n还是情浅缘深 一辈子怨偶<br />\r\n没有我以后 一个人少喝点酒</p>\r\n\r\n<p>窗台外的衣服有没有人来收<br />\r\n以后的以后 你是谁的某某某<br />\r\n若是再见 只会让人更难受<br />\r\n没有你以后 一个人四处旅游<br />\r\n在某时某地交上三两个朋友<br />\r\n以后的以后 我牵着别人衣袖<br />\r\n若是有缘再见 也要学会笑着问候<br />\r\n若是有缘再见 也要学会笑着问候</p>\r\n', 1),
(21, 8, 'server_url', '怒放的生命 ', 'http://osvpm3gw6.bkt.clouddn.com/%E6%B1%AA%E5%B3%B0%20-%20%E6%80%92%E6%94%BE%E7%9A%84%E7%94%9F%E5%91%BD.mp3', '30869_1.jpg', '4:35', '汪峰', '<p>曾经多少次跌倒在路上<br />\r\n曾经多少次折断过翅膀<br />\r\n如今我已不再感到彷徨<br />\r\n我想超越这平凡的奢望<br />\r\n我想要怒放的生命<br />\r\n就像飞翔在辽阔天空<br />\r\n就像穿行在无边的旷野<br />\r\n拥有挣脱一切的力量<br />\r\n曾经多少次失去了方向<br />\r\n曾经多少次破灭了梦想<br />\r\n如今我已不再感到迷茫<br />\r\n我要我的生命得到解放<br />\r\n我想要怒放的生命<br />\r\n就像飞翔在辽阔天空<br />\r\n就像穿行在无边的旷野<br />\r\n拥有挣脱一切的力量<br />\r\n我想要怒放的生命<br />\r\n就像矗立在彩虹之巅<br />\r\n就像穿行在璀璨的星河<br />\r\n拥有超越平凡的力量<br />\r\n曾经多少次失去了方向<br />\r\n曾经多少次破灭了梦想<br />\r\n如今我已不再感到迷茫<br />\r\n我要我的生命得到解放<br />\r\n我想要怒放的生命<br />\r\n就像飞翔在辽阔天空<br />\r\n就像穿行在无边的旷野<br />\r\n拥有挣脱一切的力量<br />\r\n我想要怒放的生命<br />\r\n就像矗立在彩虹之巅<br />\r\n就像穿行在璀璨的星河<br />\r\n拥有超越平凡的力量<br />\r\n我想要怒放的生命<br />\r\n就像飞翔在辽阔天空<br />\r\n就像穿行在无边的旷野<br />\r\n拥有挣脱一切的力量<br />\r\n我想要怒放的生命<br />\r\n就像矗立在彩虹之巅<br />\r\n就像穿行在璀璨的星河<br />\r\n拥有超越平凡的力量</p>\r\n', 1),
(22, 8, 'server_url', 'Jar Of Love', 'http://osvpm3gw6.bkt.clouddn.com/jaroflove.mp3', '66309_1.jpg', '1:01', '古力娜扎', '<p>Soon it&#39;ll all be yesterday<br />\r\n转瞬间都将变为昨天<br />\r\nAnother good day, another bad day,<br />\r\n美好的一天，糟糕的一天<br />\r\nWhat did you do today?<br />\r\n你又是如何看待今天天<br />\r\nWhy do we choose to chase what we&#39;ll lose?<br />\r\n为什么我们不断苛求一些我们终将失去的东西<br />\r\nWhat you want isn&#39;t what you have.<br />\r\n你所有拥有的未必是你所想要的<br />\r\nWhat you have may not be yours, to keep.<br />\r\n一些你已拥有的也许不属于你的<br />\r\nIf I could find love, at a stop, in a park with open arms,<br />\r\n如果我能在一个车站，亦或在一座公园张开双臂发现真爱<br />\r\nI would save all my love, in a jar,<br />\r\n我会将我所有的爱<br />\r\nmade of sparks, sealed in my beating heart,<br />\r\n存在这个蜜罐，然后封印在我跳动的心里<br />\r\nCould it be yours to keep, the Jar of Love.<br />\r\n你j会珍藏这满载着爱的蜜罐里吗<br />\r\nAnother left turn, another head turns<br />\r\n下一个左转，下一个路口<br />\r\nCould he be someone I deserve?<br />\r\n他会是我的真命天子吗<br />\r\nAnother right turn, another lesson learned<br />\r\n下一个右转，又一次教训<br />\r\nNever leave an open flame to burn<br />\r\n不要放任这热情的火燃烧<br />\r\nWhy do we choose to chase what we&#39;ll lose?<br />\r\n为什么我们不断苛求一些我们终将失去的东西<br />\r\nWhat you want isn&#39;t what you have.<br />\r\n你所有拥有的未必是你所想要的<br />\r\nWhat you have may not be yours, to keep.<br />\r\n一些你已拥有的也许不属于你的<br />\r\nIf I could find love,<br />\r\n如果我能找到真爱<br />\r\nat a stop, in a park with open arms,<br />\r\n在一家车站，亦或在一座公园张开双臂<br />\r\nI would save all my love,<br />\r\n我会将我所有的爱<br />\r\nin a jar,made of sparks,<br />\r\n存进这个满载甜蜜的罐子里<br />\r\nsealed in my beating heart,<br />\r\n然后封印在我的跳动的心里<br />\r\nCould it be yours to keep, the Jar of Love.<br />\r\n你会珍藏这满载着爱的蜜罐吗<br />\r\nCould you be my love<br />\r\n你会是我的真爱吗<br />\r\nCould you be my love<br />\r\n你会是我的真爱吗<br />\r\nCould you be my love<br />\r\n你会是我的真爱吗<br />\r\nCould you be my love<br />\r\n你会是我的真爱吗<br />\r\nCould you be her love<br />\r\n你会是她的真爱吗<br />\r\nCould you be he love<br />\r\n你会是他的真爱吗<br />\r\nCould you be my love<br />\r\n你会是我的真爱吗<br />\r\nCould I be you love<br />\r\n我能成为你的真爱吗<br />\r\nIf I could find love,<br />\r\n如果我能找到真爱<br />\r\nat a stop, in a park with open arms,<br />\r\n在一家车站，亦或在一座公园张开双臂<br />\r\nI would save all my love,<br />\r\n我会珍藏我全部的爱<br />\r\nin a jar,made of sparks,<br />\r\n存进这个满载甜蜜的罐子里<br />\r\nsealed in my beating heart,<br />\r\n然后封印在我的跳动的心里<br />\r\nCould it be yours to keep<br />\r\n你会珍藏这满载着爱的蜜罐吗<br />\r\nIf I could find love,<br />\r\n如果我能找到真爱<br />\r\nat a stop, in a park with open arms,<br />\r\n在一家车站，亦或在一座公园张开双臂<br />\r\nI would save all my love,<br />\r\n我会珍藏我全部的爱<br />\r\nin a jar,made of sparks,<br />\r\n存进这个满载甜蜜的罐子里<br />\r\nsealed in my beating heart,<br />\r\n然后封印在我的跳动的心里<br />\r\nCould it be yours to keep<br />\r\n你会珍藏这满载着爱的蜜罐吗<br />\r\nIf I could find love,<br />\r\n如果我能找到真爱<br />\r\nat a stop, in a park with open arms,<br />\r\n在一家车站，亦或在一座公园张开双臂<br />\r\nI would save all my love,<br />\r\n我会珍藏我全部的爱<br />\r\nin a jar,made of sparks,<br />\r\n存进这个满载甜蜜的罐子里<br />\r\nsealed in my beating heart,<br />\r\n然后封印在我的跳动的心里<br />\r\nCould it be yours to keep<br />\r\n你会珍藏这满载着爱的蜜罐吗<br />\r\nthe Jar of Love.<br />\r\n这罐蜜罐里的爱<br />\r\nCould it be yours to keep<br />\r\n你会珍藏它吗<br />\r\nthe Jar of Love.<br />\r\n这罐蜜罐里的爱<br />\r\nCould it be yours to keep<br />\r\n你会珍藏它吗<br />\r\nthe Jar of Love.<br />\r\n蜜罐里的爱</p>\r\n', 1);

-- --------------------------------------------------------

--
-- 表的结构 `tbl_settings`
--

CREATE TABLE `tbl_settings` (
  `id` int(11) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `app_logo` varchar(255) NOT NULL,
  `app_email` varchar(255) NOT NULL,
  `app_version` varchar(255) NOT NULL,
  `app_author` varchar(255) NOT NULL,
  `app_contact` varchar(255) NOT NULL,
  `app_website` varchar(255) NOT NULL,
  `app_description` text NOT NULL,
  `app_developed_by` varchar(255) NOT NULL,
  `app_privacy_policy` text NOT NULL,
  `api_all_order_by` varchar(255) NOT NULL,
  `api_latest_limit` int(3) NOT NULL,
  `api_cat_order_by` varchar(255) NOT NULL,
  `api_cat_post_order_by` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tbl_settings`
--

INSERT INTO `tbl_settings` (`id`, `app_name`, `app_logo`, `app_email`, `app_version`, `app_author`, `app_contact`, `app_website`, `app_description`, `app_developed_by`, `app_privacy_policy`, `api_all_order_by`, `api_latest_limit`, `api_cat_order_by`, `api_cat_post_order_by`) VALUES
(1, '柠檬音乐', 'loog.png', '18581281315@163.com', '1.0.0', '淘宝互联网那点事', '18581281315 ', 'https://shop103571392.taobao.com/', '<p><strong>柠檬云音乐</strong>是一款由柠檬开发的音乐产品，依托专业音乐人、DJ、好友推荐及社交功能，在线音乐服务主打歌单、社交、大牌推荐和音乐指纹，以歌单、DJ节目、社交、地理位置为核心要素，主打发现和分享。</p>\r\n', '互联网那点事', '<p><strong>欢迎使用柠檬公司为您提供的柠檬云音乐软件或服务。</strong></p>\r\n\r\n<p>请您（下列简称为&ldquo;用户&rdquo;）仔细阅读以下全部内容（特别是粗体下划线标注的内容）。未成年人则应在法定监护人陪同下阅读。如用户使用柠檬云音乐软件或服务，即表示用户与柠檬公司已达成协议，自愿接受本服务条款所有内容。此后，用户不得以未阅读本服务条款内容作任何形式的抗辩。</p>\r\n\r\n<p><strong>1、服务条款的确认和接纳</strong></p>\r\n\r\n<p>本条款是用户与柠檬公司之间关于用户使用柠檬云音乐软件或服务的条款，内容包括条款正文、柠檬公司已经发布的或将来可能发布的各类规则。所有规则为本条款不可分割的组成部分，与条款正文具有同等法律效力。除另行明确声明外，用户使用柠檬云音乐软件或服务的行为将受本条款约束。</p>\r\n\r\n<p>本条款如由于柠檬云音乐发展需要进行修订的，柠檬公司将在柠檬云音乐平台公布。您可前往查阅最新版协议条款。在柠檬公司修改上述条款后，如果您不接受修改后的条款，您可以选择终止使用柠檬云音乐软件或服务。您继续使用的，将被视为已接受了修改后的条款。</p>\r\n\r\n<p><strong>2、柠檬云音乐简介</strong></p>\r\n\r\n<p>本服务条款所称的&ldquo;柠檬云音乐&rdquo;是指柠檬公司所有和经营的专注于发现与分享的音乐产品，依托专业音乐人、DJ、好友推荐及社交功能，为用户打造全新的音乐生活服务。</p>\r\n\r\n<p>用户通过柠檬云音乐可享受柠檬云音乐上的音乐、DJ节目,并可在登录后享受更为完整的服务如创建更多歌单、发表评论、分享音乐等。用户登录帐号可以是用户本人的手机号、柠檬邮箱帐号或柠檬云音乐增加的其他可登录帐号。用户应维持密码及帐号的机密安全，如果用户未保管好自己的帐号和密码而对用户、柠檬公司或第三方造成损害，用户将负全部责任。用户同意若发现任何非法使用用户帐号或安全漏洞的情况，有义务立即通告柠檬公司。</p>\r\n\r\n<p>用户在使用柠檬云音乐服务时填写、登录、使用的帐号名称、头像、个人简介等帐号信息资料应遵守法律法规、社会主义制度、国家利益、公民合法权益、公共秩序、社会道德风尚和信息真实性等七条底线，不得在帐号信息资料中出现违法和不良信息，且用户保证在填写、登录、使用帐号信息资料时，不得有以下情形：<br />\r\n1）违反宪法或法律法规规定的；</p>\r\n\r\n<p>（2）危害国家安全，泄露国家秘密，颠覆国家政权，破坏国家统一的；</p>\r\n\r\n<p>（3）损害国家荣誉和利益的，损害公共利益的；</p>\r\n\r\n<p>（4）煽动民族仇恨、民族歧视，破坏民族团结的；</p>\r\n\r\n<p>（5）破坏国家宗教政策，宣扬邪教和封建迷信的；</p>\r\n\r\n<p>（6）散布谣言，扰乱社会秩序，破坏社会稳定的；</p>\r\n\r\n<p>（7）散布淫秽、色情、赌博、暴力、凶杀、恐怖或者教唆犯罪的；</p>\r\n\r\n<p>（8）侮辱或者诽谤他人，侵害他人合法权益的；</p>\r\n\r\n<p>（9）含有法律、行政法规禁止的其他内容的。</p>\r\n', 'ASC', 15, 'cid', 'DESC');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_artist`
--
ALTER TABLE `tbl_artist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `tbl_mp3`
--
ALTER TABLE `tbl_mp3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_settings`
--
ALTER TABLE `tbl_settings`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- 使用表AUTO_INCREMENT `tbl_artist`
--
ALTER TABLE `tbl_artist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- 使用表AUTO_INCREMENT `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- 使用表AUTO_INCREMENT `tbl_mp3`
--
ALTER TABLE `tbl_mp3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- 使用表AUTO_INCREMENT `tbl_settings`
--
ALTER TABLE `tbl_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
