Amazon SNS Mobile Push Kindle Mobile Push App

----------------------------------------------------


This sample creates an app to display messages from SNS Mobile Push services.



To use this sample:

1- Make sure you have the latest android sdk, found here http://developer.android.com/sdk/index.html
 
as well as the the amazon device messaging sdk, found here https://developer.amazon.com/sdk/adm.html .

2- Follow the instructions found at http://docs.aws.amazon.com/sns/latest/dg/mobile-push-adm.html .



For more information about Amazon SNS Mobile Push, please see docs.aws.amazon.com/sns/latest/dg/SNSMobilePush.html
 .
For licensing information about this sample, please see the included LICENSE.txt.