Amazon SNS Mobile Push Apple Mobile Push App
----------------------------------------------------

This sample creates an app to display messages from SNS Mobile Push services.

To use this sample follow the instructions found at http://docs.aws.amazon.com/sns/latest/dg/mobile-push-apns.html .

For more information about Amazon SNS Mobile Push, please see docs.aws.amazon.com/sns/latest/dg/SNSMobilePush.html
For licensing information about this sample, please see the included LICENSE.txt.