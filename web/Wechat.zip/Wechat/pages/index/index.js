//index.js
//获取应用实例

Page({
  data: {
  },

  onShow: function(){
    wx.navigateTo({
      url: '../firstPage/firstPage'
    })
  },

  onLoad: function () {
    
  },


})
