package cn.bluemobi.dylan.step.step.accelerometer;

/**
 * Created by dylan on 16/9/27.
 */
public interface StepValuePassListener {
    void stepChanged(int steps);
}
