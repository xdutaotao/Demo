package cn.bluemobi.dylan.step.app;

import android.app.Application;

/**
 * Created by yuandl on 2016-10-18.
 */

public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
