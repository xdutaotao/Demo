package shcem.member.service.model;

import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * 客户信息维护DTO
 * @author wangshuai
 *
 */
public class CusInfoMaintainDto extends BaseObject implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6564533129321304709L;
	private String userCode;
    private String userName;
    private String mobile;
    // 注册时间
    private Date createTime;
    private Integer userStatus;
    // 最后维护时间
    private Date lastMaintainTime;
    private Integer maintainStatus;
    private String cusUserId;
    // 客服名称
    private String cusUserName;
    
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Integer getUserStatus() {
		return userStatus;
	}
	public void setUserStatus(Integer userStatus) {
		this.userStatus = userStatus;
	}
	public Date getLastMaintainTime() {
		return lastMaintainTime;
	}
	public void setLastMaintainTime(Date lastMaintainTime) {
		this.lastMaintainTime = lastMaintainTime;
	}
	public Integer getMaintainStatus() {
		return maintainStatus;
	}
	public void setMaintainStatus(Integer maintainStatus) {
		this.maintainStatus = maintainStatus;
	}
	public String getCusUserId() {
		return cusUserId;
	}
	public void setCusUserId(String cusUserId) {
		this.cusUserId = cusUserId;
	}
	public String getCusUserName() {
		return cusUserName;
	}
	public void setCusUserName(String cusUserName) {
		this.cusUserName = cusUserName;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
    
}
