/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: TraderDAO.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.dao;

import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.member.dao.model.TradeAllData;
import shcem.member.dao.model.Trader;
import shcem.member.dao.model.TraderDataList;
import shcem.member.dao.model.TraderTmptRlsp;
import shcem.member.dao.model.User;
import shcem.member.service.model.userMobileModel;

/**
 * @author wlpod
 *
 */
public abstract interface TraderDAO extends DAO {
	/**
	 * 获取交易员列表
	 * @param qc
	 * @param pageInfo
	 * @param firmID 
	 * @return
	 */
	public abstract List<TraderDataList> getTraderList(QueryConditions qc, PageInfo pageInfo, String firmID);
	/**
	 * 获取交易员详情
	 * @param traderID
	 * @return
	 */
	public abstract TradeAllData getTrader(String traderID);
	/**
	 * 新增交易员编码
	 * @param trader
	 * @return
	 */
	public abstract Integer addTrader(Trader trader);
	/**
	 * 更新交易员信息
	 * @param trader
	 * @return
	 */
	public abstract int updateTrader(Trader trader);
	/**
	 * 禁用交易员
	 * @param traderID
	 * @return
	 */
	public abstract int disableTrader(String traderID);
	/**
	 * 启用交易员
	 * @param traderID
	 * @return
	 */
	public abstract int enableTrader(String traderID);
	
	/**
	 * 用户编码是否已经存在
	 * @param userCode
	 * @return
	 */
	public abstract boolean checkUserIDExisted(String userCode);
	/**
	 * 查询用户
	 * @param userCode
	 * @return
	 */
	public abstract User getUserById(String userCode);
	/**解绑
	 * @param tradeID
	 * @return
	 */
	public abstract int Unbundling(String tradeID);
	public abstract List<User> getUserByMobile(String mobile);
	/**交易员交易场权限
	 * @param traderID
	 * @return
	 */
	public abstract List<TraderTmptRlsp> getTraderTmptRlspList(String traderID);
	/**交易员增加交易场权限
	 * @param traderTmptRlsp
	 */
	public abstract void addTraderTmptRlsps(TraderTmptRlsp traderTmptRlsp);
	public abstract void delTraderTmptRlsps(String traderID);
	public abstract List<Trader> getTraderByUserCode(String userCode);
	public abstract int bindUser(TradeAllData traders, User user);
	public abstract void rollBack();
	public abstract int chgUserType(Integer userType,String userCode);
	public abstract List<Trader> getTraderListByFirmID(String firmID);
	/**
	 * 交易商的交易场权限发生变化应该同步影响交易员的权限
	 * @param traderID
	 * @param firmTmptRlspString
	 */
	public abstract void updateTraderTmptRlsps(String traderID,
			String firmTmptRlspString);
	/**
	 * 禁用用户的同时，起绑定的交易员userCode置null
	 * @param userCode
	 * @return
	 */
	public abstract void updateTraderByUserCode(String userCode);
	
	/**
	 * 更新交易员的状态（即冻结交易员）
	 */
	public abstract int updateTraderStatusByTraderID(Trader trader,String exeUsername);
	
	/**
	 * 获取交易员列表
	 * @param qc
	 * @param pageInfo
	 * @param firmID 
	 * @return
	 */
	public abstract List<TraderDataList> getTraderList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 获取用户手机关联列表
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<userMobileModel> queryUserMobileList(
			QueryConditions qc, PageInfo pageInfo,String userCode);
	
	/**
	 * 获取用户手机号总数（不超过20条）
	 * @param userCode
	 * @return
	 */
	public abstract int getMobileCount(String userCode);
	
	/**
	 * 新增用户手机
	 * @param moreMobile
	 * @param userCode
	 * @param userName
	 * @return
	 */
	public abstract int addUserMobile(String moreMobile, String userCode,
			String userName);
	
	/**
	 * 修改用户手机
	 * @param id
	 * @param moreMobile
	 * @param userName
	 * @return
	 */
	public abstract int changeUserMobile(int id, String moreMobile,
			String userName);
	
	/**
	 * 解绑用户手机
	 * @param id
	 * @return
	 */
	public abstract int unBindUserMobile(int id);
	
	/**
	 * 校验是否有重复手机号
	 * @param moreMobile
	 * @return
	 */
	public abstract int getSameMobile(String moreMobile, String userCode);
	
	
}
