package shcem.member.dao.model;

import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * (C_USER)
 * 
 * @author bianj
 * @version 1.0.0 2016-05-24
 */
public class User extends BaseObject implements java.io.Serializable {
    /** 版本号 */
    private static final long serialVersionUID = -1247818810436086328L;
    
    /**  */
    private String userCode;
    
    /**  */
    private String userName;
    
    /**  */
    private String userPassword;
    
    /**  */
    private String mobile;
    
    /** 默认为 0：正常，1：失效 */
    private Integer disabled;
    
    /** 类型 0:浏览用户,1:交易员用户 */
    private Integer userType;
    
    /**  */
    private Date lastLoginTime;
    
    /**  */
    private String recCreateBy;
    
    /**  */
    private Date recCreateTime;
    
    /**  */
    private String recModifyBy;
    
    /**  */
    private Date recModifyTime;
    
    /**
     * 秘钥
     * @return
     */
    private String salt;

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public Integer getUserType() {
		return userType;
	}

	public void setUserType(Integer userType) {
		this.userType = userType;
	}

	public Date getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(Date lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public String getRecCreateBy() {
		return recCreateBy;
	}

	public void setRecCreateBy(String recCreateBy) {
		this.recCreateBy = recCreateBy;
	}

	public Date getRecCreateTime() {
		return recCreateTime;
	}

	public void setRecCreateTime(Date recCreateTime) {
		this.recCreateTime = recCreateTime;
	}

	public String getRecModifyBy() {
		return recModifyBy;
	}

	public void setRecModifyBy(String recModifyBy) {
		this.recModifyBy = recModifyBy;
	}

	public Date getRecModifyTime() {
		return recModifyTime;
	}

	public void setRecModifyTime(Date recModifyTime) {
		this.recModifyTime = recModifyTime;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getSalt() {
		return salt;
	}

	public void setSalt(String salt) {
		this.salt = salt;
	}
}