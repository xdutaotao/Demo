/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IUserService.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.service;

/**
 * @author wlpod
 *
 */
public interface IUserService {
	/**
	 * 获取用户列表
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public String getUserList(String params);

	/**
	 * 获取用户详情
	 * 
	 * @param userCode
	 * @return
	 */
	public String getUser(String params);

	/**
	 * 禁用用户
	 * 
	 * @param userCode
	 * @return
	 */
	public String disableUser(String params);

	/**
	 * 启用用户
	 * 
	 * @param userCode
	 * @return
	 */
	public String enableUser(String params);
	
	/**
	 * 新增用户
	 * 
	 * @param userCode
	 * @return
	 */
	public String addUser(String params);
	

	/**
	 * 查询 客户信息维护 列表
	 * @return
	 */
	public String getCustomerMaintainInfoList(String params);
	
	/**
	 * 根据客户Code 查询 客户信息维护
	 * @return
	 */
	public String getCustomerMaintainInfoByUserCode(String params);
	
	
	/**
	 * 更新  客户信息维护
	 * @return
	 */
	public String updateCusInfoMaintain(String params);
	
	/**
	 * 配置客服
	 * @param params
	 * @return
	 */
	public String configurationCusInfo(String params);
	/**
	 * 根据userCode 获取 客服配置信息
	 * @param params
	 * @return
	 */
	public String getCusInfoCSCfgByUserCode(String params);
	
	
	/**
	 * 根据ID 解冻用户
	 * @param params
	 * @return
	 */
	public String thawUserErrorPswById(String params);

	/**
	 * 获取用户openid
	 *
	 * @param code
	 * @return openid
	 */
	public String getUserOpenId(String params);
	
	/**
	 * 添加用户和微信账号关联关系
	 * 
	 */
	public String addUserWeiXinRelation(String params);
	

	/**
	 * 判断微信和用户是否绑定
	 * 
	 * @param code
	 */
	public String isBindWeinXin(String params);
	
	/**
	 * 通过OpenId拿到 支付所要参数
	 * @param params
	 * @return
	 */
	public String getBrandWCPayRequestParams(String params);
	
	/**
	 * 拿到微信支付 JSAPI 所要的签名
	 * @param params
	 * @return
	 */
	public String getJsSignature(String params);

}
