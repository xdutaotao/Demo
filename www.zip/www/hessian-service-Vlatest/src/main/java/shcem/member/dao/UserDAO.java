/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: UserDAO.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.dao;

import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.member.dao.model.CusInfoCscfg;
import shcem.member.dao.model.User;
import shcem.member.dao.model.UserAllData;
import shcem.member.dao.model.UserDataList;
import shcem.member.service.model.CusInfoMaintainDto;
import shcem.member.service.model.CusInfoMaintainModel;

/**
 * @author wlpod
 *
 */
public abstract interface UserDAO extends DAO {
	/**
	 * 获取用户列表
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */	
	public abstract List<UserDataList> getUserList(QueryConditions qc, PageInfo pageInfo);
	/**
	 * 获取用户详情
	 * @param userCode
	 * @return
	 */
	public abstract UserAllData getUser(String userCode);

	/**
	 * 禁用用户
	 * 
	 * @param userCode
	 * @return
	 */
	public abstract int disableUser(String userCode);

	/**
	 * 启用用户
	 * 
	 * @param userCode
	 * @return
	 */
	public abstract int enableUser(String userCode);
	
	/**
	 * 新增用户
	 * 
	 * @param userCode
	 * @return
	 */
	public abstract void addUser(User user);
	
	
	/**
	 * 查询 客户信息维护 列表
	 * 
	 * @param userCode
	 * @return
	 */
	public abstract List<CusInfoMaintainDto> selectCUserList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 根据 客户Code 查询 客户信息维护 
	 * 
	 * @param userCode
	 * @return
	 */
	public abstract CusInfoMaintainModel selectCusInfoMaintainByUserCode(String userCode);
	
	/**
	 * 插入 客户信息维护 
	 * 
	 * @param userCode
	 * @return
	 */
	public abstract void insertCusInfoMaintain(CusInfoMaintainModel model);
	
	/**
	 * 更新 客户信息维护 
	 * 
	 * @param userCode
	 * @return
	 */
	public abstract void updateCusInfoMaintain(CusInfoMaintainModel model);
	
	/**
	 * 根据 userCode 统计 客户信息维护 表中 存在 userCode 的个数
	 * 
	 * @param userCode
	 * @return
	 */
	public abstract int countCusInfoMaintainByUserCode(String userCode);
	
	/**
	 * 获取客服信息
	 * @param userCode
	 * @return
	 */
	public abstract CusInfoCscfg getCusInfoCscfg(String userCode);
	
	/**
	 * 添加客服
	 * @param cusInfoCscfg
	 */
	public abstract int addCusInfo(CusInfoCscfg cusInfoCscfg);
	
	/**
	 * 更新客服
	 * @param cusInfoCscfg
	 */
	public abstract int updateCusInfo(CusInfoCscfg cusInfoCscfg);
	
	/**
	 * 根据ID更新 用户密码输入统计表 的 输错次数 为 0
	 */
	public abstract int updateUserErrorPswOfErrorNumsById(Integer id);
	
	
}
