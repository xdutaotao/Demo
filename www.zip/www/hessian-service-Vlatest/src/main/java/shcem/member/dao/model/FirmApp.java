package shcem.member.dao.model;

import java.io.Serializable;
/**
 * 交易商应用关联表
 */

import java.util.Date;

import shcem.base.dao.model.BaseObject;

public class FirmApp extends BaseObject implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	
	private String FirmID;
	
	/** 1-HJOnline 2-CbiHX */
	private Integer appType; 
	
	private Integer dISABLED;
	
	private String rEC_CREATEBY;
	
	private String rEC_MODIFYBY;
	
	private Date rEC_CREATETIME;
	
	private Date rEC_MODIFYTIME;
	
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirmID() {
		return FirmID;
	}

	public void setFirmID(String firmID) {
		FirmID = firmID;
	}

	public Integer getAppType() {
		return appType;
	}

	public void setAppType(Integer appType) {
		this.appType = appType;
	}

	public Integer getDISABLED() {
		return dISABLED;
	}

	public void setDISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
