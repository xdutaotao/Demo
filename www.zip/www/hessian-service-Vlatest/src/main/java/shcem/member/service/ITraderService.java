/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: ITraderService.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.service;

/**
 * @author wlpod
 *
 */
public interface ITraderService {
	
	/**
	 * 获取交易员列表
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public String getTraderList(String params);
	/**
	 * 获取交易员详情
	 * 
	 * @param traderID
	 * @return
	 */
	public String getTrader(String params);

	/**
	 * 新增交易员编码
	 * 
	 * @param trader
	 * @return
	 */
	public  String addTrader(String params);

	/**
	 * 更新交易员信息
	 * 
	 * @param trader
	 * @return
	 */
	public  String updateTrader(String params);

	/**
	 * 禁用交易员
	 * 
	 * @param traderID
	 * @return
	 */
	public  String disableTrader(String params);

	/**
	 * 启用交易员
	 * 
	 * @param traderID
	 * @return
	 */
	public String enableTrader(String params);

	/**
	 * 用户编码是否已经存在
	 * 
	 * @param userCode
	 * @return
	 */
	public String checkUserIDExisted(String params);
	/**
	 * 解绑
	 * 
	 * @param userCode
	 * @return
	 */
	public String Unbundling(String params);
	/**
	 * 交易商绑定
	 * @param params
	 * @return
	 */
	public String bindTrader(String params);
	
	/**
	 * 冻结交易员
	 * 
	 * @param traderID
	 * @return
	 */
	public String changeTraderStatus(String params);
	
	/**
	 * 查询交易员列表
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public String queryTraderList(String params);
	/**
	 * 查询用户手机关系数据列表
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public String queryUserMobileList(String params);
	
	/**
	 * 新增用户手机
	 * @param params
	 * @return
	 */
	public String addUserMobile(String params);
	
	/**
	 * 修改用户手机
	 * @param params
	 * @return
	 */
	public String changeUserMobile(String params);
	
	/**
	 * 解绑用户手机
	 * @param params
	 * @return
	 */
	public String unBindUserMobile(String params);
	
	/**
	 * 聊天用（检查交易员及报盘的有效状态）
	 * @param params
	 * @return
	 */
	public String checkIMAuth(String params);
}
