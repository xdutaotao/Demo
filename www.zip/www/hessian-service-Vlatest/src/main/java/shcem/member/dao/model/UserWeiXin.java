package shcem.member.dao.model;

import java.util.Date;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.annotation.JSONField;
import com.foxinmy.weixin4j.mp.type.FaceSize;
import com.foxinmy.weixin4j.mp.type.Lang;
import com.foxinmy.weixin4j.type.Gender;
import com.foxinmy.weixin4j.util.StringUtil;

import shcem.base.dao.model.BaseObject;

/**
 * (C_USER_WeiXin)
 * 
 * @author yujp
 * @version 1.0.0 2016-08-18
 */
public class UserWeiXin extends BaseObject implements java.io.Serializable {
	
	/** 鐗堟湰鍙�*/
	private static final long serialVersionUID = -2042970437920082343L;
	
    /** id */
    private int id;
    
    /** 鐢ㄦ埛code */
    private String userCode;
    
    /** 鐢ㄦ埛mobile */
    private String mobile;
    
    /** 寰俊openid */
    private String openId;
    
    /** 鐘舵� 榛樿1锛氭湁鏁�     0:鏃犳晥*/
    private int status;
    
    /** 鏈�悗鐧诲綍鏃堕棿 */
    private Date lastLoginTime;
    
    /**App绫诲瀷 鏋氫妇鍊�1-HJ 2-CbiHX*/
    private int appType;
    
	/**
	 * 鐢ㄦ埛鏄电О
	 */
	private String nickName;
	/**
	 * 鐢ㄦ埛鐨勬�鍒紝鍊间负1鏃舵槸鐢锋�锛屽�涓�鏃舵槸濂虫�锛屽�涓�鏃舵槸鏈煡
	 */
	private int gender;
	/**
	 * 鐢ㄦ埛涓汉璧勬枡濉啓鐨勭渷浠�	 */
	private String province;
	/**
	 * 鏅�鐢ㄦ埛涓汉璧勬枡濉啓鐨勫煄甯�	 */
	private String city;
	/**
	 * 鍥藉锛屽涓浗涓篊N
	 */
	private String country;
	/**
	 * 鐢ㄦ埛澶村儚锛屾渶鍚庝竴涓暟鍊间唬琛ㄦ鏂瑰舰澶村儚澶у皬锛堟湁0銆�6銆�4銆�6銆�32鏁板�鍙�锛�浠ｈ〃640*640姝ｆ柟褰㈠ご鍍忥級锛岀敤鎴锋病鏈夊ご鍍忔椂璇ラ」涓虹┖
	 */
	private String headimgurl;
	/**
	 * 鐢ㄦ埛鐗规潈淇℃伅锛宩son 鏁扮粍锛屽寰俊娌冨崱鐢ㄦ埛涓猴紙chinaunicom锛�	 */
	private JSONArray privilege;
	/**
	 * 鐢ㄦ埛鏄惁璁㈤槄璇ュ叕浼楀彿鏍囪瘑锛屽�涓�鏃讹紝浠ｈ〃姝ょ敤鎴锋病鏈夊叧娉ㄨ鍏紬鍙凤紝鎷夊彇涓嶅埌鍏朵綑淇℃伅銆�	 */
	private boolean isSubscribe;
	/**
	 * 鍏虫敞鏃堕棿
	 */
	private long subscribeTime;
	/**
	 * 浣跨敤璇█
	 */
	private String language;
	/**
	 * 鍙湁鍦ㄧ敤鎴峰皢鍏紬鍙风粦瀹氬埌寰俊寮�斁骞冲彴甯愬彿鍚庯紝鎵嶄細鍑虹幇璇ュ瓧娈�	 */
	private String unionId;
	/**
	 * 鍏紬鍙疯繍钀ヨ�瀵圭矇涓濈殑澶囨敞锛屽叕浼楀彿杩愯惀鑰呭彲鍦ㄥ井淇″叕浼楀钩鍙扮敤鎴风鐞嗙晫闈㈠绮変笣娣诲姞澶囨敞
	 */
	private String remark;
	/**
	 * 鐢ㄦ埛鎵�湪鐨勫垎缁処D
	 */
	private int groupId;

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public int getGender() {
		return gender;
	}

	@JSONField(serialize = false)
	public Gender getFormatGender() {
		if (gender == 1) {
			return Gender.male;
		} else if (gender == 2) {
			return Gender.female;
		} else {
			return Gender.unknown;
		}
	}

	public void setGender(int gender) {
		this.gender = gender;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getHeadimgurl() {
		return headimgurl;
	}

	public String getHeadimgurl(FaceSize size) {
		if (StringUtil.isNotBlank(headimgurl)) {
			StringBuilder sb = new StringBuilder(headimgurl);
			return sb.replace(0, (headimgurl.length() - 1), size.getInt() + "")
					.toString();
		}
		return "";
	}

	public void setHeadimgurl(String headimgurl) {
		this.headimgurl = headimgurl;
	}

	public JSONArray getPrivilege() {
		return privilege;
	}

	public void setPrivilege(JSONArray privilege) {
		this.privilege = privilege;
	}

	public String getLanguage() {
		return language;
	}

	@JSONField(serialize = false)
	public Lang getFormatLanguage() {
		return language != null ? Lang.valueOf(language) : null;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public long getSubscribeTime() {
		return subscribeTime;
	}

	@JSONField(serialize = false)
	public Date getFormatSubscribeTime() {
		return new Date(subscribeTime * 1000l);
	}

	public void setSubscribeTime(long subscribeTime) {
		this.subscribeTime = subscribeTime;
	}

	public String getUnionId() {
		return unionId;
	}

	public void setUnionId(String unionId) {
		this.unionId = unionId;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	@Override
	public int hashCode() {
		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof UserWeiXin) {
			UserWeiXin another = (UserWeiXin) obj;
			if (unionId != null && another.getUnionId() != null) {
				return unionId.equals(another.getUnionId());
			}
			if (openId != null && another.getOpenId() != null) {
				return openId.equals(another.getOpenId());
			}
		}
		return false;
	}

	@Override
	public String toString() {
		return "UserWeiXin [openID=" + openId + ", nickName=" + nickName
				+ ", gender=" + gender + ", province=" + province + ", city="
				+ city + ", country=" + country + ", headimgurl=" + headimgurl
				+ ", privilege=" + privilege + ", isSubscribe=" + isSubscribe
				+ ", subscribeTime=" + subscribeTime + ", language=" + language
				+ ", unionId=" + unionId + ", remark=" + remark + ", groupId="
				+ groupId + "]";
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public int getAppType() {
		return appType;
	}

	public void setAppType(int appType) {
		this.appType = appType;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		this.openId = openId;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Date getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(Date lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public boolean isSubscribe() {
		return isSubscribe;
	}

	public void setSubscribe(boolean isSubscribe) {
		this.isSubscribe = isSubscribe;
	}

}