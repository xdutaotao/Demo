/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: Firminvoice
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.dao.model;

import shcem.base.dao.model.BaseObject;


/**交易商接收地址信息（中间关联表）
 * (C_FIRMINVOICE)
 * 
 * @author bianj
 * @version 1.0.0 2016-05-23
 */
public class Firminvoice extends BaseObject implements java.io.Serializable {
    /** 版本号 */
    private static final long serialVersionUID = 2181989564574924850L;
    
    /**  */
    private String firmID;
    
    /**  */
    private Integer addressID;
    
    /** 地址类型 0:收票地址，1:收货地址 */
    private Integer addRessType;
    
    
    /**收票地址*/    
	private String collectInvoiceAddress;
	/**收票电话*/
	private String collectTel;
	/**收票人*/
	private String collectInvoicePeople;
    
    
    
	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}


	public Integer getAddressID() {
		return addressID;
	}

	public void setAddressID(Integer addressID) {
		this.addressID = addressID;
	}

	public Integer getAddRessType() {
		return addRessType;
	}

	public void setAddRessType(Integer addRessType) {
		this.addRessType = addRessType;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getCollectInvoiceAddress() {
		return collectInvoiceAddress;
	}

	public void setCollectInvoiceAddress(String collectInvoiceAddress) {
		this.collectInvoiceAddress = collectInvoiceAddress;
	}

	public String getCollectTel() {
		return collectTel;
	}

	public void setCollectTel(String collectTel) {
		this.collectTel = collectTel;
	}

	public String getCollectInvoicePeople() {
		return collectInvoicePeople;
	}

	public void setCollectInvoicePeople(String collectInvoicePeople) {
		this.collectInvoicePeople = collectInvoicePeople;
	}
}