/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmManager.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月6日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.finance.component.IFirmBanlanceOraManager;
import shcem.finance.util.FinanceOraSysData;
import shcem.finance.util.JSONArrayUtil;
import shcem.member.component.IFirmManager;
import shcem.member.dao.model.*;
import shcem.member.service.IFirmService;
import shcem.member.util.ClearSessionUtil;
import shcem.member.util.FirmSysData;
import shcem.util.JsonUtil;


/**
 * @author wlpod
 *
 */
public class FirmServiceImpl extends BaseServiceImpl implements IFirmService {//
	private IFirmManager mgr = (IFirmManager) FirmSysData.getBean(Constants.BEAN_FIRM_MGR);
	private IFirmBanlanceOraManager firmBanlanceOraManager = (IFirmBanlanceOraManager) FinanceOraSysData.getBean(Constants.BEAN_BALANCEORA_MGR);
	String mode = "member";
	/*查询交易商列表
	 * (non-Javadoc)
	 * 
	 * @see shcem.trade.service.IFirmService#getFirmList()T
	 */
	@Override
	public String getFirmList(String params) {
		this.log.info(this.getClass().getName() + " getFirmList() Start");
		this.log.debug("JSONParams=" + params);
		List<FirmDataList> list = null;
		boolean bolRst = false;
		//表头查询条件
		JSONObject JSONParams = new JSONObject(params);
		JSONObject queryModel =JSONParams.optJSONObject("queryModel");
		List<Condition> conditionsList = new ArrayList<Condition>();
		conditionsList.add(new Condition("temp.FirmID", "like", "", "string","firmID"));
		conditionsList.add(new Condition("temp.FirmName", "like", "", "string","firmName"));
		conditionsList.add(new Condition("temp.ContactName", "like", "", "string","contactName"));
		conditionsList.add(new Condition("temp.contactMobile", "like", "", "string","contactMobile"));
		conditionsList.add(new Condition("temp.BusinessType", "=", "", "String","businessType"));
		conditionsList.add(new Condition("temp.FirmStatus", "=", "","Integer","firmStatus"));// 当前审核状态
		conditionsList.add(new Condition("temp.dGLicenseAuth", "=", "","String","dGLicenseAuth"));//
		conditionsList.add(new Condition("temp.IsAuthorized", "=", "","Integer","isAuthorized"));//
		conditionsList.add(new Condition("temp.IsSignState", "=", "","String","isSignState"));//

		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionsList, "");
		
		if (queryModel.opt("firmSettingStatus") != null && !"".equals(queryModel.getString("firmSettingStatus"))){
			Integer firmSettingStatus = Integer.valueOf(queryModel.getString("firmSettingStatus"));
			String status ="(-1,1)";
			// 启用
			if (firmSettingStatus == 1){
				qc.addCondition("temp.firmSettingDisabled1", "in", status);
			}
			// 禁用
			if (firmSettingStatus == 2){
				qc.addCondition("temp.firmSettingDisabled1", "=", 0);
			}
			// 恢复
			if (firmSettingStatus == 3){
				qc.addCondition("temp.firmSettingDisabled3", "in", status);
			}
			// 冻结
			if (firmSettingStatus == 4){
				qc.addCondition("temp.firmSettingDisabled3", "=", 0);
			}
		}
		
		
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JSONParams);
		try {
			list = mgr.getFirmList(qc,pageInfo);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("查询交易商列表出错" + err.getMessage());
			setResultData("00000", null, err.getMessage());
		}			
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("交易商数据转换失败：" + e.getMessage());
				setResultData("21002", null, e.getMessage());
			}

		}
		
		this.log.info(this.getClass().getName() + " getFirmList() End");
		return rtnData.toString();
	}

	
	/* 增加交易商信息(用户代理注册，直接认为审核通过)
	 * @see shcem.member.service.IFirmService#register(java.lang.String)
	 */
	@Override
	public String register(String params){
		this.log.info(this.getClass().getName() + " register() Start");
		this.log.debug("addFirm Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		String userID = this.getUserId();
		//交易场权限
		JSONArray firmTmptRlspsTemp = JOParams.getJSONArray("firmTmptRlsps");
		int[] firmTmptRlsps = JSONArrayUtil.getJsonToIntArray(firmTmptRlspsTemp);
		FirmDetaiData firmDetaiData = null;
		try {
			firmDetaiData = (FirmDetaiData) JsonUtil.jsonToBean(JOParams, FirmDetaiData.class);
			//后台代理注册
			firmDetaiData.setFlag("backEnd");
		} catch (Exception e) {
			e.printStackTrace();;
		}
		
		
		//交易商"实名匿名"
		List<FirmTmptRlsp> list = new ArrayList<FirmTmptRlsp>();
		JSONArray firmTmptRlspListTemp = JOParams.getJSONArray("firmTmptRlspList");
		if (firmTmptRlspListTemp.length() > 0) {
			for (int i = 0; i < firmTmptRlspListTemp.length(); i++) {
				list.add((FirmTmptRlsp)JsonUtil.jsonToBean((JSONObject) firmTmptRlspListTemp.get(i), FirmTmptRlsp.class));
			}
		}
		firmDetaiData.setFirmTmptRlspList(list);
		
		//交易商详细信息
		FirmDetail firmDetail =  (FirmDetail) JsonUtil.jsonToBean(JOParams, FirmDetail.class);
		//收票地址信息
		RecAddRess recAddRess =  (RecAddRess) JsonUtil.jsonToBean(JOParams, RecAddRess.class);
		//开票地址信息
		VatAddRess vatAddRess =  (VatAddRess) JsonUtil.jsonToBean(JOParams, VatAddRess.class);
		//交易商增值税开票信息
		Firmvatinfo firmvatinfo =  (Firmvatinfo) JsonUtil.jsonToBean(JOParams, Firmvatinfo.class);
		//交易商收票信息（中间表）
		Firminvoice firminvoice = (Firminvoice) JsonUtil.jsonToBean(JOParams, Firminvoice.class);
		
		firmDetaiData.setFirmDetailBean(firmDetail);
		firmDetaiData.setRecAddRessBean(recAddRess);
		firmDetaiData.setVatAddRessBean(vatAddRess);
		firmDetaiData.setFirmvatinfoBean(firmvatinfo);
		firmDetaiData.setFirminvoiceBean(firminvoice);
		//String userID = JOParams.getString("userID");
		
		int returnCode;
		try {
			returnCode = this.mgr.addFirm(firmDetaiData,firmTmptRlsps,userID);
			if (returnCode >= 0) {
				setResultData("00000", null);
				this.log.businesslog("交易商:"+firmDetaiData.getFirmName()+" 通过后台代理注册成功",Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
			}else if(returnCode == -21011){
				setResultData("21011", null);
			}else {
				setResultData("10106", null);
			}
		} catch (Exception e) {
			this.log.error("交易商:"+firmDetaiData.getFirmName()+" 通过后台代理注册出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("交易商:"+firmDetaiData.getFirmName()+" 通过后台代理注册出错"+e.getMessage(),Constants.OPE_MODE_MEMBER,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " register() End");
		return rtnData.toString();
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.trade.service.IFirmService#getFirm(java.lang.String)
	 */
	@Override
	public String getFirmDetail(String params) {
		this.log.info(this.getClass().getName() + " getFirmDetail() Start");
		this.log.debug("getFirmDetail Service Start debug");
		FirmAllData firmAllData = new FirmAllData();
		boolean bolRst = false;
		this.log.debug(params);
		JSONObject JOParams = new JSONObject(params);
		String firmId = JOParams.getString("firmID");		
		try {
			firmAllData = mgr.getFirm(firmId);
			bolRst = true;
		} catch (Exception err) {  
			this.log.error("获取交易商出错" + err.getMessage());
			setResultData("10105", null, err.getMessage());
		}
		if (bolRst) {
			JSONObject retData;			
			try {
				retData = JsonUtil.coverModelToJSONObject(firmAllData);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error("交易商数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		
		this.log.info(this.getClass().getName() + " getFirmDetail() End");
		return rtnData.toString();
	}
	
	
	/* (non-Javadoc)
	 * @see shcem.member.service.IFirmService#updateFirmInfo(java.lang.String)
	 */
	@Override
	public String updateFirmInfo(String params) {
		this.log.info(this.getClass().getName()+ " updateFirmInfo() Start");
		this.log.debug("updateFirmInfo Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		//交易场权限
		JSONArray firmTmptRlspsTemp = JOParams.getJSONArray("firmTmptRlsps");
		int[] firmTmptRlsps = JSONArrayUtil.getJsonToIntArray(firmTmptRlspsTemp);
		
		FirmDetaiData firmDetaiData = null;
		try {
			firmDetaiData =  (FirmDetaiData) JsonUtil.jsonToBean(JOParams, FirmDetaiData.class);
			//后台代理注册
			firmDetaiData.setFlag("backEnd");
		} catch (Exception e) {
			e.printStackTrace();;
		}
		
		//交易商"实名匿名"
		List<FirmTmptRlsp> list = new ArrayList<FirmTmptRlsp>();
		JSONArray firmTmptRlspListTemp = JOParams.getJSONArray("firmTmptRlspList");
		if (firmTmptRlspListTemp.length() > 0) {
			for (int i = 0; i < firmTmptRlspListTemp.length(); i++) {
				list.add((FirmTmptRlsp)JsonUtil.jsonToBean((JSONObject) firmTmptRlspListTemp.get(i), FirmTmptRlsp.class));
			}
		}
		firmDetaiData.setFirmTmptRlspList(list);
		
		//交易商详细信息
		FirmDetail firmDetail =  (FirmDetail) JsonUtil.jsonToBean(JOParams, FirmDetail.class);
		//收票地址信息
		RecAddRess recAddRess =  (RecAddRess) JsonUtil.jsonToBean(JOParams, RecAddRess.class);
		//开票地址信息
		VatAddRess vatAddRess =  (VatAddRess) JsonUtil.jsonToBean(JOParams, VatAddRess.class);
		//交易商增值税开票信息
		Firmvatinfo firmvatinfo =  (Firmvatinfo) JsonUtil.jsonToBean(JOParams, Firmvatinfo.class);
		//交易商售票信息（中间表）
		Firminvoice firminvoice = (Firminvoice) JsonUtil.jsonToBean(JOParams, Firminvoice.class);
		
		firmDetaiData.setFirmDetailBean(firmDetail);
		firmDetaiData.setRecAddRessBean(recAddRess);
		firmDetaiData.setVatAddRessBean(vatAddRess);
		firmDetaiData.setFirmvatinfoBean(firmvatinfo);
		firmDetaiData.setFirminvoiceBean(firminvoice);
		this.log.debug(params);
		String userID = JOParams.getString("userID");
		String mode = this.getMode();
		String userName = this.getUserId() == null?"system":(this.getUserId().equals(""))?"system":this.getUserId();
		
		int returnCode;
		try {
			returnCode = this.mgr.updateFirm(firmDetaiData,firmTmptRlsps,userID,userName,mode,this.getRequestId());
			if (returnCode >= 0) {
				setResultData("00000", null);
				this.log.businesslog("更新交易商:"+firmDetaiData.getFirmName()+" 信息成功",Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
			}else {
				setResultData("10106", null);
			}
		} catch (Exception e) {
			this.log.error("修改交易商:"+firmDetaiData.getFirmName()+" 信息出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("修改交易商:"+firmDetaiData.getFirmName()+" 信息出错"+e.getMessage(),Constants.OPE_MODE_MEMBER,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName()+ " updateFirmInfo() End");
		return rtnData.toString();
	}

	@Override
	public String getRegisteredFirmList(String params) {
		this.log.info(this.getClass().getName() + " getRegisteredFirmList() Start");
		List<FirmRegister> list = null;
		boolean bolRst = false;
		JSONObject JSONParams = new JSONObject(params);
		this.log.debug(params);
		List<Condition> conditionsList = new ArrayList<Condition>();
		//表头搜索条件
		conditionsList.add(new Condition("FirmName", "like", "", "string","firmName"));
		conditionsList.add(new Condition("FirmRegId", "like", "", "string","firmRegId"));
		conditionsList.add(new Condition("ContactName", "like", "", "string","contactName"));
		conditionsList.add(new Condition("dbo.base64_utf8decode(ContactMobile)", "like", "", "string","contactMobile"));
		conditionsList.add(new Condition("BusinessType", "=", "", "String","businessType"));
		conditionsList.add(new Condition("DGLicenseAuth", "=", "", "String","dGLicenseAuth"));
		//审核状态
		conditionsList.add(new Condition("FirmStatus", "=", "", "String","firmStatus"));
		
		conditionsList.add(new Condition(
				"convert(char(10),REC_CREATETIME,120)", ">=", "",
				"string", "rEC_CREATETIME_startDate"));
		conditionsList.add(new Condition(
				"convert(char(10),REC_CREATETIME,120)", "<=", "",
				"string", "rEC_CREATETIME_endDate"));
		
		conditionsList.add(new Condition(
				"convert(char(10),REC_MODIFYTIME,120)", ">=", "",
				"string", "rEC_MODIFYTIME_startDate"));
		conditionsList.add(new Condition(
				"convert(char(10),REC_MODIFYTIME,120)", "<=", "",
				"string", "rEC_MODIFYTIME_endDate"));
		
		JSONObject queryModel = null;		
		if(!JSONParams.isNull("queryModel")){
			queryModel = JSONParams.getJSONObject("queryModel");
			this.log.debug("queryModel="+queryModel.toString());
		}
		
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionsList, "");
		this.log.debug("qc="+qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JSONParams);
		try {
			list = mgr.getRegisteredFirmList(qc,pageInfo);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("查询交易商注册信息出错" + err.getMessage());
			setResultData("10106", null, err.getMessage());
		}		
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total",pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("交易商注册信息转换失败：" + e.getMessage());
				setResultData("21002", null, e.getMessage());
			}

		}
		
		this.log.info(this.getClass().getName() + " getFirmList() End");
		return rtnData.toString();
	}

	@Override
	public String getRegisteredFirmDetail(String params) {
		this.log.info("getRegisteredFirmDetail Service Start debug");
		FirmRegister firmRegister = new FirmRegister();
		//FirmRegisterServiceModel rtnModel = new FirmRegisterServiceModel();
		boolean bolRst = false;
		this.log.debug(params);
		JSONObject JOParams = new JSONObject(params);
		String firmRegId = JOParams.getString("firmRegId");		
		try {
			firmRegister = mgr.getRegisteredFirmDetail(firmRegId);
			// 获取 注册交易商交易场关系 列表
			List<FirmRegTmptRlsp> firmRegTmptRlspList =  mgr.selectFirmRegTmptRlspByFirmRegId(firmRegId);
			firmRegister.setFirmTmptRlspList(firmRegTmptRlspList);
			bolRst = true;
			
		} catch (Exception err) {  
			this.log.error("获取交易商详细注册信息出错" + err.getMessage());
			setResultData("10105", null, err.getMessage());
		}
		if (bolRst) {
			JSONObject retData;			
			
			try {
				retData = JsonUtil.coverModelToJSONObject(firmRegister);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error("交易商详细注册信息转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		
		this.log.info(this.getClass().getName() + " getFirmDetail() End");
		return rtnData.toString();
	}


	/**审核后，交易商情报更新
	 * 2016年5月23日 上午10:23:32
	 * @param params
	 * @return
	 * 张楠/Nany
	 */
	@Override
	public String registerFirmInfo(String params) {
		this.log.info(this.getClass().getName() + " register() Start");
		this.log.debug("addFirm Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		FirmDetaiData firmDetaiData = null;
		
		//交易场权限
		JSONArray firmTmptRlspsTemp = JOParams.getJSONArray("firmTmptRlsps");
		int[] firmTmptRlsps = JSONArrayUtil.getJsonToIntArray(firmTmptRlspsTemp);
		
		try {
			firmDetaiData =  (FirmDetaiData) JsonUtil.jsonToBean(JOParams, FirmDetaiData.class);
			//前台注册
			firmDetaiData.setFlag("frontEnd");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		//交易商"实名匿名"
		List<FirmTmptRlsp> list = new ArrayList<FirmTmptRlsp>();
		JSONArray firmTmptRlspListTemp = JOParams.getJSONArray("firmTmptRlspList");
		if (firmTmptRlspListTemp.length() > 0) {
			for (int i = 0; i < firmTmptRlspListTemp.length(); i++) {
				list.add((FirmTmptRlsp)JsonUtil.jsonToBean((JSONObject) firmTmptRlspListTemp.get(i), FirmTmptRlsp.class));
			}
		}
		firmDetaiData.setFirmTmptRlspList(list);
		
		//交易商详细信息
		FirmDetail firmDetail =  (FirmDetail) JsonUtil.jsonToBean(JOParams, FirmDetail.class);
		//收票地址信息
		RecAddRess recAddRess =  (RecAddRess) JsonUtil.jsonToBean(JOParams, RecAddRess.class);
		//开票地址信息
		VatAddRess vatAddRess =  (VatAddRess) JsonUtil.jsonToBean(JOParams, VatAddRess.class);
		//交易商增值税开票信息
		Firmvatinfo firmvatinfo =  (Firmvatinfo) JsonUtil.jsonToBean(JOParams, Firmvatinfo.class);
		//交易商售票信息（中间表）
		Firminvoice firminvoice = (Firminvoice) JsonUtil.jsonToBean(JOParams, Firminvoice.class);
		
		firmDetaiData.setFirmDetailBean(firmDetail);
		firmDetaiData.setRecAddRessBean(recAddRess);
		firmDetaiData.setVatAddRessBean(vatAddRess);
		firmDetaiData.setFirmvatinfoBean(firmvatinfo);
		firmDetaiData.setFirminvoiceBean(firminvoice);
		String userID = JOParams.getString("userID");
		
		this.log.debug(params);
		int returnCode;
		try {
			returnCode = this.mgr.addFirm(firmDetaiData,firmTmptRlsps,userID);
			if (returnCode >=0) {
				setResultData("00000", null);
				this.log.businesslog("审核后，交易商:"+firmDetaiData.getFirmName()+" 信息更新成功",Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
			}else if(returnCode == -21011){
				setResultData("21011", null);
			}else if (returnCode == -21006 ) {
				setResultData("21006", null);
			}else {
				setResultData("10106", null);
			}
		} catch (Exception e) {
			this.log.error("审核后，交易商:"+firmDetaiData.getFirmName()+" 信息更新出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("审核后，交易商:"+firmDetaiData.getFirmName()+" 信息更新出错"+e.getMessage(),Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
		}
		this.log.info(this.getClass().getName() + " register() End 返回信息:"+rtnData.toString());
		return rtnData.toString();
	}


	/**
	 * 禁用交易商
	 * 交易商当前余额大于0，不能禁用
	 */
	@Override
	public String disableFirm(String params) {
		this.log.info("disableFirm Service Start debug");
		JSONObject JSONParams = new JSONObject(params);
		String firmID = JSONParams.getString("firmID");
		int disabled = JSONParams.getInt("disabled");
		int returnCode;
		try {
			returnCode = this.mgr.updateFirmDisabled(firmID,disabled);
			if (returnCode == 1) {
				setResultData("00000", null);
				this.log.businesslog("禁用编号为 "+firmID+"的交易商成功",Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
			}else if (returnCode == -1) {
				setResultData("21004", null);
			}else{
				setResultData("10106", null);
			}
		} catch (Exception e) {
			this.log.error("禁用编号为 "+firmID+"的交易商出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("禁用编号为 "+firmID+"的交易商出错"+e.getMessage(),Constants.OPE_MODE_MEMBER,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " disableFirm() End");
		return rtnData.toString();
	}


	@Override
	public String rejectFirmInfo(String params) {
		this.log.info("disableFirm Service Start debug");
		JSONObject JSONParams = new JSONObject(params);
		String firmRegId = JSONParams.getString("firmRegId");
		//拒绝原因
		String note = JSONParams.getString("note");
		try {
			this.mgr.rejectRegisteredFirm(firmRegId,note);
			setResultData("00000", null);
			this.log.businesslog("审核注册码为:"+firmRegId+"的交易商不通过成功",Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
		} catch (Exception e) {
			this.log.error("审核注册码为:"+firmRegId+"的交易商不通过失败" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("审核注册码为:"+firmRegId+"的交易商不通过失败"+e.getMessage(),Constants.OPE_MODE_MEMBER,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " disableFirm() End");
		return rtnData.toString();
	}
	
	/**
	 * 验证交易商编码是否已存在 //"交易商认证编码已经被占用"
			FirmAllData tempFirmAllData = this.mgr.getFirm(firmDetaiData.getFirmID());
	 */
	@Override
	public String checkFirmID(String params) {
		this.log.info("checkFirmID Service Start debug");
		JSONObject JSONParams = new JSONObject(params);
		String firmID = JSONParams.getString("firmID");
		int returnCode;
		try {
			FirmAllData tempFirmAllData = this.mgr.getFirm(firmID);
			//老专场 是否存在该交易商
			returnCode = this.firmBanlanceOraManager.checkFirmForOra(firmID);
			if (tempFirmAllData != null  || returnCode == -1) {
				setResultData("21001",null);
			}else {
				setResultData("21000",null);
			}
		} catch (Exception e) {
			this.log.error("验证交易商编码出错");
			setResultData("10112", e.getMessage());
		}
		return rtnData.toString();
	}


	@Override
	public String checkFirmName(String params) {
		this.log.info("checkFirmID Service Start debug");
		JSONObject JSONParams = new JSONObject(params);
		String firmName = JSONParams.getString("firmName");
		try {
			List<FirmAllData> list = this.mgr.getFirmByFirmName(firmName);
			if (list != null && list.size() == 1 ) {
				if ((list.get(0).getAppType()!=null&&list.get(0).getAppType() == 1) ||list.get(0).getAppType()==null) {
					setResultData("21003", null);
				}
				if (list.get(0).getAppType()!=null&&list.get(0).getAppType() == 2) {
					setResultData("21005", list.get(0).getFirmID());
				}
			}else if (list != null && list.size() >1 ) {
//				if ((list.get(0).getAppType()!=null&&list.get(0).getAppType() == 1) ||list.get(0).getAppType()==null) {
//					setResultData("21003", null);
//				}
//				if (list.get(0).getAppType()!=null&&list.get(0).getAppType() == 2) {
//					setResultData("21005", list.get(0).getFirmID());
//				}
				setResultData("00000", null);
			}else {
				setResultData("00000", null);
			}
//			else if (list != null && list.size() >1 ) {
//				setResultData("21003", null);
//			}else {
//				setResultData("21002", null);
//			}
		} catch (Exception e) {
			this.log.error("验证交易商简称出错");
			setResultData("10112", e.getMessage());
		}
		return rtnData.toString();
	}
	/**
	 * 验证交易员编码是否已存在
	 */
	@Override
	public String checkTraderID(String params) {
		this.log.info("checkFirmID Service Start debug");
		JSONObject JSONParams = new JSONObject(params);
		String traderID = JSONParams.getString("traderID");
		try {
			List<Trader> list = this.mgr.getTrader(traderID);
			if (list!= null && list.size() > 0) {
				setResultData("20001", null);
			}else {
				setResultData("00000", null);
			}
		} catch (Exception e) {
			this.log.error("验证交易员出错");
			setResultData("10112", e.getMessage());
		}
		return rtnData.toString();
	}
	
	@Override
	public String checkFullName(String params) {
		this.log.info("checkFirmID Service Start debug");
		JSONObject JSONParams = new JSONObject(params);
		String fullName = JSONParams.getString("fullName");
		try {
			List<FirmAllData> list = this.mgr.getFirmByFullName(fullName);
			if (list != null && list.size() > 0 ) {
				setResultData("21003", null);
			}else {
				setResultData("21002", null);
			}
		} catch (Exception e) {
			this.log.error("验证交易商全称出错");
			setResultData("10112", e.getMessage());
		}
		return rtnData.toString();
	}
	@Override
	public String GetNewFirmIDByZone(String params) {
		this.log.info("GetNewFirmIDByZone Service Start");
		JSONObject JSONParams = new JSONObject(params);
		String zoneNum = JSONParams.getString("zoneNum");
		String firmID = null;
		try {
			firmID = this.checkFirmForOra(zoneNum);
			setResultData("00000", firmID);
		} catch (Exception e) {
			this.log.error("推荐交易商编号失败 "+e.getMessage());
			setResultData("10101",null);
		}
		this.log.info("GetNewFirmIDByZone Service End");
		return rtnData.toString();
	}
	
	private String checkFirmForOra(String zoneNum) {
		String firmID = this.mgr.GetNewFirmIDByZone(zoneNum);
		//老专场 是否存在该交易商
		int returnCode = this.firmBanlanceOraManager.checkFirmForOra(firmID);
		if (returnCode == -1) {
			this.mgr.updateFirmIDPoolIsUsed(firmID);
			firmID = this.checkFirmForOra(zoneNum);
		}
		return firmID;
	}
	/**
	 *   客户注册化交网站后，客服介入联系客户，需要记录客户基本信息：公司名称，联系电话，
	 * 联系手机，地域，产品，公司类型，备注（可记录认证审核建议等信息）。
	 * 并记录客服P.I.C、客户来源、标注是否金石湾/危化、判断是否客户是否有效。
	 * 新增一个菜单【客服审核】，允许客户编辑交易商提交的审核信息，并修改状态只有【客服审核通过】
	 */
	@Override
	public String updateFirmRegister(String params) {
		this.log.info(this.getClass().getName()+ " updateFirmRegister() Start");
		this.log.debug("updateFirmRegister Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		String userName = this.getUserName() == null ? "system" : (this.getUserName() == "") ? "system" : this.getUserName();
		
		// 交易商注册表
		FirmRegister firmRegister =  (FirmRegister) JsonUtil.jsonToBean(JOParams, FirmRegister.class);
		Object approvedTemp = JOParams.opt("approved");
		boolean approved  = false;
		if(approvedTemp != null){
			approved = Boolean.valueOf(approvedTemp.toString());
		}
		firmRegister.setRecModifyby(userName);
		
		// 取得 注册交易商交易场关系 列表
		String firmRegId = firmRegister.getFirmRegId();
		List<FirmRegTmptRlsp> list = new ArrayList<FirmRegTmptRlsp>();
		JSONArray firmRegTmptRlspListTemp;
		
		if(approvedTemp == null || approved){
			firmRegTmptRlspListTemp = JOParams.getJSONArray("firmTmptRlspList");
			if (firmRegTmptRlspListTemp.length() > 0) {
				for (int i = 0; i < firmRegTmptRlspListTemp.length(); i++) {
					FirmRegTmptRlsp rlsp = (FirmRegTmptRlsp)JsonUtil.jsonToBean((JSONObject) firmRegTmptRlspListTemp.get(i), FirmRegTmptRlsp.class);
					rlsp.setFirmRegId(rlsp.getFirmRegId() == null ? firmRegId : rlsp.getFirmRegId());
					rlsp.setRecCreateby(userName);
					rlsp.setRecModifyby(userName);
					list.add(rlsp);
				}
			}
			firmRegister.setFirmTmptRlspList(list);
		}
		int returnCode;
		try {
			
			returnCode = this.mgr.updateFirmRegister(firmRegister,approved,approvedTemp);
			if (returnCode >= 0) {
				if(approved){
					setResultData("00000", null);
					this.log.businesslog("更新交易商(客服审核通过):"+firmRegister.getFirmName()+" 注册信息成功",Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
				}else {
					setResultData("00000", null);
					this.log.businesslog("更新交易商(客服审核拒绝):"+firmRegister.getFirmName()+" 注册信息成功",Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
				}
				
			}else {
				setResultData("10106", null);
			}
		} catch (Exception e) {
			this.log.error("更新交易商:"+firmRegister.getFirmName()+" 注册信息成功" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("更新交易商:"+firmRegister.getFirmName()+" 注册信息成功"+e.getMessage(),Constants.OPE_MODE_MEMBER,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName()+ " updateFirmInfo() End");
		return rtnData.toString();
	}
	
	
	@Override
	public String getFirmRecAddressList(String params) {
		this.log.info(this.getClass().getName()+ " getFirmRecAddressList() Start");
		JSONObject JOParams = new JSONObject(params);
		String firmID = JOParams.getString("firmID");
		boolean bolRst = false;
		
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		List<RecAddRess> list = null;
		try {
			list = this.mgr.getFirmRecAddressList(pageInfo,firmID);
			bolRst= true;
		} catch (Exception e) {
			this.log.error("查询交易商邮寄信息出错:"+e.getMessage());
			setResultData("10105",null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("交易商邮寄信息转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName()+ " getFirmRecAddressList() Start");
		return rtnData.toString();
	}


	@Override
	public String addRecAddress(String params) {
		this.log.info(this.getClass().getName()+ " addRecAddress() Start");
		JSONObject JOParams = new JSONObject(params);
		RecAddRess recAddress = (RecAddRess) JsonUtil.jsonToBean(JOParams, RecAddRess.class);
		try {
			this.mgr.addRecAddress(recAddress);
			setResultData("00000",null);
		} catch (Exception e) {
			this.log.error("交易商 收货/收票 地址新增失败："+e.getMessage());
			setResultData("10106",null);
		}
		this.log.info(this.getClass().getName()+ " addRecAddress() End");
		return rtnData.toString();
	}


	@Override
	public String delAddressList(String params) {
		this.log.info(this.getClass().getName()+ " delAddressList() Start");
		JSONObject JOParams = new JSONObject(params);
		/**
		 */
		JSONArray recAddressIDsTemp = JOParams.getJSONArray("recAddressIDs");
		int[] recAddressIDs = JSONArrayUtil.getJsonToIntArray(recAddressIDsTemp);
		try {
			this.mgr.delAddressList(recAddressIDs);
			setResultData("00000",null);
		} catch (Exception e) {
			this.log.error("交易商 收货/收票 地址删除失败："+e.getMessage());
			setResultData("10106",null);
		}
		this.log.info(this.getClass().getName()+ " delAddressList() End");
		return rtnData.toString();
	}


	@Override
	public String getFirmRecAddressByID(String params) {
		this.log.info(this.getClass().getName()+ " getFirmRecAddressByID() Start");
		JSONObject JOParams = new JSONObject(params);
		int recAddressID = JOParams.getInt("recAddressID");
		RecAddRess recAddress = null;
		boolean bolRst = false;
		try {
			recAddress = this.mgr.getFirmRecAddressByID(recAddressID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询交易商 收货/收票 地址失败："+e.getMessage());
			setResultData("10106",null);
		}
		if (bolRst) {
			JSONObject retData;			
			try {
				retData = JsonUtil.coverModelToJSONObject(recAddress);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error("交易商 收货/收票地址 数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName()+ " getFirmRecAddressByID() End");
		return rtnData.toString();
	}


	@Override
	public String updateRecAddress(String params) {
		this.log.info(this.getClass().getName()+ " addRecAddress() Start");
		JSONObject JOParams = new JSONObject(params);
		RecAddRess recAddress = (RecAddRess) JsonUtil.jsonToBean(JOParams, RecAddRess.class);
		try {
			this.mgr.updateRecAddress(recAddress);
			setResultData("00000",null);
		} catch (Exception e) {
			this.log.error("交易商 收货/收票 地址更新失败："+e.getMessage());
			setResultData("10106",null);
		}
		this.log.info(this.getClass().getName()+ " addRecAddress() End");
		return rtnData.toString();
	}
	
	@Override
	public String disabledRecAddress(String params) {
		this.log.info(this.getClass().getName()+ " addRecAddress() Start");
		JSONObject JOParams = new JSONObject(params);
		int recAddressID = JOParams.getInt("recAddressID");
		int disabled = JOParams.getInt("disabled");
		try {
			this.mgr.disabledRecAddress(recAddressID,disabled);
			setResultData("00000",null);
		} catch (Exception e) {
			if (disabled == 0 ) {
				this.log.error("启用 交易商 收货/收票 地址失败："+e.getMessage());
			}else {
				this.log.error("禁用 交易商 收货/收票 地址失败："+e.getMessage());
			}
			setResultData("10106",null);
		}
		this.log.info(this.getClass().getName()+ " addRecAddress() End");
		return rtnData.toString();
	}


	@Override
	public String addFirmRegister(String params) {
		this.log.info(this.getClass().getName()+ " addFirmRegister() Start");
		JSONObject JOParams = new JSONObject(params);
		FirmRegister firmRegister = (FirmRegister) JsonUtil.jsonToBean(JOParams, FirmRegister.class);
		String userName = this.getUserId() == null ? "system" : (this
		        .getUserId() == "") ? "system" : this.getUserId();
		firmRegister.setRecCreateby(userName);
		firmRegister.setRecModifyby(userName);
		// 取得交易商专场信息
		List<FirmRegTmptRlsp> list = new ArrayList<FirmRegTmptRlsp>();
		JSONArray firmRegTmptRlspListTemp = JOParams.getJSONArray("firmTmptRlspList");
		if (firmRegTmptRlspListTemp.length() > 0) {
			for (int i = 0; i < firmRegTmptRlspListTemp.length(); i++) {
				FirmRegTmptRlsp rlsp = (FirmRegTmptRlsp)JsonUtil.jsonToBean((JSONObject) firmRegTmptRlspListTemp.get(i), FirmRegTmptRlsp.class);
				rlsp.setRecCreateby(userName);
				rlsp.setRecModifyby(userName);
				list.add(rlsp);
			}
		}
		
		try {
			// 插入注册交易商
			this.mgr.insertFirmRegister(firmRegister,list);
			setResultData("00000",null);
		} catch (Exception e) {
			this.log.error("交易商注册信息 新增失败："+e.getMessage());
			setResultData("10106",null);
		}
		this.log.info(this.getClass().getName()+ " addFirmRegister() End");
		return rtnData.toString();
	}
	
	@Override
	public String synchronizeFrim(String params) {
		this.log.info(this.getClass().getName()+ " synchronizeFrim() Start");
		this.log.debug("updateFirmInfo Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		//交易场权限
		JSONArray firmTmptRlspsTemp = JOParams.getJSONArray("firmTmptRlsps");
		int[] firmTmptRlsps = JSONArrayUtil.getJsonToIntArray(firmTmptRlspsTemp);
		
		FirmDetaiData firmDetaiData = null;
		try {
			firmDetaiData =  (FirmDetaiData) JsonUtil.jsonToBean(JOParams, FirmDetaiData.class);
			//后台代理注册
			firmDetaiData.setFlag("backEnd");
		} catch (Exception e) {
			e.printStackTrace();;
		}
		
		//交易商"实名匿名"
		List<FirmTmptRlsp> list = new ArrayList<FirmTmptRlsp>();
		JSONArray firmTmptRlspListTemp = JOParams.getJSONArray("firmTmptRlspList");
		if (firmTmptRlspListTemp.length() > 0) {
			for (int i = 0; i < firmTmptRlspListTemp.length(); i++) {
				list.add((FirmTmptRlsp)JsonUtil.jsonToBean((JSONObject) firmTmptRlspListTemp.get(i), FirmTmptRlsp.class));
			}
		}
		firmDetaiData.setFirmTmptRlspList(list);
		
		//交易商详细信息
		FirmDetail firmDetail =  (FirmDetail) JsonUtil.jsonToBean(JOParams, FirmDetail.class);
		//收票地址信息
		RecAddRess recAddRess =  (RecAddRess) JsonUtil.jsonToBean(JOParams, RecAddRess.class);
		//开票地址信息
		VatAddRess vatAddRess =  (VatAddRess) JsonUtil.jsonToBean(JOParams, VatAddRess.class);
		//交易商增值税开票信息
		Firmvatinfo firmvatinfo =  (Firmvatinfo) JsonUtil.jsonToBean(JOParams, Firmvatinfo.class);
		//交易商售票信息（中间表）
		Firminvoice firminvoice = (Firminvoice) JsonUtil.jsonToBean(JOParams, Firminvoice.class);
		
		firmDetaiData.setFirmDetailBean(firmDetail);
		firmDetaiData.setRecAddRessBean(recAddRess);
		firmDetaiData.setVatAddRessBean(vatAddRess);
		firmDetaiData.setFirmvatinfoBean(firmvatinfo);
		firmDetaiData.setFirminvoiceBean(firminvoice);
		this.log.debug(params);
		String userID = JOParams.getString("userID");
		
		int returnCode;
		try {
			returnCode = this.mgr.synchronizeFrim(firmDetaiData,firmTmptRlsps,userID);
			if (returnCode >= 0) {
				setResultData("00000", null);
				this.log.businesslog("化纤平台交易商 "+firmDetaiData.getFirmName()+" 同步到化交平台成功",Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
			}else {
				setResultData("10106", null);
			}
		} catch (Exception e) {
			this.log.error("化纤平台交易商 :"+firmDetaiData.getFirmName()+" 同步到化交平台出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("化纤平台交易商 "+firmDetaiData.getFirmName()+" 同步到化交平台出错"+e.getMessage(),Constants.OPE_MODE_MEMBER,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName()+ " synchronizeFrim() End");
		return rtnData.toString();
	}


	@Override
	public String updateCFirmOfFirmStatus(String params) {
		this.log.info(this.getClass().getName()+ " updateCFirmOfFirmStatus() Start");
		JSONObject JOParams = new JSONObject(params);
		String userName = this.getUserName() == null ? "system" : (this
		        .getUserName() == "") ? "system" : this.getUserName();
		try {
			// 插入注册交易商
			this.mgr.updateCFirmOfFirmStatus(JOParams.getString("firmId"), userName, JOParams.getInt("firmStatus"));
			setResultData("00000",null);
		} catch (Exception e) {
			this.log.error(" 更新交易商的审核状态失败："+e.getMessage());
			setResultData("10106",null);
		}
		this.log.info(this.getClass().getName()+ " updateCFirmOfFirmStatus() End");
		return rtnData.toString();
	}

	/**
	 * 获取商铺列表
	 *
	 * @param params
	 * @return
	 */
	public String getshopList(String params) {
		this.log.info(this.getClass().getName()+ " getshopList() Start");
		this.log.debug("getshopList Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		List<Condition> conditionsList = new ArrayList<Condition>();
		conditionsList.add(new Condition("temp.ShopName", "like", "", "string","shopName"));
		conditionsList.add(new Condition("temp.FirmID", "like", "", "string","firmID"));
		conditionsList.add(new Condition("temp.FirmName", "like", "", "string","firmName"));
		conditionsList.add(new Condition("temp.isHaveRelationFirm", "=", "", "int","isHaveRelationFirm"));
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionsList, "");
		List<Shop> shopList=null;
		boolean bolRst = false;
		try {
			shopList=this.mgr.selectShopByParam(qc,pageInfo);
			bolRst= true;
		} catch (Exception e) {
			this.log.error("查询商铺列表失败:"+e.getMessage());
			setResultData("10105",null);
		}
		if(bolRst){
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(shopList);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("查询商铺列表转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName()+ " getshopList() end");
		return rtnData.toString();
	}

	/**
	 * 新增or修改商铺信息
	 *
	 * @param params
	 * @return
	 */
	public String saveOrupdateShop(String params) {
		this.log.info(this.getClass().getName()+ " saveOrupdateShop() Start");
		this.log.debug("saveOrupdateShop Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		Shop shop= (Shop) JsonUtil.jsonToBean(JOParams,Shop.class);
		String userName = this.getUserId() == null ? "system" : (this.getUserId() == "") ? "system" : this.getUserId();
		shop.setREC_CREATEBY(userName);
		shop.setREC_MODIFYBY(userName);
		//关联的交易商ID数组
		String[] relationFirmIDArr = {};
		JSONArray relationFirmID = JOParams.optJSONArray("relationFirmID");
		if (relationFirmID != null){
			relationFirmIDArr = JSONArrayUtil.getJsonToStringArray(relationFirmID);
		}
		shop.setRelationFirmID(relationFirmIDArr);
		
		if(shop.getId()!=null && shop.getId()>0){
			try {
				int resultCode = this.mgr.updateShop(shop);
				if (resultCode == 0){
					setResultData("00000", null);
					this.log.businesslog("修改商铺成功 ",Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
				}else if (resultCode == -1){
					setResultData("25004", null);
				}else if (resultCode == -3){
					setResultData("25002", null);
				}else if (resultCode == -4){
					setResultData("25003", null);
				}
			}catch (Exception e){
				this.log.error("更新商铺失败:"+e.getMessage());
				setResultData("25004", null);
			}
		}else{
			try {
				int resultCode = this.mgr.insertShop(shop);
				if (resultCode == 0){
					setResultData("00000", null);
					this.log.businesslog("新增商铺成功 ",Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
				}else if (resultCode == -1){
					setResultData("25000", null);
				}else if (resultCode == -2){
					setResultData("25001", null);
				}else if (resultCode == -3){
					setResultData("25002", null);
				}else if (resultCode == -4){
					setResultData("25003", null);
				}
			}catch (Exception e){
				this.log.error("新增商铺失败:"+e.getMessage());
				setResultData("25000", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName()+ " saveOrupdateShop() end");
		return rtnData.toString();
	}

	/**
	 * 获取商铺信息
	 *
	 * @param params
	 * @return
	 */
	public String getShopInfo(String params) {
		this.log.info(this.getClass().getName()+ " getShopInfo() Start");
		this.log.debug("getShopInfo Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		String id = JOParams.getString("id");
		Shop shop=null;
		boolean bolRst=false;
		try {
			shop=this.mgr.getById(id);
			bolRst=true;
		} catch (Exception e) {
			this.log.error("获取商铺信息失败:"+e.getMessage());
			setResultData("10101", null, e.getMessage());
		}
		if(bolRst){
			JSONObject retData;
			try {
				retData = JsonUtil.coverModelToJSONObject(shop);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error("获取商铺信息数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName()+ " getShopInfo() end");
		return rtnData.toString();
	}

	/**
	 * 更改商铺状态
	 *
	 * @param params
	 * @return
	 */
	public String resetShopState(String params) {
		this.log.info(this.getClass().getName()+ " resetShopState() Start");
		this.log.debug("resetShopState Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		String id=JOParams.getString("id");
		Integer disabled=JOParams.getInt("disabled");
		boolean bolRst=false;
		try {
			this.mgr.updateShopOfDisabled(Integer.valueOf(id), disabled);
			bolRst=true;
		} catch (Exception e) {
			this.log.error("禁用商铺失败:"+e.getMessage());
			setResultData("10106", null, e.getMessage());
		}
		if(bolRst){
			setResultData("00000", null);
			this.log.businesslog("禁用商铺状态成功 ",Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
		}
		this.log.info(this.getClass().getName()+ " resetShopState() end");
		return rtnData.toString();
	}


	@Override
	public String frozenOrrecoveryFirm(String params) {
		this.log.info(this.getClass().getName()+ " frozenOrrecoveryFirm() Start");
		this.log.debug("frozenOrrecoveryFirm Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		FirmSetting firmSetting = (FirmSetting) JsonUtil.jsonToBean(JOParams, FirmSetting.class);
		String userName = this.getUserName() == null ? "system" : (this.getUserName() == "") ? "system" : this.getUserName();
		firmSetting.setREC_CREATEBY(userName);
		firmSetting.setREC_MODIFYBY(userName);
		try {
			if(3 == firmSetting.getSettingType()){
				if (firmSetting.getId() == null || firmSetting.getId() == 0){
					// 冻结是清交易员的Session
					int code = ClearSessionUtil.clearSession(firmSetting.getFirmCode(), this.getUserId(), this.getMode(), this.getRequestId());
					if (code != 0){
						setResultData("30000", null,"交易商ID["+firmSetting.getFirmCode()+"]");
						return rtnData.toString();
					}
					mgr.insertFirmSetting(firmSetting); // 插入冻结
					setResultData("00000", null);
				}else{
					// 冻结是清交易员的Session
					if (firmSetting.getDISABLED() == 0){
						int code = ClearSessionUtil.clearSession(firmSetting.getFirmCode(), this.getUserId(), this.getMode(), this.getRequestId());
						if (code != 0){
							setResultData("30000", null,"交易商ID["+firmSetting.getFirmCode()+"]");
							return rtnData.toString();
						}
					}
					mgr.updateFirmSettingById(firmSetting);// 更新
					setResultData("00000", null);
				}
			}else{
				setResultData("10103",null, "传入冻结所需参数值不正确！");
				return rtnData.toString();
			}
		} catch (Exception e) {
			this.log.error("冻结交易商失败:"+e.getMessage());
			setResultData("10106", null, e.getMessage());
		}
		
		this.log.info(this.getClass().getName()+ " frozenOrrecoveryFirm() end");
		return rtnData.toString();
	}


	@Override
	public String disableOrEnableFirm(String params) {
		this.log.info(this.getClass().getName()+ " disableOrEnableFirm() Start");
		this.log.debug("disableOrEnableFirm Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		FirmSetting firmSetting = (FirmSetting) JsonUtil.jsonToBean(JOParams, FirmSetting.class);
		String userName = this.getUserName() == null ? "system" : (this.getUserName() == "") ? "system" : this.getUserName();
		firmSetting.setREC_CREATEBY(userName);
		firmSetting.setREC_MODIFYBY(userName);
		try {
			if(1 == firmSetting.getSettingType()){
				
				if (firmSetting.getId() == null || firmSetting.getId() == 0){
					mgr.insertFirmSetting(firmSetting); // 插入禁用
					setResultData("00000", null);
				}else{
					mgr.updateFirmSettingById(firmSetting);// 更新
					setResultData("00000", null);
				}
			}else{
				setResultData("10103",null, "传入禁用所需参数值不正确！");
				return rtnData.toString();
			}
		} catch (Exception e) {
			this.log.error("禁用交易商失败:"+e.getMessage());
			setResultData("10106", null, e.getMessage());
		}
		
		this.log.info(this.getClass().getName()+ " disableOrEnableFirm() end");
		return rtnData.toString();
	}


	@Override
	public String getIsNotRelationFrimListForShop(String params) {
		this.log.info(this.getClass().getName() + " getIsNotRelationFrimListForShop() Start");
		this.log.debug("JSONParams=" + params);
		List<FirmAllData> list = null;
		boolean bolRst = false;
		
		JSONObject JSONParams = new JSONObject(params);
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JSONParams);
		List<Condition> conditionsList = new ArrayList<Condition>();
		conditionsList.add(new Condition("firm.FirmID", "like", "", "string","firmID"));
		conditionsList.add(new Condition("firm.FirmName", "like", "", "string","firmName"));

		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(JSONParams, conditionsList, "");
		
		this.log.debug("qc=" + qc.toString());
		try {
			if (pageInfo == null){
				pageInfo = new PageInfo();
				pageInfo.setPageSize(20);
				pageInfo.setPageNo(1);
				pageInfo.addOrderField("firmId",false);
			}
			list = mgr.getIsNotRelationFrimListForShop(qc, pageInfo);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("获取未被关联过的交易商列表(商铺用) 失败！" + err.getMessage());
			setResultData("10105", null, err.getMessage());
		}			
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("获取未被关联过的交易商列表转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}

		}
		
		this.log.info(this.getClass().getName() + " getIsNotRelationFrimListForShop() End");
		return rtnData.toString();
	}


	/**
	 * 交易商销售配置列表
	 */
	@Override
	public String getFirmPositionLimit(String params) {
		this.log.info(this.getClass().getName() + " getFirmPositionLimit() Start");
		this.log.debug("JSONParams=" + params);
		List<FirmPositionLimitModel> list = null;
		boolean bolRst = false;
		//表头查询条件
		JSONObject JSONParams = new JSONObject(params);
		JSONObject queryModel =JSONParams.optJSONObject("queryModel");
		List<Condition> conditionsList = new ArrayList<Condition>();
		conditionsList.add(new Condition("t.firmID", "like", "", "string","firmID"));
		conditionsList.add(new Condition("t.FirmName", "like", "", "string","firmName"));
		String limit = JSONParams.optString("limit");

		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionsList, "");
		
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JSONParams);
		try {
//			list = mgr.getFirmPositionLimit(qc,pageInfo,limit);抛弃使用这个
			list = mgr.getFirmPositionLimitByTradeType(qc, pageInfo);//
			bolRst = true;
		} catch (Exception err) {
			this.log.error("查询交易商销售配置列表出错" + err.getMessage());
			setResultData("10105", null, err.getMessage());
		}			
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("交易商销售配置列表转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}

		}
		
		this.log.info(this.getClass().getName() + " getFirmPositionLimit() End");
		return rtnData.toString();
	}

	/**
	 * 交易商销售配置信息
	 */
	@Override
	public String getFirmPositionLimitByFirmID(String params) {
		this.log.info(this.getClass().getName() + " getFirmPositionLimitByFirmID() Start");
		this.log.debug("getFirmDetail Service Start debug");
		List<FirmPositionLimitModel> list = null;
		boolean bolRst = false;
		this.log.debug(params);
		JSONObject JOParams = new JSONObject(params);
		String firmId = JOParams.getString("firmID");		
		try {
			list = mgr.getFirmPositionLimitByFirmID(firmId);
			bolRst = true;
		} catch (Exception err) {  
			this.log.error("获取交易商销售配置信息出错" + err.getMessage());
			setResultData("10105", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("交易商销售配置列表转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}

		}
		
		this.log.info(this.getClass().getName() + " getFirmPositionLimitByFirmID() End");
		return rtnData.toString();
	}
	
	/**
	 * 更新交易商销售配置信息
	 */
	@Override
	public String updateFirmPositionLimitByFirmID(String params) {
		this.log.info(this.getClass().getName()+ " updateFirmPositionLimitByFirmID() Start");
		this.log.debug("updateFirmPositionLimitByFirmID Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		String firmID = JOParams.getString("firmID");
		//交易商销售配置信息:现货 /预售/期现
		List<FirmPositionLimitModel> list = new ArrayList<FirmPositionLimitModel>();
		JSONArray firmPositionLimitModelList = JOParams.getJSONArray("firmPositionLimitModelList");
		if (firmPositionLimitModelList.length() > 0) {
			for (int i = 0; i < firmPositionLimitModelList.length(); i++) {
				list.add((FirmPositionLimitModel)JsonUtil.jsonToBean((JSONObject) firmPositionLimitModelList.get(i), FirmPositionLimitModel.class));
			}
		}
		this.log.debug(params);
		String userName = this.getUserId() == null?"system":(this.getUserId().equals(""))?"system":this.getUserId();
		int returnCode;
		try {
			returnCode = this.mgr.updateFirmPositionLimitByFirmID(list,userName,firmID);
			if (returnCode >= 0) {
				setResultData("00000", null);
				this.log.businesslog("更新交易商销售配置信息成功",Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
			}else {
				setResultData("10106", null);
			}
		} catch (Exception e) {
			this.log.error("更新交易商销售配置信息出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("更新交易商销售配置信息出错"+e.getMessage(),Constants.OPE_MODE_MEMBER,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName()+ " updateFirmPositionLimitByFirmID() End");
		return rtnData.toString();
	}


	@Override
	public String selectShopFirmListByShopID(String params) {
		this.log.info(this.getClass().getName()+ " selectShopFirmListByShopID() Start");
		boolean bolRst=false;
		List<ShopFirm> list = null;
		try {
			JSONObject JSONParams = new JSONObject(params);
			List<Condition> conditionsList = new ArrayList<Condition>();
			conditionsList.add(new Condition("shopFirm.ShopID", "=", "", "int","id"));
			conditionsList.add(new Condition("shopFirm.IsMainFirm", "=", "", "int","isMainFirm"));
			QueryConditions qc = QueryHelper.getQueryConditionsFromJson(JSONParams, conditionsList, "");
			list = this.mgr.selectShopFirmListByShopID(qc, null);
			bolRst=true;
		} catch (Exception e) {
			this.log.error("获取关联交易商列表信息失败:"+e.getMessage());
			setResultData("10105", null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("关联交易商列表信息列表转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}

		}
		this.log.info(this.getClass().getName()+ " selectShopFirmListByShopID() end");
		return rtnData.toString();
	
	}
	
//	/**
//	 * 清除交易商下的所有交易员的session
//	 * @param firmID
//	 * @return
//	 */
//	private int clearFirmOfTraderSession(String firmID,String authkeyid){
//		int code = 0;
//		try {
//			Map<String,String> map =  new HashMap<String,String>();
//			map.put("Pattern", firmID);
//			/**
//			 * 调用.Net的清除交易商下的所有交易员的方法
//			 */
//			String postData = RemoteCallUtil.generateData("ClearRedisKeys", "Shcem.Member.ServiceContract.IClientLoginService",map,authkeyid);
//			JSONObject jsonObj = RemoteCallUtil.postData(postData, this.getMode());
//				
//			if (!"00000".equals(jsonObj.getString("CODE"))){
//				code = -1;
//			}
//		} catch (Exception e) {
//			code = -1;
//		}
//		return code;
//	}
}

