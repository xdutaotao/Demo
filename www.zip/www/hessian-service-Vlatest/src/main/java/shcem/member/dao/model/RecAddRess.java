package shcem.member.dao.model;

import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**收票地址
 * (C_ADDRESS)
 * 
 * @author bianj
 * @version 1.0.0 2016-05-23
 */
public class RecAddRess extends BaseObject implements java.io.Serializable {
    /** 版本号 */
    private static final long serialVersionUID = -2014177803859559405L;
    
    /**  */
    private String id;
    private Integer recAddressID;
    
    /**  */
    private Integer recPV;
    
    /**  */
    private Integer recCT;
    
    /**  */
    private Integer recDT;
    
    /**  */
    private String recAddress;
    
    /**  */
    private Integer disabled;
    
    /**  */
    private String recContactName;
    
    /**  */
    private String recContactTelNo;
    
    /**  */
    private Date createTime;
    
    /**  */
    private Date updateTime;
    
    private String recPVName;
    
    private String recCTName;
    
    private String recDTName;
    
    //地址类型    0:收票地址，1:收货地址
    private Integer addressType;
    
    //交易商id
    private String firmID;
    
	public String getRecCTName() {
		return recCTName;
	}

	public void setRecCTName(String recCTName) {
		this.recCTName = recCTName;
	}

	public String getRecDTName() {
		return recDTName;
	}

	public void setRecDTName(String recDTName) {
		this.recDTName = recDTName;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getRecPV() {
		return recPV;
	}

	public void setRecPV(Integer recPV) {
		this.recPV = recPV;
	}

	public Integer getRecCT() {
		return recCT;
	}

	public void setRecCT(Integer recCT) {
		this.recCT = recCT;
	}

	public Integer getRecDT() {
		return recDT;
	}

	public void setRecDT(Integer recDT) {
		this.recDT = recDT;
	}

	public String getRecAddress() {
		return recAddress;
	}

	public void setRecAddress(String recAddress) {
		this.recAddress = recAddress;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public String getRecContactName() {
		return recContactName;
	}

	public void setRecContactName(String recContactName) {
		this.recContactName = recContactName;
	}

	public String getRecContactTelNo() {
		return recContactTelNo;
	}

	public void setRecContactTelNo(String recContactTelNo) {
		this.recContactTelNo = recContactTelNo;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Integer getAddressType() {
		return addressType;
	}

	public void setAddressType(Integer addressType) {
		this.addressType = addressType;
	}

	public String getRecPVName() {
		return recPVName;
	}

	public void setRecPVName(String recPVName) {
		this.recPVName = recPVName;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public Integer getRecAddressID() {
		return recAddressID;
	}

	public void setRecAddressID(Integer recAddressID) {
		this.recAddressID = recAddressID;
	}

}