/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IFirmService
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.service;

/**
 * @author wlpod
 *
 */
public interface IFirmService {
	
	/**查询交易商列表
	 * 2016年5月17日 下午3:42:14
	 * @return
	 * 张楠/Nany
	 */
	public String getFirmList(String params);
	/**查询交易商
	 * 2016年5月17日 下午3:42:04
	 * @param params
	 * @return
	 * 张楠/Nany
	 */
	public String getFirmDetail(String params);
	/**修改交易商信息
	 * 2016年5月17日 下午4:17:30
	 * @param params
	 * @return
	 * 张楠/Nany
	 */
	public String updateFirmInfo(String params);
	/**增加交易商信息(用户代理注册，直接认为审核通过)
	 * 2016年5月17日 下午5:47:32
	 * @param params
	 * @return
	 * 张楠/Nany
	 */
	public String register(String params);
	/**获取交易商注册列表信息
	 * 2016年5月20日 上午13:43:32
	 * @param params
	 * @return
	 * 张楠/Nany
	 */
	public String getRegisteredFirmList(String params);
	/**获取交易商注册详细信息
	 * 2016年5月20日 上午14:23:32
	 * @param params
	 * @return
	 * 张楠/Nany
	 */
	public String getRegisteredFirmDetail(String params);
	
	/**审核后，交易商情报更新
	 * 2016年5月23日 上午10:23:32
	 * @param params
	 * @return
	 * 张楠/Nany
	 */
	public String registerFirmInfo(String params);
	
	/**禁用交易商
	 * 2016年5月24日 上午18:25:32
	 * @param params
	 * @return
	 * 张楠/Nany
	 */
	public String disableFirm(String params);
	
	/**拒绝通过审核
	 * 2016年5月24日 上午18:25:32
	 * @param params
	 * @return
	 * 张楠/Nany
	 */
	public String rejectFirmInfo(String params);
	/**验证交易商编码是否已存在
	 * @param params
	 * @return
	 */
	public String checkFirmID(String params);
	/**验证交易商编码是否已存在
	 * @param params
	 * @return
	 */
	public String checkFirmName(String params);
	/**验证交易员编码是否已存在
	 * @param params
	 * @return
	 */
	public String checkTraderID(String params);
	/**验证交易商全称
	 * @param params
	 * @return
	 */
	public String checkFullName(String params);
	/**产生推荐的交易商编号
	 * @param params
	 * @return
	 */
	public String GetNewFirmIDByZone(String params);
	/**
	 * 客服审核通过交易商注册信息
	 * @param params
	 * @return
	 */
	public String updateFirmRegister(String params);
	/**
	 * 交易商收票/收货地址信息
	 * @param params
	 * @return
	 */
	public String getFirmRecAddressList(String params);
	/**
	 * 新增 交易商收票/收货地址
	 * @param params
	 * @return
	 */
	public String addRecAddress(String params);
	/**
	 * 批量删除 交易商收票/收货地址
	 * @param params
	 * @return
	 */
	public String delAddressList(String params);
	/**
	 * 获取 交易商收票/收货地址 详情
	 * @param params
	 * @return
	 */
	public String getFirmRecAddressByID(String params);
	/**
	 * 修改 交易商收票/收货地址
	 * @param params
	 * @return
	 */
	public String updateRecAddress(String params);
	/**
	 * 禁用/启用地址
	 * @param params
	 * @return
	 */
	public String disabledRecAddress(String params);
	/**
	 * 化纤平台交易商同步到化交平台
	 * @param params
	 * @return
	 */
	public String synchronizeFrim(String params);
	
	/**
	 * 添加 交易商注册信息
	 * @param firmRegister
	 */
	public String addFirmRegister(String params);
	
	/**
	 * 更新 交易商 的审核 状态
	 * @param firmId
	 * @param firmStatus
	 */
	public String updateCFirmOfFirmStatus(String params);

	/**
	 * 获取商铺列表
	 * @param params
	 * @return
	 */
	public String getshopList(String params);

	/**
	 * 新增or修改商铺信息
	 * @param params
	 * @return
	 */
	public String saveOrupdateShop(String params);

	/**
	 * 获取商铺信息
	 * @param params
	 * @return
	 */
	public String getShopInfo(String params);

	/**
	 * 更改商铺状态
	 * @param param
	 * @return
	 */
	public String resetShopState(String params);
	
	/**
	 * 冻结或恢复交易商
	 * @param params
	 * @return
	 */
	public String frozenOrrecoveryFirm(String params);
	
	/**
	 * 禁用或启用交易商
	 * @param params
	 * @return
	 */
	public String disableOrEnableFirm(String params);
	/**
	 * 交易商销售配置列表
	 * @param params
	 * @return
	 */
	public String getFirmPositionLimit(String params);
	/**
	 * 交易商销售配置信息详情
	 * @param params
	 * @return
	 */
	public String getFirmPositionLimitByFirmID(String params);
	
	/**
	 * 获取未被关联过的交易商列表(商铺用)
	 * @param params
	 * @return
	 */
	public String getIsNotRelationFrimListForShop(String params);
	/**
	 * 更新交易商销售配置信息
	 * @param params
	 * @return
	 */
	public String updateFirmPositionLimitByFirmID(String params);
	
	/**
	 * 通过店铺ID关联的获取关联过的交易商列表
	 * @param params
	 * @return
	 */
	public String selectShopFirmListByShopID(String params);
}
