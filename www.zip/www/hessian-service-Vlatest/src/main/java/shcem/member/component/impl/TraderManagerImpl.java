/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: TraderManagerImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.component.impl;

import java.util.List;
import java.util.Map;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.dao.CommonDAO;
import shcem.member.component.ITraderManager;
import shcem.member.dao.TraderDAO;
import shcem.member.dao.UserDAO;
import shcem.member.dao.model.TradeAllData;
import shcem.member.dao.model.Trader;
import shcem.member.dao.model.TraderDataList;
import shcem.member.dao.model.TraderTmptRlsp;
import shcem.member.dao.model.User;
import shcem.member.service.model.userMobileModel;
import shcem.member.util.ClearSessionUtil;
import shcem.trade.dao.LeadsDAO;
import shcem.trade.dao.model.Leads;
import shcem.util.EncrypMD5;

/**
 * @author wlpod
 *
 */
public class TraderManagerImpl extends BaseManager implements ITraderManager {

	private TraderDAO dao;
	private TraderDAO traderDAO_read;
	private UserDAO userDAO;
	private LeadsDAO leadsDAO_read;
	private CommonDAO commonDao_read;

	public void setUserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}

	@Override
	public void setTraderDAO(TraderDAO dao) {
		this.dao = dao;
	}

	public void setTraderDAO_read(TraderDAO traderDAO_read) {
		this.traderDAO_read = traderDAO_read;
	}
	
	public void setLeadsDAO_read(LeadsDAO leadsDAO_read) {
		this.leadsDAO_read = leadsDAO_read;
	}
	
	public void setCommonDao_read(CommonDAO commonDao_read) {
		this.commonDao_read = commonDao_read;
	}

	@Override
	public List<TraderDataList> getTraderList(QueryConditions qc, PageInfo pageInfo, String firmID) {
		return this.traderDAO_read.getTraderList(qc, pageInfo, firmID);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.member.component.ITraderManager#getTrader(java.lang.String)
	 */
	@Override
	public TradeAllData getTrader(String traderID) {
		TradeAllData tradeAllData = this.traderDAO_read.getTrader(traderID);
		List<TraderTmptRlsp> traderTmptRlspList = this.traderDAO_read.getTraderTmptRlspList(traderID);
		tradeAllData.setTraderTmptRlspList(traderTmptRlspList);
		return tradeAllData;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * shcem.member.component.ITraderManager#addTrader(shcem.member.dao.model.
	 * Trader)
	 */
	@Override
	public int addTrader(Trader trader, int[] traderTmptRlsps) throws RuntimeException {
		int returnCode = 0;
		trader.setTraderPassword(EncrypMD5.eccrypt("111111"));
		trader.setRecCreateBy("");// 后台操作人员，存到session里
		trader.setRecModifyBy("");
		/**
		 * 校验该用户是否已经被别的交易商绑定
		 */
		List<Trader> list = this.dao.getTraderByUserCode(trader.getUserCode());
		if (list != null && list.size() > 0) {
			returnCode = -1;
		}
		returnCode = this.dao.addTrader(trader);
		this.addTraderTmptRlsps(traderTmptRlsps, trader.getTraderID());
		return returnCode;
	}

	/**
	 * 更新交易商交易员 returnCode: 1:正确 0：正确 -1：该用户已经被别的交易商绑定
	 */
	@Override
	public int updateTrader(Trader trader, int[] traderTmptRlsps, String mode, String userName, String requestId)
			throws RuntimeException {
		trader.setRecModifyBy("");// 后台操作人员，存到session里
		/**
		 * 更新前 在确定绑定的用户改变的前提下 判断是否 用户已经被别的交易商绑定
		 */
		int returnCode = 0;
		List<Trader> list = this.dao.getTraderByUserCode(trader.getUserCode());
		if (list != null) {
			if (list.size() > 0) {
				// 更新交易员信息，要绑定的用户没有更改
				if (list.get(0).getTraderID().equals(trader.getTraderID())) {
					returnCode = this.dao.updateTrader(trader);
				} else {// 该用户已经被别的交易商绑定
					returnCode = -1;
				}
			} else {
				returnCode = this.dao.updateTrader(trader);
			}
		} else {
			returnCode = this.dao.updateTrader(trader);
		}
		/**
		 * 编辑的时候，如果禁用交易商，同时其绑定的用户也要禁用
		 */
		if (trader.getUserCode() != null && trader.getDisabled() == 1) {
			this.userDAO.disableUser(trader.getUserCode());
		}
		if (trader.getIsClearSession()) {
			returnCode = ClearSessionUtil.clearSession(trader.getTraderID(), userName, mode, requestId);
			if (returnCode == -1) {
				this.rollBack();
				return returnCode;
			}
		}
		this.addTraderTmptRlsps(traderTmptRlsps, trader.getTraderID());
		return returnCode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * shcem.member.component.ITraderManager#disableTrader(java.lang.String)
	 */
	@Override
	public int disableTrader(String traderID, boolean whetherDisableUser) throws RuntimeException {
		TradeAllData trader = this.dao.getTrader(traderID);
		int row = this.dao.disableTrader(traderID);
		// if (whetherDisableUser) {
		// 同时禁用用户
		row = this.userDAO.disableUser(trader.getUserCode());
		// }
		return row;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.member.component.ITraderManager#enableTrader(java.lang.String)
	 */
	@Override
	public int enableTrader(String traderID) {
		int row = this.dao.enableTrader(traderID);
		TradeAllData trader = this.dao.getTrader(traderID);
		// 同时启用绑定的用户
		if (trader.getUserCode() != null && !trader.getUserCode().equals("")) {
			row = this.userDAO.enableUser(trader.getUserCode());
		}

		return row;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.member.component.ITraderManager#checkUserIDExisted(java.lang.
	 * String)
	 */
	@Override
	public boolean checkUserIDExisted(String userCode) {

		return false;
	}

	@Override
	public int Unbundling(String tradeID) throws RuntimeException {
		return this.dao.Unbundling(tradeID);
	}

	/**
	 * 交易员交易场权限
	 * 
	 * @param traderTmptRlsps
	 * @param traderID
	 * @throws RuntimeException
	 */
	private void addTraderTmptRlsps(int[] traderTmptRlsps, String traderID) throws RuntimeException {
		this.dao.delTraderTmptRlsps(traderID);
		TraderTmptRlsp traderTmptRlsp = new TraderTmptRlsp();
		traderTmptRlsp.setTraderID(traderID);
		traderTmptRlsp.setEnabled("Y");
		if (traderTmptRlsps != null && traderTmptRlsps.length > 0) {
			for (int i = 0; i < traderTmptRlsps.length; i++) {
				traderTmptRlsp.setTradeTmptId(traderTmptRlsps[i]);
				this.dao.addTraderTmptRlsps(traderTmptRlsp);
			}
		}
	}

	@Override
	public int bindTrader(Trader trader) {
		TradeAllData traders = this.dao.getTrader(trader.getTraderID());
		traders.setRecModifyBy("");
		traders.setUserCode(trader.getUserCode());
		User user = this.dao.getUserById(trader.getUserCode());
		return this.dao.bindUser(traders, user);
	}

	/**
	 * 手动回滚事务
	 */
	private void rollBack() {
		this.dao.rollBack();
	}

	@Override
	public int updateTraderStatusByTraderID(Trader trader, String exeUsername) {
		return this.dao.updateTraderStatusByTraderID(trader, exeUsername);
	}

	@Override
	public List<TraderDataList> getTraderList(QueryConditions qc, PageInfo pageInfo) {
		this.log.debug(this.getClass().getName() + "getTraderList Start");
		return this.traderDAO_read.getTraderList(qc, pageInfo);
	}

	@Override
	public List<userMobileModel> queryUserMobileList(QueryConditions qc, PageInfo pageInfo, String userCode) {
		this.log.debug(this.getClass().getName() + "queryUserMobileList Start");
		return this.traderDAO_read.queryUserMobileList(qc, pageInfo, userCode);
	}

	@Override
	public int addUserMobile(String moreMobile, String userCode, String userName) {
		this.log.debug(this.getClass().getName() + "addUserMobile Start");
		int sameMobile = this.dao.getSameMobile(moreMobile, userCode);
		if (sameMobile > 0) {
			return -20004;
		}
		int count = this.dao.getMobileCount(userCode);
		if (count > 18) {
			return -20003;
		}
		return this.dao.addUserMobile(moreMobile, userCode, userName);
	}

	@Override
	public int changeUserMobile(int id, String moreMobile, String userName) {
		this.log.debug(this.getClass().getName() + "changeUserMobile Start");
		return this.dao.changeUserMobile(id, moreMobile, userName);
	}

	@Override
	public int unBindUserMobile(int id) {
		this.log.debug(this.getClass().getName() + "unBindUserMobile Start");
		return this.dao.unBindUserMobile(id);
	}

	/**
	 * 聊天用（检查交易员及报盘的有效状态）
	 * 
	 * @param traderCode
	 * @param leadsCode
	 * @param rtnMap
	 * @return
	 */
	@Override
	public String checkIMAuth(String traderCode, String leadsCode, Map<String, String> rtnMap) {

		this.log.debug(this.getClass().getName() + " checkIMAuth Start");

		String rtnMsg = null;

		String rtnMsg1 = "当前报盘无法交易，不能发起在线咨询。";
		String rtnMsg2 = "当前报盘已经失效，不能发起在线咨询。";
		String rtnMsg3 = "很抱歉，由于您权限不足，不能发起在线咨询。";

		/**
		 * 1）报盘状态为“有效” 2）判断该报盘已经成交/撤销的时，提示“当前报盘无法交易，不能发起在线咨询。”
		 * 3）判断该报盘已经失效的时，提示“当前报盘已经失效，不能发起在线咨询。”
		 * 4）只有已经登录的具有当前报盘交易权限的用户才能发起“在线咨询”，否则提示“很抱歉，由于您权限不足，不能发起在线咨询。”
		 */
		// 取得报盘状态
		QueryConditions qc = new QueryConditions();
		qc.addCondition("leadsCode", "=", leadsCode);

		PageInfo pageInfo = new PageInfo();
		pageInfo.setPageSize(10);
		pageInfo.setPageNo(1);

		List<Leads> leads = this.leadsDAO_read.getLeadsList(qc, pageInfo);
		Leads lead = null;
		if (leads.size() > 0) {
			lead = leads.get(0);
		} else {
			rtnMsg = rtnMsg1;
		}

		/**
		 * 2,3报盘校验
		 */
		if (rtnMsg == null) {
			if (lead.getLeadsStatus().intValue() == 10 || lead.getLeadsStatus().intValue() == 99) {
				// 判断该报盘已经成交/撤销的时，提示“当前报盘无法交易，不能发起在线咨询。”
				rtnMsg = rtnMsg1;
			} else if (lead.getLeadsStatus().intValue() == 1) {
				// 判断该报盘已经失效的时，提示“当前报盘已经失效，不能发起在线咨询。”
				rtnMsg = rtnMsg2;
			}
		}

		/**
		 * 4 交易员权限校验
		 */
		if (rtnMsg == null) {
			
			/*交易场ID*/
			String tmplID = String.valueOf(lead.getTradeTmptID());
			/*交易品类ID*/
			Integer cateID = lead.getCategoryLeafID();
			/*交易牌号ID*/
			Integer brandID = lead.getBrandID();
			/*交易买卖方向：0卖  1买*/
			/**
			 * 20170911 现货默认买卖方向为1
			 */
//			int tradeRole = lead.getDirection();
			int tradeRole = 1;

			// 交易员交易场权限
			boolean tradeAuth = this.commonDao_read.ChkAuthByTraderID(traderCode, tmplID, cateID, brandID, tradeRole, 0);

			if (!tradeAuth) {
				
				// 没有当前报盘交易权限，否则提示“很抱歉，由于您权限不足，不能发起在线咨询。”
				rtnMsg = rtnMsg3;
			} else {
				
				// 取得该报盘的
				rtnMap.put("roomMaster", lead.getTradeID());
			}
		}

		this.log.debug(this.getClass().getName() + " checkIMAuth end");

		return rtnMsg;
	}
}
