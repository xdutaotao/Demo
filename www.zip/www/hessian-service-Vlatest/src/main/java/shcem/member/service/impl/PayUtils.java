package shcem.member.service.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.ConnectException;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.json.JSONObject;

import com.github.wxpay.sdk.WXPayUtil;

import scala.Console;

public class PayUtils {
	
	/**
	 * 创建支付订单
	 * @param appid
	 * @param mchID
	 * @param fee
	 * @param notifyUrl
	 * @param ip
	 * @param openId
	 * @return
	 */
	public static Map<String, String> createPayInfo(BigDecimal fee, String num, 
			String notifyUrl,String ip, String openId){
		Map<String, String> map = new HashMap<String, String>();
		map.put("device_info", "WEB");
		map.put("nonce_str", WXPayUtil.generateNonceStr());
		map.put("body", "上海化交用户交流会");
		map.put("out_trade_no", num);
		map.put("total_fee", fee.intValue()+"");
		map.put("spbill_create_ip", ip);
		map.put("notify_url", notifyUrl);
		map.put("trade_type", "JSAPI");
		map.put("openid", openId);
		return map;
	}
    
    /**
     * 获取ip地址
     * @param request
     * @return
     */
    public static String getIpAddr() { 
//    	HessianHeaderContext context = HessianHeaderContext.getContext();
//    	return context.getHeader(Constants.HEADER_CLIENT_IP) == null ? "" : context
//    	        .getHeader(Constants.HEADER_CLIENT_IP);
    	return "192.168.207.126";
    }
    
    /**
     * 商户订单号  
     * @return
     */
    public static String getOutTradeNo(){
    	SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
    	String outTradeNo = format.format(new Date()) + WXPayUtil.generateNonceStr();
    	return outTradeNo.substring(0, 31);
    }
    
    /**
     * http  请求
     * @param requestUrl
     * @param requestMethod
     * @param outputStr
     * @return
     */
    public static JSONObject httpsRequestToJsonObject(String requestUrl, String requestMethod, String outputStr) {
        JSONObject jsonObject = null;
        try {
             StringBuffer buffer = httpsRequest(requestUrl, requestMethod, outputStr);
            jsonObject = new JSONObject(buffer.toString());
        } catch (ConnectException ce) {
        	Console.println("连接超时："+ce.getMessage());
        } catch (Exception e) {
        	Console.println("https请求异常："+e.getMessage());
        }
        return jsonObject;
    }
    
    /**
     * Http  网络请求
     * @param requestUrl
     * @param requestMethod
     * @param output
     * @return
     * @throws NoSuchAlgorithmException
     * @throws NoSuchProviderException
     * @throws KeyManagementException
     * @throws MalformedURLException
     * @throws IOException
     * @throws ProtocolException
     * @throws UnsupportedEncodingException
     */
    private static StringBuffer httpsRequest(String requestUrl, String requestMethod, String output)
            throws NoSuchAlgorithmException, NoSuchProviderException, KeyManagementException, MalformedURLException,
            IOException, ProtocolException, UnsupportedEncodingException {
        
        URL url = new URL(requestUrl);
        HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
        
        connection.setDoOutput(true);
        connection.setDoInput(true);
        connection.setUseCaches(false);
        connection.setRequestMethod(requestMethod);
        if (null != output) {
            OutputStream outputStream = connection.getOutputStream();
            outputStream.write(output.getBytes("UTF-8"));
            outputStream.close();
        }

        // 从输入流读取返回内容
        InputStream inputStream = connection.getInputStream();
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "utf-8");
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
        String str = null;
        StringBuffer buffer = new StringBuffer();
        while ((str = bufferedReader.readLine()) != null) {
            buffer.append(str);
        }

        bufferedReader.close();
        inputStreamReader.close();
        inputStream.close();
        inputStream = null;
        connection.disconnect();
        return buffer;
   }
    
    
    /**
     * 算出签名
     * @param jsapi_ticket 
     * @param url 业务中调用微信js的地址
     * @return
     */
    public static Signature sign(String jsapi_ticket, String url) {
        String nonce_str = WXPayUtil.generateNonceStr();
        String timestamp = String.valueOf(System.currentTimeMillis()/1000);
        String string1;
        String signature = "";

        //注意这里参数名必须全部小写，且必须有序
        string1 = "jsapi_ticket=" + jsapi_ticket +
                  "&noncestr=" + nonce_str +
                  "&timestamp=" + timestamp +
                  "&url=" + url;
        try
        {
            MessageDigest crypt = MessageDigest.getInstance("SHA-1");
            crypt.reset();
            crypt.update(string1.getBytes("UTF-8"));
            signature = new String(crypt.digest());
        }
        catch (NoSuchAlgorithmException e)
        {
            e.printStackTrace();
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
        
        Signature result = new Signature();
        result.setUrl(url);
        result.setJsapi_ticket(jsapi_ticket);
        result.setNonceStr(nonce_str);
        result.setTimestamp(timestamp);
        result.setSignature(signature);

        return result;
    }
    
    
}
