package shcem.member.util;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;

import com.alibaba.fastjson.JSON;

import shcem.util.RemoteCallUtil;

public class RemoteMbappUtil {

	/**
	 * 获取订单总价
	 * @param orderId  订单id
	 * @param authkeyid 用户ID（暂为空）
	 * @param mode
	 * @return 订单总价
	 */
	public static BigDecimal getOrderSum(String orderId,String authkeyid,String mode, String GUID){
		BigDecimal sum  = BigDecimal.ZERO;
		try {
			Map<String,String> map =  new HashMap<String,String>();
			map.put("orderId", orderId);
			/**
			 * 调用mbapp获取订单总价
			 */
			String postData = RemoteCallUtil.generateData("getOrderInfoById", "mbapp.weixin.service.IOrderService",map,authkeyid);
			JSONObject jsonObj = RemoteCallUtil.postData(postData, mode, GUID);
				
			if (!"INFO0000".equals(jsonObj.getString("CODE"))){
				return BigDecimal.valueOf(-1);
			} else {
				JSONObject dataJSO = new JSONObject(jsonObj.getString("DATA"));
				if (!dataJSO.isNull("result")) {
					List<WOrderSearchResult> list = JSON.parseArray(dataJSO.get("result").toString(), WOrderSearchResult.class);
					for (WOrderSearchResult result:list) {
						sum = sum.add(result.getTotal());
					}
				}
			}
		} catch (Exception e) {
			return BigDecimal.valueOf(-1);
		}
		return sum.multiply(new BigDecimal(100));
	}
	
	public static void main(String[] args) {
		getOrderSum("123", "test", "local", "sdajlfjdoafjoewjfejw");
	}
}
