/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: Firm
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.dao.model;

import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * (M_FIRM)
 * 
 * @author bianj
 * @version 1.0.0 2016-05-06
 */
public class Firm extends BaseObject implements java.io.Serializable {
	/** 版本号 */

	private static final long serialVersionUID = 1L;

	/**  */
	private String firmid;

	/**  */
	private String name;

	/**  */
	private String fullname;

	/**  */
	private Integer type;

	/**  */
	private String bank;

	/**  */
	private String status;

	/**  */
	private String bankaccount;

	/**  */
	private String address;

	/**  */
	private String contactman;

	/**  */
	private String phone;

	/**  */
	private String fax;

	/**  */
	private String postcode;

	/**  */
	private String email;

	/**  */
	private String note;

	/**  */
	private String zonecode;

	/**  */
	private String industrycode;

	/**  */
	private String extenddata;

	/**  */
	private Date createtime;

	/**  */
	private Date modifytime;
	/**
	 * 交易商当前余额
	 */
	private BigDecimal balance;

	/**
	 * 获取firmid
	 * 
	 * @return firmid
	 */
	public String getFirmid() {
		return this.firmid;
	}

	/**
	 * 设置firmid
	 * 
	 * @param firmid
	 *            firmid
	 */
	public void setFirmid(String firmid) {
		this.firmid = firmid;
	}

	/**
	 * 获取name
	 * 
	 * @return name
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * 设置name
	 * 
	 * @param name
	 *            name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 获取fullname
	 * 
	 * @return fullname
	 */
	public String getFullname() {
		return this.fullname;
	}

	/**
	 * 设置fullname
	 * 
	 * @param fullname
	 *            fullname
	 */
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	/**
	 * 获取type
	 * 
	 * @return type
	 */
	public Integer getType() {
		return this.type;
	}

	/**
	 * 设置type
	 * 
	 * @param type
	 *            type
	 */
	public void setType(Integer type) {
		this.type = type;
	}

	/**
	 * 获取bank
	 * 
	 * @return bank
	 */
	public String getBank() {
		return this.bank;
	}

	/**
	 * 设置bank
	 * 
	 * @param bank
	 *            bank
	 */
	public void setBank(String bank) {
		this.bank = bank;
	}

	/**
	 * 获取status
	 * 
	 * @return status
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * 设置status
	 * 
	 * @param status
	 *            status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * 获取bankaccount
	 * 
	 * @return bankaccount
	 */
	public String getBankaccount() {
		return this.bankaccount;
	}

	/**
	 * 设置bankaccount
	 * 
	 * @param bankaccount
	 *            bankaccount
	 */
	public void setBankaccount(String bankaccount) {
		this.bankaccount = bankaccount;
	}

	/**
	 * 获取address
	 * 
	 * @return address
	 */
	public String getAddress() {
		return this.address;
	}

	/**
	 * 设置address
	 * 
	 * @param address
	 *            address
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * 获取contactman
	 * 
	 * @return contactman
	 */
	public String getContactman() {
		return this.contactman;
	}

	/**
	 * 设置contactman
	 * 
	 * @param contactman
	 *            contactman
	 */
	public void setContactman(String contactman) {
		this.contactman = contactman;
	}

	/**
	 * 获取phone
	 * 
	 * @return phone
	 */
	public String getPhone() {
		return this.phone;
	}

	/**
	 * 设置phone
	 * 
	 * @param phone
	 *            phone
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * 获取fax
	 * 
	 * @return fax
	 */
	public String getFax() {
		return this.fax;
	}

	/**
	 * 设置fax
	 * 
	 * @param fax
	 *            fax
	 */
	public void setFax(String fax) {
		this.fax = fax;
	}

	/**
	 * 获取postcode
	 * 
	 * @return postcode
	 */
	public String getPostcode() {
		return this.postcode;
	}

	/**
	 * 设置postcode
	 * 
	 * @param postcode
	 *            postcode
	 */
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	/**
	 * 获取email
	 * 
	 * @return email
	 */
	public String getEmail() {
		return this.email;
	}

	/**
	 * 设置email
	 * 
	 * @param email
	 *            email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * 获取note
	 * 
	 * @return note
	 */
	public String getNote() {
		return this.note;
	}

	/**
	 * 设置note
	 * 
	 * @param note
	 *            note
	 */
	public void setNote(String note) {
		this.note = note;
	}

	/**
	 * 获取zonecode
	 * 
	 * @return zonecode
	 */
	public String getZonecode() {
		return this.zonecode;
	}

	/**
	 * 设置zonecode
	 * 
	 * @param zonecode
	 *            zonecode
	 */
	public void setZonecode(String zonecode) {
		this.zonecode = zonecode;
	}

	/**
	 * 获取industrycode
	 * 
	 * @return industrycode
	 */
	public String getIndustrycode() {
		return this.industrycode;
	}

	/**
	 * 设置industrycode
	 * 
	 * @param industrycode
	 *            industrycode
	 */
	public void setIndustrycode(String industrycode) {
		this.industrycode = industrycode;
	}

	/**
	 * 获取extenddata
	 * 
	 * @return extenddata
	 */
	public String getExtenddata() {
		return this.extenddata;
	}

	/**
	 * 设置extenddata
	 * 
	 * @param extenddata
	 *            extenddata
	 */
	public void setExtenddata(String extenddata) {
		this.extenddata = extenddata;
	}

	/**
	 * 获取createtime
	 * 
	 * @return createtime
	 */
	public Date getCreatetime() {
		return this.createtime;
	}

	/**
	 * 设置createtime
	 * 
	 * @param createtime
	 *            createtime
	 */
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	/**
	 * 获取modifytime
	 * 
	 * @return modifytime
	 */
	public Date getModifytime() {
		return this.modifytime;
	}

	/**
	 * 设置modifytime
	 * 
	 * @param modifytime
	 *            modifytime
	 */
	public void setModifytime(Date modifytime) {
		this.modifytime = modifytime;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}
}