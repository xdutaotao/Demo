/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：app微信
 * File Name: UserDAO.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年12月2日 　喻剑平   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.dao;

import shcem.base.dao.DAO;
import shcem.member.dao.model.UserWeiXin;

/**
 * @author jampion
 *
 */
public abstract interface WeiXinKeyWordDAO extends DAO {
	
	/**
	 * 获取用户详情
	 * @param openId openid
	 * @return
	 */
	public abstract UserWeiXin getUserByOpenID(String openId);
	
	/**
	 * 获取用户详情
	 * @param userCode 用户id
	 * @return
	 */
	public abstract UserWeiXin getUserByUserCode(String userId);
	
	/**
	 * 获取用户详情
	 * @param mobile 手机号
	 * @return
	 */
	public abstract UserWeiXin getUserByMobile(String mobile);
	
	/**
	 * 新增用户和微信绑定关系
	 * 
	 * @param userWeiXin
	 * @return
	 */
	public abstract void addUserWeiXinRelation(UserWeiXin userWeiXin);
	
	/**
	 * 
	 * 添加微信授权信息
	 * */
	public abstract void addWeiXinInfo(UserWeiXin userWeiXin);


	/**
	 * 新增用户和微信绑定关系
	 * 
	 * @param userWeiXin
	 * @return
	 */
	public abstract void updateUserWeiXinAddRelation(UserWeiXin userWeiXin);
}
