/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmDetaiData
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.dao.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import shcem.base.dao.model.BaseObject;

/**交易商所有信息
 * @author zhangnan
 *
 */
public class FirmDetaiData extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8821098237888604513L;

	 /**  */
    private String firmRegId;
    
    /**  */
    private String firmName;
    
    /**  */
    private String fullName;
    
    /**  */
    private Integer firmType;
    
    /**  */
    private Integer businessType;
    
    /**  */
    private Integer disabled;
    
    /**  */
    private Integer firmStatus;
    
    /**  */
    private String address;
    
    /**  */
    private String fax;
    
    /**  */
    private String postCode;
    
    /**  */
    private String contactName;
    
    /**  */
    private String contactTelNo;
    
    /**  */
    private String contactMobile;
    
    /**  */
    private Integer bSLicense;
    
    /**  */
    private Integer taxLicense;
    
    /**  */
    private Integer orgCode;
    
    /**  */
    private Integer unifyLicense;
    
    /**  */
    private Integer dGLicense;
    
    /**  */
    private Integer settingBankID;
    
    /**  */
    private String settingBkBranch;
    
    /**  */
    private String settingBkAccount;
    
    /**  */
    private Integer vatBankID;
    
    private String vatBankName;
    
    /**  */
    private String vatBkBranch;
    
    /**  */
    private String vatBkAccount;
    
    /**  */
    private Integer vatPV;
    
    /**  */
    private Integer vatCT;
    
    /**  */
    private Integer vatDT;
    
    /**  */
    private String vatAddress;
    
    /**  */
    private String taxNo;
    
    /**  */
    private String vatContactTelNo;
    
    /**  */
    private Integer recPV;
    
    /**  */
    private Integer recCT;
    
    /**  */
    private Integer recDT;
    
    /**  */
    private String recAddRess;
    
    /**  */
    private String recContactName;
    
    /**  */
    private String recContactTelNo;
    
    /**  */
    private String recCreateby;
    
    /**  */
    private Date recCreateTime;
    
    /**  */
    private String recModifyby;
    
    /**  */
    private Date recModifyTime;
    
    //拓展属性
    private String firmID;
    
    private String note;
    
    private String bSEntityName;
    
    private String bSEntityTelNo;
    
    private String bSLicenseNo;
    
    private String registerCapiTal;
    
    private String taxRegisterNo;
    
    private String organizationCd;
    
    private String unifyLicenseNo;
    
    private String dGLicenseNo;
    
    //注册标志 前台注册/后台代理注册
    private String flag;
    
    //开票地址信息
    private RecAddRess recAddRessBean;
    //开票地址信息
    private VatAddRess vatAddRessBean;
    //交易商明细
    private FirmDetail firmDetailBean;
    //交易商接收地址信息
    private Firminvoice FirminvoiceBean;
    //交易商增值税开票信息表
    private Firmvatinfo firmvatinfoBean;
    //申请人认证
    private String requestUserId;
    //申请人是否自动绑定为管理员
    private Integer whetherToBind;
    //证照区分	0: 三证，1:综合证
    private Integer licenseDiffer;
    
    //助记码
    private String firmNamePY;
    //危化品经营许可权限
    private String dGLicenseAuth;
    
    private Integer isBinding;
    
    //交易场权限
    private List<FirmTmptRlsp> firmTmptRlspList;
    
    //是否金石湾危化  0:否，1:是
    private Integer isDanger;
    
	// 买卖权限 0：卖，1：买 2：全部
	private Integer tradeAuthority;
	
	// 危化品有效期
	private Date dGExpireDate;
	
	/** 商家是否授权 1:已经授权 2:未授权 */
	private Integer iAuthorized;
	
	/** 是否清除前台session */
	private boolean isClearSession;
	/**联系人邮箱*/
	private String contactEmail;
	
	/*推荐客服*/
	private String customerName;
	
	/*签约状态 1：未签约 2已签约*/
	private Integer isSignState;
    
	
	public Integer getTradeAuthority() {
		return tradeAuthority;
	}

	public void setTradeAuthority(Integer tradeAuthority) {
		this.tradeAuthority = tradeAuthority;
	}

	public Date getDGExpireDate() {
		return dGExpireDate;
	}

	public void setDGExpireDate(Date dGExpireDate) {
		this.dGExpireDate = dGExpireDate;
	}

	public String getFirmRegId() {
		return firmRegId;
	}

	public void setFirmRegId(String firmRegId) {
		this.firmRegId = firmRegId;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Integer getFirmType() {
		return firmType;
	}

	public void setFirmType(Integer firmType) {
		this.firmType = firmType;
	}

	public Integer getBusinessType() {
		return businessType;
	}

	public void setBusinessType(Integer businessType) {
		this.businessType = businessType;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public Integer getFirmStatus() {
		return firmStatus;
	}

	public void setFirmStatus(Integer firmStatus) {
		this.firmStatus = firmStatus;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactTelNo() {
		return contactTelNo;
	}

	public void setContactTelNo(String contactTelNo) {
		this.contactTelNo = contactTelNo;
	}

	public String getContactMobile() {
		return contactMobile;
	}

	public void setContactMobile(String contactMobile) {
		this.contactMobile = contactMobile;
	}

	public Integer getBSLicense() {
		return bSLicense;
	}

	public void setBSLicense(Integer bSLicense) {
		this.bSLicense = bSLicense;
	}

	public Integer getTaxLicense() {
		return taxLicense;
	}

	public void setTaxLicense(Integer taxLicense) {
		this.taxLicense = taxLicense;
	}

	public Integer getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(Integer orgCode) {
		this.orgCode = orgCode;
	}

	public Integer getUnifyLicense() {
		return unifyLicense;
	}

	public void setUnifyLicense(Integer unifyLicense) {
		this.unifyLicense = unifyLicense;
	}

	public Integer getDGLicense() {
		return dGLicense;
	}

	public void setDGLicense(Integer dGLicense) {
		this.dGLicense = dGLicense;
	}

	public Integer getSettingBankID() {
		return settingBankID;
	}

	public void setSettingBankID(Integer settingBankID) {
		this.settingBankID = settingBankID;
	}

	public String getSettingBkBranch() {
		return settingBkBranch;
	}

	public void setSettingBkBranch(String settingBkBranch) {
		this.settingBkBranch = settingBkBranch;
	}

	public String getSettingBkAccount() {
		return settingBkAccount;
	}

	public void setSettingBkAccount(String settingBkAccount) {
		this.settingBkAccount = settingBkAccount;
	}

	public Integer getVatBankID() {
		return vatBankID;
	}

	public void setVatBankID(Integer vatBankID) {
		this.vatBankID = vatBankID;
	}

	public String getVatBkBranch() {
		return vatBkBranch;
	}

	public void setVatBkBranch(String vatBkBranch) {
		this.vatBkBranch = vatBkBranch;
	}

	public String getVatBkAccount() {
		return vatBkAccount;
	}

	public void setVatBkAccount(String vatBkAccount) {
		this.vatBkAccount = vatBkAccount;
	}

	public Integer getVatPV() {
		return vatPV;
	}

	public void setVatPV(Integer vatPV) {
		this.vatPV = vatPV;
	}

	public Integer getVatCT() {
		return vatCT;
	}

	public void setVatCT(Integer vatCT) {
		this.vatCT = vatCT;
	}

	public Integer getVatDT() {
		return vatDT;
	}

	public void setVatDT(Integer vatDT) {
		this.vatDT = vatDT;
	}

	public String getVatAddress() {
		return vatAddress;
	}

	public void setVatAddress(String vatAddress) {
		this.vatAddress = vatAddress;
	}

	public String getTaxNo() {
		return taxNo;
	}

	public void setTaxNo(String taxNo) {
		this.taxNo = taxNo;
	}

	public Integer getRecPV() {
		return recPV;
	}

	public void setRecPV(Integer recPV) {
		this.recPV = recPV;
	}

	public Integer getRecCT() {
		return recCT;
	}

	public void setRecCT(Integer recCT) {
		this.recCT = recCT;
	}

	public Integer getRecDT() {
		return recDT;
	}

	public void setRecDT(Integer recDT) {
		this.recDT = recDT;
	}

	public String getRecAddRess() {
		return recAddRess;
	}

	public void setRecAddRess(String recAddRess) {
		this.recAddRess = recAddRess;
	}

	public String getRecContactName() {
		return recContactName;
	}

	public void setRecContactName(String recContactName) {
		this.recContactName = recContactName;
	}

	public String getRecContactTelNo() {
		return recContactTelNo;
	}

	public void setRecContactTelNo(String recContactTelNo) {
		this.recContactTelNo = recContactTelNo;
	}

	public String getRecCreateby() {
		return recCreateby;
	}

	public void setRecCreateby(String recCreateby) {
		this.recCreateby = recCreateby;
	}

	public Date getRecCreateTime() {
		return recCreateTime;
	}

	public void setRecCreateTime(Date recCreateTime) {
		this.recCreateTime = recCreateTime;
	}

	public String getRecModifyby() {
		return recModifyby;
	}

	public void setRecModifyby(String recModifyby) {
		this.recModifyby = recModifyby;
	}

	public Date getRecModifyTime() {
		return recModifyTime;
	}

	public void setRecModifyTime(Date recModifyTime) {
		this.recModifyTime = recModifyTime;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getBSEntityName() {
		return bSEntityName;
	}

	public void setBSEntityName(String bSEntityName) {
		this.bSEntityName = bSEntityName;
	}

	

	public String getBSEntityTelNo() {
		return bSEntityTelNo;
	}

	public void setBSEntityTelNo(String bSEntityTelNo) {
		this.bSEntityTelNo = bSEntityTelNo;
	}

	public String getBSLicenseNo() {
		return bSLicenseNo;
	}

	public void setBSLicenseNo(String bSLicenseNo) {
		this.bSLicenseNo = bSLicenseNo;
	}

	public String getRegisterCapiTal() {
		return registerCapiTal;
	}

	public void setRegisterCapiTal(String registerCapiTal) {
		this.registerCapiTal = registerCapiTal;
	}

	public String getTaxRegisterNo() {
		return taxRegisterNo;
	}

	public void setTaxRegisterNo(String taxRegisterNo) {
		this.taxRegisterNo = taxRegisterNo;
	}

	public String getOrganizationCd() {
		return organizationCd;
	}

	public void setOrganizationCd(String organizationCd) {
		this.organizationCd = organizationCd;
	}

	public String getUnifyLicenseNo() {
		return unifyLicenseNo;
	}

	public void setUnifyLicenseNo(String unifyLicenseNo) {
		this.unifyLicenseNo = unifyLicenseNo;
	}

	public String getDGLicenseNo() {
		return dGLicenseNo;
	}

	public void setDGLicenseNo(String dGLicenseNo) {
		this.dGLicenseNo = dGLicenseNo;
	}

	public FirmDetail getFirmDetailBean() {
		return firmDetailBean;
	}

	public void setFirmDetailBean(FirmDetail firmDetailBean) {
		this.firmDetailBean = firmDetailBean;
	}

	public Firminvoice getFirminvoiceBean() {
		return FirminvoiceBean;
	}

	public void setFirminvoiceBean(Firminvoice firminvoiceBean) {
		FirminvoiceBean = firminvoiceBean;
	}

	public Firmvatinfo getFirmvatinfoBean() {
		return firmvatinfoBean;
	}

	public void setFirmvatinfoBean(Firmvatinfo firmvatinfoBean) {
		this.firmvatinfoBean = firmvatinfoBean;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public RecAddRess getRecAddRessBean() {
		return recAddRessBean;
	}

	public void setRecAddRessBean(RecAddRess recAddRessBean) {
		this.recAddRessBean = recAddRessBean;
	}

	public VatAddRess getVatAddRessBean() {
		return vatAddRessBean;
	}

	public void setVatAddRessBean(VatAddRess vatAddRessBean) {
		this.vatAddRessBean = vatAddRessBean;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getRequestUserId() {
		return requestUserId;
	}

	public void setRequestUserId(String requestUserId) {
		this.requestUserId = requestUserId;
	}

	public Integer getWhetherToBind() {
		return whetherToBind;
	}

	public void setWhetherToBind(Integer whetherToBind) {
		this.whetherToBind = whetherToBind;
	}

	public Integer getLicenseDiffer() {
		return licenseDiffer;
	}

	public void setLicenseDiffer(Integer licenseDiffer) {
		this.licenseDiffer = licenseDiffer;
	}

	public String getFirmNamePY() {
		return firmNamePY;
	}

	public void setFirmNamePY(String firmNamePY) {
		this.firmNamePY = firmNamePY;
	}

	public String getDGLicenseAuth() {
		return dGLicenseAuth;
	}

	public void setDGLicenseAuth(String dGLicenseAuth) {
		this.dGLicenseAuth = dGLicenseAuth;
	}

	public List<FirmTmptRlsp> getFirmTmptRlspList() {
		return firmTmptRlspList;
	}

	public void setFirmTmptRlspList(List<FirmTmptRlsp> firmTmptRlspList) {
		this.firmTmptRlspList = firmTmptRlspList;
	}

	/**
	 * @return the isBinding
	 */
	public Integer getIsBinding() {
		return isBinding;
	}

	/**
	 * @param isBinding the isBinding to set
	 */
	public void setIsBinding(Integer isBinding) {
		this.isBinding = isBinding;
	}

	public String getVatContactTelNo() {
		return vatContactTelNo;
	}

	public void setVatContactTelNo(String vatContactTelNo) {
		this.vatContactTelNo = vatContactTelNo;
	}

	public Integer getIsDanger() {
		return isDanger;
	}

	public void setIsDanger(Integer isDanger) {
		this.isDanger = isDanger;
	}

	public Integer getiAuthorized() {
		return iAuthorized;
	}

	public void setiAuthorized(Integer iAuthorized) {
		this.iAuthorized = iAuthorized;
	}

	public boolean getIsClearSession() {
		return isClearSession;
	}

	public void setIsClearSession(boolean isClearSession) {
		this.isClearSession = isClearSession;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Integer getIsSignState() {
		return isSignState;
	}

	public void setIsSignState(Integer isSignState) {
		this.isSignState = isSignState;
	}

	public String getVatBankName() {
		return vatBankName;
	}

	public void setVatBankName(String vatBankName) {
		this.vatBankName = vatBankName;
	}
}
