/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmDetail
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.dao.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import shcem.base.dao.model.BaseObject;

/**
 * 交易商详细信息
 * 
 * @author zhangnan
 *
 */
public class FirmDetail extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** 交易商编码 */
	private String firmID;

	/**  */
	private String firmRegId;

	/** 交易商名称 */
	private String firmName;

	/** 交易商全称 */
	private String fullName;

	/** 企业类型 */
	private Integer firmType;

	/** 业务类型 */
	private Integer businessType;

	/** 当前审核状态 */
	private Integer firmStatus;

	/** 地址 */
	private String address;

	private Integer addressPV;

	private Integer addressCT;

	private Integer isBinding;

	private Integer addressDT;

	/** 传真 */
	private String fax;

	/** 邮编 */
	private String postCode;

	/** 当前禁用类型 */
	private Integer disabled;

	/**  */
	private Integer settingBankID;

	/**  */
	private String settingBkBranch;

	/**  */
	private String settingBkAccount;

	/**  */
	private String note;

	/**  */
	private String bSEntityName;

	/**  */
	private String bSEntityTelNo;

	/**  */
	private String contactName;

	/**  */
	private String contactTelNo;

	/**  */
	private String contactMobile;

	/**  */
	private String bSLicenseNo;

	/**  */
	private String registerCapiTal;

	/**  */
	private Integer bSLicense;

	/**  */
	private String taxRegisterNo;

	/**  */
	private Integer taxLicense;

	/**  */
	private String organizationCd;

	/**  */
	private Integer orgCode;

	/**  */
	private String unifyLicenseNo;

	/**  */
	private Integer unifyLicense;

	/**  */
	private String dGLicenseNo;

	/**  */
	private Integer dGLicense;

	/**  */
	private String dGLicenseAuth;

	/**  */
	private String taxNo;

	/** 创建人 */
	private String recCreateby;

	/** 创建时间 */
	private Date recCreateTime;

	/** 最后修改人 */
	private String recModifyby;

	/** 最后修改时间 */
	private Date recModifyTime;

	// 证照区分 0: 三证，1:综合证
	private Integer licenseDiffer;

	// 交易场权限
	private List<FirmTmptRlsp> firmTmptRlspList;

	// 助记码
	private String firmNamePY;
	
	/**向上支付方式 
	 * 0: 货款不包含手续费，1:货款包含手续费
	 */
	private Integer payType; 
	
	//是否金石湾危化  0:否，1:是
    private Integer isDanger;
    
	// 买卖权限 0：卖，1：买 2：全部
	private Integer tradeAuthority;
	
	// 危化品有效期
	private Date dGExpireDate;
	// 联系人邮箱
	private String contactEmail;
	
	/** 商家是否授权 1:已经授权 2:未授权  */
	private Integer isAuthorized;
	
	/*推荐客服*/
	private String customerName;
	
	/*签约状态 1：未签约 2已签约*/
	private Integer isSignState;
	
	/*基差的买卖权限 0：卖，1：买 2：全部*/
	private Integer rdaTradeAuthorityXX;
	
	

	public Integer getRdaTradeAuthorityXX() {
		return rdaTradeAuthorityXX;
	}

	public void setRdaTradeAuthorityXX(Integer rdaTradeAuthorityXX) {
		this.rdaTradeAuthorityXX = rdaTradeAuthorityXX;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public Integer getTradeAuthority() {
		return tradeAuthority;
	}

	public void setTradeAuthority(Integer tradeAuthority) {
		this.tradeAuthority = tradeAuthority;
	}

	public Date getDGExpireDate() {
		return dGExpireDate;
	}

	public void setDGExpireDate(Date dGExpireDate) {
		this.dGExpireDate = dGExpireDate;
	}

	public Integer getAddressPV() {
		return addressPV;
	}

	public void setAddressPV(Integer addressPV) {
		this.addressPV = addressPV;
	}

	public Integer getAddressCT() {
		return addressCT;
	}

	public void setAddressCT(Integer addressCT) {
		this.addressCT = addressCT;
	}

	public Integer getAddressDT() {
		return addressDT;
	}

	public void setAddressDT(Integer addressDT) {
		this.addressDT = addressDT;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getFirmRegId() {
		return firmRegId;
	}

	public void setFirmRegId(String firmRegId) {
		this.firmRegId = firmRegId;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Integer getFirmType() {
		return firmType;
	}

	public void setFirmType(Integer firmType) {
		this.firmType = firmType;
	}

	public Integer getBusinessType() {
		return businessType;
	}

	public void setBusinessType(Integer businessType) {
		this.businessType = businessType;
	}

	public Integer getFirmStatus() {
		return firmStatus;
	}

	public void setFirmStatus(Integer firmStatus) {
		this.firmStatus = firmStatus;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public Integer getSettingBankID() {
		return settingBankID;
	}

	public void setSettingBankID(Integer settingBankID) {
		this.settingBankID = settingBankID;
	}

	public String getSettingBkBranch() {
		return settingBkBranch;
	}

	public void setSettingBkBranch(String settingBkBranch) {
		this.settingBkBranch = settingBkBranch;
	}

	public String getSettingBkAccount() {
		return settingBkAccount;
	}

	public void setSettingBkAccount(String settingBkAccount) {
		this.settingBkAccount = settingBkAccount;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getBSEntityName() {
		return bSEntityName;
	}

	public void setBSEntityName(String bSEntityName) {
		this.bSEntityName = bSEntityName;
	}

	public String getBSEntityTelNo() {
		return bSEntityTelNo;
	}

	public void setBSEntityTelNo(String bSEntityTelNo) {
		this.bSEntityTelNo = bSEntityTelNo;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactTelNo() {
		return contactTelNo;
	}

	public void setContactTelNo(String contactTelNo) {
		this.contactTelNo = contactTelNo;
	}

	public String getContactMobile() {
		return contactMobile;
	}

	public void setContactMobile(String contactMobile) {
		this.contactMobile = contactMobile;
	}

	public String getBSLicenseNo() {
		return bSLicenseNo;
	}

	public void setBSLicenseNo(String bSLicenseNo) {
		this.bSLicenseNo = bSLicenseNo;
	}

	public String getRegisterCapiTal() {
		return registerCapiTal;
	}

	public void setRegisterCapiTal(String registerCapiTal) {
		this.registerCapiTal = registerCapiTal;
	}

	public String getTaxRegisterNo() {
		return taxRegisterNo;
	}

	public void setTaxRegisterNo(String taxRegisterNo) {
		this.taxRegisterNo = taxRegisterNo;
	}

	public Integer getTaxLicense() {
		return taxLicense;
	}

	public void setTaxLicense(Integer taxLicense) {
		this.taxLicense = taxLicense;
	}

	public String getOrganizationCd() {
		return organizationCd;
	}

	public void setOrganizationCd(String organizationCd) {
		this.organizationCd = organizationCd;
	}

	public Integer getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(Integer orgCode) {
		this.orgCode = orgCode;
	}

	public String getUnifyLicenseNo() {
		return unifyLicenseNo;
	}

	public void setUnifyLicenseNo(String unifyLicenseNo) {
		this.unifyLicenseNo = unifyLicenseNo;
	}

	public Integer getUnifyLicense() {
		return unifyLicense;
	}

	public void setUnifyLicense(Integer unifyLicense) {
		this.unifyLicense = unifyLicense;
	}

	public String getDGLicenseNo() {
		return dGLicenseNo;
	}

	public void setdGLicenseNo(String dGLicenseNo) {
		this.dGLicenseNo = dGLicenseNo;
	}

	public Integer getDGLicense() {
		return dGLicense;
	}

	public void setDGLicense(Integer dGLicense) {
		this.dGLicense = dGLicense;
	}

	public String getDGLicenseAuth() {
		return dGLicenseAuth;
	}

	public void setDGLicenseAuth(String dGLicenseAuth) {
		this.dGLicenseAuth = dGLicenseAuth;
	}

	public String getTaxNo() {
		return taxNo;
	}

	public void setTaxNo(String taxNo) {
		this.taxNo = taxNo;
	}

	public String getRecCreateby() {
		return recCreateby;
	}

	public void setRecCreateby(String recCreateby) {
		this.recCreateby = recCreateby;
	}

	public Date getRecCreateTime() {
		return recCreateTime;
	}

	public void setRecCreateime(Date recCreateTime) {
		this.recCreateTime = recCreateTime;
	}

	public String getRecModifyby() {
		return recModifyby;
	}

	public void setRecModifyby(String recModifyby) {
		this.recModifyby = recModifyby;
	}

	public Date getRecModifyTime() {
		return recModifyTime;
	}

	public void setRecModifytime(Date recModifyTime) {
		this.recModifyTime = recModifyTime;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Integer getBSLicense() {
		return bSLicense;
	}

	public void setBSLicense(Integer bSLicense) {
		this.bSLicense = bSLicense;
	}

	public Integer getLicenseDiffer() {
		return licenseDiffer;
	}

	public void setLicenseDiffer(Integer licenseDiffer) {
		this.licenseDiffer = licenseDiffer;
	}

	public String getFirmNamePY() {
		return firmNamePY;
	}

	public void setFirmNamePY(String firmNamePY) {
		this.firmNamePY = firmNamePY;
	}

	public List<FirmTmptRlsp> getFirmTmptRlspList() {
		return firmTmptRlspList;
	}

	public void setFirmTmptRlspList(List<FirmTmptRlsp> firmTmptRlspList) {
		this.firmTmptRlspList = firmTmptRlspList;
	}

	/**
	 * @return the isBinding
	 */
	public Integer getIsBinding() {
		return isBinding;
	}

	/**
	 * @param isBinding
	 *            the isBinding to set
	 */
	public void setIsBinding(Integer isBinding) {
		this.isBinding = isBinding;
	}

	public Integer getPayType() {
		return payType;
	}

	public void setPayType(Integer payType) {
		this.payType = payType;
	}

	public Integer getIsDanger() {
		return isDanger;
	}

	public void setIsDanger(Integer isDanger) {
		this.isDanger = isDanger;
	}

	public Integer getIsAuthorized() {
		return isAuthorized;
	}

	public void setIsAuthorized(Integer isAuthorized) {
		this.isAuthorized = isAuthorized;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Integer getIsSignState() {
		return isSignState;
	}

	public void setIsSignState(Integer isSignState) {
		this.isSignState = isSignState;
	}
}
