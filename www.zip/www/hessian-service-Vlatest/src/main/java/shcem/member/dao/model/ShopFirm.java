package shcem.member.dao.model;

import java.io.Serializable;
import java.util.Date;

import shcem.base.dao.model.BaseObject;
/**
 * 商铺交易商关联表
 * @author wangshuai
 *
 */
public class ShopFirm extends BaseObject implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7243455423585225887L;
	private Integer id;
	private Integer shopID;
	private String firmID;
	private String firmName;
	private Integer isMainFirm;
	private String remark;
	private Integer dISABLED;
	private String rEC_CREATEBY;
	private Date rEC_CREATETIME;
	private String rEC_MODIFYBY;
	private Date rEC_MODIFYTIME;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getShopID() {
		return shopID;
	}
	public void setShopID(Integer shopID) {
		this.shopID = shopID;
	}
	public String getFirmID() {
		return firmID;
	}
	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}
	public String getFirmName() {
		return firmName;
	}
	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}
	public Integer getIsMainFirm() {
		return isMainFirm;
	}
	public void setIsMainFirm(Integer isMainFirm) {
		this.isMainFirm = isMainFirm;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Integer getDISABLED() {
		return dISABLED;
	}
	public void setDISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}
	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}
	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}
	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}
	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}
	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}
	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}
	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}
	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
