package shcem.member.dao.model;

import java.io.Serializable;

import shcem.base.dao.model.BaseObject;

public class TraderTmptRlsp extends BaseObject implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer tradeTmptId;
	
	private String traderID;
	
	private String enabled;
	
	

	public Integer getTradeTmptId() {
		return tradeTmptId;
	}

	public void setTradeTmptId(Integer tradeTmptId) {
		this.tradeTmptId = tradeTmptId;
	}

	public String getTraderID() {
		return traderID;
	}

	public void setTraderID(String traderID) {
		this.traderID = traderID;
	}


	public String getEnabled() {
		return enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
