package shcem.member.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

public class FirmPositionLimitModel extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer id;

	private String firmID;

	/** 货品类型，0：现货 1：预售 */
	private Integer goodsType;

	/** 限额类型，0：按金额 1：按重量 */
	private Integer positionLimitType;

	/** 限额:限额吨6位小数 价格2位小数 */
	private BigDecimal positionLimitValue;
	
	/** 根据限额类型，显示现货限额文字 */
	private String show_stock_positionLimitValue;
	
	/** 现货限额类型，0：按金额 1：按重量 */
	private Integer stock_positionLimitType;

	/** 现货销售限额 */
	private BigDecimal stock_positionLimitValue;
	
	/** 现货当前挂牌量 */
	private BigDecimal stock_sell;

	/** 现货当前未交收量 */
	private BigDecimal stock_undeliveryQuantity;

	/**
	 * 现货 当前销售量（吨）
	 */
	private BigDecimal stock_saleVolume;

	/**
	 * 现货 当前销售金额（元）
	 */
	private BigDecimal stock_saleMoney;
	
	/** 根据限额类型，显示预售限额文字 */
	private String show_advance_positionLimitValue;
	
	/** 预售限额类型，0：按金额 1：按重量 */
	private Integer advance_positionLimitType;
	
	/** 预售销售限额 */
	private BigDecimal advance_positionLimitValue;

	/** 预售当前挂牌量 */
	private BigDecimal advance_sell;

	/** 预售当前未交收量 */
	private BigDecimal advance_undeliveryQuantity;	
	/**
	 * 预售 当前销售金额（元）
	 */
	private BigDecimal advance_saleVolume;
	/**
	 * 预售 当前销售金额（元）
	 */
	private BigDecimal advance_saleMoney;
	
	
	/** 根据限额类型，显示期现限额文字 */
	private String show_future_positionLimitValue;
	
	/** 期现限额类型，0：按金额 1：按重量 */
	private Integer future_positionLimitType;
	
	/** 期现销售限额 */
	private BigDecimal future_positionLimitValue;

	/** 期现当前挂牌量 */
	private BigDecimal future_sell;

	/** 期现当前未交收量 */
	private BigDecimal future_undeliveryQuantity;	
	/**
	 * 期现 当前销售金额（元）
	 */
	private BigDecimal future_saleVolume;
	/**
	 * 期现 当前销售金额（元）
	 */
	private BigDecimal future_saleMoney;
	

	private Integer dISABLED;

	private String rEC_CREATEBY;

	private Date rEC_CREATETIME;

	private String rEC_MODIFYBY;

	private Date rEC_MODIFYTIME;

	private String firmName;

	



	private String limit;

	/** 限额种类 0：现货中石化（含现货、中石化专场） 1：预售（远期现货场） 2：期现（线性专场） **/
	private Integer positionDesc;

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public BigDecimal getStock_saleVolume() {
		return stock_saleVolume;
	}

	public void setStock_saleVolume(BigDecimal stock_saleVolume) {
		this.stock_saleVolume = stock_saleVolume;
	}

	public BigDecimal getStock_saleMoney() {
		return stock_saleMoney;
	}

	public void setStock_saleMoney(BigDecimal stock_saleMoney) {
		this.stock_saleMoney = stock_saleMoney;
	}

	public BigDecimal getAdvance_saleVolume() {
		return advance_saleVolume;
	}

	public void setAdvance_saleVolume(BigDecimal advance_saleVolume) {
		this.advance_saleVolume = advance_saleVolume;
	}

	public BigDecimal getAdvance_saleMoney() {
		return advance_saleMoney;
	}

	public void setAdvance_saleMoney(BigDecimal advance_saleMoney) {
		this.advance_saleMoney = advance_saleMoney;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public Integer getGoodsType() {
		return goodsType;
	}

	public void setGoodsType(Integer goodsType) {
		this.goodsType = goodsType;
	}

	public Integer getPositionLimitType() {
		return positionLimitType;
	}

	public void setPositionLimitType(Integer positionLimitType) {
		this.positionLimitType = positionLimitType;
	}

	public BigDecimal getPositionLimitValue() {
		return positionLimitValue;
	}

	public void setPositionLimitValue(BigDecimal positionLimitValue) {
		this.positionLimitValue = positionLimitValue;
	}

	public Integer getDISABLED() {
		return dISABLED;
	}

	public void setDISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public BigDecimal getStock_positionLimitValue() {
		return stock_positionLimitValue;
	}

	public void setStock_positionLimitValue(BigDecimal stock_positionLimitValue) {
		this.stock_positionLimitValue = stock_positionLimitValue;
	}

	public BigDecimal getAdvance_positionLimitValue() {
		return advance_positionLimitValue;
	}

	public void setAdvance_positionLimitValue(
			BigDecimal advance_positionLimitValue) {
		this.advance_positionLimitValue = advance_positionLimitValue;
	}

	public String getLimit() {
		return limit;
	}

	public void setLimit(String limit) {
		this.limit = limit;
	}

	public BigDecimal getStock_undeliveryQuantity() {
		return stock_undeliveryQuantity;
	}

	public void setStock_undeliveryQuantity(BigDecimal stock_undeliveryQuantity) {
		this.stock_undeliveryQuantity = stock_undeliveryQuantity;
	}

	public BigDecimal getAdvance_undeliveryQuantity() {
		return advance_undeliveryQuantity;
	}

	public void setAdvance_undeliveryQuantity(
			BigDecimal advance_undeliveryQuantity) {
		this.advance_undeliveryQuantity = advance_undeliveryQuantity;
	}

	public BigDecimal getStock_sell() {
		return stock_sell;
	}

	public void setStock_sell(BigDecimal stock_sell) {
		this.stock_sell = stock_sell;
	}

	public BigDecimal getAdvance_sell() {
		return advance_sell;
	}

	public void setAdvance_sell(BigDecimal advance_sell) {
		this.advance_sell = advance_sell;
	}

	/**
	 * @return the positionDesc
	 */
	public Integer getPositionDesc() {
		return positionDesc;
	}

	/**
	 * @param positionDesc the positionDesc to set
	 */
	public void setPositionDesc(Integer positionDesc) {
		positionDesc = positionDesc;
	}

	/**
	 * @return the show_stock_positionLimitValue
	 */
	public String getShow_stock_positionLimitValue() {
		return show_stock_positionLimitValue;
	}

	/**
	 * @param show_stock_positionLimitValue the show_stock_positionLimitValue to set
	 */
	public void setShow_stock_positionLimitValue(
			String show_stock_positionLimitValue) {
		this.show_stock_positionLimitValue = show_stock_positionLimitValue;
	}

	/**
	 * @return the show_advance_positionLimitValue
	 */
	public String getShow_advance_positionLimitValue() {
		return show_advance_positionLimitValue;
	}

	/**
	 * @param show_advance_positionLimitValue the show_advance_positionLimitValue to set
	 */
	public void setShow_advance_positionLimitValue(
			String show_advance_positionLimitValue) {
		this.show_advance_positionLimitValue = show_advance_positionLimitValue;
	}

	/**
	 * @return the show_future_positionLimitValue
	 */
	public String getShow_future_positionLimitValue() {
		return show_future_positionLimitValue;
	}

	/**
	 * @param show_future_positionLimitValue the show_future_positionLimitValue to set
	 */
	public void setShow_future_positionLimitValue(
			String show_future_positionLimitValue) {
		this.show_future_positionLimitValue = show_future_positionLimitValue;
	}

	/**
	 * @return the future_positionLimitValue
	 */
	public BigDecimal getFuture_positionLimitValue() {
		return future_positionLimitValue;
	}

	/**
	 * @param future_positionLimitValue the future_positionLimitValue to set
	 */
	public void setFuture_positionLimitValue(BigDecimal future_positionLimitValue) {
		this.future_positionLimitValue = future_positionLimitValue;
	}

	/**
	 * @return the future_sell
	 */
	public BigDecimal getFuture_sell() {
		return future_sell;
	}

	/**
	 * @param future_sell the future_sell to set
	 */
	public void setFuture_sell(BigDecimal future_sell) {
		this.future_sell = future_sell;
	}

	/**
	 * @return the future_undeliveryQuantity
	 */
	public BigDecimal getFuture_undeliveryQuantity() {
		return future_undeliveryQuantity;
	}

	/**
	 * @param future_undeliveryQuantity the future_undeliveryQuantity to set
	 */
	public void setFuture_undeliveryQuantity(BigDecimal future_undeliveryQuantity) {
		this.future_undeliveryQuantity = future_undeliveryQuantity;
	}

	/**
	 * @return the future_saleVolume
	 */
	public BigDecimal getFuture_saleVolume() {
		return future_saleVolume;
	}

	/**
	 * @param future_saleVolume the future_saleVolume to set
	 */
	public void setFuture_saleVolume(BigDecimal future_saleVolume) {
		this.future_saleVolume = future_saleVolume;
	}

	/**
	 * @return the future_saleMoney
	 */
	public BigDecimal getFuture_saleMoney() {
		return future_saleMoney;
	}

	/**
	 * @param future_saleMoney the future_saleMoney to set
	 */
	public void setFuture_saleMoney(BigDecimal future_saleMoney) {
		this.future_saleMoney = future_saleMoney;
	}

	/**
	 * @return the stock_positionLimitType
	 */
	public Integer getStock_positionLimitType() {
		return stock_positionLimitType;
	}

	/**
	 * @param stock_positionLimitType the stock_positionLimitType to set
	 */
	public void setStock_positionLimitType(Integer stock_positionLimitType) {
		this.stock_positionLimitType = stock_positionLimitType;
	}

	/**
	 * @return the advance_positionLimitType
	 */
	public Integer getAdvance_positionLimitType() {
		return advance_positionLimitType;
	}

	/**
	 * @param advance_positionLimitType the advance_positionLimitType to set
	 */
	public void setAdvance_positionLimitType(Integer advance_positionLimitType) {
		this.advance_positionLimitType = advance_positionLimitType;
	}

	/**
	 * @return the future_positionLimitType
	 */
	public Integer getFuture_positionLimitType() {
		return future_positionLimitType;
	}

	/**
	 * @param future_positionLimitType the future_positionLimitType to set
	 */
	public void setFuture_positionLimitType(Integer future_positionLimitType) {
		this.future_positionLimitType = future_positionLimitType;
	}

}
