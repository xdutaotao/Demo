/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: TraderServiceModel.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.dao.model;

import java.io.Serializable;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**交易员信息 ，页面展示模型
 * @author wlpod
 *
 */
public class TraderDataList extends BaseObject implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** 交易员编码 */
	private String traderID;

	/** 交易员名称 */
	private String traderName;

	/** 密码 */
	/*private String traderPassword;*/

	/** 强制密码更新状态 0:已更新，1:未更新 */
	private Integer forceChangePwd;

	/**  */
	private Integer disabled;

	/** 交易商编码 */
	private String firmID;
	
	/** 交易商名称 */
	private String firmName;

	/** 类型 0:管理员,1:一般交易员 */
	private Integer firmType;

	/** 用户编码 外键-User */
	private String userCode;
	
	/** 用户名 */
	private String userName;

	/**  */
	private String recCreateBy;

	/**  */
	private Date recCreateTime;

	/**  */
	private String recModifyBy;

	/**  */
	private Date recModifyTime;

	//绑定用户，联系方式
	private String mobile;
	// 交易员状态（0启用，1冻结）
	private Integer traderStatus;
	
	public Integer getTraderStatus() {
		return traderStatus;
	}

	public void setTraderStatus(Integer traderStatus) {
		this.traderStatus = traderStatus;
	}

	public String getTraderID() {
		return traderID;
	}

	public void setTraderID(String traderID) {
		this.traderID = traderID;
	}

	public String getTraderName() {
		return traderName;
	}

	public void setTraderName(String traderName) {
		this.traderName = traderName;
	}

	public Integer getForceChangePwd() {
		return forceChangePwd;
	}

	public void setForceChangePwd(Integer forceChangePwd) {
		this.forceChangePwd = forceChangePwd;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public Integer getFirmType() {
		return firmType;
	}

	public void setFirmType(Integer firmType) {
		this.firmType = firmType;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getRecCreateBy() {
		return recCreateBy;
	}

	public void setRecCreateBy(String recCreateBy) {
		this.recCreateBy = recCreateBy;
	}

	public Date getRecCreateTime() {
		return recCreateTime;
	}

	public void setRecCreateTime(Date recCreateTime) {
		this.recCreateTime = recCreateTime;
	}

	public String getRecModifyBy() {
		return recModifyBy;
	}

	public void setRecModifyBy(String recModifyBy) {
		this.recModifyBy = recModifyBy;
	}

	public Date getRecModifyTime() {
		return recModifyTime;
	}

	public void setRecModifyTime(Date recModifyTime) {
		this.recModifyTime = recModifyTime;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toString()
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#hashCode()
	 */
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @return the firmName
	 */
	public String getFirmName() {
		return firmName;
	}

	/**
	 * @param firmName the firmName to set
	 */
	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

}
