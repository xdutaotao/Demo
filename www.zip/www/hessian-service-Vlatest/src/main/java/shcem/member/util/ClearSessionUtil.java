package shcem.member.util;

import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;
import shcem.util.RemoteCallUtil;

public class ClearSessionUtil {

	/**
	 * 清除session
	 * @param objID 交易商ID或交易员ID或手机号
	 * @param authkeyid 用户ID
	 * @param mode
	 * @return 正常：0  异常：-1
	 */
	public static int clearSession(String objID,String authkeyid,String mode, String GUID){
		int code = 0;
		try {
			Map<String,String> map =  new HashMap<String,String>();
			map.put("Pattern", objID);
			/**
			 * 调用.Net的清session方法
			 */
			String postData = RemoteCallUtil.generateData("ClearRedisKeys", "Shcem.Member.ServiceContract.IClientLoginService",map,authkeyid);
			JSONObject jsonObj = RemoteCallUtil.postData(postData, mode, GUID);
				
			if (!"00000".equals(jsonObj.getString("CODE"))){
				code = -1;
			}
		} catch (Exception e) {
			code = -1;
		}
		return code;
	}
}
