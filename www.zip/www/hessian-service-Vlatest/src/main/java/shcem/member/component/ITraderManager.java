/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: ITraderManager.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.component;

import java.util.List;
import java.util.Map;

import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.member.dao.TraderDAO;
import shcem.member.dao.model.TradeAllData;
import shcem.member.dao.model.Trader;
import shcem.member.dao.model.TraderDataList;
import shcem.member.service.model.userMobileModel;

/**
 * @author wlpod
 *
 */
public abstract interface ITraderManager {

	public abstract void setTraderDAO(TraderDAO paramTraderDAO);

	/**
	 * 获取交易员列表
	 * 
	 * @param qc
	 * @param pageInfo
	 * @param firmID
	 * @return
	 */
	public abstract List<TraderDataList> getTraderList(QueryConditions qc, PageInfo pageInfo, String firmID);

	/**
	 * 获取交易员详情
	 * 
	 * @param traderID
	 * @return
	 */
	public abstract TradeAllData getTrader(String traderID);

	/**
	 * 新增交易员编码
	 * 
	 * @param trader
	 * @param traderTmptRlsps
	 * @return
	 */
	public abstract int addTrader(Trader trader, int[] traderTmptRlsps);

	/**
	 * 禁用交易员
	 * 
	 * @param whetherDisableUser
	 * 
	 * @param trader
	 * @return
	 */
	public abstract int disableTrader(String traderID, boolean whetherDisableUser);

	/**
	 * 启用交易员
	 * 
	 * @param traderID
	 * @return
	 */
	public abstract int enableTrader(String traderID);

	/**
	 * 用户编码是否已经存在
	 * 
	 * @param userCode
	 * @return
	 */
	public abstract boolean checkUserIDExisted(String userCode);

	/**
	 * 解绑
	 * 
	 * @param tradeID
	 * @return
	 */
	public abstract int Unbundling(String tradeID);

	/**
	 * 更新交易员信息
	 * 
	 * @param trader
	 * @param traderTmptRlsps
	 * @param userName
	 * @param mode
	 */
	public abstract int updateTrader(Trader trader, int[] traderTmptRlsps, String mode, String userName,
			String requestId);

	public abstract int bindTrader(Trader trader);

	/**
	 * 更新交易员的状态（即冻结交易员）
	 */
	public abstract int updateTraderStatusByTraderID(Trader trader, String exeUsername);

	/**
	 * 获取交易员列表
	 * 
	 * @param qc
	 * @param pageInfo
	 * @param firmID
	 * @return
	 */
	public abstract List<TraderDataList> getTraderList(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 获取用户手机列表
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<userMobileModel> queryUserMobileList(QueryConditions qc, PageInfo pageInfo, String userCode);

	/**
	 * 新增用户手机，超过二十条不能新增
	 * 
	 * @param moreMobile
	 * @param userCode
	 * @param userName
	 * @return
	 */
	public abstract int addUserMobile(String moreMobile, String userCode, String userName);

	/**
	 * 修改用户手机
	 * 
	 * @param id
	 * @param moreMobile
	 * @param userName
	 * @return
	 */
	public abstract int changeUserMobile(int id, String moreMobile, String userName);

	/**
	 * 解绑用户手机
	 * 
	 * @param id
	 * @return
	 */
	public abstract int unBindUserMobile(int id);

	/**
	 * 聊天用（检查交易员及报盘的有效状态）
	 * 
	 * @param traderCode
	 * @param leadsCode
	 * @return
	 */
	public abstract String checkIMAuth(String traderCode, String leadsCode, Map<String, String> rtnMap);
}
