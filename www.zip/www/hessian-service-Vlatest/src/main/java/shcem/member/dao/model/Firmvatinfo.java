/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: Firmvatinfo
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.dao.model;

import shcem.base.dao.model.BaseObject;


/**交易商增值税开票信息
 * (C_FIRMVATINFO)
 * 
 * @author bianj
 * @version 1.0.0 2016-05-23
 */
public class Firmvatinfo extends BaseObject implements java.io.Serializable {
    /** 版本号 */
    private static final long serialVersionUID = -7752716267655775927L;
    
    /**  */
    private String firmID;
    
    /**  */
    private String vatBkAccount;
    
    /**  */
    private Integer vatBankID;
    
    /**  */
    private String vatBkBranch;
    
    /**  */
    private Integer vatAddressID;

    
	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getVatBkAccount() {
		return vatBkAccount;
	}

	public void setVatBkAccount(String vatBkAccount) {
		this.vatBkAccount = vatBkAccount;
	}

	public Integer getVatBankID() {
		return vatBankID;
	}

	public void setVatBankID(Integer vatBankID) {
		this.vatBankID = vatBankID;
	}

	public String getVatBkBranch() {
		return vatBkBranch;
	}

	public void setVatBkBranch(String vatBkBranch) {
		this.vatBkBranch = vatBkBranch;
	}


	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Integer getVatAddressID() {
		return vatAddressID;
	}

	public void setVatAddressID(Integer vatAddressID) {
		this.vatAddressID = vatAddressID;
	}
    
}