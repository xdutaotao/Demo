package shcem.member.dao.model;

import java.util.Date;

import shcem.base.dao.model.BaseObject;

public class Shop extends BaseObject implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6709035675130540472L;
	private Integer id;
	private String firmID;
	private String firmName;
	private String shopName;
	private Integer sort;
	private Integer logo;
	private String introduction;
	private String remark;
	private Integer disabled;
	private String rEC_CREATEBY;
	private Date rEC_CREATETIME;
	private String rEC_MODIFYBY;
	private Date rEC_MODIFYTIME;
	//private int isLogoDisplay;
	// 关联的交易商ID数组
	private String[] relationFirmID;
	
	// 是否存在关联交易商 0：不存在 1存在
	private Integer isHaveRelationFirm;

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public Integer getLogo() {
		return logo;
	}

	public void setLogo(Integer logo) {
		this.logo = logo;
	}

	public String getIntroduction() {
		return introduction;
	}

	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

//	public int getIsLogoDisplay() {
//		return isLogoDisplay;
//	}
//
//	public void setIsLogoDisplay(int isLogoDisplay) {
//		this.isLogoDisplay = isLogoDisplay;
//	}

	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	public String[] getRelationFirmID() {
		return relationFirmID;
	}

	public void setRelationFirmID(String[] relationFirmID) {
		this.relationFirmID = relationFirmID;
	}

	public Integer getIsHaveRelationFirm() {
		return isHaveRelationFirm;
	}

	public void setIsHaveRelationFirm(Integer isHaveRelationFirm) {
		this.isHaveRelationFirm = isHaveRelationFirm;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
