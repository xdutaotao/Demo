/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmServiceModel
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.service.model;

import java.io.Serializable;
import java.util.Date;

import org.json.JSONObject;

import shcem.base.service.model.BaseServiceObject;

/**
 * @author wlpod
 *
 */
public class FirmServiceModel extends BaseServiceObject implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4595232585271109831L;
	

	/** 交易商编码 */
    private String firmID;
    
    /**  */
    private String firmRegID;
    
    /** 交易商名称						 */
    private String firmName;
    
    /** 交易商全称						 */
    private String fullName;
    
    /** 企业类型				 */
    private Integer firmType;
    
    /** 业务类型				 */
    private Integer businessType;
    
    /** 当前审核状态					 */
    private Integer firmStatus;
    
    /** 地址 */
    private String addRess;
    
    /** 传真 */
    private String fax;
    
    /** 邮编 */
    private String postCode;
    
    /** 当前禁用类型 */
    private Integer disabled;
    
    /**  */
    private Integer settingBankID;
    
    /**  */
    private String settingBkBranch;
    
    /**  */
    private String settingBkAccount;
    
    /**  */
    private String note;
    
    /**  */
    private String bSEntityName;
    
    /**  */
    private String bSEntitytelNo;
    
    /**  */
    private String contactName;
    
    /**  */
    private String contactTelNo;
    
    /**  */
    private String contactMobile;
    
    /**  */
    private String bSLicenseNo;
    
    /**  */
    private String registerCapiTal;
    
    /**  */
    private Integer bSLcense;
    
    /**  */
    private String taxRegisterNo;
    
    /**  */
    private Integer taxLicense;
    
    /**  */
    private String organizationCd;
    
    /**  */
    private Integer orgCode;
    
    /**  */
    private String unifyLicenseNo;
    
    /**  */
    private Integer unifyLicense;
    
    /**  */
    private String dGLicenseNo;
    
    /**  */
    private Integer dGLicense;
    
    /**  */
    private Integer dGLicenseAuth;
    
    /**  */
    private String taxNo;
    
    /** 创建人 */
    private String recCreateby;
    
    /** 创建时间 */
    private Date recCreateTime;
    
    /** 最后修改人 */
    private String recModifyby;
    
    /** 最后修改时间 */
    private Date recModifyTime;
    
    
	

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getFirmRegID() {
		return firmRegID;
	}

	public void setFirmRegID(String firmRegID) {
		this.firmRegID = firmRegID;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Integer getFirmType() {
		return firmType;
	}

	public void setFirmType(Integer firmType) {
		this.firmType = firmType;
	}

	public Integer getBusinessType() {
		return businessType;
	}

	public void setBusinessType(Integer businessType) {
		this.businessType = businessType;
	}

	public Integer getFirmStatus() {
		return firmStatus;
	}

	public void setFirmStatus(Integer firmStatus) {
		this.firmStatus = firmStatus;
	}

	public String getAddRess() {
		return addRess;
	}

	public void setAddRess(String addRess) {
		this.addRess = addRess;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public Integer getSettingBankID() {
		return settingBankID;
	}

	public void setSettingBankID(Integer settingBankID) {
		this.settingBankID = settingBankID;
	}

	public String getSettingBkBranch() {
		return settingBkBranch;
	}

	public void setSettingBkBranch(String settingBkBranch) {
		this.settingBkBranch = settingBkBranch;
	}

	public String getSettingBkAccount() {
		return settingBkAccount;
	}

	public void setSettingBkAccount(String settingBkAccount) {
		this.settingBkAccount = settingBkAccount;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getBSEntityName() {
		return bSEntityName;
	}

	public void setbSEntityName(String bSEntityName) {
		this.bSEntityName = bSEntityName;
	}

	public String getBSEntitytelNo() {
		return bSEntitytelNo;
	}

	public void setbSEntitytelNo(String bSEntitytelNo) {
		this.bSEntitytelNo = bSEntitytelNo;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactTelNo() {
		return contactTelNo;
	}

	public void setContactTelNo(String contactTelNo) {
		this.contactTelNo = contactTelNo;
	}

	public String getContactMobile() {
		return contactMobile;
	}

	public void setContactMobile(String contactMobile) {
		this.contactMobile = contactMobile;
	}

	public String getBSLicenseNo() {
		return bSLicenseNo;
	}

	public void setbSLicenseNo(String bSLicenseNo) {
		this.bSLicenseNo = bSLicenseNo;
	}

	public String getRegisterCapiTal() {
		return registerCapiTal;
	}

	public void setRegisterCapiTal(String registerCapiTal) {
		this.registerCapiTal = registerCapiTal;
	}

	public Integer getBSLcense() {
		return bSLcense;
	}

	public void setbSLcense(Integer bSLcense) {
		this.bSLcense = bSLcense;
	}

	public String getTaxRegisterNo() {
		return taxRegisterNo;
	}

	public void setTaxRegisterNo(String taxRegisterNo) {
		this.taxRegisterNo = taxRegisterNo;
	}

	public Integer getTaxLicense() {
		return taxLicense;
	}

	public void setTaxLicense(Integer taxLicense) {
		this.taxLicense = taxLicense;
	}

	public String getOrganizationCd() {
		return organizationCd;
	}

	public void setOrganizationCd(String organizationCd) {
		this.organizationCd = organizationCd;
	}

	public Integer getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(Integer orgCode) {
		this.orgCode = orgCode;
	}

	public String getUnifyLicenseNo() {
		return unifyLicenseNo;
	}

	public void setUnifyLicenseNo(String unifyLicenseNo) {
		this.unifyLicenseNo = unifyLicenseNo;
	}

	public Integer getUnifyLicense() {
		return unifyLicense;
	}

	public void setUnifyLicense(Integer unifyLicense) {
		this.unifyLicense = unifyLicense;
	}

	public String getDGLicenseNo() {
		return dGLicenseNo;
	}

	public void setdGLicenseNo(String dGLicenseNo) {
		this.dGLicenseNo = dGLicenseNo;
	}

	public Integer getDGLicense() {
		return dGLicense;
	}

	public void setdGLicense(Integer dGLicense) {
		this.dGLicense = dGLicense;
	}

	public Integer getDGLicenseAuth() {
		return dGLicenseAuth;
	}

	public void setdGLicenseAuth(Integer dGLicenseAuth) {
		this.dGLicenseAuth = dGLicenseAuth;
	}

	public String getTaxNo() {
		return taxNo;
	}

	public void setTaxNo(String taxNo) {
		this.taxNo = taxNo;
	}

	public String getRecCreateby() {
		return recCreateby;
	}

	public void setRecCreateby(String recCreateby) {
		this.recCreateby = recCreateby;
	}

	public Date getRecCreateTime() {
		return recCreateTime;
	}

	public void setRecCreateTime(Date recCreateTime) {
		this.recCreateTime = recCreateTime;
	}

	public String getRecModifyby() {
		return recModifyby;
	}

	public void setRecModifyby(String recModifyby) {
		this.recModifyby = recModifyby;
	}

	public Date getRecModifyTime() {
		return recModifyTime;
	}

	public void setRecModifyTime(Date recModifyTime) {
		this.recModifyTime = recModifyTime;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toString()
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toJSONObject()
	 */
	@Override
	public JSONObject toJSONObject() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#hashCode()
	 */
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
