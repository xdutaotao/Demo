/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：聊天
 * File Name: CheckIMAuthInput.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2017年6月28日 　池永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.service.model;

import shcem.base.dao.model.BaseObject;

/**
 * @author 池永
 *
 */
public class CheckIMAuthInput extends BaseObject implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String traderCode;
	private String leadsCode;

	public String getTraderCode() {
		return traderCode;
	}

	public void setTraderCode(String traderCode) {
		this.traderCode = traderCode;
	}

	public String getLeadsCode() {
		return leadsCode;
	}

	public void setLeadsCode(String leadsCode) {
		this.leadsCode = leadsCode;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
