/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: UserDAOImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.dao.impl;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCallback;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.member.dao.UserDAO;
import shcem.member.dao.model.CusInfoCscfg;
import shcem.member.dao.model.User;
import shcem.member.dao.model.UserAllData;
import shcem.member.dao.model.UserDataList;
import shcem.member.service.model.CusInfoMaintainDto;
import shcem.member.service.model.CusInfoMaintainModel;
import shcem.util.CommonRowMapper;

/**
 * @author wlpod
 *
 */
public class UserDAOImpl extends BaseDAOImpl implements UserDAO {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * shcem.member.dao.UserDAO#getUserList(shcem.base.query.QueryConditions,
	 * shcem.base.query.PageInfo)
	 */
	@Override
	public List<UserDataList> getUserList(QueryConditions qc, PageInfo pageInfo) {
		this.log.debug("getUserList DAO Start");
		List<UserDataList> retList = null;
		String sql = sqlProperty.getProperty("UserDAO_001");
		retList = queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new UserDataList()));
		return retList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.member.dao.UserDAO#getUser(java.lang.String)
	 */
	@Override
	public UserAllData getUser(String userCode) {
		UserAllData userAllData = new UserAllData();
		Object[] params = { userCode };
		String sql = sqlProperty.getProperty("UserDAO_002");
		userAllData = (UserAllData) queryForObject(sql, params, new CommonRowMapper(new UserAllData()));
		return userAllData;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.member.dao.UserDAO#disableUser(java.lang.String)
	 */
	@Override
	public int disableUser(String userCode) {
		String sql = sqlProperty.getProperty("UserDAO_004");
		Object[] params = { userCode };
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		int rowNm = this.getJdbcTemplate().update(sql, params);
		return rowNm;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.member.dao.UserDAO#enableUser(java.lang.String)
	 */
	@Override
	public int enableUser(String userCode) {
		String sql = sqlProperty.getProperty("UserDAO_005");
		Object[] params = { userCode };
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		int rowNm = this.getJdbcTemplate().update(sql, params);
		return rowNm;
	}

	@Override
	public void addUser(User user) {
		String userID = this.getUserID();
		String sql = sqlProperty.getProperty("UserDAO_003");
		Object[] params = { userID, user.getUserName(), user.getUserPassword(), user.getMobile(), user.getDisabled(),
				user.getUserType(), user.getRecCreateBy(), user.getRecModifyBy(), user.getSalt() };
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		this.getJdbcTemplate().update(sql, params);
	}

	/**
	 * 获取sequence主键
	 * 
	 * @return
	 */
	private String getUserID() {
		String retID = null;
		String procedure = "{?=call sp_GetUserSeqId()}";
		try {
			retID = (String) this.getJdbcTemplate().execute(procedure, new CallableStatementCallback() {
				public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {
					cs.registerOutParameter(1, Types.VARCHAR); // 输出参数类型
					cs.execute();
					return cs.getString(1);
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
		int length = 10 - retID.length();
		for (int i = 0; i < length; i++) {
			retID = "0" + retID;
		}

		return retID;

	}
	
	/**
	 * 查询 客户信息维护 列表
	 * 
	 * @param userCode
	 * @return
	 */
	@Override
	public List<CusInfoMaintainDto> selectCUserList(QueryConditions qc, PageInfo pageInfo) {
		this.log.debug("selectCUserList DAO Start");
		List<CusInfoMaintainDto> retList = null;
		String sql = sqlProperty.getProperty("UserDAO_007");
		retList = queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new CusInfoMaintainDto()));
		return retList;
	}

	@Override
	public CusInfoMaintainModel selectCusInfoMaintainByUserCode(String userCode) {
		this.log.debug("selectCusInfoMaintainByUserCode DAO Start");
		String sql = sqlProperty.getProperty("UserDAO_008");
		Object[] params  = {userCode};
		return (CusInfoMaintainModel)this.queryForObject(sql, params, new CommonRowMapper(new CusInfoMaintainModel()));

	}

	@Override
	public void insertCusInfoMaintain(CusInfoMaintainModel model) {
		this.log.debug("insertCusInfoMaintain DAO Start");
		String sql = sqlProperty.getProperty("UserDAO_009");
		Object[] params  = {model.getUserCode(),model.getFirmName(),
				model.getContactTelNo(),
				model.getBusinessType(),
				model.getFax(),
				model.getAddressPV(),
				model.getAddressCT(),
				model.getAddressDT(),
				model.getAddress(),
				model.getPostCode(),
				model.getRemark(),
				model.getUserSource(),
				model.getOtherRemark(),
				model.getUserStatus(),
				model.getMaintainStatus(),
				model.getIsDanger(),
				model.getTradeAuthority(),
				0,
				model.getRecCreateby(),
				new Date(),
				model.getRecModifyby(),
				new Date()
		};
		this.updateBySQL(sql, params);
	}

	@Override
	public void updateCusInfoMaintain(CusInfoMaintainModel model) {
		this.log.debug("updateCusInfoMaintain DAO Start");
		String sql = sqlProperty.getProperty("UserDAO_010");
		Object[] params  = {model.getFirmName(),
				model.getContactTelNo(),
				model.getBusinessType(),
				model.getFax(),
				model.getAddressPV(),
				model.getAddressCT(),
				model.getAddressDT(),
				model.getAddress(),
				model.getPostCode(),
				model.getRemark(),
				model.getUserSource(),
				model.getOtherRemark(),
				model.getUserStatus(),
				model.getMaintainStatus(),
				model.getIsDanger(),
				model.getTradeAuthority(),
				model.getDisabled(),
				model.getRecModifyby(),
				new Date(),
				model.getUserCode()
		};
		this.updateBySQL(sql, params);
	}

	@Override
	public int countCusInfoMaintainByUserCode(String userCode) {
		this.log.debug("countCusInfoMaintainByUserCode DAO Start");
		String sql = sqlProperty.getProperty("UserDAO_011");
		Object[] params  = {userCode};
		return this.queryForInt(sql, params);
	}
	

	@Override
	public CusInfoCscfg getCusInfoCscfg(String userCode) {
		CusInfoCscfg cusInfoCscfg=new CusInfoCscfg();
		String sql=sqlProperty.getProperty("CusInfoDao_002");
		Object[] params={userCode};
		cusInfoCscfg=(CusInfoCscfg) queryForObject(sql, params, new CommonRowMapper(new CusInfoCscfg()));
		return cusInfoCscfg;
	}

	@Override
	public int addCusInfo(CusInfoCscfg cusInfoCscfg) {
		// TODO Auto-generated method stub
		String sql=sqlProperty.getProperty("CusInfoDao_001");
		Object[] params ={cusInfoCscfg.getUserCode(),cusInfoCscfg.getUserId(),cusInfoCscfg.getDisabled(),cusInfoCscfg.getRecCreateby(),cusInfoCscfg.getRecModifyby()};
		return this.updateBySQL(sql, params);
	}

	@Override
	public int updateCusInfo(CusInfoCscfg cusInfoCscfg) {
		String sql=sqlProperty.getProperty("CusInfoDao_003");
		Object[] params ={cusInfoCscfg.getUserId(),cusInfoCscfg.getRecModifyby(),cusInfoCscfg.getUserCode()};
		return this.updateBySQL(sql, params);
	}

	@Override
	public int updateUserErrorPswOfErrorNumsById(Integer id) {
		String sql=sqlProperty.getProperty("UserDAO_012");
		Object[] params ={id};
		return this.updateBySQL(sql, params);
	}
}
