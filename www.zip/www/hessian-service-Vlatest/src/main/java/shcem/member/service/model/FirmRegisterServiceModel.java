/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmRegisterServiceModel
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.service.model;

import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * (C_FIRMREGISTER)
 * 交易商注册信息
 * @author bianj
 * @version 1.0.0 2016-05-20
 */
public class FirmRegisterServiceModel extends BaseObject implements java.io.Serializable {
    /** 版本号 */
    private static final long serialVersionUID = 7026145037114339902L;
    
    /**  */
    private String firmRegId;
    
    /**  */
    private String firmName;
    
    /**  */
    private String fullName;
    
    /**  */
    private Integer firmType;
    
    /**  */
    private Integer businessType;
    
    /**  */
    private Integer disabled;
    
    /**  */
    private Integer firmStatus;
    
    /**  */
    private String addRess;
    
    /**  */
    private String fax;
    
    /**  */
    private String postCode;
    
    /**  */
    private String contactName;
    
    /**  */
    private String contactTelNo;
    
    /**  */
    private String contactMobile;
    
    /**  */
    private Integer bSlicense;
    
    /**  */
    private Integer taxLicense;
    
    /**  */
    private Integer orgCode;
    
    /**  */
    private Integer unifyLicense;
    
    /**  */
    private Integer dGLicense;
    
    /**  */
    private Integer settingBankID;
    
    /**  */
    private String settingBkBranch;
    
    /**  */
    private String settingBkAccount;
    
    /**  */
    private Integer vatBankID;
    
    /**  */
    private String vatBkBranch;
    
    /**  */
    private String vatBkAccount;
    
    /**  */
    private Integer vatPV;
    
    /**  */
    private Integer vatCT;
    
    /**  */
    private Integer vatDT;
    
    /**  */
    private String vatAddress;
    
    /**  */
    private String taxNo;
    
    /**  */
    private String vatContactTelNo;
    
    /**  */
    private Integer recPV;
    
    /**  */
    private Integer recCT;
    
    /**  */
    private Integer recDT;
    
    /**  */
    private String recAddRess;
    
    /**  */
    private String recContactName;
    
    /**  */
    private String recContactTelNo;
    
    /**  */
    private String recCreateby;
    
    /**  */
    private Date recCreateTime;
    
    /**  */
    private String recModifyby;
    
    /**  */
    private Date recModifyTime;
    
    //拓展属性
    private String firmID;

	public String getFirmRegId() {
		return firmRegId;
	}

	public void setFirmRegId(String firmRegId) {
		this.firmRegId = firmRegId;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Integer getFirmType() {
		return firmType;
	}

	public void setFirmType(Integer firmType) {
		this.firmType = firmType;
	}

	public Integer getBusinessType() {
		return businessType;
	}

	public void setBusinessType(Integer businessType) {
		this.businessType = businessType;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public Integer getFirmStatus() {
		return firmStatus;
	}

	public void setFirmStatus(Integer firmStatus) {
		this.firmStatus = firmStatus;
	}

	public String getAddRess() {
		return addRess;
	}

	public void setAddRess(String addRess) {
		this.addRess = addRess;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactTelNo() {
		return contactTelNo;
	}

	public void setContactTelNo(String contactTelNo) {
		this.contactTelNo = contactTelNo;
	}

	public String getContactMobile() {
		return contactMobile;
	}

	public void setContactMobile(String contactMobile) {
		this.contactMobile = contactMobile;
	}

	public Integer getBSlicense() {
		return bSlicense;
	}

	public void setBSlicense(Integer bSlicense) {
		this.bSlicense = bSlicense;
	}

	public Integer getTaxLicense() {
		return taxLicense;
	}

	public void setTaxLicense(Integer taxLicense) {
		this.taxLicense = taxLicense;
	}

	public Integer getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(Integer orgCode) {
		this.orgCode = orgCode;
	}

	public Integer getUnifyLicense() {
		return unifyLicense;
	}

	public void setUnifyLicense(Integer unifyLicense) {
		this.unifyLicense = unifyLicense;
	}

	public Integer getDGLicense() {
		return dGLicense;
	}

	public void setDGLicense(Integer dGLicense) {
		this.dGLicense = dGLicense;
	}

	public Integer getSettingBankID() {
		return settingBankID;
	}

	public void setSettingBankID(Integer settingBankID) {
		this.settingBankID = settingBankID;
	}

	public String getSettingBkBranch() {
		return settingBkBranch;
	}

	public void setSettingBkBranch(String settingBkBranch) {
		this.settingBkBranch = settingBkBranch;
	}

	public String getSettingBkAccount() {
		return settingBkAccount;
	}

	public void setSettingBkAccount(String settingBkAccount) {
		this.settingBkAccount = settingBkAccount;
	}

	public Integer getVatBankID() {
		return vatBankID;
	}

	public void setVatBankID(Integer vatBankID) {
		this.vatBankID = vatBankID;
	}

	public String getVatBkBranch() {
		return vatBkBranch;
	}

	public void setVatBkBranch(String vatBkBranch) {
		this.vatBkBranch = vatBkBranch;
	}

	public String getVatBkAccount() {
		return vatBkAccount;
	}

	public void setVatBkAccount(String vatBkAccount) {
		this.vatBkAccount = vatBkAccount;
	}

	public Integer getVatPV() {
		return vatPV;
	}

	public void setVatPV(Integer vatPV) {
		this.vatPV = vatPV;
	}

	public Integer getVatCT() {
		return vatCT;
	}

	public void setVatCT(Integer vatCT) {
		this.vatCT = vatCT;
	}

	public Integer getVatDT() {
		return vatDT;
	}

	public void setVatDT(Integer vatDT) {
		this.vatDT = vatDT;
	}


	public String getVatAddress() {
		return vatAddress;
	}

	public void setVatAddress(String vatAddress) {
		this.vatAddress = vatAddress;
	}

	public String getTaxNo() {
		return taxNo;
	}

	public void setTaxNo(String taxNo) {
		this.taxNo = taxNo;
	}
	public Integer getRecPV() {
		return recPV;
	}

	public void setRecPV(Integer recPV) {
		this.recPV = recPV;
	}

	public Integer getRecCT() {
		return recCT;
	}

	public void setRecCT(Integer recCT) {
		this.recCT = recCT;
	}

	public Integer getRecDT() {
		return recDT;
	}

	public void setRecDT(Integer recDT) {
		this.recDT = recDT;
	}

	public String getRecAddRess() {
		return recAddRess;
	}

	public void setRecAddRess(String recAddRess) {
		this.recAddRess = recAddRess;
	}

	public String getRecContactName() {
		return recContactName;
	}

	public void setRecContactName(String recContactName) {
		this.recContactName = recContactName;
	}

	public String getRecContactTelNo() {
		return recContactTelNo;
	}

	public void setRecContactTelNo(String recContactTelNo) {
		this.recContactTelNo = recContactTelNo;
	}

	public String getRecCreateby() {
		return recCreateby;
	}

	public void setRecCreateby(String recCreateby) {
		this.recCreateby = recCreateby;
	}

	public Date getRecCreateTime() {
		return recCreateTime;
	}

	public void setRecCreateTime(Date recCreateTime) {
		this.recCreateTime = recCreateTime;
	}

	public String getRecModifyby() {
		return recModifyby;
	}

	public void setRecModifyby(String recModifyby) {
		this.recModifyby = recModifyby;
	}

	public Date getRecModifyTime() {
		return recModifyTime;
	}

	public void setRecModifyTime(Date recModifyTime) {
		this.recModifyTime = recModifyTime;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getVatContactTelNo() {
		return vatContactTelNo;
	}

	public void setVatContactTelNo(String vatContactTelNo) {
		this.vatContactTelNo = vatContactTelNo;
	}
    
    
    
}