package shcem.member.dao.model;

import shcem.base.dao.model.BaseObject;

public class FirmRegTmptRlsp  extends BaseObject implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1773975085944143948L;
	private Integer tradeTmptId;
	private String firmRegId;
	private String enabled;
	private Integer isRealName;
	public Integer getTradeTmptId() {
		return tradeTmptId;
	}
	public void setTradeTmptId(Integer tradeTmptId) {
		this.tradeTmptId = tradeTmptId;
	}
	public String getFirmRegId() {
		return firmRegId;
	}
	public void setFirmRegId(String firmRegId) {
		this.firmRegId = firmRegId;
	}
	public String getEnabled() {
		return enabled;
	}
	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}
	public Integer getIsRealName() {
		return isRealName;
	}
	public void setIsRealName(Integer isRealName) {
		this.isRealName = isRealName;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
