package shcem.member.dao.model;

import java.io.Serializable;
import java.util.Date;

import shcem.base.dao.model.BaseObject;
import shcem.member.enums.FirmTypeConstant;

/**
 * 交易商列表展示
 * 
 * @author zhangnan
 *
 */
public class FirmDataList extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** 交易商编码 */
	private String firmID;

	/**  */
	private String firmRegID;

	/** 交易商名称 */
	private String firmName;

	/**  */
	private String firmNamePY;

	/** 交易商全称 */
	private String fullName;

	/** 企业类型 */
	private Integer firmType;

	private String firmTypeText;

	/** 业务类型 */
	private Integer businessType;

	private String businessTypeText;

	/** 当前审核状态 */
	private Integer firmStatus;

	private String firmStatusText;

	/** 地址 */
	private String address;

	/** 传真 */
	private String fax;

	/** 邮编 */
	private String postCode;

	/** 当前禁用类型 */
	private Integer disabled;

	/** 当前禁用类型 */
	private String disabledText;

	/** 创建人 */
	private String recCreateBy;

	/** 创建时间 */
	private Date recCreateTime;

	/** 最后修改人 */
	private String recModifyBy;

	/** 最后修改时间 */
	private Date recModifyTime;

	private Integer isBinding;

	// 联系人
	private String contactName;
	// 联系人手机
	private String contactMobile;
	/**
	 * 绑定的用户数
	 */
	private Integer traderNum;
	
	private Integer appType;
	
	// N 未冻结 Y 已冻结
	@Deprecated
	private String settingValue;
	/**1-是否禁用 2-是否黑名单 3-是否冻结 枚举 */
	private Integer firmSettingId1;
	// 交易商设置表 默认为 0：正常，1：失效
	private Integer firmSettingDisabled1;
	
	private Integer firmSettingId2;
	// 交易商设置表 默认为 0：正常，1：失效
	private Integer firmSettingDisabled2;
	
	private Integer firmSettingId3;
	// 交易商设置表 默认为 0：正常，1：失效
	private Integer firmSettingDisabled3;
	
	private String dGLicenseAuth;
	
	private Integer isAuthorized;
	
	/*推荐客服*/
	private String customerName;
	
	/*签约状态 1：未签约 2已签约*/
	private Integer isSignState;
	
	/**签约银行ID*/
	private String signBankID;
	
	/**签约银行名称*/
	private String signBankName;
	
	public Integer getFirmSettingId1() {
		return firmSettingId1;
	}

	public void setFirmSettingId1(Integer firmSettingId1) {
		this.firmSettingId1 = firmSettingId1;
	}

	public Integer getFirmSettingDisabled1() {
		return firmSettingDisabled1;
	}

	public void setFirmSettingDisabled1(Integer firmSettingDisabled1) {
		this.firmSettingDisabled1 = firmSettingDisabled1;
	}

	public Integer getFirmSettingId2() {
		return firmSettingId2;
	}

	public void setFirmSettingId2(Integer firmSettingId2) {
		this.firmSettingId2 = firmSettingId2;
	}

	public Integer getFirmSettingDisabled2() {
		return firmSettingDisabled2;
	}

	public void setFirmSettingDisabled2(Integer firmSettingDisabled2) {
		this.firmSettingDisabled2 = firmSettingDisabled2;
	}

	public Integer getFirmSettingId3() {
		return firmSettingId3;
	}

	public void setFirmSettingId3(Integer firmSettingId3) {
		this.firmSettingId3 = firmSettingId3;
	}

	public Integer getFirmSettingDisabled3() {
		return firmSettingDisabled3;
	}

	public void setFirmSettingDisabled3(Integer firmSettingDisabled3) {
		this.firmSettingDisabled3 = firmSettingDisabled3;
	}

	public String getSettingValue() {
		return settingValue;
	}

	public void setSettingValue(String settingValue) {
		this.settingValue = settingValue;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactMobile() {
		return contactMobile;
	}

	public void setContactMobile(String contactMobile) {
		this.contactMobile = contactMobile;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getFirmTypeText() {
		for (FirmTypeConstant firmTypeConstant : FirmTypeConstant.values()) {
			Integer row = firmTypeConstant.getFirmType();
			if (this.firmType == row) {
				return firmTypeConstant.getFirmTypeText();
			}
		}
		return firmTypeText;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public String getFirmNamePY() {
		return firmNamePY;
	}

	public void setFirmNamePY(String firmNamePY) {
		this.firmNamePY = firmNamePY;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Integer getFirmType() {
		return firmType;
	}

	public void setFirmType(Integer firmType) {
		this.firmType = firmType;
	}

	public Integer getBusinessType() {
		return businessType;
	}

	public void setBusinessType(Integer businessType) {
		this.businessType = businessType;
	}

	public String getBusinessTypeText() {
		return businessTypeText;
	}

	public void setBusinessTypeText(String businessTypeText) {
		this.businessTypeText = businessTypeText;
	}

	public Integer getFirmStatus() {
		return firmStatus;
	}

	public void setFirmStatus(Integer firmStatus) {
		this.firmStatus = firmStatus;
	}

	public String getFirmStatusText() {
		return firmStatusText;
	}

	public void setFirmStatusText(String firmStatusText) {
		this.firmStatusText = firmStatusText;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public String getRecCreateBy() {
		return recCreateBy;
	}

	public void setRecCreateBy(String recCreateBy) {
		this.recCreateBy = recCreateBy;
	}

	public Date getRecCreateTime() {
		return recCreateTime;
	}

	public void setRecCreateTime(Date recCreateTime) {
		this.recCreateTime = recCreateTime;
	}

	public String getRecModifyBy() {
		return recModifyBy;
	}

	public void setRecModifyBy(String recModifyBy) {
		this.recModifyBy = recModifyBy;
	}

	public Date getRecModifyTime() {
		return recModifyTime;
	}

	public void setRecModifyTime(Date recModifyTime) {
		this.recModifyTime = recModifyTime;
	}

	public void setFirmTypeText(String firmTypeText) {
		this.firmTypeText = firmTypeText;
	}

	public String getDisabledText() {
		return disabledText;
	}

	public void setDisabledText(String disabledText) {
		this.disabledText = disabledText;
	}

	public String getFirmRegID() {
		return firmRegID;
	}

	public void setFirmRegID(String firmRegID) {
		this.firmRegID = firmRegID;
	}

	/**
	 * @return the isBinding
	 */
	public Integer getIsBinding() {
		return isBinding;
	}

	/**
	 * @param isBinding
	 *            the isBinding to set
	 */
	public void setIsBinding(Integer isBinding) {
		this.isBinding = isBinding;
	}

	public Integer getTraderNum() {
		return traderNum;
	}

	public void setTraderNum(Integer traderNum) {
		this.traderNum = traderNum;
	}

	public Integer getAppType() {
		return appType;
	}

	public void setAppType(Integer appType) {
		this.appType = appType;
	}

	public String getDGLicenseAuth() {
		return dGLicenseAuth;
	}

	public void setDGLicenseAuth(String dGLicenseAuth) {
		this.dGLicenseAuth = dGLicenseAuth;
	}

	public Integer getIsAuthorized() {
		return isAuthorized;
	}

	public void setIsAuthorized(Integer isAuthorized) {
		this.isAuthorized = isAuthorized;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Integer getIsSignState() {
		return isSignState;
	}

	public void setIsSignState(Integer isSignState) {
		this.isSignState = isSignState;
	}

	public String getSignBankID() {
		return signBankID;
	}

	public void setSignBankID(String signBankID) {
		this.signBankID = signBankID;
	}

	public String getSignBankName() {
		return signBankName;
	}

	public void setSignBankName(String signBankName) {
		this.signBankName = signBankName;
	}
	
}
