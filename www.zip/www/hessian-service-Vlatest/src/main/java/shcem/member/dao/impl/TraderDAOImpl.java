/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: TraderDAOImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.dao.impl;

import java.util.List;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.member.dao.TraderDAO;
import shcem.member.dao.model.TradeAllData;
import shcem.member.dao.model.Trader;
import shcem.member.dao.model.TraderDataList;
import shcem.member.dao.model.TraderTmptRlsp;
import shcem.member.dao.model.User;
import shcem.member.service.model.userMobileModel;
import shcem.util.CommonRowMapper;

/**
 * @author wlpod
 *
 */
public class TraderDAOImpl extends BaseDAOImpl implements TraderDAO {

	@Override
	public List<TraderDataList> getTraderList(QueryConditions qc, PageInfo pageInfo,String firmID) {
		this.log.debug("getFirmList DAO Start");
		List<TraderDataList> retList = null;
		String sql = sqlProperty.getProperty("TraderDAO_001");
		String sql_firm = sqlProperty.getProperty("TraderDAO_014");
		Object[] params = {firmID};
		if (pageInfo  == null || qc == null) {
			retList = queryBySQL(sql_firm, params, null, new CommonRowMapper(new TraderDataList()));
		}else {
			retList = queryBySQL(sql, qc, pageInfo,  new CommonRowMapper(new TraderDataList()));
		}
		
		return retList;
	}
	
	@Override
	public TradeAllData getTrader(String traderID) {
		TradeAllData tradeAllData = new TradeAllData();
		Object[] params = { traderID };
		String sql = sqlProperty.getProperty("TraderDAO_015") ;
		tradeAllData = (TradeAllData) queryForObject(sql, params, new CommonRowMapper(new TradeAllData()));
		return tradeAllData;
	}

	/* (non-Javadoc)
	 * @see shcem.member.dao.TraderDAO#addTrader(shcem.member.dao.model.Trader)
	 */
	@Override
	public Integer addTrader(Trader trader) {
		int row = -1;
		String sql = sqlProperty.getProperty("TraderDAO_003");
		Object [] params = {
				trader.getTraderID(),trader.getTraderName(),trader.getTraderPassword(),
			1,trader.getDisabled(),trader.getFirmID(),trader.getFirmType(),trader.getUserCode(),trader.getRecCreateBy(),
			trader.getRecModifyBy()
		};
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		row = this.getJdbcTemplate().update(sql, params);
		//同时修改绑定用户为交易用户
		this.chgUserType(1, trader.getUserCode());
		return row;
	}

	@Override
	public int bindUser(TradeAllData trader,User user) {
		int row = -1;
		//更新之前的用户 修改用户为浏览用户
		Unbundling(trader.getTraderID()); 
		
		String sql = sqlProperty.getProperty("TraderDAO_004");
		Object [] params = {
				user.getUserName(),trader.getDisabled(),trader.getFirmType(),user.getUserCode(),
			trader.getRecModifyBy(),trader.getTraderID()
		};
		row = this.getJdbcTemplate().update(sql, params);
		
		if(trader.getUserCode()==null){
			
		}else{
			this.chgUserType(1,trader.getUserCode()); //同时修改用户为交易用户
		}
		return row;
	}
	/* (non-Javadoc)
	 * @see shcem.member.dao.TraderDAO#updateTrader(shcem.member.dao.model.Trader)
	 */
	@Override
	public int updateTrader(Trader trader) {
		String sql = sqlProperty.getProperty("TraderDAO_004");
		Object [] params = {
				trader.getTraderName(),trader.getDisabled(),trader.getFirmType(),trader.getUserCode(),
			trader.getRecModifyBy(),trader.getTraderID()
		};
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		
		//更新之前的用户 修改用户为浏览用户
		Unbundling(trader.getTraderID()); //同时修改用户为浏览用户
		
		int rowNm = this.getJdbcTemplate().update(sql, params);
		
		if(trader.getUserCode()==null){
			
		}else{
			this.chgUserType(1,trader.getUserCode()); //同时修改用户为交易用户
		}
		return rowNm;
	}

	/* (non-Javadoc)
	 * @see shcem.member.dao.TraderDAO#disableTrader(java.lang.String)
	 */
	@Override
	public int disableTrader(String traderID) {
		String sql = sqlProperty.getProperty("TraderDAO_005");
		Object [] params = {
				traderID
		};
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		int rowNm = this.getJdbcTemplate().update(sql, params);
		return rowNm;
	}

	/* (non-Javadoc)
	 * @see shcem.member.dao.TraderDAO#enableTrader(java.lang.String)
	 */
	@Override
	public int enableTrader(String traderID) {
		String sql = sqlProperty.getProperty("TraderDAO_006");
		Object [] params = {
				traderID
		};
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		int rowNm = this.getJdbcTemplate().update(sql, params);
		return rowNm;
	}

	/* (non-Javadoc)
	 * @see shcem.member.dao.TraderDAO#checkUserIDExisted(java.lang.String)
	 */
	@Override
	public boolean checkUserIDExisted(String userCode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public User getUserById(String userCode) {
		User user = new User();
		Object[] params = { userCode };
		String sql = sqlProperty.getProperty("TraderDAO_002") ;
		user = (User) queryForObject(sql, params, new CommonRowMapper(new User()));
		return user;
	}

	@Override
	public int Unbundling(String tradeID) {
		int rowNm =-1;
		TradeAllData trader = getTrader(tradeID);
		if(trader.getUserCode()!=null){
			
			this.chgUserType(0,trader.getUserCode()); //同时修改用户为浏览用户
			
			String sql = sqlProperty.getProperty("TraderDAO_008");
			Object [] params = {
				null,tradeID
			};	
			rowNm = this.getJdbcTemplate().update(sql, params);
		}
		
		return rowNm;
	}
	
	@Override
	public int chgUserType(Integer userType,String userCode){
		String sql = sqlProperty.getProperty("TraderDAO_012");
		Object[] params = { userType,userCode };
		int rowNm = this.getJdbcTemplate().update(sql, params);
		return rowNm;
	}
	
	@Override
	public List<User> getUserByMobile(String mobile) {
		User user = new User();
		Object[] params = { mobile};
		this.log.debug("getFirmList DAO Start");
		List<User> retList = null;
		String sql = sqlProperty.getProperty("UserDAO_006");
		retList =queryBySQL(sql, params, null, new CommonRowMapper(new User()) );
		return retList;
	}
	@Override
	public List<TraderTmptRlsp> getTraderTmptRlspList(String traderID) {
		String sql = this.sqlProperty.getProperty("TraderDAO_009");
		Object[] param ={
				traderID	
		};
		return this.queryBySQL(sql, param, null, new CommonRowMapper(new TraderTmptRlsp()));
	}
	
	@Override
	public void addTraderTmptRlsps(TraderTmptRlsp traderTmptRlsp) {
		String sql = this.sqlProperty.getProperty("TraderDAO_010");
		Object[] param = {
				traderTmptRlsp.getTradeTmptId(),traderTmptRlsp.getTraderID(),traderTmptRlsp.getEnabled()
		};
		this.updateBySQL(sql, param);
	}
	@Override
	public void delTraderTmptRlsps(String traderID) {
		String sql = this.sqlProperty.getProperty("TraderDAO_011");
		Object[] param = {
				traderID
		};
		this.updateBySQL(sql, param);
	}
	
	@Override
	public List<Trader> getTraderByUserCode(String userCode) {
		String sql = this.sqlProperty.getProperty("TraderDAO_013");
		Object[] param ={
				userCode	
		};
		return this.queryBySQL(sql, param, null, new CommonRowMapper(new Trader()));
	}
	
	@Override
	public List<Trader> getTraderListByFirmID(String firmID) {
		String sql = this.sqlProperty.getProperty("TraderDAO_016");
		Object[] param ={
				firmID	
		};
		return this.queryBySQL(sql, param, null, new CommonRowMapper(new Trader()));
	}
	/**
	 * 交易商的交易场权限发生变化应该同步影响交易员的权限
	 * @param traderID
	 * @param firmTmptRlspString
	 */
	@Override
	public void updateTraderTmptRlsps(String traderID, String firmTmptRlspString) {
		String sql = "DELETE FROM A_TraderTmptRlsp WHERE TradeTmptId NOT IN ("+firmTmptRlspString+") and TraderID ='"+traderID+"'";
		this.updateBySQL(sql);
	}
	/**
	 * 禁用用户的同时，起绑定的交易员userCode置null
	 */
	@Override
	public void updateTraderByUserCode(String userCode) {
		String sql = "update  C_Trader SET UserCode = NULL WHERE UserCode = '"+userCode+"'";
		this.updateBySQL(sql);
	}
	@Override
	public void rollBack() {
		try {
			this.getConnection().setAutoCommit(false);//事务设置为手动
			getConnection().rollback();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public int updateTraderStatusByTraderID(Trader trader,String exeUsername) {
		String sql = this.sqlProperty.getProperty("TraderDAO_020");
		Object[] params ={
				trader.getTraderStatus(),exeUsername,
				trader.getFrozenRemark(),
				trader.getTraderID()
		};
		return this.updateBySQL(sql, params);
	}

	@Override
	public List<TraderDataList> getTraderList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getTraderList DAO Start");
		List<TraderDataList> retList = null;;
		String sql = sqlProperty.getProperty("TraderDAO_024");
		retList = queryBySQL(sql, qc, pageInfo,  new CommonRowMapper(new TraderDataList()));
		return retList;
	}

	@Override
	public List<userMobileModel> queryUserMobileList(QueryConditions qc,
			PageInfo pageInfo,String userCode) {
		this.log.debug("queryUserMobileList DAO Start");
		List<userMobileModel> userlist = null;
		String sql = sqlProperty.getProperty("TraderDAO_025")+"  and temp.UserCode ='"+userCode+"'";
		userlist = queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new userMobileModel()));
		return userlist;
	}

	@Override
	public int getMobileCount(String userCode) {
		this.log.debug("getMobileCount DAO Start");
		String sql = sqlProperty.getProperty("TraderDAO_026");
		Object[] params ={userCode};
		int count = this.queryForInt(sql, params);
		return count;
	}

	@Override
	public int addUserMobile(String moreMobile, String userCode, String userName) {
		this.log.debug("addUserMobile DAO Start");
		String sql = sqlProperty.getProperty("TraderDAO_027");
		Object[] params = { userCode,moreMobile,userName,userName };
		return this.updateBySQL(sql, params);
	}

	@Override
	public int changeUserMobile(int id, String moreMobile, String userName) {
		this.log.debug("changeUserMobile DAO Start");
		String sql = sqlProperty.getProperty("TraderDAO_028");
		Object[] params = { moreMobile,userName,id };
		return this.updateBySQL(sql, params);
	}

	@Override
	public int unBindUserMobile(int id) {
		this.log.debug("unBindUserMobile DAO Start");
		String sql = sqlProperty.getProperty("TraderDAO_029");
		Object[] params = { id };
		return this.updateBySQL(sql, params);
	}

	@Override
	public int getSameMobile(String moreMobile, String userCode) {
		this.log.debug("getSameMobile DAO Start");
		String sql = sqlProperty.getProperty("TraderDAO_030");
		Object[] params = {moreMobile, userCode};
		int count = queryForInt(sql, params);
		return count;
	}
	
}
