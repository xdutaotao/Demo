package shcem.member.dao.model;

import java.io.Serializable;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**开票地址
 * @author zhangnan
 *
 */
public class VatAddRess extends BaseObject implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**  */
    private Integer id;
    /** 开票地址(省ID） */
    private Integer vatPV;
    /**开票地址(市ID）  */
    private Integer vatCT;
    /** 开票地址(区ID） */
    private Integer vatDT;
    /** 开票详细地址 */
    private String vatAddress;
    /**  */
    private Integer dISABLED;
    /** 开票联系人电话 */
    private String vatContactName;
    /**  */
    private String vatContactTelNo;
    /**  */
    private Date createTime;
    /**  */
    private Date updateTime;
    /** 开票银行账号*/
    private String vatBkAccount;
	/** 开票银行ID 关联VW_Bank*/
    private Integer vatBankID;
    /** 开票银行支行*/
    private String vatBkBranch;
    
    public Integer getDISABLED() {
		return dISABLED;
	}

	public void setDISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public String getVatBkAccount() {
		return vatBkAccount;
	}

	public void setVatBkAccount(String vatBkAccount) {
		this.vatBkAccount = vatBkAccount;
	}

	public Integer getVatBankID() {
		return vatBankID;
	}

	public void setVatBankID(Integer vatBankID) {
		this.vatBankID = vatBankID;
	}

	public String getVatBkBranch() {
		return vatBkBranch;
	}

	public void setVatBkBranch(String vatBkBranch) {
		this.vatBkBranch = vatBkBranch;
	}


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getVatPV() {
		return vatPV;
	}

	public void setVatPV(Integer vatPV) {
		this.vatPV = vatPV;
	}

	public Integer getVatCT() {
		return vatCT;
	}

	public void setVatCT(Integer vatCT) {
		this.vatCT = vatCT;
	}

	public Integer getVatDT() {
		return vatDT;
	}

	public void setVatDT(Integer vatDT) {
		this.vatDT = vatDT;
	}

	public String getVatAddress() {
		return vatAddress;
	}

	public void setVatAddress(String vatAddress) {
		this.vatAddress = vatAddress;
	}

	public String getVatContactName() {
		return vatContactName;
	}

	public void setVatContactName(String vatContactName) {
		this.vatContactName = vatContactName;
	}

	public String getVatContactTelNo() {
		return vatContactTelNo;
	}

	public void setVatContactTelNo(String vatContactTelNo) {
		this.vatContactTelNo = vatContactTelNo;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
