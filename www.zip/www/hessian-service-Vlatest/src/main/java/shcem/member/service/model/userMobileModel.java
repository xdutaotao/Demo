package shcem.member.service.model;

import java.io.Serializable;
import java.util.Date;

import org.json.JSONObject;

import shcem.base.dao.model.BaseObject;

public class userMobileModel extends BaseObject implements Serializable{
	
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 用户手机号关联表自增ID
	 */
	private Integer id;
	/**
	 * 用户编码
	 */
	private String userCode;
	/**
	 * 用户名
	 */
	private String userName;
	/**
	 * 主手机号
	 */
	private String mobile;
	/**
	 * 关联手机号
	 */
	private String moreMobile;
	/**
	 * 用户手机关联表 默认为 0：正常，1：失效
	 */
	private Integer dISABLED;
	/**
	 * 主号码的操作人
	 */
	private String rEC_CREATEBY;
	/**
	 * 主号码的操作时间
	 */
	private Date rEC_CREATETIME;
	/**
	 * 关联号码的操作人
	 */
	private String moreREC_CREATEBY;
	/**
	 * 关联号码的操作时间
	 */
	private Date moreREC_CREATETIME;
	
	/**是否可以操作:0 主数据不能操作  1：辅数据可以操作*/
	private Integer isOpt;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getMoreMobile() {
		return moreMobile;
	}

	public void setMoreMobile(String moreMobile) {
		this.moreMobile = moreMobile;
	}

	public Integer getDISABLED() {
		return dISABLED;
	}

	public void setDISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getMoreREC_CREATEBY() {
		return moreREC_CREATEBY;
	}

	public void setMoreREC_CREATEBY(String moreREC_CREATEBY) {
		this.moreREC_CREATEBY = moreREC_CREATEBY;
	}

	public Date getMoreREC_CREATETIME() {
		return moreREC_CREATETIME;
	}

	public void setMoreREC_CREATETIME(Date moreREC_CREATETIME) {
		this.moreREC_CREATETIME = moreREC_CREATETIME;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public boolean equals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Integer getIsOpt() {
		return isOpt;
	}

	public void setIsOpt(Integer isOpt) {
		this.isOpt = isOpt;
	}

}
