/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmManager.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月6日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.component.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.dao.model.CDictionary;
import shcem.common.service.model.ValueTxtView;
import shcem.common.util.DictionaryConstant;
import shcem.constant.Constants;
import shcem.finance.component.IFirmBanlanceOraManager;
import shcem.finance.dao.FirmBanlanceOraDAO;
import shcem.finance.util.FinanceOraSysData;
import shcem.member.component.IFirmManager;
import shcem.member.dao.FirmDAO;
import shcem.member.dao.TraderDAO;
import shcem.member.dao.model.FirmAllData;
import shcem.member.dao.model.FirmApp;
import shcem.member.dao.model.FirmDataList;
import shcem.member.dao.model.FirmDetaiData;
import shcem.member.dao.model.FirmDetail;
import shcem.member.dao.model.FirmPositionLimitModel;
import shcem.member.dao.model.FirmRegTmptRlsp;
import shcem.member.dao.model.FirmRegister;
import shcem.member.dao.model.FirmSetting;
import shcem.member.dao.model.FirmTmptRlsp;
import shcem.member.dao.model.Firminvoice;
import shcem.member.dao.model.Firmvatinfo;
import shcem.member.dao.model.RecAddRess;
import shcem.member.dao.model.Shop;
import shcem.member.dao.model.ShopFirm;
import shcem.member.dao.model.Trader;
import shcem.member.dao.model.User;
import shcem.member.dao.model.VatAddRess;
import shcem.member.util.ClearSessionUtil;
import shcem.systemMgr.dao.ISystemMgrDAO;
import shcem.systemMgr.dao.model.MUser;
import shcem.util.Common;
import shcem.util.EncrypMD5;

/**
 * @author wlpod
 *
 */
public class FirmManagerImpl extends BaseManager implements IFirmManager {
	private FirmDAO dao;
	private FirmDAO firmDAO_read;
	private TraderDAO traderDAO;
	private ISystemMgrDAO systemMgrDAO;
	private FirmBanlanceOraDAO firmBanlanceOraDAO;
	
	private IFirmBanlanceOraManager firmBanlanceOraManager = null;
	
	public void setTraderDAO(TraderDAO traderDAO) {
		this.traderDAO = traderDAO;
	}
	public void setFirmDAO(FirmDAO dao) {
		this.dao = dao;
	}
	public void setFirmDAO_read(FirmDAO firmDAO_read) {
		this.firmDAO_read = firmDAO_read;
	}
	public void setSystemMgrDAO(ISystemMgrDAO systemMgrDAO) {
		this.systemMgrDAO = systemMgrDAO;
	}
	public void setFirmBanlanceOraDAO(FirmBanlanceOraDAO firmBanlanceOraDAO) {
		this.firmBanlanceOraDAO = firmBanlanceOraDAO;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.trade.component.IFirmManager#getFirmList()
	 */
	@Override
	public List<FirmDataList> getFirmList(QueryConditions qc,PageInfo pageInfo) {
		List<FirmDataList> list = this.firmDAO_read.getFirmList(qc,pageInfo);
		
		
		//交易商企业类型、禁用类型
		if (list != null && list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				String firmID = list.get(i).getFirmID();
				FirmDataList firmDataList = new FirmDataList();
				firmDataList.setFirmType(list.get(i).getFirmType());
				list.get(i).setFirmTypeText(firmDataList.getFirmTypeText());
				
				list.get(i).setDisabledText("审核通过");
				//交易商绑定的用户数
				int traderNum = this.firmDAO_read.getTotalTraderNum(firmID);
				list.get(i).setTraderNum(traderNum);
			}
		}
		return list;
	}

	public static void main(String[] args) {
		FirmDataList firmDataList = new FirmDataList();
		firmDataList.setFirmType(0);
		System.err.println(firmDataList.getFirmTypeText());
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.trade.component.IFirmManager#getFirm(java.lang.String)
	 */
	@Override
	public FirmAllData getFirm(String firmId)throws RuntimeException {
		FirmAllData firmAllData = this.firmDAO_read.getFirm(firmId);
		/**
		 * 交易商 交易场权限
		 */
		List<FirmTmptRlsp> firmTmptRlspList = this.firmDAO_read.getFirmTmptRlspList(firmId);
		if (firmTmptRlspList != null && firmTmptRlspList.size()>0) {
			firmAllData.setFirmTmptRlspList(firmTmptRlspList);
		}
		
		/**
		 * 开票信息
		 */
		List<VatAddRess> vatAddRessList = this.firmDAO_read.getAddRessList(firmId);
		this.setVatAddress(firmAllData,vatAddRessList);
		return firmAllData;
	}

	@Override
	public int updateFirm(FirmDetaiData firmDetaiData, int[] firmTmptRlsps,String userID, String userName, String mode, String requestId) {
		MUser muser = this.systemMgrDAO.getUserByLoginName(userID)==null?new MUser():this.systemMgrDAO.getUserByLoginName(userID);
		FirmDetail firmDetail = firmDetaiData.getFirmDetailBean();
		firmDetail.setRecModifyby(muser.getName()==null?"system":muser.getName());
		int row = 0;
		try {
			//交易商主表信息更新
			row =  this.dao.updateFirm(firmDetail);
			//交易商应用关联关系
			this.addFirmApp(firmDetaiData.getFirmID(), 1, muser.getName()==null?"system":muser.getName());
			//交易场
			this.addFirmTmptRlspsList(firmDetaiData.getFirmID(), firmDetaiData.getFirmTmptRlspList(),
					firmDetaiData.getFirmDetailBean().getTradeAuthority(),
					firmDetaiData.getFirmDetailBean().getRdaTradeAuthorityXX());
			
			//交易商详细信息更新
			row = this.dao.updateFirmDetail(firmDetail);
			
			//更新交易商增值税开票信息
			VatAddRess vatAddRess = firmDetaiData.getVatAddRessBean();
			Firmvatinfo firmvatinfo = this.dao.queryFirmvatinfo(firmDetaiData.getFirmID());
			this.updateVatAddress(firmDetaiData,vatAddRess,firmvatinfo,row);
			if(firmDetaiData.getIsClearSession()){
				int returnCode = ClearSessionUtil.clearSession(firmDetaiData.getFirmID(), userName, mode, requestId);
				if(returnCode == -1){
					this.rollBack();
					return returnCode;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			row = -1;
			this.rollBack();
		}
		return row;
	}
	@Override
	public int addFirm(FirmDetaiData firmDetaiData, int[] firmTmptRlsps,String userID) {
		int returnCode = 0;
		FirmAllData tempFirmAllData = this.dao.getFirm(firmDetaiData.getFirmID());
		this.log.debug("this.dao.getFirm end");
		this.getBeans();
		//老专场是否已经存在
		returnCode = this.firmBanlanceOraManager.checkFirmForOra(firmDetaiData.getFirmID());
		if (tempFirmAllData != null || returnCode != 0) {
			//直接跳出
			return returnCode = -1;
		}
		MUser muser = this.systemMgrDAO.getUserByLoginName(userID)==null?new MUser():this.systemMgrDAO.getUserByLoginName(userID);
		this.log.debug("this.systemMgrDAO.getUserByLoginName end");
		
		this.log.debug("this.systemMgrDAO.getUserByLoginName end");
		
		//全称没有的情况下，用名称填充
		if(Common.isEmpty(firmDetaiData.getFullName())){
			String firmName = firmDetaiData.getFirmName();
			firmDetaiData.setFullName(firmName);
		}
		if(Common.isEmpty(firmDetaiData.getFirmDetailBean().getFullName())){
			String firmName = firmDetaiData.getFirmDetailBean().getFirmName();
			firmDetaiData.getFirmDetailBean().setFullName(firmName);
		}
		
		//后台操作人员，存到session里
		firmDetaiData.getFirmDetailBean().setRecCreateby(muser.getName()==null?"":muser.getName());
		firmDetaiData.getFirmDetailBean().setRecModifyby(muser.getName()==null?"":muser.getName());
		//交易商列表
		FirmDetail firmDetail = firmDetaiData.getFirmDetailBean();  
		firmDetail.setRecCreateby(muser.getName()==null?"":muser.getName());
		firmDetail.setRecModifyby(muser.getName()==null?"":muser.getName());
		
		try {
			
			//交易商主表信息
			returnCode =  this.dao.addFirm(firmDetail);
			this.log.debug("this.dao.addFirm end");
			
			//交易商应用关联关系
			this.addFirmApp(firmDetaiData.getFirmID(), 1, muser.getName()==null?"":muser.getName());
			
			//产生推荐的交易商编号被使用，更改状态  后续不在该编号不在被推荐使用
			this.dao.updateFirmIDPoolIsUsed(firmDetail.getFirmID());
			this.log.debug("this.dao.updateFirmIDPoolIsUsed end");
			
			//交易商交易场权限
			//this.addFirmTmptRlsps(firmDetaiData.getFirmID(), firmTmptRlsps);
			this.addFirmTmptRlspsList(firmDetaiData.getFirmID(), firmDetaiData.getFirmTmptRlspList(),
					firmDetaiData.getFirmDetailBean().getTradeAuthority(),
					firmDetaiData.getFirmDetailBean().getRdaTradeAuthorityXX());
			this.log.debug("this.addFirmTmptRlsps end");
			this.log.debug("this.addFirmTmptRlsps end");
			
			//交易商详情
			returnCode =  this.dao.addFirmDetail(firmDetail);
			this.log.debug("this.dao.addFirmDetail end");
			
			 //交易商收票地址信息
//			this.addRecAddRess(firmDetaiData.getRecAddRessBean(),firmDetaiData.getFirminvoiceBean(),
//					firmDetaiData.getRecContactTelNo(), firmDetaiData.getRecContactName());
			
			//交易商开票信息
			this.addFirmVATInfo(firmDetaiData.getVatAddRessBean(),firmDetaiData.getFirmvatinfoBean(),returnCode);
			this.log.debug("this.addFirmVATInfo end");
			//注册自动绑定交易员（自动绑定提请人为交易员）
			if (firmDetail.getFirmRegId() != null){
				returnCode = this.bindUser(firmDetaiData.getFirmRegId(),firmDetaiData.getFirmID(),firmDetaiData.getRequestUserId(),firmDetaiData.getFlag(),muser);
				if(returnCode <= 0){
					this.rollBack();
					return returnCode = -21006;
				}
			}
			this.log.debug("this.bindUser end");
			
			/**
			 * add 设定交易商 "销售限额" 20170206下午 
			 * 默认按金额
			 * 	限额类型，0：按金额 1：按重量 
			 */
			this.log.info(this.getClass().getName()+" addFirmPositionLimit Start");
			returnCode = this.addFirmPositionLimit(userID,firmDetaiData.getFirmID());
			if(returnCode < 0) return returnCode;
			this.log.info(this.getClass().getName()+" addFirmPositionLimit End");
			
			
			//相应的同步至老专场
			/*开户银行全称：银行+支行*/
			if(firmDetaiData.getVatBankID() != null){
				ValueTxtView bankObj = this.dao.getBankObj(firmDetaiData.getVatBankID());
				String vatBkBranchTemp = firmDetaiData.getVatBkBranch()==null?"":firmDetaiData.getVatBkBranch();
				String vatBkBranch = bankObj.getText()+"-"+vatBkBranchTemp;
				if(bankObj.getText().trim().replace(" ", "").contains("其他") || bankObj.getText().replace(" ", "").contains("其它")){
					vatBkBranch = vatBkBranchTemp;
				}
				if(vatBkBranch.replace(" ", "").getBytes("GBK").length > 64){
					System.err.println("推送到老专场 银行名称 长度："+vatBkBranch.replace(" ", "").getBytes("GBK").length);
					this.log.info(this.getClass().getName()+":SB,推送到老专场 银行名称 【"+vatBkBranch.replace(" ", "")+"】 字节长度为"+vatBkBranch.replace(" ", "").getBytes("GBK").length+",超过64位，失败！");
					this.rollBack();
					return returnCode = -21011;
				}
				firmDetaiData.setVatBkBranch(vatBkBranch.replace(" ", ""));
				
				
				/*开户银行地址信息:省市区+地址*/
				ValueTxtView addRessProvinceObj = this.dao.getBankAddRessObj(firmDetaiData.getVatPV());
				ValueTxtView addRessCountyObj = this.dao.getBankAddRessObj(firmDetaiData.getVatCT());
				ValueTxtView addRessDistrictObj = this.dao.getBankAddRessObj(firmDetaiData.getVatDT());
				String vatAddress = firmDetaiData.getVatAddress(); 
				if(addRessDistrictObj != null){
					vatAddress ="";
					vatAddress = addRessProvinceObj.getText()+"-"+addRessCountyObj.getText()+"-"+addRessDistrictObj.getText()+"-"+firmDetaiData.getVatAddress(); 
				}
				firmDetaiData.setVatAddress(vatAddress);
			}
			
			this.getBeans();
			returnCode = this.firmBanlanceOraManager.addFirmForOra(firmDetaiData.getFirmID(), firmDetaiData.getFirmName(),firmDetaiData);
			this.log.debug("this.firmBanlanceOraManager.addFirmForOra end");
			this.log.debug("returnCode = " + returnCode);
			if (returnCode != 0) {
				returnCode = -1;
				this.rollBack();
			}
		} catch (Exception e) {
			e.printStackTrace();
			returnCode = -1;
			this.rollBack();
		}
		return returnCode;
	}
	
	/**
	 * 审核通过交易商信息时，默认设定交易商 "销售限额" add 20170206下午
	 * 添加限额种类PositionDesc,,所有头寸以此判断，为了兼容原来的数据,GoodsType做同值替换。Modify by wl 2017/07/17
	 * 默认按金额
	 *   限额类型，0：按金额 1：按重量 
	 * @param userID
	 * @param firmID
	 * @return
	 */
	
	private int addFirmPositionLimit(String userID, String firmID) {
		int returnCode = 0;
		List<FirmPositionLimitModel> firmPositionLimitModelList = new ArrayList<FirmPositionLimitModel>();
		List<CDictionary> positionDescDicList = DictionaryConstant.getDicListByENName("PositionDesc");
		Integer defaultPositionLimitType = 0;  // 默认限额类型，0：按金额  //
		BigDecimal defaultPositionLimitValue = new BigDecimal(0);  // 默认限额：0  //
		for(CDictionary dic:positionDescDicList){//根据字典表中的限额类型 循环插入
			FirmPositionLimitModel firmPositionLimitModel = new FirmPositionLimitModel();   
			Integer dicValueId = new Integer(dic.getValueID()); //选字典中的valueid
			firmPositionLimitModel.setGoodsType(dicValueId);//原goodsType同 positiondesc.
			firmPositionLimitModel.setPositionDesc(dicValueId);
			firmPositionLimitModel.setPositionLimitType(defaultPositionLimitType);
			firmPositionLimitModel.setPositionLimitValue(defaultPositionLimitValue);
			firmPositionLimitModelList.add(firmPositionLimitModel);
		}
//		//货品类型，0：现货 1：预售
//		//现货限额  /** 限额类型，0：按金额 1：按重量 */
//		FirmPositionLimitModel firmPositionLimitModel_1 = new FirmPositionLimitModel();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
//		firmPositionLimitModel_1.setGoodsType(0);
//		firmPositionLimitModel_1.setPositionDesc(0);
//		firmPositionLimitModel_1.setPositionLimitType(0);
//		firmPositionLimitModel_1.setPositionLimitValue(new BigDecimal(0));
//		
//		//预售限额 
//		FirmPositionLimitModel firmPositionLimitModel_2 = new FirmPositionLimitModel();
//		firmPositionLimitModel_2.setGoodsType(1);
//		firmPositionLimitModel_2.setPositionLimitType(0);
//		firmPositionLimitModel_2.setPositionLimitValue(new BigDecimal(0));
//		firmPositionLimitModelList.add(firmPositionLimitModel_1);
//		firmPositionLimitModelList.add(firmPositionLimitModel_2);
		returnCode = this.updateFirmPositionLimitByFirmID(firmPositionLimitModelList, userID, firmID);
		return returnCode;
	}
	@Override
	public List<FirmRegister> getRegisteredFirmList(QueryConditions qc,
			PageInfo pageInfo) {
		List<FirmRegister> temList = this.firmDAO_read.getRegisteredFirmList(qc,pageInfo);
		return temList;
	}

	@Override
	public FirmRegister getRegisteredFirmDetail(String firmRegId) {
		FirmRegister firmRegister = this.firmDAO_read.getRegisteredFirmDetail(firmRegId);
		return firmRegister;
	}

	@Override
	public int  updateFirmDisabled(String firmID, int disabled)throws RuntimeException{
		int returnCode = 0;
		FirmAllData firm = this.dao.getFirm(firmID);
		try {
			if (firm.getBalance().compareTo(new BigDecimal(0)) > 0) {
				returnCode = -1;
			}else {
				this.dao.updateFirmDisabled(firmID,disabled);
				returnCode = 1;
			}
		} catch (Exception e) {
			e.printStackTrace();
			returnCode = -2;
			this.rollBack();
		}
		return returnCode;
	}
	
	
	@Override
	public int updateFirmRegister(FirmRegister firmRegister,boolean approved,Object approvedTemp) {
		if(approved){
			// 删除 注册交易商交易场关系
	 		this.dao.deleteFirmRegTmptRlspByFirmRegId(firmRegister.getFirmRegId());
	 		// 插入 注册交易商交易场关系
	 		this.dao.insertFirmRegTmptRlsp(firmRegister.getFirmTmptRlspList());
			// 更新 交易商注册表
	 		firmRegister.setFirmStatus(3);// 0:审核中,1:客服审核不通过,2:风控审核通过,3:客服审核通过,4:风控审核不通过
			return this.dao.updateFirmRegisterDetail(firmRegister);
		}else if (!approved && approvedTemp == null) {
			int  firmStatus = this.dao.getFirmRegisterFirmStatus(firmRegister.getFirmRegId());
			// 删除 注册交易商交易场关系
	 		this.dao.deleteFirmRegTmptRlspByFirmRegId(firmRegister.getFirmRegId());
	 		// 插入 注册交易商交易场关系
	 		this.dao.insertFirmRegTmptRlsp(firmRegister.getFirmTmptRlspList());
			// 更新 交易商注册表
	 		firmRegister.setFirmStatus(firmStatus);// 
			return this.dao.updateFirmRegisterDetail(firmRegister);
		}else {
			return this.dao.refuseFirmRegister(firmRegister.getFirmRegId(),firmRegister.getRejectReason());
		}
	}
	
	@Override
	public int getTotalRegisteredFirmList(QueryConditions qc) {
		return this.dao.getTotalRegisteredFirmList(qc);
	}
	@Override
	public void rejectRegisteredFirm(String firmRegId, String note) {
		this.dao.rejectRegisteredFirm(firmRegId,note);
		
	}
	@Override
	public List<FirmAllData> getFirmByFirmName(String firmName) {
		return this.firmDAO_read.getFirmByFirmName(firmName);
	}
	
	@Override
	public List<Trader> getTrader(String traderID) {
		return this.firmDAO_read.getTrader(traderID);
	}
	
	@Override
	public List<FirmAllData> getFirmByFullName(String fullName) {
		return this.firmDAO_read.getFirmByFullName(fullName);
	}
	
	@Override
	public void updateFirmIDPoolIsUsed(String firmID) {
		this.dao.updateFirmIDPoolIsUsed(firmID);
	}
	@Override
	public String GetNewFirmIDByZone(String zoneNum) {
		String firmID = this.dao.GetNewFirmIDByZone(zoneNum);
//		if (firmID.equals("0000000")) {
//			firmID = "无推荐交易商编码";
//		}
		return firmID;
	}
	
	@Override
	public List<RecAddRess> getFirmRecAddressList(PageInfo pageInfo,
			String firmID) {
		List<RecAddRess> list = this.firmDAO_read.getFirmRecAddressList(pageInfo,firmID);
		return list;
	}
	@Override
	public void addRecAddress(RecAddRess recAddress) {
		int recAddressID;
		//交易商 收货/收票地址
		recAddressID = this.dao.addRecAddress(recAddress);
		this.dao.addFirmInvoice(recAddress.getFirmID(),recAddressID,recAddress.getAddressType());
	}
	@Override
	public void delAddressList(int[] recAddressIDs) {
		if (recAddressIDs != null && recAddressIDs.length > 0) {
			String addressIDs="";
			for (int i = 0; i < recAddressIDs.length; i++) {
				if(i>0)addressIDs += ",";
				addressIDs += recAddressIDs[i];
			}
			this.dao.delAddressList(addressIDs);
		}
	}
	@Override
	public RecAddRess getFirmRecAddressByID(int recAddressID) {
		RecAddRess recAddRess = this.firmDAO_read.getFirmRecAddressByID(recAddressID);
		return recAddRess;
	}
	@Override
	public void updateRecAddress(RecAddRess recAddress) {
		//交易商 收货/收票地址
		this.dao.updateRecAddress(recAddress);
		//this.dao.updateFirmInvoice(recAddress.getRecAddressID(),recAddress.getAddressType());
	}
	@Override
	public void disabledRecAddress(int recAddressID,int disabled) {
		this.dao.disabledRecAddress(recAddressID,disabled);
	}
	
	@Override
	public int synchronizeFrim(FirmDetaiData firmDetaiData,
			int[] firmTmptRlsps, String userID) {
		int row = 0;
		MUser muser = this.systemMgrDAO.getUserByLoginName(userID)==null?new MUser():this.systemMgrDAO.getUserByLoginName(userID);
		FirmDetail firmDetail = firmDetaiData.getFirmDetailBean();
		firmDetail.setRecModifyby(muser.getName()==null?"system":muser.getName());
		try {
			//交易商主表信息更新
			row =  this.dao.updateFirm(firmDetail);
			//交易商应用关联关系
			this.addFirmApp(firmDetaiData.getFirmID(), 1, muser.getName()==null?"system":muser.getName());
			//交易场
			this.addFirmTmptRlspsList(firmDetaiData.getFirmID(), firmDetaiData.getFirmTmptRlspList(),
					firmDetaiData.getFirmDetailBean().getTradeAuthority(),
					firmDetaiData.getFirmDetailBean().getRdaTradeAuthorityXX());
			
			//交易商详细信息更新
			row = this.dao.updateFirmDetail(firmDetail);
			
			//更新交易商增值税开票信息
			VatAddRess vatAddRess = firmDetaiData.getVatAddRessBean();
			Firmvatinfo firmvatinfo = this.dao.queryFirmvatinfo(firmDetaiData.getFirmID());
			this.updateVatAddress(firmDetaiData,vatAddRess,firmvatinfo,row);
			
			//化纤数据（交易商）同时同步到老专场
			this.getBeans();
			row = this.firmBanlanceOraManager.addFirmForOra(firmDetaiData.getFirmID(), firmDetaiData.getFirmName(),firmDetaiData);
			this.log.debug("this.firmBanlanceOraManager.addFirmForOra end");
			this.log.debug("returnCode = " + row);
			if (row != 0) {
				row = -1;
				this.rollBack();
			}
		} catch (Exception e) {
			e.printStackTrace();
			row = -1;
			this.rollBack();
		}
		return row;
	}
	/**
	 * 交易商交易场权限
	 * @param firmID
	 * @param firmTmptRlsps
	 */
	private void addFirmTmptRlsps(String firmID, int[] firmTmptRlsps){
		this.dao.delFirmTmptRlsps(firmID);
		FirmTmptRlsp firmTmptRlsp = new FirmTmptRlsp();
		firmTmptRlsp.setFirmID(firmID);
		firmTmptRlsp.setEnabled("Y");
		if (firmTmptRlsps != null && firmTmptRlsps.length > 0) {
			String firmTmptRlspString = "";
			for (int i = 0; i < firmTmptRlsps.length; i++) {
				firmTmptRlsp.setTradeTmptId(firmTmptRlsps[i]);
				this.dao.addFirmTmptRlsps(firmTmptRlsp);
				if(i>0)firmTmptRlspString +=",";
				firmTmptRlspString += firmTmptRlsps[i];
			}
			//交易商的交易场权限发生变化应该同步影响交易员的权限
			List<Trader> traderList = this.traderDAO.getTraderListByFirmID(firmID);
			if (traderList != null && traderList.size() > 0) {
				for (int i = 0; i < traderList.size(); i++) {
					this.traderDAO.updateTraderTmptRlsps(traderList.get(i).getTraderID(),firmTmptRlspString);
				}
			}
		}
	}
	/**
	 * 交易商交易场权限 新增是否实名机制
	 * @param firmID
	 * @param firmTmptRlsps
	 */
	private void addFirmTmptRlspsList(String firmID,
			List<FirmTmptRlsp> firmTmptRlspList, Integer tradeAuthority, Integer tradeAuthorityXX) {
		this.dao.delFirmTmptRlsps(firmID);
		FirmTmptRlsp firmTmptRlsp = new FirmTmptRlsp();
		firmTmptRlsp.setFirmID(firmID);
		firmTmptRlsp.setEnabled("Y");
		if (firmTmptRlspList != null && firmTmptRlspList.size() > 0) {
			String firmTmptRlspString = "";
			for (int i = 0; i < firmTmptRlspList.size(); i++) {
				firmTmptRlsp.setTradeTmptId(firmTmptRlspList.get(i).getTradeTmptId());
				//是否实名
				firmTmptRlsp.setIsRealName(firmTmptRlspList.get(i).getIsRealName());
				//买卖权限
				if(firmTmptRlsp.getTradeTmptId() == 8){
					firmTmptRlsp.setTradeAuthority(tradeAuthorityXX);
				}else{
					firmTmptRlsp.setTradeAuthority(tradeAuthority);
				}
				this.dao.addFirmTmptRlsps(firmTmptRlsp);
				if(i>0)firmTmptRlspString +=",";
				firmTmptRlspString += firmTmptRlspList.get(i).getTradeTmptId();
			}
			//交易商的交易场权限发生变化应该同步影响交易员的权限
			List<Trader> traderList = this.traderDAO.getTraderListByFirmID(firmID);
			if (traderList != null && traderList.size() > 0) {
				for (int i = 0; i < traderList.size(); i++) {
					this.traderDAO.updateTraderTmptRlsps(traderList.get(i).getTraderID(),firmTmptRlspString);
				}
			}
		}
	}
	/**
	 * 手动回滚事务
	 */
	private void rollBack() {
		this.dao.rollBack();
	}
	
	private void getBeans() {
		firmBanlanceOraManager= (IFirmBanlanceOraManager) FinanceOraSysData.getBean(Constants.BEAN_BALANCEORA_MGR);
	}
	/**
	 * 交易商开票信息
	 * @param returnCode 
	 * @return
	 */
	private int addFirmVATInfo(VatAddRess vatAddRess,Firmvatinfo firmvatinfo, int returnCode) {
		if (vatAddRess.getVatBankID() != null) {
			//开票联系人
			vatAddRess.setVatContactName("");
			//开票联系人电话
			vatAddRess.setVatContactTelNo(vatAddRess.getVatContactTelNo());
			
			int vatAddRessID = this.dao.addFirmVatAddRess(vatAddRess);
			if (vatAddRessID != 0) {
				firmvatinfo.setVatBkAccount(firmvatinfo.getVatBkAccount());
				firmvatinfo.setVatAddressID(vatAddRessID);
				returnCode = this.dao.addFirmVATInfo(firmvatinfo);
			}
		}
		return returnCode;
	}
	/**
	 * 注册的交易商，审核通过自动绑定提请人为交易员
	 * @param muser 
	 * @param requestUserID 
	 * @param firmID 
	 * @param returnCode 
	 * @param flag 
	 * @return 
	 * @return
	 */
	private int bindUser(String firmRegID,String firmID, String requestUserID, String flag,MUser muser) {
		//交易员相关
		Trader trader = new Trader();
		trader.setTraderID(firmID+"00");
		trader.setTraderPassword(EncrypMD5.eccrypt("111111"));
		trader.setFirmID(firmID);
		trader.setFirmType(0);
		//交易员类型 交易员
		trader.setFirmType(0);
		//默认正常 
		trader.setDisabled(0);
		trader.setRecCreateBy("system");//后台操作人员，存到session里
		trader.setRecModifyBy("system");
		trader.setTraderName("");
		
		
		//把注册申请人自动绑定为交易员 
		
		User user = this.traderDAO.getUserById(requestUserID);
		if (user != null) {
			trader.setTraderName(user.getUserName());
			trader.setUserCode(requestUserID);
		}else {
			trader.setTraderName("");
		}
		this.traderDAO.addTrader(trader);
		int returnCode = 0;
		if (flag.equals("frontEnd")) {
			//用户注册信息 审核通过
			returnCode = this.dao.updateFirmRegister(firmRegID);
		}
		return returnCode;
	}
	/**
	 * 交易商收票地址信息
	 * @param recAddRess
	 * @param firminvoice
	 * @param recContactTelNo
	 * @param recContactName
	 */
	private void addRecAddRess(RecAddRess recAddRess,Firminvoice firminvoice,String recContactTelNo,String recContactName) {
		//交易商收票地址信息
//		if (row > 0) {
//			recAddRess.setRecContactTelNo(Base64Util.getBase64(recContactTelNo));
//			recAddRess.setRecContactName(recContactName);
//			int recAddRessID = this.dao.addFirmRecAddRess(recAddRess);
//			if (recAddRessID != 0) {
//				firminvoice.setAddressID(recAddRessID);
//				//地址类型：收票地址
//				firminvoice.setAddRessType(0);
//				row = this.dao.addFirmInvoice(firminvoice);
//			}
//		}
	}
	/**
	 * 开票信息
	 * @param firmAllData
	 * @param vatAddRessList
	 */
	private void setVatAddress(FirmAllData firmAllData, List<VatAddRess> vatAddRessList) {
		if (vatAddRessList != null && vatAddRessList.size() > 0) {
			//firmAllData.setVatAddRess(vatAddRessList.get(0));
			
			firmAllData.setVatAddress(vatAddRessList.get(0).getVatAddress());
			firmAllData.setVatAddressID(vatAddRessList.get(0).getId());
			firmAllData.setVatPV(vatAddRessList.get(0).getVatPV());
			firmAllData.setVatCT(vatAddRessList.get(0).getVatCT());
			firmAllData.setVatDT(vatAddRessList.get(0).getVatDT());
			firmAllData.setVatContactTelNo(vatAddRessList.get(0).getVatContactTelNo());
			firmAllData.setVatBkAccount(vatAddRessList.get(0).getVatBkAccount());
			firmAllData.setVatBankID(vatAddRessList.get(0).getVatBankID());
			//
			firmAllData.setVatBkBranch(vatAddRessList.get(0).getVatBkBranch());
		}

	}
	/**
	 * 更新交易商开票信息
	 * @param firmDetaiData 
	 * @param vatAddRess
	 * @param firmvatinfo
	 * @param row 
	 */
	private void updateVatAddress(FirmDetaiData firmDetaiData, VatAddRess vatAddRess, Firmvatinfo firmvatinfo, int row) {
		if (vatAddRess.getVatBankID() != null) {
				//开票联系人
			vatAddRess.setVatContactName("");
			//开票联系人电话
			vatAddRess.setVatContactTelNo(vatAddRess.getVatContactTelNo());
			
			int vatAddRessID = this.dao.addFirmVatAddRess(firmDetaiData.getVatAddRessBean());
			if (vatAddRessID != 0) {
				firmvatinfo = firmDetaiData.getFirmvatinfoBean();
				firmvatinfo.setVatBkAccount(firmDetaiData.getVatBkAccount());
				firmvatinfo.setVatAddressID(vatAddRessID);
				//交易商银行开票信息，先删除再新增
				this.dao.deleteFirmvatinfo(firmDetaiData.getFirmID());
				row = this.dao.addFirmVATInfo(firmvatinfo);
			}
		}else {
			this.dao.deleteFirmvatinfo(firmDetaiData.getFirmID());
		}
	}
	
	/**
	 * 交易商应用关联关系
	 * @param firmID
	 * @param appType
	 * @param userName
	 */
	private void addFirmApp(String firmID,Integer appType,String userName) {
		List<FirmApp> list = this.dao.getFirmAppByParam(firmID,appType);
		if (list==null || (list!=null && list.size() == 0)) {
			this.dao.addFirmApp(firmID,appType,userName);
		}
	}
	
	@Override
	public void insertFirmRegister(FirmRegister firmRegister,
			List<FirmRegTmptRlsp> list) {
		this.log.info("componnet insertFirmRegister Start");
		try {
			// 0:审核中,1:客服审核不通过,2:风控审核通过,3:客服审核通过,4:风控审核不通过
			firmRegister.setFirmStatus(3);
			String id = this.dao.insertFirmRegister(firmRegister);
			
			List<FirmRegTmptRlsp> newlist = new ArrayList<FirmRegTmptRlsp>();
			for (FirmRegTmptRlsp rlsp : list){
				rlsp.setFirmRegId(id);
				rlsp.setEnabled("N");
				rlsp.setRecCreatetime(new Date());
				rlsp.setRecModifytime(new Date());
				newlist.add(rlsp);
			}
			this.dao.insertFirmRegTmptRlsp(newlist);
		} catch (Exception e) {
			this.log.error("插入交易商注册信息失败！"+e.getMessage());
			this.rollBack();
		}
		
		this.log.info("componnet insertFirmRegister End");
	}
	@Override
	public List<FirmRegTmptRlsp> selectFirmRegTmptRlspByFirmRegId(
			String firmRegId) {
		return this.firmDAO_read.selectFirmRegTmptRlspByFirmRegId(firmRegId);
	}
	@Override
	public void deleteFirmRegTmptRlspByFirmRegId(String firmRegId) {
		this.dao.deleteFirmRegTmptRlspByFirmRegId(firmRegId);
		
	}
	@Override
	public int updateCFirmOfFirmStatus(String firmId, String username,
			Integer firmStatus) {
		return this.dao.updateCFirmOfFirmStatus(firmId, username, firmStatus);
	}

	/**
	 * 根据条件查询商铺视图
	 *
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public List<Shop> selectShopByParam(QueryConditions qc, PageInfo pageInfo) {
		return this.firmDAO_read.selectShopByParam(qc,pageInfo);
	}

	/**
	 * 添加商铺
	 *
	 * @param shop
	 */
	public int insertShop(Shop shop) {
		int resultCode = 0;
		this.log.info(this.getClass().getName()+"componnet insertShop Start");
		try {
			if (shop != null){
				String firmID = shop.getFirmID();
			
				if (firmID != null && !"".equals(firmID)){
					int count = dao.countRelationShopFrim(firmID);
					if (count == 0){
						int shopId = this.dao.insertShop(shop);
						this.addShopFirm(shop,shopId,resultCode);
					}else{
						resultCode = -3;// 主交易商账号已经本其他商铺关联.
						this.log.info("主交易商账号:"+firmID);
					}
				}else{
					this.dao.insertShop(shop);
				}
			}else{
				resultCode = -2;// 添加商铺失败，商铺信息不能为空!
			}
		} catch (Exception e) {
			resultCode = -1;
			this.log.error("添加商铺失败！"+e.getMessage());
			this.rollBack();
		}
		this.log.info(this.getClass().getName()+"componnet insertShop End");
		return resultCode;
	}
	
	private int addShopFirm(Shop shop,int shopId,int resultCode){
		
		int count = dao.countRelationShopFrim(shop.getFirmID());
		if (count != 0){
			this.log.info("主交易商账号:"+shop.getFirmID());
			resultCode = -3;
			return resultCode;// 主交易商账号已经本其他商铺关联.
		}
		// 插入商铺交易商关联表（主交易商）
		ShopFirm shopFirm = new ShopFirm();
		if (shop.getFirmID() != null && !"".equals(shop.getFirmID())){
			shopFirm.setFirmID(shop.getFirmID());
			shopFirm.setShopID(shopId);
			shopFirm.setIsMainFirm(1);// 是否主交易商 0否 1是
			shopFirm.setREC_CREATEBY(shop.getREC_CREATEBY());
			shopFirm.setREC_MODIFYBY(shop.getREC_MODIFYBY());
			dao.insertShopFirm(shopFirm);
		}
		String[]  relationFirmID = shop.getRelationFirmID();// 关联交易商ID数组
		String firmIdStr = "";
		if (relationFirmID != null && relationFirmID.length > 0){
			for (String tempFirmId : relationFirmID){
				int tempCount = dao.countRelationShopFrim(tempFirmId);
				if (tempCount != 0){
					firmIdStr+=tempFirmId+",";
				}
			}
			if ("".equals(firmIdStr)){
				// 插入商铺交易商关联表（关联的交易商）
				for (String tempFirmId : relationFirmID){
					shopFirm.setFirmID(tempFirmId);
					shopFirm.setShopID(shopId);
					shopFirm.setIsMainFirm(0);// 是否主交易商 0否 1是
					shopFirm.setREC_CREATEBY(shop.getREC_CREATEBY());
					shopFirm.setREC_MODIFYBY(shop.getREC_MODIFYBY());
					dao.insertShopFirm(shopFirm);
				}
			}else{
				resultCode = -4;// 关联的交易商账号已经被其他商铺关联过。
				this.log.info("被其他商铺关联过的交易商账号:"+firmIdStr);
			}
		}
		return resultCode;
	}

	/**
	 * 更新商铺
	 *
	 * @param shop
	 */
	public int updateShop(Shop shop) {
		this.log.info(this.getClass().getName()+"componnet updateShop Start");
		int resultCode = 0;
		try {
			this.dao.updateShop(shop);
			resultCode = this.updateShopFirm(shop,resultCode);
		} catch (Exception e) {
			resultCode = -1;
			this.log.error("更新商铺失败！"+e.getMessage());
			this.rollBack();
		}
		this.log.info(this.getClass().getName()+"componnet updateShop End");
		return resultCode;
	}

	private int updateShopFirm(Shop shop,int resultCode){
		int shopId = shop.getId();
		dao.deleteShopFirmByShopId(shopId, 1);// 删除主交易商 在 【商铺交易商关联表】中的数据
		dao.deleteShopFirmByShopId(shopId, 0);// 删除关联交易商在 【商铺交易商关联表】中的数据
		resultCode = addShopFirm(shop,shopId,resultCode);
		return resultCode;
	}
	
	/**
	 * 根据商铺id获得商铺信息
	 *
	 * @param shopId
	 * @return
	 */
	public Shop getById(String shopId) {
		return this.firmDAO_read.getById(shopId);
	}
	
	@Override
	public void insertFirmSetting(FirmSetting firmSetting) {
		dao.insertFirmSetting(firmSetting);
	}
	
	@Override
	public void deleteFirmSettingById(Integer id) {
		dao.deleteFirmSettingById(id);
	}
	
	@Override
	public void updateFirmSettingById(FirmSetting firmSetting) {
		dao.updateFirmSettingById(firmSetting);
	}
	
	/**
	 * limit:销售限额 有限制：0;无限制：1
	 */
	@Override
	public List<FirmPositionLimitModel> getFirmPositionLimit(
			QueryConditions qc, PageInfo pageInfo,String limit) {
		this.log.info("componnet getFirmPositionLimit Start");
		List<FirmPositionLimitModel> list;
		list = this.firmDAO_read.getFirmPositionLimit(qc,pageInfo,limit);
		
		/**当前销售中的量
		 * 当前销售量 = 当前已成交未完成交收量（总吨数或货款总额）  +  当前有效报盘量（总吨数或报盘对应货款总额）； 
		 */
		list = this.setsaleVolumeAndMoney(list);
		
		/**限额设置*/
		list = this.setPositionLimitValue(list);
		return list;
	}
	
	/**
	 *获取交易商限额
	 */
	@Override
	public List<FirmPositionLimitModel> getFirmPositionLimitByTradeType(
			QueryConditions qc, PageInfo pageInfo) {
		this.log.info("componnet getFirmPositionLimitByTradeType Start");
		List<FirmPositionLimitModel> list;
		list = this.firmDAO_read.getFirmPositionLimitByTradeType(qc,pageInfo);
		return list;
	}
	
	private List<FirmPositionLimitModel> setsaleVolumeAndMoney(
			List<FirmPositionLimitModel> list) {
		if(null != list && list.size() > 0){
			for (int i = 0; i < list.size(); i++) {
				//现货当前销售量
				BigDecimal leadsQuantity = this.firmDAO_read.getLeadsQuantity(list.get(i).getFirmID(),0);
				list.get(i).setStock_saleVolume(list.get(i).getStock_saleVolume().add(leadsQuantity));
				//现货当前销售额
				BigDecimal leadSMoney = this.firmDAO_read.getLeadsMonet(list.get(i).getFirmID(),0);
				list.get(i).setStock_saleMoney(list.get(i).getStock_saleMoney().add(leadSMoney));
				
				//预售当前销售量
				BigDecimal leadsQuantity_Advance = this.firmDAO_read.getLeadsQuantity(list.get(i).getFirmID(),1);
				list.get(i).setAdvance_saleVolume(list.get(i).getAdvance_saleVolume().add(leadsQuantity_Advance));
				//预售当前销售额
				BigDecimal leadSMoney_Advance = this.firmDAO_read.getLeadsMonet(list.get(i).getFirmID(),1);
				list.get(i).setAdvance_saleMoney(list.get(i).getAdvance_saleMoney().add(leadSMoney_Advance));
			}
		}
		return list;
	}
	/**
	 * 交易商销售配置详情
	 */
	@Override
	public  List<FirmPositionLimitModel> getFirmPositionLimitByFirmID(String firmId) {
		this.log.info("componnet getFirmPositionLimitByFirmID Start");
		List<FirmPositionLimitModel> list;
		list = this.firmDAO_read.getFirmPositionLimitByFirmID(firmId);
		if (list != null && list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				if(list.get(i).getPositionLimitType() == 0){
					list.get(i).setPositionLimitValue(new BigDecimal(new java.text.DecimalFormat("#.00").format(list.get(i).getPositionLimitValue())));
				}
			}
		}
		return list;
	}
	
	/**
	 *  更新交易商销售配置详情
	 */
	@Override
	public int updateFirmPositionLimitByFirmID(
			List<FirmPositionLimitModel> list, String userName,String firmID) {
		this.log.info("componnet updateFirmPositionLimitByFirmID Start");
		int returnCode = 0;
		//先删除该交易商销售配置
		returnCode = this.dao.deleteeFirmPositionLimitModelByFirmID(firmID);
		if(returnCode == -1)return returnCode;
		if(list !=null && list.size() > 0){
			for (int i = 0; i < list.size(); i++) {
				returnCode = this.dao.addFirmPositionLimitModel(list.get(i),userName,firmID);
				if(returnCode == -1){
					this.rollBack();
					return returnCode;
				}
			}
		}
		return returnCode;
	}
	
	/**
	 * 更新交易商销售量额度
	 * @param list
	 */
	private List<FirmPositionLimitModel> setPositionLimitValue(List<FirmPositionLimitModel> list) {
		if(list != null && list.size() > 0){
			for (int i = 0; i < list.size(); i++) {
				List<FirmPositionLimitModel> listTemp = this.getFirmPositionLimitByFirmID(list.get(i).getFirmID());
				if(listTemp != null && listTemp.size() > 0){
					if(listTemp.size() == 1){
						if(listTemp.get(0).getGoodsType() == 0 && listTemp.get(0).getPositionLimitType() == 0){//现货按照金额
							list.get(i).setPositionLimitType(0);
//							list.get(i).setStock_positionLimitValue(new java.text.DecimalFormat("#.00").format(listTemp.get(0).getPositionLimitValue())+"（元）");
							list.get(i).setStock_positionLimitValue(listTemp.get(0).getPositionLimitValue());
						}else if(listTemp.get(0).getGoodsType() == 0 && listTemp.get(0).getPositionLimitType() == 1) {//现货按照重量
							list.get(i).setPositionLimitType(1);
							list.get(i).setStock_positionLimitValue(listTemp.get(0).getPositionLimitValue());
						}else if(listTemp.get(0).getGoodsType() == 1 && listTemp.get(0).getPositionLimitType() == 0){//预售按照金额
							list.get(i).setPositionLimitType(0);
							list.get(i).setAdvance_positionLimitValue(listTemp.get(0).getPositionLimitValue());
						}else {
							list.get(i).setPositionLimitType(1);
							list.get(i).setAdvance_positionLimitValue(listTemp.get(0).getPositionLimitValue());//预售按照重量
						}
					}
					if (listTemp.size() == 2) {
						if(listTemp.get(0).getGoodsType() == 0 && listTemp.get(0).getPositionLimitType() == 0){//现货按照金额
							list.get(i).setPositionLimitType(0);
							list.get(i).setStock_positionLimitValue(listTemp.get(0).getPositionLimitValue());
							if(listTemp.get(1).getGoodsType() == 1 && listTemp.get(1).getPositionLimitType() == 0){//预售按照金额
								list.get(i).setPositionLimitType(0);
								list.get(i).setAdvance_positionLimitValue(listTemp.get(1).getPositionLimitValue());
							}else {
								list.get(i).setPositionLimitType(1);
								list.get(i).setAdvance_positionLimitValue(listTemp.get(1).getPositionLimitValue());//预售按照重量
							}
						}else if (listTemp.get(0).getGoodsType() == 0 && listTemp.get(0).getPositionLimitType() == 1) {//现货按照重量
							list.get(i).setPositionLimitType(1);
							list.get(i).setStock_positionLimitValue(listTemp.get(0).getPositionLimitValue());
							if(listTemp.get(1).getGoodsType() == 1 && listTemp.get(1).getPositionLimitType() == 0){//预售按照金额
								list.get(i).setPositionLimitType(0);
								list.get(i).setAdvance_positionLimitValue(listTemp.get(1).getPositionLimitValue());
							}else {
								list.get(i).setPositionLimitType(1);
								list.get(i).setAdvance_positionLimitValue(listTemp.get(1).getPositionLimitValue());//预售按照重量
							}
						}else if (listTemp.get(0).getGoodsType() == 1 && listTemp.get(1).getPositionLimitType() == 0) {//预售按照金额
							list.get(i).setPositionLimitType(0);
							list.get(i).setAdvance_positionLimitValue(listTemp.get(0).getPositionLimitValue());
							if(listTemp.get(1).getGoodsType() == 0 && listTemp.get(1).getPositionLimitType() == 0){//现货按照金额
								list.get(i).setPositionLimitType(0);
								list.get(i).setStock_positionLimitValue(listTemp.get(1).getPositionLimitValue());
							}else {
								list.get(i).setPositionLimitType(1);
								list.get(i).setStock_positionLimitValue(listTemp.get(1).getPositionLimitValue());//现货按照重量
							}
						}else {
							list.get(i).setPositionLimitType(1);
							list.get(i).setAdvance_positionLimitValue(listTemp.get(0).getPositionLimitValue());//预售按照重量
							if(listTemp.get(1).getGoodsType() == 0 && listTemp.get(1).getPositionLimitType() == 0){//现货按照金额
								list.get(i).setPositionLimitType(0);
								list.get(i).setStock_positionLimitValue(listTemp.get(1).getPositionLimitValue());
							}else {
								list.get(i).setPositionLimitType(1);
								list.get(i).setStock_positionLimitValue(listTemp.get(1).getPositionLimitValue());//现货按照重量
							}
						}
					}
				}
			}
		}
		
		return list;
	}
	
	@Override
	public List<FirmAllData> getIsNotRelationFrimListForShop(QueryConditions qc,PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+"componnet getIsNotRelationFrimListForShop Start");
		List<FirmAllData> list = firmDAO_read.getIsNotRelationFrimListForShop(qc,pageInfo);
		this.log.info(this.getClass().getName()+"componnet getIsNotRelationFrimListForShop End");
		return list;
	}
	@Override
	public List<ShopFirm> selectShopFirmListByShopID(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+"componnet selectShopFirmListByShopID Start");
		List<ShopFirm> list = firmDAO_read.selectShopFirmListByShopID(qc, pageInfo);
		this.log.info(this.getClass().getName()+"componnet selectShopFirmListByShopID End");
		return list;
	}
	@Override
	public int updateShopOfDisabled(int shopId, int disabled) {
		this.log.info(this.getClass().getName()+"componnet updateShopOfDisabled Start");
		int count = dao.updateShopOfDisabled(shopId, disabled);
		this.log.info(this.getClass().getName()+"componnet updateShopOfDisabled End");
		return count;
	}
}
