/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：app微信
 * File Name: UserDAO.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年8月18日 　喻剑平   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.dao.impl;

import java.util.List;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.member.dao.UserWeiXinDAO;
import shcem.member.dao.model.UserWeiXin;
import shcem.util.CollectionUtil;
import shcem.util.CommonRowMapper;

/**
 * @author jampion
 *
 */
public class UserWeiXinDAOImpl extends BaseDAOImpl implements UserWeiXinDAO {

	/**
	 * 获取用户详情
	 * @param openId openid
	 * @return
	 */
	@Override
	public UserWeiXin getUserByOpenID(String openId) {
		this.log.info("UserWeiXin Dao getUserByOpenID start");
		Object[] params = { openId , 1};
		String sql =	sqlProperty.getProperty("UserWeiXinDAO_001");
		
		List<UserWeiXin> userWeiXinList = queryBySQL(sql, params, null, new CommonRowMapper(new UserWeiXin()));
		
		this.log.info("UserWeiXin Dao getUserByOpenID end");
		
		if (CollectionUtil.isValidCollect(userWeiXinList)) {
			return userWeiXinList.get(0);
		}
		return null;
	}

	/**
	 * 通过usercode获取信息
	 * 
	 * @param userWeiXin
	 * @return
	 */
	@Override
	public UserWeiXin getUserByUserCode(String userCode) {
		this.log.info("UserWeiXin Dao getUserByUserCode start");
		Object[] params = { userCode,1 };  //有效(status = 1)的绑定关系
		String sql = sqlProperty.getProperty("UserWeiXinDAO_002");
		UserWeiXin userWeiXin = (UserWeiXin) queryForObject(sql, params, new CommonRowMapper(new UserWeiXin()));
		this.log.info("UserWeiXin Dao getUserByUserCode end");
		return userWeiXin;
	}

	/**
	 * 新增用户和微信绑定关系
	 * 
	 * @param userWeiXin
	 * @return
	 */
	@Deprecated
	@Override
	public void addUserWeiXinRelation(UserWeiXin userWeiXin) {
		this.log.debug("addUserWeiXinRelation DAO Start");
		String sql = sqlProperty.getProperty("UserWeiXinDAO_003");
		Object[] params = { userWeiXin.getUserCode(), userWeiXin.getOpenId() };
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		this.getJdbcTemplate().update(sql, params);
		this.log.debug("addUserWeiXinRelation DAO End");
	}

	/**
	 * 新增用户和微信绑定关系
	 * 
	 * @param userWeiXin
	 * @return
	 */
	@Override
	public void updateUserWeiXinAddRelation(UserWeiXin userWeiXin) {
		this.log.debug("updateUserWeiXinAddRelation DAO Start");
		String sql = sqlProperty.getProperty("UserWeiXinDAO_005");
		Object[] params = { userWeiXin.getUserCode(), userWeiXin.getOpenId(), 1 };
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		this.getJdbcTemplate().update(sql, params);
		this.log.debug("updateUserWeiXinAddRelation DAO End");
	}
	
	/**
	 * 获取用户详情
	 * @param mobile 手机号
	 * @return
	 */
	@Override
	public UserWeiXin getUserByMobile(String mobile) {
		this.log.debug("getUserByMobile DAO Start");
		Object[] params = { mobile };
		String sql = sqlProperty.getProperty("UserWeiXinDAO_004");
		UserWeiXin userWeiXin = (UserWeiXin) queryForObject(sql, params, new CommonRowMapper(new UserWeiXin()));
		this.log.debug("getUserByMobile DAO End");
		return userWeiXin;
	}

	/**
	 * 
	 * 添加微信授权信息
	 * */
	@Override
	public void addWeiXinInfo(UserWeiXin userWeiXin) {
		this.log.debug("addWeiXinInfo DAO Start");
		String sql = sqlProperty.getProperty("UserWeiXinDAO_003");
		Object[] params = { userWeiXin.getOpenId(), 1, userWeiXin.getNickName(), userWeiXin.getGender(), userWeiXin.getProvince(), userWeiXin.getCity(), userWeiXin.getCountry(), userWeiXin.getHeadimgurl(), userWeiXin.getPrivilege(), userWeiXin.isSubscribe(), userWeiXin.getSubscribeTime(), userWeiXin.getLanguage(), userWeiXin.getUnionId(), userWeiXin.getRemark(), userWeiXin.getGroupId(), null};
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		this.getJdbcTemplate().update(sql, params);
		this.log.debug("addWeiXinInfo DAO End");
	}
}
