package shcem.member.dao.model;

import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * (C_TRADER)
 * 
 * @author bianj
 * @version 1.0.0 2016-05-24
 */
public class Trader extends BaseObject implements java.io.Serializable {
    /** 版本号 */
    private static final long serialVersionUID = -8372517796568694118L;
    
    /** 交易员编码 */
    private String traderID;
    
    /** 交易员名称 */
    private String traderName;
    
    /** 密码 */
    private String traderPassword;
    
    /** 强制密码更新状态 0:已更新，1:未更新 */
    private Integer forceChangePwd;
    
    /**  */
    private Integer disabled;
    
    /** 交易商编码 */
    private String firmID;
    
    /** 类型 0:管理员,1:一般交易员 */
    private Integer firmType;
    
    /** 用户编码 外键-User */
    private String userCode;
    
    /**  */
    private String recCreateBy;
    
    /**  */
    private Date recCreateTime;
    
    /**  */
    private String recModifyBy;
    
    /**  */
    private Date recModifyTime;
    
    //解绑、绑定备注
    private String bindNote;
    
    private String mobile;
    // 默认为 0：恢复，1：冻结
    private Integer traderStatus;
    //冻结描述原因
    private String frozenRemark;
    
    /** 是否清除前台session */
	private boolean isClearSession;
     
    public Integer getTraderStatus() {
		return traderStatus;
	}

	public void setTraderStatus(Integer traderStatus) {
		this.traderStatus = traderStatus;
	}

	public String getFrozenRemark() {
		return frozenRemark;
	}

	public void setFrozenRemark(String frozenRemark) {
		this.frozenRemark = frozenRemark;
	}

	public String getTraderID() {
		return traderID;
	}

	public void setTraderID(String traderID) {
		this.traderID = traderID;
	}

	public String getTraderName() {
		return traderName;
	}

	public void setTraderName(String traderName) {
		this.traderName = traderName;
	}

	public String getTraderPassword() {
		return traderPassword;
	}

	public void setTraderPassword(String traderPassword) {
		this.traderPassword = traderPassword;
	}

	public Integer getForceChangePwd() {
		return forceChangePwd;
	}

	public void setForceChangePwd(Integer forceChangePwd) {
		this.forceChangePwd = forceChangePwd;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public Integer getFirmType() {
		return firmType;
	}

	public void setFirmType(Integer firmType) {
		this.firmType = firmType;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getRecCreateBy() {
		return recCreateBy;
	}

	public void setRecCreateBy(String recCreateBy) {
		this.recCreateBy = recCreateBy;
	}

	public Date getRecCreateTime() {
		return recCreateTime;
	}

	public void setRecCreateTime(Date recCreateTime) {
		this.recCreateTime = recCreateTime;
	}

	public String getRecModifyBy() {
		return recModifyBy;
	}

	public void setRecModifyBy(String recModifyBy) {
		this.recModifyBy = recModifyBy;
	}

	public Date getRecModifyTime() {
		return recModifyTime;
	}

	/**
     * 设置recModifytime
     * 
     * @param recModifytime
     *          recModifytime
     */
     public void setRecModifyTime(Date recModifytime) {
        this.recModifyTime = recModifytime;
     }

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getBindNote() {
		return bindNote;
	}

	public void setBindNote(String bindNote) {
		this.bindNote = bindNote;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public boolean getIsClearSession() {
		return isClearSession;
	}

	public void setIsClearSession(boolean isClearSession) {
		this.isClearSession = isClearSession;
	}
}