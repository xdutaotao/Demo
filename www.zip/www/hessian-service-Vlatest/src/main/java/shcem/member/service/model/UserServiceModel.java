/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: UserServiceModel.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.service.model;

import java.io.Serializable;
import java.util.Date;

import org.json.JSONObject;

import shcem.base.service.model.BaseServiceObject;

/**
 * @author wlpod
 *
 */
public class UserServiceModel extends BaseServiceObject implements Serializable {
	/**  */
	private String userCode;

	/**  */
	private String userName;

	/**  */
	private String userPassword;

	/**  */
	private String mobile;

	/** 默认为 0：正常，1：失效 */
	private Integer disabled;

	/** 类型 0:浏览用户,1:交易员用户 */
	private Integer userType;

	/**  */
	private Date lastLoginTime;

	/**  */
	private String recCreateBy;

	/**  */
	private Date recCreateTime;

	/**  */
	private String recModifyBy;

	/**  */
	private Date recModifyTime;

	/**
	 * @return the userCode
	 */
	public String getUserCode() {
		return userCode;
	}

	/**
	 * @param userCode
	 *            the userCode to set
	 */
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName
	 *            the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the userPassword
	 */
	public String getUserPassword() {
		return userPassword;
	}

	/**
	 * @param userPassword
	 *            the userPassword to set
	 */
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * @param mobile
	 *            the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 * @return the disabled
	 */
	public Integer getDisabled() {
		return disabled;
	}

	/**
	 * @param disabled
	 *            the disabled to set
	 */
	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	/**
	 * @return the userType
	 */
	public Integer getUserType() {
		return userType;
	}

	/**
	 * @param userType
	 *            the userType to set
	 */
	public void setUserType(Integer userType) {
		this.userType = userType;
	}

	/**
	 * @return the lastLoginTime
	 */
	public Date getLastLoginTime() {
		return lastLoginTime;
	}

	/**
	 * @param lastLoginTime
	 *            the lastLoginTime to set
	 */
	public void setLastLoginTime(Date lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	/**
	 * @return the recCreateBy
	 */
	public String getRecCreateBy() {
		return recCreateBy;
	}

	/**
	 * @param recCreateBy
	 *            the recCreateBy to set
	 */
	public void setRecCreateBy(String recCreateBy) {
		this.recCreateBy = recCreateBy;
	}

	/**
	 * @return the recCreateTime
	 */
	public Date getRecCreateTime() {
		return recCreateTime;
	}

	/**
	 * @param recCreateTime
	 *            the recCreateTime to set
	 */
	public void setRecCreateTime(Date recCreateTime) {
		this.recCreateTime = recCreateTime;
	}

	/**
	 * @return the recModifyBy
	 */
	public String getRecModifyBy() {
		return recModifyBy;
	}

	/**
	 * @param recModifyBy
	 *            the recModifyBy to set
	 */
	public void setRecModifyBy(String recModifyBy) {
		this.recModifyBy = recModifyBy;
	}

	/**
	 * @return the recModifyTime
	 */
	public Date getRecModifyTime() {
		return recModifyTime;
	}

	/**
	 * @param recModifyTime
	 *            the recModifyTime to set
	 */
	public void setRecModifyTime(Date recModifyTime) {
		this.recModifyTime = recModifyTime;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toString()
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toJSONObject()
	 */
	@Override
	public JSONObject toJSONObject() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#hashCode()
	 */
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
