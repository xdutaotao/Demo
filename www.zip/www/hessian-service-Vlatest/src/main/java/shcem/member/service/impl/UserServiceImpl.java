/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: UserServiceImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.service.impl;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import redis.clients.jedis.Jedis;
import shcem.base.exception.BaseException;
import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.common.util.OauthApi;
import shcem.common.util.Weixin4jConfigUtil;
import shcem.common.util.Weixin4jSettings;
import shcem.constant.Constants;
import shcem.constant.ResultCode;
import shcem.member.component.IUserManager;
import shcem.member.dao.model.CusInfoCscfg;
import shcem.member.dao.model.User;
import shcem.member.dao.model.UserAllData;
import shcem.member.dao.model.UserDataList;
import shcem.member.dao.model.UserWeiXin;
import shcem.member.service.IUserService;
import shcem.member.service.model.CusInfoMaintainDto;
import shcem.member.service.model.CusInfoMaintainModel;
import shcem.member.util.FirmSysData;
import shcem.member.util.RemoteMbappUtil;
import shcem.util.CommonUtils;
import shcem.util.EncryptUtil;
import shcem.util.JsonUtil;

import com.alibaba.fastjson.JSON;
import com.foxinmy.weixin4j.exception.WeixinException;
import com.foxinmy.weixin4j.model.WeixinAccount;
import com.foxinmy.weixin4j.mp.api.UserApi;
import com.foxinmy.weixin4j.mp.model.OauthToken;
import com.foxinmy.weixin4j.mp.token.WeixinTokenCreator;
import com.foxinmy.weixin4j.token.TokenManager;
import com.github.wxpay.sdk.WXPay;
import com.github.wxpay.sdk.WXPayConfig;
import com.github.wxpay.sdk.WXPayUtil;
import com.github.wxpay.sdk.WXPayConstants.SignType;

/**
 * @author wlpod
 *
 */
public class UserServiceImpl extends BaseServiceImpl implements IUserService {

	private IUserManager mgr = (IUserManager) FirmSysData.getBean(Constants.BEAN_USER_MGR);
	String mode = "member";
	/* (non-Javadoc)
	 * @see shcem.member.service.IUserService#getUserList(java.lang.String)
	 */
	//用户列表信息
	@Override
	public String getUserList(String params) {
		this.log.info(this.getClass().getName() + " getUserList() Start");
		this.log.debug("JSONParams=" + params);
		boolean bolRst = false;
		List<UserDataList> list = null;
		JSONObject JSONParams = new JSONObject(params);
		//表头查询条件  
		List<Condition> conditionsList = new ArrayList<Condition>();//TraderName
		conditionsList.add(new Condition("dbo.base64_utf8decode(cu.Mobile)","like","","string","mobile"));
		conditionsList.add(new Condition("cu.UserName","like","","string","userName"));
		conditionsList.add(new Condition("cu.UserCode","like","","string","userCode"));
		conditionsList.add(new Condition("cu.useravailable","like","","int","disabled"));
		conditionsList.add(new Condition("cua.AppType","=","","int","resource"));

		
		JSONObject queryModel =JSONParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionsList, "");
		qc.addCondition("cu.DISABLED","=","0","int");
		this.log.debug("qc=" + qc.toString());
		//分页信息
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JSONParams);
		try {
			list = this.mgr.getUserList(qc, pageInfo);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("取得用户列表信息失败：" + e.getMessage());
			setResultData("10104", null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("用户数据转换失败：" + e.getMessage());
				setResultData("21002", null, e.getMessage());
			}

		}
		this.log.info(this.getClass().getName() + " getUserList() End");
		return rtnData.toString();
	}

	/* (non-Javadoc)
	 * @see shcem.member.service.IUserService#getUser(java.lang.String)
	 */
	@Override
	public String getUser(String params) {
		this.log.info(this.getClass().getName() + " getTrader() Start");
		this.log.debug("getTrader Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		String userCode = JOParams.getString("userCode");
		boolean bolRst = false;
		UserAllData userAllData = new UserAllData();
		try {
			userAllData = this.mgr.getUser(userCode);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询用户是否存在出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
		}
		if (bolRst) {
			JSONObject retData;	
			try {
				retData = JsonUtil.coverModelToJSONObject(userAllData);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error("用户数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getTrader() End");
		return rtnData.toString();
	}

	/* (non-Javadoc)
	 * @see shcem.member.service.IUserService#disableUser(java.lang.String)
	 */
	@Override
	public String disableUser(String params) {
		this.log.info(this.getClass().getName() + " disableTrader() Start");
		this.log.debug("disableTrader Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		String userCode = JOParams.getString("userCode");
		try {
			int row = this.mgr.disableUser(userCode);
			setResultData("00000", null);
			this.log.businesslog("禁用用户成功",Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
		} catch (Exception e) {
			this.log.error("禁用用户出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("禁用用户出错"+e.getMessage(),Constants.OPE_MODE_MEMBER,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " disableTrader() End");
		return rtnData.toString();
	}

	/* (non-Javadoc)
	 * @see shcem.member.service.IUserService#enableUser(java.lang.String)
	 */
	@Override
	public String enableUser(String params) {
		this.log.info(this.getClass().getName() + " disableTrader() Start");
		this.log.debug("disableTrader Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		String userCode = JOParams.getString("userCode");
		try {
			int row = this.mgr.enableUser(userCode);
			setResultData("00000", null);
			this.log.businesslog("启用用户成功",Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
		} catch (Exception e) {
			this.log.error("启用用户出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("启用用户出错"+e.getMessage(),Constants.OPE_MODE_MEMBER,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " disableTrader() End");
		return rtnData.toString();
	}

	@Override
	public String addUser(String params) {
		this.log.info(this.getClass().getName() +  " addTrader() Start");
		this.log.debug("addTrader Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		User user = null;
		user = (User) JsonUtil.jsonToBean(JOParams, User.class);
		try {
			this.mgr.addUser(user);
			setResultData("00000", null);
			this.log.businesslog("新增用户成功",Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
		} catch (Exception e) {
			this.log.error("新增用户出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("新增用户出错"+e.getMessage(),Constants.OPE_MODE_MEMBER,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " addTrader() End");
		return rtnData.toString();
	}
	
	/**
	 * 查询 客户信息维护 列表
	 * @return
	 */
	@Override
	public String getCustomerMaintainInfoList(String params) {

		this.log.info(this.getClass().getName() + " getCustomerMaintainInfoList() Start");
		this.log.debug("JSONParams=" + params);
		boolean bolRst = false;
		List<CusInfoMaintainDto> list = null;
		JSONObject JSONParams = new JSONObject(params);
		
		//表头查询条件  
		List<Condition> conditionsList = new ArrayList<Condition>();//TraderName
		conditionsList.add(new Condition("tmp.mobile","like","","string","mobile"));
		conditionsList.add(new Condition("tmp.userName","like","","string","userName"));
		conditionsList.add(new Condition("tmp.userStatus","=","","string","userStatus"));//是否有效
		conditionsList.add(new Condition("tmp.maintainStatus","=","","string","maintainStatus"));
		conditionsList.add(new Condition("tmp.cusUserName","like","","String","cusUserName"));// 客服名称
		
		JSONObject queryModel = JSONParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionsList, "");
		qc.addCondition("tmp.userType","=","0","int"); // 0:浏览用户,1:交易员用户
		this.log.debug("qc=" + qc.toString());
		//分页信息
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JSONParams);
		try {
			list = this.mgr.selectCUserList(qc, pageInfo);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询客户信息维护 列表：" + e.getMessage());
			setResultData("10105", null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("客户信息维护 转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}

		}
		this.log.info(this.getClass().getName() + " getCustomerMaintainInfoList() End");
		return rtnData.toString();
	
	}

	@Override
	public String getCustomerMaintainInfoByUserCode(String params) {
		this.log.info(this.getClass().getName() + " getCustomerMaintainInfoByUserCode() Start");
		this.log.debug("JSONParams=" + params);
		boolean bolRst = false;
		JSONObject JSONParams = new JSONObject(params);
		CusInfoMaintainModel result = null;
		try {
			result = this.mgr.selectCusInfoMaintainByUserCode(JSONParams.getString("userCode"));
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询客户信息维护 失败：" + e.getMessage());
			setResultData("10105", null, e.getMessage());
		}
		if (bolRst) {
			JSONObject retData;
			try {
				retData = JsonUtil.coverModelToJSONObject(result);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error("客户信息维护 转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getCustomerMaintainInfoByUserCode() End");
		return rtnData.toString();
	}

	@Override
	public String updateCusInfoMaintain(String params) {
		this.log.info(this.getClass().getName() +  " updateCusInfoMaintain() Start");
		this.log.debug("JSONParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		CusInfoMaintainModel model = (CusInfoMaintainModel) JsonUtil.jsonToBean(queryModel, CusInfoMaintainModel.class);
		
		String curruserName = this.getUserName()==null?"system":this.getUserName();
		
		String userCode = model.getUserCode();
		try {
			int count = this.mgr.countCusInfoMaintainByUserCode(userCode);
			if (count == 0){
				model.setRecCreateby(curruserName);
				model.setRecModifyby(curruserName);
				this.mgr.insertCusInfoMaintain(model);
				setResultData("00000", null);
				this.log.businesslog("新增客户信息维护 ",Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
			}else if (count == 1){
				model.setRecModifyby(curruserName);
				this.mgr.updateCusInfoMaintain(model);
				setResultData("00000", null);
				this.log.businesslog("更新客户信息维护 ",Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
			}else{
				setResultData("10106", null);
				this.log.businesslog("更新客户信息维护 ",Constants.OPE_MODE_MEMBER,Constants.OPE_FAIL);
			}
		} catch (Exception e) {
			setResultData("10106", null);
			this.log.businesslog("更新客户信息维护 "+e.getMessage(),Constants.OPE_MODE_MEMBER,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " updateCusInfoMaintain() End");
		return rtnData.toString();
	}

	@Override
	public String configurationCusInfo(String params) {
		this.log.info(this.getClass().getName()+" configurationCusInfo() start");
		this.log.debug("configurationCusInfo Service Start debug");
		JSONObject JOParams=new JSONObject(params);
		CusInfoCscfg cusInfoCscfg=null;
		CusInfoCscfg existCscfg=null;
		cusInfoCscfg=(CusInfoCscfg) JsonUtil.jsonToBean(JOParams,CusInfoCscfg.class);
		
		String userName = this.getUserName() == null ? "system" : (this.getUserName() == "") ? "system" : this.getUserName();
		cusInfoCscfg.setRecCreateby(userName);
		cusInfoCscfg.setRecModifyby(userName);
		String userCode = JOParams.getString("userCode");
		String userId=JOParams.getString("userId");
		boolean bolRst = false;
		String messageString="";
		try {
			 existCscfg=this.mgr.getCusInfoCscfg(userCode);
			 bolRst=true;
		} catch (Exception e) {
			this.log.error("查询客服是否存在出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
		}
	
		if(bolRst){
			if(existCscfg!=null){
				try {
					existCscfg.setUserId(userId);
					existCscfg.setRecModifyby(userName);
					existCscfg.setRecModifytime(new Date());
					this.mgr.updateCusInfo(existCscfg);
					bolRst=true;
				} catch (Exception e) {
					bolRst=false;
					messageString=e.getMessage();
				}
			}else{
				try {
					this.mgr.addCusInfo(cusInfoCscfg);
					bolRst=true;
				} catch (Exception e) {
					bolRst=false;
					messageString=e.getMessage();
				}
			}
		}
		
		if(bolRst){
			setResultData("00000", null);
			this.log.businesslog("配置客服成功",Constants.OPE_MODE_MEMBER,Constants.OPE_SUCCESS);
		}else{
			setResultData("10106", null, messageString);
			this.log.businesslog("配置客服出错"+messageString,Constants.OPE_MODE_MEMBER,Constants.OPE_FAIL);
		}
		
		this.log.info(this.getClass().getName() + " configurationCusInfo() End");
		return rtnData.toString();
	}

	@Override
	public String getCusInfoCSCfgByUserCode(String params) {

		this.log.info(this.getClass().getName()+" getCusInfoCSCfgByUserCode() start");
		this.log.debug("getCusInfoCSCfgByUserCode Service Start debug");
		JSONObject JOParams=new JSONObject(params);
		boolean bolRst = false;
		CusInfoCscfg result = null;
		try {
			result = this.mgr.getCusInfoCscfg(JOParams.getString("userCode"));
			 bolRst=true;
		} catch (Exception e) {
			this.log.error("查询客服配置信息失败" + e.getMessage());
			setResultData("10106", null, e.getMessage());
		}
	
		if(bolRst){
			JSONObject retData;
			try {
				retData = JsonUtil.coverModelToJSONObject(result == null ? new CusInfoCscfg() : result);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error("客服配置信息 转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getCusInfoCSCfgByUserCode() End");
		return rtnData.toString();
	
	}
	
	@Override
	public String thawUserErrorPswById(String params) {

		this.log.info(this.getClass().getName()+" thawUserErrorPswById() start");
		this.log.debug("thawUserErrorPswById Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		if (JOParams.isNull("id")){
			setResultData("10103", null, "参数【id】未找到！");
			return rtnData.toString();
		}
		Integer id = JOParams.getInt("id");
		try {
			 this.mgr.updateUserErrorPswOfErrorNumsById(id);
			 setResultData("00000", null);
		} catch (Exception e) {
			this.log.error("解冻用户失败" + e.getMessage());
			setResultData("10106", null, e.getMessage());
		}
		this.log.info(this.getClass().getName() + " thawUserErrorPswById() End");
		return rtnData.toString();
	}
	
	/**
	 * 判断微信和用户是否绑定
	 * 
	 * @param code
	 */
	@Override
	@Deprecated
	public String isBindWeinXin(String params) {
		this.log.info(this.getClass().getName() + " isBindWeinXin() Start");
		this.log.debug("isBindWeinXin Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		String code = JOParams.getString("code");
		OauthApi oauth = new OauthApi();
		OauthToken token;
		try {
			token = oauth.getOauthToken(code);
			
			//判断是否绑定
			UserWeiXin uwx = mgr.getUserByOpenID(token.getOpenId());
			if (uwx != null) {
				//已经绑定了，页面不需要再次绑定
				this.log.warn("用户和微信账号已经绑定");
				setResultData(ResultCode.CODE10102.getValue(), null, "用户和微信账号已经绑定");
			} else {
				//还未绑定，返回openid给页面
				JSONObject jsonObj = new JSONObject();
				EncryptUtil e = new EncryptUtil(Constants.DES_KEY);
				String openId = e.encode(token.getOpenId());
				jsonObj.put("result", openId);
				setResultData(ResultCode.CODE00000.getValue(), jsonObj);
			}
			
		} catch (WeixinException e) {
			this.log.error("获取用户微信openid出错：" + e.getMessage());
			setResultData(ResultCode.CODE10101.getValue(), null, e.getMessage());
		}
		this.log.info(this.getClass().getName() + " isBindWeinXin() End");
		this.log.debug("isBindWeinXin Service End debug");
		return rtnData.toString();
	}
	
	/**
	 * code换取token
	 * {"json":{"ServiceName":"shcem.member.service.IUserService","MethodName":"getUserOpenId", "Params": "{\"code\":\"dafdafd\"}" }}
	 * reponese: {"DATA":"{\"result\":\"tlVX3qm6PvylC1Qkk9wXNudSfIhAwgPy1Bl1Mw/0Rmo=\"}","INFO":"Service执行成功。","CODE":"00000"}
	 * @param code
	 *            用户同意授权获取的code，
	 *            code作为换取access_token的票据，每次用户授权带上的code将不一样，code只能使用一次
	 *            ，5分钟未被使用自动过期。
	 * @return oauthtoken信息内的openid
	 */
	@Override
	public String getUserOpenId(String params) {
		this.log.info(this.getClass().getName() + " getUserOpenId() Start");
		this.log.debug("getUserOpenId Service Start debug");
		
		//需pool化
		Jedis jedis = new Jedis(Constants.REDIS_HJ_IP, Constants.REDIS_HJ_PORT);
		jedis.select(10);
		JSONObject JOParams = new JSONObject(params);
		String code = JOParams.getString("code");
		EncryptUtil encrypt = new EncryptUtil(Constants.DES_KEY);
		
		try {
			OauthApi oauth = new OauthApi();
			OauthToken token;
		
			this.log.debug("通过code换取网页授权access_token开始"); //（与基础支持中的access_token不同,是2个概念） 
			token = oauth.getOauthToken(code);
			//缓存code-openid
			jedis.setex("weixin_code_" + code, 3600,encrypt.encode(token.getOpenId()));
			
			this.log.debug("通过code换取网页授权access_token结束");
			
			//判断是否绑定
			UserWeiXin uwx = mgr.getUserByOpenID(token.getOpenId());
			if (uwx == null) {
				//保存用户微信信息（需微信授权）
				Weixin4jSettings<WeixinAccount> settings = new Weixin4jSettings<WeixinAccount>(
						Weixin4jConfigUtil.getWeixinAccount());
				TokenManager tokenManager = new TokenManager(new WeixinTokenCreator(settings
						.getAccount().getId(), settings.getAccount().getSecret()),
						settings.getCacheStorager0());
				
				UserApi userApi = new UserApi(tokenManager);
				com.foxinmy.weixin4j.mp.model.User user = userApi.getUser(token.getOpenId());
				UserWeiXin userWeiXin = new UserWeiXin();
				CommonUtils.copyItems(user, userWeiXin);
				userWeiXin.setSubscribe(user.isSubscribe());
				this.mgr.addWeiXinInfo(userWeiXin);
				
				//还未绑定，返回openid给页面
				JSONObject jsonObj = new JSONObject();
			
				String openId = encrypt.encode(token.getOpenId());
				jsonObj.put("result", openId);
				
				setResultData(ResultCode.CODE00000.getValue(), jsonObj);
			} else if (StringUtils.isNotBlank(uwx.getUserCode())) {
				//已经绑定了，页面不需要再次绑定
				this.log.warn("用户和微信账号已经绑定");
				//执行login动作
				//TODO
				//******微信支付***********start
				JSONObject jsonObj = new JSONObject();
				String openId = encrypt.encode(token.getOpenId());
				jsonObj.put("result", openId);
				//******微信支付***********end
				
				setResultData(ResultCode.CODE10102.getValue(), jsonObj, "用户和微信账号已经绑定");
			} else {
				//userCode为空，还未绑定，但微信已授权
				JSONObject jsonObj = new JSONObject();
				String openId = encrypt.encode(token.getOpenId());
				jsonObj.put("result", openId);
			
				setResultData(ResultCode.CODE00000.getValue(), jsonObj);
			}
			
		} catch (WeixinException e) {
			this.log.error("获取用户微信openid出错：" + e.getMessage());
			setResultData(ResultCode.CODE10101.getValue(), null, e.getMessage());
			//不合法的oauth_code:原因，该code已经失效（code只能使用一次）
			//TODO 临时代码
			if ("40029".equals(e.getErrorCode())) {
				this.log.error(jedis.get("weixin_code_" + code) + ": errorCode = 40029");
				setResultData(ResultCode.CODE10114.getValue(), jedis.get("weixin_code_" + code), "微信authCode出错！");
			}
		} catch (Exception ex) {
			this.log.error("获取用户微信openid异常：" + ex.getMessage());
			setResultData(ResultCode.CODE10101.getValue(), null, ex.getMessage());
		}
		this.log.info(this.getClass().getName() + " getUserOpenId() End");
		this.log.debug("getUserOpenId Service End debug");
		return rtnData.toString();
	}
	
//	@Override
//	public String getUserOpenId(String params) {
//		this.log.info(this.getClass().getName() + " getUserOpenId() Start");
//		this.log.debug("getUserOpenId Service Start debug");
//		
//		//userCode为空，还未绑定，但微信已授权
//		JSONObject jsonObj = new JSONObject();
//		String openId = "129479327493794739479324";
//		jsonObj.put("result", openId);
//		
//		setResultData(ResultCode.CODE00000.getValue(), jsonObj);
//		this.log.info(this.getClass().getName() + " getUserOpenId() End");
//		this.log.debug("getUserOpenId Service End debug");
//		return rtnData.toString();
//	}
	
	/**
	 * 添加用户和微信账号关联关系
	 * 
	 */
	@Override
	public String addUserWeiXinRelation(String params) {
		this.log.info(this.getClass().getName() + " addUserWeiXinRelation() Start");
		this.log.debug("addUserWeiXinRelation Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		try {
			String mobileNo = JOParams.getString("mobileNo");
			String openID = JOParams.getString("openId");
		
			UserWeiXin userWeiXin = new UserWeiXin();
			userWeiXin.setMobile(mobileNo);
			
			EncryptUtil e = new EncryptUtil(Constants.DES_KEY);
			log.info("e.decode(openID): " + e.decode(openID));
			userWeiXin.setOpenId(e.decode(openID)); //需要解密
			this.mgr.addUserWeiXinRelation(userWeiXin);
			
			setResultData(ResultCode.CODE00000.getValue(), null);
		} catch (Exception e) {
			if (e instanceof BaseException) {
				this.log.error("用户和微信账号已经绑定");
				setResultData(ResultCode.CODE10102.getValue(), null, e.getMessage());
			} else {
				this.log.error("用户和微信账号绑定出错：" + e.getMessage());
				setResultData(ResultCode.CODE10101.getValue(), null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " addUserWeiXinRelation() End");
		this.log.debug("addUserWeiXinRelation Service End debug");
		return rtnData.toString();
	}
	
	
	/**
	 * 获取JSAPI 签名
	 */
	@Override
	public String getJsSignature(String params){
		String ticketReplaceUrl = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=ACCESS_TOKEN&type=jsapi";
		String tokenReplaceUrl = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=APPID&secret=APPSECRET";
		JSONObject JOParams = new JSONObject(params);
		String allUrl = JOParams.getString("allUrl");
		
		String tokenUrl = tokenReplaceUrl.replace("APPID", Weixin4jConfigUtil.getWeixinAccount().getId())
				.replace("APPSECRET", Weixin4jConfigUtil.getWeixinAccount().getSecret());
		JSONObject tokenJO = PayUtils.httpsRequestToJsonObject(tokenUrl, "GET", null);
		if (tokenJO != null){
			String accessTokent = tokenJO.getString("access_token");
			
			try {
				
				String url = ticketReplaceUrl.replace("ACCESS_TOKEN", accessTokent);
				JSONObject jsonObject = PayUtils.httpsRequestToJsonObject(url, "GET", null);
				if (jsonObject != null && jsonObject.getInt("errcode") == 0){
					String jsApiTicket = jsonObject.getString("ticket");
					Signature signature = PayUtils.sign(jsApiTicket, allUrl);
					
					
					Map<String, String> responseMap = new HashMap<String, String>();
					responseMap.put("appId", Weixin4jConfigUtil.getWeixinAccount().getId());
					responseMap.put("timeStamp", signature.getTimestamp());
					responseMap.put("nonceStr", signature.getNonceStr());
					responseMap.put("signature", signature.getSignature());
					String responseData = JSON.toJSONString(responseMap);
					setResultData(ResultCode.CODE00000.getValue(), responseData, "success");
				}else{
					//签名失败
					setResultData(ResultCode.CODE110014.getValue(), null, "签名失败");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				//签名失败
				setResultData(ResultCode.CODE110014.getValue(), null, "签名失败");
			}
			
		}else{
			//签名失败
			setResultData(ResultCode.CODE110014.getValue(), null, "签名失败");
		}
	
		
		
		return rtnData.toString();
	}

	/**
	 * open换取preid, 然后preid得到 微信内H5调起支付 所要数据
	 * {"json":{"ServiceName":"shcem.member.service.IUserService","MethodName":"getBrandWCPayRequestParams", "Params": 
	 * "{\"total_fee\":1,\"openId\":\"openId\"}" }}
	 */
	@Override
	public String getBrandWCPayRequestParams(String params) {
		this.log.info(this.getClass().getName() + " getBrandWCPayRequestParams() Start");
		this.log.debug("getBrandWCPayRequestParams Service Start debug");
		
		final int connectTime = 6*1000;
		final int readTime = 8*1000;
		
		JSONObject JOParams = new JSONObject(params);
		try{
			
			String orderID = JOParams.getString("orderID");
			BigDecimal total_fee = RemoteMbappUtil.getOrderSum(orderID, "test", this.getMode(), this.getRequestId());
			
			if (total_fee.floatValue() < 0){
				throw new IllegalArgumentException("参数错误");
			}
			
			EncryptUtil e = new EncryptUtil(Constants.DES_KEY);
			String openId = e.decode(JOParams.getString("openId"));
//			String openId = "oSEaLv2kI_x9IjhHbTaF58d3qOxU";
			
			System.out.println("openID: " + openId);
			
			String notify_url = JOParams.getString("notify_url");
			final String appid = Weixin4jConfigUtil.getWeixinAccount().getId();
			//商户号
			final String mch_id = Weixin4jConfigUtil.getWeixinPayAccount().getMchId();
			final String key = Weixin4jConfigUtil.getWeixinPayAccount().getPaySignKey();
			String ip = PayUtils.getIpAddr();
			
			WXPayConfig config = new WXPayConfig(){

				@Override
				public String getAppID() {
					// TODO Auto-generated method stub
					return appid;
				}

				@Override
				public InputStream getCertStream() {
					// TODO Auto-generated method stub
					return null;
				}

				@Override
				public String getKey() {
					// TODO Auto-generated method stub
					return key;
				}

				@Override
				public String getMchID() {
					// 商户号
					return mch_id;
				}

				@Override
				public int getHttpConnectTimeoutMs() {
					// TODO Auto-generated method stub
					return connectTime;
				}

				@Override
				public int getHttpReadTimeoutMs() {
					// TODO Auto-generated method stub
					return readTime;
				}
				
			};
			
			// 第三个参数表示 使用测试地址
			WXPay wxPay = new WXPay(config, SignType.MD5);
			
			//商户订单号
//			String out_trade_no = System.currentTimeMillis()/1000 + 
//			UUID.randomUUID().toString().replaceAll("-", "").substring(0, 22);
	
			//商户订单号
			String out_trade_no = orderID;
			
			Map<String, String> payInfo = PayUtils.createPayInfo(total_fee, 
					out_trade_no, notify_url, ip, openId);
			//预定义账单 返回值
			Map<String, String> preIDResponseMap = wxPay.unifiedOrder(payInfo);
			
			//返回给前端的数据
			Map<String, String> responseMap = new HashMap<String, String>();
			if(preIDResponseMap.get("return_code").equals("SUCCESS")){
				if (preIDResponseMap.get("result_code").equals("SUCCESS")){
					responseMap.put("appId", appid);
					responseMap.put("timeStamp", String.valueOf(System.currentTimeMillis()/1000));
					responseMap.put("nonceStr", WXPayUtil.generateNonceStr());
					responseMap.put("package", "prepay_id=" + preIDResponseMap.get("prepay_id"));
					responseMap.put("signType", "MD5");
					responseMap.put("paySign", WXPayUtil.generateSignature(responseMap, config.getKey()));
					
					String responseData = JSON.toJSONString(responseMap);
					setResultData(ResultCode.CODE00000.getValue(), responseData, "success");
				}else{
					//签名失败
					setResultData(ResultCode.CODE110015.getValue(), null, preIDResponseMap.get("err_code_des"));
				}
				
			}else{
				//签名失败
				setResultData(ResultCode.CODE110014.getValue(), null, "签名失败");
			}
			
			
			
			
		}catch(Exception e){
			//预支付订单ID 出错
			setResultData(ResultCode.CODE10116.getValue(), null, e.getMessage());
		}
		
		return rtnData.toString();
	}
	
	
}
