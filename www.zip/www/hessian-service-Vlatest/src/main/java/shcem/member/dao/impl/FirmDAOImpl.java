/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmDAOImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.dao.impl;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.CallableStatementCallback;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.service.model.ValueTxtView;
import shcem.member.dao.FirmDAO;
import shcem.member.dao.model.FirmAllData;
import shcem.member.dao.model.FirmApp;
import shcem.member.dao.model.FirmDataList;
import shcem.member.dao.model.FirmDetail;
import shcem.member.dao.model.FirmPositionLimitModel;
import shcem.member.dao.model.FirmRegTmptRlsp;
import shcem.member.dao.model.FirmRegister;
import shcem.member.dao.model.FirmSetting;
import shcem.member.dao.model.FirmTmptRlsp;
import shcem.member.dao.model.Firmvatinfo;
import shcem.member.dao.model.RecAddRess;
import shcem.member.dao.model.Shop;
import shcem.member.dao.model.ShopFirm;
import shcem.member.dao.model.Trader;
import shcem.member.dao.model.VatAddRess;
import shcem.util.Common;
import shcem.util.CommonRowMapper;

/**
 * @author wlpod
 *
 */
public class FirmDAOImpl extends BaseDAOImpl implements FirmDAO {

	
	@Override
	public List<FirmDataList> getFirmList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getFirmList DAO Start");
		List<FirmDataList> retList = null;
		String sql = sqlProperty.getProperty("FirmDAO_001");
		retList = queryBySQL(sql, qc, pageInfo,  new CommonRowMapper(new FirmDataList()));
		return retList;
	}

	@Override
	public FirmAllData getFirm(String firmId) {
		FirmAllData firmAllData = new FirmAllData();
		Object[] params = { firmId };
		String sql = sqlProperty.getProperty("FirmDAO_002") ;
		firmAllData = (FirmAllData) queryForObject(sql, params, new CommonRowMapper(new FirmAllData()));
		return firmAllData;
	}
	
	
	
	
	@Override
	public int updateFirm(FirmDetail firmDetail) {
		//修改交易商主表信息
		String sql = sqlProperty.getProperty("FirmDAO_003");
		Object [] params = {
				firmDetail.getFirmName(),firmDetail.getFullName(),firmDetail.getFirmType(),
			firmDetail.getBusinessType(),firmDetail.getAddress(),firmDetail.getFax(),firmDetail.getPostCode(),
			firmDetail.getDisabled(),firmDetail.getRecModifyby(),firmDetail.getAddressPV(),firmDetail.getAddressCT(),
			firmDetail.getAddressDT(),firmDetail.getFirmNamePY(),firmDetail.getIsBinding(),firmDetail.getPayType(),
			firmDetail.getTradeAuthority(),firmDetail.getIsAuthorized() == null ? 0:firmDetail.getIsAuthorized(),
			firmDetail.getFirmID()
		};
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		int rowNm = this.getJdbcTemplate().update(sql, params);
		return rowNm;
	}
	
	

	@Override
	public int updateFirmDetail(FirmDetail firmDetail) {
		//修改交易商详细表信息
		String sql = sqlProperty.getProperty("FirmDAO_004");
		Object [] params = {
				firmDetail.getSettingBankID(),firmDetail.getSettingBkBranch(),firmDetail.getSettingBkAccount(),
			firmDetail.getNote(),firmDetail.getBSEntityName(),firmDetail.getBSEntityTelNo(),firmDetail.getContactName(),
			firmDetail.getContactTelNo(),firmDetail.getContactMobile(),firmDetail.getBSLicenseNo(),
			firmDetail.getRegisterCapiTal(),firmDetail.getBSLicense(),firmDetail.getTaxRegisterNo(),
			firmDetail.getTaxLicense(),firmDetail.getOrganizationCd(),firmDetail.getOrgCode(),
			firmDetail.getUnifyLicenseNo(),firmDetail.getUnifyLicense(),firmDetail.getDGLicenseNo(),
			firmDetail.getDGLicense(),firmDetail.getDGLicenseAuth(),firmDetail.getTaxNo(),firmDetail.getRecModifyby(),firmDetail.getLicenseDiffer(),
			firmDetail.getIsDanger(),firmDetail.getDGExpireDate(),
			firmDetail.getCustomerName()==null?"":firmDetail.getCustomerName(),//推荐客服
			firmDetail.getFirmID()
		};
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
			int rowNm = this.getJdbcTemplate().update(sql, params);
			return rowNm;
	}

	@Override
	public int addFirm(FirmDetail firmDetail) {
		/*
		 * 如果用户代理注册，直接认为审核通过
		 */
		//新增交易商主表信息LicenseDiffer
		//财务同步交易商科目
//		callStoredProcedure("Proc_SP_M_FirmAdd(" + firmDetail.getFirmID() + ")");
		 this.addFirmProc(firmDetail.getFirmID());
		String sql = sqlProperty.getProperty("FirmDAO_005");
		
		Object [] params = {
				firmDetail.getFirmID(),firmDetail.getFirmRegId(),firmDetail.getFirmName(),firmDetail.getFullName(),firmDetail.getFirmType(),
				firmDetail.getBusinessType(),2,firmDetail.getAddress(),firmDetail.getFax(),firmDetail.getPostCode(),
			0,firmDetail.getRecCreateby(),firmDetail.getRecCreateby(),firmDetail.getFirmNamePY(),firmDetail.getAddressPV(),
			firmDetail.getAddressCT(),firmDetail.getAddressDT(),firmDetail.getIsBinding(),firmDetail.getPayType(),
			firmDetail.getTradeAuthority(),
			firmDetail.getIsAuthorized() == null? 0:firmDetail.getIsAuthorized()
		};
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		int rowNm = this.getJdbcTemplate().update(sql, params);
		return rowNm;
	}
	
	

	@Override
	public int addFirmDetail(FirmDetail firmDetail) {
		//新增交易商详细表信息
		String sql = sqlProperty.getProperty("FirmDAO_006");
		//[123, 0, 中国银行长宁分行, MTExMTExMTExMTExMTEx, null, 123, MTIz, 李四, MDEwLTEyMzQ1Njc4, MTM1MDAwMDg4ODg=, 
		//null, null, 123, null, 62, null, 63, null, 128, null, 129, 129, A000021200, , , 1]
		Object [] params = {
				firmDetail.getFirmID(),firmDetail.getSettingBankID(),firmDetail.getSettingBkBranch(),firmDetail.getSettingBkAccount(),firmDetail.getNote(),
			firmDetail.getBSEntityName(),firmDetail.getBSEntityTelNo(),firmDetail.getContactName(),firmDetail.getContactTelNo(),
			firmDetail.getContactMobile(),firmDetail.getBSLicenseNo(),firmDetail.getRegisterCapiTal(),
			firmDetail.getBSLicense(),firmDetail.getTaxRegisterNo(),firmDetail.getTaxLicense(),
			firmDetail.getOrganizationCd(),firmDetail.getOrgCode(),firmDetail.getUnifyLicenseNo(),
			firmDetail.getUnifyLicense(),firmDetail.getDGLicenseNo(),firmDetail.getDGLicense(),
			firmDetail.getDGLicenseAuth(),firmDetail.getTaxNo(),firmDetail.getRecCreateby(),firmDetail.getRecModifyby(),
			firmDetail.getIsDanger(),firmDetail.getLicenseDiffer(),
			firmDetail.getContactEmail(),
			firmDetail.getDGExpireDate(),//危化品有效期
			firmDetail.getIsSignState()==null?1:firmDetail.getIsSignState(),//签约状态
			firmDetail.getCustomerName()==null?"":firmDetail.getCustomerName()//推荐客服
		};
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		int rowNm = this.getJdbcTemplate().update(sql, params);
		return rowNm;
	}




	@Override
	public List<FirmRegister> getRegisteredFirmList(QueryConditions qc,
			PageInfo pageInfo) {
		String sql = sqlProperty.getProperty("FirmDAO_007");
		return queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new FirmRegister()));// 通用绑定模式，根据模型和数据结果集自动。
	}

	@Override
	public int getTotalRegisteredFirmList(QueryConditions qc) {
		String sql = sqlProperty.getProperty("FirmDAO_007");
		List<FirmRegister> list = queryBySQL(sql, qc, null, new CommonRowMapper(new FirmRegister()));// 通用绑定模式，根据模型和数据结果集自动。
		if (list!= null && list.size() > 0) {
			return list.size();
		}else {
			return 0;
		}
	}
	
	@Override
	public FirmRegister getRegisteredFirmDetail(String firmRegId) {
		String sql = sqlProperty.getProperty("FirmDAO_008");
		Object [] params = {
				firmRegId
		};
		FirmRegister firmRegister = (FirmRegister) queryForObject(sql, params, new CommonRowMapper(new FirmRegister()));
		return firmRegister;
	}

	//交易商收票地址信息
	@Override
	public int addFirmRecAddRess(RecAddRess recAddRessBean) {
		String sql = sqlProperty.getProperty("FirmDAO_009");
		Object [] params = {
				recAddRessBean.getRecPV(),recAddRessBean.getRecCT(),recAddRessBean.getRecDT(),
			recAddRessBean.getRecAddress(),0,recAddRessBean.getRecContactName(),
			recAddRessBean.getRecContactTelNo()
		};
		//返回自增主键
		int AddressID = queryForIntID(sql, params);
		return AddressID;
	}

	//交易商接收地址信息（中间表）
	@Override
	public int addFirmInvoice(String firmID, int addressID,int addressType) {
		String sql = sqlProperty.getProperty("FirmDAO_010");
		//地址类型：收票地址
		Object [] params = {
				firmID,addressID,addressType
		};
		int rowNm = this.getJdbcTemplate().update(sql, params);
		return rowNm;
	}

	//交易商增值税开票信息
	@Override
	public int addFirmVATInfo(Firmvatinfo firmvatinfo) {
		String sql = sqlProperty.getProperty("FirmDAO_011");
		//"开票支行" 不需要firmvatinfo.getVatBkBranch()
		Object [] params = {
				firmvatinfo.getFirmID(),
				//开票银行帐号
				firmvatinfo.getVatBkAccount(),
				//开票银行ID
				firmvatinfo.getVatBankID(),
				//开票银行支行
				firmvatinfo.getVatBkBranch()==null?"":firmvatinfo.getVatBkBranch(),
				//开票联系信息ID
				firmvatinfo.getVatAddressID()
		};
		int rowNm = this.getJdbcTemplate().update(sql, params);
		return rowNm;
	}

	//交易商开票地址信息
	@Override
	public int addFirmVatAddRess(VatAddRess vatAddRessBean) {
		String sql = sqlProperty.getProperty("FirmDAO_009");
		Object [] params = {
				vatAddRessBean.getVatPV(),vatAddRessBean.getVatCT(),vatAddRessBean.getVatDT(),
				vatAddRessBean.getVatAddress(),0,vatAddRessBean.getVatContactName(),vatAddRessBean.getVatContactTelNo()
		};
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		//返回自增主键
		int AddressID = queryForIntID(sql, params);
		return AddressID;
	}
	@Override
	public int  updateFirmRegister(String firmRegId) {
		String sql = sqlProperty.getProperty("FirmDAO_012");
		Object [] params = {
				firmRegId
		};
		int returnCode = 0;
		try {
			returnCode = this.getJdbcTemplate().update(sql,params);
		} catch (Exception e) {
			returnCode = -1;
		}
		return returnCode;
	}

	@Override
	public List<RecAddRess> queryRecAddRess(String firmID) {
		this.log.debug("queryRecAddRess DAO Start");
		List<RecAddRess> retList = null;
		String sql = sqlProperty.getProperty("FirmDAO_013");
		Object [] params = {
				firmID
		};
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		retList = this.getJdbcTemplate().query(sql, params,  new CommonRowMapper(new RecAddRess()) );
		return retList;
	}

	@Override
	public int updateFirmvatinfo(VatAddRess vatAddRess,String firmID) {
		//修改交易商主表信息
		String sql = sqlProperty.getProperty("FirmDAO_014");
		Object [] params = {
				vatAddRess.getVatBkAccount(),vatAddRess.getVatBankID(),
				"",vatAddRess.getId(),firmID
		};
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		int rowNm = this.getJdbcTemplate().update(sql, params);
		return rowNm;
	}

	@Override
	public int updateFirmVatAddRess(VatAddRess vatAddRess) {
		//修改交易商主表信息
		String sql = sqlProperty.getProperty("FirmDAO_015");
		Object [] params = {
				vatAddRess.getVatPV(),vatAddRess.getVatCT(),vatAddRess.getVatDT(),
			vatAddRess.getVatAddress(),"",vatAddRess.getVatContactTelNo(),
			vatAddRess.getId()
		};
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		int rowNm = this.getJdbcTemplate().update(sql, params);
		return rowNm;
	}

	@Override
	public Firmvatinfo queryFirmvatinfo(String firmID) {
		Firmvatinfo firmvatinfo = new Firmvatinfo();
		Object[] params = { firmID };
		String sql = sqlProperty.getProperty("FirmDAO_016") ;
		firmvatinfo = (Firmvatinfo) queryForObject(sql, params, new CommonRowMapper(new Firmvatinfo()));
		return firmvatinfo;
	}

	@Override
	public int  updateFirmDisabled(String firmID,int disabled) {
		String sql = sqlProperty.getProperty("FirmDAO_017");
		Object [] params = {
				disabled,firmID
		};
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		return this.getJdbcTemplate().update(sql, params);
	}

	@Override
	public void rejectRegisteredFirm(String firmRegId,String note) {
		String sql = sqlProperty.getProperty("FirmDAO_018");
		Object [] params = {
				note,firmRegId
		};
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		this.getJdbcTemplate().update(sql, params);
		
	}
	
	private String addFirmProc(final String FirmID) {
		String result = "-1";
		String procedure = "{?=call Proc_SP_M_FirmAdd(?)}"; 
		try{  
			result = (String) this.getJdbcTemplate().execute(procedure, new CallableStatementCallback(){  
                public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {  
                	cs.registerOutParameter(1,Types.INTEGER); //输出参数类型  
                	cs.setString(2, FirmID);
                	cs.execute();
                	return cs.getString(1);
                }  
            }); 
        }catch(Exception e){  
            e.printStackTrace();  
            result = "-1";
        }  
		return result;

	}

	@Override
	public List<FirmAllData> getFirmByFirmName(String firmName) {
		String sql = this.sqlProperty.getProperty("FirmDAO_019");
		List<FirmAllData> retList;
		Object[] params = {
				firmName
		};
		retList = this.queryBySQL(sql, params, null, new CommonRowMapper(new FirmAllData()));
		return retList;
	}
	
	@Override
	public List<FirmAllData> getFirmByFullName(String fullName) {
		String sql = this.sqlProperty.getProperty("FirmDAO_025");
		List<FirmAllData> retList;
		Object[] params = {
				fullName
		};
		retList = this.queryBySQL(sql, params, null, new CommonRowMapper(new FirmAllData()));
		return retList;
	}
	@Override
	public List<FirmTmptRlsp> getFirmTmptRlspList(String firmId) {
		String sql = this.sqlProperty.getProperty("FirmDAO_020");
		List<FirmTmptRlsp> retList;
		Object[] params = {
				firmId
		};
		retList = this.queryBySQL(sql, params, null, new CommonRowMapper(new FirmTmptRlsp()));
		return retList;
	}
	@Override
	public void addFirmTmptRlsps(FirmTmptRlsp firmTmptRlsp) {
		String sql = this.sqlProperty.getProperty("FirmDAO_021");
		Object[] param = {
				firmTmptRlsp.getFirmID(),firmTmptRlsp.getTradeTmptId(),firmTmptRlsp.getEnabled(),
			firmTmptRlsp.getIsRealName()==null?0:firmTmptRlsp.getIsRealName(),firmTmptRlsp.getTradeAuthority()};
		this.updateBySQL(sql, param);
		
	}
	@Override
	public void delFirmTmptRlsps(String firmID) {
		String sql = this.sqlProperty.getProperty("FirmDAO_022");
		Object[] param = {
				firmID
		};
		this.updateBySQL(sql, param);
		
	}
	@Override
	public List<Trader> getTrader(String traderID) {
		String sql = this.sqlProperty.getProperty("FirmDAO_023");
		Object[] params = {
				traderID
		};
		return this.queryBySQL(sql, params, null,new CommonRowMapper(new Trader()));
	}
	
	@Override
	public int getTotalTraderNum(String firmID) {
		String sql = this.sqlProperty.getProperty("FirmDAO_024");
		Object[] params = {
				firmID
		};
		return this.queryForInt(sql, params);
	}
	@Override
	public List<VatAddRess> getAddRessList(String firmId) {
		String sql = this.sqlProperty.getProperty("FirmDAO_026");
		Object[] params = {
				firmId
		};
		return this.queryBySQL(sql, params, null,new CommonRowMapper(new VatAddRess()));
	}
	
	 @Override
	public int updateFirmvatinfo(Firmvatinfo firmvatinfo) {
		//修改交易商主表信息
		String sql = sqlProperty.getProperty("FirmDAO_027");
		Object [] params = {
				firmvatinfo.getVatBkAccount(),firmvatinfo.getVatBankID(),firmvatinfo.getVatBkBranch(),
			firmvatinfo.getVatAddressID(),firmvatinfo.getFirmID()
		};
		
		int rowNm = this.getJdbcTemplate().update(sql, params);
		return rowNm;
	}
	 
	@Override
	public void deleteFirmvatinfo(String firmID) {
		String sql = sqlProperty.getProperty("FirmDAO_028");
		Object [] params = {
				firmID
		};
		this.getJdbcTemplate().update(sql, params);
	}
	public void updateFirmIDPoolIsUsed(String firmID) {
		String sql = "update C_FirmIDPool set IsUsed = 1 where FirmID='"+firmID+"'";
		this.getJdbcTemplate().update(sql);
	}
	@Override
	public String GetNewFirmIDByZone(final String zoneNum) {
		String result = "0000000";
		String procedure = "{?=call sp_GetNewFirmIDByZone(?,?)}"; 
		try{  
			result=(String)this.getJdbcTemplate().execute(procedure, new CallableStatementCallback(){  
                public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {  
                	cs.registerOutParameter(1,Types.INTEGER); //输出参数类型  
                	cs.setString(2, zoneNum);
                	cs.setString(3, "");
                	cs.registerOutParameter(3,Types.VARCHAR); 
                	cs.execute();
                	return cs.getString(3);
                }  
            }); 
        }catch(Exception e){  
            e.printStackTrace();  
        }  
		return result;
	}
	
	/**
	 * 修改交易商注册信息 ("客服审核"通过)
	 */
	@Override
	public int updateFirmRegisterDetail(FirmRegister firmRegister) {
		String sql = this.sqlProperty.getProperty("FirmDAO_029");
		Object[] params ={
				firmRegister.getFirmStatus(),
				firmRegister.getFirmName(),firmRegister.getFullName(),
				firmRegister.getFirmType(),firmRegister.getBusinessType(),
				firmRegister.getAddressPV(),firmRegister.getAddressCT(),
				firmRegister.getAddressDT(),firmRegister.getAddress(),
				firmRegister.getFax(),firmRegister.getPostCode(),
				firmRegister.getContactName(),firmRegister.getContactTelNo(),
				//联系人手机号码               证照区分
				firmRegister.getContactMobile(),firmRegister.getLicenseDiffer(),
				//营业执照      税务登记证
				firmRegister.getBSLicense(),firmRegister.getTaxLicense(),
				//组织机构代码证       综合证
				firmRegister.getOrgCode(),firmRegister.getUnifyLicense(),
				//危化品经营许可证     结算银行ID
				firmRegister.getDGLicense(),firmRegister.getSettingBankID(),
				//结算银行支行            结算银行帐号
				firmRegister.getSettingBkBranch(),firmRegister.getSettingBkAccount(),
				//开票银行
				firmRegister.getVatBankID(),firmRegister.getVatBkBranch(),
				firmRegister.getVatBkAccount(),
				firmRegister.getVatPV(),firmRegister.getVatCT(),
				firmRegister.getVatDT(),firmRegister.getVatAddress(),
				//企业税号
				firmRegister.getTaxNo(),firmRegister.getVatContactTelNo(),
				firmRegister.getRecPV(),firmRegister.getRecCT(),
				firmRegister.getRecDT(),firmRegister.getRecAddRess(),
				firmRegister.getRecContactName(),firmRegister.getRecContactTelNo(),
				firmRegister.getRecModifyby(),new Date(),
				// 是否银商绑定       是否金石湾危化
				firmRegister.getIsBinding(),
				
				firmRegister.getRejectReason(),
				firmRegister.getFirmID(),
				firmRegister.getTradeAuthority(),
				firmRegister.getIsDanger(),
				firmRegister.getBSLicenseNo(),
				firmRegister.getOrganizationCd(),
				firmRegister.getRegisterCapital(),
				firmRegister.getBSEntityName(),
				firmRegister.getBSEntityTelNo(),
				firmRegister.getDGExpireDate(),
				firmRegister.getContactEmail(),
				firmRegister.getUnifyLicenseNo(),
				firmRegister.getDGLicenseNo(),
				firmRegister.getTaxRegisterNo(),
				firmRegister.getDGLicenseAuth(),
				
				firmRegister.getFirmRegId()
		};
		return this.updateBySQL(sql, params);
	}
	
	@Override
	public int refuseFirmRegister(String firmRegId, String rejectReason) {
		//String sql = "update C_FirmRegister set FirmStatus=4,RejectReason='"+rejectReason+"' where FirmRegId='"+firmRegId+"'";//1：风控审核不通过
		String sql = "update C_FirmRegister set FirmStatus=1,RejectReason='"+rejectReason+"' where FirmRegId='"+firmRegId+"'";//0:审核中,1:客服审核不通过,2:风控审核通过,3:客服审核通过,4:风控审核不通过
		Object [] params = {};
		int returnCode = this.updateBySQL(sql, params);
		return returnCode;
	}
	@Override
	public List<RecAddRess> getFirmRecAddressList(PageInfo pageInfo,
			String firmID) {
		String sql = this.sqlProperty.getProperty("FirmDAO_030");
		Object[] param = {
				firmID	
		};
		List<RecAddRess> list = this.queryBySQL(sql, param, pageInfo, new CommonRowMapper(new RecAddRess()));
		return list;
	}
	
	
	@Override
	public int addRecAddress(RecAddRess recAddress) {
		String sql = this.sqlProperty.getProperty("FirmDAO_031");
		Object[] params ={
				recAddress.getRecPV(),
				recAddress.getRecCT(),
				recAddress.getRecDT(),
				recAddress.getRecAddress(),
				recAddress.getRecContactName(),
				recAddress.getRecContactTelNo(),
				new Date(),
				new Date()
		};
		int recAddressID = this.queryForIntID(sql, params);
		return recAddressID;
	}
	@Override
	public void delAddressList(String addressIDs) {
		String sql = "update C_Address set DISABLED = 1 where ID IN ("+addressIDs+")";
		this.updateBySQL(sql);
	}
	@Override
	public RecAddRess getFirmRecAddressByID(int recAddressID) {
		String sql = this.sqlProperty.getProperty("FirmDAO_032");
		Object[] params = {
				recAddressID	
		};
		RecAddRess recAddress = (RecAddRess) this.queryForObject(sql, params, new CommonRowMapper(new RecAddRess()));
		return recAddress;
	}
	@Override
	public void updateRecAddress(RecAddRess recAddress) {
		String sql = this.sqlProperty.getProperty("FirmDAO_033");
		Object[] params ={
				recAddress.getRecPV(),
				recAddress.getRecCT(),
				recAddress.getRecDT(),
				recAddress.getRecAddress(),
				recAddress.getRecContactName(),
				recAddress.getRecContactTelNo(),
				new Date(),
				recAddress.getRecAddressID()
		};
		this.updateBySQL(sql, params);
	}
	@Override
	public void updateFirmInvoice(Integer recAddressID, Integer addressType) {
		String sql = "update C_FirmInvoice set addressType="+addressType+" where AddressID = "+recAddressID;
		this.updateBySQL(sql);
	}
	@Override
	public void disabledRecAddress(int recAddressID,int disabled) {
		String sql = "update C_Address set DISABLED="+disabled+" where ID ="+recAddressID;
		this.updateBySQL(sql);
	}
	
	@Override
	public void addFirmApp(String firmID, Integer appType, String userName) {
		String sql = this.sqlProperty.getProperty("FirmDAO_034");
		Object[] params = {
				firmID,	
				appType,// 1-HJOnline 2-CbiHX
				0,//DISABLED
				userName,
				new Date(),
				userName,
				new Date()
		};
		this.updateBySQL(sql,params);
	}
	@Override
	public List<FirmApp> getFirmAppByParam(String firmID, Integer appType) {
		String sql = this.sqlProperty.getProperty("FirmDAO_035");
		Object[] params = {
				firmID,	
				appType// 1-HJOnline 2-CbiHX
		};
		return this.queryBySQL(sql, params, null, new CommonRowMapper(new FirmApp()));
	}
	
	 @Override
	public void rollBack() {
		 try {
			getConnection().setAutoCommit(false);//事务设置为手动
			getConnection().rollback();
		 } catch (CannotGetJdbcConnectionException e) {
			e.printStackTrace();
		 } catch (SQLException e) {
			e.printStackTrace();
		 }
	}

		private String getFirmRegId() {
			String retID = null;
			String sql = "select next value for hjonline.dbo.FirmRegIdSeq";
			retID = (String) this.queryForObject(sql, String.class);
			int length = 10 - retID.length();
			for (int i = 0; i < length; i++) {
				retID = "0" + retID;
			}
			return retID;
		}
	 
	@Override
	public String insertFirmRegister(FirmRegister firmRegister) {
		String id = this.getFirmRegId();
		firmRegister.setFirmRegId(id);
		String sql = this.sqlProperty.getProperty("FirmDAO_036");
		Object[] params ={
				firmRegister.getFirmRegId(),
				firmRegister.getFirmName(),
				firmRegister.getFullName(),
				firmRegister.getFirmType() == null ? 0 : firmRegister.getFirmType(),// 企业类型
				firmRegister.getBusinessType() == null ? 0 : firmRegister.getBusinessType(),// 业务类型
				0,
				firmRegister.getFirmStatus(),// 当前审核状态 0:审核中,1:客服审核不通过,2:客服审核通过,3:风控审核通过,4:风控审核不通过
				firmRegister.getAddressPV(),
				firmRegister.getAddressCT(),
				firmRegister.getAddressDT(),
				firmRegister.getAddress(),
				firmRegister.getFax(),
				firmRegister.getPostCode(),
				firmRegister.getContactName(),
				firmRegister.getContactTelNo(),
				firmRegister.getContactMobile(),
				firmRegister.getLicenseDiffer()==null ? 0 :firmRegister.getLicenseDiffer(),//证照区分
				firmRegister.getBSLicense(),
				firmRegister.getTaxLicense(),
				firmRegister.getOrgCode(),
				firmRegister.getUnifyLicense(),
				firmRegister.getDGLicense(),
				firmRegister.getSettingBankID(),
				firmRegister.getSettingBkBranch(),
				firmRegister.getSettingBkAccount(),
				firmRegister.getVatBankID(),
				firmRegister.getVatBkBranch(),
				firmRegister.getVatBkAccount(),
				firmRegister.getVatPV(),
				firmRegister.getVatCT(),
				firmRegister.getVatDT(),
				firmRegister.getVatAddress(),
				firmRegister.getTaxNo(),
				firmRegister.getVatContactTelNo(),
				firmRegister.getRecPV(),
				firmRegister.getRecCT(),
				firmRegister.getRecDT(),
				firmRegister.getRecAddRess(),
				firmRegister.getRecContactName(),
				firmRegister.getRecContactTelNo(),
				firmRegister.getRequestUserId(),
				firmRegister.getRecCreateby(),
				new Date(),
				firmRegister.getRecModifyby(),
				new Date(),
				firmRegister.getIsBinding(),
				firmRegister.getRejectReason(),
				firmRegister.getFirmID(),
				firmRegister.getTradeAuthority(),
				firmRegister.getIsDanger(),
				firmRegister.getBSLicenseNo(),
				firmRegister.getOrganizationCd(),
				firmRegister.getRegisterCapital(),
				firmRegister.getBSEntityName(),
				firmRegister.getBSEntityTelNo(),
				firmRegister.getDGExpireDate(),
				firmRegister.getContactEmail(),
				firmRegister.getUnifyLicenseNo(),
				firmRegister.getDGLicenseNo(),
				firmRegister.getTaxRegisterNo(),
				firmRegister.getDGLicenseAuth()
		};
		this.updateBySQL(sql, params);
		
		return id;
	}

	@Override
	public void insertFirmRegTmptRlsp(List<FirmRegTmptRlsp> list) {

		String sql = this.sqlProperty.getProperty("FirmDAO_037");
		for (FirmRegTmptRlsp rlsp : list){
			Object[]  params = {
					rlsp.getTradeTmptId(),
					rlsp.getFirmRegId(),
					rlsp.getEnabled() == null ? "N" : rlsp.getEnabled(),
					rlsp.getIsRealName()
					};
			this.updateBySQL(sql, params);
		}
	}

	@Override
	public List<FirmRegTmptRlsp> selectFirmRegTmptRlspByFirmRegId(
			String firmRegId) {
		String sql = this.sqlProperty.getProperty("FirmDAO_038");
		Object[] params = {firmRegId};
		return this.queryBySQL(sql, params, null, new CommonRowMapper(new FirmRegTmptRlsp()));
	}

	@Override
	public void deleteFirmRegTmptRlspByFirmRegId(String firmRegId) {
		String sql = this.sqlProperty.getProperty("FirmDAO_039");
		Object[] params = {firmRegId};
		this.updateBySQL(sql, params);
		
	}

	@Override
	public int updateCFirmOfFirmStatus(String firmId,String username,Integer firmStatus) {
		String sql = this.sqlProperty.getProperty("FirmDAO_040");
		Object[] params = {firmStatus,username,new Date(),firmId};
		return this.updateBySQL(sql, params);
	}

	/**
	 * 根据条件查询商铺视图
	 *
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public List<Shop> selectShopByParam(QueryConditions qc, PageInfo pageInfo) {
		String sql=this.sqlProperty.getProperty("ShopDAO_001");
		List<Shop> shopList=this.queryBySQL(sql,qc,pageInfo,new CommonRowMapper(new Shop()));
		return shopList;
	}

	/**
	 * 添加商铺
	 *
	 * @param shop
	 */
	public int insertShop(Shop shop) {
		String sql=this.sqlProperty.getProperty("ShopDAO_002");
		Object[] parmas={shop.getShopName(),shop.getSort(),shop.getLogo(),shop.getIntroduction(),shop.getRemark(),shop.getDisabled(),shop.getREC_CREATEBY(),shop.getREC_MODIFYBY()};
		return this.queryForIntID(sql, parmas);
	}
	
	/**
	 * 更新商铺
	 *
	 * @param shop
	 */
	public int updateShop(Shop shop) {
		String sql=this.sqlProperty.getProperty("ShopDAO_003");
		Object[] parmas={shop.getShopName(),shop.getSort(),shop.getLogo(),shop.getIntroduction(),shop.getRemark(),shop.getDisabled(),shop.getREC_CREATEBY(),shop.getREC_MODIFYBY(),shop.getId()};
		return this.updateBySQL(sql,parmas);
	}

	/**
	 * 根据商铺id获得商铺信息
	 *
	 * @param shopId
	 * @return
	 */
	public Shop getById(String shopId) {
		String sql=this.sqlProperty.getProperty("ShopDAO_004");
		Object[] params={shopId};
		Shop shop= (Shop) this.queryForObject(sql,params,new CommonRowMapper(new Shop()));
		return shop;
	}

	@Override
	public void insertFirmSetting(FirmSetting firmSetting) {
		String sql=this.sqlProperty.getProperty("FirmDAO_041");
		Object[] params={firmSetting.getFirmCode(),firmSetting.getSettingType(),firmSetting.getSettingValue(),
				firmSetting.getAppType(),firmSetting.getRemark(),0,firmSetting.getREC_CREATEBY(),firmSetting.getREC_MODIFYBY()
		};
		this.updateBySQL(sql, params);
	}

	@Override
	public void deleteFirmSettingById(Integer id) {
		String sql = this.sqlProperty.getProperty("FirmDAO_042");
		Object[] params = {id};
		this.updateBySQL(sql, params);
	}

	@Override
	public void updateFirmSettingById(FirmSetting firmSetting) {
		String sql = this.sqlProperty.getProperty("FirmDAO_043");
		Object[] params = {firmSetting.getRemark(),firmSetting.getDISABLED(),
				firmSetting.getREC_MODIFYBY(),firmSetting.getId()};
		this.updateBySQL(sql, params);
	}
	
	@Override
	public int getFirmRegisterFirmStatus(String firmRegId) {
		String sql = "select FirmStatus From C_FirmRegister where FirmRegId='"+firmRegId+"'";
		int firmStatus = this.queryForInt(sql);
		return firmStatus;
	}

	@Override
	public List<FirmPositionLimitModel> getFirmPositionLimit(
			QueryConditions qc, PageInfo pageInfo,String limit) {
		List<FirmPositionLimitModel> list = null;
		String sql;
		if(("1").equals(limit)){//无限制
			sql = this.sqlProperty.getProperty("FirmDAO_044")+"AND temp.firmID NOT IN (SELECT FirmID FROM T_FirmPositionLimit)";
		}else if(("0").equals(limit)){//有限制
			sql = this.sqlProperty.getProperty("FirmDAO_044")+"AND temp.firmID IN (SELECT FirmID FROM T_FirmPositionLimit)";
		}else {
			sql = this.sqlProperty.getProperty("FirmDAO_044");
		}
		try {
			list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new FirmPositionLimitModel()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
	}
	public List<FirmPositionLimitModel> getFirmPositionLimitByTradeType(
			QueryConditions qc, PageInfo pageInfo) {
		List<FirmPositionLimitModel> list = null;
		String sql;
		sql = this.sqlProperty.getProperty("FirmDAO_047");		
		try {
			String groupByStr = " GROUP BY t.FirmID,t.FirmName ";
			list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new FirmPositionLimitModel()),groupByStr);
		} catch (Exception e) {
			e.printStackTrace();
		}		
		return list;
	}
	
	@Override
	public List<FirmPositionLimitModel> getFirmPositionLimitByFirmID(String firmId) {
		String sql = this.sqlProperty.getProperty("FirmDAO_045");
		List<FirmPositionLimitModel> list;
		Object [] params = {
				firmId
		};
		list = this.queryBySQL(sql, params, null, new CommonRowMapper(new FirmPositionLimitModel()));
		return list;
	}
	
	@Override
	public int updateFirmPositionLimitByFirmID(
			FirmPositionLimitModel firmPositionLimitModel, String userName,
			String firmID) {
		String sql = "update T_FirmPositionLimit set PositionLimitType ="+firmPositionLimitModel.getPositionLimitType()+"";
		return 0;
	}
	
	@Override
	public int deleteeFirmPositionLimitModelByFirmID(String firmID) {
		String sql = "delete from T_FirmPositionLimit where FirmID='"+firmID+"'";
		int returnCode;
		try {
			Object [] params ={};
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public int addFirmPositionLimitModel(
			FirmPositionLimitModel firmPositionLimitModel, String userName,
			String firmID) {
		String sql = this.sqlProperty.getProperty("FirmDAO_046");
		BigDecimal positionLimitValue;
		if(firmPositionLimitModel.getPositionLimitType() == 0){
			positionLimitValue = new BigDecimal(new java.text.DecimalFormat("#.00").format(firmPositionLimitModel.getPositionLimitValue()));
		}else {
			positionLimitValue = firmPositionLimitModel.getPositionLimitValue();
		}
		Object [] params = {
					firmID,
				firmPositionLimitModel.getGoodsType(),//货品类型，0：现货 1：预售
				firmPositionLimitModel.getPositionLimitType(),//限额类型，0：按金额   1：按重量
				positionLimitValue,//限额:吨6位小数  价格2位小数
				0,
				userName,
				userName,
				firmPositionLimitModel.getGoodsType()
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public List<FirmAllData> getIsNotRelationFrimListForShop(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug(this.getClass().getName()+"getIsNotRelationFrimListForShop DAO Start");
		String sql = this.sqlProperty.getProperty("ShopDAO_005");
		List<FirmAllData> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new FirmAllData()));
		this.log.debug(this.getClass().getName()+"getIsNotRelationFrimListForShop DAO End");
		return list;
	}

	@Override
	public int insertShopFirm(ShopFirm shopFirm) {
		String sql = this.sqlProperty.getProperty("ShopFirmDAO_001");
		Object[] params = {shopFirm.getShopID(),
				shopFirm.getFirmID(),
				shopFirm.getIsMainFirm(),
				shopFirm.getRemark(),
				0,
				shopFirm.getREC_CREATEBY(),
				shopFirm.getREC_MODIFYBY()};
		return this.updateBySQL(sql, params);
	}

	@Override
	public int countRelationShopFrim(String firmId) {
		String sql = this.sqlProperty.getProperty("ShopFirmDAO_002");
		Object[] params = {firmId};
		return this.queryForInt(sql, params);
	}

	@Override
	public int deleteShopFirmByShopId(Integer shopId, Integer isMainFirm) {
		String sql = this.sqlProperty.getProperty("ShopFirmDAO_003");
		Object[] params = {shopId,isMainFirm};
		return this.updateBySQL(sql, params);
	}

	@Override
	public List<ShopFirm> selectShopFirmListByShopID(QueryConditions qc,PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("ShopFirmDAO_004");
		return this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new ShopFirm()));
	}

	@Override
	public int updateShopOfDisabled(int shopId, int disabled) {
		String sql = this.sqlProperty.getProperty("ShopDAO_006");
		Object[] params = {disabled,shopId};
		return this.updateBySQL(sql, params);
	}
	
	@Override
	public BigDecimal getLeadsQuantity(String firmID,int goodsType) {
		String sql = "SELECT SUM(Quantity*TradeUnitNumber) as stock_saleVolume FROM T_Leads WHERE FirmId = '"+firmID+"' and Direction = 0 and GoodsType ="+goodsType+" "
				+ " and PaymentStatus = 1 and LeadsStatus =0  GROUP BY FirmId";
		FirmPositionLimitModel firmPositionLimitModel = (FirmPositionLimitModel) this.queryForObject(sql, null, new CommonRowMapper(new FirmPositionLimitModel()));
		if(firmPositionLimitModel == null){
			return new BigDecimal(0);
		}else {
			return firmPositionLimitModel.getStock_saleVolume();
		}
	}
	
	@Override
	public BigDecimal getLeadsMonet(String firmID,int goodsType) {
		String sql = "SELECT SUM(Quantity*TradeUnitNumber*Price) as stock_saleMoney FROM T_Leads WHERE FirmId = '"+firmID+"'and Direction = 0 and GoodsType ="+goodsType+" "
				+ "and PaymentStatus = 1 and LeadsStatus =0    GROUP BY FirmId";
		FirmPositionLimitModel firmPositionLimitModel = (FirmPositionLimitModel) this.queryForObject(sql, null, new CommonRowMapper(new FirmPositionLimitModel()));
		if(firmPositionLimitModel == null){
			return new BigDecimal(0);
		}else {
			return firmPositionLimitModel.getStock_saleMoney();
		}
	}
	
	@Override
	public ValueTxtView getBankObj(Integer vatBankID) {
		String sql ="select t.BankID as value,t.BankName as text from VW_Bank t where t.BankID="+vatBankID;
		Object [] params = {
				
		};
		ValueTxtView bankObj = (ValueTxtView) this.queryForObject(sql, params, new CommonRowMapper(new ValueTxtView()));
		return bankObj;
	}
	
	@Override
	public ValueTxtView getBankAddRessObj(Integer vatID) {
		String sql ="select FullName as text from VW_Canton  where ID="+vatID;
		Object [] params = {
				
		};
		ValueTxtView addRessObj = (ValueTxtView) this.queryForObject(sql, params, new CommonRowMapper(new ValueTxtView()));
		return addRessObj;
	}
}
