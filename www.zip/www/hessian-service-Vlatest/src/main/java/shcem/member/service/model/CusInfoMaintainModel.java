package shcem.member.service.model;

import shcem.base.dao.model.BaseObject;

public class CusInfoMaintainModel extends BaseObject implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7640161984718349508L;
	private String mobile;
	private String userName;
	private String id;
	private String userCode;
	private String firmName;
	private String contactTelNo;
	private Integer businessType;
	private String fax;
	private Integer addressPV;
	private Integer addressCT;
	private Integer addressDT;
	private String address;
	private String postCode;
	private String remark;
	private Integer userSource;
	private String otherRemark;
	private Integer userStatus;
	private Integer maintainStatus;
	private Integer isDanger;
	private Integer tradeAuthority;
	private Integer disabled;
	
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getFirmName() {
		return firmName;
	}
	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}
	public String getContactTelNo() {
		return contactTelNo;
	}
	public void setContactTelNo(String contactTelNo) {
		this.contactTelNo = contactTelNo;
	}
	public Integer getBusinessType() {
		return businessType;
	}
	public void setBusinessType(Integer businessType) {
		this.businessType = businessType;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public Integer getAddressPV() {
		return addressPV;
	}
	public void setAddressPV(Integer addressPV) {
		this.addressPV = addressPV;
	}
	public Integer getAddressCT() {
		return addressCT;
	}
	public void setAddressCT(Integer addressCT) {
		this.addressCT = addressCT;
	}
	public Integer getAddressDT() {
		return addressDT;
	}
	public void setAddressDT(Integer addressDT) {
		this.addressDT = addressDT;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Integer getUserSource() {
		return userSource;
	}
	public void setUserSource(Integer userSource) {
		this.userSource = userSource;
	}
	public String getOtherRemark() {
		return otherRemark;
	}
	public void setOtherRemark(String otherRemark) {
		this.otherRemark = otherRemark;
	}
	public Integer getUserStatus() {
		return userStatus;
	}
	public void setUserStatus(Integer userStatus) {
		this.userStatus = userStatus;
	}
	public Integer getMaintainStatus() {
		return maintainStatus;
	}
	public void setMaintainStatus(Integer maintainStatus) {
		this.maintainStatus = maintainStatus;
	}
	public Integer getIsDanger() {
		return isDanger;
	}
	public void setIsDanger(Integer isDanger) {
		this.isDanger = isDanger;
	}
	public Integer getTradeAuthority() {
		return tradeAuthority;
	}
	public void setTradeAuthority(Integer tradeAuthority) {
		this.tradeAuthority = tradeAuthority;
	}

	public Integer getDisabled() {
		return disabled;
	}
	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	
}
