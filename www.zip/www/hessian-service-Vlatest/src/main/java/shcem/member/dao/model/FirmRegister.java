/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmRegister
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.dao.model;

import java.util.Date;
import java.util.List;

import shcem.base.dao.model.BaseObject;

/**
 * (C_FIRMREGISTER)
 * 交易商注册信息
 * @author bianj
 * @version 1.0.0 2016-05-20
 */
public class FirmRegister extends BaseObject implements java.io.Serializable {
    /** 版本号 */
    private static final long serialVersionUID = 7026145037114339902L;
    
    /**  */
    private String firmRegId;
    
    /**  */
    private String firmName;
    
    /**  */
    private String fullName;
    
    /**  */
    private Integer firmType;
    
    /**  */
    private Integer businessType;
    
    /**  */
    private Integer disabled;
    
    /**  */
    private Integer firmStatus;
    
    /**  */
    private String address;
    private Integer addressPV;
    private Integer addressCT;
    private Integer addressDT;
    
    private String addressPVName;
    private String addressCTName;
    private String addressDTName;
    
	/**  */
    private String fax;
    
    /**  */
    private String postCode;
    
    /**  */
    private String contactName;
    
    /**  */
    private String contactTelNo;
    
    /**  */
    private String contactMobile;
    
    /**  */
    private Integer bSLicense;
    
    /**  */
    private Integer taxLicense;
    
    /**  */
    private Integer orgCode;
    
    /**  */
    private Integer unifyLicense;
    
    /**  */
    private Integer dGLicense;
    
    /**  */
    private Integer settingBankID;
    /**  */
    private String settingBkBranch;
    
    /**  */
    private String settingBkAccount;
    
    /**  */
    private Integer vatBankID;
    
    private String vatBankName;
    
    /**  */
    private String vatBkBranch;
    
    /**  */
    private String vatBkAccount;
    
    /**  */
    private Integer vatPV;
    
    /**  */
    private Integer vatCT;
    
    /**  */
    private Integer vatDT;
    
    /**  */
    private String vatPVName;
    
    /**  */
    private String vatCTName;
    
    /**  */
    private String vatDTName;
    
    /**  */
    private String vatAddress;
    
    /**  */
    private String taxNo;
    
    /**  */
    private String vatContactTelNo;
    
    /**  */
    private Integer recPV;
    
    /**  */
    private Integer recCT;
    
    /**  */
    private Integer recDT;
    
    /**  */
    private String recPVName;
    
    /**  */
    private String recCTName;
    
    /**  */
    private String recDTName;
    
    /**  */
    private String recAddRess;
    
    /**  */
    private String recContactName;
    
    /**  */
    private String recContactTelNo;
    
    /**  */
    private String recCreateby;
    
    /**  */
    private Date recCreateTime;
    
    /**  */
    private String recModifyby;
    
    /**  */
    private Date recModifyTime;
    
    //拓展属性
    private String firmID;
    
    //申请人认证
    private String requestUserId;
    
    //证照区分
    private Integer licenseDiffer;
    /**
     * 结算银行
     * @return
     */
    private String settingBankName;
    //是否银商绑定
    private Integer isBinding;
    //驳回理由
    private String rejectReason;
    //是否金石湾危化  0:否，1:是
    private Integer isDanger;
    
    // 账户买卖标识 0：卖，1：买 2：全部
    private Integer tradeAuthority;
    // 营业执照号码
    private String bSLicenseNo;
    // 组织机构代码
    private String organizationCd;
    // 注册资金
    private String registerCapital;
    // 企业法人姓名	
    private String bSEntityName;
    // 企业法人电话
    private String bSEntityTelNo;
    // 危化品有效期
    private Date dGExpireDate;
    // 联系邮箱
    private String contactEmail;
    // 注册交易商交易场关系
    private List<FirmRegTmptRlsp> firmTmptRlspList;
    
    private String unifyLicenseNo;
    private String dGLicenseNo;
    private String taxRegisterNo;
    private String dGLicenseAuth;
    
	private Integer dISABLED;
	private String rEC_CREATEBY;
	private Date rEC_CREATETIME;
	private String rEC_MODIFYBY;
	private Date rEC_MODIFYTIME;
    
    public Integer getDISABLED() {
		return dISABLED;
	}

	public void setDISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	public String getAddressPVName() {
		return addressPVName;
	}

	public void setAddressPVName(String addressPVName) {
		this.addressPVName = addressPVName;
	}

	public String getAddressCTName() {
		return addressCTName;
	}

	public void setAddressCTName(String addressCTName) {
		this.addressCTName = addressCTName;
	}

	public String getAddressDTName() {
		return addressDTName;
	}

	public void setAddressDTName(String addressDTName) {
		this.addressDTName = addressDTName;
	}

	public String getVatPVName() {
		return vatPVName;
	}

	public void setVatPVName(String vatPVName) {
		this.vatPVName = vatPVName;
	}

	public String getVatCTName() {
		return vatCTName;
	}

	public void setVatCTName(String vatCTName) {
		this.vatCTName = vatCTName;
	}

	public String getVatDTName() {
		return vatDTName;
	}

	public void setVatDTName(String vatDTName) {
		this.vatDTName = vatDTName;
	}

	public String getRecPVName() {
		return recPVName;
	}

	public void setRecPVName(String recPVName) {
		this.recPVName = recPVName;
	}

	public String getRecCTName() {
		return recCTName;
	}

	public void setRecCTName(String recCTName) {
		this.recCTName = recCTName;
	}

	public String getRecDTName() {
		return recDTName;
	}

	public void setRecDTName(String recDTName) {
		this.recDTName = recDTName;
	}

	public String getUnifyLicenseNo() {
		return unifyLicenseNo;
	}

	public void setUnifyLicenseNo(String unifyLicenseNo) {
		this.unifyLicenseNo = unifyLicenseNo;
	}

	public String getDGLicenseNo() {
		return dGLicenseNo;
	}

	public void setDGLicenseNo(String dGLicenseNo) {
		this.dGLicenseNo = dGLicenseNo;
	}

	public String getTaxRegisterNo() {
		return taxRegisterNo;
	}

	public void setTaxRegisterNo(String taxRegisterNo) {
		this.taxRegisterNo = taxRegisterNo;
	}

	public String getDGLicenseAuth() {
		return dGLicenseAuth;
	}

	public void setDGLicenseAuth(String dGLicenseAuth) {
		this.dGLicenseAuth = dGLicenseAuth;
	}

	public List<FirmRegTmptRlsp> getFirmTmptRlspList() {
		return firmTmptRlspList;
	}

	public void setFirmTmptRlspList(List<FirmRegTmptRlsp> firmTmptRlspList) {
		this.firmTmptRlspList = firmTmptRlspList;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public Integer getbSLicense() {
		return bSLicense;
	}

	public void setbSLicense(Integer bSLicense) {
		this.bSLicense = bSLicense;
	}

	public Integer getTradeAuthority() {
		return tradeAuthority;
	}

	public void setTradeAuthority(Integer tradeAuthority) {
		this.tradeAuthority = tradeAuthority;
	}

	public String getBSLicenseNo() {
		return bSLicenseNo;
	}

	public void setBSLicenseNo(String bSLicenseNo) {
		this.bSLicenseNo = bSLicenseNo;
	}

	public String getOrganizationCd() {
		return organizationCd;
	}

	public void setOrganizationCd(String organizationCd) {
		this.organizationCd = organizationCd;
	}

	public String getRegisterCapital() {
		return registerCapital;
	}

	public void setRegisterCapital(String registerCapital) {
		this.registerCapital = registerCapital;
	}

	public String getBSEntityName() {
		return bSEntityName;
	}

	public void setBSEntityName(String bSEntityName) {
		this.bSEntityName = bSEntityName;
	}

	public String getBSEntityTelNo() {
		return bSEntityTelNo;
	}

	public void setBSEntityTelNo(String bSEntityTelNo) {
		this.bSEntityTelNo = bSEntityTelNo;
	}

	public Date getDGExpireDate() {
		return dGExpireDate;
	}

	public void setDGExpireDate(Date dGExpireDate) {
		this.dGExpireDate = dGExpireDate;
	}

	public Integer getAddressPV() {
		return addressPV;
	}

	public void setAddressPV(Integer addressPV) {
		this.addressPV = addressPV;
	}

	public Integer getAddressDT() {
		return addressDT;
	}

	public void setAddressDT(Integer addressDT) {
		this.addressDT = addressDT;
	}

	public Integer getLicenseDiffer() {
		return licenseDiffer;
	}

	public void setLicenseDiffer(Integer licenseDiffer) {
		this.licenseDiffer = licenseDiffer;
	}

	public String getFirmRegId() {
		return firmRegId;
	}

	public void setFirmRegId(String firmRegId) {
		this.firmRegId = firmRegId;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Integer getFirmType() {
		return firmType;
	}

	public void setFirmType(Integer firmType) {
		this.firmType = firmType;
	}

	public Integer getBusinessType() {
		return businessType;
	}

	public void setBusinessType(Integer businessType) {
		this.businessType = businessType;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public Integer getFirmStatus() {
		return firmStatus;
	}

	public void setFirmStatus(Integer firmStatus) {
		this.firmStatus = firmStatus;
	}


	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactTelNo() {
		return contactTelNo;
	}

	public void setContactTelNo(String contactTelNo) {
		this.contactTelNo = contactTelNo;
	}

	public String getContactMobile() {
		return contactMobile;
	}

	public void setContactMobile(String contactMobile) {
		this.contactMobile = contactMobile;
	}

	public Integer getBSLicense() {
		return bSLicense;
	}

	public void setBSLicense(Integer bSlicense) {
		this.bSLicense = bSlicense;
	}

	public Integer getTaxLicense() {
		return taxLicense;
	}

	public void setTaxLicense(Integer taxLicense) {
		this.taxLicense = taxLicense;
	}

	public Integer getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(Integer orgCode) {
		this.orgCode = orgCode;
	}

	public Integer getUnifyLicense() {
		return unifyLicense;
	}

	public void setUnifyLicense(Integer unifyLicense) {
		this.unifyLicense = unifyLicense;
	}

	public Integer getDGLicense() {
		return dGLicense;
	}

	public void setDGLicense(Integer dGLicense) {
		this.dGLicense = dGLicense;
	}

	public Integer getSettingBankID() {
		return settingBankID;
	}

	public void setSettingBankID(Integer settingBankID) {
		this.settingBankID = settingBankID;
	}

	public String getSettingBkBranch() {
		return settingBkBranch;
	}

	public void setSettingBkBranch(String settingBkBranch) {
		this.settingBkBranch = settingBkBranch;
	}

	public String getSettingBkAccount() {
		return settingBkAccount;
	}

	public void setSettingBkAccount(String settingBkAccount) {
		this.settingBkAccount = settingBkAccount;
	}

	public Integer getVatBankID() {
		return vatBankID;
	}

	public void setVatBankID(Integer vatBankID) {
		this.vatBankID = vatBankID;
	}

	public String getVatBkBranch() {
		return vatBkBranch;
	}

	public void setVatBkBranch(String vatBkBranch) {
		this.vatBkBranch = vatBkBranch;
	}

	public String getVatBkAccount() {
		return vatBkAccount;
	}

	public void setVatBkAccount(String vatBkAccount) {
		this.vatBkAccount = vatBkAccount;
	}

	public Integer getVatPV() {
		return vatPV;
	}

	public void setVatPV(Integer vatPV) {
		this.vatPV = vatPV;
	}

	public Integer getVatCT() {
		return vatCT;
	}

	public void setVatCT(Integer vatCT) {
		this.vatCT = vatCT;
	}

	public Integer getVatDT() {
		return vatDT;
	}

	public void setVatDT(Integer vatDT) {
		this.vatDT = vatDT;
	}

	
	public String getVatAddress() {
		return vatAddress;
	}

	public void setVatAddress(String vatAddress) {
		this.vatAddress = vatAddress;
	}

	public String getTaxNo() {
		return taxNo;
	}

	public void setTaxNo(String taxNo) {
		this.taxNo = taxNo;
	}

	public Integer getRecPV() {
		return recPV;
	}

	public void setRecPV(Integer recPV) {
		this.recPV = recPV;
	}

	public Integer getRecCT() {
		return recCT;
	}

	public void setRecCT(Integer recCT) {
		this.recCT = recCT;
	}

	public Integer getRecDT() {
		return recDT;
	}

	public void setRecDT(Integer recDT) {
		this.recDT = recDT;
	}

	public String getRecAddRess() {
		return recAddRess;
	}

	public void setRecAddRess(String recAddRess) {
		this.recAddRess = recAddRess;
	}

	public String getRecContactName() {
		return recContactName;
	}

	public void setRecContactName(String recContactName) {
		this.recContactName = recContactName;
	}

	public String getRecContactTelNo() {
		return recContactTelNo;
	}

	public void setRecContactTelNo(String recContactTelNo) {
		this.recContactTelNo = recContactTelNo;
	}

	public String getRecCreateby() {
		return recCreateby;
	}

	public void setRecCreateby(String recCreateby) {
		this.recCreateby = recCreateby;
	}

	public Date getRecCreateTime() {
		return recCreateTime;
	}

	public void setRecCreateTime(Date recCreateTime) {
		this.recCreateTime = recCreateTime;
	}

	public String getRecModifyby() {
		return recModifyby;
	}

	public void setRecModifyby(String recModifyby) {
		this.recModifyby = recModifyby;
	}

	public Date getRecModifyTime() {
		return recModifyTime;
	}

	public void setRecModifyTime(Date recModifyTime) {
		this.recModifyTime = recModifyTime;
	}
	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getRequestUserId() {
		return requestUserId;
	}

	public void setRequestUserId(String requestUserId) {
		this.requestUserId = requestUserId;
	}

	public Integer getAddressCT() {
		return addressCT;
	}

	public void setAddressCT(Integer addressCT) {
		this.addressCT = addressCT;
	}

	public String getSettingBankName() {
		return settingBankName;
	}

	public void setSettingBankName(String settingBankName) {
		this.settingBankName = settingBankName;
	}

	public Integer getIsBinding() {
		return isBinding;
	}

	public void setIsBinding(Integer isBinding) {
		this.isBinding = isBinding;
	}

	public String getRejectReason() {
		return rejectReason;
	}

	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}

	public String getVatBankName() {
		return vatBankName;
	}

	public void setVatBankName(String vatBankName) {
		this.vatBankName = vatBankName;
	}

	public String getVatContactTelNo() {
		return vatContactTelNo;
	}

	public void setVatContactTelNo(String vatContactTelNo) {
		this.vatContactTelNo = vatContactTelNo;
	}

	public Integer getIsDanger() {
		return isDanger;
	}

	public void setIsDanger(Integer isDanger) {
		this.isDanger = isDanger;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}


}