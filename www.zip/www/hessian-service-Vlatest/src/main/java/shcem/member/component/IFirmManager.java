/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IFirmManager
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.component;

import java.util.List;

import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.member.dao.FirmDAO;
import shcem.member.dao.model.*;

/**
 * @author wlpod
 *
 */
public interface IFirmManager {
	
	public abstract void setFirmDAO(FirmDAO paramFirmDAO);
	/**
	 * 
	 * @param qc 
	 * @param pageInfo 
	 * @return List<Firm>
	 */
	public abstract List<FirmDataList> getFirmList(QueryConditions qc, PageInfo pageInfo);

	/**
	 *
	 * 
	 * @param firmId
	 * @return Firm
	 */
	public abstract FirmAllData getFirm(String firmId);
	/**修改交易商信息
	 * 2016年5月17日 下午4:34:08
	 * @param firmDetaiData
	 * @param firmTmptRlsps 
	 * @param userID 
	 * @param mode 
	 * @param userName 
	 * @return
	 * 张楠/Nany
	 */
	public abstract int updateFirm(FirmDetaiData firmDetaiData, int[] firmTmptRlsps, String userID, String userName, String mode, String requestId);
	/**新增交易商信息
	 * 2016年5月17日 下午5:56:48
	 * @param firmTmptRlsps 
	 * @param userID 
	 * @param firmDetail
	 * @return
	 * 张楠/Nany
	 */
	public abstract int addFirm(FirmDetaiData firmDetaiData, int[] firmTmptRlsps, String userID);
	/**
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<FirmRegister> getRegisteredFirmList(
			QueryConditions qc, PageInfo pageInfo);
	/**获取交易商详细注册信息
	 * 2016年5月17日 下午5:56:48
	 * @param firmDetail
	 * @return
	 * 张楠/Nany
	 */
	public abstract FirmRegister getRegisteredFirmDetail(String firmRegId);
	/**禁用交易商
	 * @param firmID
	 * @param disabled 
	 * @return 
	 */
	public abstract int updateFirmDisabled(String firmID, int disabled);
	public abstract int getTotalRegisteredFirmList(QueryConditions qc);
	public abstract void rejectRegisteredFirm(String firmRegId, String note);
	public abstract List<FirmAllData> getFirmByFirmName(String firmName);
	public abstract List<Trader> getTrader(String traderID);
	public abstract List<FirmAllData> getFirmByFullName(String fullName);
	public abstract String GetNewFirmIDByZone(String zoneNum);
	public abstract void updateFirmIDPoolIsUsed(String firmID);
	public abstract int updateFirmRegister(FirmRegister firmRegister, boolean approved, Object approvedTemp);
	/**
	 * 交易商邮寄地址
	 * @param pageInfo
	 * @param firmID
	 * @return
	 */
	public abstract List<RecAddRess> getFirmRecAddressList(PageInfo pageInfo,
			String firmID);
	public abstract void addRecAddress(RecAddRess recAddress);
	public abstract void delAddressList(int[] recAddressIDs);
	public abstract RecAddRess getFirmRecAddressByID(int recAddressID);
	public abstract void updateRecAddress(RecAddRess recAddress);
	public abstract void disabledRecAddress(int recAddressID, int disabled);
	public abstract int synchronizeFrim(FirmDetaiData firmDetaiData,
			int[] firmTmptRlsps, String userID);
	
	/**
	 * 添加 交易商注册信息
	 * @param firmRegister
	 */
	public abstract void insertFirmRegister(FirmRegister firmRegister,List<FirmRegTmptRlsp> list);
	
	/**
	 * 根据 FirmRegId 查询 注册交易商交易场关系列表
	 * @param firmRegister
	 */
	public abstract List<FirmRegTmptRlsp> selectFirmRegTmptRlspByFirmRegId(String firmRegId);
	
	/**
	 * 根据 FirmRegId 删除 注册交易商交易场关系列表
	 * @param firmRegister
	 */
	public abstract void deleteFirmRegTmptRlspByFirmRegId(String firmRegId);
	
	/**
	 * 更新 交易商 的审核 状态
	 * @param firmId
	 * @param firmStatus
	 */
	public abstract int updateCFirmOfFirmStatus(String firmId,String username, Integer firmStatus);

	/**
	 * 根据条件查询商铺视图
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<Shop> selectShopByParam(QueryConditions qc, PageInfo pageInfo);

	/**
	 *添加商铺
	 * @param shop
	 */
	public abstract int insertShop(Shop shop);

	/**
	 * 更新商铺
	 * @param shop
	 */
	public abstract int updateShop(Shop shop);

	/**
	 * 根据商铺id获得商铺信息
	 * @param shopId
	 * @return
	 */
	public abstract Shop getById(String shopId);
	
	/**
	 * 插入交易商设置表
	 * @param params
	 * @return
	 */
	public abstract void insertFirmSetting(FirmSetting firmSetting);
	
	/**
	 * 删除交易商设置表
	 * @param params
	 * @return
	 */
	public abstract void deleteFirmSettingById(Integer id);
	
	/**
	 * 更新交易商设置表
	 * @param params
	 * @return
	 */
	public abstract void updateFirmSettingById(FirmSetting firmSetting);
	/**
	 * 交易商销售配置列表
	 * @param qc
	 * @param pageInfo
	 * @param limit 
	 * @return
	 */
	public abstract List<FirmPositionLimitModel> getFirmPositionLimit(
			QueryConditions qc, PageInfo pageInfo, String limit);
	/**
	 * 交易商销售配置详情
	 * @param firmId
	 * @return
	 */
	public abstract List<FirmPositionLimitModel> getFirmPositionLimitByFirmID(
			String firmId);
	/**
	 * 更新交易商销售配置详情
	 * @param list
	 * @param userName
	 * @return
	 */
	public abstract int updateFirmPositionLimitByFirmID(
			List<FirmPositionLimitModel> list, String userName,String firmID);
	
	/**
	 * 获取未被关联过的交易商列表(商铺用)
	 * @param params
	 * @return
	 */
	public List<FirmAllData> getIsNotRelationFrimListForShop(QueryConditions qc,PageInfo pageInfo);
	
	/**
	 * 通过店铺ID关联的交易商
	 * @param params
	 * @return
	 */
	public List<ShopFirm> selectShopFirmListByShopID(QueryConditions qc,PageInfo pageInfo);
	
	/**
	 * 更新商铺表 禁用状态
	 * @param params
	 * @return
	 */
	public int updateShopOfDisabled(int shopId,int disabled);
	/**
	 * 获取交易商限额配置
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public List<FirmPositionLimitModel> getFirmPositionLimitByTradeType(
			QueryConditions qc, PageInfo pageInfo);
}
