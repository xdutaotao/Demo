/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmDAO
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.dao;

import java.math.BigDecimal;
import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.service.model.ValueTxtView;
import shcem.member.dao.model.FirmAllData;
import shcem.member.dao.model.FirmApp;
import shcem.member.dao.model.FirmDataList;
import shcem.member.dao.model.FirmDetail;
import shcem.member.dao.model.FirmPositionLimitModel;
import shcem.member.dao.model.FirmRegTmptRlsp;
import shcem.member.dao.model.FirmRegister;
import shcem.member.dao.model.FirmSetting;
import shcem.member.dao.model.FirmTmptRlsp;
import shcem.member.dao.model.Firmvatinfo;
import shcem.member.dao.model.RecAddRess;
import shcem.member.dao.model.Shop;
import shcem.member.dao.model.ShopFirm;
import shcem.member.dao.model.Trader;
import shcem.member.dao.model.VatAddRess;

/**
 * @author wlpod
 *
 */
public abstract interface FirmDAO extends DAO {
	/**
	 * 
	 * @return List<Firm>
	 */
	public abstract List<FirmDataList> getFirmList(QueryConditions qc,PageInfo pageInfo);
	/**
	 * 
	 * @param firmId
	 * @return Firm
	 */
	public abstract FirmAllData getFirm(String firmId);
	/**新增交易上信息(主表)
	 * 2016年5月17日 下午5:57:40
	 * @param firmDetail
	 * @return
	 * 张楠/Nany
	 */
	public abstract int addFirm(FirmDetail firmDetail);
	/**新增交易上信息(详细表)
	 * 2016年5月17日 下午5:57:40
	 * @param firmDetail
	 * @return
	 * 张楠/Nany
	 */
	public abstract int addFirmDetail(FirmDetail firmDetail);
	/**修改交易商主表信息
	 * 2016年5月17日 下午4:35:15
	 * @param firmDetail
	 * @return
	 * 张楠/Nany
	 */
	public abstract int updateFirm(FirmDetail firmDetail);
	/**修改交易商详细信息
	 * 2016年5月17日 下午4:35:15
	 * @param firmDetail
	 * @return
	 * 张楠/Nany
	 */
	public abstract int updateFirmDetail(FirmDetail firmDetail);
	/**
	 * @return
	 */
	public abstract List<FirmRegister> getRegisteredFirmList(QueryConditions qc,
			PageInfo pageInfo);
	
	public abstract FirmRegister getRegisteredFirmDetail(String firmRegId);
	/**交易商收票地址
	 * @param recAddRessBean
	 * @return
	 */
	public abstract int addFirmRecAddRess(RecAddRess recAddRessBean);
	/**交易商接收地址信息(中间表)
	 * @param firminvoice
	 * @return
	 */
	public abstract int addFirmInvoice(String FirmID, int addressID,int addressType);
	/**交易商开票地址
	 * @param vatAddRessBean
	 * @return
	 */
	public abstract int addFirmVatAddRess(VatAddRess vatAddRessBean);
	/**交易商增值税开票信息
	 * @param firmvatinfo
	 * @return
	 */
	public abstract int addFirmVATInfo(Firmvatinfo firmvatinfo);
	/**交易商注册信息审核通过
	 * @param firmRegId 
	 * @return
	 */
	public abstract int updateFirmRegister(String firmRegId);
	/**收货/收票地址
	 * @param FirmID
	 * @return
	 */
	public abstract List<RecAddRess> queryRecAddRess(String firmID);
	/**更新增值税开票信息
	 * @param vatAddRess
	 * @return
	 */
	public abstract int updateFirmvatinfo(VatAddRess vatAddRess,String firmID);
	/**更新交易商增值税开票地址信息
	 * @param vatAddRessBean
	 * @return
	 */
	public abstract int updateFirmVatAddRess(VatAddRess vatAddRessBean);
	/**取得交易商开票信息
	 * @param firmID
	 * @return
	 */
	public abstract Firmvatinfo queryFirmvatinfo(String firmID);
	/**禁用交易商
	 * @param firmID
	 * @param disabled 
	 * @return 
	 */
	public abstract int updateFirmDisabled(String firmID, int disabled);
	public abstract int getTotalRegisteredFirmList(QueryConditions qc);
	public abstract void rejectRegisteredFirm(String firmRegId, String note);
	public abstract List<FirmAllData> getFirmByFirmName(String firmName);
	/**交易场
	 * @param firmId
	 * @return
	 */
	public abstract List<FirmTmptRlsp> getFirmTmptRlspList(String firmId);
	public abstract void addFirmTmptRlsps(FirmTmptRlsp firmTmptRlsp);
	/**删除某个交易商的交易场权限
	 * @param firmID
	 */
	public abstract void delFirmTmptRlsps(String firmID);
	public abstract List<Trader> getTrader(String traderID);
	public abstract int getTotalTraderNum(String firmID);
	public abstract List<FirmAllData> getFirmByFullName(String fullName);
	/**
	 * 交易商开票信息
	 * @param firmId
	 * @return
	 */
	public abstract List<VatAddRess> getAddRessList(String firmId);
	public abstract int updateFirmvatinfo(Firmvatinfo firmvatinfo);
	public abstract void rollBack();
	public abstract String GetNewFirmIDByZone(String zoneNum);
	public abstract void updateFirmIDPoolIsUsed(String firmID);
	public abstract void deleteFirmvatinfo(String firmID);
	public abstract int updateFirmRegisterDetail(FirmRegister firmRegister);
	public abstract List<RecAddRess> getFirmRecAddressList(PageInfo pageInfo,
			String firmID);
	public abstract int addRecAddress(RecAddRess recAddress);
	public abstract void delAddressList(String addressIDs);
	public abstract RecAddRess getFirmRecAddressByID(int recAddressID);
	public abstract void updateRecAddress(RecAddRess recAddress);
	public abstract void updateFirmInvoice(Integer recAddressID,
			Integer addressType);
	public abstract void disabledRecAddress(int recAddressID,int disabled);
	public abstract void addFirmApp(String firmID, Integer appType,
			String userName);
	public abstract List<FirmApp> getFirmAppByParam(String firmID,
			Integer appType);
	
	/**
	 * 添加 交易商注册信息
	 * @param firmRegister
	 */
	public abstract String insertFirmRegister(FirmRegister firmRegister);
	
	
	/**
	 * 添加 注册交易商交易场关系表
	 * @param firmRegister
	 */
	public abstract void insertFirmRegTmptRlsp(List<FirmRegTmptRlsp> list);	
	
	/**
	 * 根据 FirmRegId 查询 注册交易商交易场关系列表
	 * @param firmRegister
	 */
	public abstract List<FirmRegTmptRlsp> selectFirmRegTmptRlspByFirmRegId(String firmRegId);
	
	/**
	 * 根据 FirmRegId 删除 注册交易商交易场关系列表
	 * @param firmRegister
	 */
	public abstract void deleteFirmRegTmptRlspByFirmRegId(String firmRegId);
	
	/**
	 * 更新 交易商 的审核 状态
	 * @param firmId
	 * @param firmStatus
	 */
	public abstract int updateCFirmOfFirmStatus(String firmId,String username, Integer firmStatus);

	/**
	 * 根据条件查询商铺视图
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<Shop> selectShopByParam(QueryConditions qc,PageInfo pageInfo);

	/**
	 *添加商铺
	 * @param shop
	 */
	public abstract int insertShop(Shop shop);

	/**
	 * 更新商铺
	 * @param shop
	 */
	public abstract int updateShop(Shop shop);

	/**
	 * 根据商铺id获得商铺信息
	 * @param shopId
	 * @return
	 */
	public abstract Shop getById(String shopId);
	
	/**
	 * 插入交易商设置表
	 * @param params
	 * @return
	 */
	public abstract void insertFirmSetting(FirmSetting firmSetting);
	
	/**
	 * 删除交易商设置表
	 * @param params
	 * @return
	 */
	public abstract void deleteFirmSettingById(Integer id);
	
	/**
	 * 更新交易商设置表
	 * @param params
	 * @return
	 */
	public abstract void updateFirmSettingById(FirmSetting firmSetting);
	public abstract int refuseFirmRegister(String firmRegId, String rejectReason);
	public abstract int getFirmRegisterFirmStatus(String firmRegId);
	public abstract List<FirmPositionLimitModel> getFirmPositionLimit(
			QueryConditions qc, PageInfo pageInfo, String limit);
	public abstract List<FirmPositionLimitModel> getFirmPositionLimitByFirmID(
			String firmId);
	public abstract int updateFirmPositionLimitByFirmID(
			FirmPositionLimitModel firmPositionLimitModel, String userName,
			String firmID);
	public abstract int deleteeFirmPositionLimitModelByFirmID(String firmID);
	public abstract int addFirmPositionLimitModel(
			FirmPositionLimitModel firmPositionLimitModel, String userName,
			String firmID);
	
	/**
	 * 获取未被关联过的交易商列表(商铺用)
	 * @param params
	 * @return
	 */
	public List<FirmAllData> getIsNotRelationFrimListForShop(QueryConditions qc,PageInfo pageInfo);
	
	/**
	 * 判断当前交易商ID是否关联过商铺
	 * @param params
	 * @return 0:没有被关联过，>=1：被关联过
	 */
	public int countRelationShopFrim(String firmId);
	
	
	/**
	 * 插入商铺交易商关联表
	 * @param params
	 * @return
	 */
	public int insertShopFirm(ShopFirm shopFirm);
	
	/**
	 * 通过shopId删除商铺交易商关联数据
	 * @param params
	 * @return
	 */
	public int deleteShopFirmByShopId(Integer shopId,Integer isMainFirm);
	
	/**
	 * 通过店铺ID关联的交易商
	 * @param params
	 * @return
	 */
	public List<ShopFirm> selectShopFirmListByShopID(QueryConditions qc,PageInfo pageInfo);
	
	/**
	 * 更新商铺表 禁用状态
	 * @param params
	 * @return
	 */
	public int updateShopOfDisabled(int shopId,int disabled);
	/**
	 * 交易商所有报盘可用量
	 * @param firmID
	 * @param goodsType 0:现货 1：预售
	 * @return
	 */
	public abstract BigDecimal getLeadsQuantity(String firmID,int goodsType);
	/**
	 * 交易商所有报盘可用量总货款
	 * @param firmID
	 * @param goodsType 0:现货 1：预售
	 * @return
	 */
	public abstract BigDecimal getLeadsMonet(String firmID,int goodsType);
	/**
	 * 银行信息
	 * @param vatBankID
	 * @return
	 */
	public abstract ValueTxtView getBankObj(Integer vatBankID);
	/**
	 * 开户银行地址信息:省市区
	 * @param vatID
	 * @return
	 */
	public abstract ValueTxtView getBankAddRessObj(Integer vatID);
	
	/**
	 * 获取交易商限额配置
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public List<FirmPositionLimitModel> getFirmPositionLimitByTradeType(
			QueryConditions qc, PageInfo pageInfo);
	
}
