package shcem.member.enums;

/**公司类型 0:个人，1:法人，2:代理
 * @author zhangnan
 *
 */
public enum FirmTypeConstant {
	//公司类型 0:个人，1:法人，2:代理
	FIRMTYPE0("个人",0),
	FIRMTYPE1("法人",1),
	FIRMTYPE2("代理",2);
	private String firmTypeText;
	private Integer firmType;
	FirmTypeConstant(String firmTypeText,int firmType){
		this.setFirmTypeText(firmTypeText);
		this.setFirmType(firmType);
	}
	FirmTypeConstant(int firmType){
		this.setFirmTypeText(firmTypeText);
		this.setFirmType(firmType);
	}
	public String getFirmTypeText() {
		return firmTypeText;
	}
	public void setFirmTypeText(String firmTypeText) {
		this.firmTypeText = firmTypeText;
	}
	public Integer getFirmType() {
		return firmType;
	}
	public void setFirmType(Integer firmType) {
		this.firmType = firmType;
	}
}
