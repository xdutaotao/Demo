package shcem.member.dao.model;

import java.io.Serializable;

import shcem.base.dao.model.BaseObject;
/**
 * 交易员模块权限关系
 * @author zhangnan
 *
 */
public class FirmTmptRlsp  extends BaseObject implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer tradeTmptId;
	
	private String firmID;
	
	private String enabled;
	
	//交易商是否实名   0:否，1:是
    private Integer isRealName;
    
	//买卖权限 0：卖，1：买 2：全部（线性场设定，其他场与交易商买卖权限同步）
    private Integer tradeAuthority;
	
	

	public Integer getTradeAuthority() {
		return tradeAuthority;
	}

	public void setTradeAuthority(Integer tradeAuthority) {
		this.tradeAuthority = tradeAuthority;
	}

	public Integer getTradeTmptId() {
		return tradeTmptId;
	}

	public void setTradeTmptId(Integer tradeTmptId) {
		this.tradeTmptId = tradeTmptId;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}


	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getEnabled() {
		return enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}

	public Integer getIsRealName() {
		return isRealName;
	}

	public void setIsRealName(Integer isRealName) {
		this.isRealName = isRealName;
	}

}
