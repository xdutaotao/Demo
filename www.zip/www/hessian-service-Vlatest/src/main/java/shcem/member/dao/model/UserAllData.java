package shcem.member.dao.model;

import java.io.Serializable;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**用户详细信息
 * @author zhangnan
 *
 */
public class UserAllData extends BaseObject implements Serializable {
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**  */
    private String userCode;
    
    /**  */
    private String userName;
    
    /**  */
    private String mobile;
    
    /** 默认为 0：正常，1：失效 */
    private Integer disabled;
    
    /** 类型 0:浏览用户,1:交易员用户 */
    private Integer userType;
    
    /**  */
    private Date lastLoginTime;
    
    /**  */
    private String recCreateBy;
    
    /**  */
    private Date recCreateTime;
    
    /**  */
    private String recModifyBy;
    
    /**  */
    private Date recModifyTime;

    
    
    
	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public Integer getUserType() {
		return userType;
	}

	public void setUserType(Integer userType) {
		this.userType = userType;
	}

	public Date getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(Date lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public String getRecCreateBy() {
		return recCreateBy;
	}

	public void setRecCreateBy(String recCreateBy) {
		this.recCreateBy = recCreateBy;
	}

	public Date getRecCreateTime() {
		return recCreateTime;
	}

	public void setRecCreateTime(Date recCreateTime) {
		this.recCreateTime = recCreateTime;
	}

	public String getRecModifyBy() {
		return recModifyBy;
	}

	public void setRecModifyBy(String recModifyBy) {
		this.recModifyBy = recModifyBy;
	}

	public Date getRecModifyTime() {
		return recModifyTime;
	}

	public void setRecModifyTime(Date recModifyTime) {
		this.recModifyTime = recModifyTime;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}
