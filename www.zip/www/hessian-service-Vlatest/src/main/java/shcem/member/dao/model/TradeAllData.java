package shcem.member.dao.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import shcem.base.dao.model.BaseObject;

/**交易员相关所有信息
 * @author zhangnan
 *
 */
public class TradeAllData extends BaseObject implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/** 交易员编码 */
    private String traderID;
    
    /** 交易员名称 */
    private String traderName;
    
    /** 强制密码更新状态 0:已更新，1:未更新 */
    private Integer forceChangePwd;
    
    /**  */
    private Integer disabled;
    
    /** 交易商编码 */
    private String firmID;
    
    /** 交易商名称 */
    private String firmName;
    
    /** 类型 0:管理员,1:一般交易员 */
    private Integer firmType;
    
    /**  */
    private String recCreateBy;
    
    /**  */
    private Date recCreateTime;
    
    /**  */
    private String recModifyBy;
    
    /**  */
    private Date recModifyTime;
    
    //用户
    /**  */
    private String userCode;
    
    /**  */
    private String userName;
    
    /**  */
    private String userPassword;
    
    /**  */
    private String mobile;
    
    /** 类型 0:浏览用户,1:交易员用户 */
    private Integer userType;
    
    /**  */
    private Date lastLoginTime;
    
    //交易场权限
    private List<TraderTmptRlsp> traderTmptRlspList;

    public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public String getTraderID() {
		return traderID;
	}

	public void setTraderID(String traderID) {
		this.traderID = traderID;
	}

	public String getTraderName() {
		return traderName;
	}

	public void setTraderName(String traderName) {
		this.traderName = traderName;
	}


	public Integer getForceChangePwd() {
		return forceChangePwd;
	}

	public void setForceChangePwd(Integer forceChangePwd) {
		this.forceChangePwd = forceChangePwd;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public Integer getFirmType() {
		return firmType;
	}

	public void setFirmType(Integer firmType) {
		this.firmType = firmType;
	}

	public String getRecCreateBy() {
		return recCreateBy;
	}

	public void setRecCreateBy(String recCreateBy) {
		this.recCreateBy = recCreateBy;
	}

	public Date getRecCreateTime() {
		return recCreateTime;
	}

	public void setRecCreateTime(Date recCreateTime) {
		this.recCreateTime = recCreateTime;
	}

	public String getRecModifyBy() {
		return recModifyBy;
	}

	public void setRecModifyBy(String recModifyBy) {
		this.recModifyBy = recModifyBy;
	}

	public Date getRecModifyTime() {
		return recModifyTime;
	}

	public void setRecModifyTime(Date recModifyTime) {
		this.recModifyTime = recModifyTime;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Integer getUserType() {
		return userType;
	}

	public void setUserType(Integer userType) {
		this.userType = userType;
	}

	public Date getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(Date lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public List<TraderTmptRlsp> getTraderTmptRlspList() {
		return traderTmptRlspList;
	}

	public void setTraderTmptRlspList(List<TraderTmptRlsp> traderTmptRlspList) {
		this.traderTmptRlspList = traderTmptRlspList;
	}

}
