/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: UserManagerImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.component.impl;

import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.exception.BaseException;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.constant.Constants;
import shcem.member.component.IUserManager;
import shcem.member.dao.TraderDAO;
import shcem.member.dao.UserDAO;
import shcem.member.dao.UserWeiXinDAO;
import shcem.member.dao.model.CusInfoCscfg;
import shcem.member.dao.model.User;
import shcem.member.dao.model.UserAllData;
import shcem.member.dao.model.UserDataList;
import shcem.member.dao.model.UserWeiXin;
import shcem.member.service.model.CusInfoMaintainDto;
import shcem.member.service.model.CusInfoMaintainModel;
import shcem.util.EncrypMD5;

/**
 * @author wlpod
 *
 */
public class UserManagerImpl extends BaseManager implements IUserManager {
	private UserDAO dao;
	private UserDAO userDAO_read;
	private TraderDAO traderDAO;
	
	private UserWeiXinDAO userWeiXinDao;
	private UserWeiXinDAO userWeiXinDao_read;
	public void setTraderDAO(TraderDAO traderDAO) {
		this.traderDAO = traderDAO;
	}

	@Override
	public void setUserDAO(UserDAO dao) {
		this.dao = dao;
	}

	public void setUserDAO_read(UserDAO userDAO_read) {
		this.userDAO_read = userDAO_read;
	}

	public void setUserWeiXinDao(UserWeiXinDAO userWeiXinDao) {
		this.userWeiXinDao = userWeiXinDao;
	}

	public void setUserWeiXinDao_read(UserWeiXinDAO userWeiXinDao_read) {
		this.userWeiXinDao_read = userWeiXinDao_read;
	}

	/* (non-Javadoc)
	 * @see shcem.member.component.IUserManager#getUserList(shcem.base.query.QueryConditions, shcem.base.query.PageInfo)
	 */
	@Override
	public List<UserDataList> getUserList(QueryConditions qc, PageInfo pageInfo) {
		List<UserDataList> list = this.userDAO_read.getUserList(qc, pageInfo);
		return list;
	}

	/* (non-Javadoc)
	 * @see shcem.member.component.IUserManager#getUser(java.lang.String)
	 */
	@Override
	public UserAllData getUser(String userCode) {
		return this.userDAO_read.getUser(userCode);
	}

	/* (non-Javadoc)
	 * @see shcem.member.component.IUserManager#disableUser(java.lang.String)
	 */
	@Override
	public int disableUser(String userCode) {
		int returnCode;
		returnCode = this.dao.disableUser(userCode);
		//禁用用户的同时，起绑定的交易员userCode置null
		this.traderDAO.updateTraderByUserCode(userCode);
		return returnCode;
	}

	/* (non-Javadoc)
	 * @see shcem.member.component.IUserManager#enableUser(java.lang.String)
	 */
	@Override
	public int enableUser(String userCode) {
		return this.dao.enableUser(userCode);
	}

	@Override
	public void addUser(User user)throws RuntimeException {
		user.setUserPassword(EncrypMD5.eccrypt("111111"));
		user.setDisabled(0);
		//默认浏览用户
		user.setUserType(0);
		user.setRecCreateBy("");//后台操作人员，存到session里
		user.setRecModifyBy("");
		//秘钥
		user.setSalt("");
		this.dao.addUser(user);
	}

	@Override
	public List<CusInfoMaintainDto> selectCUserList(QueryConditions qc,
			PageInfo pageInfo) {
		return this.userDAO_read.selectCUserList(qc, pageInfo);
	}

	@Override
	public CusInfoMaintainModel selectCusInfoMaintainByUserCode(String userCode) {
		return this.userDAO_read.selectCusInfoMaintainByUserCode(userCode);
	}

	@Override
	public void insertCusInfoMaintain(CusInfoMaintainModel model) {
		this.dao.insertCusInfoMaintain(model);
	}

	@Override
	public void updateCusInfoMaintain(CusInfoMaintainModel model) {
		this.dao.updateCusInfoMaintain(model);
	}

	@Override
	public int countCusInfoMaintainByUserCode(String userCode) {
		int count = this.dao.countCusInfoMaintainByUserCode(userCode);
		return count;
	}
	
	@Override
	public CusInfoCscfg getCusInfoCscfg(String userCode) {
		return this.userDAO_read.getCusInfoCscfg(userCode);
	}

	@Override
	public int addCusInfo(CusInfoCscfg cusInfoCscfg) {
		return this.dao.addCusInfo(cusInfoCscfg);
	}

	@Override
	public int updateCusInfo(CusInfoCscfg cusInfoCscfg) {
		return this.dao.updateCusInfo(cusInfoCscfg);
	}

	@Override
	public int updateUserErrorPswOfErrorNumsById(Integer id) {
		return dao.updateUserErrorPswOfErrorNumsById(id);
	}
	
	/**
	 * 
	 * 添加微信授权信息
	 * @throws Exception 
	 * */
	@Override
	public void addWeiXinInfo(UserWeiXin userWeiXin) throws Exception {
		this.userWeiXinDao.addWeiXinInfo(userWeiXin);
	}
	
	/**
	 * 
	 * 添加用户和微信账号关联关系
	 * @throws Exception 
	 * */
	@Override
	public void addUserWeiXinRelation(UserWeiXin userWeiXin) throws Exception {
		List<User> userList = this.traderDAO.getUserByMobile(userWeiXin.getMobile());
		if (userList != null && userList.size() > 0) {
			userWeiXin.setUserCode(userList.get(0).getUserCode());
			
			UserWeiXin uwx = this.userWeiXinDao.getUserByUserCode(userWeiXin.getUserCode());
			if (uwx != null) {
				log.error("手机号：" + userWeiXin.getMobile() + " 已经绑定！");
				throw new BaseException(Constants.EXCEPTION_ERROR_CODE_1001, new Object[]{ "手机号：" + userWeiXin.getMobile() + " 已经绑定！"});
			}
			this.userWeiXinDao.updateUserWeiXinAddRelation(userWeiXin);
		} else {
			log.error("手机号：" + userWeiXin.getMobile() + " 找不到对应的用户相关信息！");
			throw new Exception("手机号：" + userWeiXin.getMobile() + " 找不到对应的用户相关信息！");
		}
	}
	
	/**
	 * 通过openId获取信息
	 * 
	 * @param userWeiXin
	 * @return
	 */
	@Override
	public UserWeiXin getUserByOpenID(String openId) {
		return this.userWeiXinDao_read.getUserByOpenID(openId);
	}
}
