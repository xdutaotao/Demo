/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: TraderServiceImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.member.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.finance.util.JSONArrayUtil;
import shcem.member.component.ITraderManager;
import shcem.member.dao.model.TradeAllData;
import shcem.member.dao.model.Trader;
import shcem.member.dao.model.TraderDataList;
import shcem.member.service.ITraderService;
import shcem.member.service.model.CheckIMAuthInput;
import shcem.member.service.model.userMobileModel;
import shcem.member.util.ClearSessionUtil;
import shcem.member.util.FirmSysData;
import shcem.util.JsonUtil;

/**
 * @author wlpod
 *
 */
public class TraderServiceImpl extends BaseServiceImpl implements ITraderService {

	private ITraderManager mgr = (ITraderManager) FirmSysData.getBean(Constants.BEAN_TRDER_MGR);
	String mode = "member";

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.member.service.ITraderService#getTrader(java.lang.String)
	 */
	@Override
	public String getTrader(String params) {
		this.log.info(this.getClass().getName() + " getTrader() Start");
		this.log.debug("getTrader Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		String traderID = JOParams.getString("traderID");
		boolean bolRst = false;
		TradeAllData tradeAllData = new TradeAllData();
		try {
			tradeAllData = this.mgr.getTrader(traderID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("检查交易员编码是否存在出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
		}
		if (bolRst) {
			JSONObject retData;
			try {
				retData = JsonUtil.coverModelToJSONObject(tradeAllData);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error("交易商数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getTrader() End");
		this.log.debug(rtnData.toString());
		return rtnData.toString();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.member.service.ITraderService#disableTrader(java.lang.String)
	 */
	// 禁用交易员
	@Override
	public String disableTrader(String params) {
		this.log.info(this.getClass().getName() + " disableTrader() Start");
		this.log.debug("disableTrader Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		String traderID = JOParams.getString("traderID");
		String bindNote = JOParams.getString("bindNote");// 禁用备注
		boolean whetherDisableUser = false;
		if (!JOParams.isNull("isCheck")) {
			whetherDisableUser = JOParams.getBoolean("isCheck");
		}
		try {
			int row = this.mgr.disableTrader(traderID, whetherDisableUser);
			setResultData("00000", null);
			this.log.businesslog("禁用交易员成功 禁用原因" + bindNote, Constants.OPE_MODE_MEMBER, Constants.OPE_SUCCESS);
		} catch (Exception e) {
			this.log.error("禁用交易员出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("禁用交易员出错" + e.getMessage(), Constants.OPE_MODE_MEMBER, Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " disableTrader() End");
		return rtnData.toString();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.member.service.ITraderService#enableTrader(java.lang.String)
	 */
	// 启用交易员
	@Override
	public String enableTrader(String params) {
		this.log.info(this.getClass().getName() + " enableTrader() Start");
		this.log.debug("enableTrader Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		String traderID = JOParams.getString("traderID");
		String bindNote = JOParams.getString("bindNote");// 禁用备注
		try {
			int row = this.mgr.enableTrader(traderID);
			setResultData("00000", null);
			this.log.businesslog("启用交易员成功 禁用原因" + bindNote, Constants.OPE_MODE_MEMBER, Constants.OPE_SUCCESS);
		} catch (Exception e) {
			this.log.error("重新启用交易员出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("重新启用交易员出错" + e.getMessage(), Constants.OPE_MODE_MEMBER, Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " enableTrader() End");
		return rtnData.toString();
	}

	@Override
	public String getTraderList(String params) {
		this.log.info(this.getClass().getName() + " getTraderList() Start");
		this.log.debug("JSONParams=" + params);
		boolean bolRst = false;
		List<TraderDataList> list = null;
		JSONObject JSONParams = new JSONObject(params);
		// 表头查询条件
		List<Condition> conditionsList = new ArrayList<Condition>();
		JSONObject queryModel = null;
		PageInfo pageInfo = null;
		QueryConditions qc = null;
		String firmID = null;
		if (!JSONParams.isNull("firmID")) {
			firmID = JSONParams.getString("firmID");
		} else {
			conditionsList.add(new Condition("ct.TraderName", "like", "", "string", "traderName"));// 交易员名称
																									// 模糊查询
			conditionsList.add(new Condition("ct.TraderID", "like", "", "string", "traderID"));// 交易员ID
																								// 模糊查询
			conditionsList.add(new Condition("cf.FirmName", "like", "", "string", "firmName"));// 交易shang名称
																								// 模糊查询
			conditionsList.add(new Condition("cf.FirmID", "like", "", "string", "firmID"));// 交易商编码
																							// 模糊查询
			conditionsList.add(new Condition("ct.DISABLED", "like", "", "string", "disabled"));// 交易员ID
																								// 模糊查询
			conditionsList.add(new Condition("ct.TraderStatus", "like", "", "Integer", "traderStatus"));// 交易员ID

			queryModel = JSONParams.optJSONObject("queryModel");
			qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionsList, "");
			this.log.debug("qc=" + qc.toString());
			// 分页信息
			pageInfo = QueryHelper.getPageInfoFromJsonReq(JSONParams);
		}

		try {
			list = this.mgr.getTraderList(qc, pageInfo, firmID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("取得交易员列表信息失败：" + e.getMessage());
			setResultData("10104", null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				if (JSONParams.isNull("firmID")) {
					jsonObj.put("total", pageInfo.getTotalRecords());
				} else {
					jsonObj.put("total", list.size());
				}
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("交易商数据转换失败：" + e.getMessage());
				setResultData("21002", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getTraderList() End");
		return rtnData.toString();
	}

	@Override
	public String addTrader(String params) {
		this.log.info(this.getClass().getName() + " addTrader() Start");
		this.log.debug("addTrader Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		// 交易场权限
		JSONArray traderTmptRlspsTemp = JOParams.getJSONArray("traderTmptRlsps");
		int[] traderTmptRlsps = JSONArrayUtil.getJsonToIntArray(traderTmptRlspsTemp);
		Trader trader = null;
		trader = (Trader) JsonUtil.jsonToBean(JOParams, Trader.class);
		int returnCode;
		try {
			returnCode = this.mgr.addTrader(trader, traderTmptRlsps);
			if (returnCode == 1) {
				setResultData("00000", null);
				this.log.businesslog("新增交易员成功", Constants.OPE_MODE_MEMBER, Constants.OPE_SUCCESS);
			} else if (returnCode == -1) {
				setResultData("20002", null);
			} else {
				setResultData("10106", null);
			}
		} catch (Exception e) {
			this.log.error("新增交易员信息出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("新增交易员出错" + e.getMessage(), Constants.OPE_MODE_MEMBER, Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " addTrader() End");
		return rtnData.toString();
	}

	@Override
	public String updateTrader(String params) {
		this.log.info(this.getClass().getName() + " updateTrader() Start");
		this.log.debug("updateTrader Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		// 交易场权限
		JSONArray traderTmptRlspsTemp = JOParams.getJSONArray("traderTmptRlsps");
		int[] traderTmptRlsps = JSONArrayUtil.getJsonToIntArray(traderTmptRlspsTemp);
		Trader trader = null;
		trader = (Trader) JsonUtil.jsonToBean(JOParams, Trader.class);
		int returnCode;
		String mode = this.getMode();
		String userName = this.getUserId() == null ? "system" : (this.getUserId().equals("")) ? "system" : this
				.getUserId();
		try {
			returnCode = this.mgr.updateTrader(trader, traderTmptRlsps, mode, userName, this.getRequestId());
			if (returnCode >= 0) {
				setResultData("00000", null);
				this.log.businesslog("更新交易员信息成功", Constants.OPE_MODE_MEMBER, Constants.OPE_SUCCESS);
			} else if (returnCode == -1) {
				/**
				 * 该交易员已被绑定到其他交易商
				 */
				setResultData("20002", null);
			} else {
				setResultData("10106", null);
			}
		} catch (Exception e) {
			this.log.error("更新交易员信息出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("更新交易员信息出错" + e.getMessage(), Constants.OPE_MODE_MEMBER, Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " updateTrader() End");

		return rtnData.toString();
	}

	// 检查交易员编码是否存在
	@Override
	public String checkUserIDExisted(String params) {
		this.log.info(this.getClass().getName() + " checkUserIDExisted() Start");
		this.log.debug("checkUserIDExisted Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		Trader trader = null;
		trader = (Trader) JsonUtil.jsonToBean(JOParams, Trader.class);
		try {
			TradeAllData traderTemp = this.mgr.getTrader(trader.getTraderID());
			if (traderTemp != null) {
				setResultData("20001", null);
			} else {
				setResultData("20000", null);
			}
		} catch (Exception e) {
			this.log.error("检查交易员编码是否存在出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
		}
		this.log.info(this.getClass().getName() + " checkUserIDExisted() End");
		return rtnData.toString();
	}

	@Override
	public String Unbundling(String params) {
		this.log.info(this.getClass().getName() + " Unbundling() Start");
		this.log.debug("Unbundling Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		String tradeID = JOParams.getString("traderID");
		/**
		 * 解绑缘由
		 */
		String bindNote = JOParams.getString("bindNote");
		try {
			int row = this.mgr.Unbundling(tradeID);
			if (row == 1) {
				// 清除交易员的Session
				int code = ClearSessionUtil
						.clearSession(tradeID, this.getUserId(), this.getMode(), this.getRequestId());
				if (code != 0) {
					setResultData("30000", null, "解绑交易员ID[" + tradeID + "]失败");
					return rtnData.toString();
				}
			}

			setResultData("00000", null);
			this.log.businesslog("交易员和用户解绑成功", Constants.OPE_MODE_MEMBER, Constants.OPE_SUCCESS);
		} catch (Exception e) {
			this.log.error("解绑出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("交易员和用户解绑出错" + e.getMessage(), Constants.OPE_MODE_MEMBER, Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " Unbundling() End");
		return rtnData.toString();
	}

	@Override
	public String bindTrader(String params) {
		this.log.info(this.getClass().getName() + " bindTrader() Start");
		this.log.debug("addTrader Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		Trader trader = (Trader) JsonUtil.jsonToBean(JOParams, Trader.class);
		int returnCode;
		trader.setRecCreateBy("");
		try {
			returnCode = this.mgr.bindTrader(trader);
			if (returnCode == 1) {
				setResultData("00000", null);
				this.log.businesslog("绑定交易员成功", Constants.OPE_MODE_MEMBER, Constants.OPE_SUCCESS);
			} else if (returnCode == -1) {
				setResultData("20002", null);
			} else {
				setResultData("10106", null);
			}
		} catch (Exception e) {
			this.log.error("绑定交易员信息出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("绑定交易员出错" + e.getMessage(), Constants.OPE_MODE_MEMBER, Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " bindTrader() End");
		return rtnData.toString();
	}

	@Override
	public String changeTraderStatus(String params) {
		this.log.info(this.getClass().getName() + " changeTraderStatus() Start");
		this.log.debug("changeTraderStatus Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		Trader trader = (Trader) JsonUtil.jsonToBean(JOParams, Trader.class);
		String userName = this.getUserName() == null ? "system" : (this.getUserName() == "") ? "system" : this
				.getUserName();
		try {
			int count = this.mgr.updateTraderStatusByTraderID(trader, userName);
			if (count == 1) {
				// 清除交易员的Session
				int code = ClearSessionUtil.clearSession(trader.getTraderID(), this.getUserId(), this.getMode(),
						this.getRequestId());
				if (code != 0) {
					setResultData("30000", null, "交易员ID[" + trader.getTraderID() + "]");
					return rtnData.toString();
				}

				setResultData("00000", null);
				this.log.businesslog("冻结交易员成功", Constants.OPE_MODE_MEMBER, Constants.OPE_SUCCESS);
			} else {
				setResultData("10106", null);
				this.log.businesslog("冻结交易员出错", Constants.OPE_MODE_MEMBER, Constants.OPE_FAIL);
			}
		} catch (Exception e) {
			this.log.error("冻结交易员信息出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("冻结交易员出错" + e.getMessage(), Constants.OPE_MODE_MEMBER, Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " changeTraderStatus() End");
		return rtnData.toString();
	}

	@Override
	public String queryTraderList(String params) {
		this.log.info(this.getClass().getName() + " queryTraderList() Start");
		this.log.debug("JSONParams=" + params);
		boolean bolRst = false;
		List<TraderDataList> list = null;
		JSONObject JSONParams = new JSONObject(params);
		// 表头查询条件
		List<Condition> conditionsList = new ArrayList<Condition>();
		QueryConditions qc = null;
		conditionsList.add(new Condition("temp.FirmID", "=", "", "string", "firmID"));// 交易商ID
		conditionsList.add(new Condition("temp.FirmType", "=", "", "string", "firmType"));// 交易员类型
																							// 0:管理员,1:一般交易员
		qc = QueryHelper.getQueryConditionsFromJson(JSONParams, conditionsList, "");
		try {
			list = this.mgr.getTraderList(qc, null);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("取得交易员列表信息失败：" + e.getMessage());
			setResultData("10104", null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("交易商数据转换失败：" + e.getMessage());
				setResultData("21002", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " queryTraderList() End");
		return rtnData.toString();
	}

	@Override
	public String queryUserMobileList(String params) {
		this.log.info(this.getClass().getName() + " queryUserMobileList() Start");
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		String userCode = "";
		if (!JOParams.isNull("userCode")) {
			userCode = JOParams.getString("userCode");
		}
		List<Condition> conditionList = new ArrayList<Condition>();

		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<userMobileModel> list = null;
		boolean bolRst = false;
		try {
			list = this.mgr.queryUserMobileList(qc, pageInfo, userCode);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("取得用户手机号列表失败：" + e.getMessage());
			setResultData("30000", null, e.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("30000", null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " queryUserMobileList() End");
		return rtnData.toString();
	}

	@Override
	public String addUserMobile(String params) {
		this.log.info(this.getClass().getName() + " addUserMobile() Start");
		JSONObject JOParams = new JSONObject(params);
		String moreMobile = JOParams.getString("moreMobile");
		String userCode = JOParams.getString("userCode");
		String userName = this.getUserName() == null ? "system" : (this.getUserName() == "") ? "system" : this
				.getUserName();
		int returnCode;
		try {
			returnCode = this.mgr.addUserMobile(moreMobile, userCode, userName);
			if (returnCode >= 0) {
				setResultData("00000", null);
			} else if (returnCode == -20003) {
				setResultData("20003", null);
			} else if (returnCode == -20004) {
				setResultData("20004", null);
			} else {
				setResultData("30000", null);
			}
		} catch (Exception e) {
			this.log.error("添加用户手机失败：" + e.getMessage());
			setResultData("30000", null);
		}
		this.log.info(this.getClass().getName() + " addUserMobile() End");
		return rtnData.toString();
	}

	@Override
	public String changeUserMobile(String params) {
		this.log.info(this.getClass().getName() + " changeUserMobile() Start");
		JSONObject JOParams = new JSONObject(params);
		int id = JOParams.getInt("id");
		String moreMobile = JOParams.getString("moreMobile");
		String userName = this.getUserName() == null ? "system" : (this.getUserName() == "") ? "system" : this
				.getUserName();
		int returnCode;
		try {
			returnCode = this.mgr.changeUserMobile(id, moreMobile, userName);
			if (returnCode >= 0) {
				setResultData("00000", null);
			} else {
				setResultData("30000", null);
			}
		} catch (Exception e) {
			this.log.error("修改用户手机失败：" + e.getMessage());
			setResultData("30000", null);
		}
		this.log.info(this.getClass().getName() + " changeUserMobile() End");
		return rtnData.toString();
	}

	@Override
	public String unBindUserMobile(String params) {
		this.log.info(this.getClass().getName() + " unBindUserMobile() Start");
		JSONObject JOParams = new JSONObject(params);
		int id = JOParams.getInt("id");
		int returnCode;
		try {
			returnCode = this.mgr.unBindUserMobile(id);
			if (returnCode >= 0) {
				setResultData("00000", null);
			} else {
				setResultData("30000", null);
			}
		} catch (Exception e) {
			this.log.error("解绑用户手机失败：" + e.getMessage());
			setResultData("30000", null);
		}
		this.log.info(this.getClass().getName() + " unBindUserMobile() End");
		return rtnData.toString();
	}

	/**
	 * 聊天用（检查交易员及报盘的有效状态）
	 * 
	 * @param params
	 * @return
	 */
	@Override
	public String checkIMAuth(String params) {

		this.log.info(this.getClass().getName() + " checkIMAuth() Start");
		
		// 取得输入参数
		CheckIMAuthInput input = (CheckIMAuthInput) JsonUtil.jsonToBean(new JSONObject(params), CheckIMAuthInput.class);
		String traderCode = input.getTraderCode();
		String leadsCode = input.getLeadsCode();
		Map<String, String> rtnMap = new HashMap<String, String>();
		
		String returnMsg;
		try {
			returnMsg = this.mgr.checkIMAuth(traderCode, leadsCode, rtnMap);
			if (returnMsg == null) {
				setResultData("00000", rtnMap);
			} else {
				setResultData("30000", returnMsg);
			}
		} catch (Exception e) {
			this.log.error("检查交易员及报盘的有效状态错误：" + e.toString());
			setResultData("30000", "当前报盘状态确认失败，不能发起在线咨询。", e.toString());
		}
		
		this.log.info(this.getClass().getName() + " checkIMAuth() End");
		return rtnData.toString();
	}
}
