package shcem.kpi.dao.model;

import java.io.Serializable;

import shcem.base.dao.model.BaseObject;

/**
 * 银行开户信息
 * */
public class KpiBankAccount extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 银行名字
	 * */
	private String bankName;
	
	/**
	 * 开户数
	 * */
	private int openCounts;

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public int getOpenCounts() {
		return openCounts;
	}

	public void setOpenCounts(int openCounts) {
		this.openCounts = openCounts;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}
