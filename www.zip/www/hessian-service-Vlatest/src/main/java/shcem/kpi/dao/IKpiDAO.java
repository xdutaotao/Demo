package shcem.kpi.dao;

import java.util.List;

import shcem.base.dao.DAO;
import shcem.kpi.dao.model.Deal;
import shcem.kpi.dao.model.DealAssignStatus;
import shcem.kpi.dao.model.KpiCargoAgent;
import shcem.kpi.dao.model.KpiOperation;
import shcem.kpi.dao.model.KpiOperationTarget;
import shcem.kpi.dao.model.KpiWareHouse;
import shcem.kpi.dao.model.Trader;
import shcem.kpi.dao.model.User;

public abstract interface IKpiDAO extends DAO {
	/**
	 * 获取’今日成交‘kpi
	 * */
	public abstract Deal getDealTodayKpi(String params) ;
	
	/**
	 * 获取’总成交‘kpi
	 * */
	public abstract Deal getDealAllKpi(String params) ;
	
	/**
	 * 获取’当日订单各个状态的计数 (前台)‘kpi
	 * */
	public abstract List<DealAssignStatus> getDealAssignStatus(String params) ;
	
	/**
	 * 获取’当前交易商数量(买/卖) / 用户数‘kpi
	 * */
	public abstract List<User> getAllTrader(String params) ;
	
	/**
	 * 获取’当日交易商数量(买/卖) / 用户数‘kpi
	 * */
	public abstract List<User> getTodayTrader(String params) ;
	
	/**
	 * 获取’月活交易商(成交或者询盘1次以上 或者 登录次数每月超过10次)‘kpi
	 * */
	public abstract List<Trader> getActiveTrader(String params) ;

	/**
	 * 取得某段日期内的交易列表（单数，吨数，金额）
	 * */
	public abstract List<Deal> getDealListKpi(String params);


	/**
	 * （运营）本月量化目标-重复成交买家数
	 * */
	public abstract KpiOperation getMonthRptBuyFirmNums(int year, int month);

	/**
	 * （运营）本月量化目标-日均询盘数
	 * */
	public abstract KpiOperation getMonthAvgEnquiryNums(int days, int year, int month);

	/**
	 * （运营）本月量化目标-月成交买家数
	 * */
	public abstract KpiOperation getMonthBuyFirmNums(int year, int month);

	/**
	 * （运营）本月量化目标-成交量
	 * */
	public abstract KpiOperation getMonthTotalQuantity(int year, int month);

	/**
	 * 交易场：现货，预售，中石化配送
	 * */
	public abstract List<Deal> getTradeTmptDealTodayKpi(String params);

	/**
	 * 每天新增交易商数量 / 用户数量
	 * */
	public abstract List<User> getDayNewlyTrader(String params);

	/**
	 * （物流）仓库数
	 * */
	public abstract List<KpiWareHouse> getWareHouseNums();

	/**
	 * （物流）货代数
	 * */
	public abstract List<KpiCargoAgent> getCargoAgentNums();

	/**
	 * 交易场：现货，预售，中石化配送（总）
	 * */
	public abstract List<Deal> getTradeTmptDealAllKpi(String params);

	/**
	 * （运营）本月量化目标值，数据持久化
	 * month format: 201701
	 * */
	public abstract List<KpiOperationTarget> getMonthOperationTarget(int year, int month);

	/**
	 * （用户）最新一条卖家信息
	 * */
	public abstract List<Trader> getNewestSeller(String params);

}
