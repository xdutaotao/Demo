package shcem.kpi.dao.model;

import java.io.Serializable;
import java.util.List;


public class KpiLogistics implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 仓库
	 * */
	private List<KpiWareHouse> whList;
	
	/**
	 * 货代
	 * */
	private List<KpiCargoAgent> caList;
	
	public List<KpiWareHouse> getWhList() {
		return whList;
	}

	public void setWhList(List<KpiWareHouse> whList) {
		this.whList = whList;
	}

	public List<KpiCargoAgent> getCaList() {
		return caList;
	}

	public void setCaList(List<KpiCargoAgent> caList) {
		this.caList = caList;
	}

}
