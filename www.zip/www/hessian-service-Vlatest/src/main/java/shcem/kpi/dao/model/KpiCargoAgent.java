package shcem.kpi.dao.model;

import java.io.Serializable;

import shcem.base.dao.model.BaseObject;

public class KpiCargoAgent extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 交收方式
	 * */
	private String deliveryType;
	
	/**
	 * 货代数
	 * */
	private int caNums;

	public String getDeliveryType() {
		return deliveryType;
	}

	public void setDeliveryType(String deliveryType) {
		this.deliveryType = deliveryType;
	}

	public int getCaNums() {
		return caNums;
	}

	public void setCaNums(int caNums) {
		this.caNums = caNums;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	
}
