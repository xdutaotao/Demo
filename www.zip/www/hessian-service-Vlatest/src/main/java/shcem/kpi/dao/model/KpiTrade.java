package shcem.kpi.dao.model;

import java.io.Serializable;

public class KpiTrade implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// 交易状态
	private String TradeStatus;
	private String TradeStatusName;
	// 当日该交易状态的计数
	private int number;

	public String getTradeStatus() {
		return TradeStatus;
	}

	public void setTradeStatus(String tradeStatus) {
		TradeStatus = tradeStatus;
	}

	public String getTradeStatusName() {
		return TradeStatusName;
	}

	public void setTradeStatusName(String tradeStatusName) {
		TradeStatusName = tradeStatusName;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

}
