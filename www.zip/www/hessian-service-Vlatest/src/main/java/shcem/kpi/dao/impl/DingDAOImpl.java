package shcem.kpi.dao.impl;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.kpi.dao.IDingDAO;
import shcem.kpi.dao.model.Deal;

public class DingDAOImpl extends BaseDAOImpl implements IDingDAO {

	@Override
	public Deal getDealTodayKpi(String params) {
		// TODO Auto-generated method stub
		return null;
	}

}
