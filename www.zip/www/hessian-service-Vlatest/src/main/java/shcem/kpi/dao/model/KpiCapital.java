package shcem.kpi.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import shcem.base.dao.model.BaseObject;

public class KpiCapital extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 入金日期
	 * */
	private String createtime;
	
	/**
	 * 今日入金笔数
	 * */
	private int inMoneyCountToday;
	
	/**
	 * 今日入金金额
	 * */
	private BigDecimal inMoneyAmountToday;
	
	/**
	 * 总入金笔数
	 * */
	private int inMoneyCountAll;
	
	/**
	 * 总入金金额
	 * */
	private BigDecimal inMoneyAmountAll;
	
	/**
	 * 银行名字List
	 * */
	private List<String> bankNameList;
	
	/**
	 * 入金日期List
	 * */
	private List<String> createtimeList;
	
	/**
	 * 今日资金详情
	 * */
	private List<KpiSubCapital> todayCapitalList = new ArrayList<KpiSubCapital>();
	
	/**
	 * 历史趋势资金详情
	 * */
	private List<KpiSubCapital> subCapitalList = new ArrayList<KpiSubCapital>();

	/**
	 * 银行开户信息
	 * *
	 */
	private List<KpiBankAccount> bankAccts;
	
	/**
	 * 银行开户数
	 * *
	 */
	private int openCountsAll;
	
	public List<KpiSubCapital> getSubCapitalList() {
		return subCapitalList;
	}

	public void setSubCapitalList(List<KpiSubCapital> subCapitalList) {
		this.subCapitalList = subCapitalList;
	}

	public String getCreatetime() {
		return createtime;
	}

	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}

	public List<String> getBankNameList() {
		return bankNameList;
	}

	public void setBankNameList(List<String> bankNameList) {
		this.bankNameList = bankNameList;
	}

	public List<String> getCreatetimeList() {
		return createtimeList;
	}

	public void setCreatetimeList(List<String> createtimeList) {
		this.createtimeList = createtimeList;
	}

	public List<KpiSubCapital> getTodayCapitalList() {
		return todayCapitalList;
	}

	public void setTodayCapitalList(List<KpiSubCapital> todayCapitalList) {
		this.todayCapitalList = todayCapitalList;
	}

	public int getInMoneyCountToday() {
		return inMoneyCountToday;
	}

	public void setInMoneyCountToday(int inMoneyCountToday) {
		this.inMoneyCountToday = inMoneyCountToday;
	}

	public BigDecimal getInMoneyAmountToday() {
		return inMoneyAmountToday;
	}

	public void setInMoneyAmountToday(BigDecimal inMoneyAmountToday) {
		this.inMoneyAmountToday = inMoneyAmountToday;
	}

	public int getInMoneyCountAll() {
		return inMoneyCountAll;
	}

	public void setInMoneyCountAll(int inMoneyCountAll) {
		this.inMoneyCountAll = inMoneyCountAll;
	}

	public BigDecimal getInMoneyAmountAll() {
		return inMoneyAmountAll;
	}

	public void setInMoneyAmountAll(BigDecimal inMoneyAmountAll) {
		this.inMoneyAmountAll = inMoneyAmountAll;
	}

	public List<KpiBankAccount> getBankAccts() {
		return bankAccts;
	}

	public void setBankAccts(List<KpiBankAccount> bankAccts) {
		this.bankAccts = bankAccts;
	}

	public int getOpenCountsAll() {
		return openCountsAll;
	}

	public void setOpenCountsAll(int openCountsAll) {
		this.openCountsAll = openCountsAll;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}
