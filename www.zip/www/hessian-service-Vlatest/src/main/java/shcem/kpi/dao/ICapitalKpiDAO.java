package shcem.kpi.dao;

import java.util.List;

import shcem.base.dao.DAO;
import shcem.kpi.dao.model.KpiBankAccount;
import shcem.kpi.dao.model.KpiSubCapital;

public abstract interface ICapitalKpiDAO extends DAO {
	/**
	 * 获取’资金‘数据
	 * */
	public abstract List<KpiSubCapital> getCapitalKpi(String params) ;

	/**
	 * 银行开户数
	 * */
	public abstract List<KpiBankAccount> getOpenAccCountsKpi(String params);

}
