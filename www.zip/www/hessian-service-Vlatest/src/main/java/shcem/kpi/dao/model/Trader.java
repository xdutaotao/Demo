package shcem.kpi.dao.model;

import java.io.Serializable;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

public class Trader extends BaseObject  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String FirmID;
	private String FirmName;
	private String reason;
	private Date createTime;
	
	public String getFirmID() {
		return FirmID;
	}

	public void setFirmID(String firmID) {
		FirmID = firmID;
	}

	public String getFirmName() {
		return FirmName;
	}

	public void setFirmName(String firmName) {
		FirmName = firmName;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
