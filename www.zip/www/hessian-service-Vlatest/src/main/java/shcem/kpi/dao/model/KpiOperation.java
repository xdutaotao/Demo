package shcem.kpi.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import shcem.base.dao.model.BaseObject;

public class KpiOperation extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 月成交量
	 * */
	private BigDecimal totalQuantity;
	
	/**
	 * 月成交买家数
	 * */
	private int buyFirmNums;
	
	/**
	 * 重复成交买家数
	 * */
	private int rptBuyFirmNums;
	
	/**
	 * 日均询盘数
	 * */
	private double avgEnquiryNums;
	
	/**
	 * 入金买家数
	 * */
	private int inMoneyBuyFirmNums;
	
	/**
	 * 运营月目标值
	 * */
	private List<KpiOperationTarget> targets;

	public BigDecimal getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(BigDecimal totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	public int getBuyFirmNums() {
		return buyFirmNums;
	}

	public void setBuyFirmNums(int buyFirmNums) {
		this.buyFirmNums = buyFirmNums;
	}

	public int getRptBuyFirmNums() {
		return rptBuyFirmNums;
	}

	public void setRptBuyFirmNums(int rptBuyFirmNums) {
		this.rptBuyFirmNums = rptBuyFirmNums;
	}

	public double getAvgEnquiryNums() {
		return avgEnquiryNums;
	}

	public void setAvgEnquiryNums(double avgEnquiryNums) {
		this.avgEnquiryNums = avgEnquiryNums;
	}

	public int getInMoneyBuyFirmNums() {
		return inMoneyBuyFirmNums;
	}

	public void setInMoneyBuyFirmNums(int inMoneyBuyFirmNums) {
		this.inMoneyBuyFirmNums = inMoneyBuyFirmNums;
	}

	public List<KpiOperationTarget> getTargets() {
		return targets;
	}

	public void setTargets(List<KpiOperationTarget> targets) {
		this.targets = targets;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}
