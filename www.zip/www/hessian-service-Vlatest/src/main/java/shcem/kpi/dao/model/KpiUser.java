package shcem.kpi.dao.model;

import java.io.Serializable;
import java.util.List;

import shcem.base.dao.model.BaseObject;

public class KpiUser extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// 当日订单各个状态的计数 (前台)
	private List<KpiTrade> lstTrade;

	// 当前交易商数量(买/卖) / 用户数
	private List<KpiTrader> lstAllTrader;

	// 当日新增交易商数量 / 用户数量
	private List<KpiTrader> lstTodayTrader;

	// 每日新增交易商数量 / 用户数量
	private List<KpiTrader> lstDayNewlyTrader;
	
	// 月活交易商(成交或者询盘1次以上 或者 登录次数每月超过10次)
	private List<KpiActiveTrader> lstActiveTrader;
	
	// 交易商（最新一条卖家信息）
	private List<Trader> newestSeller;
	
	public List<KpiTrade> getLstTrade() {
		return lstTrade;
	}

	public void setLstTrade(List<KpiTrade> lstTrade) {
		this.lstTrade = lstTrade;
	}

	public List<KpiTrader> getLstDayNewlyTrader() {
		return lstDayNewlyTrader;
	}

	public void setLstDayNewlyTrader(List<KpiTrader> lstDayNewlyTrader) {
		this.lstDayNewlyTrader = lstDayNewlyTrader;
	}

	public List<KpiTrader> getLstAllTrader() {
		return lstAllTrader;
	}

	public void setLstAllTrader(List<KpiTrader> lstAllTrader) {
		this.lstAllTrader = lstAllTrader;
	}

	public List<KpiTrader> getLstTodayTrader() {
		return lstTodayTrader;
	}

	public void setLstTodayTrader(List<KpiTrader> lstTodayTrader) {
		this.lstTodayTrader = lstTodayTrader;
	}

	public List<KpiActiveTrader> getLstActiveTrader() {
		return lstActiveTrader;
	}

	public void setLstActiveTrader(List<KpiActiveTrader> lstActiveTrader) {
		this.lstActiveTrader = lstActiveTrader;
	}
	
	public List<Trader> getNewestSeller() {
		return newestSeller;
	}

	public void setNewestSeller(List<Trader> newestSeller) {
		this.newestSeller = newestSeller;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
