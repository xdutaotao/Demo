package shcem.kpi.dao.model;

import java.io.Serializable;

import shcem.base.dao.model.BaseObject;

public class User extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String TradeAuthority;
	private int numbers;
	
	/**日期*/
	private String date;

	public String getTradeAuthority() {
		return TradeAuthority;
	}

	public void setTradeAuthority(String tradeAuthority) {
		TradeAuthority = tradeAuthority;
	}

	public int getNumbers() {
		return numbers;
	}

	public void setNumbers(int numbers) {
		this.numbers = numbers;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
