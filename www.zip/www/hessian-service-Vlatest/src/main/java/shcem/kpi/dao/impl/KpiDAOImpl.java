package shcem.kpi.dao.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.kpi.dao.IKpiDAO;
import shcem.kpi.dao.model.Deal;
import shcem.kpi.dao.model.DealAssignStatus;
import shcem.kpi.dao.model.KpiCargoAgent;
import shcem.kpi.dao.model.KpiOperation;
import shcem.kpi.dao.model.KpiOperationTarget;
import shcem.kpi.dao.model.KpiWareHouse;
import shcem.kpi.dao.model.Trader;
import shcem.kpi.dao.model.User;
import shcem.util.CommonRowMapper;

public class KpiDAOImpl extends BaseDAOImpl implements IKpiDAO {
	
	@Override
	public Deal getDealAllKpi(String params) {
		String sql = this.sqlProperty.getProperty("KPI_001");
		Deal deal = (Deal) queryForObject(sql, null,new CommonRowMapper(new Deal()));
		return deal;
	}
	
	/**
	 * 交易场：现货，预售，中石化配送（总）
	 * */
	@Override
	public List<Deal> getTradeTmptDealAllKpi(String params) {
		String sql = this.sqlProperty.getProperty("KPI_00101");
		Object[] paramsa = null;
		List<Deal> deals = queryBySQL(sql, paramsa,null,new CommonRowMapper(new Deal()));
		return deals;
	}
	
	@Override
	public Deal getDealTodayKpi(String params) {
		String sql = this.sqlProperty.getProperty("KPI_002");
		Deal deal = (Deal) queryForObject(sql, null,new CommonRowMapper(new Deal()));
		return deal;
	}
	
	/**
	 * 交易场：现货，预售，中石化配送（今日）
	 * */
	@Override
	public List<Deal> getTradeTmptDealTodayKpi(String params) {
		String sql = this.sqlProperty.getProperty("KPI_00201");
		Object[] paramsa = null;
		List<Deal> deals = queryBySQL(sql, paramsa,null,new CommonRowMapper(new Deal()));
		return deals;
	}
	
	/**
	 * 取得某段日期内的交易列表（单数，吨数，金额）-总成交的月趋势图表
	 * */
	@Override
	public List<Deal> getDealListKpi(String params) {
		String sql = this.sqlProperty.getProperty("KPI_007");
		List<Deal> retList = null;
		
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.add(Calendar.DAY_OF_MONTH, -1);
		//上个月天数
		int days = cal.get(Calendar.DAY_OF_MONTH);
		
		Object[] paramsa = {days};
		retList = queryBySQL(sql, paramsa, null,new CommonRowMapper(new Deal()));
		return retList;
	}

	@Override
	public List<DealAssignStatus> getDealAssignStatus(String params) {
		String sql = this.sqlProperty.getProperty("KPI_003");
		List<DealAssignStatus> retList = null;
		Object[] paramsa = null;
		retList = queryBySQL(sql, paramsa, null, new CommonRowMapper(new DealAssignStatus()));
		return retList;
	}
	
	@Override
	public List<User> getAllTrader(String params) {
		String sql = this.sqlProperty.getProperty("KPI_004");
		List<User> retList = null;
		Object[] paramsa = null;
		retList = queryBySQL(sql, paramsa, null, new CommonRowMapper(new User()));
		return retList;
	}
	
	/**
	 * 最新一条卖家信息
	 * */
	@Override
	public List<Trader> getNewestSeller(String params) {
		String sql = this.sqlProperty.getProperty("KPI_00401");
		List<Trader> retList = null;
		Object[] paramsa = null;
		retList = queryBySQL(sql, paramsa, null, new CommonRowMapper(new Trader()));
		return retList;
	}
	
	@Override
	public List<User> getTodayTrader(String params) {
		String sql = this.sqlProperty.getProperty("KPI_005");
		List<User> retList = null;
		Object[] paramsa = null;
		retList = queryBySQL(sql, paramsa, null, new CommonRowMapper(new User()));
		return retList;
	}
	
	/**
	 * 每天新增交易商数量 / 用户数量
	 * */
	@Override
	public List<User> getDayNewlyTrader(String params) {
		String sql = this.sqlProperty.getProperty("KPI_00501");
		List<User> retList = null;
		
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.add(Calendar.DAY_OF_MONTH, -1);
		//上个月天数
		int days = cal.get(Calendar.DAY_OF_MONTH);
		Object[] paramsa = {days, days};
		retList = queryBySQL(sql, paramsa, null, new CommonRowMapper(new User()));
		return retList;
	}
	
	@Override
	public List<Trader> getActiveTrader(String params) {
		List<Trader> retList = new ArrayList<Trader>();
		String sql = this.sqlProperty.getProperty("KPI_00601");
		List<Trader> retList1 = null;
		Object[] paramsa = null;
		retList1 = queryBySQL(sql, paramsa, null, new CommonRowMapper(new Trader()));
		retList.addAll(retList1);
		
		String sql2 = this.sqlProperty.getProperty("KPI_00602");
		List<Trader> retList2 = null;
		retList2 = queryBySQL(sql, paramsa, null, new CommonRowMapper(new Trader()));
		retList.addAll(retList2);
		
		String sql3 = this.sqlProperty.getProperty("KPI_00603");
		List<Trader> retList3 = null;
		retList3 = queryBySQL(sql, paramsa, null, new CommonRowMapper(new Trader()));
		retList.addAll(retList3);
		
		return retList;
	}

	/**
	 * （运营）本月量化目标-成交量
	 * */
	@Override
	public KpiOperation getMonthTotalQuantity(int year, int month) {
		String sql = this.sqlProperty.getProperty("KPI_008");
		
		Object[] paramsa = {};
		List<KpiOperation> operations = queryBySQL(sql, paramsa, null,new CommonRowMapper(new KpiOperation()));
		return operations.get(0);
	}

	/**
	 * （运营）本月量化目标-月成交买家数
	 * */
	@Override
	public KpiOperation getMonthBuyFirmNums(int year, int month) {
		String sql = this.sqlProperty.getProperty("KPI_009");
		
		Object[] paramsa = {};
		List<KpiOperation> operations = queryBySQL(sql, paramsa, null,new CommonRowMapper(new KpiOperation()));
		return operations.get(0);
	}
	
	/**
	 * （运营）本月量化目标-重复成交买家数
	 * */
	@Override
	public KpiOperation getMonthRptBuyFirmNums(int year, int month) {
		String sql = this.sqlProperty.getProperty("KPI_010");
		
		Object[] paramsa = {};
		List<KpiOperation> operations = queryBySQL(sql, paramsa, null,new CommonRowMapper(new KpiOperation()));
		return operations.get(0);
	}
	
	/**
	 * （运营）本月量化目标-日均询盘数
	 * */
	@Override
	public KpiOperation getMonthAvgEnquiryNums(int days, int year, int month) {
		String sql = this.sqlProperty.getProperty("KPI_011");
		
		Object[] paramsa = {days, year, month};
		List<KpiOperation> operations = queryBySQL(sql, paramsa, null,new CommonRowMapper(new KpiOperation()));
		return operations.get(0);
	}
	
	/**
	 * （运营）本月量化目标值，数据持久化
	 * month format: 201701
	 * */
	@Override
	public List<KpiOperationTarget> getMonthOperationTarget(int year, int month) {
		String sql = this.sqlProperty.getProperty("KPI_012");
		int channelType = 1;  //化交
		Object[] paramsa = {channelType, year, month};
		List<KpiOperationTarget> targets = queryBySQL(sql, paramsa, null,new CommonRowMapper(new KpiOperationTarget()));
		return targets;
	}
	
	/**
	 * （物流）仓库数
	 * */
	@Override
	public List<KpiWareHouse> getWareHouseNums() {
		String sql = this.sqlProperty.getProperty("KPI_022");
		
		Object[] paramsa = {};
		List<KpiWareHouse> whs = queryBySQL(sql, paramsa, null,new CommonRowMapper(new KpiWareHouse()));
		return whs;
	}
	
	/**
	 * （物流）货代数
	 * */
	@Override
	public List<KpiCargoAgent> getCargoAgentNums() {
		String sql = this.sqlProperty.getProperty("KPI_023");
		
		Object[] paramsa = {};
		List<KpiCargoAgent> cas = queryBySQL(sql, paramsa, null,new CommonRowMapper(new KpiCargoAgent()));
		return cas;
	}
}
