package shcem.kpi.service;

public interface IKpiApiService {
	/*
	 * 数据请求
	 * */
	public String getKpiData(String params);
	
}
