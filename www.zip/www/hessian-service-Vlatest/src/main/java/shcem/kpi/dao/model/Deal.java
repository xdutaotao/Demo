package shcem.kpi.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

public class Deal extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 交易场：现货、预售、中石化配送
	 * */
	private String tradeTmptName;
	
	private BigDecimal TotalQuantity;
	private BigDecimal sumAmount;
	private int sumNumber;
	
	/**开始日期*/
	private Date beginDate;
	
	/**结束日期*/
	private Date endDate;
	
	/**日期*/
	private String date;
	
	public String getTradeTmptName() {
		return tradeTmptName;
	}

	public void setTradeTmptName(String tradeTmptName) {
		this.tradeTmptName = tradeTmptName;
	}

	public BigDecimal getTotalQuantity() {
		return TotalQuantity;
	}

	public void setTotalQuantity(BigDecimal totalQuantity) {
		TotalQuantity = totalQuantity;
	}

	public BigDecimal getSumAmount() {
		return sumAmount;
	}

	public void setSumAmount(BigDecimal sumAmount) {
		this.sumAmount = sumAmount;
	}

	public int getSumNumber() {
		return sumNumber;
	}

	public void setSumNumber(int sumNumber) {
		this.sumNumber = sumNumber;
	}

	public Date getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
