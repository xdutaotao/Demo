package shcem.kpi.dao.model;

import java.io.Serializable;

public class KpiActiveTrader implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// 交易商ID
	private String firmId;
	// 交易商名称
	private String firmName;
	// 原因
	private String reasonCode;
	// 原因名
	private String reason;

	public String getFirmId() {
		return firmId;
	}

	public void setFirmId(String firmId) {
		this.firmId = firmId;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

}
