package shcem.kpi.component.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import shcem.base.component.impl.BaseManager;
import shcem.constant.Constants;
import shcem.constant.DimDate;
import shcem.kpi.component.IKpiApiManager;
import shcem.kpi.dao.ICapitalKpiDAO;
import shcem.kpi.dao.IKpiDAO;
import shcem.kpi.dao.model.Deal;
import shcem.kpi.dao.model.DealAssignStatus;
import shcem.kpi.dao.model.Kpi;
import shcem.kpi.dao.model.KpiActiveTrader;
import shcem.kpi.dao.model.KpiBankAccount;
import shcem.kpi.dao.model.KpiCapital;
import shcem.kpi.dao.model.KpiCargoAgent;
import shcem.kpi.dao.model.KpiLogistics;
import shcem.kpi.dao.model.KpiOperation;
import shcem.kpi.dao.model.KpiOperationTarget;
import shcem.kpi.dao.model.KpiSubCapital;
import shcem.kpi.dao.model.KpiTrade;
import shcem.kpi.dao.model.KpiTrader;
import shcem.kpi.dao.model.KpiUser;
import shcem.kpi.dao.model.KpiWareHouse;
import shcem.kpi.dao.model.Trader;
import shcem.kpi.dao.model.User;
import shcem.util.CommonUtils;
import shcem.util.DateUtil;

public class KpiApiManagerImpl extends BaseManager implements IKpiApiManager {

	private IKpiDAO kpiDAO;
	private ICapitalKpiDAO capitalKpiDAO;
	
	public void setKpiDAO(IKpiDAO kpiDAO) {
		this.kpiDAO = kpiDAO;
	}

	public void setCapitalKpiDAO(ICapitalKpiDAO capitalKpiDAO) {
		this.capitalKpiDAO = capitalKpiDAO;
	}

	/**
	 * 今日成交
	 * 
	 * */
	@Override
	public Kpi getDealTodayKpiResponse(String type) throws Exception {
		this.log.info("getDealTodayKpiResponse start");
		Kpi kpi = new Kpi();
		Deal dealToday = kpiDAO.getDealTodayKpi(type);
		
		kpi.setTodaySumAmount(dealToday.getSumAmount());
		kpi.setTodaySumNumber(dealToday.getSumNumber());
		kpi.setTodayTotalQuantity(dealToday.getTotalQuantity());

		
		//按交易场
		List<Deal> tradeTmptDeals = kpiDAO.getTradeTmptDealTodayKpi(type);
		kpi.setDealList(tradeTmptDeals);
		
		this.log.info("getDealTodayKpiResponse end");
		return kpi;
	}
	
	/**
	 * 总成交
	 * 
	 * */
	@Override
	public Kpi getDealAllKpiResponse(String type) throws Exception {
		this.log.info("getDealAllKpiResponse start");
		Kpi kpi = new Kpi();

		Deal dealAll = kpiDAO.getDealAllKpi(type);
		
		kpi.setAllSumAmount(dealAll.getSumAmount());
		kpi.setAllSumNumber(dealAll.getSumNumber());
		kpi.setAllTotalQuantity(dealAll.getTotalQuantity());
		
		//按交易场
		List<Deal> tradeTmptDeals = kpiDAO.getTradeTmptDealAllKpi(type);
		kpi.setDealList2(tradeTmptDeals);
				
		//图表list(一月)
		List<Deal> dealList = kpiDAO.getDealListKpi(type);
		kpi.setDealList(dealList);
		
		this.log.info("getDealAllKpiResponse end");
		return kpi;
	}
	
	/**
	 * 用户
	 * 
	 * */
	@Override
	public Kpi getUserKpiResponse(String type) throws Exception {
		this.log.info("getUserKpiResponse start");
		Kpi kpi = new Kpi();
		KpiUser user = new KpiUser();
		
		//用户
		//List<DealAssignStatus> lstDealAssignSt = kpiDAO.getDealAssignStatus(type);
		List<User> lstUserAll = kpiDAO.getAllTrader(type);
		List<User> lstUserToday = kpiDAO.getTodayTrader(type);
		List<User> lstUserDayNewly = kpiDAO.getDayNewlyTrader(type);
		//List<Trader> lstActiveTrader = kpiDAO.getActiveTrader(type);

		// 当前交易商数量(买/卖) / 用户数
		setKpiAllTrader(lstUserAll, kpi, user);
		
		// 每日新增交易商数量 / 用户数量
		setKpiDayNewlyTrader(lstUserDayNewly, kpi, user);
		
		// 当日新增交易商数量 / 用户数量
		setKpiTodayTrader(lstUserToday, kpi, user);
		
		// 当日订单各个状态的计数 (前台)
		//setKpiDealAssignSt(lstDealAssignSt, kpi, user);
		
		// 月活交易商(成交或者询盘1次以上 或者 登录次数每月超过10次)
		//setKpiActiveTrader(lstActiveTrader, kpi, user);

		//最新一条卖家信息
		List<Trader> newestSeller = kpiDAO.getNewestSeller(type);
		user.setNewestSeller(newestSeller);
		
		this.log.info("getUserKpiResponse end");
		return kpi;
	}
	
	/**
	 * 运营
	 * 
	 * */
	@Override
	public Kpi getOperationKpiResponse(String type) throws Exception {
		this.log.info("getOperationKpiResponse start");
		
		Calendar cal =Calendar.getInstance();
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1;
		//成交量
		KpiOperation totalQuantityOps = kpiDAO.getMonthTotalQuantity(year, month);
		//月成交买家数
		KpiOperation buyFirmNumsOps = kpiDAO.getMonthBuyFirmNums(year, month);
		//重复成交买家数
		KpiOperation rptBuyFirmNumsOps = kpiDAO.getMonthRptBuyFirmNums(year, month);
		//日均询盘数
		int days = getWorkDayNumOfMonth(); //获取当天是第几个工作日
		KpiOperation avgEnquiryNumsOps = kpiDAO.getMonthAvgEnquiryNums(days, year, month);

		KpiOperation operation = new KpiOperation();
		operation.setTotalQuantity(totalQuantityOps.getTotalQuantity());//成交量
		operation.setBuyFirmNums(buyFirmNumsOps.getBuyFirmNums());//月成交买家数
		operation.setRptBuyFirmNums(rptBuyFirmNumsOps.getRptBuyFirmNums());//重复成交买家数
		operation.setAvgEnquiryNums(avgEnquiryNumsOps.getAvgEnquiryNums());//日均询盘数
		
		//月运营kpi目标预期值
		List<KpiOperationTarget> targets = kpiDAO.getMonthOperationTarget(Integer.valueOf(DateUtil.convert(new Date(), DateUtil.C_DATE_YEAR)), Integer.valueOf(DateUtil.convert(new Date(), DateUtil.C_DATE_MONTTH)));
		operation.setTargets(targets);
		
		Kpi kpi = new Kpi();
		kpi.setOperation(operation); //运营数据
		
		this.log.info("getOperationKpiResponse end");
		return kpi;
	}

	/**
	 * 资金（各银行的汇总入金资金明细）
	 * 
	 * */
	@Override
	public Kpi getCapitalKpiResponse(String type) throws Exception {
		this.log.info("getCapitalKpiResponse start");
		
		Kpi kpi = new Kpi();
		KpiCapital capital = new KpiCapital();
		//总历史资金情况
		List<KpiSubCapital> subCapitalList = capitalKpiDAO.getCapitalKpi(type); 
		
		BigDecimal inMoneyAmountAll = BigDecimal.ZERO;
		int inMoneyCountAll = 0;
		
		if (CommonUtils.isValidCollect(subCapitalList)) {
			for (KpiSubCapital sub : subCapitalList) {
				inMoneyAmountAll = inMoneyAmountAll.add(sub.getInMoneyAmount());
				inMoneyCountAll += sub.getInMoneyCount();
			}
		}
		
		//各银行资金情况
		capital.setSubCapitalList(subCapitalList);

		//今日资金
		capital.setInMoneyAmountAll(inMoneyAmountAll);
		capital.setInMoneyCountAll(inMoneyCountAll);
	
		
		int openCountsAll = 0;
		//开户信息
		List<KpiBankAccount> accounts = capitalKpiDAO.getOpenAccCountsKpi(type);
		if (CommonUtils.isValidCollect(accounts)) {
			for (KpiBankAccount acc : accounts) {
				openCountsAll += acc.getOpenCounts();
			}
		}
		capital.setBankAccts(accounts);
		capital.setOpenCountsAll(openCountsAll);
		
		kpi.setCapital(capital); //资金数据
		
		this.log.info("getCapitalKpiResponse end");
		return kpi;
	}
	
	/**
	 * 物流
	 * 
	 * */
	@Override
	public Kpi getLogisticsKpiResponse(String type) throws Exception {
		this.log.info("getLogisticsKpiResponse start");
		
		Kpi kpi = new Kpi();
		KpiLogistics logistics = new KpiLogistics();

		//仓库
		List<KpiWareHouse> whList = kpiDAO.getWareHouseNums();
		logistics.setWhList(whList);
		
		//货代
		List<KpiCargoAgent> caList = kpiDAO.getCargoAgentNums();
		logistics.setCaList(caList);
		
		kpi.setLogistics(logistics);
		
		this.log.info("getLogisticsKpiResponse end");
		return kpi;
	}
	
	/**
	 * 资金（每天各银行的入金资金明细）
	 * 
	 * */
//	@Override
//	public Kpi getCapitalKpiResponse(String type) throws Exception {
//		this.log.info("getCapitalKpiResponse start");
//		
//		Kpi kpi = new Kpi();
//		KpiCapital capital = new KpiCapital();
//		//总历史资金情况
//		List<KpiSubCapital> subCapitalList = capitalKpiDAO.getCapitalKpi(type); 
//		
//		//从总历史资金里过滤出今日资金情况
//		List<KpiSubCapital> todayCapitalList = new ArrayList<KpiSubCapital>();
//
//		BigDecimal inMoneyAmountToday = BigDecimal.ZERO;
//		int inMoneyCountToday = 0;
//		
//		List<KpiSubCapital> fullCapitalList = new ArrayList<KpiSubCapital>();
//		
//		//获取银行名称合集
//		List<String> bankNameList = new ArrayList<String>();
//		//获取入金日期合集
//		List<String> createDateList = new ArrayList<String>();
//		
//		if (CommonUtils.isValidCollect(subCapitalList)) {
//			
//			//从总历史资金里过滤出今日资金情况
//			KpiSubCapital today = null;
//			for (KpiSubCapital sub : subCapitalList) {
//				//过滤今日日期数据
//				if (sub.getCreatetime().equals(DateUtil.convert(new Date(), DateUtil.C_DATE_PATTERN_DEFAULT))) {
//					today = new KpiSubCapital();
//					CommonUtils.copyItems(sub, today);
//					todayCapitalList.add(today);
//					inMoneyAmountToday = inMoneyAmountToday.add(today.getInMoneyAmount());
//					inMoneyCountToday += today.getInMoneyCount();
//				}
//			}
//			capital.setTodayCapitalList(todayCapitalList);
//			//今日资金
//			capital.setInMoneyAmountToday(inMoneyAmountToday);
//			capital.setInMoneyCountToday(inMoneyCountToday);
//			
//			//生成bankName和createDate全集
//			for (KpiSubCapital sub : subCapitalList) {
//				Boolean nameFlag = true;
//				for (String name :bankNameList) {
//					if (name.equals(sub.getBankName())) {
//						nameFlag = false;
//						break;
//					}
//				}
//				if (nameFlag) bankNameList.add(sub.getBankName());
//				
//				Boolean dateFlag = true;
//				for (String date :createDateList) {
//					if (date.equals(sub.getCreatetime())) {
//						dateFlag = false;
//						break;
//					}
//				}
//				if (dateFlag) createDateList.add(sub.getCreatetime());
//			}
//			
//			capital.setBankNameList(bankNameList);
//			capital.setCreatetimeList(createDateList);
//			
//			//生成全，但是空的list表
//			KpiSubCapital cap = null;
//			for (String bankName : bankNameList) {
//				for (String createDate : createDateList) {
//					cap = new KpiSubCapital();
//					cap.setBankName(bankName);
//					cap.setCreatetime(createDate);
//					cap.setInMoneyAmount(BigDecimal.ZERO);
//					cap.setInMoneyCount(0);
//					
//					fullCapitalList.add(cap);
//				}
//			}
//			
//			//赋值给全，但是空的list
//			KpiSubCapital subCap = null;
//			for (KpiSubCapital emptyCap : fullCapitalList) {
//				for (int index = 0; index < subCapitalList.size(); index++) {
//					subCap = subCapitalList.get(index);
//					if (emptyCap.getBankName().equals(subCap.getBankName()) 
//							&& emptyCap.getCreatetime().equals(subCap.getCreatetime())) {
//						emptyCap.setInMoneyAmount(subCap.getInMoneyAmount());
//						emptyCap.setInMoneyCount(subCap.getInMoneyCount());
//						
//						subCapitalList.remove(index);
//					}
//				}
//			}
//		}
//		
//		//各银行资金情况
//		capital.setSubCapitalList(fullCapitalList);
//
//		kpi.setCapital(capital); //资金数据
//		
//		this.log.info("getCapitalKpiResponse end");
//		return kpi;
//	}
	
	/**
	 * 获取当天是该月第几个工作日
	 * */
	private int getWorkDayNumOfMonth() {
		
		int days = 22; //默认
		try {
			String today = DateUtil.convert(new Date(), DateUtil.C_DATA_PATTERN_YYYYMMDD);
			days = Integer.parseInt(DimDate.workDayMap.get(today)[1].toString());
			
			if (days == 0) days = 1;
		} catch (Exception ex) {
			days = 22;
			ex.printStackTrace();
			log.error("方法异常：获取当天是该月第几个工作日 ");
			log.error(ex.getMessage());
		}
		return days;
	}
	
	/**
	 * 当日订单各个状态的计数 (前台)
	 * @param lstDealAssignSt
	 * @param kpi
	 */
	private void setKpiDealAssignSt(List<DealAssignStatus> lstDealAssignSt, Kpi kpi, KpiUser user) {
		
		List<KpiTrade> lstKpiTrade = new ArrayList<KpiTrade>();
		boolean bolData = false;
		for (int i = 0; i < lstDealAssignSt.size(); i++) {
			DealAssignStatus trade = lstDealAssignSt.get(i);
			KpiTrade kpiTrade = new KpiTrade();
			bolData = false;

			if (Constants.KPI_WAITBUYER_PAY.equals(trade.getTradeStatus())) {
				bolData = true;
				kpiTrade.setTradeStatusName(Constants.KPI_WAITBUYER_PAY_Name);
			}
			if (Constants.KPI_BUYERPAYED.equals(trade.getTradeStatus())) {
				bolData = true;
				kpiTrade.setTradeStatusName(Constants.KPI_BUYERPAYED_Name);
			}
			if (Constants.KPI_DELIVERING.equals(trade.getTradeStatus())) {
				bolData = true;
				kpiTrade.setTradeStatusName(Constants.KPI_DELIVERING_NAME);
			}
			if (Constants.KPI_BID_TOSELLER.equals(trade.getTradeStatus())) {
				bolData = true;
				kpiTrade.setTradeStatusName(Constants.KPI_BID_TOSELLER_NAME);
			}
			if (Constants.KPI_RECEIVER_UPED.equals(trade.getTradeStatus())) {
				bolData = true;
				kpiTrade.setTradeStatusName(Constants.KPI_RECEIVER_UPED_NAME);
			}
			if (Constants.KPI_DELIVERYCONFIMED.equals(trade.getTradeStatus())) {
				bolData = true;
				kpiTrade.setTradeStatusName(Constants.KPI_DELIVERYCONFIMED_NAME);
			}
			if (Constants.KPI_WAITRISK_CONFIRM.equals(trade.getTradeStatus())) {
				bolData = true;
				kpiTrade.setTradeStatusName(Constants.KPI_WAITRISK_CONFIRM_NAME);
			}
			if (Constants.KPI_RISK_DENIED.equals(trade.getTradeStatus())) {
				bolData = true;
				kpiTrade.setTradeStatusName(Constants.KPI_RISK_DENIED_NAME);
			}
			if (Constants.KPI_WAITSELLER_CONFIRM.equals(trade.getTradeStatus())) {
				bolData = true;
				kpiTrade.setTradeStatusName(Constants.KPI_WAITSELLER_CONFIRM_NAME);
			}
			if (Constants.KPI_MOREORLESS.equals(trade.getTradeStatus())) {
				bolData = true;
				kpiTrade.setTradeStatusName(Constants.KPI_MOREORLESS_NAME);
			}
			if (Constants.KPI_FINISHED.equals(trade.getTradeStatus())) {
				bolData = true;
				kpiTrade.setTradeStatusName(Constants.KPI_FINISHED_NAME);
			}
			if (Constants.KPI_BUYER_BREAK.equals(trade.getTradeStatus())) {
				bolData = true;
				kpiTrade.setTradeStatusName(Constants.KPI_BUYER_BREAK_NAME);
			}
			if (Constants.KPI_SELLER_BREAK.equals(trade.getTradeStatus())) {
				bolData = true;
				kpiTrade.setTradeStatusName(Constants.KPI_SELLER_BREAK_NAME);
			}
			
			if (bolData) {
				kpiTrade.setNumber(trade.getNumbers());
				kpiTrade.setTradeStatus(trade.getTradeStatus());
			}
			
			lstKpiTrade.add(kpiTrade);
		}
		user.setLstTrade(lstKpiTrade);
		kpi.setUser(user);
	}
	
	/**
	 * 月活交易商(成交或者询盘1次以上 或者 登录次数每月超过10次)
	 * @param lstActiveTrader
	 * @param kpi
	 */
	private void setKpiActiveTrader(List<Trader> lstActiveTrader, Kpi kpi, KpiUser user) {
		
		List<KpiActiveTrader> lstKpiActivie = new ArrayList<KpiActiveTrader>();
		boolean bolData = false;
		for (int i = 0; i < lstActiveTrader.size(); i++) {
			Trader trader = lstActiveTrader.get(i);
			KpiActiveTrader kpiTrader = new KpiActiveTrader();
			bolData = false;

			if (Constants.KPI_DEAL.equals(trader.getReason())) {
				bolData = true;
				kpiTrader.setReasonCode(Constants.KPI_DEAL_NAME);
			}
			if (Constants.KPI_REQUEST.equals(trader.getReason())) {
				bolData = true;
				kpiTrader.setReasonCode(Constants.KPI_REQUEST_NAME);
			}
			if (Constants.KPI_LOGIN.equals(trader.getReason())) {
				bolData = true;
				kpiTrader.setReasonCode(Constants.KPI_LOGIN_NAME);
			}
			
			if (bolData) {
				kpiTrader.setFirmId(trader.getFirmID());
				kpiTrader.setFirmName(trader.getFirmName());
				kpiTrader.setReason(trader.getReason());
			}
			
			lstKpiActivie.add(kpiTrader);
		}
		user.setLstActiveTrader(lstKpiActivie);
		kpi.setUser(user);
	}
	
	/**
	 * 当前交易商数量(买/卖) / 用户数
	 * @param lstActiveTrader
	 * @param kpi
	 */
	private void setKpiAllTrader(List<User> lstUserAll, Kpi kpi, KpiUser user) {
		
		List<KpiTrader> lstKpi = new ArrayList<KpiTrader>();
		boolean bolData = false;
		for (int i = 0; i < lstUserAll.size(); i++) {
			User trader = lstUserAll.get(i);
			KpiTrader kpiTrader = new KpiTrader();
			bolData = false;

			if (Constants.KPI_SELLER_TRADER.equals(trader.getTradeAuthority())) {
				bolData = true;
				kpiTrader.setUserName(Constants.KPI_SELLER_TRADER_NAME);
			}
			if (Constants.KPI_BUYER_TRADER.equals(trader.getTradeAuthority())) {
				bolData = true;
				kpiTrader.setUserName(Constants.KPI_BUYER_TRADER_NAME);
			}
			if (Constants.KPI_BOTH_TRADER.equals(trader.getTradeAuthority())) {
				bolData = true;
				kpiTrader.setUserName(Constants.KPI_BOTH_TRADER_NAME);
			}
			if (Constants.KPI_User.equals(trader.getTradeAuthority())) {
				bolData = true;
				kpiTrader.setUserName(Constants.KPI_User_NAME);
			}
			
			if (bolData) {
				kpiTrader.setNumber(trader.getNumbers());
				kpiTrader.setUserCode(trader.getTradeAuthority());
			}
			
			lstKpi.add(kpiTrader);
		}
		user.setLstAllTrader(lstKpi);
		kpi.setUser(user);
	}

	/**
	 * 当日交易商数量(买/卖) / 用户数
	 * @param lstActiveTrader
	 * @param kpi
	 */
	private void setKpiTodayTrader(List<User> lstUserToday, Kpi kpi, KpiUser user) {
		
		List<KpiTrader> lstKpi = new ArrayList<KpiTrader>();
		boolean bolData = false;
		for (int i = 0; i < lstUserToday.size(); i++) {
			User trader = lstUserToday.get(i);
			KpiTrader kpiTrader = new KpiTrader();
			bolData = false;

			if (Constants.KPI_SELLER_TRADER.equals(trader.getTradeAuthority())) {
				bolData = true;
				kpiTrader.setUserName(Constants.KPI_SELLER_TRADER_NAME);
			}
			if (Constants.KPI_BUYER_TRADER.equals(trader.getTradeAuthority())) {
				bolData = true;
				kpiTrader.setUserName(Constants.KPI_BUYER_TRADER_NAME);
			}
			if (Constants.KPI_BOTH_TRADER.equals(trader.getTradeAuthority())) {
				bolData = true;
				kpiTrader.setUserName(Constants.KPI_BOTH_TRADER_NAME);
			}
			if (Constants.KPI_User.equals(trader.getTradeAuthority())) {
				bolData = true;
				kpiTrader.setUserName(Constants.KPI_User_NAME);
			}
			
			if (bolData) {
				kpiTrader.setNumber(trader.getNumbers());
				kpiTrader.setUserCode(trader.getTradeAuthority());
			}
			
			lstKpi.add(kpiTrader);
		}
		user.setLstTodayTrader(lstKpi);
		kpi.setUser(user);
	}
	/**
	 * 每日交易商数量(买/卖) / 用户数
	 * @param lstActiveTrader
	 * @param kpi
	 */
	private void setKpiDayNewlyTrader(List<User> lstUserDayNewly, Kpi kpi, KpiUser user) {
		
		List<KpiTrader> lstKpi = new ArrayList<KpiTrader>();
		boolean bolData = false;
		for (int i = 0; i < lstUserDayNewly.size(); i++) {
			User trader = lstUserDayNewly.get(i);
			KpiTrader kpiTrader = new KpiTrader();
			bolData = false;

			if (Constants.KPI_SELLER_TRADER.equals(trader.getTradeAuthority())) {
				bolData = true;
				kpiTrader.setUserName(Constants.KPI_SELLER_TRADER_NAME);
			}
			if (Constants.KPI_BUYER_TRADER.equals(trader.getTradeAuthority())) {
				bolData = true;
				kpiTrader.setUserName(Constants.KPI_BUYER_TRADER_NAME);
			}
			if (Constants.KPI_BOTH_TRADER.equals(trader.getTradeAuthority())) {
				bolData = true;
				kpiTrader.setUserName(Constants.KPI_BOTH_TRADER_NAME);
			}
			if (Constants.KPI_User.equals(trader.getTradeAuthority())) {
				bolData = true;
				kpiTrader.setUserName(Constants.KPI_User_NAME);
			}
			
			if (bolData) {
				kpiTrader.setNumber(trader.getNumbers());
				kpiTrader.setUserCode(trader.getTradeAuthority());
				kpiTrader.setDate(trader.getDate());
			}
			
			lstKpi.add(kpiTrader);
		}
		user.setLstDayNewlyTrader(lstKpi);
		kpi.setUser(user);
	}
}
