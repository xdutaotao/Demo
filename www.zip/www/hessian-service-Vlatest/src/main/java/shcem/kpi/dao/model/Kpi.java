package shcem.kpi.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public class Kpi implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// 当前总成交吨数
	private BigDecimal AllTotalQuantity;
	// 当前总成交金额
	private BigDecimal AllSumAmount;
	// 当前总成交单数
	private int AllSumNumber;
	// 当日总成交吨数
	private BigDecimal TodayTotalQuantity;
	// 当日总成交金额
	private BigDecimal TodaySumAmount;
	// 当日总成交单数
	private int TodaySumNumber;

	//交易列表
	private List<Deal> dealList;
	
	//交易列表（总成交按交易场）
	private List<Deal> dealList2;
	
	//运营
	private KpiOperation operation;
	
	//资金
	private KpiCapital capital;
	
	//物流
	private KpiLogistics logistics;
	
	//用户
	private KpiUser user;
	
	public BigDecimal getAllTotalQuantity() {
		return AllTotalQuantity;
	}

	public KpiLogistics getLogistics() {
		return logistics;
	}

	public void setLogistics(KpiLogistics logistics) {
		this.logistics = logistics;
	}

	public void setAllTotalQuantity(BigDecimal allTotalQuantity) {
		AllTotalQuantity = allTotalQuantity;
	}

	public BigDecimal getAllSumAmount() {
		return AllSumAmount;
	}

	public void setAllSumAmount(BigDecimal allSumAmount) {
		AllSumAmount = allSumAmount;
	}

	public int getAllSumNumber() {
		return AllSumNumber;
	}

	public void setAllSumNumber(int allSumNumber) {
		AllSumNumber = allSumNumber;
	}

	public BigDecimal getTodayTotalQuantity() {
		return TodayTotalQuantity;
	}

	public void setTodayTotalQuantity(BigDecimal todayTotalQuantity) {
		TodayTotalQuantity = todayTotalQuantity;
	}

	public BigDecimal getTodaySumAmount() {
		return TodaySumAmount;
	}

	public void setTodaySumAmount(BigDecimal todaySumAmount) {
		TodaySumAmount = todaySumAmount;
	}

	public int getTodaySumNumber() {
		return TodaySumNumber;
	}

	public void setTodaySumNumber(int todaySumNumber) {
		TodaySumNumber = todaySumNumber;
	}

	public List<Deal> getDealList() {
		return dealList;
	}

	public void setDealList(List<Deal> dealList) {
		this.dealList = dealList;
	}

	public KpiOperation getOperation() {
		return operation;
	}

	public void setOperation(KpiOperation operation) {
		this.operation = operation;
	}

	public KpiCapital getCapital() {
		return capital;
	}

	public void setCapital(KpiCapital capital) {
		this.capital = capital;
	}

	public List<Deal> getDealList2() {
		return dealList2;
	}

	public void setDealList2(List<Deal> dealList2) {
		this.dealList2 = dealList2;
	}

	public KpiUser getUser() {
		return user;
	}

	public void setUser(KpiUser user) {
		this.user = user;
	}

}
