package shcem.kpi.dao.model;

import java.io.Serializable;

public class KpiTrader implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// 交易商/用户区分
	private String UserCode;
	private String UserName;

	// 数量
	private int number;

	/**日期*/
	private String date;
	
	public String getUserCode() {
		return UserCode;
	}

	public void setUserCode(String userCode) {
		UserCode = userCode;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

}
