package shcem.kpi.component;

import shcem.kpi.dao.model.Kpi;
import shcem.kpi.dao.model.KpiOperation;


public abstract interface IKpiApiManager {
	
	/**
	 * 今日成交
	 * 
	 * */
	public abstract Kpi getDealTodayKpiResponse(String type) throws Exception;

	/**
	 * 总成交
	 * 
	 * */
	public abstract Kpi getDealAllKpiResponse(String type) throws Exception;

	/**
	 * 用户
	 * 
	 * */
	public abstract  Kpi getUserKpiResponse(String type) throws Exception;

	/**
	 * 运营
	 * 
	 * */
	public abstract Kpi getOperationKpiResponse(String type) throws Exception;

	/**
	 * 资金
	 * 
	 * */
	public abstract Kpi getCapitalKpiResponse(String type) throws Exception;

	/**
	 * 物流
	 * 
	 * */
	public abstract Kpi getLogisticsKpiResponse(String type) throws Exception;
	
}
