package shcem.kpi.dao.impl;

import java.util.List;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.kpi.dao.ICapitalKpiDAO;
import shcem.kpi.dao.model.KpiBankAccount;
import shcem.kpi.dao.model.KpiSubCapital;
import shcem.util.CommonRowMapper;

public class CapitalKpiDAOImpl extends BaseDAOImpl implements ICapitalKpiDAO {

	@Override
	public List<KpiSubCapital> getCapitalKpi(String params) {
		String sql = this.sqlProperty.getProperty("KPI_020");
		Object[] paramsa = null;
		List<KpiSubCapital> capitals = queryBySQL(sql, paramsa, null, new CommonRowMapper(new KpiSubCapital()));
		return capitals;
	}

	@Override
	public List<KpiBankAccount> getOpenAccCountsKpi(String params) {
		String sql = this.sqlProperty.getProperty("KPI_021");
		Object[] paramsa = null;
		List<KpiBankAccount> accounts = queryBySQL(sql, paramsa, null, new CommonRowMapper(new KpiBankAccount()));
		return accounts;
	}
}
