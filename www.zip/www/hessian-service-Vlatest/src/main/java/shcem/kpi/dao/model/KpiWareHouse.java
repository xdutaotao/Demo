package shcem.kpi.dao.model;

import java.io.Serializable;

import shcem.base.dao.model.BaseObject;

public class KpiWareHouse extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 省名称
	 * */
	private String pvName;
	
	/**
	 * 仓库数
	 * */
	private int whNums;

	public String getPvName() {
		return pvName;
	}

	public void setPvName(String pvName) {
		this.pvName = pvName;
	}

	public int getWhNums() {
		return whNums;
	}

	public void setWhNums(int whNums) {
		this.whNums = whNums;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
