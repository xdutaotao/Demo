package shcem.kpi.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;

import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.constant.ResultCode;
import shcem.kpi.component.IKpiApiManager;
import shcem.kpi.dao.model.Kpi;
import shcem.kpi.service.IKpiApiService;
import shcem.kpi.util.Encryption;
import shcem.kpi.util.KpiSys;
import shcem.util.JsonUtil;


public class KpiApiServiceImpl extends BaseServiceImpl implements IKpiApiService {

	private IKpiApiManager mgr = (IKpiApiManager) KpiSys.getBean(Constants.BEAN_KPI_API_MGR);
    
	/*
	 * 获取kpi数据
	 * {"json":{"ServiceName":"shcem.kpi.service.IKpiApiService","MethodName":"getKpiData","Params":"{\"code\":\"6360490281069330810\"}","authkeyid":"a_"}}
	 * */
	@Override
	public String getKpiData(String params) {
		
		this.log.info("kpiService dataRequest method start");
		JSONObject jsonRequest = new JSONObject(params);
		
		Kpi kpi = new Kpi();
		String code = jsonRequest.getString("code");
		int type = jsonRequest.getInt("type");  //1: 今日成交   2： 总成交   3： 用户
		if (StringUtils.isEmpty(code) || !code.equals(Encryption.EncryptionStr(Constants.DES_KEY2,Encryption.MD5))) {
			setResultData(ResultCode.CODE10101.getValue(), null, "验证失败，非法访问！");
		} else {
			try {
				JSONObject json = new JSONObject();
				JSONObject opsJson = null;
				JSONObject captJson = null;
				JSONObject logtJson = null;
				JSONObject userJson = null;
				
				if (type == 1) { //1: 今日成交
					kpi = mgr.getDealTodayKpiResponse(params);
				} else if (type == 2) { //2： 运营
					kpi = mgr.getOperationKpiResponse(params);
					opsJson = JsonUtil.coverModelToJSONObject(kpi.getOperation());
				} else if (type == 3) { //3： 总成交 
					kpi = mgr.getDealAllKpiResponse(params);
				} else if (type == 4) { //4： 用户
					kpi = mgr.getUserKpiResponse(params);
					userJson = JsonUtil.coverModelToJSONObject(kpi.getUser());
				} else if (type == 5) { //5：资金
					kpi = mgr.getCapitalKpiResponse(params);
					captJson = JsonUtil.coverModelToJSONObject(kpi.getCapital());
				} else if (type == 6) { //6：物流
					kpi = mgr.getLogisticsKpiResponse(params);
					logtJson = JsonUtil.coverModelToJSONObject(kpi.getLogistics());
				} else {
					setResultData(ResultCode.CODE10101.getValue(), null, "传入参数有误");
					this.log.info("传入参数有误， type=" + type);
					return rtnData.toString();
				}
				
				json = JsonUtil.coverModelToJSONObject(kpi);
				
				if (userJson != null) json.put("user", userJson);
				if (opsJson != null) json.put("operation", opsJson);
				if (captJson != null) json.put("capital", captJson);
				if (logtJson != null) json.put("logistics", logtJson);
				
				setResultData(ResultCode.CODE00000.getValue(), json);
			} catch (Exception e) {
				e.printStackTrace();
				setResultData(ResultCode.CODE10101.getValue(), null, "kpi信息查询失败");
				this.log.info(e.getMessage());
				return rtnData.toString();
			}
		}
		
		this.log.info("kpiService dataRequest method end");
		return rtnData.toString();
	}
	
}
