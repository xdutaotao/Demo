package shcem.kpi.dao;

import shcem.base.dao.DAO;
import shcem.kpi.dao.model.Deal;

public abstract interface IDingDAO extends DAO {
	/**
	 * 获取’今日成交‘kpi
	 * */
	public abstract Deal getDealTodayKpi(String params) ;

}
