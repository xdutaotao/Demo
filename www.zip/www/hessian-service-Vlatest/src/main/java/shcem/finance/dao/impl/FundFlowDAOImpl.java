package shcem.finance.dao.impl;

import java.util.List;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.FundFlowDAO;
import shcem.finance.dao.model.FinancialBills;
import shcem.finance.dao.model.FundflowServiceModel;
import shcem.util.CommonRowMapper;

public class FundFlowDAOImpl extends BaseDAOImpl implements FundFlowDAO{

	@Override
	public List<FundflowServiceModel> getFundFlowList(QueryConditions qc,
			PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("FundFlowDAO_001");
		List<FundflowServiceModel> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new FundflowServiceModel()));
		return list;
	}
	/**
	 * financialBillsType开票状态 1：未申请  2：待财务处理 3：处理完成
	 */
	@Override
	public List<FinancialBills> getFinancialBillsList(QueryConditions qc,
			PageInfo pageInfo,int financialBillsType) {
		String sql;
		if(financialBillsType == 2){
			sql = this.sqlProperty.getProperty("FinancialBillsDAO_001")+" where 1=1";
		}else if(financialBillsType == 3) {
			sql = this.sqlProperty.getProperty("FinancialBillsDAO_001")+" where 1=1";
		}else {
			sql = this.sqlProperty.getProperty("FinancialBillsDAO_001")+" where 1=1";
		}
		List<FinancialBills> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new FinancialBills()));
		return list;
	}
}
