/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmBanlanceOraManagerImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.component.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.component.IFirmBanlanceOraManager;
import shcem.finance.dao.FirmBanlanceOraDAO;
import shcem.finance.dao.model.FirmBanlanceListForOra;
import shcem.finance.dao.model.FirmForOra;
import shcem.finance.dao.model.FirmModuleForOra;
import shcem.finance.dao.model.FirmTradeFeeForOra;
import shcem.member.dao.model.FirmDetaiData;

/**
 * FirmBanlanceOraManagerImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class FirmBanlanceOraManagerImpl extends BaseManager implements IFirmBanlanceOraManager {
	private FirmBanlanceOraDAO dao;

	public void setFirmBanlanceOraDAO(FirmBanlanceOraDAO dao) {
		this.dao = dao;
	}

	@Override
	public List<FirmBanlanceListForOra> queryFirmBanlance(QueryConditions qc, PageInfo pageInfo) {
		return this.dao.queryFirmBanlance(qc, pageInfo);
	}

	@Override
	public List<FirmTradeFeeForOra> queryFirmTradeFee(QueryConditions qc, PageInfo pageInfo, String firmName) {
		return this.dao.queryFirmTradeFee(qc, pageInfo, firmName);
	}
	public static void main(String[] args) {
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println(dateFormat.format(date));
	}
	
	@Override
	public int addFirmForOra(String firmId, String firmName,FirmDetaiData firmDetaiData) {
		int result = 0;

		FirmForOra firm = new FirmForOra();
		this.setFirmForOraProperty(firm,firmDetaiData);
		
		try {
			if (dao.verifyRepeat(firmId) > 0) {
				this.log.debug("dao.verifyRepeat end");
				// 此交易商已经存在
				result = -1;
				return result;
			}

			dao.createFirm(firm);
			this.log.debug("dao.createFirm end");
			List modulList = dao.getTradeModuleList();
			this.log.debug("dao.getTradeModuleList end");
			if (modulList != null) {
				for (int i = 0; i < modulList.size(); i++) {
					String moduleId = (String) ((Map) modulList.get(i)).get("MODULEID");
					FirmModuleForOra firmModule = new FirmModuleForOra();
					firmModule.setFirmId(firmId);
					firmModule.setEnabled("N");
					firmModule.setModuleId(moduleId);
					this.dao.addFirmModule(firmModule);
					this.log.debug("this.dao.addFirmModule end");
				}
			}

			result = dao.addFirm(firmId);
			this.log.debug("dao.addFirm end");
		} catch (Exception e) {
			this.log.debug("Exception e = " + e.getMessage());
			result = -1;
		}
		this.log.debug("result = " + result);
		if (result == -1) {
			this.dao.rollBack();
		}
		return result;
	}

	private void setFirmForOraProperty(FirmForOra firm,
			FirmDetaiData firmDetaiData) {
		/**交易商编号*/
		firm.setFirmId(firmDetaiData.getFirmID());
		/**交易商简称*/
		firm.setName(firmDetaiData.getFirmName());
		/**交易商全称*/
		firm.setFullname(firmDetaiData.getFullName()==null?"":firmDetaiData.getFullName());
		/**企业类型 1-法人 2-代理*/
		firm.setType(1);
		/**开票银行*/
		firm.setBank(firmDetaiData.getVatBkBranch()==null?"":firmDetaiData.getVatBkBranch());
		/**交易商状态 N-非禁用 D-禁用*/
		firm.setStatus('N');
		/**开票银行账号*/
		firm.setBankAccount(firmDetaiData.getVatBkAccount()==null?"":firmDetaiData.getVatBkAccount());
		/**开票地址(加：省市区)*/
		firm.setAddress(firmDetaiData.getVatAddress()==null?"":firmDetaiData.getVatAddress());
		/**联系人*/
		firm.setContactMan(firmDetaiData.getContactName()==null?"":firmDetaiData.getContactName());
		/**开票电话*/
		firm.setPhone(firmDetaiData.getVatContactTelNo()==null?"":firmDetaiData.getVatContactTelNo());
		/**企业传真*/
		firm.setFax(firmDetaiData.getFax()==null?"":firmDetaiData.getFax());
		/**开票地址邮编*/
		firm.setPostCode(firmDetaiData.getPostCode()==null?"":firmDetaiData.getPostCode());
		/**企业Email*/
		firm.setEmail(firmDetaiData.getContactEmail()==null?"":firmDetaiData.getContactEmail());
		/**备注*/
		firm.setNote(firmDetaiData.getNote()==null?"":firmDetaiData.getNote());
		/**ZONECODE*/
		firm.setZoneCode("");
		/**INDUSTRYCODE*/
		firm.setIndustryCode("");
		/**EXTENDDATA*/
		firm.setExtendData(getToXml(firmDetaiData));
	}
	
	private String getToXml(FirmDetaiData firmDetaiData) {
		Map<String, String> extendMap = new HashMap<String, String>();
		/**交易商编号*/
		extendMap.put("FirmID",firmDetaiData.getFirmID()==null?"":firmDetaiData.getFirmID());
		/**收票人*/
		extendMap.put("businessContacter","");
		/**营业执照号*/
		extendMap.put("businessLicenseNo", firmDetaiData.getBSLicenseNo()==null?"":firmDetaiData.getBSLicenseNo());
		/**经营业务范围 :收票地址 + ' '+收票人电话*/
		extendMap.put("businessScope", "");
		/**联系人电话*/
		extendMap.put("ContacterPhoneNo", firmDetaiData.getContactMobile()==null?"":firmDetaiData.getContactMobile());
		/**企业性质*/
		extendMap.put("enterpriseKind", "");
		/**法定代表人*/
		extendMap.put("legalRepresentative", firmDetaiData.getBSEntityName()==null?"":firmDetaiData.getBSEntityName());
		/**法人手机号码*/
		extendMap.put("LRphoneNo",firmDetaiData.getBSEntityTelNo()==null?"":firmDetaiData.getBSEntityTelNo());
		/**组织机构代码*/
		extendMap.put("organizationCode", firmDetaiData.getOrganizationCd()==null?"":firmDetaiData.getOrganizationCd());
		/**注册资金*/
		extendMap.put("registeredCapital", firmDetaiData.getRegisterCapiTal()==null?"":firmDetaiData.getRegisterCapiTal());
		/**税务登记号*/
		extendMap.put("taxRegistrationNo", firmDetaiData.getTaxNo()==null?"":firmDetaiData.getTaxNo());
		
		extendMap.put("STATUS", "");
		
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		extendMap.put("CREATEON",dateFormat.format(date));
		
		 /*证照区分	0: 三证，1:综合证*/
		if(firmDetaiData.getLicenseDiffer() == 0){
			/*营业执照号*/
			extendMap.put("businessLicenseNo", firmDetaiData.getBSLicenseNo()==null?"":firmDetaiData.getBSLicenseNo());
		}else if (firmDetaiData.getLicenseDiffer() == 1) {
			/*企业综合证号(三证合一才有)*/
			extendMap.put("businessLicenseNo", firmDetaiData.getUnifyLicenseNo()==null?"":firmDetaiData.getUnifyLicenseNo());
		}
		
		Set set = extendMap.entrySet();
		Iterator i = set.iterator();
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GBK");
		Element booksElement = document.addElement("root");
		while (i.hasNext()) {
			Map.Entry me = (Map.Entry) i.next();
			Element oElement = booksElement.addElement("keyValue");
			Element oElement1 = oElement.addElement("key");
			oElement1.addCDATA(me.getKey().toString());
			Element oElement2 = oElement.addElement("value");
			oElement2.addCDATA(me.getValue().toString());
		}

		String result = document.asXML();
		return result;
	}

	@Override
	public int checkFirmForOra(String firmId) {
		if (dao.verifyRepeat(firmId) > 0) {
			// 此交易商已经存在
			return -1;
		} else {
			return 0;
		}
	}
	
	@Override
	public int queryFirmTradeFeeCount(QueryConditions qc, Object object,
			String firmName) {
		this.log.info(this.getClass().getName()+" queryFirmTradeFeeCount Start");
		int totalCount = this.dao.queryFirmTradeFeeCount(qc,firmName);
		this.log.info(this.getClass().getName()+" queryFirmTradeFeeCount End");
		return totalCount;
	}
}
