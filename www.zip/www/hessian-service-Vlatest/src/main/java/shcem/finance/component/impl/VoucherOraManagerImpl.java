/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: VoucherOraManagerImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.component.impl;

import shcem.base.component.impl.BaseManager;
import shcem.finance.component.IVoucherOraManager;
import shcem.finance.dao.VoucherOraDAO;
import shcem.finance.dao.model.FBanks;
import shcem.finance.dao.model.FVoucherForOra;
import shcem.finance.dao.model.FirmValue;
import shcem.finance.dao.model.PaymentLog;
import shcem.finance.dao.model.PaymentLogDetail;
import shcem.finance.dao.model.VoucherModel;

/**
 * VoucherOraManagerImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class VoucherOraManagerImpl extends BaseManager implements IVoucherOraManager {
	private VoucherOraDAO dao;

	public void setVoucherOraDAO(VoucherOraDAO dao) {
		this.dao = dao;
	}

	
	@Override
	public int createAndAuditVoucher(String summaryNo, String summary, String debitCode, String creditCode, String contractno,
			String inputUser, String money) {
		this.log.debug("createAndAuditVoucher Component Start");
		return this.dao.createAndAuditVoucher(summaryNo, summary, debitCode, creditCode, contractno, inputUser, money);
	}

	
	@Override
	public int fastVoucher(String summaryNo, String summary, String debitCode, String creditCode, String contractno,
			String inputUser, String money) {
		this.log.debug("fastVoucher Component Start");
		return this.dao.createVoucherFast(summaryNo, summary, debitCode, creditCode, contractno, inputUser, money);
	}

	@Override
	public void submitAuditVoucher(boolean allFlg, long[] submitCodes) {
		this.log.debug("submitAuditVoucher Component Start");
		if (allFlg) {
			this.dao.submitAllVoucherForAudit();
		} else {
			for (int i = 0; i < submitCodes.length; i++) {
				this.dao.submitVoucherForAudit(new Long(submitCodes[i]));
			}
		}
	}

	@Override
	public int auditVoucher(Long voucherNo, boolean isPass, String loginUserId) {
		this.log.debug("auditVoucher Component Start");
		FVoucherForOra voucher = this.dao.getVoucherByNo(voucherNo);
		voucher.setAuditor(loginUserId);
		this.dao.updateVoucherNotEntrys(voucher);
		int result = this.dao.auditVoucher(voucherNo, isPass);
		return result;
	}

	@Override
	public FVoucherForOra getVoucherByNo(Long voucherNo) {
		this.log.debug("getVoucherByNo Component Start");
		FVoucherForOra voucher = this.dao.getVoucherByNo(voucherNo);
		return voucher;
	}

	@Override
	public VoucherModel getVoucherModelByCode(String code) {
		this.log.debug("getVoucherModelByCode Component Start");
		VoucherModel fVoucherModel = this.dao.getVoucherModelByCode(code);
		return fVoucherModel;
	}

	@Override
	public void rollback() {
		this.dao.rollBack();
	}

	@Override
	public FBanks getBank(String bankID) {
		return this.dao.getBank(bankID);
	}

	@Override
	public FirmValue getFirm(String firmID) {
		return this.dao.getFirm(firmID);
	}

	@Override
	public int insertPaymentLog(PaymentLog paymentLog) {
		return this.dao.insertPaymentLog(paymentLog);
	}

	@Override
	public int insertPaymentLogDetail(PaymentLogDetail paymentLogDetail) {
		return this.dao.insertPaymentLogDetail(paymentLogDetail);
	}

	@Override
	public int updatePaymentLogStatus(long id, Integer status) {
		return this.dao.updatePaymentLogStatus(id, status);
	}

	@Override
	public int updatePaymentLogNote(long id, String note) {
		return this.dao.updatePaymentLogNote(id, note);
	}

	@Override
	public int updatePaymentLogDetailStatus(long id, Integer detailId, Integer status) {
		return this.dao.updatePaymentLogDetailStatus(id, detailId, status);
	}

	@Override
	public int updatePaymentLogDetailError(long id, Integer detailId, Integer errorType, String errorMsg) {
		return this.dao.updatePaymentLogDetailError(id, detailId, errorType, errorMsg);
	}

	@Override
	public long getPaymentId() {
		return this.dao.getPaymentId();
	}


	@Override
	public int updatePaymentLogEndTime(long id) {
		return this.dao.updatePaymentLogEndTime(id);
	}


	@Override
	public int updatePaymentLogDetailEndTime(long id, Integer detailId) {
		return this.dao.updatePaymentLogDetailEndTime(id, detailId);
	}

}
