package shcem.finance.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;
/**
 * 优惠券
 * @author wangshuai
 *
 */
public class Coupon extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7782161887476698783L;
	private Integer id;
	private String  firmID;
	private String  firmName;
	private BigDecimal balance;
	private BigDecimal frozenfunds;
	private BigDecimal lastBalance;
	private Date creditDate;
	
	
	public Date getCreditDate() {
		return creditDate;
	}
	public void setCreditDate(Date creditDate) {
		this.creditDate = creditDate;
	}
	public String getFirmName() {
		return firmName;
	}
	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFirmID() {
		return firmID;
	}
	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}
	public BigDecimal getBalance() {
		return balance;
	}
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}
	public BigDecimal getFrozenfunds() {
		return frozenfunds;
	}
	public void setFrozenfunds(BigDecimal frozenfunds) {
		this.frozenfunds = frozenfunds;
	}
	public BigDecimal getLastBalance() {
		return lastBalance;
	}
	public void setLastBalance(BigDecimal lastBalance) {
		this.lastBalance = lastBalance;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}
