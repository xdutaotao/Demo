/**
 * @author ws
 * 2016-10-13 10:36:13
 */
package shcem.finance.dao.model;

import java.io.Serializable;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

public class InvoiceDetailRel extends BaseObject implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -4043574160770650549L;


	private Integer id;


    private Integer invoiceDetailID;


    private Integer applyRelID;


    private Integer dISABLED;


    private String rEC_CREATEBY;


    private Date rEC_CREATETIME;


    private String rEC_MODIFYBY;


    private Date rEC_MODIFYTIME;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getInvoiceDetailID() {
        return invoiceDetailID;
    }

    public void setInvoiceDetailID(Integer invoiceDetailID) {
        this.invoiceDetailID = invoiceDetailID;
    }

    public Integer getApplyRelID() {
        return applyRelID;
    }

    public void setApplyRelID(Integer applyRelID) {
        this.applyRelID = applyRelID;
    }

    public Integer getDISABLED() {
        return dISABLED;
    }

    public void setDISABLED(Integer dISABLED) {
        this.dISABLED = dISABLED;
    }

    public String getREC_CREATEBY() {
        return rEC_CREATEBY;
    }

    public void setREC_CREATEBY(String rEC_CREATEBY) {
        this.rEC_CREATEBY = rEC_CREATEBY == null ? null : rEC_CREATEBY.trim();
    }

    public Date getREC_CREATETIME() {
        return rEC_CREATETIME;
    }

    public void setREC_CREATETIME(Date rEC_CREATETIME) {
        this.rEC_CREATETIME = rEC_CREATETIME;
    }

    public String getREC_MODIFYBY() {
        return rEC_MODIFYBY;
    }

    public void setREC_MODIFYBY(String rEC_MODIFYBY) {
        this.rEC_MODIFYBY = rEC_MODIFYBY == null ? null : rEC_MODIFYBY.trim();
    }

    public Date getREC_MODIFYTIME() {
        return rEC_MODIFYTIME;
    }

    public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
        this.rEC_MODIFYTIME = rEC_MODIFYTIME;
    }

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}