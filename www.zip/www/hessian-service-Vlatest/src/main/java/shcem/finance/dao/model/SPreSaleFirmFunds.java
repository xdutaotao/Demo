package shcem.finance.dao.model;

import shcem.base.dao.model.BaseObject;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by cwei on 2016/8/24.
 * 预售授信资金表
 */
public class SPreSaleFirmFunds extends BaseObject implements java.io.Serializable, Cloneable{

    private static final long serialVersionUID = 2158171819872663891L;

    /**
     *id
     * @return
     */
    private Integer iD;

    /**
     * 交易商ID
     * @return
     */
    private String firmID;

    /**
     * 当前余额
     * @return
     */
    private BigDecimal balance;

    /**
     * 冻结额（已使用金额）
     * @return
     */
    private BigDecimal frozenFunds;

    /**
     * 期初额（初期设置额度）
     * @return
     */
    private BigDecimal lastBalance;

    /**
     * 授信时间
     * @return
     */
    private Date creditDate;
    
    private String firmName;


    public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public Integer getiD() {
        return iD;
    }

    public void setiD(Integer iD) {
        this.iD = iD;
    }

    public String getFirmID() {
        return firmID;
    }

    public void setFirmID(String firmID) {
        this.firmID = firmID;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public BigDecimal getFrozenFunds() {
        return frozenFunds;
    }

    public void setFrozenFunds(BigDecimal frozenFunds) {
        this.frozenFunds = frozenFunds;
    }

    public BigDecimal getLastBalance() {
        return lastBalance;
    }

    public void setLastBalance(BigDecimal lastBalance) {
        this.lastBalance = lastBalance;
    }

    public Date getCreditDate() {
        return creditDate;
    }

    public void setCreditDate(Date creditDate) {
        this.creditDate = creditDate;
    }

    public String toString() {
        return null;
    }

    public boolean equals(Object paramObject) {
        return false;
    }

    public int hashCode() {
        return 0;
    }
}
