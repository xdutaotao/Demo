/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IVoucherManager
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.component;

import java.math.BigDecimal;
import java.util.List;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.VoucherDAO;
import shcem.finance.dao.model.CreatVoucherParam;
import shcem.finance.dao.model.FVoucher;
import shcem.finance.dao.model.VocherDataList;
import shcem.finance.dao.model.Voucher;
import shcem.finance.dao.model.VoucherAllData;
import shcem.finance.dao.model.VoucherModel;

/**
 * IVoucherManager
 * 
 * @author chiyong
 * @version 1.0
 */
public abstract interface IVoucherManager extends Manager {

	public abstract void setVoucherDAO(VoucherDAO paramVoucherDAO);

	/**
	 * 快捷生成凭证
	 * @param summaryNo 摘要号
	 * @param summary 摘要名称
	 * @param debitCode 借方科目代码
	 * @param creditCode 贷方科目代码
	 * @param contractno 合同号
	 * @param inputUser 数据更新者id
	 * @param money 金额
	 * @param firmID 交易商账号
	 * @return 凭证号
	 */
	public abstract int fastVoucher(String summaryNo, String summary, String debitCode, String creditCode,
			String contractno, String inputUser, String money, String firmID);

	/**
	 * 提交审核
	 * @param allFlg 是否全部提交
	 * @param submitCodes 提交的凭证号
	 */
	public abstract void submitAuditVoucher(boolean allFlg, long[] submitCodes);

	/**
	 * 审核通过/失败
	 * @param voucherNo 凭证号
	 * @param isPass 审核通过true/失败false
	 * @param loginUserId 登录者id
	 */
	public abstract int auditVoucher(Long voucherNo, boolean isPass, String loginUserId);

	public abstract List<VocherDataList> getAllVoucherList(QueryConditions qc,
			PageInfo pageInfo);

	/**录入未审核（可编辑）
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<VocherDataList> getEditingVoucherList(
			QueryConditions qc, PageInfo pageInfo);

	public abstract List<VocherDataList> getAuditingVoucherList(
			QueryConditions qc, PageInfo pageInfo);

	public abstract VoucherAllData getVoucherByNo(Long vOUCHERNO);

	public abstract int deleteVoucher(long[] voucherNoCodes);

	public abstract VoucherModel getVoucherModelByCode(String voucherModelID);

	public abstract void updateVoucherNote(Voucher voucher);
	
	/**
	 * 取得凭证信息
	 * @param voucherNo 凭证号
	 */
	public abstract FVoucher getVoucher(Long voucherNo);
	
	
	/**
	 * 快速生成新老凭证
	 * @param voucherModelID
	 * @param money
	 * @param contractno
	 * @param firmID
	 * @param note
	 * @param inputUser
	 * @return -1 :老专场不存在这样的model
	 *         -2 :快捷创建凭证失败！(老)
	 *         -3 :凭证审核失败！请确认摘要与科目是否正确。(老)
	 *         -4 :凭证审核失败！造成201余额为负值。(老)
	 *         -5 :凭证审核失败！(老)
	 *         -6 :快捷创建凭证失败！(新)
	 *         -7 :凭证审核失败！请确认摘要与科目是否正确。(新)
	 *         -8 :凭证审核失败！造成201余额为负值。(新)
	 *         -9 :凭证审核失败！(新)
	 *         -10 :新专场不存在这样的model
	 */
	public abstract int createNewOldVoucher(String voucherModelID, BigDecimal money,
			String contractno,String firmID,String note,String inputUser);
	
	
	public abstract int createNewOldVoucherBat(List<CreatVoucherParam> creatVoucherParams);
	
	/**
	 * 快速生成老凭证(老专场数据rollback用)
	 * @param voucherModelID
	 * @param money
	 * @param contractno
	 * @param firmID
	 * @param note
	 * @param inputUser
	 * @return -1 :老专场不存在这样的model
	 *         -2 :快捷创建凭证失败！(老)
	 *         -3 :凭证审核失败！请确认摘要与科目是否正确。(老)
	 *         -4 :凭证审核失败！造成201余额为负值。(老)
	 *         -5 :凭证审核失败！(老)
	 */
	public abstract int createOldVoucher(String voucherModelID, BigDecimal money,
			String contractno,String firmID,String note,String inputUser);
	
	public abstract void rollback();
	
	public abstract void fixNewOldSubBalance(String contractno,String firmID);
}
