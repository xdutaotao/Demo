/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: BalanceModel
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.service.model;

import java.io.Serializable;
import java.sql.Timestamp;

import org.json.JSONObject;

import shcem.base.service.model.BaseServiceObject;

/**
 * @author wlpod
 *
 */
public class CapitalModel extends BaseServiceObject implements Serializable {

	private static final long serialVersionUID = -7464587171301763763L;

	/**
	 * 记录流水号
	 */
	private long iD;
	/**
	 * 市场业务流水号
	 */
	private long actionID;
	/**
	 * 交易商代码
	 */
	private String firmID;
	/**
	 * 银行业务流水号
	 */
	private String funID;
	/**
	 * 银行代码
	 */
	private String bankID;
	/**
	 * 借方科目代码
	 */
	private String debitID;
	/**
	 * 贷方科目代码
	 */
	private String creditID;
	/**
	 * 类型：0 入金 1 出金2 出入金手续费 3 其他资金划转 4 入金冲正 5 出金冲正
	 */
	private int type;
	/**
	 * 金额
	 */
	private double money;
	/**
	 * 业务代码
	 */
	private String oprcode;
	/**
	 * 记录创建时间
	 */
	private Timestamp createtime;
	/**
	 * 银行端操作时间
	 */
	private Timestamp bankTime;

	public long getID() {
		return iD;
	}

	public void setID(long iD) {
		this.iD = iD;
	}

	public long getActionID() {
		return actionID;
	}

	public void setActionID(long actionID) {
		this.actionID = actionID;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getFunID() {
		return funID;
	}

	public void setFunID(String funID) {
		this.funID = funID;
	}

	public String getBankID() {
		return bankID;
	}

	public void setBankID(String bankID) {
		this.bankID = bankID;
	}

	public String getDebitID() {
		return debitID;
	}

	public void setDebitID(String debitID) {
		this.debitID = debitID;
	}

	public String getCreditID() {
		return creditID;
	}

	public void setCreditID(String creditID) {
		this.creditID = creditID;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public double getMoney() {
		return money;
	}

	public void setMoney(double money) {
		this.money = money;
	}

	public String getOprcode() {
		return oprcode;
	}

	public void setOprcode(String oprcode) {
		this.oprcode = oprcode;
	}

	public Timestamp getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Timestamp createtime) {
		this.createtime = createtime;
	}

	public Timestamp getBankTime() {
		return bankTime;
	}

	public void setBankTime(Timestamp bankTime) {
		this.bankTime = bankTime;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getExpress() {
		return express;
	}

	public void setExpress(int express) {
		this.express = express;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	/**
	 * 状态：0：成功 1：失败 2：处理中 3:待审核 4:二次审核 5:银行无应答 6:市场流水号冲突 -1:流水被冲正
	 */
	private int status;
	/**
	 * 是否加急：0：正常 1：加急
	 */
	private int express;
	/**
	 * 备注
	 */
	private String note;
	/**
	 * 银行名称
	 */
	private String bankName;
	/**
	 * 账户名
	 */
	private String firmName;
	/**
	 * 银行账号
	 */
	private String account;

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toString()
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toJSONObject()
	 */
	@Override
	public JSONObject toJSONObject() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#hashCode()
	 */
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
