package shcem.finance.component;

import java.util.List;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.FundFlowDAO;
import shcem.finance.dao.model.FinancialBills;
import shcem.finance.dao.model.FundflowServiceModel;

public abstract interface IFundFlowManager extends Manager{

	public abstract void setFundFlowDAO(FundFlowDAO paramFundFlowDao);
	
	List<FundflowServiceModel> getFundFlowList(QueryConditions qc,PageInfo pageInfo);

	public abstract List<FinancialBills> getFinancialBillsList(
			QueryConditions qc, PageInfo pageInfo, int financialBillsType);
	
}
