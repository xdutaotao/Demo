package shcem.finance.service;

public interface ICouponMgrService {
	/**
	 * 申请优惠券
	 * @param params
	 * @return
	 */
	public String addCouponApply(String params);
	
	/**
	 * 查询申请过的优惠券列表
	 * @param params
	 * @return
	 */
	public String queryCouponApplyList(String params);
	
	/**
	 * 审核申请过的优惠券
	 * @param params
	 * @return
	 */
	public String passCouponApply(String params);
	
	/**
	 * 查询优惠券列表
	 * @param params
	 * @return
	 */
	public String queryCouponList(String params);
	
	
	/**
	 * 查询优惠券流水列表
	 * @param params
	 * @return
	 */
	public String queryCouponFlowList(String params);
	
	/**
	 * 查询优惠券流水列表(前台用)
	 * @param params
	 * @return
	 */
	public String queryCouponFlowListForFront(String params);
	
}
