package shcem.finance.dao.model;

import java.io.Serializable;

import shcem.base.dao.model.BaseObject;

/**分录科目
 * @author zhangnan
 *
 */
public class VoucherModel extends BaseObject implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String cODE;
	
	private String nAME;
	
	private String sUMMARYNO;
	
	private String dEBITCODE;
	
	private String cREDITCODE;
	
	private String nEEDCONTRACTNO;
	
	private String nOTE;
	
	private String oracleModelID;
	
	
	
	public String getOracleModelID() {
		return oracleModelID;
	}

	public void setOracleModelID(String oracleModelID) {
		this.oracleModelID = oracleModelID;
	}

	public String getCODE() {
		return cODE;
	}

	public void setCODE(String cODE) {
		this.cODE = cODE;
	}

	public String getNAME() {
		return nAME;
	}

	public void setNAME(String nAME) {
		this.nAME = nAME;
	}

	public String getSUMMARYNO() {
		return sUMMARYNO;
	}

	public void setSUMMARYNO(String sUMMARYNO) {
		this.sUMMARYNO = sUMMARYNO;
	}

	public String getDEBITCODE() {
		return dEBITCODE;
	}

	public void setDEBITCODE(String dEBITCODE) {
		this.dEBITCODE = dEBITCODE;
	}

	public String getCREDITCODE() {
		return cREDITCODE;
	}

	public void setCREDITCODE(String cREDITCODE) {
		this.cREDITCODE = cREDITCODE;
	}

	public String getNEEDCONTRACTNO() {
		return nEEDCONTRACTNO;
	}

	public void setNEEDCONTRACTNO(String nEEDCONTRACTNO) {
		this.nEEDCONTRACTNO = nEEDCONTRACTNO;
	}

	public String getNOTE() {
		return nOTE;
	}

	public void setNOTE(String nOTE) {
		this.nOTE = nOTE;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
