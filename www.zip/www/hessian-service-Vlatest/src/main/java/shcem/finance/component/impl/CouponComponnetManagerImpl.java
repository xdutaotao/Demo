package shcem.finance.component.impl;

import java.math.BigDecimal;
import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.component.ICouponComponnetManager;
import shcem.finance.dao.ICouponDao;
import shcem.finance.dao.model.Coupon;
import shcem.finance.dao.model.CouponApply;
import shcem.finance.dao.model.CouponFlow;
import shcem.util.Common;

public class CouponComponnetManagerImpl extends BaseManager implements
		ICouponComponnetManager {

	private ICouponDao couponDao;
	private ICouponDao couponDao_read;
	public void setCouponDao(ICouponDao couponDao) {
		this.couponDao = couponDao;
	}

	public void setCouponDao_read(ICouponDao couponDao_read) {
		this.couponDao_read = couponDao_read;
	}

	@Override
	public int insertCouponApply(CouponApply couponApply) {
		return couponDao.insertCouponApply(couponApply);
	}

	@Override
	public CouponApply selectCouponApplyById(Integer id) {
		return couponDao.selectCouponApplyById(id);
	}

	@Override
	public int updateCouponApplyOfStatusById(CouponApply couponApply) {
		// 更新 优惠券申请表 的审核状态
		int count = couponDao.updateCouponApplyOfStatusById(couponApply);
		return count;
	}

	@Override
	public List<CouponApply> queryCouponApplyList(QueryConditions qc,
			PageInfo pageInfo) {
		return couponDao_read.queryCouponApplyList(qc, pageInfo);
	}

	@Override
	public int insertCoupon(Coupon coupon) {
		return couponDao.insertCoupon(coupon);
	}

	@Override
	public int updateCouponById(Coupon coupon) {
		int count = couponDao.updateCouponById(coupon);
		return count;
	}

	@Override
	public List<Coupon> queryCouponList(QueryConditions qc, PageInfo pageInfo) {
		return couponDao_read.queryCouponList(qc, pageInfo);
	}

	@Override
	public int insertCouponFlow(CouponFlow couponFlow) {
		return couponDao.insertCouponFlow(couponFlow);
	}

	@Override
	public List<CouponFlow> queryCouponFlowList(QueryConditions qc,
			PageInfo pageInfo) {
		return couponDao_read.queryCouponFlowList(qc, pageInfo);
	}

	@Override
	public Coupon selectCouponByFirmID(String firmID) {
		return couponDao_read.selectCouponByFirmID(firmID);
	}
	
	/**
	 * 
	 * @param oprCode
	 *            操作代码 101 入金，102 出金
	 * @param flag
	 *            使用 0：退还：1
	 * @param money
	 *            使用的资金
	 * @param objectType 0:优惠券号 1:订单ID 2:报盘ID 3:优惠券申请ID 4:询盘ID 5:交收单ID
	 *            
	 * @param flowType  0充值 1扣除 2抵用
	 * @return
	 */
	private int createCouponFlow(String firmID, String oprCode, int flag, BigDecimal money, String ObjectID,int objectType,int flowType, String Operator) {
		int result = -1;
		BigDecimal sBalance = new BigDecimal(0);
		Coupon coupon = this.couponDao.selectCouponByFirmID(firmID);
		if (coupon != null) {
			sBalance = coupon.getBalance();
		} else {
			return -2; // firm not exist
		}
		if (flag == 0) {
			money = money.multiply(new BigDecimal(-1));
			// 减授信额的时候，check余额不能小于money
			if (sBalance.compareTo(money) == -1) {
				return -2;
			}
		}
		// 优惠券流水表追加
		CouponFlow couponFlow = new CouponFlow();

		couponFlow.setFirmID(firmID);
		couponFlow.setOperCode(oprCode);
		couponFlow.setBalance(coupon.getBalance().add(money));
		couponFlow.setAmount(money.abs());
		couponFlow.setCreatetime(Common.getDate());
		couponFlow.setObjectID(ObjectID);
		couponFlow.setObjectType(objectType);
		couponFlow.setFlowType(flowType);
		couponFlow.setOperator(Operator);
		result = this.couponDao.insertCouponFlow(couponFlow);
		if (result != 1) {
			return -4;
		}
		result = this.couponDao.updateCouponByUse(firmID, money);
		if (result != 1) {
			return -5;
		}
		result = 1;
		return result;
	}
	
	/**
	 * 用优惠券抵用收取交易手续费
	 * 
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType  0充值 1扣除 2抵用
	 * @param objectType 0:优惠券号 1:订单ID 2:报盘ID 3:优惠券申请ID 4:询盘ID 5:交收单ID
	 * @return
	 */
	@Override
	public int getFee(String firmID, BigDecimal money, String ObjectID,int objectType, int flowType, String Operator) {
		return this.createCouponFlow(firmID, "201", 0, money, ObjectID,objectType, flowType, Operator);
	}
	
	@Override
	public void rollback() {
		this.couponDao.rollBack();
	}

	@Override
	public int passCouponApply(Integer couponApplyId,String userName,String refuseReason) {
		this.log.debug(this.getClass().getName()+".passCouponApply Start");
		int resultCode = 0;
		// 获取 申请优惠券申请信息
		CouponApply couponApplyInfo = couponDao.selectCouponApplyById(couponApplyId);
		if (couponApplyInfo == null){
			resultCode = -90013;
			return resultCode;
		}
		String firmID = couponApplyInfo.getFirmID();
		// 获取 交易商的优惠券信息
		Coupon couponInfo = couponDao.selectCouponByFirmID(firmID);
		if (couponInfo == null){
			this.log.error("没有查询到交易商ID["+firmID+"]的账户信息");
			resultCode = -90009;
			return resultCode;
		}
		// 如果申请的优惠券已经被审核 申请状态  0：待审核 1：审核通过 2：审核不通过
		if (couponApplyInfo.getStatus() != 0){
			resultCode = -90015;
			return resultCode;
		}
		// 申请优惠券的金额
		BigDecimal amount = couponApplyInfo.getAmount();
		// 待审核
		if (0 == couponApplyInfo.getStatus()){
			// 增减区分 0：增
			if (0 == couponApplyInfo.getApplyType()){
				// 期初额（初期设置额度） = 期初额（初期设置额度） + 增的金额
				couponInfo.setLastBalance(couponInfo.getLastBalance().add(amount));
				// 当前余额 = 期初额（初期设置额度） - 已使用金额
				couponInfo.setBalance(couponInfo.getLastBalance().subtract(couponInfo.getFrozenfunds()));
			}else if (1 == couponApplyInfo.getApplyType()){// 增减区分 1：减
				// 当前余额 = 当前余额 - 减的金额
				BigDecimal balance = couponInfo.getBalance().subtract(amount);//couponInfo.setBalance();
				// 小于0时
				if (balance.compareTo(new BigDecimal(0)) < 0){
					this.log.warn("申请减的金额不能大于当前交易商["+firmID+"]优惠券的余额!");
					resultCode = -90010;
					return resultCode;
				}
				couponInfo.setBalance(balance);
				// 期初额（初期设置额度） = 期初额（初期设置额度） - 减的金额
				BigDecimal lastBalance = couponInfo.getLastBalance().subtract(amount);
				// 小于0时
				if (lastBalance.compareTo(new BigDecimal(0)) < 0){
					this.log.warn("申请减的金额不能大于 期初额（初期设置额度）!"+lastBalance);
					resultCode = -90011;
					return resultCode;
				}
				couponInfo.setLastBalance(lastBalance);
			}
			
			// 更新 优惠券申请表 的 审核状态
			CouponApply upCouponApply = new CouponApply();
			upCouponApply.setStatus(1);//审核通过
			upCouponApply.setRefuseReason(refuseReason);
			upCouponApply.setId(couponApplyId);//
			upCouponApply.setApprover(userName);
			int count = couponDao.updateCouponApplyOfStatusById(upCouponApply);
			if (count > 0){
				// 1.更新优惠券信息
				int countCoupon = couponDao.updateCouponById(couponInfo);
				this.log.debug("更新优惠券信息成功！");
				// 2.插入优惠券流水表
				if (countCoupon != 0){
					CouponFlow couponFlow = new CouponFlow();
					couponFlow.setFirmID(couponInfo.getFirmID());
					if (couponApplyInfo.getApplyType() == 0){
						couponFlow.setOperCode("801");// 充值优惠券余额 
					} else if (couponApplyInfo.getApplyType() == 1){
						couponFlow.setOperCode("802");// 扣除优惠券余额 
					}else{
						couponFlow.setOperCode("");//
						this.log.warn("未知的优惠券申请类型ApplyType："+couponApplyInfo.getApplyType());
					}
					couponFlow.setAmount(couponApplyInfo.getAmount());
					couponFlow.setBalance(couponInfo.getBalance());
					couponFlow.setObjectID(String.valueOf(couponApplyId));// 申请ID
					couponFlow.setObjectType(3);// 
					couponFlow.setFlowType(couponApplyInfo.getApplyType());//  0充值  1扣除  2抵用
					couponFlow.setOperator(userName);//操作人
					couponDao.insertCouponFlow(couponFlow);
					this.log.debug("插入优惠券流水成功！");
				}
			}else{
				resultCode = -90012;
			}
		}
		this.log.debug(this.getClass().getName()+".passCouponApply End");
		return resultCode;
	}
	
	/**
	 * 操作优惠券(充值已经测试，在抵扣或抵用的情况没有测试,使用人请自行测试)
	 * @param firmID 交易商ID
	 * @param money 充值金额
	 * @param operCode 业务代码（摘要号） 关联F_Summary.SummaryNO。801 充值优惠券余额、802 扣除优惠券余额、其他请查表
	 * @param ObjectID  0:F_NewCouponTrans.CouponNumber 1:T_Order.OrderID 2:T_Leads.ID 3:F_CouponApply.ID 4:T_Enquiry.EnquiryId 5:T_Delivery.DeliveryID
	 * @param objectType  0:优惠券号 1:订单ID 2:报盘ID 3:优惠券申请ID 4:询盘ID 5:交收单ID
	 * @param flowType  0充值 1扣除  2抵用
	 * @param Operator 操作人
	 * @return
	 */
	@Override
	public int operationCoupon(String firmID, BigDecimal money,String operCode, String ObjectID, int objectType, int flowType,String Operator) {
		this.log.debug(this.getClass().getName()+".operationCoupon Start");
		int resultCode = 0;
		BigDecimal sBalance = new BigDecimal(0);
		Coupon coupon = this.couponDao.selectCouponByFirmID(firmID);
		if (coupon != null) {
			sBalance = coupon.getBalance();
			if (flowType == 0){// 充值
				/**
				 * 优惠券流水表追加
				 */
				CouponFlow couponFlow = new CouponFlow();
				couponFlow.setFirmID(firmID);
				couponFlow.setOperCode(operCode);
				couponFlow.setBalance(sBalance.add(money));
				couponFlow.setAmount(money);
				couponFlow.setCreatetime(Common.getDate());
				couponFlow.setObjectID(ObjectID);
				couponFlow.setObjectType(objectType);
				couponFlow.setFlowType(flowType);
				couponFlow.setOperator(Operator);
				this.couponDao.insertCouponFlow(couponFlow);
				/**
				 * 更新账户余额
				 */
				this.couponDao.updateCouponByUse(firmID, money);
			}else{// 1扣除  2抵用
				// check余额不能小于money
				if (sBalance.subtract(money).compareTo(new BigDecimal(0)) < 0) {
					return -2;// 余额不足
				}
				// 取负值
				money = money.multiply(new BigDecimal(-1));
				// 优惠券流水表追加
				CouponFlow couponFlow = new CouponFlow();
				couponFlow.setFirmID(firmID);
				couponFlow.setOperCode(operCode);
				couponFlow.setBalance(coupon.getBalance().add(money));
				couponFlow.setAmount(money.abs());
				couponFlow.setCreatetime(Common.getDate());
				couponFlow.setObjectID(ObjectID);
				couponFlow.setObjectType(objectType);
				couponFlow.setFlowType(flowType);
				couponFlow.setOperator(Operator);
				this.couponDao.insertCouponFlow(couponFlow);
				this.couponDao.updateCouponByUse(firmID, money);
			}
		} else {
			return -1; // 交易商的优惠券账户不存在！
		}
		this.log.debug(this.getClass().getName()+".operationCoupon End");
		return resultCode;
	}


}
