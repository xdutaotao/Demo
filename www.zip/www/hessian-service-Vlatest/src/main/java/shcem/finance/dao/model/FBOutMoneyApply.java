/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FVoucher
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.model;

import java.math.BigDecimal;

import shcem.base.dao.model.BaseObject;

/**
 * (f_Voucher)
 * 
 * @author wlpod
 * @version 1.0.0 2016-05-12
 */
public class FBOutMoneyApply extends BaseObject implements java.io.Serializable, Cloneable {

	private static final long serialVersionUID = -7464587171301763763L;

	/** 自增ID */
	private Integer id;

	/** 交易商id */
	private String firmID;

	/** 交易商名称 */
	private String firmName;

	/** 签约银行id */
	private String bankID;

	/** 签约银行名称 */
	private String bankName;

	/** 申请出金金额 */
	private BigDecimal money;

	/** 申请时间 */
	private String applyer;
	
	/** 申请时间 */
	private String applyTime;

	/** 审核人 */
	private String auditor;

	/** 审核时间 */
	private String auditTime;

	/** 备注 */
	private String note;

	/** 申请状态 */
	private Integer status;
	
	

	public String getApplyer() {
		return applyer;
	}

	public void setApplyer(String applyer) {
		this.applyer = applyer;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public String getBankID() {
		return bankID;
	}

	public void setBankID(String bankID) {
		this.bankID = bankID;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public BigDecimal getMoney() {
		return money;
	}

	public void setMoney(BigDecimal money) {
		this.money = money;
	}

	public String getApplyTime() {
		return applyTime;
	}

	public void setApplyTime(String applyTime) {
		this.applyTime = applyTime;
	}

	public String getAuditor() {
		return auditor;
	}

	public void setAuditor(String auditor) {
		this.auditor = auditor;
	}

	public String getAuditTime() {
		return auditTime;
	}

	public void setAuditTime(String auditTime) {
		this.auditTime = auditTime;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}