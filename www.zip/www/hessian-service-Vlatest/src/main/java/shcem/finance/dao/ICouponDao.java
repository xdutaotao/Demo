package shcem.finance.dao;

import java.math.BigDecimal;
import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.model.Coupon;
import shcem.finance.dao.model.CouponApply;
import shcem.finance.dao.model.CouponFlow;
import shcem.finance.dao.model.CouponFlowFront;
/**
 * 优惠券DAO
 * @author wangshuai
 *
 */
public abstract interface ICouponDao extends DAO {

	/**
	 * 插入 优惠券申请
	 * @param couponApply
	 * @return
	 */
	int insertCouponApply(CouponApply couponApply);
	
	/**
	 * 根据ID 查询优惠券申请
	 * @param couponApply
	 * @return
	 */
	CouponApply selectCouponApplyById(Integer id);
	
	/**
	 * 根据ID 更新优惠券申请的 申请状态
	 * @param couponApply
	 * @return
	 */
	int updateCouponApplyOfStatusById(CouponApply couponApply);
	
	/**
	 * 查询优惠券申请列表
	 */
	List<CouponApply> queryCouponApplyList(QueryConditions qc, PageInfo pageInfo);
	
	
	/**
	 * 插入 优惠券
	 */
	int insertCoupon(Coupon coupon);
	
	/**
	 * 更新 优惠券
	 */
	int updateCouponById(Coupon coupon);
	
	/**
	 * 查询 优惠券 根据FirmID
	 */
	Coupon selectCouponByFirmID(String firmID);
	
	/**
	 * 查询优惠券列表
	 */
	List<Coupon> queryCouponList(QueryConditions qc, PageInfo pageInfo);
	
	
	/**
	 * 插入 优惠券流水
	 */
	int insertCouponFlow(CouponFlow couponFlow);
	
	/**
	 * 查询 优惠券流水列表
	 */
	List<CouponFlow> queryCouponFlowList(QueryConditions qc, PageInfo pageInfo);
	
	
	int updateCouponByUse(String firmId, BigDecimal money);
	
	public abstract void rollBack();
	
	
//	/**
//	 * 查询 优惠券流水列表(前台用)
//	 */
//	List<CouponFlowFront> queryCouponFlowListForFront(QueryConditions qc, PageInfo pageInfo);
	
}
