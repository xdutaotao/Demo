/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmBanlanceOraDAO
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
  * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao;

import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.model.FirmBanlanceListForOra;
import shcem.finance.dao.model.FirmForOra;
import shcem.finance.dao.model.FirmModuleForOra;
import shcem.finance.dao.model.FirmTradeFeeForOra;

/**
 * FirmBanlanceOraDAO
 * 
 * @author chiyong
 * @version 1.0
 */
public abstract interface FirmBanlanceOraDAO extends DAO {

	/**
	 * 交易商当前资金查询
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<FirmBanlanceListForOra> queryFirmBanlance(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 交易商期间手续费合计查询
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<FirmTradeFeeForOra> queryFirmTradeFee(QueryConditions qc, PageInfo pageInfo, String firmName);

	public abstract int verifyRepeat(String firmId);

	public abstract void createFirm(FirmForOra firm);

	public abstract List getTradeModuleList();

	public abstract int addFirmModule(FirmModuleForOra firmModule);

	public abstract int addFirm(String firmId);
	
	public abstract void rollBack();

	public abstract int queryFirmTradeFeeCount(QueryConditions qc,
			String firmName);

}
