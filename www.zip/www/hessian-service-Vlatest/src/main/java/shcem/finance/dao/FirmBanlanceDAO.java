/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmBanlanceDAO
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
  * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao;

import java.math.BigDecimal;
import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.model.CancelDetail;
import shcem.finance.dao.model.FBOutMoneyApply;
import shcem.finance.dao.model.FeeModel;
import shcem.finance.dao.model.FirmBanlanceList;
import shcem.finance.dao.model.TDelivery;
import shcem.finance.dao.model.TEnquiry;
import shcem.finance.dao.model.TLeads;
import shcem.finance.dao.model.TOrder;

/**
 * FirmBanlanceDAO
 * 
 * @author chiyong
 * @version 1.0
 */
public abstract interface FirmBanlanceDAO extends DAO {
	
	
	public abstract int updateOutMoneyApply(Integer id, Integer fromStatus, Integer toStatus, String auditor,String note);
	
	public abstract List<FBOutMoneyApply> getOutMoneyApplyList(QueryConditions qc, PageInfo pageInfo);
	
	public abstract void insertOutMoneyApply(FBOutMoneyApply applyModel);
	
	
	/**
	 * 交易商当前资金查询
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<FirmBanlanceList> queryFirmBanlance(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 查询出金申请列表
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<FirmBanlanceList> queryOutMoneyList(QueryConditions qc, PageInfo pageInfo);
	
	
	/**
	 * 报盘数据取得
	 * @param leadsId
	 * @return
	 */
	public abstract TLeads getLeadsById(Long leadsId);
	
	
	/**
	 * 询盘数据取得
	 * @param enquiryId
	 * @return
	 */
	public abstract TEnquiry getEnquiryById(Long enquiryId);
	
	/**
	 * 报盘成交数据取得
	 * @param enquiryId
	 * @return
	 */
	public abstract TOrder getOrderById(String orderId);
	
	/**
	 * 交收数据取得
	 * @param enquiryId
	 * @return
	 */
	public abstract TDelivery getDeliveryById(String deliveryId);
	
	/**
	 * 
	 * @param model 1: 挂盘  手续费、保证金处理
	 *			   	2：询盘  手续费、保证金处理
	 *				3：直接成交  下家（买家）手续费、保证金处理
	 *		  		4：询盘成交  下家（买家）手续费、保证金处理
	 *		   		5：成交 卖方（上家）手续费、保证金处理
	 *		   		6：挂盘撤盘  退交易手续费、保证金处理
	 *			    7：询盘撤单  退交易手续费、保证金处理
	 *			    8：交收 上家 交易保证金转交收保证金
	 *			    9：交收 下家 授信转资金
	 *			    10：交收 下家 保证金、手续费、货款
	 * @param id
	 * @param fundsBalance
	 * @param creditBalance
	 * @return
	 */
	public abstract FeeModel getFeeModel(int model, String id, BigDecimal fundsBalance, BigDecimal creditBalance, int coupon, BigDecimal couponAmount, int bsFlg);
	
	
	public abstract void updateAllCanBackLeads();


	public abstract List<TLeads> getAllCanBackLeads();


	public abstract List<TEnquiry> getAllCanBackEnquiry();

	public abstract List<TEnquiry> getAllSinopecCanBackEnquiry();

	public abstract List<TLeads> getAllSinopecCanBackLeads();


	public abstract void updateAllSinopecLeadsAndEnquiry(); 
	
	public abstract List<CancelDetail> getCancelDetail(String ApplyID); 
	public abstract void updateCancelMoneySuccess(String keyID, String userId); 
	public abstract void updateCancelMoneySuccessHalf(String keyID, String userId); 
	public abstract void updateCancelMoneyFailed(String keyID, String userId); 
	
	/*
	 * 以下为期现市场
	 */
	/**
	 * 取得询盘列表
	 * 
	 * @param differ
	 * @param enqId
	 * @return
	 */
	public abstract List<TEnquiry> getCancelEnquiryLst(int differ, int enqId); 
	
	/**
	 * 取得挂盘列表
	 * 
	 * @param differ
	 * @param leadId
	 * @return
	 */
	public abstract List<TLeads> getCancelLeadLst(int differ, int leadId); 
	
	/**
	 * 事前更新询盘列表
	 * 
	 * @param differ
	 * @param enqId
	 * @return
	 */
	public abstract void preCancelEnquiryLst(int differ, int enqId); 
	
	/**
	 * 事前更新挂盘列表
	 * 
	 * @param differ
	 * @param leadId
	 * @return
	 */
	public abstract void preCancelLeadLst(int differ, int leadId); 
	
	/**
	 * 事后更新询盘列表
	 * 
	 * @param differ
	 * @param enquiry
	 * @return
	 */
	public abstract void postCancelEnquiryLst(int differ, TEnquiry enquiry); 
	
	/**
	 * 事后更新挂盘列表
	 * 
	 * @param differ
	 * @param lead
	 * @return
	 */
	public abstract void postCancelLeadLst(int differ, TLeads lead); 
}
