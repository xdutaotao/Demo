/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IBankMgrService
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.service;

/**
 * IBankMgrService
 * 
 * @author chiyong
 * @version 1.0
 */
public interface IBankMgrService {


	public String getBankList(String params);
	
	public String getBank(String params);

	public String updateBank(String params);

	public String addBank(String params);

	public String validBank(String params);

	public String invalidBank(String params);
	
	public String openAbcAccount(String params);
	
	public String delAbcAccount(String params);
}