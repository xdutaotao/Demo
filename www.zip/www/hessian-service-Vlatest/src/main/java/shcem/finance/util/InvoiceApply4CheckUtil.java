package shcem.finance.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.apache.zookeeper.Op.Check;

import shcem.finance.dao.IInvoiceDao;
import shcem.finance.dao.model.InvoiceApply;
import shcem.finance.dao.model.InvoiceApply4Check;
import shcem.finance.service.model.ImportInvoiceDetail;
import shcem.log.service.ILogService;

/**
 * 开票数据
 * @author zhangnan
 *
 */
public class InvoiceApply4CheckUtil {

	public static String checkInvoiceApply4Check(
			List<InvoiceApply4Check> invoiceApplyList, ILogService log) {
		log.info("shcem.finance.util.InvoiceApply4CheckUtil  checkInvoiceApply4Check Start");
		String returnMessage = "";
		int loopCount = 0;
		for (InvoiceApply4Check invoiceApply4Check : invoiceApplyList) {
			Class data = invoiceApply4Check.getClass();
			Field[] fields = data.getDeclaredFields();
			for (int i = 0; i < fields.length; i++) {
				 	Field f = fields[i];
				 	f.setAccessible(true);
	            	try {
	            		
	            		if(f.get(invoiceApply4Check) != null){
	            			String fieldValue =  f.get(invoiceApply4Check).toString().replace(" ", "");
	            			System.out.println("属性名:" + f.getName() + " 属性值:" + f.get(invoiceApply4Check));
	            			if(fieldValue.equals("")){
	            				returnMessage += " 【交易商： "+invoiceApply4Check.getFirmName()+"】 : 数据不完整！不能申请开票！^^ ";
	            				loopCount++;
		            			break;
	            			}
	            		}else {
	            			returnMessage += " 【交易商： "+invoiceApply4Check.getFirmName()+"】 : 数据不完整！不能申请开票！^^ ";
	            			System.out.println("属性名:" + f.getName() + " 属性值:" + f.get(invoiceApply4Check));
	            			loopCount++;
	            			break;
						}
					} catch (IllegalArgumentException e) {
						log.error("shcem.finance.util.InvoiceApply4CheckUtil  checkInvoiceApply4Check :"+e.getMessage());
						e.printStackTrace();
						returnMessage += "";
					}catch (IllegalAccessException e) {
						log.error("shcem.finance.util.InvoiceApply4CheckUtil  checkInvoiceApply4Check :"+e.getMessage());
						e.printStackTrace();
						returnMessage += "";
					}
			}
		}
		returnMessage = " 共 "+loopCount+" 条开票数据交收单无法开票，开票数据不完善，包含以下公司 ：^^"+returnMessage;
		if(loopCount == 0) returnMessage = "所有开票申请数据,校验通过！";
		log.info("shcem.finance.util.InvoiceApply4CheckUtil  checkInvoiceApply4Check End");
		return returnMessage;
	}

	/**
	 * 剔除不完整的申请数据
	 * @param invoiceApplyList
	 * @param log
	 * @return
	 */
	public static List<InvoiceApply> getFullInvoiceApplyList(
			List<InvoiceApply> invoiceApplyList, ILogService log) {
		log.info("shcem.finance.util.InvoiceApply4CheckUtil  getFullInvoiceApplyList Start");
		List<InvoiceApply> temp_invoiceApplyList = new ArrayList<InvoiceApply>();
		for (InvoiceApply invoiceApply : invoiceApplyList) {
			InvoiceApply4Check invoiceApply4Check = invoiceApply.getInvoiceApply4Check();
			if(CheckInvoiceApply4CheckData(invoiceApply4Check)) temp_invoiceApplyList.add(invoiceApply);
		}
		
		log.info("shcem.finance.util.InvoiceApply4CheckUtil  getFullInvoiceApplyList End");
		return temp_invoiceApplyList;
	}

	public static boolean CheckInvoiceApply4CheckData(
			InvoiceApply4Check invoiceApply4Check) { 
		boolean checkStatus = true;
		Class data = invoiceApply4Check.getClass();
		Field[] fields = data.getDeclaredFields();
		for (int i = 0; i < fields.length; i++) {
			 	Field f = fields[i];
			 	f.setAccessible(true);
            	try {
            		if(f.get(invoiceApply4Check) != null){
            			String fieldValue =  f.get(invoiceApply4Check).toString().replace(" ", "");
            			System.out.println("属性名:" + f.getName() + " 属性值:" + f.get(invoiceApply4Check));
            			if(fieldValue.equals("")){
            				checkStatus = false;
	            			break;
            			}
            		}else {
            			checkStatus = false;
            			break;
					}
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
					checkStatus = false;
				}catch (IllegalAccessException e) {
					e.printStackTrace();
					checkStatus = false;
				}
		}
		return checkStatus;
	}

	/**
	 * 发票导入Excel,剔除不正确的数据
	 * @param listTemp
	 * @param invoiceDao 
	 * @param log 
	 * @return
	 */
	public static List<ImportInvoiceDetail> getCorrectImportInvoiceList(
			List<ImportInvoiceDetail> listTemp, IInvoiceDao invoiceDao, ILogService log) {
		log.info("shcem.finance.util.InvoiceApply4CheckUtil getCorrectImportInvoiceList  Start");
		List<ImportInvoiceDetail> list = new ArrayList<ImportInvoiceDetail>();
		for (ImportInvoiceDetail importInvoiceDetail : listTemp) {
			boolean record = checkImportInvoiceDetail(importInvoiceDetail,invoiceDao,log);
			if(record) list.add(importInvoiceDetail);
		}
		log.info("shcem.finance.util.InvoiceApply4CheckUtil getCorrectImportInvoiceList  End");
		return list;
	}

	/**
	 * 发票导入Excel,校验每条数据
	 * @param importInvoiceDetail
	 * @param invoiceDao
	 * @param log
	 * @return
	 */
	private static boolean checkImportInvoiceDetail(
			ImportInvoiceDetail importInvoiceDetail, IInvoiceDao invoiceDao, ILogService log) {
		log.info("shcem.finance.util.InvoiceApply4CheckUtil checkImportInvoiceDetail  Start");
		/*销售单号、备注(交收单号)匹配校验*/
		boolean record = true;
		InvoiceApply invoiceApply = invoiceDao.getInvoiceApply(importInvoiceDetail.getRelationNo());
		if(invoiceApply == null){
			record = false;
		}else {
			if(!invoiceApply.getDeliveryID().equals(importInvoiceDetail.getRemark())){
				record = false;
			}
		}
		
		/*价税合计 校验*/
		if(!(importInvoiceDetail.getTotalMoney().compareTo(invoiceApply.getApplyMoney()) == 0)){
			record = false;
		}
		
		/*是否已经导入校验:1：已申请，待财务处理 5：已审批 ，10：已拒绝，15：开票完成 */
		if(invoiceApply.getApplyStatus() == 15){
			record = false;
		}
		log.info("shcem.finance.util.InvoiceApply4CheckUtil checkImportInvoiceDetail  End");
		return record;
	}
}
