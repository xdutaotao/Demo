package shcem.finance.util;

public class OrderTradeStatusUtil {
	/**
	 * 通过成交单状态 获取状态名称
	 * @param tradeStatus
	 * @return
	 */
	public static String getTradeStatusName(Integer tradeStatus){
		String name = "";
		switch (tradeStatus) {
		case 1: name = "待买方付款";break;
		case 5: name = "买方已付化交";break;
		case 10: name = "交收处理中";break;
		case 12: name = "买家已付运费 ";break;
		case 15: name = "已传上家";break;
		case 20: name = "签收单已上传";break;
		case 25: name = "物流签收数量已确认";break;
		case 30: name = "待风控审核";break;
		case 35: name = "风控拒绝";break;
		case 40: name = "风控通过，待卖家确认";break;
		case 45: name = "溢短处理中";break;
		case 50: name = "交易完成";break;
		case 55: name = "买家违约";break;
		case 60: name = "卖家违约";break;
		default:
			break;
		}
		return name;
	}
}
