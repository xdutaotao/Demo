/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: SApply
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.model;

import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * (SApply)
 * 
 * @author wlpod
 * @version 1.0.0 2016-05-12
 */
public class SApply extends BaseObject implements java.io.Serializable, Cloneable {

	private static final long serialVersionUID = -7464587171301763763L;

	/** 申请ID */
	private Integer iD;
	/**申请类型（0：现货授信，1：预售授信） */
	private Integer diffType;
	/** 增减区分 0：增 1：减 */
	private Integer applyType;
	/** 申请状态 0：待审核 1：审核通过(待授信) 2：审核不通过 3：已授信 */
	private Integer status;
	/** 交易商代码 */
	private String firmID;
	/** 申请金额 */
	private BigDecimal amount;
	/** 申请人 */
	private String applyer;
	/** 申请时间 */
	private Date applyTime;
	/** 审批人 */
	private String approver;
	/** 审批时间 */
	private Date approveTime;
	/** 备注 */
	private String note;
	/** 拒绝原因 */
	private String refuseReason;


	/** 交易商名称 */
	private String firmName;
	/** 申请人 */
	private String applyerName;
	/** 审核人 */
	private String approverName;

	public Integer getDiffType() {
		return diffType;
	}

	public void setDiffType(Integer diffType) {
		this.diffType = diffType;
	}

	public String getRefuseReason() {
		return refuseReason;
	}

	public void setRefuseReason(String refuseReason) {
		this.refuseReason = refuseReason;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public String getApplyerName() {
		return applyerName;
	}

	public void setApplyerName(String applyerName) {
		this.applyerName = applyerName;
	}

	public String getApproverName() {
		return approverName;
	}

	public void setApproverName(String approverName) {
		this.approverName = approverName;
	}

	public Integer getID() {
		return iD;
	}

	public void setID(Integer iD) {
		this.iD = iD;
	}

	public Integer getApplyType() {
		return applyType;
	}

	public void setApplyType(Integer applyType) {
		this.applyType = applyType;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getApplyer() {
		return applyer;
	}

	public void setApplyer(String applyer) {
		this.applyer = applyer;
	}

	public Date getApplyTime() {
		return applyTime;
	}

	public void setApplyTime(Date applyTime) {
		this.applyTime = applyTime;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public Date getApproveTime() {
		return approveTime;
	}

	public void setApproveTime(Date approveTime) {
		this.approveTime = approveTime;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}