package shcem.finance.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.finance.component.IVoucherManager;
import shcem.finance.component.IVoucherOraManager;
import shcem.finance.dao.model.FVoucher;
import shcem.finance.dao.model.VocherDataList;
import shcem.finance.dao.model.Voucher;
import shcem.finance.dao.model.VoucherAllData;
import shcem.finance.dao.model.VoucherModel;
import shcem.finance.service.IVoucherMgrService;
import shcem.finance.util.FinanceOraSysData;
import shcem.finance.util.FinanceSysData;
import shcem.finance.util.JSONArrayUtil;
import shcem.systemMgr.component.ISystemMgrManager;
import shcem.systemMgr.dao.model.MUser;
import shcem.systemMgr.util.SystemMgrSysData;
import shcem.util.JsonUtil;

public class VoucherMgrServiceImpl extends BaseServiceImpl implements IVoucherMgrService {

	private IVoucherManager mgr = (IVoucherManager) FinanceSysData.getBean(Constants.BEAN_VOUCHER_MGR);
	private IVoucherOraManager mgrOra = (IVoucherOraManager) FinanceOraSysData.getBean(Constants.BEAN_VOUCHERORA_MGR);
	private ISystemMgrManager userMgr = (ISystemMgrManager) SystemMgrSysData.getBean(Constants.BEAN_SYSTEMMGR_MGR);
	@Override
	public String getAllVoucherList(String params) {
		this.log.info(this.getClass().getName() + " getAllVoucherList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<VocherDataList> list = null;
		boolean bolRst = false;
		List<Condition> conditionList = new ArrayList<Condition>(); // 允许的查询参数列表，定义字段，操作符及类型,查询json固定模型queryModel
		conditionList.add(new Condition("fv.VOUCHERNO", "like", "", "String", "vOUCHERNO"));
		conditionList.add(new Condition("fv.SUMMARYNO", "=", "", "String", "sUMMARYNO"));
		conditionList.add(new Condition("convert(char(10),fv.INPUTTIME,120)", " >= ", "", "String", "bDATESTART"));
		conditionList.add(new Condition("convert(char(10),fv.INPUTTIME,120)", " <= ", "", "String", "bDATEEND"));
		conditionList.add(new Condition("fv.STATUS", "=", "", "String", "sTATUS"));

		// 交易商
		conditionList.add(new Condition("fv.FIRMID", "like", "", "String", "firmId"));
		conditionList.add(new Condition("cf.FirmName", "like", "", "String", "firmName"));
		conditionList.add(new Condition("cf.FirmNamePY", "like", "", "String", "firmNamePY"));

		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			list = mgr.getAllVoucherList(qc, pageInfo);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("取得凭证列表失败：" + err.getMessage());
			setResultData("10104", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);

				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("凭证列表数据转换失败：" + e.getMessage());
				setResultData("10104", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getAllVoucherList() End");
		return rtnData.toString();
	}

	@Override
	public String getEditingVoucherList(String params) {
		this.log.info(this.getClass().getName() + " getAllVoucherList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<VocherDataList> list = null;
		boolean bolRst = false;
		List<Condition> conditionList = new ArrayList<Condition>(); // 允许的查询参数列表，定义字段，操作符及类型,查询json固定模型queryModel
		conditionList.add(new Condition("fv.VOUCHERNO", "like", "", "String", "vOUCHERNO"));
		conditionList.add(new Condition("fv.SUMMARYNO", "=", "", "String", "sUMMARYNO"));
		conditionList.add(new Condition("convert(char(10),fv.INPUTTIME,120)", ">=", "", "String", "bDATESTART"));
		conditionList.add(new Condition("convert(char(10),fv.INPUTTIME,120)", "<=", "", "String", "bDATEEND"));
		
		// 交易商
		conditionList.add(new Condition("fv.FIRMID", "like", "", "String", "firmId"));
		conditionList.add(new Condition("cf.FirmName", "like", "", "String", "firmName"));
		conditionList.add(new Condition("cf.FirmNamePY", "like", "", "String", "firmNamePY"));

		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");

		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			list = mgr.getEditingVoucherList(qc, pageInfo);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("取得编辑中凭证列表失败：" + err.getMessage());
			setResultData("10104", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);

				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				this.log.debug("retData:"+ retData.toString());
				this.log.debug("jsonObj:"+ jsonObj.toString());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("编辑中凭证数据转换失败：" + e.getMessage());
				setResultData("10104", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getAllVoucherList() End");
		return rtnData.toString();
	}

	@Override
	public String getAuditingVoucherList(String params) {
		this.log.info(this.getClass().getName() + " getAllVoucherList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<VocherDataList> list = null;
		boolean bolRst = false;
		List<Condition> conditionList = new ArrayList<Condition>(); // 允许的查询参数列表，定义字段，操作符及类型,查询json固定模型queryModel
		conditionList.add(new Condition("fv.VOUCHERNO", "like", "", "String", "vOUCHERNO"));
		conditionList.add(new Condition("fv.SUMMARYNO", "=", "", "String", "sUMMARYNO"));
		conditionList.add(new Condition("convert(char(10),fv.INPUTTIME,120)", " >= ", "", "String", "bDATESTART"));
		conditionList.add(new Condition("convert(char(10),fv.INPUTTIME,120)", " <= ", "", "String", "bDATEEND"));
		// 交易商
		conditionList.add(new Condition("fv.FIRMID", "like", "", "String", "firmId"));
		conditionList.add(new Condition("cf.FirmName", "like", "", "String", "firmName"));
		conditionList.add(new Condition("cf.FirmNamePY", "like", "", "String", "firmNamePY"));

		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");

		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			list = mgr.getAuditingVoucherList(qc, pageInfo);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("取得待审核凭证列表失败：" + err.getMessage());
			setResultData("10104", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);

				jsonObj.put("total",pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("待审核凭证列表数据转换失败：" + e.getMessage());
				setResultData("10104", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getAllVoucherList() End");
		return rtnData.toString();
	}

	@Override
	public String addVoucher(String params) {
		this.log.info(this.getClass().getName() + " addVoucher() Start");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		Voucher voucher = null;
		// 录入人 是登录用户
		voucher = (Voucher) JsonUtil.jsonToBean(JOParams, Voucher.class);
		//String userID = JOParams.getString("userID");
		String userID = this.getUserId();
		
		MUser user = this.userMgr.getMUserByLoginName(userID);
		if (user == null) {
			user = new MUser();
			user.setName("");
		}
		try {
			
			VoucherModel voucherModel = this.mgr.getVoucherModelByCode(voucher.getVoucherModelID());
			String deBitCode = voucherModel.getDEBITCODE().replace("-", voucher.getFirmID());
			String creDitCode = voucherModel.getCREDITCODE().replace("-", voucher.getFirmID());

			int voucherNo = this.mgr.fastVoucher(voucherModel.getSUMMARYNO(), voucherModel.getNAME(), deBitCode,
					creDitCode, voucher.getCONTRACTNO(), user.getName(), voucher.getMoney().toString(),
					voucher.getFirmID());
			if (voucherNo > 0) {
				voucher.setVOUCHERNO(voucherNo);
				this.mgr.updateVoucherNote(voucher);
			}
			setResultData("00000", null);
			this.log.businesslog("生成凭证成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		} catch (Exception e) {
			this.log.error("生成凭证出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("生成凭证出错" + e.getMessage(), Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " addVoucher() End");
		return rtnData.toString();
	}

	private void updateVoucherNote(Voucher voucher) {
		// TODO Auto-generated method stub

	}

	// 提交审核
	@Override
	public String submitAuditVoucher(String params) {
		this.log.info(this.getClass().getName() + " submitAuditVoucher() Start");
		JSONObject JOParams = new JSONObject(params);
		// 提交的凭证号数组
		JSONArray voucherNoCodesTemp = JOParams.getJSONArray("voucherNoCodes");
		long[] voucherNoCodes = JSONArrayUtil.getJsonToLongArray(voucherNoCodesTemp);
		// 是否全部提交
		boolean allFlg = JOParams.getBoolean("allFlg");
		this.log.debug(params);
		try {
			this.mgr.submitAuditVoucher(allFlg, voucherNoCodes);
			setResultData("00000", null);
			this.log.businesslog("提交审核成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		} catch (Exception e) {
			this.log.error("提交审核出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("提交审核出错" + e.getMessage(), Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " submitAuditVoucher() End");
		return rtnData.toString();
	}

	// 审核通过/失败
	@Override
	public String auditVoucher(String params) {
		this.log.info(this.getClass().getName() + " auditVoucher() Start");
		JSONObject JOParams = new JSONObject(params);
		Long voucherNo = JOParams.getLong("vOUCHERNO");
		boolean isPass = JOParams.getBoolean("isPass");
		String loginUserId = this.getUserId();
		this.log.debug("loginUserId: " + loginUserId);
		MUser user = this.userMgr.getMUserByLoginName(loginUserId);
		if (user == null) {
			user = new MUser();
			user.setName("system");
		} else if ("".equals(user.getName())) {
			user.setName("system");
		}
		
		try {
			boolean oldOkFlg = true;
			String msg = "";
			if (isPass) {
				int result = -1;
				// Ora也新建一个审核通过的凭证
				FVoucher voucher = mgr.getVoucher(voucherNo);
				mgr.fixNewOldSubBalance(voucher.getContractno(), voucher.getFirmid());
				if (voucher.getVoucherEntrys() == null || voucher.getVoucherEntrys().size() != 2) {
					oldOkFlg = false;
					msg = "VoucherEntry没有2件或者VoucherEntry的借方貸方code不正確。";
				} else {
					result = mgrOra.fastVoucher(voucher.getSummaryno(), voucher.getSummary(),
							voucher.getVoucherEntrys().get(0).getAccountcode(),
							voucher.getVoucherEntrys().get(1).getAccountcode(), voucher.getContractno(),
							user.getName(), voucher.getVoucherEntrys().get(0).getDebitamount().toString());
					if (result > 0) {
						long oldVocherNo = (long) result;
						// 提交审核
						long[] voucherNoCodes = new long[1];
						voucherNoCodes[0] = oldVocherNo;
						mgrOra.submitAuditVoucher(false, voucherNoCodes);

						// 审核通过
						result = mgrOra.auditVoucher(oldVocherNo, true, "system");
						if (result == -1) {
							oldOkFlg = false;
							msg = "凭证审核失败！请确认摘要与科目是否正确。";
						} else if (result == -2) {
							oldOkFlg = false;
							msg = "凭证审核失败！交易商余额不足。";
						}
					} else {
						oldOkFlg = false;
						msg = "快捷创建凭证失败！";
					}
				}
			}

			if (oldOkFlg) {
				int row = this.mgr.auditVoucher(voucherNo, isPass, user.getName());
				if (row > 0) {
					setResultData("00000", null);
					this.log.businesslog("凭证提交审核成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
				} else {
					setResultData("10106", null, "凭证审核失败！");
				}
			} else {
				setResultData("10106", null, msg);
			}
		} catch (Exception e) {
			this.log.error("凭证提交审核出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("凭证提交审核" + e.getMessage(), Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " auditVoucher() End");
		return rtnData.toString();
	}

	@Override
	public String getVoucherByNo(String params) {
		this.log.info(this.getClass().getName() + " getVoucherByNo() Start");
		boolean bolRst = false;
		JSONObject JOParams = new JSONObject(params);
		Long vOUCHERNO = JOParams.getLong("vOUCHERNO");
		VoucherAllData voucherAllData = null;
		try {
			voucherAllData = this.mgr.getVoucherByNo(vOUCHERNO);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("获取凭证详情出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
		}
		if (bolRst) {
			JSONObject retData;
			try {
				retData = JsonUtil.coverModelToJSONObject(voucherAllData);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error("凭证详情转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getVoucherByNo() End");
		return rtnData.toString();
	}

	@Override
	public String deleteVoucher(String params) {
		this.log.info(this.getClass().getName() + " deleteVoucher() Start");
		JSONObject JOParams = new JSONObject(params);
		// 提交的凭证号数组
		JSONArray voucherNoCodesTemp = JOParams.getJSONArray("voucherNoCodes");
		long[] voucherNoCodes = JSONArrayUtil.getJsonToLongArray(voucherNoCodesTemp);
		int returnCode;
		try {
			returnCode = this.mgr.deleteVoucher(voucherNoCodes);
			if (returnCode >= 1) {
				setResultData("00000", null);
				this.log.businesslog("删除凭证成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
			}else {
				setResultData("10107", null);
			}
			
		} catch (Exception e) {
			this.log.error("删除凭证" + e.getMessage());
			this.log.businesslog("删除凭证" + e.getMessage(), Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			setResultData("10107", null);
		}
		this.log.info(this.getClass().getName() + " deleteVoucher() End");
		return rtnData.toString();
	}

	@Override
	public String updateVoucher(String params) {
		this.log.info(this.getClass().getName() + " updateFirmInfo() Start");
		this.log.debug("updateFirmInfo Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		Voucher voucher = (Voucher) JsonUtil.jsonToBean(JOParams, Voucher.class);
		try {
			this.log.businesslog("更新交易商信息成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		} catch (Exception e) {
			this.log.error("修改交易商信息出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("修改交易商信息出错" + e.getMessage(), Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		}
		return null;
	}

	@Override
	public String oneKeyCreateVoucher(String params) {
		this.log.info(this.getClass().getName() + " oneKeyCreateVoucher() Start");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		Voucher voucher = null;
		// 录入人 是登录用户
		voucher = (Voucher) JsonUtil.jsonToBean(JOParams, Voucher.class);
		voucher.setINPUTUSER("system");

		int result = this.mgr.createNewOldVoucher(voucher.getVoucherModelID(), voucher.getMoney(),
				voucher.getCONTRACTNO(), voucher.getFirmID(), voucher.getNOTE(), voucher.getINPUTUSER());

		if (result < 0) {
			setResultData("10106", null, "凭证生成失败！");
			this.log.businesslog("凭证生成失败！", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		} else {
			setResultData("00000", null);
			this.log.businesslog("生成凭证成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		}

		this.log.info(this.getClass().getName() + " oneKeyCreateVoucher() End");
		return rtnData.toString();
	}
	
	@Override
	public String getAuditStatus(String params) {
		this.log.info(this.getClass().getName() + " getAuditStatus() Start");
		JSONObject JOParams = new JSONObject(params);
		Long voucherNo = JOParams.getLong("vOUCHERNO");
		boolean flag = false;
		this.log.debug(params);
		FVoucher voucher = null;
		try {
			voucher = this.mgr.getVoucher(voucherNo);
			flag = true;
		} catch (Exception e) {
			this.log.error(""+e.getMessage());
			setResultData("10105",null);
		}
		if (flag) {
			JSONObject retData;			
			try {
				retData = JsonUtil.coverModelToJSONObject(voucher);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error("凭证数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		return rtnData.toString();
	}
}
