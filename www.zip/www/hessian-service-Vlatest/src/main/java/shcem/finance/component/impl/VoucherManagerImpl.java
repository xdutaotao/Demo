/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: VoucherManagerImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.component.impl;

import java.math.BigDecimal;
import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.constant.Constants;
import shcem.finance.component.IFirmBanlanceManager;
import shcem.finance.component.IFirmBanlanceOraManager;
import shcem.finance.component.IVoucherManager;
import shcem.finance.component.IVoucherOraManager;
import shcem.finance.dao.VoucherDAO;
import shcem.finance.dao.model.CreatVoucherParam;
import shcem.finance.dao.model.FVoucher;
import shcem.finance.dao.model.FirmBanlanceList;
import shcem.finance.dao.model.FirmBanlanceListForOra;
import shcem.finance.dao.model.PaymentLog;
import shcem.finance.dao.model.PaymentLogDetail;
import shcem.finance.dao.model.VocherDataList;
import shcem.finance.dao.model.Voucher;
import shcem.finance.dao.model.VoucherAllData;
import shcem.finance.dao.model.VoucherModel;
import shcem.finance.util.FinanceOraSysData;
import shcem.finance.util.FinanceSysData;

/**
 * VoucherManagerImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class VoucherManagerImpl extends BaseManager implements IVoucherManager {
	private VoucherDAO dao;
	
	private VoucherDAO voucherDAO_read;
	
	
	
	public void setVoucherDAO_read(VoucherDAO voucherDAO_read) {
		this.voucherDAO_read = voucherDAO_read;
	}

	private IVoucherOraManager mgrOra = (IVoucherOraManager) FinanceOraSysData.getBean(Constants.BEAN_VOUCHERORA_MGR);
	
	private IFirmBanlanceManager balanceMgr = null;;
	private IFirmBanlanceOraManager balanceOraMgr = null;;
	

	public void setVoucherDAO(VoucherDAO dao) {
		this.dao = dao;
	}

	@Override
	public int fastVoucher(String summaryNo, String summary, String debitCode, String creditCode, String contractno,
			String inputUser, String money, String firmID) {
		this.log.debug("fastVoucher Component Start");
		return this.dao.createVoucherFast(summaryNo, summary, debitCode, creditCode, contractno, inputUser, money, firmID);
	}

	@Override
	public void submitAuditVoucher(boolean allFlg, long[] submitCodes) {
		this.log.debug("submitAuditVoucher Component Start");
		if (allFlg) {
			this.dao.submitAllVoucherForAudit();
		} else {
			for (int i = 0; i < submitCodes.length; i++) {
				this.dao.submitVoucherForAudit(new Long(submitCodes[i]));
			}
		}
	}

	@Override
	public int auditVoucher(Long voucherNo, boolean isPass, String loginUserId) {
		this.log.debug("auditVoucher Component Start");
		FVoucher voucher = this.dao.getVoucherByNo(voucherNo);
		voucher.setAuditor(loginUserId);
		this.log.debug("auditVoucher updateVoucherNotEntrys");
		this.dao.updateVoucherNotEntrys(voucher);
		int result = this.dao.auditVoucher(voucherNo, isPass);
		//拒绝，只更新状态
		if (isPass == false) {
			this.dao.rejectAuditVoucher(voucherNo);
		}
		return result;
	}

	@Override
	public List<VocherDataList> getAllVoucherList(QueryConditions qc, PageInfo pageInfo) {
		return this.voucherDAO_read.getAllVoucherList(qc,pageInfo);
	}

	@Override
	public List<VocherDataList> getEditingVoucherList(QueryConditions qc,
			PageInfo pageInfo) {
		return this.voucherDAO_read.getEditingVoucherList(qc,pageInfo);
	}

	@Override
	public List<VocherDataList> getAuditingVoucherList(QueryConditions qc,
			PageInfo pageInfo) {
		return  this.voucherDAO_read.getAuditingVoucherList(qc,pageInfo);
	}

	@Override
	public VoucherAllData getVoucherByNo(Long vOUCHERNO) {
		return this.voucherDAO_read.getVoucherByNos(vOUCHERNO);
	}

	@Override
	public int  deleteVoucher(long[] vOUCHERNO)throws RuntimeException {
		int returnCode;
		String vOUCHERNOs = "";
		for (int i = 0; i < vOUCHERNO.length; i++) {
			if (i >0) vOUCHERNOs += ",";
			vOUCHERNOs +=vOUCHERNO[i];
		}
		/**
		 * 查询是否存在不能删除的记录
		 */
		List<Voucher> list = this.dao.getVoucherList(vOUCHERNOs);
		if (list != null && list.size() > 0) {
			returnCode = -1;
		}else {
			returnCode = this.dao.deleteVoucher(vOUCHERNOs);
		}
		return returnCode;
	}

	@Override
	public VoucherModel getVoucherModelByCode(String voucherModelID) {
		return this.dao.getVoucherModelByCode(voucherModelID);
	}

	@Override
	public void updateVoucherNote(Voucher voucher) {
		this.dao.updateVoucherNote(voucher);
	}
	    
	@Override
	public FVoucher getVoucher(Long voucherNo) {
		this.log.debug("getVoucher Component Start");
		FVoucher voucher = this.voucherDAO_read.getVoucherByNo(voucherNo);
		return voucher;
	}
	
	
	@Override
	public void fixNewOldSubBalance(String contractno, String firmID) {
		// 新资金变成和老资金一样
		BigDecimal[] firmBalances = this.getMoneys(firmID);
		if (firmBalances[0].compareTo(firmBalances[1]) != 0) {
			VoucherModel voucherModel = null;
			BigDecimal Submoney = null;
			if (firmBalances[0].compareTo(firmBalances[1]) == -1) {
				voucherModel = this.getVoucherModelByCode("1");
				voucherModel.setSUMMARYNO("501");
				voucherModel.setNAME("调整余额入金");
				Submoney = firmBalances[1].subtract(firmBalances[0]);
			} else {
				voucherModel = this.getVoucherModelByCode("2");
				voucherModel.setSUMMARYNO("502");
				voucherModel.setNAME("调整余额出金");
				Submoney = firmBalances[0].subtract(firmBalances[1]);
			}
			String deBitCode = voucherModel.getDEBITCODE().replace("-", firmID);
			String creDitCode = voucherModel.getCREDITCODE().replace("-", firmID);
			String summaryNo = voucherModel.getSUMMARYNO();
			String summaryName = voucherModel.getNAME();
			int voucherNo = this.fastVoucher(summaryNo, summaryName, deBitCode, creDitCode, contractno, "system",
					Submoney.toString(), firmID);

			if (voucherNo > 0) {
				Voucher voucher = new Voucher();
				voucher.setVOUCHERNO(voucherNo);
				voucher.setNOTE("新老资金一致处理");
				this.updateVoucherNote(voucher);

				long longVano = (long) voucherNo;
				// 提交审核
				long[] voucherNoCodes = new long[1];
				voucherNoCodes[0] = longVano;
				this.submitAuditVoucher(false, voucherNoCodes);

				// 审核通过
				this.auditVoucher(longVano, true, "system");
			}
		}
	}
	
	@Override
	public int createNewOldVoucherBat(List<CreatVoucherParam> params) {

		int result = -1;

		for (int i = 0; i < params.size(); i++) {
			CreatVoucherParam param = params.get(i);
			log.debug("createNewOldVoucherBat.params循环第" + i + "条，参数： " + param.toString());
			result = createNewOldVoucher(param.getVoucherModelID(), param.getMoney(), param.getContractno(),
					param.getFirmID(), param.getNote(), param.getInputUser());
			log.debug("createNewOldVoucherBat.params循环第" + i + "条，结果： " + result);
			if (result < 0) {
				return result;
			}
		}

		return result;
	}
	
	/**
	 * 快速生成新老凭证
	 */
	@Override
	public int createNewOldVoucher(String voucherModelID, BigDecimal money,
			String contractno, String firmID, String note, String inputUser) {
		this.log.info(this.getClass().getName() + " createNewOldVoucher Start");

		int result = -1;
		long paymentId = this.mgrOra.getPaymentId();
		Integer detailId = 1;
		
		try {
			fixNewOldSubBalance(contractno, firmID);

			this.log.debug("fixNewOldSubBalance end");
			String callerStr = "";
			StackTraceElement[] temp = Thread.currentThread().getStackTrace();
			for (int i = 0; i < temp.length; i++) {
				StackTraceElement caller = (StackTraceElement) temp[i];
				if (caller.getClassName().startsWith("shcem.finance")
						|| caller.getClassName().startsWith("shcem.trade")) {
					callerStr += caller.getClassName() + "." + caller.getMethodName() + "()--->";
				}
			}
			this.log.debug("取得caller end");
			
			PaymentLog paymentLog = new PaymentLog();
			paymentLog.setId(paymentId);
			paymentLog.setCaller(callerStr);
			paymentLog.setPaycount(1);
			paymentLog.setStatus(Constants.PAYMENT_STATUS_FAILED);

			PaymentLogDetail paymentLogDetail = new PaymentLogDetail();
			paymentLogDetail.setId(paymentId);
			paymentLogDetail.setDETAILID(detailId);
			paymentLogDetail.setVoucherModelID(voucherModelID);
			paymentLogDetail.setMoney(money);
			paymentLogDetail.setContractno(contractno);
			paymentLogDetail.setFirmID(firmID);
			paymentLogDetail.setNote(note);
			paymentLogDetail.setInputUser(inputUser);
			paymentLogDetail.setSTATUS(Constants.PAYMENT_DETAIL_STATUS_WAITING);

			this.mgrOra.insertPaymentLog(paymentLog);
			this.mgrOra.insertPaymentLogDetail(paymentLogDetail);
			this.log.debug("insertPaymentLogDetail end");
			
			VoucherModel voucherModel = this.getVoucherModelByCode(voucherModelID);
			if (voucherModel == null) {
				this.log.debug("voucherModelID：" + voucherModelID + "新专场不存在这样的model");
				this.mgrOra.updatePaymentLogDetailStatus(paymentId, detailId, Constants.PAYMENT_DETAIL_STATUS_FAILED);
				this.mgrOra.updatePaymentLogDetailError(paymentId, detailId, -10, "新专场不存在这样的model");
				this.mgrOra.updatePaymentLogEndTime(paymentId);
				this.mgrOra.updatePaymentLogDetailEndTime(paymentId, detailId);
				return -10;
			}

			String oldMode = voucherModel.getOracleModelID();

			if (oldMode == null || "".equals(oldMode)) {
				this.log.debug("oldMode：" + oldMode + "老专场不存在这样的model");
				this.mgrOra.updatePaymentLogDetailStatus(paymentId, detailId, Constants.PAYMENT_DETAIL_STATUS_FAILED);
				this.mgrOra.updatePaymentLogDetailError(paymentId, detailId, -1, "老专场不存在这样的model");
				this.mgrOra.updatePaymentLogEndTime(paymentId);
				this.mgrOra.updatePaymentLogDetailEndTime(paymentId, detailId);
				return -1;
			}
			this.log.debug("取得model end");
			
			this.log.debug("新专场做成凭证开始");
			String deBitCode = voucherModel.getDEBITCODE().replace("-", firmID);
			String creDitCode = voucherModel.getCREDITCODE().replace("-", firmID);
			String summaryNo = voucherModel.getSUMMARYNO();
			String summaryName = voucherModel.getNAME();
			result = this.dao.createAndAuditVoucher(summaryNo, summaryName, deBitCode, creDitCode, contractno,
					inputUser, money.toString(), firmID);

			if (result == -21004) {
				this.rollback();
				this.log.debug("凭证审核失败！请确认摘要与科目是否正确。");
				this.mgrOra.updatePaymentLogDetailStatus(paymentId, detailId, Constants.PAYMENT_DETAIL_STATUS_FAILED);
				this.mgrOra.updatePaymentLogDetailError(paymentId, detailId, -7, "凭证审核失败！请确认摘要与科目是否正确。");
				this.mgrOra.updatePaymentLogEndTime(paymentId);
				this.mgrOra.updatePaymentLogDetailEndTime(paymentId, detailId);
				return -7;
			} else if (result == -2) {
				this.rollback();
				this.log.debug("凭证审核失败！造成201余额为负值。");
				this.mgrOra.updatePaymentLogDetailStatus(paymentId, detailId, Constants.PAYMENT_DETAIL_STATUS_FAILED);
				this.mgrOra.updatePaymentLogDetailError(paymentId, detailId, -8, "凭证审核失败！造成201余额为负值。");
				this.mgrOra.updatePaymentLogEndTime(paymentId);
				this.mgrOra.updatePaymentLogDetailEndTime(paymentId, detailId);
				return -8;
			} else if (result < 0) {
				this.rollback();
				this.log.debug("快捷创建凭证失败！");
				this.mgrOra.updatePaymentLogDetailStatus(paymentId, detailId, Constants.PAYMENT_DETAIL_STATUS_FAILED);
				this.mgrOra.updatePaymentLogDetailError(paymentId, detailId, -6, "快捷创建凭证失败！");
				this.mgrOra.updatePaymentLogEndTime(paymentId);
				this.mgrOra.updatePaymentLogDetailEndTime(paymentId, detailId);
				return -6;
			}
			this.log.debug("新专场做成凭证结束");

			this.log.debug("老专场做成凭证开始");
			String[] oldThings = this.exMode(oldMode);
			result = this.mgrOra.createAndAuditVoucher(oldThings[0], oldThings[3], oldThings[1].replace("-", firmID),
					oldThings[2].replace("-", firmID), contractno, inputUser, money.toString());

			if (result == -1) {
				this.rollback();
				this.log.debug("凭证审核失败！请确认摘要与科目是否正确。");
				this.mgrOra.updatePaymentLogDetailStatus(paymentId, detailId, Constants.PAYMENT_DETAIL_STATUS_FAILED);
				this.mgrOra.updatePaymentLogDetailError(paymentId, detailId, -3, "凭证审核失败！请确认摘要与科目是否正确。");
				this.mgrOra.updatePaymentLogEndTime(paymentId);
				this.mgrOra.updatePaymentLogDetailEndTime(paymentId, detailId);
				return -3;
			} else if (result == -2) {
				this.rollback();
				this.log.debug("凭证审核失败！造成201余额为负值。");
				this.mgrOra.updatePaymentLogDetailStatus(paymentId, detailId, Constants.PAYMENT_DETAIL_STATUS_FAILED);
				this.mgrOra.updatePaymentLogDetailError(paymentId, detailId, -4, "凭证审核失败！造成201余额为负值。");
				this.mgrOra.updatePaymentLogEndTime(paymentId);
				this.mgrOra.updatePaymentLogDetailEndTime(paymentId, detailId);
				return -4;
			} else if (result < 0) {
				this.rollback();
				this.log.debug("快捷创建凭证失败！");
				this.mgrOra.updatePaymentLogDetailStatus(paymentId, detailId, Constants.PAYMENT_DETAIL_STATUS_FAILED);
				this.mgrOra.updatePaymentLogDetailError(paymentId, detailId, -5, "快捷创建凭证失败！");
				this.mgrOra.updatePaymentLogEndTime(paymentId);
				this.mgrOra.updatePaymentLogDetailEndTime(paymentId, detailId);
				return -5;
			}
			this.log.debug("老专场做成凭证结束");
		} catch (Exception e) {
			this.rollback();
			this.log.error("createNewOldVoucher时Exception发生：" + e.getMessage());
			this.mgrOra.updatePaymentLogDetailStatus(paymentId, detailId, Constants.PAYMENT_DETAIL_STATUS_FAILED);
			this.mgrOra.updatePaymentLogDetailError(paymentId, detailId, -11, "createNewOldVoucher时Exception发生：" + e.getMessage());
			this.mgrOra.updatePaymentLogEndTime(paymentId);
			this.mgrOra.updatePaymentLogDetailEndTime(paymentId, detailId);
			return -11;
		}

		this.mgrOra.updatePaymentLogStatus(paymentId, Constants.PAYMENT_STATUS_SUCCESS);
		this.mgrOra.updatePaymentLogDetailStatus(paymentId, detailId, Constants.PAYMENT_DETAIL_STATUS_SUCCESS);
		this.mgrOra.updatePaymentLogEndTime(paymentId);
		this.mgrOra.updatePaymentLogDetailEndTime(paymentId, detailId);
		
		return result;
	}
	
	/**
	 * 新专场可用资金 ， 老专场可用资金取得
	 * 
	 * @param firmID
	 * @param tmplID
	 * @param cateID
	 * @param brandID
	 * @param tradeRole
	 * @param price
	 * @param quantity
	 * @param tradeUnitNumber
	 * @return BigDecimal[0] 新专场可用资金 BigDecimal[1] 老专场可用资金
	 */
	private BigDecimal[] getMoneys(String firmID) {
		balanceMgr = (IFirmBanlanceManager) FinanceSysData.getBean(Constants.BEAN_BALANCE_MGR);;
		balanceOraMgr = (IFirmBanlanceOraManager) FinanceOraSysData.getBean(Constants.BEAN_BALANCEORA_MGR);;
		BigDecimal newBalance = new BigDecimal(0.00); // 新专场可用资金
		BigDecimal oldBalance = new BigDecimal(0.00); // 老专场可用资金

		QueryConditions qc = new QueryConditions();
		qc.addCondition("t1.FIRMID", "=", firmID);
		List<FirmBanlanceList> list1 = balanceMgr.queryFirmBanlance(qc, null);
		if (list1 != null && list1.size() > 0 && list1.get(0).getBALANCE() != null) {
			newBalance = list1.get(0).getBALANCE();
		}

		List<FirmBanlanceListForOra> list2 = balanceOraMgr.queryFirmBanlance(qc, null);
		if (list2 != null && list2.size() > 0 && list2.get(0).getUSER_BALANCE() != null) {
			oldBalance = list2.get(0).getUSER_BALANCE();
		}

		return new BigDecimal[] { newBalance, oldBalance };
	}
	
	/**
	 * 快速生成老凭证(老专场数据rollback用)
	 */
	@Override
	public int createOldVoucher(String voucherModelID, BigDecimal money,
			String contractno, String firmID, String note, String inputUser) {
		int result;

		VoucherModel voucherModel = this.getVoucherModelByCode(voucherModelID);
		String oldMode = voucherModel.getOracleModelID();

		if (oldMode == null || "".equals(oldMode)) {
			this.log.debug("voucherModelID：" + voucherModelID + "老专场不存在这样的model");
			return -1;
		}

		this.log.debug("老专场做成凭证开始");
		String[] oldThings = this.exMode(oldMode);
		int oldVoucherNo = this.mgrOra.fastVoucher(oldThings[0], oldThings[3], oldThings[1].replace("-", firmID),
				oldThings[2].replace("-", firmID), contractno, inputUser, money.toString());
		if (oldVoucherNo > 0) {
			long longOldVano = (long) oldVoucherNo;
			// 提交审核
			long[] voucherNoCodes = new long[1];
			voucherNoCodes[0] = longOldVano;
			this.mgrOra.submitAuditVoucher(false, voucherNoCodes);

			// 审核通过
			result = this.mgrOra.auditVoucher(longOldVano, true, "system");
			if (result == -1) {
				this.log.debug("凭证审核失败！请确认摘要与科目是否正确。");
				return -3;
			} else if (result == -2) {
				this.log.debug("凭证审核失败！造成201余额为负值。");
				return -4;
			} else if (result < 0) {
				this.log.debug("凭证审核失败！");
				return -5;
			}
		} else {
			this.log.debug("快捷创建凭证失败！");
			return -2;
		}
		this.log.debug("老专场做成凭证结束");

		return result;
	}
	
	/**
	 * 老系统对应model数据取得
	 * 
	 * @param oldMode
	 * @return rtnStrings[0]:summaryNo rtnStrings[1]:debitcode
	 *         rtnStrings[2]:creditcode rtnStrings[3]:summaryName
	 */
	private String[] exMode(String oldMode) {
		VoucherModel voucherModel = this.mgrOra.getVoucherModelByCode(oldMode);
		
		String[] rtnStrings = new String[4];
		rtnStrings[0] = voucherModel.getSUMMARYNO();
		rtnStrings[1] = voucherModel.getDEBITCODE();
		rtnStrings[2] = voucherModel.getCREDITCODE();
		rtnStrings[3] = voucherModel.getNAME();
		return rtnStrings;
	}
	
	@Override
	public void rollback() {
		this.dao.rollBack();
		this.mgrOra.rollback();
	}


}
