/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: BalanceServiceModel
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.service.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.json.JSONObject;

import shcem.base.service.model.BaseServiceObject;

/**
 * @author wlpod
 *
 */
public class BalanceServiceModel extends BaseServiceObject implements Serializable {

	private static final long serialVersionUID = -7464587171301763763L;

	// F_FirmFunds交易商资金表
	/** 交易商ID */
	private String FIRMID;
	
	/** 交易商名 */
	private String FIRMNAME;

	/** 当前余额 */
	private BigDecimal BALANCE;

	/** 冻结额 */
	private BigDecimal FROZENFUNDS;

	/** 期初额 */
	private BigDecimal LASTBALANCE;

	/** 担保金 */
	private BigDecimal LASTWARRANTY;

	/** 结算保证金 */
	private BigDecimal SETTLEMARGIN;

	/** 最后结算保证金 */
	private BigDecimal LASTSETTLEMARGIN;

	// S_FirmFunds交易商授信资金表
	/** 当前余额 */
	private BigDecimal BALANCEFromS;

	/** 冻结额（已使用金额） */
	private BigDecimal FROZENFUNDSFromS;

	/** 期初额（初期设置额度） */
	private BigDecimal LASTBALANCEFromS;

	/** 授信时间 */
	private Date CREDITDATEFromS;

	// 老专场资金
	/** 交易商名称 */
	private String NAME;

	/** 交易系统当前余额 */
	private BigDecimal FBALANCEFromOra;

	/** 财务结算余额 */
	private BigDecimal LBALANCEFromOra;

	/** 财务未结算金额 */
	private BigDecimal YBALANCEFromOra;

	/** 差额 */
	private BigDecimal BALANCESUBTRACTFromOra;

	/** 担保金 */
	private BigDecimal LASTWARRANTYFromOra;

	/** 临时资金 */
	private BigDecimal FROZENFUNDSFromOra;

	/** 可提资金 */
	private BigDecimal USERBALANCEFromOra;

	public String getFIRMID() {
		return FIRMID;
	}

	public void setFIRMID(String fIRMID) {
		FIRMID = fIRMID;
	}
	
	public String getFIRMNAME() {
		return FIRMNAME;
	}

	public void setFIRMNAME(String fIRMNAME) {
		FIRMNAME = fIRMNAME;
	}

	public BigDecimal getBALANCE() {
		return BALANCE;
	}

	public void setBALANCE(BigDecimal bALANCE) {
		BALANCE = bALANCE;
	}

	public BigDecimal getFROZENFUNDS() {
		return FROZENFUNDS;
	}

	public void setFROZENFUNDS(BigDecimal fROZENFUNDS) {
		FROZENFUNDS = fROZENFUNDS;
	}

	public BigDecimal getLASTBALANCE() {
		return LASTBALANCE;
	}

	public void setLASTBALANCE(BigDecimal lASTBALANCE) {
		LASTBALANCE = lASTBALANCE;
	}

	public BigDecimal getLASTWARRANTY() {
		return LASTWARRANTY;
	}

	public void setLASTWARRANTY(BigDecimal lASTWARRANTY) {
		LASTWARRANTY = lASTWARRANTY;
	}

	public BigDecimal getSETTLEMARGIN() {
		return SETTLEMARGIN;
	}

	public void setSETTLEMARGIN(BigDecimal sETTLEMARGIN) {
		SETTLEMARGIN = sETTLEMARGIN;
	}

	public BigDecimal getLASTSETTLEMARGIN() {
		return LASTSETTLEMARGIN;
	}

	public void setLASTSETTLEMARGIN(BigDecimal lASTSETTLEMARGIN) {
		LASTSETTLEMARGIN = lASTSETTLEMARGIN;
	}

	public BigDecimal getBALANCEFromS() {
		return BALANCEFromS;
	}

	public void setBALANCEFromS(BigDecimal bALANCEFromS) {
		BALANCEFromS = bALANCEFromS;
	}

	public BigDecimal getFROZENFUNDSFromS() {
		return FROZENFUNDSFromS;
	}

	public void setFROZENFUNDSFromS(BigDecimal fROZENFUNDSFromS) {
		FROZENFUNDSFromS = fROZENFUNDSFromS;
	}

	public BigDecimal getLASTBALANCEFromS() {
		return LASTBALANCEFromS;
	}

	public void setLASTBALANCEFromS(BigDecimal lASTBALANCEFromS) {
		LASTBALANCEFromS = lASTBALANCEFromS;
	}

	public Date getCREDITDATEFromS() {
		return CREDITDATEFromS;
	}

	public void setCREDITDATEFromS(Date cREDITDATEFromS) {
		CREDITDATEFromS = cREDITDATEFromS;
	}

	public String getNAME() {
		return NAME;
	}

	public void setNAME(String nAME) {
		NAME = nAME;
	}

	public BigDecimal getFBALANCEFromOra() {
		return FBALANCEFromOra;
	}

	public void setFBALANCEFromOra(BigDecimal fBALANCEFromOra) {
		FBALANCEFromOra = fBALANCEFromOra;
	}

	public BigDecimal getLBALANCEFromOra() {
		return LBALANCEFromOra;
	}

	public void setLBALANCEFromOra(BigDecimal lBALANCEFromOra) {
		LBALANCEFromOra = lBALANCEFromOra;
	}

	public BigDecimal getYBALANCEFromOra() {
		return YBALANCEFromOra;
	}

	public void setYBALANCEFromOra(BigDecimal yBALANCEFromOra) {
		YBALANCEFromOra = yBALANCEFromOra;
	}

	public BigDecimal getBALANCESUBTRACTFromOra() {
		return BALANCESUBTRACTFromOra;
	}

	public void setBALANCESUBTRACTFromOra(BigDecimal bALANCESUBTRACTFromOra) {
		BALANCESUBTRACTFromOra = bALANCESUBTRACTFromOra;
	}

	public BigDecimal getLASTWARRANTYFromOra() {
		return LASTWARRANTYFromOra;
	}

	public void setLASTWARRANTYFromOra(BigDecimal lASTWARRANTYFromOra) {
		LASTWARRANTYFromOra = lASTWARRANTYFromOra;
	}

	public BigDecimal getFROZENFUNDSFromOra() {
		return FROZENFUNDSFromOra;
	}

	public void setFROZENFUNDSFromOra(BigDecimal fROZENFUNDSFromOra) {
		FROZENFUNDSFromOra = fROZENFUNDSFromOra;
	}

	public BigDecimal getUSERBALANCEFromOra() {
		return USERBALANCEFromOra;
	}

	public void setUSERBALANCEFromOra(BigDecimal uSERBALANCEFromOra) {
		USERBALANCEFromOra = uSERBALANCEFromOra;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toString()
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toJSONObject()
	 */
	@Override
	public JSONObject toJSONObject() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#hashCode()
	 */
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
