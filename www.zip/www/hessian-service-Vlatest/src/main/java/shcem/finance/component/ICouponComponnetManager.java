package shcem.finance.component;

import java.math.BigDecimal;
import java.util.List;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.model.Coupon;
import shcem.finance.dao.model.CouponApply;
import shcem.finance.dao.model.CouponFlow;

public abstract interface ICouponComponnetManager extends Manager  {

	/**
	 * 插入 优惠券申请
	 * @param couponApply
	 * @return
	 */
	int insertCouponApply(CouponApply couponApply);
	
	/**
	 * 根据ID 查询优惠券申请
	 * @param couponApply
	 * @return
	 */
	CouponApply selectCouponApplyById(Integer id);
	
	/**
	 * 根据ID 更新优惠券申请的 申请状态
	 * @param couponApply
	 * @return
	 */
	int updateCouponApplyOfStatusById(CouponApply couponApply);
	
	/**
	 * 查询优惠券申请列表
	 */
	List<CouponApply> queryCouponApplyList(QueryConditions qc, PageInfo pageInfo);
	
	
	/**
	 * 插入 优惠券
	 */
	int insertCoupon(Coupon coupon);
	
	/**
	 * 更新 优惠券
	 */
	int updateCouponById(Coupon coupon);
	
	/**
	 * 查询优惠券列表
	 */
	List<Coupon> queryCouponList(QueryConditions qc, PageInfo pageInfo);
	
	
	/**
	 * 插入 优惠券流水
	 */
	int insertCouponFlow(CouponFlow couponFlow);
	
	/**
	 * 查询 优惠券 根据FirmID
	 */
	Coupon selectCouponByFirmID(String firmID);
	
	/**
	 * 查询 优惠券流水列表
	 */
	List<CouponFlow> queryCouponFlowList(QueryConditions qc, PageInfo pageInfo);
	
	int getFee(String firmID, BigDecimal money, String ObjectID,int objectType, int flowType, String Operator);
	
	/**
	 * 审核申请过的优惠券
	 * @param couponApplyId 优惠券的申请ID
	 * @param userName 用户名
	 * @param refuseReason 审核通过和审核拒绝的备注。
	 * @return
	 */
	public int passCouponApply(Integer couponApplyId,String userName,String refuseReason);
	
	/**
	 * 操作优惠券
	 * @param firmID 交易商ID
	 * @param money 充值金额
	 * @param operCode 业务代码（摘要号） 关联F_Summary.SummaryNO。801 充值优惠券余额、802 扣除优惠券余额、其他请查表
	 * @param ObjectID  0:F_NewCouponTrans.CouponNumber 1:T_Order.OrderID 2:T_Leads.ID 3:F_CouponApply.ID 4:T_Enquiry.EnquiryId 5:T_Delivery.DeliveryID
	 * @param objectType  0:优惠券号 1:订单ID 2:报盘ID 3:优惠券申请ID 4:询盘ID 5:交收单ID
	 * @param flowType  0充值 1扣除  2抵用
	 * @param Operator 操作人
	 * @return
	 */
	int operationCoupon(String firmID, BigDecimal money, String operCode, String ObjectID,int objectType, int flowType, String Operator);
	
	public abstract void rollback();
	
}
