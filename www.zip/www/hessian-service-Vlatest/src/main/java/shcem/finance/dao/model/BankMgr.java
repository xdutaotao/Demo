/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: BankMgr
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import shcem.base.dao.model.BaseObject;

/**
 * BankMgr
 * @author chiyong
 * @version 1.0
 */
public class BankMgr extends BaseObject implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer id;


	public Integer getSectionID() {
		return this.id;
	}

	public void setSectionID(Integer sectionID) {
		this.id = sectionID;
	}



	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof BankMgr))
			return false;

		BankMgr m = (BankMgr) o;

		return this.id != null ? this.id.equals(m.id) : m.id == null;
	}

	public int hashCode() {
		return this.id != null ? this.id.hashCode() : 0;
	}
}
