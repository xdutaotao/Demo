package shcem.finance.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.bouncycastle.pqc.math.linearalgebra.BigEndianConversions;

import shcem.base.dao.model.BaseObject;

/**
 * 开票信息
 * @author zhangnan
 *
 */
public class FinancialBills extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1364076654157332010L;
	
	/**交收单号*/
	private  String deliveryID;
	
	/**订单号*/
	private  String orderId;
	
	private String firmID;
	/**交收单号*/
	private  String firmName;
	
	/**开票费用类型 1：货款 2：手续费*/
	private  Integer applyType;
	
	/**品类牌号*/
	private  String goodName;
	
	/**成交单价(元)*/
	private  BigDecimal price;
	
	/**交收数量(吨)*/
	private  BigDecimal deliveryQuantity;
	
	/**签收数量(吨)*/
	private  BigDecimal takenQuantity;
	
	/**货款金额*/
	private  BigDecimal deliveryQuantityMoney;
	
	/**手续费金额*/
	private  BigDecimal commissionCharge;
	
	/**开票金额*/
	private  BigDecimal takenQuantityMoney;
	
	/**开票银行账号*/
	private  String vatBkAccount;
	
	/**税号*/
	private String taxNo;
	
	/**开户行名称*/
	private  String VatBankName;
	/**开户行支行名称*/
	private String vatBkBranch;
	
	/**开票地址*/
	private  String VatBankAddress;
	
	/** 开票状态 0：未申请   1：已申请，待财务处理 5：已审批 ，10：已拒绝，15：开票完成    */
	private  Integer financialBillsType;
	
	private Integer bankID;
	
	/** 开票电话*/
	private String invoiceTel;
	/** 收票电话*/
	private String collectTel;
	/** 收票地址*/
	private String collectInvoiceAddress;
	/** 收票人*/
	private String collectInvoicePeople;
	// 交收状态
	private Integer deliveryStatus;
	// 升贴水
	private BigDecimal overloadFee;
	
	/** 交收类型 0: 自提；1:配送,2:转货权  */
	private Integer deliveryType;
	
	/*运费*/
	private BigDecimal freightFee;
	
	/**是否开启手续费开票 ：0 否  1是*/
	private Integer isInvoiceOpenFee;
	
	/**是否开启货款开票 ：0 否  1是*/
	private Integer isInvoiceOpenAmout;
	
	/**订单成交日期*/
	private Date tradeDate;
	
	/** 交收重量 */
	private BigDecimal deliveryWeight;
	
	/**
	 * 调整运费额：因为溢短而发生的运费变动，多退少补。该值为正数，则扣买方，加卖方。该值为负数，则扣卖方，加买方  
	 */
	private BigDecimal overloadFreight;
	
	/**是否参与保价：0不参与 1参与 */
	private Integer isNeedInsurance;

	/**
	 * 实退保金额
	 */
	private BigDecimal realBackAmount;
	

	public String getDeliveryID() {
		return deliveryID;
	}

	public void setDeliveryID(String deliveryID) {
		this.deliveryID = deliveryID;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}


	public String getGoodName() {
		return goodName;
	}

	public void setGoodName(String goodName) {
		this.goodName = goodName;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public BigDecimal getDeliveryQuantity() {
		return deliveryQuantity;
	}

	public void setDeliveryQuantity(BigDecimal deliveryQuantity) {
		this.deliveryQuantity = deliveryQuantity;
	}

	public BigDecimal getTakenQuantity() {
		return takenQuantity;
	}

	public void setTakenQuantity(BigDecimal takenQuantity) {
		this.takenQuantity = takenQuantity;
	}

	public BigDecimal getDeliveryQuantityMoney() {
		return deliveryQuantityMoney;
	}

	public void setDeliveryQuantityMoney(BigDecimal deliveryQuantityMoney) {
		this.deliveryQuantityMoney = deliveryQuantityMoney;
	}

	public BigDecimal getCommissionCharge() {
		return commissionCharge;
	}

	public void setCommissionCharge(BigDecimal commissionCharge) {
		this.commissionCharge = commissionCharge;
	}

	public BigDecimal getTakenQuantityMoney() {
		return takenQuantityMoney;
	}

	public void setTakenQuantityMoney(BigDecimal takenQuantityMoney) {
		this.takenQuantityMoney = takenQuantityMoney;
	}

	public String getVatBkAccount() {
		return vatBkAccount;
	}

	public void setVatBkAccount(String vatBkAccount) {
		this.vatBkAccount = vatBkAccount;
	}

	public String getVatBankName() {
		return VatBankName;
	}

	public void setVatBankName(String vatBankName) {
		VatBankName = vatBankName;
	}

	public String getVatBankAddress() {
		return VatBankAddress;
	}

	public void setVatBankAddress(String vatBankAddress) {
		VatBankAddress = vatBankAddress;
	}

	public Integer getFinancialBillsType() {
		return financialBillsType;
	}

	public void setFinancialBillsType(Integer financialBillsType) {
		this.financialBillsType = financialBillsType;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getTaxNo() {
		return taxNo;
	}

	public void setTaxNo(String taxNo) {
		this.taxNo = taxNo;
	}

	public Integer getApplyType() {
		return applyType;
	}

	public void setApplyType(Integer applyType) {
		this.applyType = applyType;
	}

	public Integer getBankID() {
		return bankID;
	}

	public void setBankID(Integer bankID) {
		this.bankID = bankID;
	}

	public String getInvoiceTel() {
		return invoiceTel;
	}

	public void setInvoiceTel(String invoiceTel) {
		this.invoiceTel = invoiceTel;
	}

	public String getCollectTel() {
		return collectTel;
	}

	public void setCollectTel(String collectTel) {
		this.collectTel = collectTel;
	}

	public String getCollectInvoiceAddress() {
		return collectInvoiceAddress;
	}

	public void setCollectInvoiceAddress(String collectInvoiceAddress) {
		this.collectInvoiceAddress = collectInvoiceAddress;
	}

	public String getCollectInvoicePeople() {
		return collectInvoicePeople;
	}

	public void setCollectInvoicePeople(String collectInvoicePeople) {
		this.collectInvoicePeople = collectInvoicePeople;
	}

	public String getVatBkBranch() {
		return vatBkBranch;
	}

	public void setVatBkBranch(String vatBkBranch) {
		this.vatBkBranch = vatBkBranch;
	}

	public Integer getDeliveryStatus() {
		return deliveryStatus;
	}

	public void setDeliveryStatus(Integer deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}

	public BigDecimal getOverloadFee() {
		return overloadFee;
	}

	public void setOverloadFee(BigDecimal overloadFee) {
		this.overloadFee = overloadFee;
	}

	public Integer getDeliveryType() {
		return deliveryType;
	}

	public void setDeliveryType(Integer deliveryType) {
		this.deliveryType = deliveryType;
	}

	public BigDecimal getFreightFee() {
		return freightFee;
	}

	public void setFreightFee(BigDecimal freightFee) {
		this.freightFee = freightFee;
	}

	public Integer getIsInvoiceOpenFee() {
		return isInvoiceOpenFee;
	}

	public void setIsInvoiceOpenFee(Integer isInvoiceOpenFee) {
		this.isInvoiceOpenFee = isInvoiceOpenFee;
	}

	public Integer getIsInvoiceOpenAmout() {
		return isInvoiceOpenAmout;
	}

	public void setIsInvoiceOpenAmout(Integer isInvoiceOpenAmout) {
		this.isInvoiceOpenAmout = isInvoiceOpenAmout;
	}

	public Date getTradeDate() {
		return tradeDate;
	}

	public void setTradeDate(Date tradeDate) {
		this.tradeDate = tradeDate;
	}

	public BigDecimal getDeliveryWeight() {
		return deliveryWeight;
	}

	public void setDeliveryWeight(BigDecimal deliveryWeight) {
		this.deliveryWeight = deliveryWeight;
	}

	public BigDecimal getOverloadFreight() {
		return overloadFreight;
	}

	public void setOverloadFreight(BigDecimal overloadFreight) {
		this.overloadFreight = overloadFreight;
	}

	public Integer getIsNeedInsurance() {
		return isNeedInsurance;
	}

	public void setIsNeedInsurance(Integer isNeedInsurance) {
		this.isNeedInsurance = isNeedInsurance;
	}

	public BigDecimal getRealBackAmount() {
		return realBackAmount;
	}

	public void setRealBackAmount(BigDecimal realBackAmount) {
		this.realBackAmount = realBackAmount;
	}


}
