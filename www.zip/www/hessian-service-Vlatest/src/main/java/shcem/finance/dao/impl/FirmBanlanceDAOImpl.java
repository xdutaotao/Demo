/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmBanlanceDAOImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.impl;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCallback;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.constant.Constants;
import shcem.finance.dao.FirmBanlanceDAO;
import shcem.finance.dao.model.CancelDetail;
import shcem.finance.dao.model.FBOutMoneyApply;
import shcem.finance.dao.model.FeeModel;
import shcem.finance.dao.model.FirmBanlanceList;
import shcem.finance.dao.model.TDelivery;
import shcem.finance.dao.model.TEnquiry;
import shcem.finance.dao.model.TLeads;
import shcem.finance.dao.model.TOrder;
import shcem.util.Common;
import shcem.util.CommonRowMapper;

/**
 * FirmBanlanceDAOImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class FirmBanlanceDAOImpl extends BaseDAOImpl implements FirmBanlanceDAO {

	/**
	 * 交易商当前资金查询
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	@Override
	public List<FirmBanlanceList> queryFirmBanlance(QueryConditions qc, PageInfo pageInfo) {
		List<FirmBanlanceList> list = new ArrayList<FirmBanlanceList>();
		this.log.debug("queryFirmBanlance DAO Start");
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_001");
		list = queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new FirmBanlanceList()));
		return list;
	}
	
	/**
	 * 查询出金申请列表
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	@Override
	public List<FirmBanlanceList> queryOutMoneyList(QueryConditions qc, PageInfo pageInfo) {
		List<FirmBanlanceList> list = new ArrayList<FirmBanlanceList>();
		this.log.debug("queryFirmBanlance DAO Start");
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_044");
		list = queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new FirmBanlanceList()));
		return list;
	}

	@Override
	public TLeads getLeadsById(Long leadsId) {
		this.log.debug("getLeadsById DAO Start");
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_005");
		Object[] params = new Object[] { leadsId };
		return (TLeads) queryForObject(sql, params, new CommonRowMapper(new TLeads()));
	}

	@Override
	public TEnquiry getEnquiryById(Long enquiryId) {
		this.log.debug("getEnquiryById DAO Start");
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_006");
		Object[] params = new Object[] { enquiryId };
		return (TEnquiry) queryForObject(sql, params, new CommonRowMapper(new TEnquiry()));
	}

	@Override
	public TOrder getOrderById(String orderId) {
		this.log.debug("getOrderById DAO Start");
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_007");
		Object[] params = new Object[] { orderId };
		return (TOrder) queryForObject(sql, params, new CommonRowMapper(new TOrder()));
	}

	@Override
	public TDelivery getDeliveryById(String deliveryId) {
		this.log.debug("getDeliveryById DAO Start");
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_015");
		Object[] params = new Object[] { deliveryId };
		return (TDelivery) queryForObject(sql, params, new CommonRowMapper(new TDelivery()));
	}

	/**
	 * 
	 * @param model
	 *            1: Proc_SP_FundForLeads 2：Proc_SP_FundForEnquiry
	 *            3：Proc_SP_FundForOrderDirect 4：Proc_SP_FundForOrderEnquiry
	 *            5：Proc_SP_FundForOrderSellProc 6：Proc_SP_CancleLeadsForRefund
	 *            7：Proc_SP_CancleEnquiryForRefund
	 *            8：Proc_SP_DeliverySellerForFunds
	 *            13: Proc_SP_ReleaseEnquiry_LLDPE
	 *            14: Proc_SP_CancleLeadsForRefund_LLDPE
	 *            15: Proc_SP_ReleaseLeads_LLDPE
	 * @param bsFlg 0卖 1买
	 * @param fundsBalance
	 * @param creditBalance
	 * @return
	 */
	@Override
	public FeeModel getFeeModel(final int model, final String id, final BigDecimal fundsBalance,
			final BigDecimal creditBalance, final int coupon, final BigDecimal couponAmount, final int bsFlg) {
		this.log.debug("getFeeModel model = " + model + " Start");
		this.log.debug("param : id, fundsBalance, creditBalance, coupon, couponAmount, bsFlg = " + id + ", " + fundsBalance
				+ ", " + creditBalance + ", " + coupon + ", " + couponAmount + ", " + bsFlg);
		String sql = "";
		switch (model) {
		case 1:
			sql = "FirmBanlanceDAO_008";// Proc_SP_FundForLeads
			break;
		case 2:
			sql = "FirmBanlanceDAO_009";// Proc_SP_FundForEnquiry
			break;
		case 3:
			sql = "FirmBanlanceDAO_010";// Proc_SP_FundForOrderDirect
			break;
		case 4:
			sql = "FirmBanlanceDAO_011";// Proc_SP_FundForOrderEnquiry
			break;
		case 5:
			sql = "FirmBanlanceDAO_012";// Proc_SP_FundForOrderSellProc
			break;
		case 6:
			sql = "FirmBanlanceDAO_013";// Proc_SP_CancleLeadsForRefund
			break;
		case 7:
			sql = "FirmBanlanceDAO_014";// Proc_SP_CancleEnquiryForRefund
			break;
		case 8:
			sql = "FirmBanlanceDAO_016";// Proc_SP_DeliverySellerForFunds
			break;
		case 9:
			sql = "FirmBanlanceDAO_017";// Proc_SP_PaymentBuyer
			break;
		case 10:
			sql = "FirmBanlanceDAO_018";// Proc_SP_DeliveryBuyerForFunds
			break;
		case 11:
			sql = "FirmBanlanceDAO_023";// Proc_SP_ModifyLeads
			break;
		case 12:
			sql = "FirmBanlanceDAO_024";// Proc_SP_ModifyLeads
			break;
		case 13:
			sql = "FirmBanlanceDAO_041";// Proc_SP_ReleaseEnquiry_LLDPE
			break;
		case 14:
			sql = "FirmBanlanceDAO_042";// Proc_SP_CancleLeadsForRefund_LLDPE
			break;
		case 15:
			sql = "FirmBanlanceDAO_043";// Proc_SP_ReleaseLeads_LLDPE
			break;
		default:
			break;
		}

		String procedure = sqlProperty.getProperty(sql);
		FeeModel retM = new FeeModel();
		try {
			retM = (FeeModel) this.getJdbcTemplate().execute(procedure, new CallableStatementCallback() {
				public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {
					FeeModel feeModel = new FeeModel();
					if (model == 1 || model == 2 || model == 11) {
						cs.setLong(1, Long.parseLong(id));
						cs.setBigDecimal(2, fundsBalance);
						cs.setBigDecimal(3, creditBalance);
					} else if (model == 3 || model == 4) {
						cs.setString(1, id);
						cs.setBigDecimal(2, fundsBalance);
						cs.setBigDecimal(3, creditBalance);
					} else if (model == 5 || model == 8) {
						cs.setString(1, id);
					} else if (model == 6 || model == 7) {
						cs.setLong(1, Long.parseLong(id));
					} else if (model == 10) {
						cs.setString(1, id);
						cs.setBigDecimal(2, fundsBalance);
					} else if (model == 9) {
						cs.setString(1, id);
						cs.setBigDecimal(2, fundsBalance);
						cs.setInt(3, coupon);
						cs.setBigDecimal(4, couponAmount);
					} else if (model == 12) {
						cs.setString(1, id);
						cs.setBigDecimal(2, fundsBalance);
						cs.setBigDecimal(3, creditBalance);
						cs.setInt(4, bsFlg);
					} else if (model == 13 || model == 14 || model == 15) {
						// 期现市场追加
						cs.setLong(1, Long.parseLong(id));
					} 
					
					ResultSet rs = cs.executeQuery();
					while (rs.next()) {
						if (model == 1 || model == 2 || model == 3 || model == 5 || model == 11) {
							feeModel.setTakenTradeFee(rs.getBigDecimal("v_TakenTradeFee"));
							feeModel.setTakenTradeDeposit(rs.getBigDecimal("v_TakenTradeDeposit"));
							feeModel.setCreditFee(rs.getBigDecimal("v_CreditFee"));
							feeModel.setCreditDeposit(rs.getBigDecimal("v_CreditDeposit"));
							feeModel.setReturnCode(rs.getInt("v_Return"));
						} else if (model == 6 || model == 7) {
							feeModel.setTakenTradeFee(rs.getBigDecimal("v_TakenTradeFee"));
							feeModel.setTakenTradeDeposit(rs.getBigDecimal("v_TakenTradeDeposit"));
							feeModel.setCreditFee(rs.getBigDecimal("v_CreditFee"));
							feeModel.setCreditDeposit(rs.getBigDecimal("v_CreditDeposit"));
						} else if (model == 8) {
							feeModel.setReturnCode(rs.getInt("v_Return"));
							feeModel.setTransTaken(rs.getBigDecimal("v_TransTaken"));
							feeModel.setTransCredit(rs.getBigDecimal("v_TransCredit"));
						} else if (model == 9) {
							feeModel.setReturnCode(rs.getInt("v_Return"));
							feeModel.setTakenFee(rs.getBigDecimal("v_TakenFee"));
							feeModel.setBuyCreditDeposit(rs.getBigDecimal("v_buyCreditDeposit"));
							feeModel.setBuyTakenDeposit(rs.getBigDecimal("v_buyTakenDeposit"));
							feeModel.setTakenMoney(rs.getBigDecimal("v_TakenMoney"));
							feeModel.setCouponFee(rs.getBigDecimal("v_CouponFee"));
						} else if (model == 10) {
							feeModel.setReturnCode(rs.getInt("v_Return"));
							feeModel.setReBackBuyTakenTradeDeposit(
									rs.getBigDecimal("v_reBackBuyTakenTradeDeposit"));
							feeModel.setTakenBSDeposit(rs.getBigDecimal("v_TakenBSDeposit"));
							feeModel.setTakenMoney(rs.getBigDecimal("v_TakenMoney"));
						} else if (model == 12) {
							feeModel.setReturnCode(rs.getInt("v_Return"));
							feeModel.setBuyCreditDeposit(rs.getBigDecimal("v_buyCreditDeposit"));
							feeModel.setBuyTakenDeposit(rs.getBigDecimal("v_buyTakenDeposit"));
						} else if (model == 4) {
							feeModel.setReturnCode(rs.getInt("v_Return"));
							feeModel.setTakenTradeDeposit(rs.getBigDecimal("v_TakenTradeDeposit"));
							feeModel.setCreditDeposit(rs.getBigDecimal("v_CreditDeposit"));
							feeModel.setBuyTakenDeposit(rs.getBigDecimal("v_RealTakenTradeDeposit"));
							feeModel.setBuyCreditDeposit(rs.getBigDecimal("v_RealCreditDeposit"));
						} else if (model == 13 || model == 14 || model == 15) {
							
							// 期现市场追加
							feeModel.setReturnCode(rs.getInt("v_Return"));
							feeModel.setTakenTradeDeposit(rs.getBigDecimal("v_TakenTradeDeposit"));
							feeModel.setCreditDeposit(rs.getBigDecimal("v_CreditDeposit"));
						} 
					}
					return feeModel;
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
		this.log.debug("feeModel = "  + retM.toString());
		this.log.debug("getFeeModel model = " + model + " End");
		this.log.debug("retM.getReturnCode() = " + retM.getReturnCode());
		return retM;
	}

	@Override
	public void updateAllCanBackLeads() {
		this.log.debug("updateAllCanBackLeads DAO Start");
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_019");
		Object[] params = new Object[] { "system", Common.getDate(), };
		updateBySQL(sql, params);
		sql = sqlProperty.getProperty("FirmBanlanceDAO_020");
		updateBySQL(sql, params);
	}
	@Override
	public void updateAllSinopecLeadsAndEnquiry() {
		this.log.debug("updateAllSinopecLeadsAndEnquiry DAO Start");
		String sql = "update T_Leads set REC_MODIFYBY = \u003f , REC_MODIFYTIME  = \u003f  , LeadsStatus =1 where LeadsStatus = 0 and SettlementMethod = 21";
		Object[] params = new Object[] { "system", Common.getDate(), };
		updateBySQL(sql, params);
		sql = "update T_Enquiry set REC_MODIFYBY = \u003f , REC_MODIFYTIME  = \u003f  , EnquiryStatus =0 where EnquiryStatus = 1 and SettlementMethod = 21";
		updateBySQL(sql, params);
	}
	
	
	@Override
	public List<TLeads> getAllCanBackLeads() {
		List<TLeads> list = new ArrayList<TLeads>();
		this.log.debug("getAllCanBackLeads DAO Start");
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_021");
		Object[] params = new Object[] {};
		list = queryBySQL(sql, params, null, new CommonRowMapper(new TLeads()));
		return list;
	}

	@Override
	public List<TEnquiry> getAllCanBackEnquiry() {
		List<TEnquiry> list = new ArrayList<TEnquiry>();
		this.log.debug("queryFirmBanlance DAO Start");
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_022");
		Object[] params = new Object[] {};
		list = queryBySQL(sql, params, null, new CommonRowMapper(new TEnquiry()));
		return list;
	}
	
	@Override
	public List<TEnquiry> getAllSinopecCanBackEnquiry() {
		this.log.info(this.getClass().getName()+" getAllSinopecCanBackEnquiry Dao Start");
		List<TEnquiry> list = new ArrayList<TEnquiry>();
		String sql = "select * from T_Enquiry  where EnquiryStatus = 1 and SettlementMethod = 21";
		
		/*只撤销当天询盘，只用于测试*/
//				+ "and Convert(varchar(10),REC_MODIFYTIME,120) = Convert(varchar(10),getDate(),120)";
		Object[] params = new Object[] {};
		list = queryBySQL(sql, params, null, new CommonRowMapper(new TEnquiry()));
		this.log.info(this.getClass().getName()+" getAllSinopecCanBackEnquiry Dao Start");
		return list;
	}
	
	@Override
	public List<TLeads> getAllSinopecCanBackLeads() {
		this.log.info(this.getClass().getName()+" getAllSinopecCanBackLeads Dao Start");
		List<TLeads> list = new ArrayList<TLeads>();
		String sql = "select * from T_Leads where LeadsStatus = 0 and SettlementMethod = 21 ";
		
		/*只撤销当天报盘，只用于测试*/
//				+ " and Convert(varchar(10),REC_MODIFYTIME,120) = Convert(varchar(10),getDate(),120)";
		Object[] params = new Object[] {};
		list = queryBySQL(sql, params, null, new CommonRowMapper(new TLeads()));
		this.log.info(this.getClass().getName()+" getAllSinopecCanBackLeads Dao Start");
		return list;
	}

	@Override
	public List<CancelDetail> getCancelDetail(String ApplyID) {
		List<CancelDetail> list = new ArrayList<CancelDetail>();
		this.log.debug("getCancelDetail DAO Start");
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_025");
		Object[] params = new Object[] {ApplyID};
		list = queryBySQL(sql, params, null, new CommonRowMapper(new CancelDetail()));
		return list;
	}

	@Override
	public void updateCancelMoneySuccess(String keyID, String userId) {
		this.log.debug("updateCancelMoneySuccess DAO Start");
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_026");
		Object[] params = new Object[] { userId, keyID };
		updateBySQL(sql, params);
	}

	@Override
	public void updateCancelMoneySuccessHalf(String keyID, String userId) {
		this.log.debug("updateCancelMoneySuccess DAO Start");
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_027");
		Object[] params = new Object[] { userId, keyID };
		updateBySQL(sql, params);
	}

	@Override
	public void updateCancelMoneyFailed(String keyID, String userId) {
		this.log.debug("updateCancelMoneySuccess DAO Start");
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_028");
		Object[] params = new Object[] { userId, keyID };
		updateBySQL(sql, params);
	}
	
	/*
	 * 以下为期现市场
	 */
	/**
	 * 取得询盘列表
	 * 
	 * @param differ
	 * @param enqId
	 * @return
	 */
	@Override
	public List<TEnquiry> getCancelEnquiryLst(int differ, int enqId) {
		
		this.log.debug("getCancelEnquiryLst DAO Start");
		
		List<TEnquiry> enqLst = null;
		Object[] params = null;
		String sql = null;
		
		if (Constants.BACK_END == differ) {
			
			// 后台释放询盘
			sql = sqlProperty.getProperty("FirmBanlanceDAO_029");
			params = new Object[] {enqId};
		} else {
			
			// Job撤销询盘
			sql = sqlProperty.getProperty("FirmBanlanceDAO_030");
		}

		enqLst = queryBySQL(sql, params, null, new CommonRowMapper(new TEnquiry()));
		
		this.log.debug("getCancelEnquiryLst DAO End");
		return enqLst;
	}
	
	/**
	 * 取得挂盘列表
	 * 
	 * @param differ
	 * @param leadId
	 * @return
	 */
	@Override
	public List<TLeads> getCancelLeadLst(int differ, int leadId) {
		
		this.log.debug("getCancelLeadLst DAO Start");
		
		List<TLeads> leadLst = null;
		Object[] params = null;
		String sql = null;
		
		if (Constants.BACK_FRONT == differ) {
			
			// 前台撤销挂盘
			sql = sqlProperty.getProperty("FirmBanlanceDAO_031");
			params = new Object[] {leadId};
		} else {
			
			// Job撤销挂盘
			sql = sqlProperty.getProperty("FirmBanlanceDAO_032");
		}

		leadLst = queryBySQL(sql, params, null, new CommonRowMapper(new TLeads()));
		
		this.log.debug("getCancelLeadLst DAO End");
		return leadLst;
	}
	
	/**
	 * 事前更新询盘列表
	 * 
	 * @param differ
	 * @param enqId
	 * @return
	 */
	@Override
	public void preCancelEnquiryLst(int differ, int enqId) {
		
		this.log.debug("preCancelEnquiryLst DAO Start");
		
		Object[] params = null;
		String sql = null;
		
		if (Constants.BACK_END == differ) {
			
			// 后台释放询盘
			sql = sqlProperty.getProperty("FirmBanlanceDAO_033");
			params = new Object[] {enqId};
			
			updateBySQL(sql, params);
		} else {
			
			// Job撤销询盘
			sql = sqlProperty.getProperty("FirmBanlanceDAO_034");
			
			updateBySQL(sql);
		}

		
		this.log.debug("preCancelEnquiryLst DAO End");
	}
	
	/**
	 * 事前更新挂盘列表
	 * 
	 * @param differ
	 * @param leadId
	 * @return
	 */
	@Override
	public void preCancelLeadLst(int differ, int leadId) {
		
		this.log.debug("preCancelLeadLst DAO Start");
		
		Object[] params = null;
		String sql = null;
		
		if (Constants.BACK_FRONT == differ) {
			
			// 前台撤销挂盘
			sql = sqlProperty.getProperty("FirmBanlanceDAO_035");
			params = new Object[] {leadId};
			
			updateBySQL(sql, params);
		} else {
			
			// Job撤销挂盘
			sql = sqlProperty.getProperty("FirmBanlanceDAO_036");
			
			updateBySQL(sql);
		}


		
		this.log.debug("preCancelLeadLst DAO End");
	}
	
	/**
	 * 事后更新询盘列表
	 * 
	 * @param differ
	 * @param enquiry
	 * @return
	 */
	@Override
	public void postCancelEnquiryLst(int differ, TEnquiry enquiry)  {
		
		this.log.debug("postCancelEnquiryLst DAO Start");
		
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_037");
		Object[] params = new Object[] {enquiry.getEnquiryStatus() ,enquiry.getEnquiryId()};
		
		updateBySQL(sql, params);
		
		this.log.debug("postCancelEnquiryLst DAO End");
	}
	
	/**
	 * 事后更新挂盘列表
	 * 
	 * @param differ
	 * @param lead
	 * @return
	 */
	@Override
	public void postCancelLeadLst(int differ, TLeads lead) {
		
		this.log.debug("postCancelLeadLst DAO Start");
		
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_039");
		Object[] params = new Object[] {lead.getLeadsStatus() ,lead.getID()};

		updateBySQL(sql, params);
		
		this.log.debug("postCancelLeadLst DAO End");
	}

	@Override
	public void insertOutMoneyApply(FBOutMoneyApply applyModel) {
		this.log.debug("insertOutMoneyApply DAO Start");
		
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_045");
		Object[] params = new Object[] {applyModel.getFirmID(),applyModel.getFirmName(),applyModel.getBankID(),
				applyModel.getBankName(),applyModel.getMoney(), applyModel.getApplyer()};

		updateBySQL(sql, params);
		
		this.log.debug("insertOutMoneyApply DAO End");
		
	}

	@Override
	public int updateOutMoneyApply(Integer id, Integer fromStatus, Integer toStatus, String auditor,String note) {
		this.log.debug("updateOutMoneyApplyStatus DAO Start");
		
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_046");
		Object[] params = new Object[] {toStatus,auditor,note, id, fromStatus};
		this.log.debug("updateOutMoneyApplyStatus DAO End");
		return updateBySQL(sql, params);
	}

	@Override
	public List<FBOutMoneyApply> getOutMoneyApplyList(QueryConditions qc, PageInfo pageInfo) {
		List<FBOutMoneyApply> list = new ArrayList<FBOutMoneyApply>();
		this.log.debug("getOutMoneyApplyList DAO Start");
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_047");
		list = queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new FBOutMoneyApply()));
		return list;
	} 
}
