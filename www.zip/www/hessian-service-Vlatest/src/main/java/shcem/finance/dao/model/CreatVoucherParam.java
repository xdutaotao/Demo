/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmBanlanceListForOra
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.model;

import java.math.BigDecimal;

import shcem.base.dao.model.BaseObject;

public class CreatVoucherParam extends BaseObject implements java.io.Serializable, Cloneable {

	private static final long serialVersionUID = -7464587171301763763L;

	/** 凭证模板id */
	private String voucherModelID;

	/** 发生金额 */
	private BigDecimal money;

	/** 订单号 */
	private String contractno;

	/** 交易商id */
	private String firmID;

	/** 备注 */
	private String note;

	/** 输入者 */
	private String inputUser;
	

	public String getVoucherModelID() {
		return voucherModelID;
	}

	public void setVoucherModelID(String voucherModelID) {
		this.voucherModelID = voucherModelID;
	}

	public BigDecimal getMoney() {
		return money;
	}

	public void setMoney(BigDecimal money) {
		this.money = money;
	}

	public String getContractno() {
		return contractno;
	}

	public void setContractno(String contractno) {
		this.contractno = contractno;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getInputUser() {
		return inputUser;
	}

	public void setInputUser(String inputUser) {
		this.inputUser = inputUser;
	}

	@Override
	public String toString() {
		return this.voucherModelID + "," + this.money + "," + this.contractno + "," + this.firmID + "," + this.note
				+ "," + this.inputUser;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}