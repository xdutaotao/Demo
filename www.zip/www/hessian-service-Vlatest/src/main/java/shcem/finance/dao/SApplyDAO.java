/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: SApplyDAO
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
  * 04/29/16 　罗恒   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.model.*;

public abstract interface SApplyDAO extends DAO {

	/**
	 * 授信申请记录查询
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<SApply> getSApplyList(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 授信申请追加
	 * 
	 * @param sapply
	 * @return
	 */
	public abstract int addApply(SApply sapply);

	/**
	 * 更新申请状态
	 * 
	 * @param applyId
	 * @param status
	 * @return
	 */
	public abstract int updateStatus(Integer applyId, Integer status);
	
	/**
	 * 更新拒绝原因
	 * 
	 * @param applyId
	 * @param status
	 * @return
	 */
	public abstract int updateRefuseReason(Integer applyId, String refuseReason);

	/**
	 * 当前授信资金查询(现货)
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<SFirmFunds> getFirmFundsList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 当前授信资金查询(预售)
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<SPreSaleFirmFunds> getPreSaleFirmFundsList(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 交易商授信资金查询
	 * 
	 * @param firmId
	 * @return
	 */
	public abstract SFirmFunds getFirmFunds(String firmId);
	
	/**
	 * 交易商预售授信资金查询
	 * 
	 * @param firmId
	 * @return
	 */
	public abstract SPreSaleFirmFunds getPreSaleFirmFundsFirmFunds(String firmId);

	/**
	 * 追加授信流水
	 * 
	 * @param firmId
	 * @return
	 */
	public abstract int addSFundFlow(SFundFlow sFundFlow);

	/**
	 * 授信资金表更新（当前余额，期初额）
	 * 
	 * @param firmId
	 * @param money
	 *            今次授信金额
	 * @return
	 */
	public abstract int updateSfirmFunds(String firmId, BigDecimal money, Date creditDate);

	/**
	 * 主键取得授信申请记录
	 * 
	 * @param sapply
	 * @return
	 */
	public abstract SApply getApply(Integer applyId);

	/**
	 * 更新审核者，审核时间
	 * 
	 * @param applyId
	 * @param approver
	 * @param approveTime
	 * @return
	 */
	public abstract int updateApprover(Integer applyId, String approver, Date approveTime);

	public abstract int updateSfirmFundsByUse(String firmId, BigDecimal money);
	
	public abstract void rollBack();
	
	/**
	 * 授信资金流水list取得
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<SFundFlow> getSFundFlowList(QueryConditions qc,
			PageInfo pageInfo);
	
	/**
	 * 预售授信流水list取得
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<SPreSaleFundFlow> getPreSaleFundFlowList(QueryConditions qc,PageInfo pageInfo);
	
	/**
	 * 授信资金和市场资金流水list取得
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<AllFundFlow> getAllFundFlowList(QueryConditions qc,
			PageInfo pageInfo);

	/**
	 * 增加预售授信流水表
	 * @param sPreSaleFundFlow
	 * @return
	 */
	public abstract int addPreSaleFundFlow(SPreSaleFundFlow sPreSaleFundFlow);

	/**
	 * 更新预售授信资金表
	 * @param firmId
	 * @param money
	 * @param creditDate
	 * @return
	 */
	public abstract int updatePreSaleFirmFound(String firmId, BigDecimal money, Date creditDate);
}
