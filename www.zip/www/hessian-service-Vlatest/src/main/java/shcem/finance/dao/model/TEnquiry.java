/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: TEnquiry
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.model;

import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * (TEnquiry)
 * 
 * @author wlpod
 * @version 1.0.0 2016-05-12
 */
public class TEnquiry extends BaseObject implements java.io.Serializable, Cloneable {

	private static final long serialVersionUID = -7464587171301763763L;

	private Long enquiryId;
	private Long leadsID;
	private BigDecimal price;
	private Integer quantity;
	private String traderId;
	private String firmId;
	private Integer enquiryStatus;
	private String rECCREATEBY;
	private Date rECCREATETIME;
	private String rECMODIFYBY;
	private Date rECMODIFYTIME;
	private Integer dISABLED;
	private String enquiryCode;

	public Long getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Long enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Long getLeadsID() {
		return leadsID;
	}

	public void setLeadsID(Long leadsID) {
		this.leadsID = leadsID;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public String getTraderId() {
		return traderId;
	}

	public void setTraderId(String traderId) {
		this.traderId = traderId;
	}

	public String getFirmId() {
		return firmId;
	}

	public void setFirmId(String firmId) {
		this.firmId = firmId;
	}

	public Integer getEnquiryStatus() {
		return enquiryStatus;
	}

	public void setEnquiryStatus(Integer enquiryStatus) {
		this.enquiryStatus = enquiryStatus;
	}

	public String getrECCREATEBY() {
		return rECCREATEBY;
	}

	public void setrECCREATEBY(String rECCREATEBY) {
		this.rECCREATEBY = rECCREATEBY;
	}

	public Date getrECCREATETIME() {
		return rECCREATETIME;
	}

	public void setrECCREATETIME(Date rECCREATETIME) {
		this.rECCREATETIME = rECCREATETIME;
	}

	public String getrECMODIFYBY() {
		return rECMODIFYBY;
	}

	public void setrECMODIFYBY(String rECMODIFYBY) {
		this.rECMODIFYBY = rECMODIFYBY;
	}

	public Date getrECMODIFYTIME() {
		return rECMODIFYTIME;
	}

	public void setrECMODIFYTIME(Date rECMODIFYTIME) {
		this.rECMODIFYTIME = rECMODIFYTIME;
	}

	public Integer getdISABLED() {
		return dISABLED;
	}

	public void setdISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getEnquiryCode() {
		return enquiryCode;
	}

	public void setEnquiryCode(String enquiryCode) {
		this.enquiryCode = enquiryCode;
	}

	private String userCode;
	private String remarks;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}