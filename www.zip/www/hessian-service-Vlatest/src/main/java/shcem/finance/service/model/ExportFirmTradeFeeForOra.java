/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmTradeFeeForOra
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.service.model;

public class ExportFirmTradeFeeForOra {

	// 交易商id
	private String firmid;
	// 交易商手续费合计
	private String TradeFee;
	// 交易商全名
	private String fullname;
	// 交易商地址
	private String address;
	// 交易商银行
	private String bank;
	// 交易商银行账号
	private String bankaccount;
	// 交易商电话
	private String phone;
	// 交易商税号
	private String taxRegistrationNo;
	// 交易商发票地址
	private String businessScope;
	// 交易商发票联系人
	private String b_businessContacter;

	public String getFirmid() {
		return firmid;
	}

	public void setFirmid(String firmid) {
		this.firmid = firmid;
	}

	public String getTradeFee() {
		return TradeFee;
	}

	public void setTradeFee(String tradeFee) {
		TradeFee = tradeFee;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public String getBankaccount() {
		return bankaccount;
	}

	public void setBankaccount(String bankaccount) {
		this.bankaccount = bankaccount;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getTaxRegistrationNo() {
		return taxRegistrationNo;
	}

	public void setTaxRegistrationNo(String taxRegistrationNo) {
		this.taxRegistrationNo = taxRegistrationNo;
	}

	public String getBusinessScope() {
		return businessScope;
	}

	public void setBusinessScope(String businessScope) {
		this.businessScope = businessScope;
	}

	public String getB_businessContacter() {
		return b_businessContacter;
	}

	public void setB_businessContacter(String b_businessContacter) {
		this.b_businessContacter = b_businessContacter;
	}
}