/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: BankMgrServiceImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 05/11/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import gnnt.trade.bank.util.Tool;
import gnnt.trade.bank.vo.ReturnValue;
import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.finance.component.IBankMgrManager;
import shcem.finance.dao.model.FBanks;
import shcem.finance.service.IBankMgrService;
import shcem.finance.util.FinanceSysData;
import shcem.finance.util.BankInterfaceRMI;
import shcem.trade.service.model.BankServiceModel;
import shcem.util.CopyProperties;
import shcem.util.JsonUtil;

/**
 * BankMgrServiceImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class BankMgrServiceImpl extends BaseServiceImpl implements IBankMgrService {

	private IBankMgrManager mgr = (IBankMgrManager) FinanceSysData.getBean(Constants.BEAN_BANKMGR_MGR);

	/**
	 * 取得银行列表
	 * 
	 * 
	 * @return
	 */
	public String getBankList(String params) {

		this.log.info(this.getClass().getName() + " getBankList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<FBanks> list = null;
		boolean bolRst = false;
		List<Condition> conditionList = new ArrayList<Condition>(); // 允许的查询参数列表，定义字段，操作符及类型,查询json固定模型queryModel
		conditionList.add(new Condition("t.bankID", "=", "", "long", "bankID")); // 只接收一个参数，bankID=
																					// param,aliasName为模型中的定义属性，field为sql字段
		// conditionList.add(new Condition("bankID","like","","string"));
		// //bankID like '%param%'
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		// PageInfo pageInfo = new PageInfo(1, 15, "bankID", false);
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			list = mgr.getBankList(qc, pageInfo);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("取得银行列表f_banks失败：" + err.getMessage());
			setResultData("10104", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);

				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10104", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getBankList() End");
		return rtnData.toString();
	}

	@Override
	public String getBank(String params) {
		this.log.info(this.getClass().getName() + " getBank() Start");

		FBanks bank = new FBanks();
		BankServiceModel rtnModel = new BankServiceModel();
		boolean bolRst = false;
		this.log.debug(params);
		JSONObject JOParams = new JSONObject(params);
		String bankID = JOParams.getString("bankID");
		try {
			bank = mgr.getBank(bankID);
			bolRst = true;

		} catch (Exception err) {
			this.log.error("取得银行情报失败：" + err.getMessage());
			setResultData("10105", null, err.getMessage());
		}
		if (bolRst) {
			JSONObject retData;
			try {
				CopyProperties.copyProperties(bank, rtnModel);
			} catch (Exception e1) {
				setResultData("10105", null, e1.getMessage());
			}
			try {
				retData = JsonUtil.coverModelToJSONObject(rtnModel);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getBank() End");
		return rtnData.toString();
	}

	@Override
	public String updateBank(String params) {
		this.log.info(this.getClass().getName() + " updateBank() Start");

		JSONObject JOParams = new JSONObject(params);
		FBanks bank = (FBanks) JsonUtil.jsonToBean(JOParams, FBanks.class);

		// validate bank bean
		String vdMsg = this.validateBean(bank);
		if (vdMsg != null) {
			setResultData("10106", null, vdMsg);
			return rtnData.toString();
		}

		try {
			this.mgr.updateBank(bank);
			setResultData("00000", null);
			this.log.businesslog("更新银行情报成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		} catch (Exception e) {
			this.log.error("更新银行情报失败：" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("更新银行情报失败", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		}

		this.log.info(this.getClass().getName() + " updateBank() End");
		return rtnData.toString();
	}

	@Override
	public String addBank(String params) {
		this.log.info(this.getClass().getName() + " addBank() Start");

		JSONObject JOParams = new JSONObject(params);
		FBanks bank = (FBanks) JsonUtil.jsonToBean(JOParams, FBanks.class);
		this.log.debug(params);
		try {
			bank.setValidFlag(0);
			this.log.debug("bankid=" + bank.getBankName());
			int retCode = this.mgr.addBank(bank);
			this.log.debug("retCode=" + retCode);
			if (retCode == 0) {
				setResultData("00000", null);
			} else {
				setResultData("10106", null);
			}
			this.log.businesslog("增加银行情报成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		} catch (Exception e) {
			this.log.error("增加银行情报失败：" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("增加银行情报失败", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		}

		this.log.info(this.getClass().getName() + " addBank() End");
		return rtnData.toString();
	}

	@Override
	public String validBank(String params) {
		this.log.info(this.getClass().getName() + " validBank() Start");
		JSONObject JOParams = new JSONObject(params);
		String bankID = JOParams.getString("bankID");
		try {
			this.mgr.validBank(bankID);
			setResultData("00000", null);
			this.log.businesslog("银行有效化操作成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		} catch (Exception e) {
			this.log.error("银行有效化操作失败：" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("银行有效化操作失败", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		}

		this.log.info(this.getClass().getName() + " validBank() End");
		return rtnData.toString();
	}

	@Override
	public String invalidBank(String params) {
		this.log.info(this.getClass().getName() + " invalidBank() Start");
		JSONObject JOParams = new JSONObject(params);
		String bankID = JOParams.getString("bankID");
		try {
			this.mgr.invalidBank(bankID);
			setResultData("00000", null);
			this.log.businesslog("银行无效化操作成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		} catch (Exception e) {
			this.log.error("银行无效化操作" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("银行无效化操作失败", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		}

		this.log.info(this.getClass().getName() + " invalidBank() End");
		return rtnData.toString();
	}

	@Override
	public String openAbcAccount(String params) {
		this.log.info(this.getClass().getName() + " openAbcAccount() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		String requestID = JOParams.optString("requestID");
		String firmID = JOParams.optString("firmID");
		String bankID = JOParams.optString("bankID");
		String account = JOParams.optString("account");
		String signInfo = JOParams.optString("signInfo");
		ReturnValue result = new ReturnValue();
		boolean bolRst = false;

		try {
			result = BankInterfaceRMI.openAbcAccount(requestID, bankID, firmID, account, signInfo, getMode());
			bolRst = true;
		} catch (Exception err) {
			this.log.error("签约账号失败：" + err.getMessage());
			setResultData("11001", null, err.getMessage());
			this.log.info(this.getClass().getName() + " openAbcAccount() End");
			return rtnData.toString();
		}

		String str1 = "签约账号成功";
		if (bolRst && result.result >= 0) {
			try {
				JSONObject jsonObj = new JSONObject();
				jsonObj.put("result", result.funID);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10112", null, e.getMessage());
			}
		} else {
			if (result.result == -3) {
				str1 = "系统错误";
			} else if (result.result == -4) {
				str1 = "银行不能市场端签约";
			} else if (result.result == -5) {
				str1 = "不能重复签约";
			} else if (result.result == -6) {
				str1 = "未找到交易商的银行注册信息";
			} else {
				str1 = "其他错误";
			}
			setResultData("11001", null, str1);
		}

		String logcontent = " 签约银行账号：银行代码" + bankID + "、" + str1;
		this.log.info(getUserId() + logcontent);
		this.log.info(this.getClass().getName() + " openAbcAccount() End");
		return rtnData.toString();
	}
	
	@Override
	public String delAbcAccount(String params) {
		this.log.info(this.getClass().getName() + " delAbcAccount() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		String requestID = JOParams.optString("requestID");
		String firmID = JOParams.optString("firmID");
		String bankID = JOParams.optString("bankID");
		String account = JOParams.optString("account");
		String account1 = JOParams.optString("account1");
		String accountName = JOParams.optString("accountName");
		String signInfo = JOParams.optString("signInfo");
		int isOpen = JOParams.optInt("isOpen");

		long result = -1;
		boolean bolRst = false;

		try {
			result = BankInterfaceRMI.delAbcAccount(requestID, bankID, firmID, account, account1, accountName, signInfo, isOpen, getMode());
			bolRst = true;
		} catch (Exception err) {
			this.log.error("注销账号失败：" + err.getMessage());
			setResultData("11002", null, err.getMessage());
			this.log.info(this.getClass().getName() + " delCorrespond() End");
			return rtnData.toString();
		}

		if (bolRst && result >= 0) {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("result", result);
			setResultData("00000", jsonObj);
		} else {
			String str1 = "";
			if (result == -40011) {
				str1 = "信息不完整";
			} else if (result == -40014) {
				str1 = "账号未注册";
			} else if (result == -40015) {
				str1 = "银行解约失败";
			} else if (result == -2) {
				str1 = "已签约帐户市场不能注销";
			} else {
				str1 = "其他错误";
			}
			setResultData("11002", null, str1);
			String logcontent = " 注销账户：" + firmID + "银行：" + bankID + str1 + "时间：" + Tool.fmtTime(new java.util.Date());
			this.log.info(getUserId() + logcontent);
		}

		this.log.info(this.getClass().getName() + " delCorrespond() End");
		return rtnData.toString();
	}
}