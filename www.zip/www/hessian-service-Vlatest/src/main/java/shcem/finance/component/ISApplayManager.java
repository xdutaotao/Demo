/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: ISApplayManager
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.component;

import java.math.BigDecimal;
import java.util.List;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.SApplyDAO;
import shcem.finance.dao.model.*;

public abstract interface ISApplayManager extends Manager {

	public abstract void setSApplyDAO(SApplyDAO paramDAO);

	/**
	 * 授信申请记录查询
	 */
	public abstract List<SApply> getSApplyList(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 授信申请追加
	 */
	public abstract int addApply(SApply sapply);

	/**
	 * 当前授信资金查询(现货)
	 */
	public abstract List<SFirmFunds> getFirmFundsList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 当前授信资金查询(预售)
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<SPreSaleFirmFunds> getPreSaleFirmFundsList(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 审核不通过
	 */
	public abstract int approveNot(Integer id, String refuseReason);

	/**
	 * 审核通过
	 */
	public abstract int approveYes(Integer id, String approver, String refuseReason);
	
	/**
	 * 收取授信交易手续费
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public abstract int getFee(String firmID, BigDecimal money, String ObjectID, int flowType);
	/**
	 * 退还授信交易手续费
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public abstract int backFee(String firmID, BigDecimal money, String ObjectID, int flowType);
	/**
	 * 收取授信交收手续费
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public abstract int getSettleFee(String firmID, BigDecimal money, String ObjectID, int flowType);
	/**
	 * 退还授信交收手续费
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public abstract int backSettleFee(String firmID, BigDecimal money, String ObjectID, int flowType);
	/**
	 * 收取授信交易保证金
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public abstract int getMargin(String firmID, BigDecimal money, String ObjectID, int flowType);
	/**
	 * 退还授信交易保证金(现货)
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public abstract int backMargin(String firmID, BigDecimal money, String ObjectID, int flowType);
	/**
	 * 收取授信交收保证金
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public abstract int getSettleMargin(String firmID, BigDecimal money, String ObjectID, int flowType);
	/**
	 * 退还授信交收保证金
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public abstract int backSettleMargin(String firmID, BigDecimal money, String ObjectID, int flowType);

	public abstract void rollback();
	
	/**
	 * 授信资金流水list取得
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<SFundFlow> getSFundFlowList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 预售授信资金流水list取得
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<SPreSaleFundFlow> getPreSaleFundFlowList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 授信资金和市场资金流水list取得
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<AllFundFlow> getAllFundFlowList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 收取授信交易手续费(预售)
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public abstract int getFeeForPreSale(String firmID, BigDecimal money, String ObjectID, int flowType);
	
	/**
	 * 退还授信交易手续费(预售)
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public abstract int backFeeForPreSale(String firmID, BigDecimal money, String ObjectID, int flowType);
	/**
	 * 收取授信交收手续费(预售)
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public abstract int getSettleFeeForPreSale(String firmID, BigDecimal money, String ObjectID, int flowType);
	/**
	 * 退还授信交收手续费(预售)
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public abstract int backSettleFeeForPreSale(String firmID, BigDecimal money, String ObjectID, int flowType);
	/**
	 * 收取授信交易保证金(预售)
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public abstract int getMarginForPreSale(String firmID, BigDecimal money, String ObjectID, int flowType);
	/**
	 * 退还授信交易保证金(预售)
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public abstract int backMarginForPreSale(String firmID, BigDecimal money, String ObjectID, int flowType);
	/**
	 * 收取授信交收保证金(预售)
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public abstract int getSettleMarginForPreSale(String firmID, BigDecimal money, String ObjectID, int flowType);
	/**
	 * 退还授信交收保证金(预售)
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public abstract int backSettleMarginForPreSale(String firmID, BigDecimal money, String ObjectID, int flowType);
}
