package shcem.finance.ExportModel;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * 开票导出类
 * 
 * @author zhangnan
 *
 */
public class InvoiceCollect4Export extends BaseObject implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// 成交单号
	private String orderId;
	// 交易场
	private String tradeTmptName;
	// 卖方交易商
	private String sellFirmName;
	// 品类牌号
	private String goodName;
	// 成交单价
	private BigDecimal price;
	// 成交数量（吨）
	private BigDecimal totalQuantityTon;
	// 签收数量（吨）
	private BigDecimal signQuantityTon;
	// 货款金额
	private BigDecimal amount;
	// 实发金额( 签收数量（吨）*成交单价)
	private BigDecimal signAmount;
	// 成交时间
	private Date tradeDate;
	// 成交状态(名称)
	private String tradeStatusName;
	// 收票时间
	private Date collectDate;
	// 收票金额(含税)
	private BigDecimal invoiceTotalMoney;
	// 应收金额
	private BigDecimal shouldInvoiceMoney;
	// 收票吨数
	private BigDecimal invoiceQuantity;
	// 发票号
	private String invoiceNo;
	// 备注
	private String remark;
	
	/**成交状态*/
	private Integer tradeStatus;
	
	/***/
	private BigDecimal totalQuantity;
	
	/***/
	private BigDecimal deliveryTakenQuantity;
	
	/***/
	private Date invoiceCollectDate;
	
	/***/
	private String invoiceRemark;
	
	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getTradeTmptName() {
		return tradeTmptName;
	}

	public void setTradeTmptName(String tradeTmptName) {
		this.tradeTmptName = tradeTmptName;
	}

	public String getSellFirmName() {
		return sellFirmName;
	}

	public void setSellFirmName(String sellFirmName) {
		this.sellFirmName = sellFirmName;
	}

	public String getGoodName() {
		return goodName;
	}

	public void setGoodName(String goodName) {
		this.goodName = goodName;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public BigDecimal getTotalQuantityTon() {
		return totalQuantityTon;
	}

	public void setTotalQuantityTon(BigDecimal totalQuantityTon) {
		this.totalQuantityTon = totalQuantityTon;
	}

	public BigDecimal getSignQuantityTon() {
		return signQuantityTon;
	}

	public void setSignQuantityTon(BigDecimal signQuantityTon) {
		this.signQuantityTon = signQuantityTon;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getSignAmount() {
		return signAmount;
	}

	public void setSignAmount(BigDecimal signAmount) {
		this.signAmount = signAmount;
	}

	public Date getTradeDate() {
		return tradeDate;
	}

	public void setTradeDate(Date tradeDate) {
		this.tradeDate = tradeDate;
	}

	public String getTradeStatusName() {
		return tradeStatusName;
	}

	public void setTradeStatusName(String tradeStatusName) {
		this.tradeStatusName = tradeStatusName;
	}

	public Date getCollectDate() {
		return collectDate;
	}

	public void setCollectDate(Date collectDate) {
		this.collectDate = collectDate;
	}

	public BigDecimal getInvoiceTotalMoney() {
		return invoiceTotalMoney;
	}

	public void setInvoiceTotalMoney(BigDecimal invoiceTotalMoney) {
		this.invoiceTotalMoney = invoiceTotalMoney;
	}

	public BigDecimal getInvoiceQuantity() {
		return invoiceQuantity;
	}

	public void setInvoiceQuantity(BigDecimal invoiceQuantity) {
		this.invoiceQuantity = invoiceQuantity;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getTradeStatus() {
		return tradeStatus;
	}

	public void setTradeStatus(Integer tradeStatus) {
		this.tradeStatus = tradeStatus;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public BigDecimal getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(BigDecimal totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	public BigDecimal getDeliveryTakenQuantity() {
		return deliveryTakenQuantity;
	}

	public void setDeliveryTakenQuantity(BigDecimal deliveryTakenQuantity) {
		this.deliveryTakenQuantity = deliveryTakenQuantity;
	}

	public Date getInvoiceCollectDate() {
		return invoiceCollectDate;
	}

	public void setInvoiceCollectDate(Date invoiceCollectDate) {
		this.invoiceCollectDate = invoiceCollectDate;
	}

	public String getInvoiceRemark() {
		return invoiceRemark;
	}

	public void setInvoiceRemark(String invoiceRemark) {
		this.invoiceRemark = invoiceRemark;
	}

	public BigDecimal getShouldInvoiceMoney() {
		return shouldInvoiceMoney;
	}

	public void setShouldInvoiceMoney(BigDecimal shouldInvoiceMoney) {
		this.shouldInvoiceMoney = shouldInvoiceMoney;
	}

}
