package shcem.finance.service;

/**资金相关
 * @author zhangnan
 *
 */
public interface IBalanceMgrService {
	
	/**交易商当前资金查询
	 * @param params
	 * @return
	 */
	public String queryFirmBanlance(String params);
	
	
	/**单个交易商当前资金查询
	 * @param params
	 * @return
	 */
	public String queryOneFirmBanlance(String params);
	
	
	/**查询出金申请页面列表
	 * @param params
	 * @return
	 */
	public String queryOutMoneyList(String params);
	
	/**查询出金申请记录列表
	 * @param params
	 * @return
	 */
	public String queryOutMoneyApplyList(String params);
	
	/**提交出金申请
	 * @param params
	 * @return
	 */
	public String insertOutMoneyApply(String params);
	
	/**提交出金申请
	 * @param params
	 * @return
	 */
	public String updateOutMoneyApply(String params);
}
