/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: CapitalProcessorRMI.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月22日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.util;

import java.math.BigDecimal;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.Vector;

import gnnt.trade.bank.processorrmi.CapitalProcessorRMI;
import gnnt.trade.bank.util.ErrorCode;
import gnnt.trade.bank.vo.BankValue;
import gnnt.trade.bank.vo.CapitalValue;
import gnnt.trade.bank.vo.CorrespondValue;
import gnnt.trade.bank.vo.FirmBalanceValue;
import gnnt.trade.bank.vo.ReturnValue;
import shcem.constant.Constants;
import shcem.finance.service.model.AbcSignInfoModel;
import shcem.util.Common;
import shcem.util.PropertyUtil;

/**
 * @author wlpod
 *
 */
public class BankInterfaceRMI {
	private static CapitalProcessorRMI cp = null;
	private static String rmiIpAddress = null;
	private static String rmiPortNumber = null;
	private static String rmiServiceName = null;
	private static Properties rmiProperty = null;
	private static boolean autoAudit = false;

	public static void testRMI() {
		try {
			System.out.println("//" + rmiIpAddress + ":" + rmiPortNumber + "/" + rmiServiceName);
			System.out.println(cp.testRmi());
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String args[]) {
		init(Constants.MODE_DEPLOY);
		testRMI();
		try {
			getFirmBankBalance("0215888", "10", "", Constants.MODE_DEPLOY);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	public static void init(String mode) {
		try {
			ErrorCode errorCode=new ErrorCode();
			errorCode.load();//加载错误码对应的信息
			PropertyUtil propUtil = new PropertyUtil();
			rmiProperty = propUtil.getProperties(Constants.RMI_PROPERTY);
			if (Constants.MODE_DEPLOY.equals(mode)) {
				//生产环境下读取RMI处理机配置
				rmiIpAddress = rmiProperty.getProperty("rmiIpAddress");
				rmiPortNumber = rmiProperty.getProperty("rmiPortNumber");
				rmiServiceName = rmiProperty.getProperty("rmiServiceName");
				cp = (CapitalProcessorRMI) Naming.lookup("//" + rmiIpAddress + ":" + rmiPortNumber + "/" + rmiServiceName);
				System.out.println(cp.testRmi());
			} else if (Constants.MODE_UAT.equals(mode)) {
				//UAT环境下读取RMI处理机配置
				rmiIpAddress = rmiProperty.getProperty("UAT_rmiIpAddress");
				rmiPortNumber = rmiProperty.getProperty("UAT_rmiPortNumber");
				rmiServiceName = rmiProperty.getProperty("UAT_rmiServiceName");
				cp = (CapitalProcessorRMI) Naming.lookup("//" + rmiIpAddress + ":" + rmiPortNumber + "/" + rmiServiceName);
				System.out.println(cp.testRmi());
			} else {
				//其他环境下读取RMI处理机配置
				rmiIpAddress = rmiProperty.getProperty("TEST_rmiIpAddress");
				rmiPortNumber = rmiProperty.getProperty("TEST_rmiPortNumber");
				rmiServiceName = rmiProperty.getProperty("TEST_rmiServiceName");
				cp = (CapitalProcessorRMI) Naming.lookup("//" + rmiIpAddress + ":" + rmiPortNumber + "/" + rmiServiceName);
				System.out.println(cp.testRmi());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	
	private static void checkCp(String mode){
		if (cp == null) {
			init(mode);
		}else{
			try {
				cp.testRmi();
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				init(mode);
			}
		}
	}
	
	/**
	 * 取得交易商注册银行
	 * 
	 * @param firmID
	 * @return
	 */
	public static Vector<BankValue> getAssignBankListByFirmID(String firmID, String mode) {
		Vector<BankValue> bankList = null;
		checkCp(mode);

		// 银行接口关闭
//		if (Constants.OPENFLG_CLOSE.equals(Common.getOpenFlag(mode))) {
//			return null;
//		}

		if (cp != null) {
			String sqlCond = " where bankid in (select bankid from f_b_firmidandaccount where firmid='" + firmID
					+ "' and status=0 and isopen=1)";
			try {
				bankList = cp.getBankList(sqlCond);
			} catch (RemoteException e) {
				e.printStackTrace();
			}
		}

		return bankList;
	}
	
	/**
	 * 取得交易商注册银行信息
	 * 
	 * @param firmID
	 * @param bankID
	 * @return
	 */
	public static Vector<CorrespondValue> getCorrespond(String firmID, String bankID, String mode) {
		Vector<CorrespondValue> cvList = null;
		checkCp(mode);

		if (cp != null) {
			String filter = " where bankid='" + bankID + "' and firmid='" + firmID + "'";
			try {
				cvList = cp.getCorrespondValue(filter);
			} catch (RemoteException e) {
				e.printStackTrace();
			}
		}

		return cvList;
	}

	public static FirmBalanceValue getMarketBalanceByFirmID(String firmID, String mode) {
		FirmBalanceValue fv = null;
		checkCp(mode);
		
		// 银行接口关闭
		if (Constants.OPENFLG_CLOSE.equals(Common.getOpenFlag(mode))) {
			return null;
		}
		if (cp != null) {
			try {
				fv = cp.getMarketBalance(firmID);
			} catch (RemoteException e) {
				e.printStackTrace();
			}
		}
		return fv;
	}

	/**
	 * 银行出入金处理
	 * 
	 * @param money
	 * @param firmID
	 * @param inoutFlag
	 * @param bankID
	 * @param bankName
	 * @param password
	 * @param isExpress
	 * @return
	 * @throws RemoteException
	 */
	public static String inoutMoney(BigDecimal money, String firmID, int inoutFlag, String bankID, String bankName,
			String password, int isExpress, double auditBalance, String mode) throws RemoteException {
		long result = -1;

		String results = result + "";
		checkCp(mode);
		
		// 银行接口关闭
		if (Constants.OPENFLG_CLOSE.equals(Common.getOpenFlag(mode))) {
			return result + ":" + results;
		}
		if (cp != null) {
			String filter = " where 1=1 ";
			if (firmID != null) {
				filter = filter + " and FIRMID='" + firmID + "'";
			}
			if (bankID != null) {
				filter = filter + " and bankid='" + bankID + "'";
			}
			String acount = null;
			Vector<CorrespondValue> vcv = cp.getCorrespondValue(filter);
			CorrespondValue cv = null;
			if (vcv != null && vcv.size() > 0) {
				cv = vcv.get(0);
			}
			if (cv != null && cv.isOpen == 1) {
				acount = cv.account;
			}

			if (inoutFlag == 1) {
				result = (cp.outMoney(bankID, money.doubleValue(), firmID, acount, null, "market_out", isExpress,
						0)).result;
			} else {
				result = cp.inMoneyMarket(bankID, firmID, acount, password, money.doubleValue(), "market_in");
			}

			/** 判断是否超出审核额度标志 */
			boolean Beyond = false;
			if (money.doubleValue() <= auditBalance) {
				Beyond = true;
			}

			if (inoutFlag == 1) {
				if (result >= 0) {
					if ("true".equals(autoAudit) || Beyond) {
						if (result == 5) {
							results = "出金处理中！";
						} else {
							results = "出金成功！";
						}
					} else {
						if (result == 5) {
							results = "出金处理中！";
						} else {
							results = "等待审核，请联系客服！";
						}
					}
				} else if (result == -1) {
					results = "出金金额超过审核额度，出金被拒绝！";
				} else {
					System.out.println("--------------" + result);
					results = ErrorCode.error.get(result);
					if (results == null)
						results = result + "";
				}
			} else if (inoutFlag == 0) {
				if (result >= 0) {
					results = "入金成功！";
				} else {
					results = ErrorCode.error.get(result);
					if (results == null)
						results = result + "";
				}
			}
		}
		return result + ":" + results;
	}
	
	/**
	 * 农业银行出入金处理
	 * 
	 * @param requestID
	 * @param money
	 * @param firmID
	 * @param inoutFlag
	 * @param bankID
	 * @param bankName
	 * @param signInfo
	 * @param isExpress
	 * @return
	 * @throws RemoteException
	 */
	public static String inoutMoneyForAbc(long requestID, BigDecimal money, String firmID, int inoutFlag, String bankID, String bankName,
			String signInfo, int isExpress, double auditBalance, String mode) throws RemoteException {
		long result = -1;

		String results = result + "";
		checkCp(mode);
		
		// 银行接口关闭
		if (Constants.OPENFLG_CLOSE.equals(Common.getOpenFlag(mode))) {
			return result + ":" + results;
		}
		if (cp != null) {
			String filter = " where 1=1 ";
			if (firmID != null) {
				filter = filter + " and FIRMID='" + firmID + "'";
			}
			if (bankID != null) {
				filter = filter + " and bankid='" + bankID + "'";
			}
			String acount = null;
			Vector<CorrespondValue> vcv = cp.getCorrespondValue(filter);
			CorrespondValue cv = null;
			if (vcv != null && vcv.size() > 0) {
				cv = vcv.get(0);
			}
			if (cv != null && cv.isOpen == 1) {
				acount = cv.account;
			}

			if (inoutFlag == 1) {
				result = (cp.outMoneyAbc(requestID, bankID, money.doubleValue(), firmID, acount, signInfo, "market_out", isExpress, 0)).result;
			} else {
				result = cp.inMoneyMarketAbc(requestID, bankID, firmID, acount, signInfo, money.doubleValue(), "market_in");
			}

			/** 判断是否超出审核额度标志 */
			boolean Beyond = false;
			if (money.doubleValue() <= auditBalance) {
				Beyond = true;
			}

			if (inoutFlag == 1) {
				if (result >= 0) {
					if ("true".equals(autoAudit) || Beyond) {
						if (result == 5) {
							results = "农行出金处理中！";
						} else {
							results = "农行出金成功！";
						}
					} else {
						if (result == 5) {
							results = "农行出金处理中！";
						} else {
							results = "等待审核，请联系客服！";
						}
					}
				} else if (result == -1) {
					results = "农行出金金额超过审核额度，出金被拒绝！";
				} else {
					System.out.println("--------------" + result);
					results = ErrorCode.error.get(result);
					if (results == null)
						results = result + "";
				}
			} else if (inoutFlag == 0) {
				if (result >= 0) {
					results = "农行入金成功！";
				} else {
					results = ErrorCode.error.get(result);
					if (results == null)
						results = result + "";
				}
			}
		}
		return result + ":" + results;
	}

	/**
	 * 查询交易商银行资金余额
	 * 
	 * @param firmID
	 * @param bankid
	 * @param password
	 * @return
	 * @throws RemoteException
	 */
	public static Double getFirmBankBalance(String firmID, String bankid, String password, String mode)
			throws RemoteException {
		FirmBalanceValue fv = null;
		checkCp(mode);
		
		// 银行接口关闭
		if (Constants.OPENFLG_CLOSE.equals(Common.getOpenFlag(mode))) {
			return null;
		}
		if (cp != null) {
			fv = cp.getFirmBalance(bankid, firmID, password);
		}
		return fv.getBankBalance();
	}

	/**
	 * 查询交易商银行资金流水
	 * 
	 * @param firmID
	 * @param qrDate
	 * @param srDate
	 * @return
	 * @throws RemoteException
	 */
	public static Vector<CapitalValue> getCapitalList(String firmID, String qrDate, String srDate, String type,
			String mode) throws RemoteException {
		Vector<CapitalValue> fv = null;
		checkCp(mode);
		
		// 银行接口关闭
		if (Constants.OPENFLG_CLOSE.equals(Common.getOpenFlag(mode))) {
			return null;
		}
		if (cp != null) {
			if ("".equals(qrDate) || qrDate == null) {
				qrDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
			}
			if ("".equals(srDate) || srDate == null) {
				srDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
			}

			String filter = "";
			if (Common.isEmpty(type)) {
				filter = " where (type='0' or type='1') and FIRMID='" + firmID + "' and trunc(createTime)>=to_date('"
						+ qrDate + "','yyyy-MM-dd') and trunc(createTime)<=to_date('" + srDate + "','yyyy-MM-dd') ";
			} else {
				filter = " where type ='" + type + "'  and FIRMID='" + firmID + "' and trunc(createTime)>=to_date('"
						+ qrDate + "','yyyy-MM-dd') and trunc(createTime)<=to_date('" + srDate + "','yyyy-MM-dd') ";
			}
			filter += " order by id desc";
			fv = cp.getCapitalList(filter);
		}
		return fv;
	}
	
	/**
	 * 农业银行签约
	 */
	public static ReturnValue openAbcAccount(String requestID, String bankID, String firmID, String account, String signInfo, String mode) {
		ReturnValue resultVal = new ReturnValue();
		checkCp(mode);
		try {
			String filter = " where bankID= '" + bankID + "' and firmID = '" + firmID + "' and account = '" + account
					+ "' ";
			Vector<CorrespondValue> corrList = cp.getCorrespondValue(filter);
			if (corrList == null || corrList.size() == 0) {
				resultVal.result = -6;
				return resultVal;
			}
			CorrespondValue corr = corrList.get(0);

			if (corr.isOpen == 1) {
				resultVal.result = -5;
				return resultVal;
			}
			
			corr.status = 0;
			corr.signInfo = signInfo;
			corr.actionID = requestID;

			if (openAccountBank(bankID)) {
				ReturnValue rv = null;
				rv = cp.openAccountMarket(corr);
				if (0 != rv.result) {
					resultVal.result = -3;
				} else {
					resultVal.remark = rv.remark;
					resultVal.funID = rv.funID;
					resultVal.result = 0;
				}
			} else {
				resultVal.result = -4;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultVal;
	}
	
	/**
	 * 验证可签约银行ID
	 */
	private static boolean openAccountBank(String bankID) {
		if ("05".equals(bankID) || "17".equals(bankID) || "99".equals(bankID) || "79".equals(bankID)) {
			return true;
		} else if ("21".equals(bankID)) {
			return true;
		} else if ("30".equals(bankID)) {
			return true;
		} else if ("86".equals(bankID)) {
			return true;
		}
		return false;
	}
	
	/**
	 * 农业银行解约
	 */
	public static Long delAbcAccount(String requestID, String bankID, String firmID, String account, String account1, 
			String accountName, String signInfo, int isOpen, String mode) {
		long result = -1;

		checkCp(mode);

		CorrespondValue corr = new CorrespondValue();
		corr.bankID = bankID;
		corr.firmID = firmID;
		corr.account = account;
		corr.account1 = account1;
		corr.accountName = accountName;
		corr.signInfo = signInfo;
		corr.isOpen = isOpen;
		corr.actionID = requestID;

		try {
			if (!delAccountBank(corr.bankID.trim()) && corr.isOpen == 1) {
				result = -2;
			} else {
				result = cp.delAccountMaket(corr);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	/**
	 * 验证可解约银行ID
	 */
	private static boolean delAccountBank(String bankID) {
		if ("06".equals(bankID)) {
			return true;
		} else if ("30".equals(bankID)) {
			return true;
		} else if ("86".equals(bankID)) {
			return true;
		}
		return false;
	}

	/**
	 * 判断该交易商是否绑定的平安银行
	 * 
	 * @param firmid
	 * @return
	 * @throws RemoteException
	 */
//	public static boolean isPABFirm(String firmid) {
//		if (cp == null) {
//			init();
//		}
//
//		boolean result = false;
//
//		try {
//			String filer = " where bankid = '22' and firmid = '" + firmid + "' ";
//			Vector<CorrespondValue> vec = cp.getCorrespondValue(filer);
//
//			if (vec != null && vec.size() > 0) {
//				int isOpen = vec.get(0).isOpen;
//				if (isOpen == 1) {
//					result = true;
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return result;
//	}

	/**
	 * 收/退交易商资金
	 * 
	 * @param money
	 *            金额
	 * @param firmID
	 *            交易商代码
	 * @param creditID
	 *            贷方科目
	 * @param debitID
	 *            借方科目
	 * @param contractNo
	 *            合同号
	 * @param summaryNo
	 *            摘要号
	 * @param inOutFlg
	 *            收/退Flg in：收 out：退
	 * @return ReturnValue 银行接口业务流水号,返回<0的值表示操作失败
	 * @throws RemoteException
	 */
//	public static ReturnValue transferMoney(double money, String firmID, String creditID, String debitID,
//			String contractNo, String summaryNo, String inOutFlg) {
//		if (cp == null) {
//			init();
//		}
//
//		ReturnValue rv = new ReturnValue();
//		try {
//			if ("in".equals(inOutFlg)) {
//				rv = cp.transferMoneyToMarket("22", money, firmID, creditID, debitID, contractNo, summaryNo, "");
//			} else {
//				rv = cp.transferMoneyToFirm("22", money, firmID, creditID, debitID, contractNo, summaryNo, "");
//			}
//		} catch (Exception e) {
//			rv.result = -1;
//			rv.remark = "资金划转时异常发生";
//			e.printStackTrace();
//		}
//
//		return rv;
//	}
	
	/**
	 * 农业银行获取签名用信息
	 * 
	 * @param bankID
	 * @param firmID
	 * @param functionID
	 * @param mode
	 * @return
	 * @throws RemoteException
	 */
	public static AbcSignInfoModel getAbcSignInfoString(String bankID, String firmID, String account, 
			BigDecimal payAmount, String functionID, String mode) throws RemoteException {
		AbcSignInfoModel retModel = new AbcSignInfoModel();
		checkCp(mode);
		
		if (cp != null) {
			//获取交易商银行关联信息
			String filter = " where firmid ='" + firmID + "' and bankid ='" + bankID + "' and account ='" + account + "'";
			Vector<CorrespondValue> cv = cp.getCorrespondValue(filter);
			if (cv != null && cv.size() > 0) {
				retModel.setRequestID(cp.getMktActionID());
				retModel.setFunctionID(functionID);
				if (Constants.ABC_FUNCTIONID_MARKET_SIGNUP.equals(functionID) || 
						Constants.ABC_FUNCTIONID_MARKET_SIGNOFF.equals(functionID)) {
					retModel.setMerchantID("231000003914E01");
					retModel.setMerchantName("上海化工品交易市场经营管理有限公司");
					retModel.setCustName(cv.get(0).accountName);
				} else if (Constants.ABC_FUNCTIONID_MARKET_ORDERPAY.equals(functionID)) {
					retModel.setPayAmount(payAmount);
					retModel.setOrderNo(cv.get(0).firmID.concat(String.valueOf(retModel.getRequestID())));
				}
				retModel.setResult(0);
			} else {
				retModel.setResult(-1);
			}
		}
		return retModel;
	}
}
