/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: TOrder
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.model;

import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * (TOrder)
 * 
 * @author wlpod
 * @version 1.0.0 2016-05-12
 */
public class TOrder extends BaseObject implements java.io.Serializable, Cloneable {

	private static final long serialVersionUID = -7464587171301763763L;

	private String orderId;
	private Long leadsID;
	private String traderId;
	private String userCode;
	private String sellFirmId;
	private String buyFirmId;
	private Integer tradeTmptId;
	private Integer categoryLeafID;
	private Integer brandID;
	private Integer sourcePlaceID;
	private Integer packageStandard;
	private Integer settlementMethod;
	private Integer goodsType;
	private BigDecimal price;
	private Integer quantity;
	private BigDecimal amount;
	private BigDecimal sellFee;
	private BigDecimal sellFeeRatio;
	private BigDecimal buyFee;
	private BigDecimal buyFeeRatio;
	private BigDecimal sellDeposit;
	private BigDecimal sellDepositRatio;
	private BigDecimal buyDeposit;
	private BigDecimal buyDepositRatio;
	private Date tradeDate;
	private Date delievryDate;
	private Integer tradeStatus;
	private Integer tradeMode;
	private String remarks;
	private Long enquiryID;
	private BigDecimal deliveryQuantity;
	private BigDecimal signQuantity;
	private String breachReason;
	private Integer dISABLED;
	private String rECCREATEBY;
	private Date rECCREATETIME;
	private String rECMODIFYBY;
	private Date rECMODIFYTIME;
	private Integer addressID;
	private Integer deliveryPlaceId;
	private String storeHouseFN;
	private String storeContactName;
	private String storeContactTelNo;
	private BigDecimal tradeUnitNumber;
	private BigDecimal totalQuantity;
	private BigDecimal receivableBuyLateFee;
	private BigDecimal receivedBuyLateFee;
	
	private BigDecimal sellTradeDepositLeads;
	private BigDecimal buyTradeDeposit;
	private BigDecimal sellTradeDeposit;
	

	public BigDecimal getSellTradeDeposit() {
		return sellTradeDeposit;
	}

	public void setSellTradeDeposit(BigDecimal sellTradeDeposit) {
		this.sellTradeDeposit = sellTradeDeposit;
	}

	public BigDecimal getBuyTradeDeposit() {
		return buyTradeDeposit;
	}

	public void setBuyTradeDeposit(BigDecimal buyTradeDeposit) {
		this.buyTradeDeposit = buyTradeDeposit;
	}

	public BigDecimal getSellTradeDepositLeads() {
		return sellTradeDepositLeads;
	}

	public void setSellTradeDepositLeads(BigDecimal sellTradeDepositLeads) {
		this.sellTradeDepositLeads = sellTradeDepositLeads;
	}

	public BigDecimal getReceivedBuyLateFee() {
		return receivedBuyLateFee;
	}

	public void setReceivedBuyLateFee(BigDecimal receivedBuyLateFee) {
		this.receivedBuyLateFee = receivedBuyLateFee;
	}

	public BigDecimal getReceivableBuyLateFee() {
		return receivableBuyLateFee;
	}

	public void setReceivableBuyLateFee(BigDecimal receivableBuyLateFee) {
		this.receivableBuyLateFee = receivableBuyLateFee;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Long getLeadsID() {
		return leadsID;
	}

	public void setLeadsID(Long leadsID) {
		this.leadsID = leadsID;
	}

	public String getTraderId() {
		return traderId;
	}

	public void setTraderId(String traderId) {
		this.traderId = traderId;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getSellFirmId() {
		return sellFirmId;
	}

	public void setSellFirmId(String sellFirmId) {
		this.sellFirmId = sellFirmId;
	}

	public String getBuyFirmId() {
		return buyFirmId;
	}

	public void setBuyFirmId(String buyFirmId) {
		this.buyFirmId = buyFirmId;
	}

	public Integer getTradeTmptId() {
		return tradeTmptId;
	}

	public void setTradeTmptId(Integer tradeTmptId) {
		this.tradeTmptId = tradeTmptId;
	}

	public Integer getCategoryLeafID() {
		return categoryLeafID;
	}

	public void setCategoryLeafID(Integer categoryLeafID) {
		this.categoryLeafID = categoryLeafID;
	}

	public Integer getBrandID() {
		return brandID;
	}

	public void setBrandID(Integer brandID) {
		this.brandID = brandID;
	}

	public Integer getSourcePlaceID() {
		return sourcePlaceID;
	}

	public void setSourcePlaceID(Integer sourcePlaceID) {
		this.sourcePlaceID = sourcePlaceID;
	}

	public Integer getPackageStandard() {
		return packageStandard;
	}

	public void setPackageStandard(Integer packageStandard) {
		this.packageStandard = packageStandard;
	}

	public Integer getSettlementMethod() {
		return settlementMethod;
	}

	public void setSettlementMethod(Integer settlementMethod) {
		this.settlementMethod = settlementMethod;
	}

	public Integer getGoodsType() {
		return goodsType;
	}

	public void setGoodsType(Integer goodsType) {
		this.goodsType = goodsType;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getSellFee() {
		return sellFee;
	}

	public void setSellFee(BigDecimal sellFee) {
		this.sellFee = sellFee;
	}

	public BigDecimal getSellFeeRatio() {
		return sellFeeRatio;
	}

	public void setSellFeeRatio(BigDecimal sellFeeRatio) {
		this.sellFeeRatio = sellFeeRatio;
	}

	public BigDecimal getBuyFee() {
		return buyFee;
	}

	public void setBuyFee(BigDecimal buyFee) {
		this.buyFee = buyFee;
	}

	public BigDecimal getBuyFeeRatio() {
		return buyFeeRatio;
	}

	public void setBuyFeeRatio(BigDecimal buyFeeRatio) {
		this.buyFeeRatio = buyFeeRatio;
	}

	public BigDecimal getSellDeposit() {
		return sellDeposit;
	}

	public void setSellDeposit(BigDecimal sellDeposit) {
		this.sellDeposit = sellDeposit;
	}

	public BigDecimal getSellDepositRatio() {
		return sellDepositRatio;
	}

	public void setSellDepositRatio(BigDecimal sellDepositRatio) {
		this.sellDepositRatio = sellDepositRatio;
	}

	public BigDecimal getBuyDeposit() {
		return buyDeposit;
	}

	public void setBuyDeposit(BigDecimal buyDeposit) {
		this.buyDeposit = buyDeposit;
	}

	public BigDecimal getBuyDepositRatio() {
		return buyDepositRatio;
	}

	public void setBuyDepositRatio(BigDecimal buyDepositRatio) {
		this.buyDepositRatio = buyDepositRatio;
	}

	public Date getTradeDate() {
		return tradeDate;
	}

	public void setTradeDate(Date tradeDate) {
		this.tradeDate = tradeDate;
	}

	public Date getDelievryDate() {
		return delievryDate;
	}

	public void setDelievryDate(Date delievryDate) {
		this.delievryDate = delievryDate;
	}

	public Integer getTradeStatus() {
		return tradeStatus;
	}

	public void setTradeStatus(Integer tradeStatus) {
		this.tradeStatus = tradeStatus;
	}

	public Integer getTradeMode() {
		return tradeMode;
	}

	public void setTradeMode(Integer tradeMode) {
		this.tradeMode = tradeMode;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Long getEnquiryID() {
		return enquiryID;
	}

	public void setEnquiryID(Long enquiryID) {
		this.enquiryID = enquiryID;
	}

	public BigDecimal getDeliveryQuantity() {
		return deliveryQuantity;
	}

	public void setDeliveryQuantity(BigDecimal deliveryQuantity) {
		this.deliveryQuantity = deliveryQuantity;
	}

	public BigDecimal getSignQuantity() {
		return signQuantity;
	}

	public void setSignQuantity(BigDecimal signQuantity) {
		this.signQuantity = signQuantity;
	}

	public String getBreachReason() {
		return breachReason;
	}

	public void setBreachReason(String breachReason) {
		this.breachReason = breachReason;
	}

	public Integer getdISABLED() {
		return dISABLED;
	}

	public void setdISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public String getrECCREATEBY() {
		return rECCREATEBY;
	}

	public void setrECCREATEBY(String rECCREATEBY) {
		this.rECCREATEBY = rECCREATEBY;
	}

	public Date getrECCREATETIME() {
		return rECCREATETIME;
	}

	public void setrECCREATETIME(Date rECCREATETIME) {
		this.rECCREATETIME = rECCREATETIME;
	}

	public String getrECMODIFYBY() {
		return rECMODIFYBY;
	}

	public void setrECMODIFYBY(String rECMODIFYBY) {
		this.rECMODIFYBY = rECMODIFYBY;
	}

	public Date getrECMODIFYTIME() {
		return rECMODIFYTIME;
	}

	public void setrECMODIFYTIME(Date rECMODIFYTIME) {
		this.rECMODIFYTIME = rECMODIFYTIME;
	}

	public Integer getAddressID() {
		return addressID;
	}

	public void setAddressID(Integer addressID) {
		this.addressID = addressID;
	}

	public Integer getDeliveryPlaceId() {
		return deliveryPlaceId;
	}

	public void setDeliveryPlaceId(Integer deliveryPlaceId) {
		this.deliveryPlaceId = deliveryPlaceId;
	}

	public String getStoreHouseFN() {
		return storeHouseFN;
	}

	public void setStoreHouseFN(String storeHouseFN) {
		this.storeHouseFN = storeHouseFN;
	}

	public String getStoreContactName() {
		return storeContactName;
	}

	public void setStoreContactName(String storeContactName) {
		this.storeContactName = storeContactName;
	}

	public String getStoreContactTelNo() {
		return storeContactTelNo;
	}

	public void setStoreContactTelNo(String storeContactTelNo) {
		this.storeContactTelNo = storeContactTelNo;
	}

	public BigDecimal getTradeUnitNumber() {
		return tradeUnitNumber;
	}

	public void setTradeUnitNumber(BigDecimal tradeUnitNumber) {
		this.tradeUnitNumber = tradeUnitNumber;
	}

	public BigDecimal getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(BigDecimal totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}