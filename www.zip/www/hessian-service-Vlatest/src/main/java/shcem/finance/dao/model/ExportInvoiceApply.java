package shcem.finance.dao.model;

import java.math.BigDecimal;

/**
 * 导出类：开票申请
 * 
 * @author zhangnan
 *
 */
public class ExportInvoiceApply {
	/** 单据编号 */
	private Integer id;

	/** 购货单位 */
	private String invoiceTitle;

	/** 商品名称 */
	private String categoryName;

	/** 规格型号 */
	private String brandName;

	/** 商品单位 */
	private String goodUnit;

	/** 商品数量 */
	private String applyQuantity;

	/** 税率 */
	private BigDecimal taxRate;

	/** 商品含税单价 */
	private String applyPrice;

	/** 商品含税金额 */
	private BigDecimal applyMoney;
	/** 交收单号 */
	private String deliveryID;
	/** 成交单号 */
	private String orderID;
	/** 税号 */
	private String taxNo;
	/** 地址电话(开票地址+开票电话) */
	private String invoiceAddressTel;
	/** 银行账号(银行名+支行+账号) */
	private String bankNameBranchAccount;
	/** 快递收件人(收票人) */
	private String collectInvoicePeople;
	/** 快递收件人地址(收票地址) */
	private String collectInvoiceAddress;
	/** 快递收件人电话(收票电话) */
	private String collectTel;
	
	/** 备注（开票要求、拆单开票等） */
	private String remark;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getInvoiceTitle() {
		return invoiceTitle;
	}
	public void setInvoiceTitle(String invoiceTitle) {
		this.invoiceTitle = invoiceTitle;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getGoodUnit() {
		return goodUnit;
	}
	public void setGoodUnit(String goodUnit) {
		this.goodUnit = goodUnit;
	}
	public String getApplyQuantity() {
		return applyQuantity;
	}
	public void setApplyQuantity(String applyQuantity) {
		this.applyQuantity = applyQuantity;
	}
	public BigDecimal getTaxRate() {
		return taxRate;
	}
	public void setTaxRate(BigDecimal taxRate) {
		this.taxRate = taxRate;
	}
	public String getApplyPrice() {
		return applyPrice;
	}
	public void setApplyPrice(String applyPrice) {
		this.applyPrice = applyPrice;
	}
	public BigDecimal getApplyMoney() {
		return applyMoney;
	}
	public void setApplyMoney(BigDecimal applyMoney) {
		this.applyMoney = applyMoney;
	}
	public String getDeliveryID() {
		return deliveryID;
	}
	public void setDeliveryID(String deliveryID) {
		this.deliveryID = deliveryID;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getOrderID() {
		return orderID;
	}
	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}
	public String getTaxNo() {
		return taxNo;
	}
	public void setTaxNo(String taxNo) {
		this.taxNo = taxNo;
	}
	public String getInvoiceAddressTel() {
		return invoiceAddressTel;
	}
	public void setInvoiceAddressTel(String invoiceAddressTel) {
		this.invoiceAddressTel = invoiceAddressTel;
	}
	public String getBankNameBranchAccount() {
		return bankNameBranchAccount;
	}
	public void setBankNameBranchAccount(String bankNameBranchAccount) {
		this.bankNameBranchAccount = bankNameBranchAccount;
	}
	public String getCollectInvoicePeople() {
		return collectInvoicePeople;
	}
	public void setCollectInvoicePeople(String collectInvoicePeople) {
		this.collectInvoicePeople = collectInvoicePeople;
	}
	public String getCollectInvoiceAddress() {
		return collectInvoiceAddress;
	}
	public void setCollectInvoiceAddress(String collectInvoiceAddress) {
		this.collectInvoiceAddress = collectInvoiceAddress;
	}
	public String getCollectTel() {
		return collectTel;
	}
	public void setCollectTel(String collectTel) {
		this.collectTel = collectTel;
	}
	
}
