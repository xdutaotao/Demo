/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FVoucherEntryForOra
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.model;

import java.math.BigDecimal;

import shcem.base.dao.model.BaseObject;

/**
 * (F_VOUCHERENTRY)
 * 
 * @author wlpod
 * @version 1.0.0 2016-05-12
 */
public class FVoucherEntryForOra extends BaseObject implements java.io.Serializable, Cloneable {

	private static final long serialVersionUID = -7464587171301763763L;

	/** 分录ID */
	private Integer entryid;

	/** 分录摘要 */
	private String entrysummary;

	/** 记录号（凭证代码） */
	private Integer voucherno;

	/** 科目代码 */
	private String accountcode;

	/** 科目名 */
	private String accountName;

	/** 借方金额 */
	private BigDecimal debitamount;

	/** 贷方金额 */
	private BigDecimal creditamount;

	public Integer getEntryid() {
		return entryid;
	}

	public void setEntryid(Integer entryid) {
		this.entryid = entryid;
	}

	public String getEntrysummary() {
		return entrysummary;
	}

	public void setEntrysummary(String entrysummary) {
		this.entrysummary = entrysummary;
	}

	public Integer getVoucherno() {
		return voucherno;
	}

	public void setVoucherno(Integer voucherno) {
		this.voucherno = voucherno;
	}

	public String getAccountcode() {
		return accountcode;
	}

	public void setAccountcode(String accountcode) {
		this.accountcode = accountcode;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public BigDecimal getDebitamount() {
		return debitamount;
	}

	public void setDebitamount(BigDecimal debitamount) {
		this.debitamount = debitamount;
	}

	public BigDecimal getCreditamount() {
		return creditamount;
	}

	public void setCreditamount(BigDecimal creditamount) {
		this.creditamount = creditamount;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}