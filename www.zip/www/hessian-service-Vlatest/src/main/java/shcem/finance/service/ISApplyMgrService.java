/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: ISApplyMgrService.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月12日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.service;

/**
 * @author wlpod
 *
 */
public interface ISApplyMgrService {

	/**
	 * 申请列表查询
	 */
	public String getApplyingList(String params);

	/**
	 * 审核列表查询
	 */
	public String getApprovingList(String params);

	/**
	 * 授信历史列表查询
	 */
	public String getApprovedList(String params);

	/**
	 * 授信申请追加
	 */
	public String addApply(String params);

	/**
	 * 当前授信资金查询
	 */
	public String getFirmFundsList(String params);

	/**
	 * 审核不通过
	 */
	public String approveNot(String params);

	/**
	 * 审核通过
	 */
	public String approveYes(String params);
	
	/**
	 * 授信资金流水list取得
	 */
	public String getSFundFlowList(String params);
	
	/**
	 * 授信资金和市场资金流水list取得
	 */
	public String getAllFundFlowList(String params);
}
