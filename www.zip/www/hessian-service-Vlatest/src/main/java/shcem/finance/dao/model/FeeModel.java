/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: SApply
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.model;

import java.math.BigDecimal;

import shcem.base.dao.model.BaseObject;

/**
 * (SApply)
 * 
 * @author wlpod
 * @version 1.0.0 2016-05-12
 */
public class FeeModel extends BaseObject implements java.io.Serializable, Cloneable {

	private static final long serialVersionUID = -7464587171301763763L;

	private Integer returnCode;

	private BigDecimal takenTradeFee;

	private BigDecimal takenTradeDeposit;

	private BigDecimal creditFee;

	private BigDecimal creditDeposit;

	// model 8
	private BigDecimal transTaken;

	private BigDecimal transCredit;

	// model 9
	private BigDecimal takenFee;

	private BigDecimal buyCreditDeposit;

	private BigDecimal CouponFee;

	private BigDecimal buyTakenDeposit;

	// model 10
	private BigDecimal reBackBuyTakenTradeDeposit;

	private BigDecimal takenBSDeposit;

	private BigDecimal takenMoney;

	public BigDecimal getTransTaken() {
		return transTaken;
	}

	public void setTransTaken(BigDecimal transTaken) {
		this.transTaken = transTaken;
	}

	public BigDecimal getTransCredit() {
		return transCredit;
	}

	public void setTransCredit(BigDecimal transCredit) {
		this.transCredit = transCredit;
	}

	public BigDecimal getTakenFee() {
		return takenFee;
	}

	public void setTakenFee(BigDecimal takenFee) {
		this.takenFee = takenFee;
	}

	public BigDecimal getCouponFee() {
		return CouponFee;
	}

	public void setCouponFee(BigDecimal couponFee) {
		CouponFee = couponFee;
	}

	public BigDecimal getBuyCreditDeposit() {
		return buyCreditDeposit;
	}

	public void setBuyCreditDeposit(BigDecimal buyCreditDeposit) {
		this.buyCreditDeposit = buyCreditDeposit;
	}

	public BigDecimal getBuyTakenDeposit() {
		return buyTakenDeposit;
	}

	public void setBuyTakenDeposit(BigDecimal buyTakenDeposit) {
		this.buyTakenDeposit = buyTakenDeposit;
	}

	public BigDecimal getReBackBuyTakenTradeDeposit() {
		return reBackBuyTakenTradeDeposit;
	}

	public void setReBackBuyTakenTradeDeposit(BigDecimal reBackBuyTakenTradeDeposit) {
		this.reBackBuyTakenTradeDeposit = reBackBuyTakenTradeDeposit;
	}

	public BigDecimal getTakenBSDeposit() {
		return takenBSDeposit;
	}

	public void setTakenBSDeposit(BigDecimal takenBSDeposit) {
		this.takenBSDeposit = takenBSDeposit;
	}

	public BigDecimal getTakenMoney() {
		return takenMoney;
	}

	public void setTakenMoney(BigDecimal takenMoney) {
		this.takenMoney = takenMoney;
	}

	public Integer getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(Integer returnCode) {
		this.returnCode = returnCode;
	}

	public BigDecimal getTakenTradeFee() {
		return takenTradeFee;
	}

	public void setTakenTradeFee(BigDecimal takenTradeFee) {
		this.takenTradeFee = takenTradeFee;
	}

	public BigDecimal getTakenTradeDeposit() {
		return takenTradeDeposit;
	}

	public void setTakenTradeDeposit(BigDecimal takenTradeDeposit) {
		this.takenTradeDeposit = takenTradeDeposit;
	}

	public BigDecimal getCreditFee() {
		return creditFee;
	}

	public void setCreditFee(BigDecimal creditFee) {
		this.creditFee = creditFee;
	}

	public BigDecimal getCreditDeposit() {
		return creditDeposit;
	}

	public void setCreditDeposit(BigDecimal creditDeposit) {
		this.creditDeposit = creditDeposit;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		String sep = "\n";
		sb.append("takenTradeFee:" + this.takenTradeFee + sep);
		sb.append("takenTradeDeposit:" + this.takenTradeDeposit + sep);
		sb.append("creditFee:" + this.creditFee + sep);
		sb.append("creditDeposit:" + this.creditDeposit + sep);
		sb.append("transTaken:" + this.transTaken + sep);
		sb.append("transCredit:" + this.transCredit + sep);
		sb.append("takenFee:" + this.takenFee + sep);
		sb.append("buyCreditDeposit:" + this.buyCreditDeposit + sep);
		sb.append("CouponFee:" + this.CouponFee + sep);
		sb.append("buyTakenDeposit:" + this.buyTakenDeposit + sep);
		sb.append("reBackBuyTakenTradeDeposit:" + this.reBackBuyTakenTradeDeposit + sep);
		sb.append("takenBSDeposit:" + this.takenBSDeposit + sep);
		sb.append("takenMoney:" + this.takenMoney);
		return sb.toString();
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}