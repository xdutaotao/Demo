/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: VoucherOraDAOImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.impl;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.RowMapper;

import gnnt.trade.bank.vo.BankValue;
import shcem.base.dao.impl.BaseDAOImpl;
import shcem.finance.dao.VoucherOraDAO;
import shcem.finance.dao.model.FBanks;
import shcem.finance.dao.model.FVoucherEntryForOra;
import shcem.finance.dao.model.FVoucherForOra;
import shcem.finance.dao.model.FirmValue;
import shcem.finance.dao.model.PaymentLog;
import shcem.finance.dao.model.PaymentLogDetail;
import shcem.finance.dao.model.VoucherModel;
import shcem.util.CommonRowMapper;

/**
 * VoucherOraDAOImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class VoucherOraDAOImpl extends BaseDAOImpl implements VoucherOraDAO {

	
	/**
	 * 快捷录入生成凭证
	 */
	public int createAndAuditVoucher(final String summaryNo, final String summary, final String debitCode, final String creditCode,
			final String contractno, final String inputUser, final String money) {
		this.log.debug("VoucherOraDAOImpl createAndAuditVoucher DAO Start");
		String result = "-1";
		String procedure = "{?=call FN_F_CreateAndAuditVoucher(?,?,?,?,?,?,?)}";
		try {
			result = (String) this.getJdbcTemplate().execute(procedure, new CallableStatementCallback() {
				public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {
					cs.registerOutParameter(1,Types.NUMERIC); //输出参数类型  
                	cs.setString(2, summaryNo);
                	cs.setString(3, summary);
                	cs.setString(4, debitCode);
                	cs.setString(5, creditCode);
                	cs.setBigDecimal(6, new BigDecimal(money));
                	cs.setString(7, contractno);
                	cs.setString(8, inputUser);
                	cs.execute();
                	return cs.getString(1);
				}
			});
			this.log.debug("createAndAuditVoucher.result = " + result);
		} catch (Exception e) {
			this.log.debug("createAndAuditVoucher DAO error:" + e.getMessage());
			e.printStackTrace();
			result = "-1";
			this.log.debug("createAndAuditVoucher异常发生！");
		}
		this.log.debug("VoucherOraDAOImpl createAndAuditVoucher DAO End");
		return Integer.parseInt(result);
	}

	
	/**
	 * 快捷录入生成凭证
	 */
	public int createVoucherFast(String summaryNo, String summary, String debitCode, String creditCode,
			String contractno, String inputUser, String money) {
		this.log.debug("VoucherOraDAOImpl createVoucherFast DAO Start");

		int result = 0;
		double amount = 0.0D;
		try {
			amount = Double.parseDouble(money);
		} catch (Exception e) {
			result = -1;
		}

		 if (contractno != null) {
			 contractno = "'" + contractno + "'";
		 }

		if (result == 0) {
			this.log.debug("FN_F_CreateVoucher('" + summaryNo + "','" + summary + "','" + debitCode
					+ "','" + creditCode + "'," + amount + "," + contractno + ",'" + inputUser + "')");
			result = callStoredProcedure("FN_F_CreateVoucher('" + summaryNo + "','" + summary + "','" + debitCode
					+ "','" + creditCode + "'," + amount + "," + contractno + ",'" + inputUser + "')");
			this.log.debug("createVoucherFast.result = " + result);
		}
		this.log.debug("VoucherOraDAOImpl createVoucherFast DAO End");
		return result;
	}

	/**
	 * 全部提交审核
	 */
	public void submitAllVoucherForAudit() {
		this.log.debug("VoucherOraDAOImpl submitAllVoucherForAudit DAO Start");
		String sql = "update f_Voucher set status='auditing' where status='editing'";
		updateBySQL(sql);
		this.log.debug("VoucherOraDAOImpl submitAllVoucherForAudit DAO End");
	}

	/**
	 * 提交审核
	 */
	public void submitVoucherForAudit(Long voucherNo) {
		this.log.debug("VoucherOraDAOImpl submitVoucherForAudit DAO Start");
		if (voucherNo == null)
			return;
		String sql = "update f_Voucher set status='auditing' where voucherNo= ? and status='editing'";
		Object[] params = new Object[] { voucherNo };
		updateBySQL(sql, params);
		this.log.debug("VoucherOraDAOImpl submitVoucherForAudit DAO End");
	}

	/**
	 * 取得凭证信息
	 */
	public FVoucherForOra getVoucherByNo(Long voucherNo) {
		this.log.debug("VoucherOraDAOImpl getVoucherByNo DAO Start");
		String sql = "select * from f_Voucher where voucherNo = ?";

		Object[] params = { voucherNo };

		this.logger.debug("sql: " + sql);
		this.logger.debug("voucherNo: " + params[0]);

		Object obj = null;
		FVoucherForOra voucher = null;
		try {
			obj = queryForObject(sql, params, new CommonRowMapper(new FVoucherForOra()));
			voucher = (FVoucherForOra) obj;
			voucher.setVoucherEntrys(getVoucherEntrys(voucherNo));
		} catch (IncorrectResultSizeDataAccessException e) {
			this.log.error("voucherNo " + voucherNo + " Not exist !");
		}
		this.log.debug("VoucherOraDAOImpl getVoucherByNo DAO End");
		return voucher;
	}

	/**
	 * 取得凭证Entry信息
	 */
	private List<FVoucherEntryForOra> getVoucherEntrys(Long voucherNo) {
		this.log.debug("VoucherOraDAOImpl getVoucherEntrys DAO Start");
		Object[] params = { voucherNo };

		String entrySql = "select a.*,b.name as accountName from f_VoucherEntry a,F_Account b where voucherNo=? and a.accountcode=b.code order by entryId";

		this.logger.debug("sql: " + entrySql);
		this.logger.debug("voucherNo: " + params[0]);
		List<FVoucherEntryForOra> voucherEntrys = queryBySQL(entrySql, params, null,
				new CommonRowMapper(new FVoucherEntryForOra()));
		this.log.debug("VoucherOraDAOImpl getVoucherEntrys DAO End");
		return voucherEntrys;
	}

	public void updateVoucherNotEntrys(FVoucherForOra voucher) {
		this.log.debug("VoucherOraDAOImpl updateVoucherNotEntrys DAO Start");
		String sql = "update f_Voucher set summaryNo=?, summary=?, note=?, inputuser=?, inputtime=?, auditor=?, audittime=?, auditnote=?, status=?, contractNo=?  where voucherNo=?";

		Object[] params = { voucher.getSummaryno(), voucher.getSummary(), voucher.getNote(), voucher.getInputuser(),
				voucher.getInputtime(), voucher.getAuditor(), voucher.getAudittime(), voucher.getAuditnote(),
				voucher.getStatus(), voucher.getContractno(), voucher.getVoucherno() };
		int[] dataTypes = { 1, 12, 12, 12, 93, 12, 93, 12, 12, 12, 12 };
		this.logger.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++) {
			this.logger.debug("params[" + i + "]: " + params[i]);
		}

		updateBySQL(sql, params, dataTypes);
		this.log.debug("VoucherOraDAOImpl updateVoucherNotEntrys DAO End");
	}

	/**
	 * 审核通过/失败
	 */
	public int auditVoucher(Long voucherNo, boolean isPass) {
		this.log.debug("VoucherOraDAOImpl auditVoucher DAO Start");
		int result = -1;
		if (voucherNo != null) {
			FVoucherForOra voucher = this.getVoucherByNo(voucherNo);
			if (voucher != null) {
				if (isPass) {
					result = this.auditVoucher(voucherNo);
				} else {
					voucher.setStatus("editing");
					this.updateVoucherNotEntrys(voucher);
					result = 1;
				}
			}
		}
		this.log.debug("VoucherOraDAOImpl auditVoucher DAO End");
		return result;
	}

	private int auditVoucher(final Long voucherNo) {
		this.log.debug("VoucherOraDAOImpl private auditVoucher DAO Start");
		this.log.debug("auditVoucher.voucherNo = " + voucherNo);
		String result = "-1";
		String procedure = "{?=call FN_F_auditVoucherPass(?)}";
		try {
			result = (String) this.getJdbcTemplate().execute(procedure, new CallableStatementCallback() {
				public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {
					cs.registerOutParameter(1, Types.NUMERIC); // 输出参数类型
					cs.setLong(2, voucherNo);
					cs.execute();
					return cs.getString(1);
				}
			});
			this.log.debug("auditVoucher.result = " + result);
		} catch (Exception e) {
			this.log.debug("auditVoucher Exception e = " + e.getMessage());
			e.printStackTrace();
			result = "-1";
			this.log.debug("auditVoucher异常发生！");
		}
		this.log.debug("VoucherOraDAOImpl private auditVoucher DAO End");
		return Integer.parseInt(result);
	}

	@Override
	public VoucherModel getVoucherModelByCode(String code) {
		this.log.debug("VoucherOraDAOImpl getVoucherModelByCode DAO Start");
		String sql = "select * from F_VOUCHERMODEL where code = ?";
		Object[] params = new Object[] { code };
		VoucherModel voucherModel = (VoucherModel) queryForObject(sql, params, new CommonRowMapper(new VoucherModel()));
		this.log.debug("VoucherOraDAOImpl getVoucherModelByCode DAO End");
		return voucherModel;
	}

	@Override
	public void rollBack() {
		this.log.debug("VoucherOraDAOImpl rollBack DAO Start");
		try {
			getConnection().rollback();
		} catch (CannotGetJdbcConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		this.log.debug("VoucherOraDAOImpl rollBack DAO End");
	}

	@Override
	public FBanks getBank(String bankID) {
		this.log.debug("VoucherOraDAOImpl getBank DAO Start");
		String sql = "select * from F_B_banks where bankid = ?";
		Object[] params = new Object[] { bankID };
		return (FBanks) queryForObject(sql, params, new CommonRowMapper(new FBanks()));// 通用绑定模式，根据模型和数据结果集自动。
		//return (BankValue) getJdbcTemplate().query(sql, params, new BankValueRowMapper());// 手动绑定，需自定义实现rowmapper接口。
	}

	@Override
	public FirmValue getFirm(String firmID) {
		this.log.debug("VoucherOraDAOImpl getFirm DAO Start");
		String sql = "select * from F_B_FirmUser where firmid = ?";
		Object[] params = new Object[] { firmID };
		return (FirmValue) queryForObject(sql, params, new CommonRowMapper(new FirmValue()));// 通用绑定模式，根据模型和数据结果集自动。
	}

	class BankValueRowMapper implements RowMapper<BankValue> {
		BankValueRowMapper() {
		}

		public BankValue mapRow(ResultSet rs, int rowNum) throws SQLException {
			return rsToBank(rs);
		}

		private BankValue rsToBank(ResultSet rs) throws SQLException {
			BankValue bank = new BankValue();
			bank.adapterClassname = rs.getString("adapterClassname");
			bank.bankID = rs.getString("bankID");
			bank.bankName = rs.getString("bankName");
			bank.maxPerTransCount = rs.getInt("maxPerTransCount");
			bank.maxPerTransMoney = rs.getDouble("maxPerTransMoney");
			bank.maxAuditMoney = rs.getDouble("maxAuditMoney");
			bank.validFlag = rs.getInt("validFlag");
			bank.maxPerSglTransMoney = rs.getDouble("maxPerSglTransMoney");
			bank.beginTime = rs.getString("beginTime");
			bank.endTime = rs.getString("endTime");
			bank.control = rs.getInt("control");
			return bank;
		}
	}
	
	@Override
	public int insertPaymentLog(PaymentLog paymentLog) {
		String sql = sqlProperty.getProperty("VoucherDAO_011");
		Object[] params = { paymentLog.getId(), paymentLog.getCaller(), paymentLog.getPaycount(),
				paymentLog.getStatus(), paymentLog.getNote()};
		return getJdbcTemplate().update(sql, params);
	}
	
	@Override
	public int insertPaymentLogDetail(PaymentLogDetail paymentLogDetail) {
		String sql = sqlProperty.getProperty("VoucherDAO_012");
		Object[] params = { paymentLogDetail.getId(), paymentLogDetail.getDETAILID(),
				paymentLogDetail.getVoucherModelID(), paymentLogDetail.getMoney(), paymentLogDetail.getContractno(),
				paymentLogDetail.getFirmID(), paymentLogDetail.getNote(), paymentLogDetail.getInputUser(),
				paymentLogDetail.getSTATUS(), paymentLogDetail.getERRORTYPE(), paymentLogDetail.getERRORMSG() };
		return getJdbcTemplate().update(sql, params);
	}

	@Override
	public long getPaymentId() {
		String sql = sqlProperty.getProperty("VoucherDAO_013");

		return this.queryForInt(sql);
	}

	@Override
	public int updatePaymentLogStatus(long id, Integer status) {
		String sql = sqlProperty.getProperty("VoucherDAO_014");
		Object[] params = { status, id };
		return getJdbcTemplate().update(sql, params);
	}

	@Override
	public int updatePaymentLogNote(long id, String note) {
		String sql = sqlProperty.getProperty("VoucherDAO_015");
		Object[] params = { note, id };
		return getJdbcTemplate().update(sql, params);
	}

	@Override
	public int updatePaymentLogDetailStatus(long id, Integer detailId, Integer status) {
		String sql = sqlProperty.getProperty("VoucherDAO_016");
		Object[] params = { status, id, detailId };
		return getJdbcTemplate().update(sql, params);
	}

	@Override
	public int updatePaymentLogDetailError(long id, Integer detailId, Integer errorType, String errorMsg) {
		String sql = sqlProperty.getProperty("VoucherDAO_017");
		Object[] params = { errorType, errorMsg, id, detailId };
		return getJdbcTemplate().update(sql, params);
	}

	@Override
	public int updatePaymentLogEndTime(long id) {
		String sql = sqlProperty.getProperty("VoucherDAO_018");
		Object[] params = { id };
		return getJdbcTemplate().update(sql, params);
	}

	@Override
	public int updatePaymentLogDetailEndTime(long id, Integer detailId) {
		String sql = sqlProperty.getProperty("VoucherDAO_019");
		Object[] params = { id, detailId };
		return getJdbcTemplate().update(sql, params);
	}
}
