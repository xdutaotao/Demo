package shcem.finance.dao.impl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.CannotGetJdbcConnectionException;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.ICouponDao;
import shcem.finance.dao.model.Coupon;
import shcem.finance.dao.model.CouponApply;
import shcem.finance.dao.model.CouponFlow;
import shcem.finance.dao.model.CouponFlowFront;
import shcem.util.CommonRowMapper;

public class CouponDaoImpl extends BaseDAOImpl implements ICouponDao {

	private Integer getCouponApplyId(){
		String sqlCouponFlow = "select next value for hjonline.dbo.seq_f_CouponApply";
		return this.queryForInt(sqlCouponFlow);
	}
	
	@Override
	public int insertCouponApply(CouponApply couponApply) {
		this.log.debug("insertCouponApply DAO Start");
		String sql = sqlProperty.getProperty("CouponDao_001");
		// 申请Id
		couponApply.setId(getCouponApplyId());
		Object[] params = {
				couponApply.getId(),
				couponApply.getApplyType(),0,
				couponApply.getFirmID(),couponApply.getAmount(),
				couponApply.getApplyer(),couponApply.getNote()
				};
		return this.updateBySQL(sql, params);
	}

	@Override
	public CouponApply selectCouponApplyById(Integer id) {
		this.log.debug("selectCouponApplyById DAO Start");
		String sql = sqlProperty.getProperty("CouponDao_003") + " and ca.ID = "+id;
		return (CouponApply) this.queryForObject(sql, null, new CommonRowMapper(new CouponApply()));
	}

	@Override
	public int updateCouponApplyOfStatusById(CouponApply couponApply) {
		this.log.debug("updateCouponApplyOfStatusById DAO Start");
		String sql = sqlProperty.getProperty("CouponDao_002");
		Object[] params = {
				couponApply.getStatus(),couponApply.getApprover(),
				couponApply.getRefuseReason(),couponApply.getId()
				};
		return this.updateBySQL(sql, params);
	}

	@Override
	public List<CouponApply> queryCouponApplyList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("queryCouponApplyList DAO Start");
		String sql = sqlProperty.getProperty("CouponDao_003");
		return this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new CouponApply()));
	}

	@Override
	public int insertCoupon(Coupon coupon) {
		this.log.debug("insertCoupon DAO Start");
		String sql = sqlProperty.getProperty("CouponDao_004");
		Object[] params = {
				coupon.getFirmID(),
				coupon.getBalance() == null ? coupon.getLastBalance() : coupon.getBalance(),
				coupon.getFrozenfunds() == null ? 0 : coupon.getFrozenfunds() ,
				coupon.getLastBalance()
				};
		return this.updateBySQL(sql, params);
	}

	@Override
	public List<Coupon> queryCouponList(QueryConditions qc, PageInfo pageInfo) {
		this.log.debug("queryCouponList DAO Start");
		String sql = sqlProperty.getProperty("CouponDao_005");
		return this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new Coupon()));
	}
	
	@Override
	public int updateCouponById(Coupon coupon) {
		this.log.debug("updateCouponById DAO Start");
		String sql = sqlProperty.getProperty("CouponDao_006");
		Object[] params = {
				coupon.getBalance(),
				coupon.getLastBalance(),
				coupon.getId()
				};
		return this.updateBySQL(sql, params);
	}

	private Integer getCouponFlowId(){
		String sqlCouponFlow = "select next value for hjonline.dbo.seq_F_CouponFlow";
		return this.queryForInt(sqlCouponFlow);
	}
	@Override
	public int insertCouponFlow(CouponFlow couponFlow) {
		this.log.debug("insertCouponFlow DAO Start");
		// 设置 流水号
		couponFlow.setFundFlowID(getCouponFlowId());
		String sql = sqlProperty.getProperty("CouponDao_007");
		Object[] params = {
				couponFlow.getFundFlowID(),
				couponFlow.getFirmID(),
				couponFlow.getOperCode(),
				couponFlow.getAmount(),
				couponFlow.getBalance(),
				couponFlow.getObjectID(),
				couponFlow.getObjectType(),
				couponFlow.getFlowType(),
				couponFlow.getOperator()
				};
		return this.updateBySQL(sql, params);
	}

	@Override
	public List<CouponFlow> queryCouponFlowList(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.debug("queryCouponFlowList DAO Start");
		String sql = sqlProperty.getProperty("CouponDao_008");
		return this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new CouponFlow()));
	}

//	@Override
//	public List<CouponFlowFront> queryCouponFlowListForFront(QueryConditions qc,
//			PageInfo pageInfo) {
//		this.log.debug("queryCouponFlowListForFront DAO Start");
//		String sql = sqlProperty.getProperty("CouponDao_009");
//		return this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new CouponFlowFront()));
//	}

	@Override
	public Coupon selectCouponByFirmID(String firmID) {
		this.log.debug("selectCouponByFirmID DAO Start");
		String sql = sqlProperty.getProperty("CouponDao_009");
		Object[] params = {firmID};
		return (Coupon) this.queryForObject(sql, params, new CommonRowMapper(new Coupon()));
	}

	/**
	 * 优惠券资金表使用更新（当前余额，冻结额）
	 * 用于解冻/解冻 授信资金
	 * @param firmId
	 * @param money
	 *            今次金额
	 * @return
	 */
	@Override
	public int updateCouponByUse(String firmId, BigDecimal money) {
		String sql = sqlProperty.getProperty("CouponDao_010");
		Object[] params = { money, money, firmId };
		return getJdbcTemplate().update(sql, params);
	}
	
	@Override
	public void rollBack() {
		try {
			getConnection().rollback();
		} catch (CannotGetJdbcConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	
}
