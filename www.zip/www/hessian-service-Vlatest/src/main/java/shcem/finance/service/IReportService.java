/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IPaymentService.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月15日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.service;

/**
 * @author wlpod
 *
 */
public interface IReportService {

	
	/**
	 * 取得交易商手续费合计
	 * @param params
	 * @return
	 */
	public String getTradeFeeSum(String params);
	
	/**
	 * 导出交易商手续费合计excel
	 * @param params
	 * @return
	 */
	public String exportTradeFeeSum(String params);
	
	
}
