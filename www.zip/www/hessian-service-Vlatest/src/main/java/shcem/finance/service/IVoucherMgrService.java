package shcem.finance.service;

/**
 * 凭证相关
 * 
 * @author zhangnan
 *
 */
public interface IVoucherMgrService {
	/**
	 * 获取所有凭证列表
	 * 
	 * @param params
	 * @return
	 */
	public String getAllVoucherList(String params);

	/**
	 * 获取编辑中提交凭证列表
	 * 
	 * @param params
	 * @return
	 */
	public String getEditingVoucherList(String params);

	/**
	 * 获取已提交待审核凭证列表
	 * 
	 * @param params
	 * @return
	 */
	public String getAuditingVoucherList(String params);

	/**
	 * 生成凭证
	 * 
	 * @param params
	 * @return
	 */
	public String addVoucher(String params);

	/**
	 * 提交审核
	 * 
	 * @param params
	 * @return
	 */
	public String submitAuditVoucher(String params);

	/**
	 * 审核通过/拒绝
	 * 
	 * @param params
	 * @return
	 */
	public String auditVoucher(String params);

	/**
	 * 获取凭证详情
	 * 
	 * @param params
	 * @return
	 */
	public String getVoucherByNo(String params);

	/**
	 * 删除凭证（未审核之前可以删除）
	 * 
	 * @param params
	 * @return
	 */
	public String deleteVoucher(String params);

	/**
	 * 修改凭证信息（未提交审核之前可以删除）
	 * 
	 * @param params
	 * @return
	 */
	public String updateVoucher(String params);


	/**
	 * 一次性生成/提交/审核通过新老凭证
	 * 
	 * @param params
	 * @return
	 */
	public String oneKeyCreateVoucher(String params);
	/**
	 * 获取凭证状态
	 * @param params
	 * @return
	 */
	public String getAuditStatus(String params);
}
