/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: VoucherOraDAO
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
  * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao;

import shcem.base.dao.DAO;
import shcem.finance.dao.model.FBanks;
import shcem.finance.dao.model.FVoucherForOra;
import shcem.finance.dao.model.FirmValue;
import shcem.finance.dao.model.PaymentLog;
import shcem.finance.dao.model.PaymentLogDetail;
import shcem.finance.dao.model.VoucherModel;

/**
 * VoucherOraDAO
 * 
 * @author chiyong
 * @version 1.0
 */
public abstract interface VoucherOraDAO extends DAO {
	
	public abstract int createAndAuditVoucher(String summaryNo, String summary, String debitCode, String creditCode,
			String contractno, String inputUser, String money);


	public abstract int createVoucherFast(String summaryNo, String summary, String debitCode, String creditCode,
			String contractno, String inputUser, String money);

	public abstract void submitAllVoucherForAudit();

	public abstract void submitVoucherForAudit(Long voucherNo);

	public abstract FVoucherForOra getVoucherByNo(Long voucherNo);

	public abstract void updateVoucherNotEntrys(FVoucherForOra voucher);

	public abstract int auditVoucher(Long voucherNo, boolean isPass);
	
	public abstract VoucherModel getVoucherModelByCode(String code);
	
	public abstract void rollBack();
	
	public abstract FBanks getBank(String bankID);
	
	public abstract FirmValue getFirm(String firmID);
	
	public abstract int insertPaymentLog(PaymentLog paymentLog);
	public abstract int insertPaymentLogDetail(PaymentLogDetail paymentLogDetail);
	
	public abstract int updatePaymentLogStatus(long id, Integer status);
	public abstract int updatePaymentLogNote(long id, String note);
	public abstract int updatePaymentLogEndTime(long id);
	
	public abstract int updatePaymentLogDetailStatus(long id,Integer detailId, Integer status);
	public abstract int updatePaymentLogDetailError(long id,Integer detailId, Integer errorType,String errorMsg);
	public abstract int updatePaymentLogDetailEndTime(long id,Integer detailId);
	
	public abstract long getPaymentId();
}
