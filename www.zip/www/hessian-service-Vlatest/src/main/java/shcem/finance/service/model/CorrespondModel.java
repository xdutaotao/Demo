package shcem.finance.service.model;

import java.io.Serializable;

import org.json.JSONObject;

import shcem.base.service.model.BaseServiceObject;

public class CorrespondModel extends BaseServiceObject implements Serializable {

	private static final long serialVersionUID = 1L;
	/**
	 * 银行代码
	 */
	public String bankID;
	/**
	 * 交易商代码
	 */
	public String firmID;
	/**
	 * 银行帐号(正式账号)
	 */
	public String account;
	/**
	 * 银行帐号(内部账号)
	 */
	public String account1;
	/**
	 * 账户名
	 */
	public String accountName;
	/**
	 * 银行内部账号名称
	 */
	public String accountName1;
	/**
	 * 开户行名字
	 */
	public String bankName;
	/**
	 * 开户行省份
	 */
	public String bankProvince;
	/**
	 * 开户行市
	 */
	public String bankCity;
	/**
	 * 电话
	 */
	public String mobile;
	/**
	 * 电子邮件
	 */
	public String email;
	/**
	 * 状态：0：可用1：禁用
	 */
	public int status ;
	/**
	 * 签约 状态：0：签约失败1：签约成功
	 */
	public int isOpen ;
	/** 
	 * 客户证件类型 1身份证,
	 * 2军官证,3国内护照,4户口本,5学员证,6退休证,
	 * 7临时身份证,8组织机构代码,9营业执照,
	 * A警官证,B解放军士兵证,C回乡证,D外国护照, 
	 * E港澳台居民身份证,F台湾通行证及其他有效旅行证,
	 * G海外客户编号,H解放军文职干部证,I武警文职干部证,
	 * J武警士兵证,X其他有效证件,Z重号身份证
	 */
	public String cardType ;
	/**
	 * 证件号
	 */
	public String card;
	/**
	 * 交易商冻结资金
	 */
	public double frozenFuns;
	/**
	 * 入世协议号
	 */
	public String inMarketCode;
	/**
	 * 签约时间
	 */
	public java.util.Date opentime;
	/**
	 * 解约时间
	 */
	public java.util.Date deltime;
	/**
	 * 开户行支付系统行号
	 */
	public String OpenBankCode;
	/**
	 * 是否跨行
	 */
	public String isCrossLine;
	
	public String getBankID() {
		return bankID;
	}

	public void setBankID(String bankID) {
		this.bankID = bankID;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getAccount1() {
		return account1;
	}

	public void setAccount1(String account1) {
		this.account1 = account1;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountName1() {
		return accountName1;
	}

	public void setAccountName1(String accountName1) {
		this.accountName1 = accountName1;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankProvince() {
		return bankProvince;
	}

	public void setBankProvince(String bankProvince) {
		this.bankProvince = bankProvince;
	}

	public String getBankCity() {
		return bankCity;
	}

	public void setBankCity(String bankCity) {
		this.bankCity = bankCity;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getIsOpen() {
		return isOpen;
	}

	public void setIsOpen(int isOpen) {
		this.isOpen = isOpen;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getCard() {
		return card;
	}

	public void setCard(String card) {
		this.card = card;
	}

	public double getFrozenFuns() {
		return frozenFuns;
	}

	public void setFrozenFuns(double frozenFuns) {
		this.frozenFuns = frozenFuns;
	}

	public String getInMarketCode() {
		return inMarketCode;
	}

	public void setInMarketCode(String inMarketCode) {
		this.inMarketCode = inMarketCode;
	}

	public java.util.Date getOpentime() {
		return opentime;
	}

	public void setOpentime(java.util.Date opentime) {
		this.opentime = opentime;
	}

	public java.util.Date getDeltime() {
		return deltime;
	}

	public void setDeltime(java.util.Date deltime) {
		this.deltime = deltime;
	}

	public String getOpenBankCode() {
		return OpenBankCode;
	}

	public void setOpenBankCode(String openBankCode) {
		OpenBankCode = openBankCode;
	}

	public String getIsCrossLine() {
		return isCrossLine;
	}

	public void setIsCrossLine(String isCrossLine) {
		this.isCrossLine = isCrossLine;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toString()
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toJSONObject()
	 */
	@Override
	public JSONObject toJSONObject() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#hashCode()
	 */
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}
