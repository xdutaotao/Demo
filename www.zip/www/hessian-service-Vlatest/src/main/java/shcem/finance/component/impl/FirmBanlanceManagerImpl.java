/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmBanlanceManagerImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.component.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.constant.Constants;
import shcem.finance.component.ICouponComponnetManager;
import shcem.finance.component.IFirmBanlanceManager;
import shcem.finance.component.IFirmBanlanceOraManager;
import shcem.finance.component.ISApplayManager;
import shcem.finance.component.IVoucherManager;
import shcem.finance.dao.FirmBanlanceDAO;
import shcem.finance.dao.model.CancelDetail;
import shcem.finance.dao.model.FBOutMoneyApply;
import shcem.finance.dao.model.FeeModel;
import shcem.finance.dao.model.FirmBanlanceList;
import shcem.finance.dao.model.FirmBanlanceListForOra;
import shcem.finance.dao.model.TDelivery;
import shcem.finance.dao.model.TEnquiry;
import shcem.finance.dao.model.TLeads;
import shcem.finance.dao.model.TOrder;
import shcem.finance.util.FinanceOraSysData;
import shcem.finance.util.FinanceSysData;
import shcem.util.Common;

/**
 * FirmBanlanceManagerImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class FirmBanlanceManagerImpl extends BaseManager implements IFirmBanlanceManager {
	private FirmBanlanceDAO dao;
	public void setFirmBanlanceDAO_read(FirmBanlanceDAO firmBanlanceDAO_read) {
		this.firmBanlanceDAO_read = firmBanlanceDAO_read;
	}

	private FirmBanlanceDAO firmBanlanceDAO_read;
	
	private IVoucherManager voucheMgr = null;
	private IFirmBanlanceOraManager balanceOraMgr = null;
	private ISApplayManager sapplyMgr = null;
	private ICouponComponnetManager couonMgr = null;

	@Override
	public void setFirmBanlanceDAO(FirmBanlanceDAO dao) {
		this.dao = dao;
	}

	/**
	 * 交易商当前资金查询
	 */
	@Override
	public List<FirmBanlanceList> queryFirmBanlance(QueryConditions qc, PageInfo pageInfo) {
		return this.firmBanlanceDAO_read.queryFirmBanlance(qc, pageInfo);
	}
	
	/**
	 * 报盘收保证金手续费
	 */
	@Override
	public int payMoneyByleadsId(Long leadsId) {
		getBeans();
		TLeads tLeads = this.dao.getLeadsById(leadsId);
		String firmID = tLeads.getFirmID();
		// 授信类型，0：现货 1：预售
		int goodsType = Common.getGoodsType(tLeads.getTradeType());

		// 交易商可用资金,可用授信资金取得
		BigDecimal[] firmBalances = this.getMoneys(firmID);

		// 授信金额从哪个账户扣除的判断(授信or远期授信)
		BigDecimal credit = null;
		if (goodsType == 0) {
			credit = firmBalances[1];
		} else if (goodsType == 1) {
			credit = firmBalances[2];
		} else {
			return -2;
		}

		FeeModel feeModel = this.dao.getFeeModel(1, leadsId.toString(), firmBalances[0], credit, 0, BigDecimal.ZERO, 0);

		if (feeModel.getReturnCode() == -1) {
			this.log.debug("getFeeModel(1),资金余额不足 leadsId = " + leadsId);
			sapplyMgr.rollback();
			voucheMgr.rollback();
			return -1;
		}
		if (getFeeAndDeposit(tLeads.getLeadsCode(), 2, firmID, feeModel, "报盘时收卖家", goodsType)) {
			return 0;
		} else {
			return -2;
		}
	}

	/**
	 * 询盘收保证金手续费
	 */
	@Override
	public int payMoneyByEnquiryId(Long enquiryId) {
		getBeans();
		TEnquiry tEnquiry = this.dao.getEnquiryById(enquiryId);
		TLeads tLeads = this.dao.getLeadsById(tEnquiry.getLeadsID());

		String firmID = tEnquiry.getFirmId();
		// 授信类型，0：现货 1：预售
		int goodsType = Common.getGoodsType(tLeads.getTradeType());

		// 交易商可用资金,可用授信资金取得
		BigDecimal[] firmBalances = this.getMoneys(firmID);

		// 授信金额从哪个账户扣除的判断(授信or远期授信)
		BigDecimal credit = null;
		if (goodsType == 0) {
			credit = firmBalances[1];
		} else if (goodsType == 1) {
			credit = firmBalances[2];
		} else {
			return -2;
		}

		FeeModel feeModel = this.dao.getFeeModel(2, enquiryId.toString(), firmBalances[0], credit, 0, BigDecimal.ZERO, 0);

		if (feeModel.getReturnCode() == -1) {
			this.log.debug("getFeeModel(2),资金余额不足 enquiryId = " + enquiryId);
			sapplyMgr.rollback();
			voucheMgr.rollback();
			return -1;
		}
		if (getFeeAndDeposit(tEnquiry.getEnquiryCode(), 4, firmID, feeModel, "询盘时收买家", goodsType)) {
			return 0;
		} else {
			return -2;
		}
	}

	/**
	 * 成交时收保证金手续费
	 */
	@Override
	public int payMoneyByOrderId(String orderID) {
		getBeans();

		log.debug("payMoneyByOrderId成交下单开始  time =" + Common.fmtDateTimeSSS(Common.getDate()));
		TOrder tOrder = this.dao.getOrderById(orderID);
		//发盘方
		String sellFirmId = tOrder.getSellFirmId();
		//接盘方
		String buyFirmId = tOrder.getBuyFirmId();
		
		TLeads tLeads = this.dao.getLeadsById(tOrder.getLeadsID());
		
		if(tLeads.getFirmID().equals(buyFirmId)){
			buyFirmId = tOrder.getSellFirmId();
			sellFirmId = tOrder.getBuyFirmId();
		}
		
		
		// 授信类型，0：现货 1：预售
		int goodsType = Common.getGoodsType(tLeads.getTradeType());

		boolean result = false;

		// 买家交易商可用资金,可用授信资金取得
		BigDecimal[] firmBalances = this.getMoneys(buyFirmId);

		// 授信金额从哪个账户扣除的判断(授信or远期授信)
		BigDecimal credit = null;
		if (goodsType == 0) {
			credit = firmBalances[1];
		} else if (goodsType == 1) {
			credit = firmBalances[2];
		} else {
			return -1;
		}
		log.debug("payMoneyByOrderId成交下单处理接盘方开始  time =" + Common.fmtDateTimeSSS(Common.getDate()));
		// 没有询盘的情况,直接下单的情况
		if (tOrder.getEnquiryID() == null) {
			log.debug("payMoneyByOrderId成交下单没有询盘！！！！");
			// 收买家手续费保证金
			FeeModel feeModel = this.dao.getFeeModel(3, orderID, firmBalances[0], credit, 0, BigDecimal.ZERO, 0);
			if (feeModel.getReturnCode() == -1) {
				this.log.debug("getFeeModel(3),资金余额不足 orderID = " + orderID);
				sapplyMgr.rollback();
				voucheMgr.rollback();
				return -2;
			}
			result = getFeeAndDeposit(orderID, 1, buyFirmId, feeModel, "直接下单成交时收接盘方", goodsType);
			if (!result) {
				return -3;
			}
		} else {
			log.debug("payMoneyByOrderId成交下单有询盘！！！！");
			TEnquiry tEnquiry = this.dao.getEnquiryById(tOrder.getEnquiryID());
			// 询单，还盘后成交的情况
			FeeModel feeModel = this.dao.getFeeModel(4, orderID, firmBalances[0], credit, 0, BigDecimal.ZERO, 0);
			if (feeModel.getReturnCode() == -1) {
				sapplyMgr.rollback();
				voucheMgr.rollback();
				this.log.debug("getFeeModel(4),资金余额不足 orderID = " + orderID);
				return -2;
			}
			// 退询盘手续费保证金
			FeeModel feeModelTmp = new FeeModel();
			feeModelTmp.setTakenTradeFee(BigDecimal.ZERO);
			feeModelTmp.setTakenTradeDeposit(feeModel.getTakenTradeDeposit());
			feeModelTmp.setCreditFee(BigDecimal.ZERO);
			feeModelTmp.setCreditDeposit(feeModel.getCreditDeposit());
			result = backFeeAndDeposit(tEnquiry.getEnquiryCode(), 4, buyFirmId, feeModelTmp, "成交时退接盘方询盘", goodsType);
			if (!result) {
				return -5;
			}
			// 收成交手续费保证金
			feeModelTmp = new FeeModel();
			feeModelTmp.setTakenTradeFee(BigDecimal.ZERO);
			feeModelTmp.setTakenTradeDeposit(feeModel.getBuyTakenDeposit());
			feeModelTmp.setCreditFee(BigDecimal.ZERO);
			feeModelTmp.setCreditDeposit(feeModel.getBuyCreditDeposit());
			result = getFeeAndDeposit(orderID, 1, buyFirmId, feeModelTmp, "成交时收接盘方成交", goodsType);
			if (!result) {
				return -6;
			}
		}
		log.debug("payMoneyByOrderId成交下单处理接盘方结束  time =" + Common.fmtDateTimeSSS(Common.getDate()));
		
		log.debug("payMoneyByOrderId成交下单处理发盘方开始  time =" + Common.fmtDateTimeSSS(Common.getDate()));
		// 卖家资金退收
		FeeModel feeModel = this.dao.getFeeModel(5, orderID, null, null, 0, BigDecimal.ZERO, 0);
		if (feeModel.getReturnCode() == -1) {
			sapplyMgr.rollback();
			voucheMgr.rollback();
			this.log.debug("getFeeModel(5),资金余额不足 orderID = " + orderID);
			return -4;
		}
		// 退报盘手续费保证金
		result = backFeeAndDeposit(tLeads.getLeadsCode(), 2, sellFirmId, feeModel, "成交时退发盘方报盘", goodsType);
		if (!result) {
			return -5;
		}
		// 收成交手续费保证金
		result = getFeeAndDeposit(orderID, 1, sellFirmId, feeModel, "成交时收发盘方成交", goodsType);
		if (!result) {
			return -6;
		}
		log.debug("payMoneyByOrderId成交下单处理发盘方结束  time =" + Common.fmtDateTimeSSS(Common.getDate()));
		
		
		//发盘方自动补保
		
		// 发盘方可用资金,可用授信资金取得
		BigDecimal[] firmBalances2 = this.getMoneys(sellFirmId);

		// 授信金额从哪个账户扣除的判断(授信or远期授信)
		BigDecimal credit2 = null;
		if (goodsType == 0) {
			credit2 = firmBalances2[1];
		} else if (goodsType == 1) {
			credit2 = firmBalances2[2];
		} else {
			return -1;
		}
		
		//已收金额
		BigDecimal yishouDeposit = BigDecimal.ZERO;		
		int bsFlg;
		if(sellFirmId.equals(tOrder.getSellFirmId())){
			yishouDeposit = tOrder.getSellTradeDeposit();
			bsFlg = 0;
		}else{
			yishouDeposit = tOrder.getBuyTradeDeposit();
			bsFlg = 1;
		}
		//需要补保金额
		BigDecimal haixuDeposit = tOrder.getSellTradeDepositLeads().subtract(yishouDeposit);
		
		
		//授信额度够的话，自动补保
		if(credit2.compareTo(haixuDeposit) >= 0 && tLeads.getTradeType() == 2){
			// 发盘方补交保证金
			feeModel = this.dao.getFeeModel(12, orderID, firmBalances2[0], credit2, 0, BigDecimal.ZERO, bsFlg);
			if (feeModel.getReturnCode() == -1) {
				this.log.debug("getFeeModel(12),资金余额不足 orderID = " + orderID);
				sapplyMgr.rollback();
				voucheMgr.rollback();
				return -4;
			}

			// 加（减）保证金实体资金额
			FeeModel feeModelTmp = new FeeModel();
			feeModelTmp.setTakenTradeFee(BigDecimal.ZERO);
			feeModelTmp.setTakenTradeDeposit(feeModel.getBuyTakenDeposit().abs());
			feeModelTmp.setCreditFee(BigDecimal.ZERO);
			feeModelTmp.setCreditDeposit(BigDecimal.ZERO);
			if (feeModel.getBuyTakenDeposit().compareTo(BigDecimal.ZERO) == -1) {
				if (!backFeeAndDeposit(orderID, 1, sellFirmId, feeModelTmp, "退发盘方", goodsType)) {
					return -1;
				}
			} else if (feeModel.getBuyTakenDeposit().compareTo(BigDecimal.ZERO) == 1) {
				if (!getFeeAndDeposit(orderID, 1, sellFirmId, feeModelTmp, "收发盘方", goodsType)) {
					return -1;
				}
			}

			// 加（减）保证金授信额
			feeModelTmp = new FeeModel();
			feeModelTmp.setTakenTradeFee(BigDecimal.ZERO);
			feeModelTmp.setTakenTradeDeposit(BigDecimal.ZERO);
			feeModelTmp.setCreditFee(BigDecimal.ZERO);
			feeModelTmp.setCreditDeposit(feeModel.getBuyCreditDeposit().abs());
			if (feeModel.getBuyCreditDeposit().compareTo(BigDecimal.ZERO) == -1) {
				if (!backFeeAndDeposit(orderID, 1, sellFirmId, feeModelTmp, "退发盘方", goodsType)) {
					return -1;
				}
			} else if (feeModel.getBuyCreditDeposit().compareTo(BigDecimal.ZERO) == 1) {
				if (!getFeeAndDeposit(orderID, 1, sellFirmId, feeModelTmp, "收发盘方", goodsType)) {
					return -1;
				}
			}
		}
		
		log.debug("payMoneyByOrderId成交下单结束  time =" + Common.fmtDateTimeSSS(Common.getDate()));
		return 0;
	}

	@Override
	public HashMap PaymentBuyer(String orderID, boolean couponFlg, String Operator, BigDecimal couponAmount) {
		getBeans();
		TOrder tOrder = this.dao.getOrderById(orderID);
		String buyFirmId = tOrder.getBuyFirmId();
		boolean result = false;
		TLeads tLeads = this.dao.getLeadsById(tOrder.getLeadsID());
		// 授信类型，0：现货 1：预售
		int goodsType = Common.getGoodsType(tLeads.getTradeType());
		BigDecimal lateFee = tOrder.getReceivableBuyLateFee();//应收买方滞纳金
		if(lateFee == null){
			lateFee = BigDecimal.ZERO; 
		}

		HashMap map = new HashMap();
		int intFlg = -1;
		if (couponFlg) {
			if (couponAmount.compareTo(BigDecimal.ZERO) == 0) {
				intFlg = 1;
			} else {
				intFlg = 2;
			}
		} else {
			if (couponAmount.compareTo(BigDecimal.ZERO) == 0) {
				intFlg = 0;
			} else {
				intFlg = 3;
			}
		}
		
		// 买家交易商可用资金,可用授信资金取得
		BigDecimal[] firmBalances = this.getMoneys(buyFirmId);

		// 退买家保证金
		FeeModel feeModel = this.dao.getFeeModel(9, orderID, firmBalances[0], null, intFlg, couponAmount, 0);
		map.put("feeModel", feeModel);
		map.put("LateFee", lateFee);
		map.put("result", 0);
		if (feeModel.getReturnCode() == -1) {
			sapplyMgr.rollback();
			voucheMgr.rollback();
			this.log.debug("getFeeModel(9),资金余额不足 orderID = " + orderID);
			map.put("result", -1);
			return map;
		}

		// 退买家保证金
		FeeModel feeModelTmp = new FeeModel();
		feeModelTmp.setTakenTradeFee(BigDecimal.ZERO);
		feeModelTmp.setTakenTradeDeposit(feeModel.getBuyTakenDeposit());
		feeModelTmp.setCreditFee(BigDecimal.ZERO);
		feeModelTmp.setCreditDeposit(feeModel.getBuyCreditDeposit());

		// 退买家保证金
		result = backFeeAndDeposit(orderID, 1, buyFirmId, feeModelTmp, "付款时退买家交易", goodsType);
		if (!result) {
			map.put("result", -2);
			return map;
		}

		// 收买家手续费
		feeModelTmp = new FeeModel();
		feeModelTmp.setTakenTradeFee(feeModel.getTakenFee());
		feeModelTmp.setTakenTradeDeposit(BigDecimal.ZERO);
		feeModelTmp.setCreditFee(BigDecimal.ZERO);
		feeModelTmp.setCreditDeposit(BigDecimal.ZERO);
		// 收买家资金手续费
		result = getFeeAndDeposit(orderID, 1, buyFirmId, feeModelTmp, "付款时收买家", goodsType);
		if (!result) {
			map.put("result", -2);
			return map;
		}

		// 收买家货款
		if (!Realpay(Constants.VOUCHERMODE_SHOU_HUO_KUAN, feeModel.getTakenMoney(), orderID, buyFirmId, "付款时收买家货款",
				"system")) {
			map.put("result", -2);
			return map;
		}
		
		// 收买家滞纳金
		if (!Realpay(Constants.VOUCHERMODE_SHOU_ZHI_NA_JIN, lateFee, orderID, buyFirmId, "付款时收买家滞纳金",
				"system")) {
			map.put("result", -2);
			return map;
		}

		// 优惠券抵扣手续费
		if (feeModel.getCouponFee().compareTo(BigDecimal.ZERO) != 0) {
			int rst = couonMgr.getFee(buyFirmId, feeModel.getCouponFee(), orderID, 1, 2, Operator);
			if (rst < 0) {
				sapplyMgr.rollback();
				voucheMgr.rollback();
				couonMgr.rollback();
				map.put("result", -2);
				return map;
			}
		}
		// 买家交易商可用资金,可用授信资金取得
		firmBalances = this.getMoneys(buyFirmId);
		map.put("firmBalances", firmBalances);
		return map;
	}

	/**
	 * 交收时收保证金手续费，收货款
	 */
	@Override
	public boolean payMoneyByDeliveryId(String deliveryId) {
		getBeans();
		TDelivery tDelivery = this.dao.getDeliveryById(deliveryId);
		String orderId = tDelivery.getOrderID();
		TOrder tOrder = this.dao.getOrderById(orderId);
		String sellFirmId = tOrder.getSellFirmId();
		String buyFirmId = tOrder.getBuyFirmId();
		TLeads tLeads = this.dao.getLeadsById(tOrder.getLeadsID());
		// 授信类型，0：现货 1：预售
		int goodsType = Common.getGoodsType(tLeads.getTradeType());
		boolean result = false;

		// 卖家资金退收
		FeeModel feeModel = this.dao.getFeeModel(8, deliveryId, null, null, 0, BigDecimal.ZERO, 0);
		if (feeModel.getReturnCode() == -1) {
			sapplyMgr.rollback();
			voucheMgr.rollback();
			this.log.debug("getFeeModel(8),资金余额不足 deliveryId = " + deliveryId);
			return false;
		}

		// 退卖家交易保证金,收卖家交收保证金
		FeeModel feeModelTmp = new FeeModel();
		feeModelTmp.setTakenTradeFee(BigDecimal.ZERO);
		feeModelTmp.setTakenTradeDeposit(feeModel.getTransTaken());
		feeModelTmp.setCreditFee(BigDecimal.ZERO);
		feeModelTmp.setCreditDeposit(feeModel.getTransCredit());

		// 退卖家交易保证金
		result = backFeeAndDeposit(orderId, 5, sellFirmId, feeModelTmp, "交收时退卖家交易", goodsType);
		if (!result) {
			return false;
		}

		// 收卖家交收保证金
		result = getFeeAndDepositDeli(deliveryId, 5, sellFirmId, feeModelTmp, "交收时收卖家交收", goodsType);
		if (!result) {
			return false;
		}

		// 买家资金退收

		// 买家交易商可用资金,可用授信资金取得
		BigDecimal[] firmBalances = this.getMoneys(buyFirmId);

		// // 退买家授信手续费保证金，收买家资金手续费保证金
		// feeModel = this.dao.getFeeModel(9, deliveryId, firmBalances[0],
		// null);
		// if (feeModel.getReturnCode() == -1) {
		// sapplyMgr.rollback();
		// voucheMgr.rollback();
		// this.log.debug("getFeeModel(9),资金余额不足 deliveryId = " + deliveryId);
		// return false;
		// }
		//
		// feeModelTmp = new FeeModel();
		// feeModelTmp.setTakenTradeFee(BigDecimal.ZERO);
		// feeModelTmp.setTakenTradeDeposit(BigDecimal.ZERO);
		// feeModelTmp.setCreditFee(feeModel.getBuyCreditFee());
		// feeModelTmp.setCreditDeposit(feeModel.getBuyCreditDeposit());
		//
		// // 退买家授信手续费保证金
		// result = backFeeAndDeposit(orderId, 5, buyFirmId, feeModelTmp,
		// "交收时退买家授信");
		// if (!result) {
		// return false;
		// }
		//
		// feeModelTmp = new FeeModel();
		// feeModelTmp.setTakenTradeFee(feeModel.getBuyCreditFee());
		// feeModelTmp.setTakenTradeDeposit(feeModel.getBuyCreditDeposit());
		// feeModelTmp.setCreditFee(BigDecimal.ZERO);
		// feeModelTmp.setCreditDeposit(BigDecimal.ZERO);
		// // 收买家资金手续费保证金
		// result = getFeeAndDeposit(orderId, 5, buyFirmId, feeModelTmp,
		// "交收时收买家");
		// if (!result) {
		// return false;
		// }

		feeModel = this.dao.getFeeModel(10, deliveryId, firmBalances[0], null, 0, BigDecimal.ZERO, 0);
		if (feeModel.getReturnCode() == -1) {
			sapplyMgr.rollback();
			voucheMgr.rollback();
			this.log.debug("getFeeModel(10),资金余额不足 deliveryId = " + deliveryId);
			return false;
		}

		feeModelTmp = new FeeModel();
		feeModelTmp.setTakenTradeFee(BigDecimal.ZERO);
		feeModelTmp.setTakenTradeDeposit(feeModel.getReBackBuyTakenTradeDeposit());
		feeModelTmp.setCreditFee(BigDecimal.ZERO);
		feeModelTmp.setCreditDeposit(BigDecimal.ZERO);
		// 退买家已收交易保证金
		result = backFeeAndDeposit(orderId, 5, buyFirmId, feeModelTmp, "交收时退买家", goodsType);
		if (!result) {
			return false;
		}

		feeModelTmp = new FeeModel();
		feeModelTmp.setTakenTradeFee(BigDecimal.ZERO);
		feeModelTmp.setTakenTradeDeposit(feeModel.getTakenBSDeposit());
		feeModelTmp.setCreditFee(BigDecimal.ZERO);
		feeModelTmp.setCreditDeposit(BigDecimal.ZERO);
		// 收买家交收保证金
		result = getFeeAndDepositDeli(deliveryId, 5, buyFirmId, feeModelTmp, "交收时收买家交收", goodsType);
		if (!result) {
			return false;
		}

		// 收买家货款
		if (!Realpay(Constants.VOUCHERMODE_SHOU_HUO_KUAN, feeModel.getTakenMoney(), deliveryId.toString(), buyFirmId,
				"交收时收买家货款", "system")) {
			return false;
		}

		return true;
	}

	/**
	 * 报盘撤单退保证金手续费
	 */
	@Override
	public boolean backByLeadsID(Long leadsId) {
		getBeans();
		TLeads tLeads = this.dao.getLeadsById(leadsId);
		String firmID = tLeads.getFirmID();
		// 授信类型，0：现货 1：预售
		int goodsType = Common.getGoodsType(tLeads.getTradeType());

		// 挂盘撤盘 退交易手续费、保证金
		FeeModel feeModel = this.dao.getFeeModel(6, leadsId.toString(), null, null, 0, BigDecimal.ZERO, 0);
		return backFeeAndDeposit(tLeads.getLeadsCode(), 2, firmID, feeModel, "报盘撤单时退", goodsType);
	}

	/**
	 * 询盘撤单退保证金手续费
	 */
	@Override
	public boolean backByEnquiryID(Long enquiryId) {
		this.log.info(this.getClass().getName()+" backByEnquiryID(询盘撤单退保证金手续费) Start");
		getBeans();
		TEnquiry tEnquiry = this.dao.getEnquiryById(enquiryId);
		TLeads tLeads = this.dao.getLeadsById(tEnquiry.getLeadsID());
		String firmID = tEnquiry.getFirmId();
		// 授信类型，0：现货 1：预售
		int goodsType = Common.getGoodsType(tLeads.getTradeType());

		FeeModel feeModel = this.dao.getFeeModel(7, enquiryId.toString(), null, null, 0, BigDecimal.ZERO, 0);
		return backFeeAndDeposit(tEnquiry.getEnquiryCode(), 4, firmID, feeModel, "询盘撤单时退", goodsType);
	}

	private void getBeans() {
		if (voucheMgr == null) {
			voucheMgr = (IVoucherManager) FinanceSysData.getBean(Constants.BEAN_VOUCHER_MGR);
		}
		if (sapplyMgr == null) {
			sapplyMgr = (ISApplayManager) FinanceSysData.getBean(Constants.BEAN_SAPPLYMGR_MGR);
		}
		if (balanceOraMgr == null) {
			balanceOraMgr = (IFirmBanlanceOraManager) FinanceOraSysData.getBean(Constants.BEAN_BALANCEORA_MGR);
		}
		if (couonMgr == null) {
			couonMgr = (ICouponComponnetManager) FinanceSysData.getBean(Constants.BEAN_COUPON_MGR);
		}
	}

	/**
	 * 收取手续费保证金
	 * 
	 * @param ObjectID
	 * @param flowType
	 * @param firmID
	 * @param feeModel
	 * @param note
	 * @return
	 */
	private boolean getFeeAndDeposit(String ObjectID, int flowType, String firmID, FeeModel feeModel, String note,
			int creditType) {

		// 收取授信交易手续费
		if (feeModel.getCreditFee() != null && feeModel.getCreditFee().compareTo(BigDecimal.ZERO) != 0) {
			if (!Spay(firmID, feeModel.getCreditFee(), ObjectID.toString(), flowType, 1, creditType)) {
				return false;
			}
		}
		// 收取授信交易保证金
		if (feeModel.getCreditDeposit() != null && feeModel.getCreditDeposit().compareTo(BigDecimal.ZERO) != 0) {
			if (!Spay(firmID, feeModel.getCreditDeposit(), ObjectID.toString(), flowType, 3, creditType)) {
				return false;
			}
		}

		// 收交易手续费
		if (feeModel.getTakenTradeFee() != null && feeModel.getTakenTradeFee().compareTo(BigDecimal.ZERO) != 0) {
			if (!Realpay(Constants.VOUCHERMODE_SHOU_JIAOYI_SHOUXUFEI, feeModel.getTakenTradeFee(), ObjectID.toString(),
					firmID, note + "手续费", "system")) {
				return false;
			}
		}
		// 收交易保证金
		if (feeModel.getTakenTradeDeposit() != null && feeModel.getTakenTradeDeposit().compareTo(BigDecimal.ZERO) != 0) {
			if (!Realpay(Constants.VOUCHERMODE_SHOU_BAOZHENGJIN, feeModel.getTakenTradeDeposit(), ObjectID.toString(),
					firmID, note + "保证金", "system")) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 退还手续费保证金
	 * 
	 * @param ObjectID
	 * @param flowType
	 * @param firmID
	 * @param feeModel
	 * @param note
	 * @return
	 */
	@Override
	public boolean backFeeAndDeposit(String ObjectID, int flowType, String firmID, FeeModel feeModel, String note,
			int creditType) {
		getBeans();
		// 退还授信交易手续费
		if (feeModel.getCreditFee() != null && feeModel.getCreditFee().compareTo(BigDecimal.ZERO) != 0) {
			if (!Spay(firmID, feeModel.getCreditFee(), ObjectID.toString(), flowType, 2, creditType)) {
				return false;
			}
		}
		// 退还授信交易保证金
		if (feeModel.getCreditDeposit() != null && feeModel.getCreditDeposit().compareTo(BigDecimal.ZERO) != 0) {
			if (!Spay(firmID, feeModel.getCreditDeposit(), ObjectID.toString(), flowType, 4, creditType)) {
				return false;
			}
		}
		// 退交易手续费
		if (feeModel.getTakenTradeFee() != null && feeModel.getTakenTradeFee().compareTo(BigDecimal.ZERO) != 0) {
			if (!Realpay(Constants.VOUCHERMODE_TUI_JIAOYI_SHOUXUFEI, feeModel.getTakenTradeFee(), ObjectID.toString(),
					firmID, note + "手续费", "system")) {
				return false;
			}
		}
		// 退交易保证金
		if (feeModel.getTakenTradeDeposit() != null && feeModel.getTakenTradeDeposit().compareTo(BigDecimal.ZERO) != 0) {
			if (!Realpay(Constants.VOUCHERMODE_TUI_BAOZHENGJIN, feeModel.getTakenTradeDeposit(), ObjectID.toString(),
					firmID, note + "保证金", "system")) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 收取交收手续费保证金
	 * 
	 * @param ObjectID
	 * @param flowType
	 * @param firmID
	 * @param feeModel
	 * @param note
	 * @return
	 */
	@Override
	public boolean getFeeAndDepositDeli(String ObjectID, int flowType, String firmID, FeeModel feeModel, String note,
			int creditType) {
		getBeans();
		// 收取授信交收手续费
		if (feeModel.getCreditFee() != null && feeModel.getCreditFee().compareTo(BigDecimal.ZERO) != 0) {
			if (!Spay(firmID, feeModel.getCreditFee(), ObjectID.toString(), flowType, 5, creditType)) {
				return false;
			}
		}
		// 收取授信交收保证金
		if (feeModel.getCreditDeposit() != null && feeModel.getCreditDeposit().compareTo(BigDecimal.ZERO) != 0) {
			if (!Spay(firmID, feeModel.getCreditDeposit(), ObjectID.toString(), flowType, 7, creditType)) {
				return false;
			}
		}
		// 收交收手续费
		if (feeModel.getTakenTradeFee() != null && feeModel.getTakenTradeFee().compareTo(BigDecimal.ZERO) != 0) {
			if (!Realpay(Constants.VOUCHERMODE_SHOU_JIAOSHOU_SHOUXUFEI, feeModel.getTakenTradeFee(),
					ObjectID.toString(), firmID, note + "手续费", "system")) {
				return false;
			}
		}
		// 收交收保证金
		if (feeModel.getTakenTradeDeposit() != null && feeModel.getTakenTradeDeposit().compareTo(BigDecimal.ZERO) != 0) {
			if (!Realpay(Constants.VOUCHERMODE_SHOU_JIAOSHOU_BAOZHENGJING, feeModel.getTakenTradeDeposit(),
					ObjectID.toString(), firmID, note + "保证金", "system")) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 交易商可用资金,可用授信资金取得
	 * 
	 * @param firmID
	 * @param tmplID
	 * @param cateID
	 * @param brandID
	 * @param tradeRole
	 * @param price
	 * @param quantity
	 * @param tradeUnitNumber
	 * @return BigDecimal[0] 交易商可用资金 BigDecimal[1] 交易商可用授信资金
	 *         BigDecimal[2]交易商可用授信资金 (远期)
	 */
	public BigDecimal[] getMoneys(String firmID) {
		BigDecimal firmBalance = new BigDecimal(0.00); // 交易商可用资金
		BigDecimal firmCreditBalance = new BigDecimal(0.00); // 交易商可用授信资金
		BigDecimal firmPreSaleCreditBalance = new BigDecimal(0.00); // 交易商可用授信资金
																	// (远期)

		QueryConditions qc = new QueryConditions();
		qc.addCondition("t1.FIRMID", "=", firmID);
		List<FirmBanlanceList> list1 = this.queryFirmBanlance(qc, null);
		if (list1 != null && list1.size() > 0 && list1.get(0).getBALANCEFromS() != null) {
			firmCreditBalance = list1.get(0).getBALANCEFromS();
			firmPreSaleCreditBalance = list1.get(0).getPreSaleBALANCEFROMS();
		}

		List<FirmBanlanceListForOra> list2 = balanceOraMgr.queryFirmBanlance(qc, null);
		if (list2 != null && list2.size() > 0 && list2.get(0).getUSER_BALANCE() != null) {
			firmBalance = list2.get(0).getUSER_BALANCE();
		}

		return new BigDecimal[] { firmBalance, firmCreditBalance, firmPreSaleCreditBalance };
	}

	/**
	 * 授信资金收取或退还
	 * 
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @param mode
	 *            1： 收取授信交易手续费 2：退还授信交易手续费 3：收取授信交易保证金 4：退还授信交易保证金 5：收取授信交收手续费
	 *            6：退还授信交收手续费 7：收取授信交收保证金 8：退还授信交收保证金
	 * @return
	 */
	private boolean Spay(String firmID, BigDecimal money, String ObjectID, int flowType, int mode, int creditType) {
		if (money.compareTo(BigDecimal.ZERO) == 0) {
			return true;
		}

		int result = 1;

		switch (mode) {
		case 1:
			if (creditType == 0) {
				result = sapplyMgr.getFee(firmID, money, ObjectID, flowType);
			} else {
				result = sapplyMgr.getFeeForPreSale(firmID, money, ObjectID, flowType);
			}
			break;
		case 2:
			if (creditType == 0) {
				result = sapplyMgr.backFee(firmID, money, ObjectID, flowType);
			} else {
				result = sapplyMgr.backFeeForPreSale(firmID, money, ObjectID, flowType);
			}
			break;
		case 3:
			if (creditType == 0) {
				result = sapplyMgr.getMargin(firmID, money, ObjectID, flowType);
			} else {
				result = sapplyMgr.getMarginForPreSale(firmID, money, ObjectID, flowType);
			}
			break;
		case 4:
			if (creditType == 0) {
				result = sapplyMgr.backMargin(firmID, money, ObjectID, flowType);
			} else {
				result = sapplyMgr.backMarginForPreSale(firmID, money, ObjectID, flowType);
			}
			break;
		case 5:
			if (creditType == 0) {
				result = sapplyMgr.getSettleFee(firmID, money, ObjectID, flowType);
			} else {
				result = sapplyMgr.getSettleFeeForPreSale(firmID, money, ObjectID, flowType);
			}
			break;
		case 6:
			if (creditType == 0) {
				result = sapplyMgr.backSettleFee(firmID, money, ObjectID, flowType);
			} else {
				result = sapplyMgr.backSettleFeeForPreSale(firmID, money, ObjectID, flowType);
			}
			break;
		case 7:
			if (creditType == 0) {
				result = sapplyMgr.getSettleMargin(firmID, money, ObjectID, flowType);
			} else {
				result = sapplyMgr.getSettleMarginForPreSale(firmID, money, ObjectID, flowType);
			}
			break;
		case 8:
			if (creditType == 0) {
				result = sapplyMgr.backSettleMargin(firmID, money, ObjectID, flowType);
			} else {
				result = sapplyMgr.backSettleMarginForPreSale(firmID, money, ObjectID, flowType);
			}
			break;
		default:
			break;
		}

		if (result < 0) {
			sapplyMgr.rollback();
			voucheMgr.rollback();
			return false;
		} else {
			return true;
		}
	}

	/**
	 * 实体资金收取或退还
	 * 
	 * @param voucherModelID
	 * @param money
	 * @param contractno
	 * @param firmID
	 * @param note
	 * @param inputUser
	 * @return
	 */
	private boolean Realpay(String voucherModelID, BigDecimal money, String contractno, String firmID, String note,
			String inputUser) {
		if (money.compareTo(BigDecimal.ZERO) == 0) {
			return true;
		}

		int result = voucheMgr.createNewOldVoucher(voucherModelID, money, contractno, firmID, note, inputUser);
		if (result < 0) {
			sapplyMgr.rollback();
			voucheMgr.rollback();
			return false;
		} else {
			return true;
		}
	}

	/**
	 * 报盘交易商资金校验
	 */
	@Override
	public boolean chkFirmFundsForLeads(Long leadsId) {
		return true;
	}

	/**
	 * 询盘交易商资金校验
	 */
	@Override
	public boolean chkFirmFundsForEnquiry(Long EnquiryId) {
		return true;
	}

	/**
	 * 成交时交易商资金校验
	 */
	@Override
	public boolean chkFirmFundsForOrder(String orderID) {
		return true;
	}

	/**
	 * 交收时交易商资金校验
	 */
	@Override
	public boolean chkFirmFundsForDelivery(String deliveryId) {
		return true;
	}

	@Override
	public TLeads getLeadsById(Long id) {
		return this.dao.getLeadsById(id);
	}

	@Override
	public TEnquiry getEnquiryById(Long id) {
		return this.dao.getEnquiryById(id);
	}

	@Override
	public TOrder getOrderById(String id) {
		return this.dao.getOrderById(id);
	}

	@Override
	public boolean backAllLeadsAndEnquiry() {
		List<TEnquiry> tEnquiryList = this.dao.getAllCanBackEnquiry();
		List<TLeads> tLeadsList = this.dao.getAllCanBackLeads();

		for (int i = 0; i < tEnquiryList.size(); i++) {

			if (!this.backByEnquiryID(tEnquiryList.get(i).getEnquiryId())) {
				return false;
			}
		}

		for (int i = 0; i < tLeadsList.size(); i++) {

			if (!this.backByLeadsID(tLeadsList.get(i).getID())) {
				return false;
			}
		}

		this.dao.updateAllCanBackLeads();

		return true;
	}
	
	/**
	 * 中石化自动撤盘(超过12点)
	 */
	@Override
	public boolean backAllSinopecLeadsAndEnquiry() {
		this.log.info(this.getClass().getName()+" backAllSinopecLeadsAndEnquiry Component Start");
		List<TEnquiry> tEnquiryList = this.dao.getAllSinopecCanBackEnquiry();
		List<TLeads> tLeadsList = this.dao.getAllSinopecCanBackLeads();

		for (int i = 0; i < tEnquiryList.size(); i++) {

			if (!this.backByEnquiryID(tEnquiryList.get(i).getEnquiryId())) {
				return false;
			}
		}

		for (int i = 0; i < tLeadsList.size(); i++) {

			if (!this.backByLeadsID(tLeadsList.get(i).getID())) {
				return false;
			}
		}

		this.dao.updateAllSinopecLeadsAndEnquiry();
		
		this.log.info(this.getClass().getName()+" backAllSinopecLeadsAndEnquiry Component Start");
		return true;
	}

	@Override
	public int getCanBackCount() {
		List<TEnquiry> tEnquiryList = this.dao.getAllCanBackEnquiry();
		List<TLeads> tLeadsList = this.firmBanlanceDAO_read.getAllCanBackLeads();

		return tEnquiryList.size() + tLeadsList.size();
	}

	@Override
	public int modifyLeads(Long leadsId) {
		getBeans();
		TLeads tLeads = this.dao.getLeadsById(leadsId);
		String firmID = tLeads.getFirmID();
		// 授信类型，0：现货 1：预售
		int goodsType = Common.getGoodsType(tLeads.getTradeType());

		// 交易商可用资金,可用授信资金取得
		BigDecimal[] firmBalances = this.getMoneys(firmID);

		// 授信金额从哪个账户扣除的判断(授信or远期授信)
		BigDecimal credit = null;
		if (goodsType == 0) {
			credit = firmBalances[1];
		} else if (goodsType == 1) {
			credit = firmBalances[2];
		} else {
			return -2;
		}

		FeeModel feeModel = this.dao.getFeeModel(11, leadsId.toString(), firmBalances[0], credit, 0, BigDecimal.ZERO, 0);

		if (feeModel.getReturnCode() == -1) {
			this.log.debug("getFeeModel(11),资金余额不足 leadsId = " + leadsId);
			sapplyMgr.rollback();
			voucheMgr.rollback();
			return -1;
		}

		FeeModel feeModelTmp = new FeeModel();
		feeModelTmp.setTakenTradeFee(BigDecimal.ZERO);
		feeModelTmp.setTakenTradeDeposit(feeModel.getTakenTradeDeposit().abs());
		feeModelTmp.setCreditFee(BigDecimal.ZERO);
		feeModelTmp.setCreditDeposit(BigDecimal.ZERO);
		if (feeModel.getTakenTradeDeposit().compareTo(BigDecimal.ZERO) == -1) {
			if (!backFeeAndDeposit(tLeads.getLeadsCode(), 2, firmID, feeModelTmp, "修改报盘时退卖家", goodsType)) {
				return -2;
			}
		} else if (feeModel.getTakenTradeDeposit().compareTo(BigDecimal.ZERO) == 1) {
			if (!getFeeAndDeposit(tLeads.getLeadsCode(), 2, firmID, feeModelTmp, "修改报盘时收卖家", goodsType)) {
				return -2;
			}
		}

		feeModelTmp = new FeeModel();
		feeModelTmp.setTakenTradeFee(BigDecimal.ZERO);
		feeModelTmp.setTakenTradeDeposit(BigDecimal.ZERO);
		feeModelTmp.setCreditFee(BigDecimal.ZERO);
		feeModelTmp.setCreditDeposit(feeModel.getCreditDeposit().abs());
		if (feeModel.getCreditDeposit().compareTo(BigDecimal.ZERO) == -1) {
			if (!backFeeAndDeposit(tLeads.getLeadsCode(), 2, firmID, feeModelTmp, "修改报盘时退卖家", goodsType)) {
				return -2;
			}
		} else if (feeModel.getCreditDeposit().compareTo(BigDecimal.ZERO) == 1) {
			if (!getFeeAndDeposit(tLeads.getLeadsCode(), 2, firmID, feeModelTmp, "修改报盘时收卖家", goodsType)) {
				return -2;
			}
		}
		return 0;
	}

	@Override
	public int payForCouPon(String firmId, BigDecimal couponAmount, String contractno, String inputUser) {
		getBeans();
		log.debug("FirmBanlanceManagerImpl.payForCouPon()开始");
		int result = voucheMgr.createNewOldVoucher(Constants.VOUCHERMODE_COUPON_FEE, couponAmount, contractno, firmId,
				"买抵扣型优惠券扣费", inputUser);
		log.debug("FirmBanlanceManagerImpl.payForCouPon() result = " + result);
		return result; 
	}

	@Override
	public int addDepositBuyer(String orderID) {
		getBeans();

		TOrder tOrder = this.dao.getOrderById(orderID);
		String buyFirmId = tOrder.getBuyFirmId();
		TLeads tLeads = this.dao.getLeadsById(tOrder.getLeadsID());
		// 授信类型，0：现货 1：预售
		int goodsType = Common.getGoodsType(tLeads.getTradeType());

		// 买家交易商可用资金,可用授信资金取得
		BigDecimal[] firmBalances = this.getMoneys(buyFirmId);

		// 授信金额从哪个账户扣除的判断(授信or远期授信)
		BigDecimal credit = null;
		if (goodsType == 0) {
			credit = firmBalances[1];
		} else if (goodsType == 1) {
			credit = firmBalances[2];
		} else {
			return -2;
		}

		// 买家 补交保证金
		FeeModel feeModel = this.dao.getFeeModel(12, orderID, firmBalances[0], credit, 0, BigDecimal.ZERO, 1);
		if (feeModel.getReturnCode() == -1) {
			this.log.debug("getFeeModel(12),资金余额不足 orderID = " + orderID);
			sapplyMgr.rollback();
			voucheMgr.rollback();
			return -1;
		}

		// 加（减）保证金实体资金额
		FeeModel feeModelTmp = new FeeModel();
		feeModelTmp.setTakenTradeFee(BigDecimal.ZERO);
		feeModelTmp.setTakenTradeDeposit(feeModel.getBuyTakenDeposit().abs());
		feeModelTmp.setCreditFee(BigDecimal.ZERO);
		feeModelTmp.setCreditDeposit(BigDecimal.ZERO);
		if (feeModel.getBuyTakenDeposit().compareTo(BigDecimal.ZERO) == -1) {
			if (!backFeeAndDeposit(orderID, 1, buyFirmId, feeModelTmp, "退买家", goodsType)) {
				return -2;
			}
		} else if (feeModel.getBuyTakenDeposit().compareTo(BigDecimal.ZERO) == 1) {
			if (!getFeeAndDeposit(orderID, 1, buyFirmId, feeModelTmp, "收买家", goodsType)) {
				return -2;
			}
		}

		// 加（减）保证金授信额
		feeModelTmp = new FeeModel();
		feeModelTmp.setTakenTradeFee(BigDecimal.ZERO);
		feeModelTmp.setTakenTradeDeposit(BigDecimal.ZERO);
		feeModelTmp.setCreditFee(BigDecimal.ZERO);
		feeModelTmp.setCreditDeposit(feeModel.getBuyCreditDeposit().abs());
		if (feeModel.getBuyCreditDeposit().compareTo(BigDecimal.ZERO) == -1) {
			if (!backFeeAndDeposit(orderID, 1, buyFirmId, feeModelTmp, "退买家", goodsType)) {
				return -2;
			}
		} else if (feeModel.getBuyCreditDeposit().compareTo(BigDecimal.ZERO) == 1) {
			if (!getFeeAndDeposit(orderID, 1, buyFirmId, feeModelTmp, "收买家", goodsType)) {
				return -2;
			}
		}
		return 0;
	}
	
	@Override
	public int addDepositSeller(String orderID) {
		getBeans();

		TOrder tOrder = this.dao.getOrderById(orderID);
		String sellFirmId = tOrder.getSellFirmId();
		TLeads tLeads = this.dao.getLeadsById(tOrder.getLeadsID());
		// 授信类型，0：现货 1：预售
		int goodsType = Common.getGoodsType(tLeads.getTradeType());

		// 卖家交易商可用资金,可用授信资金取得
		BigDecimal[] firmBalances = this.getMoneys(sellFirmId);

		// 授信金额从哪个账户扣除的判断(授信or远期授信)
		BigDecimal credit = null;
		if (goodsType == 0) {
			credit = firmBalances[1];
		} else if (goodsType == 1) {
			credit = firmBalances[2];
		} else {
			return -2;
		}

		// 卖家 补交保证金
		FeeModel feeModel = this.dao.getFeeModel(12, orderID, firmBalances[0], credit, 0, BigDecimal.ZERO, 0);
		if (feeModel.getReturnCode() == -1) {
			this.log.debug("getFeeModel(12),资金余额不足 orderID = " + orderID);
			sapplyMgr.rollback();
			voucheMgr.rollback();
			return -1;
		}

		// 加（减）保证金实体资金额
		FeeModel feeModelTmp = new FeeModel();
		feeModelTmp.setTakenTradeFee(BigDecimal.ZERO);
		feeModelTmp.setTakenTradeDeposit(feeModel.getBuyTakenDeposit().abs());
		feeModelTmp.setCreditFee(BigDecimal.ZERO);
		feeModelTmp.setCreditDeposit(BigDecimal.ZERO);
		if (feeModel.getBuyTakenDeposit().compareTo(BigDecimal.ZERO) == -1) {
			if (!backFeeAndDeposit(orderID, 1, sellFirmId, feeModelTmp, "退卖家", goodsType)) {
				return -2;
			}
		} else if (feeModel.getBuyTakenDeposit().compareTo(BigDecimal.ZERO) == 1) {
			if (!getFeeAndDeposit(orderID, 1, sellFirmId, feeModelTmp, "收卖家", goodsType)) {
				return -2;
			}
		}

		// 加（减）保证金授信额
		feeModelTmp = new FeeModel();
		feeModelTmp.setTakenTradeFee(BigDecimal.ZERO);
		feeModelTmp.setTakenTradeDeposit(BigDecimal.ZERO);
		feeModelTmp.setCreditFee(BigDecimal.ZERO);
		feeModelTmp.setCreditDeposit(feeModel.getBuyCreditDeposit().abs());
		if (feeModel.getBuyCreditDeposit().compareTo(BigDecimal.ZERO) == -1) {
			if (!backFeeAndDeposit(orderID, 1, sellFirmId, feeModelTmp, "退卖家", goodsType)) {
				return -2;
			}
		} else if (feeModel.getBuyCreditDeposit().compareTo(BigDecimal.ZERO) == 1) {
			if (!getFeeAndDeposit(orderID, 1, sellFirmId, feeModelTmp, "收卖家", goodsType)) {
				return -2;
			}
		}
		return 0;
	}
	
	private BigDecimal[] getShouldIns(CancelDetail dto){
		//应收资金合计
		BigDecimal totalFund_SIn = dto.getReceivableAmount().add(dto.getReceivableFreight().add(dto.getReceivableTradeFeeFunds()));
		//应收授信合计
		BigDecimal totalCredit_SIn = dto.getReceivableTradeFeeCredit();
		//应收手续费账户资金合计
		BigDecimal totalFeeAccount_SIn = dto.getReceivableTradeFeeAccountFunds();
		
		//已收资金合计
		BigDecimal totalFund_AIn = dto.getReceivedAmount().add(dto.getReceivedFreight().add(dto.getReceivedTradeFeeFunds()));
		//已收授信合计
		BigDecimal totalCredit_AIn = dto.getReceivedTradeFeeCredit();
		//已收手续费账户资金合计
		BigDecimal totalFeeAccount_AIn = dto.getReceivedTradeFeeAccountFunds();
		
		//应付资金合计
		BigDecimal totalFund_SOut = dto.getPayAmount().add(dto.getPayFreight().add(dto.getPayTradeFeeFunds().add(dto.getPayTradeDepositFunds())));
		//应付授信合计
		BigDecimal totalCredit_SOut = dto.getPayTradeFeeCredit().add(dto.getPayTradeDepositCredit());
		//应付手续费账户资金合计
		BigDecimal totalFeeAccount_SOut = dto.getPayTradeFeeAccountFunds();
		
		//已付资金合计
		BigDecimal totalFund_AOut = dto.getPaidAmount().add(dto.getPaidFreight().add(dto.getPaidTradeFeeFunds().add(dto.getPaidTradeDepositFunds())));
		//已付授信合计
		BigDecimal totalCredit_AOut = dto.getPaidTradeFeeCredit().add(dto.getPaidTradeDepositCredit());
		//已付手续费账户资金合计
		BigDecimal totalFeeAccount_AOut = dto.getPaidTradeFeeAccountFunds();
		
		
		//资金取差值
		BigDecimal shouldInFund = (totalFund_SIn.subtract(totalFund_AIn)).subtract((totalFund_SOut.subtract(totalFund_AOut)));
		
		//授信取差值
		BigDecimal shouldInCredit = (totalCredit_SIn.subtract(totalCredit_AIn)).subtract((totalCredit_SOut.subtract(totalCredit_AOut)));
		
		//手续费账户取差值
		BigDecimal shouldInFeeAccount = (totalFeeAccount_SIn.subtract(totalFeeAccount_AIn)).subtract((totalFeeAccount_SOut.subtract(totalFeeAccount_AOut)));
		
		BigDecimal[] shouldIns = new BigDecimal[3];
		shouldIns[0] = shouldInFund;
		shouldIns[1] = shouldInCredit;
		shouldIns[2] = shouldInFeeAccount;
		
		return shouldIns;
	}
	
	private int payShouldIns(BigDecimal[] shouldIns, CancelDetail dto) {
		// 应收资金(为负值则是应付)
		BigDecimal shouldInFund = shouldIns[0];
		// 应收授信(为负值则是应付)
		BigDecimal shouldInCredit = shouldIns[1];
		// 应收手续费账户(为负值则是应付)
		BigDecimal shouldInFeeAccount = shouldIns[2];

		int result;
		if (shouldInFund.compareTo(BigDecimal.ZERO) > 0) {
			result = voucheMgr.createNewOldVoucher(Constants.VOUCHERMODE_SHOU_JIEYUE, shouldInFund,
					dto.getDeliveryID(), dto.getFirmID(), "解约收资金", "system");
		} else if (shouldInFund.compareTo(BigDecimal.ZERO) == 0) {
			result = 0;
		} else {
			result = voucheMgr.createNewOldVoucher(Constants.VOUCHERMODE_FU_JIEYUE, shouldInFund.abs(),
					dto.getDeliveryID(), dto.getFirmID(), "解约退资金", "system");
		}
		if (result < 0) {
			sapplyMgr.rollback();
			voucheMgr.rollback();
			// 余额不足
			if (result == -4 || result == -8) {
				return -1;
			} else {
				// 支付失败
				return -2;
			}
		}

		if (shouldInCredit.compareTo(BigDecimal.ZERO) > 0) {
			if (dto.getTradeType() == 0) {
				result = sapplyMgr.getMargin(dto.getFirmID(), shouldInCredit, dto.getDeliveryID(), 5);
			} else {
				result = sapplyMgr.getMarginForPreSale(dto.getFirmID(), shouldInCredit, dto.getDeliveryID(), 5);
			}
		} else if (shouldInCredit.compareTo(BigDecimal.ZERO) == 0) {
			result = 0;
		} else {
			if (dto.getTradeType() == 0) {
				result = sapplyMgr.backMargin(dto.getFirmID(), shouldInCredit.abs(), dto.getDeliveryID(), 5);
			} else {
				result = sapplyMgr.backMarginForPreSale(dto.getFirmID(), shouldInCredit.abs(), dto.getDeliveryID(), 5);
			}
		}
		if (result < 0) {
			sapplyMgr.rollback();
			voucheMgr.rollback();
			// 余额不足
			if (result == -2) {
				return -3;
			} else {
				// 支付失败
				return -4;
			}
		}

		if (shouldInFeeAccount.compareTo(BigDecimal.ZERO) > 0) {
			result = this.couonMgr.operationCoupon(dto.getFirmID(), shouldInFeeAccount, "802", dto.getDeliveryID(), 5,
					1, "system");
		} else if (shouldInFeeAccount.compareTo(BigDecimal.ZERO) == 0) {
			result = 0;
		} else {
			result = this.couonMgr.operationCoupon(dto.getFirmID(), shouldInFeeAccount.abs(), "801",
					dto.getDeliveryID(), 5, 0, "system");
		}
		if (result < 0) {
			sapplyMgr.rollback();
			voucheMgr.rollback();
			// 余额不足
			if (result == -2) {
				return -5;
			} else {
				// 支付失败
				return -6;
			}
		}

		return result;
	}
	
	@Override
	public int payForCancel(String ApplyID, String userId) {
		getBeans();

		List<CancelDetail> detList = this.dao.getCancelDetail(ApplyID);

		if (detList.size() != 1 && detList.size() != 2) {
			this.log.error("payForCancel支付明细件数不正确! ApplyID = " + ApplyID);
			// 支付明细件数不正确
			return -99;
		} else if (detList.size() == 1) {
			this.log.debug("payForCancel支付明细件数 = 1 ApplyID = " + ApplyID);
			BigDecimal[] shouldIns = getShouldIns(detList.get(0));
			int result = payShouldIns(shouldIns, detList.get(0));
			if (result < 0) {
				if (result == -1 || result == -2) {
					this.dao.updateCancelMoneyFailed(detList.get(0).getKeyID(), userId);
				} else {
					this.dao.updateCancelMoneySuccessHalf(detList.get(0).getKeyID(), userId);
				}
				this.log.error("payForCancel支付失败!明细件数 = 1 ,KeyID =" + detList.get(0).getKeyID() + ", result = " + result);
				return result;
			} else {
				this.dao.updateCancelMoneySuccess(detList.get(0).getKeyID(), userId);
			}
		} else {
			this.log.debug("payForCancel支付明细件数 = 2 ApplyID = " + ApplyID);
			BigDecimal[] shouldIns0 = getShouldIns(detList.get(0));
			int result0 = payShouldIns(shouldIns0, detList.get(0));
			if (result0 < 0) {
				if (result0 == -1 || result0 == -2) {
					this.dao.updateCancelMoneyFailed(detList.get(0).getKeyID(), userId);
				} else {
					this.dao.updateCancelMoneySuccessHalf(detList.get(0).getKeyID(), userId);
				}
				this.log.error("payForCancel支付失败!明细件数 = 2的第1件 ,KeyID =" + detList.get(0).getKeyID() + ", result = " + result0);
				return result0;
			} else {
				BigDecimal[] shouldIns1 = getShouldIns(detList.get(1));
				int result1 = payShouldIns(shouldIns1, detList.get(1));
				if (result1 < 0) {
					if (result1 == -1 || result1 == -2) {
						this.dao.updateCancelMoneyFailed(detList.get(1).getKeyID(), userId);
					} else {
						this.dao.updateCancelMoneySuccessHalf(detList.get(1).getKeyID(), userId);
					}
					this.dao.updateCancelMoneySuccessHalf(detList.get(0).getKeyID(), userId);
					this.log.error("payForCancel支付失败!明细件数 = 2的第2件 ,KeyID =" + detList.get(1).getKeyID() + ", result = " + result1);
					return result1;
				} else {
					this.dao.updateCancelMoneySuccess(detList.get(0).getKeyID(), userId);
					this.dao.updateCancelMoneySuccess(detList.get(1).getKeyID(), userId);
				}
			}
		}

		return 0;
	}
	
	/*
	 * 以下为期现的撤盘业务
	 */
	/**
	 * 撤销询盘前检查询盘状态, 成功锁数据, 失败返回
	 * 
	 * @param differ: 1|后台释放询盘; 2|Job撤询盘
	 * @param enqId: differ为0，1场合的询盘ID
	 */
	@Override
	public List<TEnquiry> preBackQXEnquiry(int differ, int enqId) throws Exception {
		
		log.debug(" IFirmBanlanceManager.preBackQXEnquiry Start");
		
		List<TEnquiry> enqLst = this.firmBanlanceDAO_read.getCancelEnquiryLst(differ, enqId);
		
		if (enqLst == null || enqLst.size() == 0) {
			log.debug(" IFirmBanlanceManager.preBackQXEnquiry 没有可以撤销的询盘。");
		} else {
			log.debug(" IFirmBanlanceManager.preBackQXEnquiry 可以撤销的询盘数:" + enqLst.size());
			this.dao.preCancelEnquiryLst(differ, enqId);
		}

		log.debug(" IFirmBanlanceManager.preBackQXEnquiry End");
		return enqLst;
	}
	
	/**
	 * 撤销挂盘前检查挂盘状态, 成功锁数据, 失败返回
	 * 
	 * @param differ: 0|前台撤挂盘 ; 2|Job撤挂盘
	 * @param enqId: differ为0，1场合的挂盘ID
	 */
	@Override
	public List<TLeads> preBackQXLead(int differ, int leadId) throws Exception {
		
		log.debug(" IFirmBanlanceManager.preBackQXLead Start");

		List<TLeads> leadLst = this.firmBanlanceDAO_read.getCancelLeadLst(differ, leadId);
		
		if (leadLst == null || leadLst.size() == 0) {
			log.debug(" IFirmBanlanceManager.preBackQXLead 没有可以撤销的挂盘。");
		} else {
			log.debug(" IFirmBanlanceManager.preBackQXLead 可以撤销的挂盘数:" + leadLst.size());
			this.dao.preCancelLeadLst(differ, leadId);
		}
		
		log.debug(" IFirmBanlanceManager.preBackQXLead End");
		return leadLst;
	}
	
	/**
	 * 撤销询盘
	 * 
	 * @param differ: 1|后台释放询盘; 2|Job撤询盘
	 * @param enquiry: 需要撤的询盘
	 */
	@Override
	public void backQXEnquiry(int differ, TEnquiry enquiry) throws Exception {
		
		log.debug(" IFirmBanlanceManager.backQXEnquiry Start");

		getBeans();
		String firmID = enquiry.getFirmId();
		TLeads tLeads = this.dao.getLeadsById(enquiry.getLeadsID());
		// 授信类型，0：现货 1：预售
		int goodsType = Common.getGoodsType(tLeads.getTradeType());

		// 后台释放询盘/Job失效询盘
		FeeModel feeModel = this.dao.getFeeModel(13, enquiry.getEnquiryId().toString(), null, null, 0, BigDecimal.ZERO, 0);
		
		if (feeModel.getReturnCode().intValue() == -1) {
			log.debug(" IFirmBanlanceManager.backQXEnquiry 撤销询盘时计算退回保证金失败。");
			throw new Exception("撤销询盘时计算退回保证金失败。");
		}
		
		boolean backMoneyResult =  backFeeAndDeposit(enquiry.getEnquiryCode(), 4, firmID, feeModel, "询盘撤单时退", goodsType);
		
		if (!backMoneyResult) {
			log.debug(" IFirmBanlanceManager.backQXEnquiry 撤销询盘时退回保证金发生错误。");
			throw new Exception("撤销询盘时退回保证金发生错误。");
		}
		
		log.debug(" IFirmBanlanceManager.backQXEnquiry End");
	}
	
	/**
	 * 撤销挂盘
	 * 
	 * @param differ: 0|前台撤挂盘 ; 2|Job撤挂盘
	 * @param lead: 需要撤的挂盘
	 */
	@Override
	public void backQXLead(int differ, TLeads lead) throws Exception {
		
		log.debug(" IFirmBanlanceManager.backQXLead Start");

		getBeans();
		
		TLeads newLeads = this.dao.getLeadsById(lead.getID());
		
		String firmID = lead.getFirmID();
		// 授信类型，0：现货 1：预售
		int goodsType = Common.getGoodsType(newLeads.getTradeType());

		// 挂盘撤盘 退交易保证金
		FeeModel feeModel = null;
		
		if (Constants.BACK_FRONT == differ) {
			// 前台撤销挂盘
			feeModel = this.dao.getFeeModel(14, lead.getID().toString(), null, null, 0, BigDecimal.ZERO, 0);
		} else {
			// Job失效挂盘
			feeModel = this.dao.getFeeModel(15, lead.getID().toString(), null, null, 0, BigDecimal.ZERO, 0);
		}

		if (feeModel.getReturnCode().intValue() == -1) {
			log.debug(" IFirmBanlanceManager.backQXLead 撤销挂盘时计算退回保证金失败。");
			throw new Exception("撤销挂盘时计算退回保证金失败。");
		}
		
		boolean backMoneyResult = backFeeAndDeposit(lead.getLeadsCode(), 2, firmID, feeModel, "挂盘撤单时退", goodsType);
		
		if (!backMoneyResult) {
			log.debug(" IFirmBanlanceManager.backQXLead 撤销挂盘时退回保证金发生错误。");
			throw new Exception("撤销挂盘时退回保证金发生错误。");
		}

		log.debug(" IFirmBanlanceManager.backQXLead End");
	}
	
	/**
	 * 撤销询盘后释放数据
	 * 
	 * @param differ: 1|后台释放询盘; 2|Job撤询盘
	 * @param enquiry: 需要恢复的询盘
	 */
	@Override
	public void postBackQXEnquiry(int differ, TEnquiry enquiry) throws Exception {
		
		log.debug(" IFirmBanlanceManager.postBackQXEnquiry Start");

		// 需要恢复的询盘
		this.dao.postCancelEnquiryLst(differ, enquiry);

		log.debug(" IFirmBanlanceManager.postBackQXEnquiry End");
	}
	
	/**
	 * 撤销挂盘后释放数据
	 * 
	 * @param differ: 0|前台撤挂盘 ; 2|Job撤挂盘
	 * @param lead: 需要恢复的挂盘
	 */
	@Override
	public void postBackQXLead(int differ, TLeads lead) throws Exception {
		
		log.debug(" IFirmBanlanceManager.postBackQXLead Start");

		// 需要恢复的挂盘
		this.dao.postCancelLeadLst(differ, lead);

		log.debug(" IFirmBanlanceManager.postBackQXLead End");
	}
	
	/**
	 * 查询出金申请列表
	 */
	@Override
	public List<FirmBanlanceList> queryOutMoneyList(QueryConditions qc, PageInfo pageInfo) {
		return this.firmBanlanceDAO_read.queryOutMoneyList(qc, pageInfo);
	}

	@Override
	public void insertOutMoneyApply(FBOutMoneyApply applyModel) {
		log.debug(" IFirmBanlanceManager.insertOutMoneyApply Start");

		// 出金申请
		this.dao.insertOutMoneyApply(applyModel);

		log.debug(" IFirmBanlanceManager.insertOutMoneyApply End");

	}

	@Override
	public int updateOutMoneyApply(Integer id, Integer fromStatus, Integer toStatus, String auditor, String note) {

		return this.dao.updateOutMoneyApply(id, fromStatus, toStatus, auditor, note);
	}

	@Override
	public List<FBOutMoneyApply> getOutMoneyApplyList(QueryConditions qc, PageInfo pageInfo) {
		return this.firmBanlanceDAO_read.getOutMoneyApplyList(qc, pageInfo);

	}

}
