package shcem.finance.service;

/**
 * 发票相关
 * @author wangshuai
 *
 */
public interface IInvoiceService {
	/**
	 * 开票管理列表数据
	 * @param params
	 * @return
	 */
	public String getFinancialBillsList(String params);
	
	/**
	 * 交易商收票地址
	 * @param params
	 * @return
	 */
	public String getfirmInvoicePlaceList(String params);
	/**
	 * 打开开票申请dialog
	 * @param params
	 * @return
	 */
	public String openInvoiceApplyForm(String params);
	/**
	 * 开票申请
	 * @param params
	 * @return
	 */
	public String addInvoiceApply(String params);
	/**
	 * 开票申请流水列表
	 * @param params
	 * @return
	 */
	public String getInvoiceApplyList(String params);
	/**
	 * 发票撤销
	 * @param params
	 * @return
	 */
	public String cancelInvoiceApply(String params);
	
	/**
	 * 校验经税系统生成的Excel
	 * @param params
	 * @return
	 */
	public String checkImportInvoiceExcel(String params);
	/**
	 * 导入发票
	 * @param params
	 * @return
	 */
	public String importInvoiceExcel(String params);
	/**
	 * 导出开票申请流水，供票据系统开票使用
	 * @param params
	 * @return
	 */
	public String exportInvoiceApply(String params);
	
	
	/**
	 * 新增收票记录
	 * @param invoiceCollectDetail
	 * @return
	 */
	public String addInvoiceCollectDetail(String params);
	
	/**
	 * 更新收票记录
	 * @param invoiceCollectDetail
	 * @return
	 */
	public String updateInvoiceCollectDetailByID(String params);
	
	/**
	 * 更新收票记录的状态
	 * @param id 收票关联表ID
	 * @param status 收票关联表状态  1：正常 , 5：失效
	 * @param modifyBy 修改人
	 * @return
	 */
	public String updateInvoiceCollectDetailRelOfStatus(String params);
	
	/**
	 * 获取收票记录信息
	 * @return
	 */
	public String getInvoiceCollectDetailByID(String params);
	
	/**
	 * 根据relationID 查询收票详细表列表
	 * @param relationID
	 * @return
	 */
	public String selectInvoiceCollectDetailListByRelationID(String params);
	
	
	/**
	 * 更新订单的收票状态（0：未收票  5：部分收票 10：全部收票）
	 * @return
	 */
	public String updateOrderOfInvoiceCollectStatus(String params);
	
	/**
	 * 查询开票管理的列表
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public String selectInvoiceOrderList(String params);
	
	/**
	 * 导出收票详情列表
	 * @return
	 */
	public String exportInvoiceCollectDetailList(String params);
	
	/**
	 * 开票流水作废
	 * @param params
	 * @return
	 */
	public String invalidInvoiceApply(String params);
	
	/**
	 * 开票申请，数据校验
	 * @param params
	 * @return
	 */
	public String checkInvoiceApply(String params);
	
	/**
	 * 开票，批量申请
	 * @param params
	 * @return
	 */
	public String addInvoiceApplyList(String params);
	
	/**
	 * 关闭/启用开票
	 * @param params
	 * @return
	 */
	public String disOrEnabled(String params);
	
	/**
	 * 开票详情
	 * @param params
	 * @return
	 */
	public String getInvoiceApplyDetail(String params);
	
	/** 
	 * 开票详情修改(未开票完成能修改)
	 * @param params
	 * @return
	 */
	public String updateInvoiceApplyDetail(String params);
	
	/**
	 * 开票申请的一些地址信息
	 * @param params
	 * @return
	 */
	public String getApplyAddress(String params);
	
	/**
	 * 增值性优惠券开票申请列表(前台客户申请)
	 * @param params
	 * @return
	 */
	public String getCouponInvoiceApplyListByCustomer(String params);
	
	/**
	 * 审核前台客户申请的开票信息(修改)
	 * @param params
	 * @return
	 */
	public String updateCouponInvoiceApplyListByCustomer(String params);
	
	/**
	 * 开启 审核前台客户申请的开票信息(置标)
	 * @param params
	 * @return
	 */
	public String openInvoice(String params);
	/**
	 * 关闭 审核前台客户申请的开票信息(置标)
	 * @param params
	 * @return
	 */
	public String CloseInvoice(String params);
	
	/**
	 * 审核前台客户申请的开票信息
	 * @param params
	 * @return
	 */
	public String updateCouponInvoiceApplyListByCustomerWithLotSize(String params);
}
