/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: BankMgrDAOImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.BankMgrDAO;
import shcem.finance.dao.model.FBanks;
import shcem.util.CommonRowMapper;

/**
 * BankMgrDAOImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class BankMgrDAOImpl extends BaseDAOImpl implements BankMgrDAO {

	/**
	 * 获取银行列表
	 * 
	 * 
	 */
	public List<FBanks> getBankList() {
		this.log.debug("getBankList DAO Start");
		String sql = sqlProperty.getProperty("BankDAO_001");
		Object[] params = new Object[] {};
		// return getJdbcTemplate().query(sql, params, new
		// BankRowMapper());//手动绑定，需自定义实现rowmapper接口。

		return queryBySQL(sql, params, null, new CommonRowMapper(new FBanks()));// 通用绑定模式，根据模型和数据结果集自动。
	}

	/***
	 * 获取交易商列表
	 * param :qc 查询条件
	 * param :pageInfo 分页条件
	 * @return 
	 */
	public List<FBanks> getBankList(QueryConditions qc, PageInfo pageInfo) {
		String sql = sqlProperty.getProperty("BankDAO_001");
		return queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new FBanks()));// 通用绑定模式，根据模型和数据结果集自动。
	}

	/**
	 * 获取接口银行详情
	 */
	public FBanks getBank(String bankId) {
		this.log.debug("getBank DAO Start");
		String sql = sqlProperty.getProperty("BankDAO_002");
		Object[] params = new Object[] { bankId };
		// return (FBanks) getJdbcTemplate().queryForObject(sql, params, new
		// BankRowMapper());

		return (FBanks) queryForObject(sql, params, new CommonRowMapper(new FBanks()));
	}

	/**
	 * ����������Ϣ
	 * 
	 * @return
	 */
	public int updateBank(FBanks bank) {
		String sql = sqlProperty.getProperty("BankDAO_003");
		Object[] params = { bank.getBankName(), bank.getBeginTime(), bank.getEndTime(), bank.getMaxPerSglTransMoney(),
				bank.getMaxPerTransMoney(), bank.getMaxPerTransCount(), bank.getMaxAuditMoney(), bank.getControl(),
				bank.getBankID() };
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		return getJdbcTemplate().update(sql, params);
	}

	/**
	 * ��������
	 */
	public int addBank(FBanks bank) {
		String sql = sqlProperty.getProperty("BankDAO_006");
		Object[] params = { bank.getBankID(), bank.getBankName(), bank.getBeginTime(), bank.getEndTime(),
				bank.getMaxPerSglTransMoney(), bank.getMaxPerTransMoney(), bank.getMaxPerTransCount(),
				bank.getMaxAuditMoney(), bank.getControl() };
		return getJdbcTemplate().update(sql, params);
	}

	/**
	 * �ظ����п���
	 */
	public int validBank(String bankId) {
		String sql = sqlProperty.getProperty("BankDAO_005");
		Object[] params = new Object[] { bankId };
		return getJdbcTemplate().update(sql, params);
	}

	/***
	 * ��������
	 */
	public int invalidBank(String bankId) {
		String sql = sqlProperty.getProperty("BankDAO_004");
		Object[] params = new Object[] { bankId };
		return getJdbcTemplate().update(sql, params);
	}

	class BankRowMapper implements RowMapper<FBanks> {
		BankRowMapper() {
		}

		public FBanks mapRow(ResultSet rs, int rowNum) throws SQLException {
			return rsToBank(rs);
		}

		private FBanks rsToBank(ResultSet rs) throws SQLException {
			FBanks bank = new FBanks();
			bank.setBankID(rs.getString("BankId"));
			bank.setBankName(rs.getString("bankName"));
			bank.setMaxPerSglTransMoney(rs.getBigDecimal("maxpersgltransmoney"));
			bank.setMaxPerTransCount(rs.getInt("maxpertranscount"));
			bank.setMaxPerTransMoney(rs.getBigDecimal("maxpertransmoney"));
			bank.setBeginTime(rs.getString("beginTime"));
			bank.setEndTime(rs.getString("endTime"));
			bank.setControl(rs.getInt("control"));
			bank.setValidFlag(rs.getInt("validFlag"));
			bank.setMaxAuditMoney(rs.getBigDecimal("maxAuditMoney"));
			return bank;
		}
	}

}
