/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: VoucherDAO
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
  * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao;

import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.model.FVoucher;
import shcem.finance.dao.model.VocherDataList;
import shcem.finance.dao.model.Voucher;
import shcem.finance.dao.model.VoucherAllData;
import shcem.finance.dao.model.VoucherModel;

/**
 * VoucherDAO
 * 
 * @author chiyong
 * @version 1.0
 */
public abstract interface VoucherDAO extends DAO {
	
	public abstract int createAndAuditVoucher(String summaryNo, String summary, String debitCode, String creditCode,
			String contractno, String inputUser, String money, String firmID);


	public abstract int createVoucherFast(String summaryNo, String summary, String debitCode, String creditCode,
			String contractno, String inputUser, String money, String firmID);

	public abstract void submitAllVoucherForAudit();

	public abstract void submitVoucherForAudit(Long voucherNo);

	public abstract FVoucher getVoucherByNo(Long voucherNo);

	public abstract void updateVoucherNotEntrys(FVoucher voucher);

	public abstract int auditVoucher(Long voucherNo, boolean isPass);

	public abstract List<VocherDataList> getAllVoucherList(QueryConditions qc,
			PageInfo pageInfo);

	public abstract List<VocherDataList> getEditingVoucherList(
			QueryConditions qc, PageInfo pageInfo);

	public abstract List<VocherDataList> getAuditingVoucherList(
			QueryConditions qc, PageInfo pageInfo);

	public abstract VoucherAllData getVoucherByNos(Long vOUCHERNO);

	public abstract int deleteVoucher(String vOUCHERNOs);

	public abstract int deleteVouCherEntry(Long vOUCHERNO);

	public abstract int rejectAuditVoucher(Long voucherNo);

	public abstract VoucherModel getVoucherModelByCode(String voucherModelID);

	public abstract void updateVoucherNote(Voucher voucher);
	
	public abstract void rollBack();


	public abstract List<Voucher> getVoucherList(String vOUCHERNOs);
}
