/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: VoucherDAOImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.impl;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.CallableStatementCallback;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.VoucherDAO;
import shcem.finance.dao.model.FVoucher;
import shcem.finance.dao.model.FVoucherEntry;
import shcem.finance.dao.model.VocherDataList;
import shcem.finance.dao.model.Voucher;
import shcem.finance.dao.model.VoucherAllData;
import shcem.finance.dao.model.VoucherModel;
import shcem.util.Common;
import shcem.util.CommonRowMapper;

/**
 * VoucherDAOImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class VoucherDAOImpl extends BaseDAOImpl implements VoucherDAO {

	private String createAndAuditVoucherByPrco(final String summaryNo, final String summary,
			final String debitCode, final String creditCode, final BigDecimal amount,
			final String contractno, final String inputUser, final String firmID,final int paraType,final int i) {
		
		this.log.debug("createAndAuditVoucherByPrco DAO Start");
		
		String result;
		String procedure = "{?=call Proc_FN_F_CreateAndAuditVoucher(?,?,?,?,?,?,?,?,?,?)}"; 
		try{  
			result = (String) this.getJdbcTemplate().execute(procedure, new CallableStatementCallback(){  
                public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {  
                	cs.registerOutParameter(1,Types.INTEGER); //输出参数类型  
                	cs.setString(2, summaryNo);
                	cs.setString(3, summary);
                	cs.setString(4, debitCode);
                	cs.setString(5, creditCode);
                	cs.setBigDecimal(6, amount);
                	cs.setString(7, contractno);
                	cs.setString(8, inputUser);
                	cs.setString(9, firmID);
                	cs.setInt(10, paraType);
                	cs.registerOutParameter(11, Types.VARCHAR);
                	cs.execute();
                	return cs.getObject(11);
                }  
            });  
        }catch(Exception e){  
        	this.log.debug("createAndAuditVoucherByPrco DAO error:" + e.getMessage());
            e.printStackTrace();  
            result = "-1:Exception发生！";
        }  
		
		this.log.debug("createAndAuditVoucherByPrco DAO End");
		return result;
	}

	
	/**
	 * 快捷录入生成凭证
	 */
	public int createAndAuditVoucher(String summaryNo, String summary, String debitCode, String creditCode,
			String contractno, String inputUser, String money, String firmID) {
		this.log.debug("createAndAuditVoucher DAO Start");

		int result = 0;
		BigDecimal amount = new BigDecimal(0);
		try {
			amount = new BigDecimal(money);
		} catch (Exception e) {
			this.log.debug("createAndAuditVoucher DAO error:" + e.getMessage());
			result = -1;
		}

		if (result == 0) {
			String ret = this.createAndAuditVoucherByPrco(summaryNo, summary, debitCode, creditCode, amount, contractno,
					inputUser, firmID, 1, 1);
			if(!Common.isEmpty(ret)){
				result = Integer.parseInt(ret.split(":")[0]);
			}
		}

		this.log.debug("createAndAuditVoucher DAO End");
		return result;
	}

	
	/**
	 * 快捷录入生成凭证
	 */
	public int createVoucherFast(String summaryNo, String summary, String debitCode, String creditCode,
			String contractno, String inputUser, String money, String firmID) {
		this.log.debug("createVoucherFast DAO Start");

		int result = 0;
		BigDecimal amount = new BigDecimal(0);
		try {
			amount = new BigDecimal(money);
		} catch (Exception e) {
			this.log.debug("createVoucherFast DAO error:" + e.getMessage());
			result = -1;
		}

//		if (contractno != null) {
//			contractno = "'" + contractno + "'";
//		}

		if (result == 0) {
//			result = callStoredProcedure("Proc_FN_F_CreateVoucher('" + summaryNo + "','" + summary + "','" + debitCode
//					+ "','" + creditCode + "'," + amount + "," + contractno + ",'" + inputUser + "','" + firmID+"','" + 1 + "','')");
			String ret = this.createVoucherFastByPrco(summaryNo,summary,debitCode,creditCode,amount,contractno,inputUser,firmID,1,1);
			result = Integer.parseInt(ret);
			// 2016.08.10 wangshuai start 根据需求【制单两次确认，取消确认功能】添加以下代码
			// 提交审核
			this.submitVoucherForAudit(Long.parseLong(ret));
			// 2016.08.10 wangshuai end
		}
		
		this.log.debug("createVoucherFast DAO End");
		return result;
	}

	private String createVoucherFastByPrco(final String summaryNo, final String summary,
			final String debitCode, final String creditCode, final BigDecimal amount,
			final String contractno, final String inputUser, final String firmID,final int paraType,final int i) {
		
		this.log.debug("createVoucherFastByPrco DAO Start");
		
		String result;
		String procedure = "{?=call Proc_FN_F_CreateVoucher(?,?,?,?,?,?,?,?,?,?)}"; 
		try{  
			result = (String) this.getJdbcTemplate().execute(procedure, new CallableStatementCallback(){  
                public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {  
                	cs.registerOutParameter(1,Types.INTEGER); //输出参数类型  
                	cs.setString(2, summaryNo);
                	cs.setString(3, summary);
                	cs.setString(4, debitCode);
                	cs.setString(5, creditCode);
                	cs.setBigDecimal(6, amount);
                	cs.setString(7, contractno);
                	cs.setString(8, inputUser);
                	cs.setString(9, firmID);
                	cs.setInt(10, paraType);
                	cs.setInt(11, i);
                	cs.execute();
                	return cs.getString(1);
                }  
            });  
        }catch(Exception e){  
        	this.log.debug("createVoucherFastByPrco DAO error:" + e.getMessage());
            e.printStackTrace();  
            result = "-1";
        }  
		
		this.log.debug("createVoucherFastByPrco DAO End");
		return result;
	}

	/**
	 * 全部提交审核
	 */
	public void submitAllVoucherForAudit() {
		this.log.debug("submitAllVoucherForAudit DAO Start");
		String sql = "update f_Voucher set status='1' where status='0'";
		updateBySQL(sql);
	}

	/**
	 * 提交审核
	 */
	public void submitVoucherForAudit(Long voucherNo) {
		this.log.debug("submitVoucherForAudit DAO Start");
		if (voucherNo == null)
			return;
		String sql = "update f_Voucher set status='1' where voucherNo= ? and status='0'";
		Object[] params = new Object[] { voucherNo };
		updateBySQL(sql, params);
	}

	/**
	 * 取得凭证信息
	 */
	public FVoucher getVoucherByNo(Long voucherNo) {
		this.log.debug("getVoucherByNo DAO Start");
		String sql = "select * from f_Voucher where voucherNo = ?";

		Object[] params = { voucherNo };

		this.log.debug("sql: " + sql);
		this.log.debug("voucherNo: " + params[0]);

		Object obj = null;
		FVoucher voucher = null;
		try {
			obj = queryForObject(sql, params, new CommonRowMapper(new FVoucher()));
			voucher = (FVoucher) obj;
			this.log.debug("getVoucherByNo queryForObject");
			voucher.setVoucherEntrys(getVoucherEntrys(voucherNo));
			this.log.debug("getVoucherByNo setVoucherEntrys");
		} catch (IncorrectResultSizeDataAccessException e) {
			this.log.error("voucherNo " + voucherNo + " Not exist !");
			e.printStackTrace();
		}

		return voucher;
	}

	/**
	 * 取得凭证Entry信息
	 */
	private List<FVoucherEntry> getVoucherEntrys(Long voucherNo) {
		Object[] params = { voucherNo };

		String entrySql = "select a.*,b.name as accountName from f_VoucherEntry a,F_Account b where voucherNo=? and a.accountcode=b.code order by entryId";

		this.log.debug("sql: " + entrySql);
		this.log.debug("voucherNo: " + params[0]);
		List<FVoucherEntry> voucherEntrys = queryBySQL(entrySql, params, null,
				new CommonRowMapper(new FVoucherEntry()));
		this.log.debug("voucherEntrys: " + voucherEntrys.toString());
		return voucherEntrys;
	}

	public void updateVoucherNotEntrys(FVoucher voucher) {
		String sql = "update f_Voucher set summaryNo=?, summary=?, note=?, inputuser=?, inputtime=?, auditor=?, audittime=?, auditnote=?, status=?, contractNo=?  where voucherNo=?";

		Object[] params = { voucher.getSummaryno(), voucher.getSummary(), voucher.getNote(), voucher.getInputuser(),
				voucher.getInputtime(), voucher.getAuditor(), voucher.getAudittime(), voucher.getAuditnote(),
				voucher.getStatus(), voucher.getContractno(), voucher.getVoucherno() };
		int[] dataTypes = { 1, 12, 12, 12, 93, 12, 93, 12, 12, 12, 12 };
		this.logger.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++) {
			this.logger.debug("params[" + i + "]: " + params[i]);
		}

		updateBySQL(sql, params, dataTypes);
	}

	/**
	 * 审核通过/失败
	 */
	public int auditVoucher(Long voucherNo, boolean isPass) {
		int result = -1;
		if (voucherNo != null) {
			FVoucher voucher = this.getVoucherByNo(voucherNo);
			if (voucher != null) {
				if (isPass) {
					String row = auditVoucher(voucherNo);
					result = Integer.parseInt(row);
				} else {
					voucher.setStatus(0);
					this.updateVoucherNotEntrys(voucher);
					result = 1;
				}
			}
		}
		return result;
	}

	@Override
	public List<VocherDataList> getAllVoucherList(QueryConditions qc,
			PageInfo pageInfo) {
		List<VocherDataList> list = new ArrayList<VocherDataList>();
		this.log.debug("getBankList DAO Start");
		String sql = sqlProperty.getProperty("VoucherDAO_001");
		list = queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new VocherDataList()));// 通用绑定模式，根据模型和数据结果集自动。
		return list;
	}

	@Override
	public List<VocherDataList> getEditingVoucherList(QueryConditions qc,
			PageInfo pageInfo) {
		List<VocherDataList> list = new ArrayList<VocherDataList>();
		this.log.debug("getEditingVoucherList DAO Start");
		String sql = sqlProperty.getProperty("VoucherDAO_002");
		this.log.debug("VoucherDAO_002_SQL: " + sql);
		list = queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new VocherDataList()));
		return list;
	}

	@Override
	public List<VocherDataList> getAuditingVoucherList(QueryConditions qc,
			PageInfo pageInfo) {
		List<VocherDataList> list = new ArrayList<VocherDataList>();
		this.log.debug("getBankList DAO Start");
		String sql = sqlProperty.getProperty("VoucherDAO_003");
		list = queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new VocherDataList()));
		return list;
	}

	@Override
	public VoucherAllData getVoucherByNos(Long vOUCHERNO) {
		String sql = sqlProperty.getProperty("VoucherDAO_004");
		Object [] params = {
				vOUCHERNO
		};
		return (VoucherAllData) queryForObject(sql, params, new CommonRowMapper(new VoucherAllData()));
	}

	@Override
	public int  deleteVoucher(String vOUCHERNOs) {
		
		String sql = sqlProperty.getProperty("VoucherDAO_005")+" and VOUCHERNO in("+vOUCHERNOs+")";
		Object [] param ={};
		int returnCode;
		try {
			 returnCode = updateBySQL(sql,param);
		} catch (Exception e) {
			returnCode = -1;
		}
		return returnCode;
	}

	@Override
	public int deleteVouCherEntry(Long vOUCHERNO) {
		String sql = sqlProperty.getProperty("VoucherDAO_006");
		Object [] params = {
				vOUCHERNO
		};
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		int rowNm = this.getJdbcTemplate().update(sql, params);
		return rowNm;
	}

	@Override
	public int rejectAuditVoucher(Long voucherNo) {
		String sql = sqlProperty.getProperty("VoucherDAO_007");
		Object [] params = {
				voucherNo
		};
		this.log.debug("sql: " + sql);
		for (int i = 0; i < params.length; i++)
			this.log.debug("params[" + i + "]: " + params[i]);
		int rowNm = this.getJdbcTemplate().update(sql, params);
		return rowNm;
		
	}
	
	private String auditVoucher(final Long voucherNo ) {
		String result = "-1";
		String procedure = "{?=call Proc_FN_F_auditVoucherPass(?)}"; 
		try{  
			result=(String)this.getJdbcTemplate().execute(procedure, new CallableStatementCallback(){  
                public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {  
                	cs.registerOutParameter(1,Types.VARCHAR); //输出参数类型  
                	cs.setLong(2, voucherNo);
                	cs.execute();
                	return cs.getString(1);
                }  
            }); 
        }catch(Exception e){
        	this.log.debug("auditVoucher Exception e = " + e.getMessage());
            e.printStackTrace();  
            result = "-1";
        }   
		return result;
	}

	@Override
	public VoucherModel getVoucherModelByCode(String voucherModelID) {
		String sql = sqlProperty.getProperty("VoucherDAO_008");
		Object [] params = {
				voucherModelID
		};
		VoucherModel voucherModel = (VoucherModel) queryForObject(sql, params, new CommonRowMapper(new VoucherModel()));
		return voucherModel;
	}

	@Override
	public void updateVoucherNote(Voucher voucher) {
		String sql = sqlProperty.getProperty("VoucherDAO_009");
		Object [] params = {
				voucher.getNOTE(),voucher.getVOUCHERNO()
		};
		this.updateBySQL(sql, params);
	}
	
	@Override
	public List<Voucher> getVoucherList(String vOUCHERNOs) {

		String sql = sqlProperty.getProperty("VoucherDAO_010")+" and VOUCHERNO in("+vOUCHERNOs+")";
		Object[] params ={};
		return this.queryBySQL(sql, params, null, new CommonRowMapper(new Voucher()));
	}
	
	@Override
	public void rollBack() {
		try {
			getConnection().rollback();
		} catch (CannotGetJdbcConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
