/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: SApplyMgrServiceImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月12日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.finance.component.ISApplayManager;
import shcem.finance.dao.model.AllFundFlow;
import shcem.finance.dao.model.SApply;
import shcem.finance.dao.model.SFirmFunds;
import shcem.finance.dao.model.SFundFlow;
import shcem.finance.dao.model.SPreSaleFirmFunds;
import shcem.finance.dao.model.SPreSaleFundFlow;
import shcem.finance.service.ISApplyMgrService;
import shcem.finance.util.FinanceSysData;
import shcem.util.Common;
import shcem.util.JsonUtil;

/**
 * @author wlpod
 *
 */
public class SApplyMgrServiceImpl extends BaseServiceImpl implements ISApplyMgrService {

	private ISApplayManager mgr = (ISApplayManager) FinanceSysData.getBean(Constants.BEAN_SAPPLYMGR_MGR);

	/**
	 * 申请列表查询
	 */
	@Override
	public String getApplyingList(String params) {
		this.log.info(this.getClass().getName() + " getApplyingList() Start");
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");

		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("t1.DiffType","=","","long","diffType"));
		conditionList.add(new Condition("t1.FirmID", "like", "", "String", "firmID"));
		conditionList.add(new Condition("t4.FirmName", "like", "", "String", "firmName"));
		conditionList.add(new Condition("t1.Status", "=", "", "long", "status"));
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<SApply> list = null;
		boolean bolRst = false;
		try {
			list = mgr.getSApplyList(qc, pageInfo);
			bolRst = true;
//			this.log.businesslog("取得申请列表S_APPLY成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		} catch (Exception err) {
			this.log.error("取得申请列表S_APPLY失败：" + err.getMessage());
//			this.log.businesslog("取得申请列表S_APPLY失败", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			setResultData("10104", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);

				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10104", null, e.getMessage());
			}
		}
		
		this.log.info(this.getClass().getName() + " getApplyingList() End");
		return rtnData.toString();
	}

	/**
	 * 审核列表查询
	 */
	@Override
	public String getApprovingList(String params) {
		this.log.info(this.getClass().getName() + " getApprovingList() Start");
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");

		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("t1.DiffType","=","","long","diffType"));
		conditionList.add(new Condition("t1.FirmID", "like", "", "String", "firmID"));
		conditionList.add(new Condition("t4.FirmName", "like", "", "String", "firmName"));
		conditionList.add(new Condition("t1.Status", "=", "", "long", "status"));
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<SApply> list = null;
		boolean bolRst = false;
		try {
			list = mgr.getSApplyList(qc, pageInfo);
			bolRst = true;
//			this.log.businesslog("取得审核列表S_APPLY成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		} catch (Exception err) {
			this.log.error("取得审核列表S_APPLY失败：" + err.getMessage());
			setResultData("10104", null, err.getMessage());
//			this.log.businesslog("取得审核列表S_APPLY失败", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);

				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10104", null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getApprovingList() End");
		return rtnData.toString();
	}

	/**
	 * 授信历史列表查询
	 */
	@Override
	public String getApprovedList(String params) {
		this.log.info(this.getClass().getName() + " getApprovedList() Start");
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");

		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("t1.FirmID", "=", "", "String", "firmID"));
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		qc.addCondition("t1.Status", "=", "1");

		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<SApply> list = null;
		boolean bolRst = false;
		try {
			list = mgr.getSApplyList(qc, pageInfo);
			bolRst = true;
//			this.log.businesslog("取得审核历史列表S_APPLY成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		} catch (Exception err) {
			this.log.error("取得审核历史列表S_APPLY失败：" + err.getMessage());
			setResultData("10104", null, err.getMessage());
//			this.log.businesslog("取得审核历史列表S_APPLY失败", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);

				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10104", null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getApprovedList() End");
		return rtnData.toString();
	}

	/**
	 * 授信申请追加
	 */
	@Override
	public String addApply(String params) {
		this.log.info(this.getClass().getName() + " addApply() Start");

		JSONObject JOParams = new JSONObject(params);
		SApply sapply = (SApply) JsonUtil.jsonToBean(JOParams, SApply.class);
		this.log.debug(params);
		String userName = this.getUserName() == null ? "test001" : (this
				.getUserName() == "") ? "test001" : this.getUserName();
		try {
			sapply.setApplyer(userName);
			sapply.setApplyTime(Common.getDate());

			int retCode = this.mgr.addApply(sapply);
			this.log.debug("retCode=" + retCode);
			if (retCode == 1) {
				setResultData("00000", null);
				this.log.businesslog("增加授信申请情报成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
			} else {
				setResultData("10106", null);
				this.log.businesslog("增加授信申请情报失败", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			}

		} catch (Exception e) {
			this.log.error("增加授信申请情报失败：" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("增加授信申请情报失败", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		}

		this.log.info(this.getClass().getName() + " addApply() End");
		return rtnData.toString();
	}

	/**
	 * 当前授信资金查询
	 */
	@Override
	public String getFirmFundsList(String params) {
		this.log.info(this.getClass().getName() + " getFirmFundsList() Start");
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");

		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("t1.firmID", "like", "", "String", "firmID"));
		conditionList.add(new Condition("firmName", "like", "", "String", "firmName"));
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		
		// 类型（0：现货授信，1：预售授信）
		Object obj = queryModel.opt("diffType");
		Integer diffType = 0;
		if (obj != null){
			diffType = Integer.valueOf(obj.toString());
		}
		List<SFirmFunds> list = null;
		List<SPreSaleFirmFunds> preSaleFirmFundslist = null;
		boolean bolRst = false;
		try {
			if (diffType == 1){
				preSaleFirmFundslist = mgr.getPreSaleFirmFundsList(qc, pageInfo);
			}else{
				list = mgr.getFirmFundsList(qc, pageInfo);
			}
			
			bolRst = true;
//			this.log.businesslog("取得当前授信资金列表S_FIRMFUNDS成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		} catch (Exception err) {
			this.log.error("取得当前授信资金列表S_FIRMFUNDS失败：" + err.getMessage());
//			this.log.businesslog("取得当前授信资金列表S_FIRMFUNDS失败", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			setResultData("10104", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				if (diffType == 1){
					retData = JsonUtil.coverModelToJSONArray(preSaleFirmFundslist);
				}else{
					retData = JsonUtil.coverModelToJSONArray(list);
				}
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10104", null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getFirmFundsList() End");
		return rtnData.toString();
	}

	/**
	 * 审核不通过
	 */
	@Override
	public String approveNot(String params) {
		this.log.info(this.getClass().getName() + " approveNot() Start");
		JSONObject JOParams = new JSONObject(params);

		// 申请ID
		String id = JOParams.getString("iD");
		String refuseReason = null;
		if(!JOParams.isNull("refuseReason")){
			refuseReason = JOParams.getString("refuseReason");
		}
		
		this.log.debug(params);

		try {

			int retCode = this.mgr.approveNot(Integer.parseInt(id), refuseReason);
			this.log.debug("retCode=" + retCode);
			if (retCode == 1) {
				setResultData("00000", null);
				this.log.businesslog("审核成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
			} else {
				setResultData("10106", null);
				this.log.businesslog("审核失败", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			}

		} catch (Exception e) {
			this.log.error("审核失败：" + e.getMessage());
			this.log.businesslog("审核失败", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			setResultData("10106", null, e.getMessage());
		}

		this.log.info(this.getClass().getName() + " approveNot() End");
		return rtnData.toString();
	}

	/**
	 * 审核通过
	 */
	@Override
	public String approveYes(String params) {
		this.log.info(this.getClass().getName() + " approveYes() Start");
		JSONObject JOParams = new JSONObject(params);

		// 申请ID
		String id = JOParams.getString("iD");
		String refuseReason = null;
		if(!JOParams.isNull("refuseReason")){
			refuseReason = JOParams.getString("refuseReason");
		}
		this.log.debug(params);

		try {
			int retCode = this.mgr.approveYes(Integer.parseInt(id), getUserId(), refuseReason);
			this.log.debug("retCode=" + retCode);
			if (retCode > 0) {
				setResultData("00000", null);
				this.log.businesslog("审核成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
			} else if (retCode == -2) {
				setResultData("10103", null, "当前授信额度小于调整额！");
				this.log.businesslog("审核失败", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			} else {
				setResultData("10106", null);
				this.log.businesslog("审核失败", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			}

		} catch (Exception e) {
			this.log.error("审核失败：" + e.getMessage());
			this.log.businesslog("审核失败", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			setResultData("10106", null, e.getMessage());
		}

		this.log.info(this.getClass().getName() + " approveYes() End");
		return rtnData.toString();
	}

	/**
	 * 授信资金流水list取得
	 */
	@Override
	public String getSFundFlowList(String params) {
		this.log.info(this.getClass().getName() + " getSFundFlowList() Start");
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");

		List<Condition> conditionList = new ArrayList<Condition>();
		
		conditionList.add(new Condition("t1.FirmID", "like", "", "String", "firmID"));
		conditionList.add(new Condition("firmName", "like", "", "String", "firmName"));
		conditionList.add(new Condition("t1.OperCode", "=", "", "String", "operCode"));
		conditionList.add(new Condition("convert(char(10),t1.CREATETIME,120)", " >= ", "", "String", "startDate"));
		conditionList.add(new Condition("convert(char(10),t1.CREATETIME,120)", " <= ", "", "String", "endDate"));
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<SFundFlow> fundFlowList = null;
		List<SPreSaleFundFlow> preSaleSFundFlowList = null;
		boolean bolRst = false;
		// 申请类型（0：现货授信，1：预售授信）
		Integer diffType = queryModel.getInt("diffType");
		try {
			if (1 == diffType){
				preSaleSFundFlowList = mgr.getPreSaleFundFlowList(qc, pageInfo);
			}else{
				fundFlowList = mgr.getSFundFlowList(qc, pageInfo);
			}
			bolRst = true;
		} catch (Exception err) {
			this.log.error("取得授信资金流水失败：" + err.getMessage());
			setResultData("10104", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				if (1 == diffType){
					retData = JsonUtil.coverModelToJSONArray(preSaleSFundFlowList);
				}else{
					retData = JsonUtil.coverModelToJSONArray(fundFlowList);
				}
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10104", null, e.getMessage());
			}
		}
		
		this.log.info(this.getClass().getName() + " getSFundFlowList() End");
		return rtnData.toString();
	}

	@Override
	public String getAllFundFlowList(String params) {
		this.log.info(this.getClass().getName() + " getAllFundFlowList() Start");
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");

		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("firmID", "=", "", "String", "firmID"));
		conditionList.add(new Condition("operCode", "=", "", "String", "operCode"));
		conditionList.add(new Condition("accountType", "=", "", "String", "accountType"));
		conditionList.add(new Condition("convert(char(10),CREATETIME,120)", " >= ", "", "String", "startDate"));
		conditionList.add(new Condition("convert(char(10),CREATETIME,120)", " <= ", "", "String", "endDate"));
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<AllFundFlow> list = null;
		boolean bolRst = false;
		try {
			list = mgr.getAllFundFlowList(qc, pageInfo);
			bolRst = true;
//			this.log.businesslog("取得商城交易明细成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		} catch (Exception err) {
			this.log.error("取得商城交易明细失败：" + err.getMessage());
//			this.log.businesslog("取得商城交易明细失败", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			setResultData("10104", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);

				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10104", null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getAllFundFlowList() End");
		return rtnData.toString();
	}
}
