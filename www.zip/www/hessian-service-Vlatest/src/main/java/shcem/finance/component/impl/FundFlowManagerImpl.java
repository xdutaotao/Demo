package shcem.finance.component.impl;

import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.component.IFundFlowManager;
import shcem.finance.dao.FundFlowDAO;
import shcem.finance.dao.model.FinancialBills;
import shcem.finance.dao.model.FundflowServiceModel;

public class FundFlowManagerImpl extends BaseManager implements IFundFlowManager {
	private FundFlowDAO dao;
	private FundFlowDAO fundFlowDAO_read;
	public void setFundFlowDAO(FundFlowDAO dao) {
		this.dao = dao;
	}

	public void setFundFlowDAO_read(FundFlowDAO fundFlowDAO_read) {
		this.fundFlowDAO_read = fundFlowDAO_read;
	}

	@Override
	public List<FundflowServiceModel> getFundFlowList(QueryConditions qc,
			PageInfo pageInfo)throws RuntimeException{
		List<FundflowServiceModel> list = null ;
		list= this.fundFlowDAO_read.getFundFlowList(qc,pageInfo);
		return list;
	}
	
	/**
	 * 
	 */
	@Override
	public List<FinancialBills> getFinancialBillsList(QueryConditions qc,
			PageInfo pageInfo,int financialBillsType) {
		List<FinancialBills> list = null ;
		list= this.fundFlowDAO_read.getFinancialBillsList(qc,pageInfo,financialBillsType);
		return list;
	}
}
