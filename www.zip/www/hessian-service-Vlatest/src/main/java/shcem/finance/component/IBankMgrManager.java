/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IBankMgrManager
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.component;

import java.util.List;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.BankMgrDAO;
import shcem.finance.dao.model.FBanks;

/**
 * IBankMgrManager
 * 
 * @author chiyong
 * @version 1.0
 */
public abstract interface IBankMgrManager extends Manager {

	public abstract void setBankMgrDAO(BankMgrDAO paramBankMgrDAO);

	/**
	 * ȡ�������б�
	 * 
	 * @return �����б�
	 */
	public abstract List<FBanks> getBankList(QueryConditions qc, PageInfo pageInfo);

	public abstract FBanks getBank(String bankId);

	public abstract int updateBank(FBanks bank);

	public abstract int addBank(FBanks bank);

	public abstract int validBank(String bankId);

	public abstract int invalidBank(String bankId);
}
