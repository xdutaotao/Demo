/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmBanlanceListForOra
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.model;

import java.math.BigDecimal;

import shcem.base.dao.model.BaseObject;

public class PaymentLogDetail extends BaseObject implements java.io.Serializable, Cloneable {

	private static final long serialVersionUID = -7464587171301763763L;

	/** 流水id */
	private long Id;

	/** 明细id */
	private Integer DETAILID;
	
	/** 凭证模板id */
	private String voucherModelID;

	/** 发生金额 */
	private BigDecimal money;

	/** 订单号 */
	private String contractno;

	/** 交易商id */
	private String firmID;

	/** 备注 */
	private String note;

	/** 输入者 */
	private String inputUser;
	
	/** 明细流水状态 1 成功 -1 失败  2 待支付 0 未支付*/
	private Integer STATUS;
	
	/** 错误code */
	private Integer ERRORTYPE;
	
	/** 错误内容 */
	private String ERRORMSG;


	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

	public Integer getDETAILID() {
		return DETAILID;
	}

	public void setDETAILID(Integer dETAILID) {
		DETAILID = dETAILID;
	}

	public String getVoucherModelID() {
		return voucherModelID;
	}

	public void setVoucherModelID(String voucherModelID) {
		this.voucherModelID = voucherModelID;
	}

	public BigDecimal getMoney() {
		return money;
	}

	public void setMoney(BigDecimal money) {
		this.money = money;
	}

	public String getContractno() {
		return contractno;
	}

	public void setContractno(String contractno) {
		this.contractno = contractno;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getInputUser() {
		return inputUser;
	}

	public void setInputUser(String inputUser) {
		this.inputUser = inputUser;
	}

	public Integer getSTATUS() {
		return STATUS;
	}

	public void setSTATUS(Integer sTATUS) {
		STATUS = sTATUS;
	}

	public Integer getERRORTYPE() {
		return ERRORTYPE;
	}

	public void setERRORTYPE(Integer eRRORTYPE) {
		ERRORTYPE = eRRORTYPE;
	}

	public String getERRORMSG() {
		return ERRORMSG;
	}

	public void setERRORMSG(String eRRORMSG) {
		ERRORMSG = eRRORMSG;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}