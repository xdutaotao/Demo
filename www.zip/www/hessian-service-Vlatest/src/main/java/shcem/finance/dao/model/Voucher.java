package shcem.finance.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**凭证表
 * @author zhangnan
 *
 */
public class Voucher extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**  */
    private Integer vOUCHERNO;
    
    /**  */
    private Date bDATE;
    
    /**  */
    private String sUMMARYNO;
    
    /**  */
    private String sUMMARY;
    
    /**  */
    private String nOTE;
    
    /**  */
    private String iNPUTUSER;
    
    /**  */
    private String iNPUTTIME;
    
    /**  */
    private String aUDITOR;
    
    /**  */
    private String aUDITTIME;
    
    /**  */
    private String aUDITNOTE;
    
    /**  */
    private String sTATUS;
    
    /**  */
    private String cONTRACTNO;
    
    /**  */
    private Integer fUNDFLOWID;
    
    private String firmID;
    
    //开始结束日期
    private String bDATESTART;
    private String bDATEEND;
    
    //交易商相关
    private String firmName;
    
    private String firmNamePY;
    
    //借方科目代码
    private String deBitCode;
    //贷方科目代码
    private String creDitCode;
    //金额
    private BigDecimal money;
    
    //科目模型代码
    private String voucherModelID;
    
    
	
	public Integer getVOUCHERNO() {
		return vOUCHERNO;
	}

	public void setVOUCHERNO(Integer vOUCHERNO) {
		this.vOUCHERNO = vOUCHERNO;
	}

	public Date getBDATE() {
		return bDATE;
	}

	public void setBDATE(Date bDATE) {
		this.bDATE = bDATE;
	}

	public String getSUMMARYNO() {
		return sUMMARYNO;
	}

	public void setSUMMARYNO(String sUMMARYNO) {
		this.sUMMARYNO = sUMMARYNO;
	}

	public String getSUMMARY() {
		return sUMMARY;
	}

	public void setSUMMARY(String sUMMARY) {
		this.sUMMARY = sUMMARY;
	}

	public String getNOTE() {
		return nOTE;
	}

	public void setNOTE(String nOTE) {
		this.nOTE = nOTE;
	}

	public String getINPUTUSER() {
		return iNPUTUSER;
	}

	public void setINPUTUSER(String iNPUTUSER) {
		this.iNPUTUSER = iNPUTUSER;
	}

	public String getINPUTTIME() {
		return iNPUTTIME;
	}

	public void setINPUTTIME(String iNPUTTIME) {
		this.iNPUTTIME = iNPUTTIME;
	}

	public String getAUDITOR() {
		return aUDITOR;
	}

	public void setAUDITOR(String aUDITOR) {
		this.aUDITOR = aUDITOR;
	}

	public String getAUDITTIME() {
		return aUDITTIME;
	}

	public void setAUDITTIME(String aUDITTIME) {
		this.aUDITTIME = aUDITTIME;
	}

	public String getAUDITNOTE() {
		return aUDITNOTE;
	}

	public void setAUDITNOTE(String aUDITNOTE) {
		this.aUDITNOTE = aUDITNOTE;
	}

	public String getSTATUS() {
		return sTATUS;
	}

	public void setSTATUS(String sTATUS) {
		this.sTATUS = sTATUS;
	}

	public String getCONTRACTNO() {
		return cONTRACTNO;
	}

	public void setCONTRACTNO(String cONTRACTNO) {
		this.cONTRACTNO = cONTRACTNO;
	}

	public Integer getFUNDFLOWID() {
		return fUNDFLOWID;
	}

	public void setFUNDFLOWID(Integer fUNDFLOWID) {
		this.fUNDFLOWID = fUNDFLOWID;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getBDATESTART() {
		return bDATESTART;
	}

	public void setBDATESTART(String bDATESTART) {
		this.bDATESTART = bDATESTART;
	}

	public String getBDATEEND() {
		return bDATEEND;
	}

	public void setbDATEEND(String bDATEEND) {
		this.bDATEEND = bDATEEND;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public String getFirmNamePY() {
		return firmNamePY;
	}

	public void setFirmNamePY(String firmNamePY) {
		this.firmNamePY = firmNamePY;
	}

	public String getDeBitCode() {
		return deBitCode;
	}

	public void setDeBitCode(String deBitCode) {
		this.deBitCode = deBitCode;
	}

	public String getCreDitCode() {
		return creDitCode;
	}

	public void setCreDitCode(String creDitCode) {
		this.creDitCode = creDitCode;
	}

	public BigDecimal getMoney() {
		return money;
	}

	public void setMoney(BigDecimal money) {
		this.money = money;
	}

	public String getVoucherModelID() {
		return voucherModelID;
	}

	public void setVoucherModelID(String voucherModelID) {
		this.voucherModelID = voucherModelID;
	}

}
