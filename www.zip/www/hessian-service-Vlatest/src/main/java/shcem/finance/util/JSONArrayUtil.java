package shcem.finance.util;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONArray;

public class JSONArrayUtil {
	/**
     * 将json数组转化为Long型
     * @param str
     * @return
     */
    public static long[] getJsonToLongArray(JSONArray jsonArray) {
    	long[] arr=new long[jsonArray.length()];
         for(int i=0;i<jsonArray.length();i++){
             arr[i]=jsonArray.getLong(i);
             System.out.println(arr[i]);
         }
         return arr;
   }
    
    
    /**
     * 将json数组转化为int型
     * @param str
     * @return
     */
    public static int[] getJsonToIntArray(JSONArray jsonArray) {
    	int[] arr=new int[jsonArray.length()];
         for(int i=0;i<jsonArray.length();i++){
             arr[i]=jsonArray.getInt(i);
             System.out.println(arr[i]);
         }
         return arr;
   }
    
    /**
     * 将json数组转化为int型
     * @param str
     * @return
     */
    public static Integer[] getJsonToIntegerArray(JSONArray jsonArray) {
    	Integer[] arr=new Integer[jsonArray.length()];
         for(int i=0;i<jsonArray.length();i++){
             arr[i]=jsonArray.getInt(i);
             System.out.println(arr[i]);
         }
         return arr;
   }
    
    /**
     * 将json数组转化为String型
     * @param str
     * @return
     */
    public static String[] getJsonToStringArray(JSONArray jsonArray) {
         
         String[] arr=new String[jsonArray.length()];
         for(int i=0;i<jsonArray.length();i++){
             arr[i]=jsonArray.getString(i);
             System.out.println(arr[i]);
         }
         return arr;
   }
    /**
     * 将json数组转化为Double型
     * @param str
     * @return
     */
    public static double[] getJsonToDoubleArray(JSONArray jsonArray) {
    	double[] arr=new double[jsonArray.length()];
    	for(int i=0;i<jsonArray.length();i++){
    		arr[i]=jsonArray.getDouble(i);
    	}
    	return arr;
   }
    /**
     * 将json数组转化为Date型
     * @param str
     * @return
     */
    public static Date[] getJsonToDateArray(JSONArray jsonArray) {
         Date[] dateArray = new Date[jsonArray.length()];
         String dateString;
         Date date;
         SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
         for (int i = 0; i < jsonArray.length(); i++) {
             dateString = jsonArray.getString(i);
             try {
                 date=sdf.parse(dateString);
                 dateArray[i] = date;
             } catch (Exception e) {
                 e.printStackTrace();
             }
         }
         return dateArray;
   }
    
    
    /**
     * 将json数组转化为BigDecimal型
     * @param str
     * @return
     */
    public static BigDecimal[] getJsonToBigDecimalArray(JSONArray jsonArray) {
         
    	BigDecimal[] arr=new BigDecimal[jsonArray.length()];
         for(int i=0;i<jsonArray.length();i++){
             arr[i]=new BigDecimal(jsonArray.getString(i));
             System.out.println(arr[i]);
         }
         return arr;
   }
}
