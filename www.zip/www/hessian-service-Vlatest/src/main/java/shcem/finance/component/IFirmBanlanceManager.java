/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IFirmBanlanceManager
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.component;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.FirmBanlanceDAO;
import shcem.finance.dao.model.FBOutMoneyApply;
import shcem.finance.dao.model.FeeModel;
import shcem.finance.dao.model.FirmBanlanceList;
import shcem.finance.dao.model.TEnquiry;
import shcem.finance.dao.model.TLeads;
import shcem.finance.dao.model.TOrder;

/**
 * IFirmBanlanceManager
 * 
 * @author chiyong
 * @version 1.0
 */
public abstract interface IFirmBanlanceManager extends Manager {

	public abstract void setFirmBanlanceDAO(FirmBanlanceDAO paramDAO);


	
	public abstract int updateOutMoneyApply(Integer id, Integer fromStatus, Integer toStatus, String auditor,String note);
	
	public abstract List<FBOutMoneyApply> getOutMoneyApplyList(QueryConditions qc, PageInfo pageInfo);
	
	public abstract void insertOutMoneyApply(FBOutMoneyApply applyModel);
	
	/**
	 * 交易商当前资金查询
	 */
	public abstract List<FirmBanlanceList> queryFirmBanlance(QueryConditions qc, PageInfo pageInfo);
	
	
	/**
	 * 查询出金申请列表
	 */
	public abstract List<FirmBanlanceList> queryOutMoneyList(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 报盘收保证金手续费
	 * 
	 * @param leadsId
	 * @return
	 */
	public abstract int payMoneyByleadsId(Long leadsId);
	
	/**
	 * 报盘收保证金手续费
	 * 
	 * @param leadsId
	 * @return
	 */
	public abstract int modifyLeads(Long leadsId);

	/**
	 * 询盘收保证金手续费
	 * 
	 * @param enquiryId
	 * @return
	 */
	public abstract int payMoneyByEnquiryId(Long enquiryId);

	/**
	 * 成交时收保证金手续费
	 * 
	 * @param orderID
	 * @return
	 */
	public abstract int payMoneyByOrderId(String orderID);
	
	/**
	 * 成交后付货款
	 * 
	 * @param orderID
	 * @return
	 */
	public abstract HashMap PaymentBuyer(String orderID, boolean couponFlg, String Operator, BigDecimal couponAmount);

	/**
	 * 根据交收数据，权限校验，资金校验，收买方货款，退买/卖方交易手续费，收买/卖方交收手续费，退买/卖方交易保证金，收买/卖方交易保证金（对应数量比例
	 * ），生成相应流水， 更新交收表的已收买/卖方保证金，已收买/卖方手续费，已收买方货款字段
	 * 
	 * @param deliveryId
	 * @return
	 */
	public abstract boolean payMoneyByDeliveryId(String deliveryId);

	/**
	 * 报盘撤盘退还费用
	 * 
	 * @param leadsId
	 * @return
	 */
	public abstract boolean backByLeadsID(Long leadsId);

	/**
	 * 询盘撤盘退还费用
	 * 
	 * @param enquiryId
	 * @return
	 */
	public abstract boolean backByEnquiryID(Long enquiryId);

	/**
	 * 报盘交易商资金校验
	 * 
	 * @param leadsId
	 * @return
	 */
	public abstract boolean chkFirmFundsForLeads(Long leadsId);

	/**
	 * 询盘交易商资金校验
	 * 
	 * @param enquiryId
	 * @return
	 */
	public abstract boolean chkFirmFundsForEnquiry(Long EnquiryId);

	/**
	 * 成交时交易商资金校验
	 * 
	 * @param orderID
	 * @return
	 */
	public abstract boolean chkFirmFundsForOrder(String orderID);

	/**
	 * 交收时买方 交易商资金校验
	 * 
	 * @param deliveryId
	 * @return
	 */
	public abstract boolean chkFirmFundsForDelivery(String deliveryId);

	/**
	 * 报盘信息取得
	 * 
	 * @param id
	 * @return
	 */
	public abstract TLeads getLeadsById(Long id);

	/**
	 * 询盘信息取得
	 * 
	 * @param id
	 * @return
	 */
	public abstract TEnquiry getEnquiryById(Long id);

	/**
	 * 成交信息取得
	 * 
	 * @param id
	 * @return
	 */
	public abstract TOrder getOrderById(String id);


	/**
	 * 批量撤销报盘和询盘
	 * 
	 * @param id
	 * @return
	 */
	public abstract boolean backAllLeadsAndEnquiry();
	
	/**
	 * 能撤销报盘和询盘的个数
	 * 
	 * @param id
	 * @return
	 */
	public abstract int getCanBackCount();

	public abstract boolean backFeeAndDeposit(String ObjectID, int flowType, String firmID, FeeModel feeModel, String note, int creditType);
	public abstract boolean getFeeAndDepositDeli(String ObjectID, int flowType, String firmID, FeeModel feeModel, String note, int creditType);

	/**
	 * 中石化自动撤盘
	 * @return
	 */
	public abstract boolean backAllSinopecLeadsAndEnquiry();

	public abstract int payForCouPon(String firmId, BigDecimal couponAmount, String contractno, String inputUser);
	
	public abstract int addDepositSeller(String orderId);
	public abstract int addDepositBuyer(String orderId);
	
	
	public abstract int payForCancel(String ApplyID, String userId);
	
	/*
	 * 以下线性市场追加
	 */
	/**
	 * 撤销询盘前检查询盘状态, 成功锁数据, 失败返回
	 * 
	 * @param differ: 1|后台释放询盘; 2|Job撤询盘
	 * @param enqId: differ为0，1场合的询盘ID
	 */
	public List<TEnquiry> preBackQXEnquiry(int differ, int enqId) throws Exception;
	
	/**
	 * 撤销挂盘前检查挂盘状态, 成功锁数据, 失败返回
	 * 
	 * @param differ: 0|前台撤挂盘 ; 2|Job撤挂盘
	 * @param enqId: differ为0，1场合的挂盘ID
	 */
	public List<TLeads> preBackQXLead(int differ, int leadId) throws Exception;
	
	/**
	 * 撤销询盘
	 * 
	 * @param differ: 1|后台释放询盘; 2|Job撤询盘
	 * @param enquiry: 需要撤的询盘
	 */
	public void backQXEnquiry(int differ, TEnquiry enquiry) throws Exception;
	
	/**
	 * 撤销挂盘
	 * 
	 * @param differ: 0|前台撤挂盘 ; 2|Job撤挂盘
	 * @param lead: 需要撤的挂盘
	 */
	public void backQXLead(int differ, TLeads lead) throws Exception;
	
	/**
	 * 撤销询盘后释放数据
	 * 
	 * @param differ: 1|后台释放询盘; 2|Job撤询盘
	 * @param enquiry: 需要恢复的询盘
	 */
	public void postBackQXEnquiry(int differ, TEnquiry enquiry) throws Exception;
	
	/**
	 * 撤销挂盘后释放数据
	 * 
	 * @param differ: 0|前台撤挂盘 ; 2|Job撤挂盘
	 * @param lead: 需要恢复的挂盘
	 */
	public void postBackQXLead(int differ, TLeads lead) throws Exception;
	
}
