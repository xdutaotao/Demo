package shcem.finance.ExportModel;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;
import shcem.finance.dao.model.InvoiceApply4Check;

/**
 * 开票导出类
 * @author zhangnan
 *
 */
public class InvoiceApply4Export extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer id;

	/**发票类型  1:增值税发票 5：普通发票*/
	private Integer invoiceType;
	
	/** 发票抬头 :买家交易商名称*/
	private String invoiceTitle;
	
	/**税号*/
	private String taxNo;
	
	/**开票银行帐号*/
	private String bankAccount;
	
	/**开票银行ID*/
	private Integer bankID;
	
	/**开票银行名称*/
	private String bankName;
	
	/**开票地址*/
	private String invoiceAddress;
	
	/**开票电话*/
	private String invoiceTel;
	
	/**税率*/
	private BigDecimal taxRate;
	
	/**开票数量（吨）*/
	private BigDecimal applyQuantity;
	
	/**开票单价（元)*/
	private BigDecimal applyPrice;
	
	/**开票金额*/
	private BigDecimal applyMoney;
	
	/**备注*/
	private String remark;
	
	/**成交单号*/
	private String orderID;
	
	/**线下合同号*/
	private String XSSFNumber;
	
	/** 快递单号 */
	private String trackingNo;
	
	/**品类*/
	private String categoryName;
	
	/**牌号*/
	private String brandName;
	
	/**产地*/
	private String sourcePlaceName;
	
	/**交收单号*/
	private String deliveryID;
	
	/**开票支行名称*/
	private String branchName;
	/**收票地址*/    
	private String collectInvoiceAddress;
	/**收票电话*/
	private String collectTel;
	/**收票人*/
	private String collectInvoicePeople;
	
	/**申请信息是否详细*/
	private Boolean isDetailed; 
	
	/** 开票申请来源 0:前台商城 1：化交后台*/
	private Integer applyOrigin = 1;
	
	/**
	 * 开票单位
	 */
	private String goodUnit;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(Integer invoiceType) {
		this.invoiceType = invoiceType;
	}

	public String getInvoiceTitle() {
		return invoiceTitle;
	}

	public void setInvoiceTitle(String invoiceTitle) {
		this.invoiceTitle = invoiceTitle;
	}

	public String getTaxNo() {
		return taxNo;
	}

	public void setTaxNo(String taxNo) {
		this.taxNo = taxNo;
	}

	public String getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}

	public Integer getBankID() {
		return bankID;
	}

	public void setBankID(Integer bankID) {
		this.bankID = bankID;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getInvoiceAddress() {
		return invoiceAddress;
	}

	public void setInvoiceAddress(String invoiceAddress) {
		this.invoiceAddress = invoiceAddress;
	}

	public String getInvoiceTel() {
		return invoiceTel;
	}

	public void setInvoiceTel(String invoiceTel) {
		this.invoiceTel = invoiceTel;
	}

	public BigDecimal getTaxRate() {
		return taxRate;
	}

	public void setTaxRate(BigDecimal taxRate) {
		this.taxRate = taxRate;
	}

	public BigDecimal getApplyQuantity() {
		return applyQuantity;
	}

	public void setApplyQuantity(BigDecimal applyQuantity) {
		this.applyQuantity = applyQuantity;
	}

	public BigDecimal getApplyPrice() {
		return applyPrice;
	}

	public void setApplyPrice(BigDecimal applyPrice) {
		this.applyPrice = applyPrice;
	}

	public BigDecimal getApplyMoney() {
		return applyMoney;
	}

	public void setApplyMoney(BigDecimal applyMoney) {
		this.applyMoney = applyMoney;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getTrackingNo() {
		return trackingNo;
	}

	public void setTrackingNo(String trackingNo) {
		this.trackingNo = trackingNo;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	
	public String getSourcePlaceName() {
		return sourcePlaceName;
	}

	public void setSourcePlaceName(String sourcePlaceName) {
		this.sourcePlaceName = sourcePlaceName;
	}


	public String getDeliveryID() {
		return deliveryID;
	}

	public void setDeliveryID(String deliveryID) {
		this.deliveryID = deliveryID;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getCollectInvoiceAddress() {
		return collectInvoiceAddress;
	}

	public void setCollectInvoiceAddress(String collectInvoiceAddress) {
		this.collectInvoiceAddress = collectInvoiceAddress;
	}

	public String getCollectTel() {
		return collectTel;
	}

	public void setCollectTel(String collectTel) {
		this.collectTel = collectTel;
	}

	public String getCollectInvoicePeople() {
		return collectInvoicePeople;
	}

	public void setCollectInvoicePeople(String collectInvoicePeople) {
		this.collectInvoicePeople = collectInvoicePeople;
	}

	public Boolean getIsDetailed() {
		return isDetailed;
	}

	public void setIsDetailed(Boolean isDetailed) {
		this.isDetailed = isDetailed;
	}

	public Integer getApplyOrigin() {
		return applyOrigin;
	}

	public void setApplyOrigin(Integer applyOrigin) {
		this.applyOrigin = applyOrigin;
	}


	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getGoodUnit() {
		return goodUnit;
	}

	public void setGoodUnit(String goodUnit) {
		this.goodUnit = goodUnit;
	}

	public String getOrderID() {
		return orderID;
	}

	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}

	public String getXSSFNumber() {
		return XSSFNumber;
	}

	public void setXSSFNumber(String xSSFNumber) {
		XSSFNumber = xSSFNumber;
	}
	
	

}
