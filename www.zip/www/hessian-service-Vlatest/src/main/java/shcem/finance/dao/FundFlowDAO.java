package shcem.finance.dao;

import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.model.FinancialBills;
import shcem.finance.dao.model.FundflowServiceModel;

public abstract interface FundFlowDAO extends DAO{

	public abstract List<FundflowServiceModel> getFundFlowList(QueryConditions qc,
			PageInfo pageInfo);

	public abstract List<FinancialBills> getFinancialBillsList(
			QueryConditions qc, PageInfo pageInfo, int financialBillsType);

}
