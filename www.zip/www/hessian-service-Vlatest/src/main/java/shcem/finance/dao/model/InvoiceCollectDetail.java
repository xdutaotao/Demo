/**
 * @author ws
 * 2016-10-13 10:22:13
 */
package shcem.finance.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

public class InvoiceCollectDetail extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -850277518846982299L;

	private Integer id;

	private Integer invoiceType;

	private String invoiceNo;

	private Date invoiceDate;

	private String invoiceTitle;

	private String taxNo;

	private String bankName;

	private String bankAccount;

	private String invoiceAddress;

	private String invoiceTel;

	private String invoiceContent;

	private BigDecimal invoiceQuantity;

	private BigDecimal invoicePrice;

	private BigDecimal taxRate;

	private BigDecimal invoiceMoney;

	private BigDecimal invoiceTax;

	private BigDecimal invoiceTotalMoney;

	private Date collectDate;

	private String remark;

	private Integer dISABLED;

	private String rEC_CREATEBY;

	private Date rEC_CREATETIME;

	private String rEC_MODIFYBY;

	private Date rEC_MODIFYTIME;
	// 关联单号（成交ID）
	private String relationID;
	// 成交单下所有收票记录的总金额
	private BigDecimal allInvoiceTotalMoney;
	
	// 收票关联表ID
	private Integer invoiceCollectDetailRelID;
	
	// 卖方交易商ID
	private String frimID;
	// 卖方交易商ID
	private String firmName;
	// 状态  1：正常 , 5：失效
	private Integer status;
	// 收票数量（吨） 
	private BigDecimal allInvoiceQuantity;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(Integer invoiceType) {
		this.invoiceType = invoiceType;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo == null ? null : invoiceNo.trim();
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getInvoiceTitle() {
		return invoiceTitle;
	}

	public void setInvoiceTitle(String invoiceTitle) {
		this.invoiceTitle = invoiceTitle == null ? null : invoiceTitle.trim();
	}

	public String getTaxNo() {
		return taxNo;
	}

	public void setTaxNo(String taxNo) {
		this.taxNo = taxNo == null ? null : taxNo.trim();
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName == null ? null : bankName.trim();
	}

	public String getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount == null ? null : bankAccount.trim();
	}

	public String getInvoiceAddress() {
		return invoiceAddress;
	}

	public void setInvoiceAddress(String invoiceAddress) {
		this.invoiceAddress = invoiceAddress == null ? null : invoiceAddress
				.trim();
	}

	public String getInvoiceTel() {
		return invoiceTel;
	}

	public void setInvoiceTel(String invoiceTel) {
		this.invoiceTel = invoiceTel == null ? null : invoiceTel.trim();
	}

	public String getInvoiceContent() {
		return invoiceContent;
	}

	public void setInvoiceContent(String invoiceContent) {
		this.invoiceContent = invoiceContent == null ? null : invoiceContent
				.trim();
	}

	public BigDecimal getInvoiceQuantity() {
		return invoiceQuantity;
	}

	public void setInvoiceQuantity(BigDecimal invoiceQuantity) {
		this.invoiceQuantity = invoiceQuantity;
	}

	public BigDecimal getInvoicePrice() {
		return invoicePrice;
	}

	public void setInvoicePrice(BigDecimal invoicePrice) {
		this.invoicePrice = invoicePrice;
	}

	public BigDecimal getTaxRate() {
		return taxRate;
	}

	public void setTaxRate(BigDecimal taxRate) {
		this.taxRate = taxRate;
	}

	public BigDecimal getInvoiceMoney() {
		return invoiceMoney;
	}

	public void setInvoiceMoney(BigDecimal invoiceMoney) {
		this.invoiceMoney = invoiceMoney;
	}

	public BigDecimal getInvoiceTax() {
		return invoiceTax;
	}

	public void setInvoiceTax(BigDecimal invoiceTax) {
		this.invoiceTax = invoiceTax;
	}

	public BigDecimal getInvoiceTotalMoney() {
		return invoiceTotalMoney;
	}

	public void setInvoiceTotalMoney(BigDecimal invoiceTotalMoney) {
		this.invoiceTotalMoney = invoiceTotalMoney;
	}

	public Date getCollectDate() {
		return collectDate;
	}

	public void setCollectDate(Date collectDate) {
		this.collectDate = collectDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark == null ? null : remark.trim();
	}

	public Integer getDISABLED() {
		return dISABLED;
	}

	public void setDISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY == null ? null : rEC_CREATEBY.trim();
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY == null ? null : rEC_MODIFYBY.trim();
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	
	public String getRelationID() {
		return relationID;
	}

	public void setRelationID(String relationID) {
		this.relationID = relationID;
	}

	public BigDecimal getAllInvoiceTotalMoney() {
		return allInvoiceTotalMoney;
	}

	public void setAllInvoiceTotalMoney(BigDecimal allInvoiceTotalMoney) {
		this.allInvoiceTotalMoney = allInvoiceTotalMoney;
	}

	public Integer getInvoiceCollectDetailRelID() {
		return invoiceCollectDetailRelID;
	}

	public void setInvoiceCollectDetailRelID(Integer invoiceCollectDetailRelID) {
		this.invoiceCollectDetailRelID = invoiceCollectDetailRelID;
	}

	public String getFrimID() {
		return frimID;
	}

	public void setFrimID(String frimID) {
		this.frimID = frimID;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public BigDecimal getAllInvoiceQuantity() {
		return allInvoiceQuantity;
	}

	public void setAllInvoiceQuantity(BigDecimal allInvoiceQuantity) {
		this.allInvoiceQuantity = allInvoiceQuantity;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}