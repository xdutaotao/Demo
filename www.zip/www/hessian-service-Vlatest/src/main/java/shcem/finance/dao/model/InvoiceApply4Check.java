package shcem.finance.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;

import shcem.base.dao.model.BaseObject;

/**
 * 开票申请数据，批量数据校验
 * @author zhangnan
 *
 */
public class InvoiceApply4Check extends BaseObject  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**交易商名称*/
	private String firmName;
	
	/** 开票类型 */
	private Integer applyType;
	
	/** 发票类型 */
	private Integer invoiceType;
	
	/** 发票抬头*/
	private String  invoiceTitle;
	
	/** 税号 */
	private String  taxNo;
	
	/** 交易商ID */
	private String firmId;
	
	/** 开票银行帐号 */
	private String bankAccount;
	
	/** 开票银行ID */
	private Integer bankID;
	
	/** 开票银行	*/
	private String bankName;
	
	/** 开票地址 */
	private String invoiceAddress;
	
	/** 开票电话 */
	private String invoiceTel;
	
	/** 税率 */
	private BigDecimal taxRate;
	
	/** 开票数量（吨）*/
	private BigDecimal applyQuantity;
	
	/** 开票单价（元) */
	private BigDecimal  applyPrice;
	
	/**开票金额*/
	private BigDecimal applyMoney;
	
	/**收票地址*/
	private String collectInvoiceAddress;
	
	/**收票电话*/
	private String collectTel;
	
	/**收票人*/
	private String collectInvoicePeople;
	
	/**支行名称*/
	private String branchName;

	
	public String getCollectInvoiceAddress() {
		return collectInvoiceAddress;
	}

	public void setCollectInvoiceAddress(String collectInvoiceAddress) {
		this.collectInvoiceAddress = collectInvoiceAddress;
	}

	public String getCollectTel() {
		return collectTel;
	}

	public void setCollectTel(String collectTel) {
		this.collectTel = collectTel;
	}

	public String getCollectInvoicePeople() {
		return collectInvoicePeople;
	}

	public void setCollectInvoicePeople(String collectInvoicePeople) {
		this.collectInvoicePeople = collectInvoicePeople;
	}

	public Integer getApplyType() {
		return applyType;
	}

	public void setApplyType(Integer applyType) {
		this.applyType = applyType;
	}

	public Integer getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(Integer invoiceType) {
		this.invoiceType = invoiceType;
	}

	public String getInvoiceTitle() {
		return invoiceTitle;
	}

	public void setInvoiceTitle(String invoiceTitle) {
		this.invoiceTitle = invoiceTitle;
	}

	public String getTaxNo() {
		return taxNo;
	}

	public void setTaxNo(String taxNo) {
		this.taxNo = taxNo;
	}

	public String getFirmId() {
		return firmId;
	}

	public void setFirmId(String firmId) {
		this.firmId = firmId;
	}

	public String getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}

	public Integer getBankID() {
		return bankID;
	}

	public void setBankID(Integer bankID) {
		this.bankID = bankID;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getInvoiceAddress() {
		return invoiceAddress;
	}

	public void setInvoiceAddress(String invoiceAddress) {
		this.invoiceAddress = invoiceAddress;
	}

	public String getInvoiceTel() {
		return invoiceTel;
	}

	public void setInvoiceTel(String invoiceTel) {
		this.invoiceTel = invoiceTel;
	}

	public BigDecimal getTaxRate() {
		return taxRate;
	}

	public void setTaxRate(BigDecimal taxRate) {
		this.taxRate = taxRate;
	}

	public BigDecimal getApplyQuantity() {
		return applyQuantity;
	}

	public void setApplyQuantity(BigDecimal applyQuantity) {
		this.applyQuantity = applyQuantity;
	}

	public BigDecimal getApplyPrice() {
		return applyPrice;
	}

	public void setApplyPrice(BigDecimal applyPrice) {
		this.applyPrice = applyPrice;
	}

	public BigDecimal getApplyMoney() {
		return applyMoney;
	}

	public void setApplyMoney(BigDecimal applyMoney) {
		this.applyMoney = applyMoney;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

}
