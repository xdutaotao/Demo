package shcem.finance.dao.impl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.jdbc.CannotGetJdbcConnectionException;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.constant.Constants;
import shcem.finance.ExportModel.InvoiceApply4Export;
import shcem.finance.ExportModel.InvoiceCollect4Export;
import shcem.finance.dao.IInvoiceDao;
import shcem.finance.dao.model.CouponApply;
import shcem.finance.dao.model.ExportInvoiceCollectDetail;
import shcem.finance.dao.model.FinancialBills;
import shcem.finance.dao.model.InvoiceApply4Check;
import shcem.finance.dao.model.InvoiceApplyRel;
import shcem.finance.dao.model.InvoiceCollectDetail;
import shcem.finance.dao.model.InvoiceCollectDetailRel;
import shcem.finance.dao.model.InvoiceDetailRel;
import shcem.trade.dao.model.Order;
import shcem.finance.dao.model.InvoiceApply;
import shcem.finance.dao.model.InvoiceDetail;
import shcem.member.dao.model.Firminvoice;
import shcem.util.CommonRowMapper;
/**
 * 发票相关
 * @author wangshuai
 *
 */
public class InvoiceDaoImpl extends BaseDAOImpl implements IInvoiceDao {

	/**
	 * financialBillsType开票状态 1：未申请  2：待财务处理 3：处理完成
	 */
	@Override
	public List<FinancialBills> getFinancialBillsList(QueryConditions qc,
			PageInfo pageInfo,int financialBillsType) {
		String sql = this.sqlProperty.getProperty("FinancialBillsDAO_001")+" where 1=1";
		List<FinancialBills> list = new ArrayList<FinancialBills>();
		try {
			list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new FinancialBills()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public int insertInvoiceCollectDetail(InvoiceCollectDetail invoiceCollectDetail) {
		String sql = sqlProperty.getProperty("InvoiceDao_001");
		Object[] params = {
				invoiceCollectDetail.getInvoiceType(),
				invoiceCollectDetail.getInvoiceNo(),
				invoiceCollectDetail.getInvoiceDate(),
				invoiceCollectDetail.getInvoiceTitle(),
				invoiceCollectDetail.getTaxNo(),
				invoiceCollectDetail.getBankName(),
				invoiceCollectDetail.getBankAccount(),
				invoiceCollectDetail.getInvoiceAddress(),
				invoiceCollectDetail.getInvoiceTel(),
				invoiceCollectDetail.getInvoiceContent(),
				invoiceCollectDetail.getInvoiceQuantity(),
				invoiceCollectDetail.getInvoicePrice(),
				invoiceCollectDetail.getTaxRate(),
				invoiceCollectDetail.getInvoiceMoney(),
				invoiceCollectDetail.getInvoiceTax(),
				invoiceCollectDetail.getInvoiceTotalMoney(),
				invoiceCollectDetail.getCollectDate(),
				invoiceCollectDetail.getRemark(),
				0,
				invoiceCollectDetail.getREC_CREATEBY(),
				invoiceCollectDetail.getREC_MODIFYBY()
		};
		
		return this.queryForIntID(sql, params);
	}

	@Override
	public int updateInvoiceCollectDetailByID(InvoiceCollectDetail invoiceCollectDetail) {
		String sql = sqlProperty.getProperty("InvoiceDao_002");
		Object[] params = {
				invoiceCollectDetail.getInvoiceType(),
				invoiceCollectDetail.getInvoiceNo(),
				invoiceCollectDetail.getInvoiceDate(),
				invoiceCollectDetail.getInvoiceTitle(),
				invoiceCollectDetail.getTaxNo(),
				invoiceCollectDetail.getBankName(),
				invoiceCollectDetail.getBankAccount(),
				invoiceCollectDetail.getInvoiceAddress(),
				invoiceCollectDetail.getInvoiceTel(),
				invoiceCollectDetail.getInvoiceContent(),
				invoiceCollectDetail.getInvoiceQuantity(),
				invoiceCollectDetail.getInvoicePrice(),
				invoiceCollectDetail.getTaxRate(),
				invoiceCollectDetail.getInvoiceMoney(),
				invoiceCollectDetail.getInvoiceTax(),
				invoiceCollectDetail.getInvoiceTotalMoney(),
				invoiceCollectDetail.getCollectDate(),
				invoiceCollectDetail.getRemark(),
				invoiceCollectDetail.getREC_MODIFYBY(),
				invoiceCollectDetail.getId()
		};
		return this.updateBySQL(sql, params);
	}


//	@Override
//	public int updateInvoiceCollectDetailOfDISABLED(Integer id,Integer disabled,String modifyBy) {
//		String sql = sqlProperty.getProperty("InvoiceDao_003");
//		Object[] params = {
//				disabled,modifyBy,id
//		};
//		return this.updateBySQL(sql, params);
//	}
	
	@Override
	public InvoiceCollectDetail selectInvoiceCollectDetailByID(Integer id) {
		String sql = sqlProperty.getProperty("InvoiceDao_004");
		Object[] params = {id};
		return (InvoiceCollectDetail) this.queryForObject(sql, params, new CommonRowMapper(new InvoiceCollectDetail()));
	}

	@Override
	public int insertInvoiceCollectDetailRel(InvoiceCollectDetailRel invoiceCollectDetailRel) {
		String sql = sqlProperty.getProperty("InvoiceDao_005");
		Object[] params = {
				invoiceCollectDetailRel.getDetailID(),
				invoiceCollectDetailRel.getRelationID(),
				invoiceCollectDetailRel.getStatus(),
				0,
				invoiceCollectDetailRel.getREC_CREATEBY(),
				invoiceCollectDetailRel.getREC_MODIFYBY()
		};
		return this.updateBySQL(sql, params);
	}

	@Override
	public int updateInvoiceCollectDetailRelByID(InvoiceCollectDetailRel invoiceCollectDetailRel) {
		String sql = sqlProperty.getProperty("InvoiceDao_006");
		Object[] params = {
				invoiceCollectDetailRel.getDetailID(),
				invoiceCollectDetailRel.getRelationID(),
				invoiceCollectDetailRel.getStatus(),
				invoiceCollectDetailRel.getDISABLED(),
				invoiceCollectDetailRel.getREC_MODIFYBY()
		};
		return this.updateBySQL(sql, params);
	}

	@Override
	public int updateOrderOfInvoiceCollectStatus(String orderId,Integer invoiceCollectStatus, String modifyBy) {
		String sql = sqlProperty.getProperty("InvoiceDao_007");
		Object[] params = {
				invoiceCollectStatus,
				modifyBy,
				orderId
		};
		return this.updateBySQL(sql, params);
	}

	@Override
	public InvoiceCollectDetail countInvoiceTotalMoneyByOrderId(String orderId) {
		//BigDecimal allInvoiceTotalMoney = new BigDecimal(0);
		String sql = sqlProperty.getProperty("InvoiceDao_008");
		Object[] params = {orderId};
		InvoiceCollectDetail detail = (InvoiceCollectDetail) this.queryForObject(sql, params, new CommonRowMapper(new InvoiceCollectDetail()));
//		if (detail != null){
//			allInvoiceTotalMoney = detail.getAllInvoiceTotalMoney();
//		}
		return detail;
	}
	
	@Override
	public int updateInvoiceCollectDetailRelOfStatus(Integer id, Integer status,String modifyBy) {
		String sql = sqlProperty.getProperty("InvoiceDao_009");
		Object[] params = {
				status,modifyBy,id
		};
		return this.updateBySQL(sql, params);
	}

	@Override
	public List<InvoiceCollectDetail> selectInvoiceCollectDetailListByRelationID(
			String relationID) {
		String sql = sqlProperty.getProperty("InvoiceDao_010");
		Object[] params = {
				relationID
		};
		return this.queryBySQL(sql, params, null, new CommonRowMapper(new InvoiceCollectDetail()));
	}

	@Override
	public List<Order> selectOrderList(QueryConditions qc, PageInfo pageInfo) {
		String sql = sqlProperty.getProperty("InvoiceDao_011");
		List<Order> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new Order()));
		return list;
	}
	
	@Override
	public int addInvoiceApply(InvoiceApply invoiceApply,String userName) {
		this.log.info(this.getClass().getName()+" addInvoiceApply Start");
		String sql= this.sqlProperty.getProperty("FinancialBillsDAO_002");
		Object [] params ={
				invoiceApply.getCollectInvoiceAddress(),//收票地址
				invoiceApply.getCollectTel(),// 收票电话
				invoiceApply.getBranchName(),// 开票银行支行名称
				invoiceApply.getCollectInvoicePeople(),//收票人
				invoiceApply.getApplyType(),//开票类型
				invoiceApply.getInvoiceType(),//发票类型
				invoiceApply.getInvoiceTitle(),//发票抬头
				invoiceApply.getTaxNo(),//税号
				invoiceApply.getFirmId(),//交易商ID
				invoiceApply.getBankAccount(),//开票银行帐号
				invoiceApply.getBankID(),//开票银行ID
				invoiceApply.getBankName(),//开票银行
				invoiceApply.getInvoiceAddress(),//开票地址
				invoiceApply.getInvoiceTel()==null?"":invoiceApply.getInvoiceTel(),//开票电话
				invoiceApply.getTaxRate(),//税率
				invoiceApply.getApplyQuantity(),//开票数量（吨）
				invoiceApply.getApplyPrice() == null?new BigDecimal(0):invoiceApply.getApplyPrice(),//开票单价（元)
				invoiceApply.getApplyMoney(),//开票金额
				invoiceApply.getRemark(),//备注
				userName,//申请人
				invoiceApply.getApplyType()==10?0:1,//审批状态 1：已申请，待财务处理 5：已审批 ，10：已拒绝，
				0,//默认为 0：正常，1：失效
				userName,//创建人
				userName,//最后修改人
				invoiceApply.getApplyOrigin() == null?1:invoiceApply.getApplyOrigin()//开票申请来源 0:前台商城 1：化交后台*/
		};
		this.log.info(this.getClass().getName()+" addInvoiceApply 开票参数："+Arrays.asList(params));
		int invoiceApplyID = 0;
		try {
			invoiceApplyID = this.queryForIntID(sql, params);
		} catch (Exception e) {
			this.log.info(this.getClass().getName()+" 申请开票失败："+e.getMessage());
			invoiceApplyID = -1;
		}
		this.log.info(this.getClass().getName()+" addInvoiceApply End");
		return invoiceApplyID;
	}
	
	@Override
	public String addInvoiceApplyRel(int invoiceApplyID, String deliveryID,
			String userName) {
		String sql = this.sqlProperty.getProperty("FinancialBillsDAO_003");
		Object [] params = {
				invoiceApplyID,
				deliveryID,
				0,
				userName,
				userName
		};
		String returnCode = "";
		try {
			int returnCodes = this.updateBySQL(sql, params);
			returnCode = returnCodes+"";
		} catch (Exception e) {
			e.printStackTrace();
			returnCode = "-1";
		}
		return returnCode;
	}
	
	@Override
	public int getInvoiceApplyRelCount(String deliveryID, Integer invoiceType) {
		String sql = this.sqlProperty.getProperty("FinancialBillsDAO_004");
		Object [] params ={
				deliveryID,
				invoiceType
		};
		int count =0;
		try {
			count = this.queryForInt(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return count;
	}
	
	@Override
	public InvoiceApply getInvoiceDetail(String firmID) {
		String sql = this.sqlProperty.getProperty("FinancialBillsDAO_005");
		Object [] params = {
				firmID
		};
		InvoiceApply invoiceApply = (InvoiceApply) this.queryForObject(sql, params, new CommonRowMapper(new InvoiceApply()));
		return invoiceApply;
	}
	
	@Override
	public List<InvoiceApply> getInvoiceApplyList(QueryConditions qc,
			PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("FinancialBillsDAO_006");
		List<InvoiceApply> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new InvoiceApply()));
		if(list!= null && list.size() > 0){
			for (int i = 0; i < list.size(); i++) {
				list.get(i).setIsDetailed(true);
			}
		}
		return list;
	}
	
	
	@Override
	public List<InvoiceApply4Check> getInvoiceApply4CheckList(
			QueryConditions qc, PageInfo pageInfo,boolean replace) {
		String sql = this.sqlProperty.getProperty("FinancialBillsDAO_006");
		if(replace) sql = sql.replaceFirst("SELECT", "SELECT top "+Constants.EXPORT_MAX_COUNT+" ");
		List<InvoiceApply4Check> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new InvoiceApply4Check()));
		return list;
	}
	
	@Override
	public int updateInvoiceApply(int invoiceApplyID, int applyStatus) {
		String sql = this.sqlProperty.getProperty("FinancialBillsDAO_007");
		Object [] params={
				applyStatus,invoiceApplyID
		};
		int returnCode = this.updateBySQL(sql, params);
		return returnCode;
	}
	
	@Override
	public int deleteInvoiceDetailRel(int invoiceApplyRelID) {
		String sql = "delete from T_InvoiceDetailRel where ID in("+invoiceApplyRelID+")";
		Object [] params={};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode=-1;
		}
		return returnCode;
	}
	
	@Override
	public InvoiceApply getInvoiceApply(int invoiceApplyID) {
		this.log.info(this.getClass().getName()+" getInvoiceApply Start");
		String sql = "SELECT tina.*,tinar.ID as invoiceApplyRelID,tinar.RelationID as deliveryID  FROM  T_InvoiceApply tina "
				+ "INNER JOIN T_InvoiceApplyRel tinar ON tinar.InvoiceApplyID = tina.ID WHERE tina.ID ="+invoiceApplyID+" and tinar.DISABLED = 0";
		Object [] params = {};
		InvoiceApply invoiceApply = (InvoiceApply) this.queryForObject(sql, params, new CommonRowMapper(new InvoiceApply()));
		return invoiceApply;
	}
	
	/**
	 * 新增发票，来源：发票导入
	 */
	@Override
	public int addInvoiceDetail(InvoiceDetail invoiceDetail, String userName) {
		String sql = this.sqlProperty.getProperty("FinancialBillsDAO_008");
		Object [] params = {
				invoiceDetail.getInvoiceType(),//发票类型，1增值税发票,5普通发票		InvoiceType										
				invoiceDetail.getInvoiceNo(),//发票号								InvoiceNo										
//				invoiceDetail.get,//发票日期								InvoiceDate										
				invoiceDetail.getInvoiceTitle(),//发票抬头								InvoiceTitle										
				invoiceDetail.getTaxNo(),//税号								TaxNo										
				invoiceDetail.getBankName(),//开票银行								BankName										
				invoiceDetail.getBankAccount(),//开票银行帐号								BankAccount										
				invoiceDetail.getInvoiceAddress(),//开票地址								InvoiceAddress										
				invoiceDetail.getInvoiceTel(),//开票电话								InvoiceTel										
				invoiceDetail.getInvoiceContent(),//发票内容								InvoiceContent										
				invoiceDetail.getInvoiceQuantity(),//发票数量（吨）								InvoiceQuantity										
				invoiceDetail.getInvoicePrice(),//发票单价（元)								InvoicePrice										
				invoiceDetail.getTaxRate(),//税率								TaxRate										
				invoiceDetail.getInvoiceMoney(),//发票金额								InvoiceMoney										
				invoiceDetail.getInvoiceTax(),//发票税额								InvoiceTax										
				invoiceDetail.getInvoiceTotalMoney(),//发票总额（含税）								InvoiceTotalMoney										
				invoiceDetail.getTrackingNo(),//快递单号								TrackingNo										
				invoiceDetail.getRemark(),//备注								Remark										
				0,//默认为 0：正常，1：失效								DISABLED										
				userName,//创建人								REC_CREATEBY										
//				//创建时间								REC_CREATETIME										
				userName//最后修改人								REC_MODIFYBY										
//				//最后修改时间								REC_MODIFYTIME										
				
		};
		int returnCode;
		try {
			returnCode = this.queryForIntID(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public int addInvoiceDetailRel(int invoiceDetailID, Integer applyRelID,
			String userName) {
		String sql = this.sqlProperty.getProperty("FinancialBillsDAO_009");
		Object [] params = {
				invoiceDetailID,
				applyRelID,
				0,
				userName,
				userName
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode =-1;
		}
		return returnCode;
	}
	
	@Override
	public int getInvoiceDetailCount(String invoiceNo) {
		String sql = "select count(*) from T_InvoiceDetail where InvoiceNo='"+invoiceNo+"' and DISABLED=0";
		int count = this.queryForInt(sql);
		return count;
	}
	
	@Override
	public int updateInvoiceDetail(String trackingNo, String invoiceNo,
			String userName) {
		String sql = "update T_InvoiceDetail set TrackingNo='"+trackingNo+"',REC_MODIFYBY='"+userName+"',REC_MODIFYTIME=GETDATE()"
				+ " where InvoiceNo='"+invoiceNo+"'";
		Object [] params = {};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode =-1;
		}
		return returnCode;
	}
	
	@Override
	public int updateInvoiceApplyStatus(Integer applyRelID, int applyStatus,String userName) {
		String sql = "update T_InvoiceApply set ApplyStatus="+applyStatus+",REC_MODIFYBY='"+userName+"',REC_MODIFYTIME=GETDATE()"
				+ " where ID="+applyRelID+"";
		Object [] params = {};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode =-1;
		}
		return returnCode;
	}
	
	@Override
	public List<InvoiceDetailRel> getInvoiceDetailRel(int invoiceApplyID) {
		String sql = "select tind.* from T_InvoiceDetailRel  tind INNER JOIN  T_InvoiceApplyRel  tina ON tind.ApplyRelID = tina.ID"
				+ " where tina.InvoiceApplyID="+invoiceApplyID+"";
		Object [] params = {};
		List<InvoiceDetailRel> list= this.queryBySQL(sql, params, null, new CommonRowMapper(new InvoiceDetailRel()));
		return list;
	}
	
	@Override
	public int disabledInvoiceDetail(Integer invoiceDetailID) {
		String sql = "update T_InvoiceDetail set DISABLED="+1+"where ID="+invoiceDetailID+"";
		Object [] params = {};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode =-1;
		}
		return returnCode;
	}
	@Override
	public void rollBack() {
		try {
			getConnection().setAutoCommit(false);//事务设置为手动
			getConnection().rollback();
		} catch (CannotGetJdbcConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public InvoiceCollectDetailRel selectInvoiceCollectDetailRelById(Integer id) {
		String sql = sqlProperty.getProperty("InvoiceDao_012");
		Object[] params = {id};
		return (InvoiceCollectDetailRel) this.queryForObject(sql, params, new CommonRowMapper(new InvoiceCollectDetailRel()));
	}

	@Override
	public List<InvoiceCollect4Export> exportInvoiceCollectDetailList(QueryConditions qc,
			PageInfo pageInfo,boolean replace) {
		String sql = sqlProperty.getProperty("InvoiceDao_013");
		if(replace)sql = sql.replaceFirst("select","select top "+Constants.EXPORT_MAX_COUNT+" ");
		List<InvoiceCollect4Export> list= this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new InvoiceCollect4Export()));
		return list;
	}

	@Override
	public int disabledInvoiceApplyRelByInvoiceApplyID(Integer invoiceApplyID,
			String userName) {
		String sql = sqlProperty.getProperty("InvoiceDao_014");
		Object[] params = {1,userName,invoiceApplyID};
		return this.updateBySQL(sql, params);
	}

	@Override
	public int disabledInvoiceDetailRelByApplyRelID(
			Integer ApplyRelID, String userName) {
		String sql = sqlProperty.getProperty("InvoiceDao_015");
		Object[] params = {1,userName,ApplyRelID};
		return this.updateBySQL(sql, params);
	}

	@Override
	public List<InvoiceApplyRel> getInvoiceApplyRelByInvoiceApplyID(
			Integer invoiceApplyID) {
		String sql = sqlProperty.getProperty("InvoiceDao_016");
		Object[] params = {invoiceApplyID};
		List<InvoiceApplyRel> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new InvoiceApplyRel()));
		return list;
	}
	
	@Override
	public List<Firminvoice> getfirmInvoicePlaceList(String firmID) {
		String sql = this.sqlProperty.getProperty("InvoiceDao_017");
		Object [] params = {
				firmID
		};
		List<Firminvoice> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new Firminvoice()));
		return list;
	}
	
	@Override
	public int disOrEnabled(String deliveryID, String tableField, int enabled,
			String userName) {
		this.log.info(this.getClass().getName()+" disOrEnabled Start");
		String sql = "update T_Delivery set "+tableField+"="+enabled+",REC_MODIFYBY='"+userName+"',REC_MODIFYTIME=GETDATE() where deliveryID='"+deliveryID+"'"
				+ " and "+tableField+" !="+enabled;
		Object [] params = {};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" disOrEnabled: "+e.getMessage());
			returnCode = -1;
		}
		this.log.info(this.getClass().getName()+" disOrEnabled End");
		return returnCode;
	}
	
	/**
	 * 开票详情修改(未开票完成能修改)
	 */
	@Override
	public int updateInvoiceApplyDetail(InvoiceApply invoiceApply,
			String userName) {
		this.log.info(this.getClass().getName()+" updateInvoiceApplyDetail Start");
		String sql = this.sqlProperty.getProperty("InvoiceDao_018");
		Object [] param = {
				invoiceApply.getInvoiceTitle(),//发票抬头
				invoiceApply.getTaxNo(),//税号
				invoiceApply.getBankAccount(),//开户银行账号
				invoiceApply.getBankID(),//开票银行ID
				invoiceApply.getBankName(),//开票银行名称
				invoiceApply.getInvoiceAddress(),//开票地址
				invoiceApply.getBranchName(),//开票银行支行名称
				invoiceApply.getInvoiceTel(),//开票电话
				invoiceApply.getCollectInvoiceAddress(),//收票地址
				invoiceApply.getCollectTel(),//收票电话
				invoiceApply.getCollectInvoicePeople(),//收票人(收件人姓名)
				invoiceApply.getTaxRate(),//税率
				invoiceApply.getRemark(),//备注
				userName,//修改人
				invoiceApply.getId()
				
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, param);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" updateInvoiceApplyDetail: "+e.getMessage());
			returnCode = -1;
		}
		this.log.info(this.getClass().getName()+" updateInvoiceApplyDetail End");
		return returnCode;
	}
	
	@Override
	public int getInvoiceApplyList4ExportCount(QueryConditions qc) {
		this.log.info(this.getClass().getName()+" getInvoiceApplyList4ExportCount Start");
		String sql = this.sqlProperty.getProperty("FinancialBillsDAO_006");
		int totalRecords = 0;
		totalRecords = getTotalCount(sql,qc);
		this.log.info(this.getClass().getName()+" getInvoiceApplyList4ExportCount End");
		return totalRecords;
	}
	
	@Override
	public List<InvoiceApply4Export> getInvoiceApplyList4Export(
			QueryConditions qc, PageInfo pageInfo,boolean replace) {
		String sql = this.sqlProperty.getProperty("FinancialBillsDAO_006");
		if(replace)sql = sql.replaceFirst("SELECT", "SELECT top "+Constants.EXPORT_MAX_COUNT+" ");
		List<InvoiceApply4Export> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new InvoiceApply4Export()));
		if(list!= null && list.size() > 0){
			for (int i = 0; i < list.size(); i++) {
				list.get(i).setIsDetailed(true);
			}
		}
		return list;
	}
	
	@Override
	public int getExportInvoiceCollectDetailCount(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+" getExportInvoiceCollectDetailCount Start");
		String sql = this.sqlProperty.getProperty("InvoiceDao_013");
		int totalRecords = 0;
		totalRecords = getTotalCount(sql,qc);
		this.log.info(this.getClass().getName()+" getExportInvoiceCollectDetailCount End");
		return totalRecords;
	}
	/**
	 * 
	 * @param qc
	 * @param pageInfo
	 * @param invoiceStatus 充值型优惠券列表展示位置：0展示在"开票管理"页面 2 展示在"开票申请流水"页面 
	 * @return
	 */
	@Override
	public List<InvoiceApply> getCouponInvoiceApplyListByCustomer(
			QueryConditions qc, PageInfo pageInfo,int invoiceStatus) {
		this.log.info(this.getClass().getName()+" getCouponInvoiceApplyListByCustomer Start");
		String sql = this.sqlProperty.getProperty("InvoiceDao_019");
		if(invoiceStatus == 2 ) sql = sql+" AND temp.ApplyStatus != 0";
		List<InvoiceApply> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new InvoiceApply()));
		this.log.info(this.getClass().getName()+" getCouponInvoiceApplyListByCustomer Start");
		return list;
	}
	
	@Override
	public int updateCouponInvoiceApplyListByCustomer(
			InvoiceApply invoiceApply, int invoiceApplyID, String userName) {
		this.log.info(this.getClass().getName()+" updateCouponInvoiceApplyListByCustomer Start");
		int returnCode = 0;
		String sql = this.sqlProperty.getProperty("InvoiceDao_020");
		Object[] params = {
				invoiceApply.getCollectInvoiceAddress(),//收票地址
				invoiceApply.getCollectTel(),// 收票电话
				invoiceApply.getBranchName(),// 开票银行支行名称
				invoiceApply.getCollectInvoicePeople(),//收票人
				invoiceApply.getInvoiceType(),//发票类型
				invoiceApply.getInvoiceTitle(),//发票抬头
				invoiceApply.getTaxNo(),//税号
				invoiceApply.getBankAccount(),//开票银行帐号
				invoiceApply.getBankID(),//开票银行ID
				invoiceApply.getBankName(),//开票银行
				invoiceApply.getInvoiceAddress(),//开票地址
				invoiceApply.getInvoiceTel()==null?"":invoiceApply.getInvoiceTel(),//开票电话
				invoiceApply.getTaxRate(),//税率
				invoiceApply.getRemark(),//备注
				userName,//申请人
				1,//审批状态 1：已申请，待财务处理 5：已审批 ，10：已拒绝，
				userName,//最后修改人
				invoiceApplyID //主键
		};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" 增值性优惠券开票后台修改失败:"+e.getMessage());
			returnCode = -1;
		}
		
		this.log.info(this.getClass().getName()+" updateCouponInvoiceApplyListByCustomer End");
		return returnCode;
	}
	
	@Override
	public int updateIsInvoiceOpen(int invoiceApplyID, String userName,int IsInvoiceOpen) {
		this.log.info(this.getClass().getName()+" updateIsInvoiceOpen Start");
		int returnCode = 0;
		String sql = this.sqlProperty.getProperty("InvoiceDao_021");
		Object[] params = {
				IsInvoiceOpen,
				userName,
				invoiceApplyID	
		};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" 开启 审核前台客户申请的开票信息(置标)失败:"+e.getMessage());
			returnCode = -1;
		}
		this.log.info(this.getClass().getName()+" updateIsInvoiceOpen End");
		return returnCode;
	}

	@Override
	public int getCouponInvoiceApplyListByCustomerCount(QueryConditions qc) {
		this.log.info(this.getClass().getName()+" getInvoiceApplyList4ExportCount Start");
		String sql = this.sqlProperty.getProperty("InvoiceDao_019");
		sql = sql+" AND temp.ApplyStatus != 0";
		int totalRecords = 0;
		totalRecords = getTotalCount(sql,qc);
		this.log.info(this.getClass().getName()+" getInvoiceApplyList4ExportCount End");
		return totalRecords;
	}
	
	@Override
	public List<InvoiceApply4Export> getCouponInvoiceApplyList4Export(
			QueryConditions qc, PageInfo pageInfo, boolean replace,
			int invoiceStatus) {
		this.log.info(this.getClass().getName()+" getCouponInvoiceApplyList4Export Start");
		String sql = this.sqlProperty.getProperty("InvoiceDao_019");
		sql = sql+" AND temp.ApplyStatus != 0";
		if(replace)sql = sql.replaceFirst("SELECT", "SELECT top "+Constants.EXPORT_MAX_COUNT+" ");
		List<InvoiceApply4Export> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new InvoiceApply4Export()));
		this.log.info(this.getClass().getName()+" getCouponInvoiceApplyList4Export End");
		return list;
	}

	@Override
	public Order getOrderInvoiceCollectDetail(String orderId) {
		this.log.info(this.getClass().getName()+" getOrderInvoiceCollectDetail Start");
		String sql = sqlProperty.getProperty("InvoiceDao_022");
		Object[] params = {orderId};
		Order order = (Order) this.queryForObject(sql, params, new CommonRowMapper(new Order()));
		this.log.info(this.getClass().getName()+" getOrderInvoiceCollectDetail End");
		return order;
	}
}
