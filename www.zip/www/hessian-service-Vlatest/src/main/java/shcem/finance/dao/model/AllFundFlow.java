/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: AllFundFlow
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.model;

import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * (AllFundFlow)
 * 
 * @author wlpod
 * @version 1.0.0 2016-05-12
 */
public class AllFundFlow extends BaseObject implements java.io.Serializable, Cloneable {

	private static final long serialVersionUID = -7464587171301763763L;

	
	private String operCode;
	private BigDecimal amount;
	private String balance;
	private String balanceS;
	private Date createtime;
	private String objectID;
	private Integer flowType;
	private String operName;
	private String fUNDDCFLAG;
	private String accountType;
	
	

	public String getBalanceS() {
		return balanceS;
	}

	public void setBalanceS(String balanceS) {
		this.balanceS = balanceS;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getFUNDDCFLAG() {
		return fUNDDCFLAG;
	}

	public void setFUNDDCFLAG(String fUNDDCFLAG) {
		this.fUNDDCFLAG = fUNDDCFLAG;
	}

	public String getOperName() {
		return operName;
	}

	public void setOperName(String operName) {
		this.operName = operName;
	}

	public String getOperCode() {
		return operCode;
	}

	public void setOperCode(String operCode) {
		this.operCode = operCode;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getObjectID() {
		return objectID;
	}

	public void setObjectID(String objectID) {
		this.objectID = objectID;
	}

	public Integer getFlowType() {
		return flowType;
	}

	public void setFlowType(Integer flowType) {
		this.flowType = flowType;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}