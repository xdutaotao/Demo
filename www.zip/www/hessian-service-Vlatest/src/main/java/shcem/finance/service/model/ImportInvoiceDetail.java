package shcem.finance.service.model;

import java.math.BigDecimal;
import java.util.List;

/**
 * Excel 导入发票详情
 * @author sunf
 *
 */
public class ImportInvoiceDetail {
	
	/*发票号码*/
	private String[] invoiceNo;
	/*关联单号*/
	private Integer relationNo;
	/*单位名称*/
	private String companyName;
	/*产品名称*/
	private String productName;
	/*规格型号*/
	private String brandName;
	/*计量单位*/
	private String unit;
	/*产品数量*/
	private BigDecimal quantity;
	/*单价*/
	private BigDecimal price;
	/*总价*/
	private BigDecimal totalMoney;
	/*税率*/
	private BigDecimal taxRate;
	/*备注*/
	private String remark;
	/*发票类型*/
	private Integer invoiceType;
	/*快递单号*/
	private String trackingNo;
	
	
	public String[] getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String[] invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public Integer getRelationNo() {
		return relationNo;
	}
	public void setRelationNo(Integer relationNo) {
		this.relationNo = relationNo;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public BigDecimal getQuantity() {
		return quantity;
	}
	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	public BigDecimal getTotalMoney() {
		return totalMoney;
	}
	public void setTotalMoney(BigDecimal totalMoney) {
		this.totalMoney = totalMoney;
	}
	public BigDecimal getTaxRate() {
		return taxRate;
	}
	public void setTaxRate(BigDecimal taxRate) {
		this.taxRate = taxRate;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Integer getInvoiceType() {
		return invoiceType;
	}
	public void setInvoiceType(Integer invoiceType) {
		this.invoiceType = invoiceType;
	}
	public String getTrackingNo() {
		return trackingNo;
	}
	public void setTrackingNo(String trackingNo) {
		this.trackingNo = trackingNo;
	}
}
