/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: PaymentServiceImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月15日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.service.impl;

import gnnt.trade.bank.util.ObjSet;
import gnnt.trade.bank.vo.BankValue;
import gnnt.trade.bank.vo.CapitalValue;
import gnnt.trade.bank.vo.CorrespondValue;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.finance.component.IFirmBanlanceManager;
import shcem.finance.component.IVoucherOraManager;
import shcem.finance.dao.model.FBanks;
import shcem.finance.dao.model.FeeModel;
import shcem.finance.dao.model.FirmValue;
import shcem.finance.dao.model.TEnquiry;
import shcem.finance.dao.model.TLeads;
import shcem.finance.service.IPaymentService;
import shcem.finance.service.model.AbcSignInfoModel;
import shcem.finance.service.model.AssignBankModel;
import shcem.finance.service.model.CapitalModel;
import shcem.finance.service.model.CorrespondModel;
import shcem.finance.util.BankInterfaceRMI;
import shcem.finance.util.FinanceOraSysData;
import shcem.finance.util.FinanceSysData;
import shcem.util.Common;
import shcem.util.JsonUtil;

/**
 * @author wlpod
 *
 */
public class PaymentServiceImpl extends BaseServiceImpl implements IPaymentService {

	private IFirmBanlanceManager balanceMgr = (IFirmBanlanceManager) FinanceSysData.getBean(Constants.BEAN_BALANCE_MGR);
	private IVoucherOraManager mgrOra = (IVoucherOraManager) FinanceOraSysData.getBean(Constants.BEAN_VOUCHERORA_MGR);

	@Override
	public String addDepositBuyer(String params) {
		this.log.info(this.getClass().getName() + " addDepositBuyer() Start");

		try {
			JSONObject JOParams = new JSONObject(params);
			String orderId = JOParams.optString("orderId");

			// 买家 补交保证金
			int result = balanceMgr.addDepositBuyer(orderId);

			if (result == -1) {
				setResultData("23007", null);
				this.log.businesslog("买方交易商余额不足!", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			} else if (result == -2) {
				setResultData("10112", null, "买方补交保证金失败！");
				this.log.businesslog("买方补交保证金失败！", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			} else {
				setResultData("00000", null);
				this.log.businesslog("买方补交保证金成功！", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
			}
		} catch (Exception e) {
			this.log.debug(e.getMessage());
			this.log.debug("addDepositBuyer发生Exception");
			setResultData("10112", null, "买方补交保证金发生异常！");
		}

		this.log.info(this.getClass().getName() + " addDepositBuyer() End");
		return rtnData.toString();
	}

	@Override
	public String addDepositSeller(String params) {
		this.log.info(this.getClass().getName() + " addDepositSeller() Start");

		try {
			JSONObject JOParams = new JSONObject(params);
			String orderId = JOParams.optString("orderId");

			// 上家 预售 补交保证金
			int result = balanceMgr.addDepositSeller(orderId);

			if (result == -1) {
				setResultData("23007", null);
				this.log.businesslog("卖方交易商余额不足!", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			} else if (result == -2) {
				setResultData("10112", null, "卖方补交保证金失败！");
				this.log.businesslog("卖方补交保证金失败！", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			} else {
				setResultData("00000", null);
				this.log.businesslog("卖方补交保证金成功！", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
			}
		} catch (Exception e) {
			this.log.debug(e.getMessage());
			this.log.debug("addDepositSeller发生Exception");
			setResultData("10112", null, "卖方补交保证金发生异常！");
		}

		this.log.info(this.getClass().getName() + " addDepositSeller() End");
		return rtnData.toString();
	}

	@Override
	public String payForCouPon(String params) {
		this.log.info(this.getClass().getName() + " payForCouPon() Start");

		try {
			JSONObject JOParams = new JSONObject(params);
			log.debug("firmId = " + JOParams.optString("firmId"));
			log.debug("payMoney = " + JOParams.optString("payMoney"));
			log.debug("contractno = " + JOParams.optString("contractno"));
			String firmId = JOParams.optString("firmId");
			BigDecimal payMoney = new BigDecimal(JOParams.optString("payMoney"));
			String contractno = JOParams.optString("contractno");

			int result = balanceMgr.payForCouPon(firmId, payMoney, contractno, "system");

			if (result == -4 || result == -8) {
				setResultData("23003", null);
				this.log.businesslog("扣款账户余额不足!", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			} else if (result < 0) {
				setResultData("10112", null, "兑换优惠券时资金支付失败！");
				this.log.businesslog("兑换优惠券时资金支付失败！", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			} else {
				setResultData("00000", null);
				this.log.businesslog("兑换优惠券时资金支付成功！", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
			}
		} catch (Exception e) {
			this.log.debug(e.getMessage());
			this.log.debug("payForCouPon发生Exception");
			setResultData("10112", null, "资金扣除时发生异常!");
		}

		this.log.info(this.getClass().getName() + " payForCouPon() End");
		return rtnData.toString();
	}

	/**
	 * 根据报盘ID扣除相应保证金手续费并生成资金流水
	 * 
	 * @param params
	 * @return
	 */
	public String payMoney(String params) {
		this.log.info(this.getClass().getName() + " payMoney() Start");

		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		this.log.debug(JOParams.toString());

		String orderId = JOParams.optString("orderId");
		boolean couponFlg = JOParams.optBoolean("couponFlg");
		String Operator = JOParams.optString("Operator");

		// 抵扣型优惠券抵扣手续费金额
		String strCouponAmount = JOParams.optString("couponAmount");
		BigDecimal couponAmount = BigDecimal.ZERO;
		if (!Common.isEmpty(strCouponAmount)) {
			couponAmount = new BigDecimal(strCouponAmount);
		}

		this.log.debug("orderId, couponFlg, Operator, couponAmount = " + orderId + "," + couponFlg + "," + Operator
				+ "," + couponAmount);
		HashMap map = balanceMgr.PaymentBuyer(orderId, couponFlg, Operator, couponAmount);

		this.log.debug("payMoney() map = " + map.toString());

		int result = Integer.parseInt(map.get("result").toString());

		// 支付保证金手续费
		if (result == -1) {
			setResultData("23002", null);
			this.log.businesslog("买方交易商余额不足!", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		} else if (result == -2) {
			setResultData("10112", null, "支付保证金手续费失败！");
			this.log.businesslog("支付保证金手续费失败！", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		} else {
			FeeModel feeModel = (FeeModel) map.get("feeModel");
			BigDecimal[] firmBalances = (BigDecimal[]) map.get("firmBalances");
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("Fee", feeModel.getTakenFee());
			jsonObj.put("TakenMoney", feeModel.getTakenMoney());
			jsonObj.put("CouponFee", feeModel.getCouponFee().add(couponAmount));
			jsonObj.put("FirmBalance", firmBalances[0]);
			jsonObj.put("LateFee", (BigDecimal) map.get("LateFee"));
			setResultData("00000", jsonObj);
			this.log.businesslog("支付保证金手续费成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		}

		this.log.info(this.getClass().getName() + " payMoney() End");
		return rtnData.toString();
	}

	/**
	 * 根据报盘ID扣除相应保证金手续费并生成资金流水
	 * 
	 * @param params
	 * @return
	 */
	public String paymentByLeadsID(String params) {
		this.log.info(this.getClass().getName() + " paymentByLeadsID() Start");
		JSONObject JOParams = new JSONObject(params);
		Long leadsId = JOParams.getLong("leadsId");

		// 支付保证金手续费
		int result = 0;
		result = balanceMgr.payMoneyByleadsId(leadsId);
		if (result == -1) {
			setResultData("23007", null);
			this.log.businesslog("报盘方交易商余额不足!", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		} else if (result == -2) {
			setResultData("10112", null);
			this.log.businesslog("系统出错，联系管理员!", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		} else {
			setResultData("00000", null);
			this.log.businesslog("支付保证金手续费成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		}

		this.log.info(this.getClass().getName() + " paymentByLeadsID() End");
		return rtnData.toString();
	}

	/**
	 * 根据报盘ID扣除相应保证金手续费并生成资金流水
	 * 
	 * @param params
	 * @return
	 */
	public String modifyLeads(String params) {
		this.log.info(this.getClass().getName() + " modifyLeads() Start");
		JSONObject JOParams = new JSONObject(params);
		Long leadsId = JOParams.getLong("leadsId");

		// 支付保证金手续费
		int result = 0;
		result = balanceMgr.modifyLeads(leadsId);
		if (result == -1) {
			setResultData("23007", null);
			this.log.businesslog("报盘方交易商余额不足!", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		} else if (result == -2) {
			setResultData("10112", null);
			this.log.businesslog("系统出错，联系管理员!", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		} else {
			setResultData("00000", null);
			this.log.businesslog("支付保证金手续费成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		}

		this.log.info(this.getClass().getName() + " modifyLeads() End");
		return rtnData.toString();
	}

	/**
	 * 根据询盘ID扣除相应保证金手续费并生成资金流水
	 * 
	 * @param params
	 * @return
	 */
	public String paymentByEnquiryID(String params) {
		this.log.info(this.getClass().getName() + " paymentByEnquiryID() Start");
		JSONObject JOParams = new JSONObject(params);
		Long enquiryId = JOParams.getLong("enquiryId");

		// 支付保证金手续费
		int result = 0;
		result = balanceMgr.payMoneyByEnquiryId(enquiryId);
		if (result == -1) {
			setResultData("23002", null);
			this.log.businesslog("询盘方交易商余额不足!", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		} else if (result == -2) {
			setResultData("10112", null);
			this.log.businesslog("系统出错，联系管理员!", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		} else {
			setResultData("00000", null);
			this.log.businesslog("支付保证金手续费成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		}

		this.log.info(this.getClass().getName() + " paymentByEnquiryID() End");
		return rtnData.toString();
	}

	/**
	 * 成交时 补退/收，买/卖方的保证金，手续费。
	 * 
	 * @param params
	 * @return
	 */
	public String paymentByOrderID(String params) {
		this.log.info(this.getClass().getName() + " paymentByOrderID() Start");
		JSONObject JOParams = new JSONObject(params);
		String orderId = JOParams.getString("orderId");

		int result = balanceMgr.payMoneyByOrderId(orderId);

		// 支付保证金手续费
		if (result == -2) {
			setResultData("23002", null);
			this.log.businesslog("询盘方交易商余额不足!", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		} else if (result == -4) {
			setResultData("23007", null);
			this.log.businesslog("报盘方交易商余额不足!", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		} else if (result != 0) {
			setResultData("10112", null, "支付保证金手续费失败！");
			this.log.businesslog("支付保证金手续费失败！", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		} else {
			setResultData("00000", null);
			this.log.businesslog("支付保证金手续费成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		}

		this.log.info(this.getClass().getName() + " paymentByOrderID() End");
		return rtnData.toString();
	}

	/**
	 * 根据交收数据，权限校验，资金校验，收买方货款，退买/卖方交易手续费，收买/卖方交收手续费，退买/卖方交易保证金，收买/卖方交易保证金（对应数量比例
	 * ），生成相应流水， 更新交收表的已收买/卖方保证金，已收买/卖方手续费，已收买方货款字段
	 * 
	 * @param params
	 * @return
	 */
	@Override
	public String paymentForDelivery(String params) {
		setResultData("10104", null, "此接口已失效！");
		return rtnData.toString();
		// this.log.info(this.getClass().getName() +
		// " paymentForDelivery() Start");
		// JSONObject JOParams = new JSONObject(params);
		// String deliveryId = JOParams.getString("deliveryId");
		//
		// // 交易商资金校验
		// if (!balanceMgr.chkFirmFundsForDelivery(deliveryId)) {
		// setResultData("23001", deliveryId);
		// return rtnData.toString();
		// }
		//
		// // 支付保证金手续费
		// if (!balanceMgr.payMoneyByDeliveryId(deliveryId)) {
		// setResultData("10106", null, "支付费用失败！");
		// this.log.businesslog("支付费用失败！", Constants.OPE_MODE_FINANCE,
		// Constants.OPE_FAIL);
		// } else {
		// setResultData("00000", null);
		// this.log.businesslog("支付费用成功", Constants.OPE_MODE_FINANCE,
		// Constants.OPE_SUCCESS);
		// }
		//
		// this.log.info(this.getClass().getName() +
		// " paymentForDelivery() End");
		// return rtnData.toString();
	}

	/**
	 * 报盘撤盘退回保证金，手续费
	 * 
	 * @param params
	 * @return
	 */
	@Override
	public String backByLeadsID(String params) {
		this.log.info(this.getClass().getName() + " backByLeadsID() Start");
		JSONObject JOParams = new JSONObject(params);
		Long leadsId = JOParams.getLong("leadsId");

		// 退保证金手续费
		if (!balanceMgr.backByLeadsID(leadsId)) {
			setResultData("10112", null, "退还保证金手续费失败！");
			this.log.businesslog("退还保证金手续费失败！", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		} else {
			setResultData("00000", null);
			this.log.businesslog("退还保证金手续费成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		}

		this.log.info(this.getClass().getName() + " backByLeadsID() End");
		return rtnData.toString();
	}

	/**
	 * 询盘撤盘退回保证金，手续费
	 * 
	 * @param params
	 * @return
	 */
	@Override
	public String backByEnquiryID(String params) {
		this.log.info(this.getClass().getName() + " backByEnquiryID() Start");
		JSONObject JOParams = new JSONObject(params);
		Long enquiryId = JOParams.getLong("enquiryId");

		// 退保证金手续费
		if (!balanceMgr.backByEnquiryID(enquiryId)) {
			setResultData("10112", null, "退还保证金手续费失败！");
			this.log.businesslog("退还保证金手续费失败！", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		} else {
			setResultData("00000", null);
			this.log.businesslog("退还保证金手续费成功", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		}

		this.log.info(this.getClass().getName() + " backByEnquiryID() End");
		return rtnData.toString();
	}

	@Override
	public String inMoney(String params) {
		this.log.info(this.getClass().getName() + " inMoney() Start");
		JSONObject JOParams = new JSONObject(params);
		String bankID = JOParams.getString("bankID");
		String firmID = JOParams.getString("firmID");
		// bankID = "10";
		// firmID = "0215888";

		BigDecimal money = new BigDecimal(JOParams.getString("money"));
		FBanks bVal = mgrOra.getBank(bankID);
		FirmValue fVal = mgrOra.getFirm(firmID);
		double auditBalance = bVal.getMaxAuditMoney().doubleValue();
		if (fVal != null && fVal.maxAuditMoney > 0)
			auditBalance = fVal.maxAuditMoney;
		try {
			String ret = "";
			if ("86".equals(bankID)) {
				// 农行出入金时取得签名信息
				long requestID = JOParams.getLong("requestID");
				String signInfo = JOParams.getString("signInfo");
				// 调用农行出入金专用接口
				ret = BankInterfaceRMI.inoutMoneyForAbc(requestID, money, firmID, 0, bankID, "", signInfo, 0,
						auditBalance, getMode());
			} else {
				ret = BankInterfaceRMI.inoutMoney(money, firmID, 0, bankID, "", "", 0, auditBalance, getMode());
			}

			String errCode = ret.split(":")[0];
			String errMsg = ret.split(":")[1];
			this.log.debug(errMsg);

			if (Long.parseLong(errCode) >= 0) {
				setResultData("00000", null, "入金成功！");
				this.log.businesslog("入金成功！", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
			} else {
				setResultData("10112", null, "入金失败！");
				this.log.businesslog("入金失败！", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			}
		} catch (Exception e) {
			this.log.debug(e.getMessage());
			this.log.businesslog("入金失败！", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " inMoney() End");
		return rtnData.toString();

		// setResultData("00000", null, "入金成功！(假)");
		// return rtnData.toString();
	}

	@Override
	public String outMoney(String params) {
		this.log.info(this.getClass().getName() + " outMoney() Start");
		JSONObject JOParams = new JSONObject(params);
		String bankID = JOParams.getString("bankID");
		String firmID = JOParams.getString("firmID");
		// bankID = "10";
		// firmID = "0215888";

		BigDecimal money = new BigDecimal(JOParams.getString("money"));
		FBanks bVal = mgrOra.getBank(bankID);
		FirmValue fVal = mgrOra.getFirm(firmID);
		double auditBalance = bVal.getMaxAuditMoney().doubleValue();
		if (fVal != null && fVal.maxAuditMoney > 0)
			auditBalance = fVal.maxAuditMoney;
		try {
			String ret = "";
			if ("86".equals(bankID)) {
				// 农行出入金时取得签名信息
				long requestID = JOParams.getLong("requestID");
				String signInfo = JOParams.getString("signInfo");
				// 调用农行出入金专用接口
				ret = BankInterfaceRMI.inoutMoneyForAbc(requestID, money, firmID, 1, bankID, "", signInfo, 0,
						auditBalance, getMode());
			} else {
				ret = BankInterfaceRMI.inoutMoney(money, firmID, 1, bankID, "", "", 0, auditBalance, getMode());
			}
			String errCode = ret.split(":")[0];
			String errMsg = ret.split(":")[1];
			this.log.debug(errMsg);

			if (Long.parseLong(errCode) >= 0) {
				setResultData("00000", null, "出金成功！");
				this.log.businesslog("出金成功！", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
			} else if ("-30006".equals(errCode)) {
				setResultData("00000", null, "出金提交成功，等待交易所审核！");
				this.log.businesslog("出金提交成功，等待交易所审核！", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
			} else {
				setResultData("30000", null, errMsg);
				this.log.businesslog("出金失败！", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			}
		} catch (Exception e) {
			this.log.debug(e.getMessage());
			this.log.businesslog("出金失败！", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		}

		this.log.info(this.getClass().getName() + " outMoney() End");
		return rtnData.toString();

		// setResultData("00000", null, "出金成功！(假)");
		// return rtnData.toString();
	}

	@Override
	public String getAssignBankListByFirmID(String params) {
		this.log.info(this.getClass().getName() + " getAssignBankListByFirmID() Start");
		JSONObject JOParams = new JSONObject(params);
		String firmID = JOParams.getString("firmID");

		Vector<BankValue> ret = BankInterfaceRMI.getAssignBankListByFirmID(firmID, getMode());

		if (ret == null) {
			setResultData("10104", null, "取得交易商注册银行失败！");
			// this.log.businesslog("取得交易商注册银行失败！", Constants.OPE_MODE_FINANCE,
			// Constants.OPE_FAIL);
		} else {

			List<AssignBankModel> bankList = new ArrayList<AssignBankModel>();
			for (int i = 0; i < ret.size(); i++) {
				BankValue bankValue = ret.get(i);
				AssignBankModel tempMode = new AssignBankModel();
				tempMode.setBankID(bankValue.bankID);
				tempMode.setBankName(bankValue.bankName);
				tempMode.setBeginTime(bankValue.beginTime);
				tempMode.setControl(bankValue.control);
				tempMode.setEndTime(bankValue.endTime);
				tempMode.setMaxAuditMoney(bankValue.maxAuditMoney);
				tempMode.setMaxPerSglTransMoney(bankValue.maxPerSglTransMoney);
				tempMode.setMaxPerTransCount(bankValue.maxPerTransCount);
				tempMode.setMaxPerTransMoney(bankValue.maxPerTransMoney);
				tempMode.setValidFlag(bankValue.validFlag);
				tempMode.setAdapterClassname(bankValue.adapterClassname);
				bankList.add(tempMode);
			}

			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(bankList);

				jsonObj.put("total", ret.size());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
				// this.log.businesslog("取得交易商注册银行成功！",
				// Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10104", null, e.getMessage());
				// this.log.businesslog("取得交易商注册银行失败！",
				// Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			}
		}
		this.log.info(this.getClass().getName() + " getAssignBankListByFirmID() End");
		return rtnData.toString();
	}

	@Override
	public String getOneAssignBankByFirmID(String params) {
		this.log.info(this.getClass().getName() + " getOneAssignBankByFirmID() Start");
		JSONObject JOParams = new JSONObject(params);
		String firmID = JOParams.getString("firmID");

		Vector<BankValue> ret = BankInterfaceRMI.getAssignBankListByFirmID(firmID, getMode());

		if (ret == null) {
			setResultData("10104", null, "取得交易商注册银行失败！");
			// this.log.businesslog("取得交易商注册银行失败！", Constants.OPE_MODE_FINANCE,
			// Constants.OPE_FAIL);
		} else if (ret.size() == 0) {
			setResultData("10101", null, "交易商没有签约银行！");
			// this.log.businesslog("交易商没有签约银行！", Constants.OPE_MODE_FINANCE,
			// Constants.OPE_FAIL);
		} else {

			List<AssignBankModel> bankList = new ArrayList<AssignBankModel>();
			for (int i = 0; i < ret.size(); i++) {
				BankValue bankValue = ret.get(i);
				AssignBankModel tempMode = new AssignBankModel();
				tempMode.setBankID(bankValue.bankID);
				tempMode.setBankName(bankValue.bankName);
				tempMode.setBeginTime(bankValue.beginTime);
				tempMode.setControl(bankValue.control);
				tempMode.setEndTime(bankValue.endTime);
				tempMode.setMaxAuditMoney(bankValue.maxAuditMoney);
				tempMode.setMaxPerSglTransMoney(bankValue.maxPerSglTransMoney);
				tempMode.setMaxPerTransCount(bankValue.maxPerTransCount);
				tempMode.setMaxPerTransMoney(bankValue.maxPerTransMoney);
				tempMode.setValidFlag(bankValue.validFlag);
				tempMode.setAdapterClassname(bankValue.adapterClassname);
				bankList.add(tempMode);
			}

			JSONObject jsonObj;
			try {
				jsonObj = JsonUtil.coverModelToJSONObject(bankList.get(0));
				setResultData("00000", jsonObj);
				// this.log.businesslog("取得交易商注册银行成功！",
				// Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10104", null, e.getMessage());
				// this.log.businesslog("取得交易商注册银行失败！",
				// Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
			}
		}
		this.log.info(this.getClass().getName() + " getOneAssignBankByFirmID() End");
		return rtnData.toString();
	}

	@Override
	public String getCorrespond(String params) {
		this.log.info(this.getClass().getName() + " getCorrespond() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		String firmID = JOParams.optString("firmID");
		String bankID = JOParams.optString("bankID");

		Vector<CorrespondValue> cvList = null;

		try {
			cvList = BankInterfaceRMI.getCorrespond(firmID, bankID, getMode());
		} catch (Exception err) {
			this.log.error("取得交易商代码银行账户对应关系失败：" + err.getMessage());
			setResultData("10104", null, err.getMessage());
		}

		if (cvList == null) {
			setResultData("10104", null, "取得交易商注册银行失败！");
		} else if (cvList.size() == 0) {
			setResultData("10101", null, "交易商没有签约银行！");
		} else {
			try {
				CorrespondModel cm = new CorrespondModel();
				CorrespondValue cv = cvList.get(0);
				cm.setBankID(cv.bankID);
				cm.setFirmID(cv.firmID);
				cm.setAccount(cv.account);
				cm.setAccount1(cv.account1);
				cm.setAccountName(cv.accountName);
				cm.setAccountName1(cv.accountName1);
				cm.setBankName(cv.bankName);
				cm.setBankProvince(cv.bankProvince);
				cm.setBankCity(cv.bankCity);
				cm.setMobile(cv.mobile);
				cm.setEmail(cv.email);
				cm.setStatus(cv.status);
				cm.setIsOpen(cv.isOpen);
				cm.setCardType(cv.cardType);
				cm.setCard(cv.card);
				cm.setFrozenFuns(cv.frozenFuns);
				cm.setInMarketCode(cv.inMarketCode);
				cm.setOpentime(cv.opentime);
				cm.setDeltime(cv.deltime);
				cm.setOpenBankCode(cv.OpenBankCode);
				cm.setIsCrossLine(cv.isCrossLine);

				JSONObject jsonObj = new JSONObject();
				jsonObj = JsonUtil.coverModelToJSONObject(cm);
				setResultData("00000", jsonObj);

			} catch (Exception e) {
				this.log.error("交易商代码银行账户对应关系转换失败：" + e.getMessage());
				setResultData("10104", null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getCorrespond() End");
		return rtnData.toString();
	}

	@Override
	public String getFirmBankBalance(String params) {
		this.log.info(this.getClass().getName() + " getFirmBankBalance() Start");
		JSONObject JOParams = new JSONObject(params);
		String bankID = JOParams.getString("bankID");
		String firmID = JOParams.getString("firmID");
		String password = JOParams.getString("password");
		Double firmBankBalance;
		try {
			firmBankBalance = BankInterfaceRMI.getFirmBankBalance(firmID, bankID, password, getMode());

			if (firmBankBalance == null) {
				setResultData("10104", null, "取得银行余额失败！");
				// this.log.businesslog("取得银行余额失败！", Constants.OPE_MODE_FINANCE,
				// Constants.OPE_FAIL);
			} else {
				JSONObject jsonObj = new JSONObject();
				jsonObj.put("firmBankBalance", firmBankBalance);
				setResultData("00000", jsonObj);
				// this.log.businesslog("取得银行余额成功！", Constants.OPE_MODE_FINANCE,
				// Constants.OPE_SUCCESS);
			}
		} catch (Exception e) {
			this.log.debug(e.getMessage());
			setResultData("10104", null, e.getMessage());
			this.log.error("取得银行余额失败：" + e.getMessage());
			// this.log.businesslog("取得银行余额失败！", Constants.OPE_MODE_FINANCE,
			// Constants.OPE_FAIL);
		}

		this.log.info(this.getClass().getName() + " getFirmBankBalance() End");
		return rtnData.toString();
	}

	@Override
	public String getCapitalList(String params) {
		this.log.info(this.getClass().getName() + " getCapitalList() Start");
		JSONObject JOParams = new JSONObject(params);
		String firmID = JOParams.getString("firmID");
		String qrDate = JOParams.getString("qrDate");
		String srDate = JOParams.getString("srDate");
		String type = JOParams.getString("type");
		int pageSize = JOParams.getInt("pageSize");
		int pageIndex = JOParams.getInt("pageIndex");

		BigDecimal sumInMoney = BigDecimal.ZERO;
		BigDecimal sumOutMoney = BigDecimal.ZERO;
		Vector ret;
		try {
			ret = BankInterfaceRMI.getCapitalList(firmID, qrDate, srDate, type, getMode());
			if (ret == null) {
				setResultData("10104", null, "取得银行流水失败！");
				// this.log.businesslog("取得银行流水失败！", Constants.OPE_MODE_FINANCE,
				// Constants.OPE_FAIL);
			} else {

				// 分页处理
				ObjSet obj = ObjSet.getInstance(ret, pageSize, pageIndex);

				List<CapitalModel> capitalList = new ArrayList<CapitalModel>();
				for (int i = 0; i < obj.size(); i++) {
					CapitalValue capitalValue = (CapitalValue) obj.get(i);
					CapitalModel tempMode = new CapitalModel();
					tempMode.setID(capitalValue.iD);
					tempMode.setActionID(capitalValue.actionID);
					tempMode.setFirmID(capitalValue.firmID);
					tempMode.setFunID(capitalValue.funID);
					tempMode.setBankID(capitalValue.bankID);
					tempMode.setDebitID(capitalValue.debitID);
					tempMode.setCreditID(capitalValue.creditID);
					tempMode.setType(capitalValue.type);
					tempMode.setMoney(capitalValue.money);
					tempMode.setOprcode(capitalValue.oprcode);
					tempMode.setCreatetime(capitalValue.createtime);
					tempMode.setBankTime(capitalValue.bankTime);
					tempMode.setStatus(capitalValue.status);
					tempMode.setExpress(capitalValue.express);
					tempMode.setNote(capitalValue.note);
					tempMode.setBankName(capitalValue.bankName);
					tempMode.setFirmName(capitalValue.firmName);
					tempMode.setAccount(capitalValue.account);
					capitalList.add(tempMode);
				}

				// 入金总计：sumInMoney 元，出金总计：sumOutMoney元 计算出来
				for (int i = 0; i < ret.size(); i++) {
					CapitalValue capitalValue = (CapitalValue) ret.get(i);

					if (capitalValue.type == 0) {
						sumInMoney = sumInMoney.add(new BigDecimal(capitalValue.money));
					} else {
						sumOutMoney = sumOutMoney.add(new BigDecimal(capitalValue.money));
					}
				}

				JSONArray retData;
				JSONObject jsonObj = new JSONObject();
				try {
					retData = JsonUtil.coverModelToJSONArray(capitalList);

					jsonObj.put("total", ret.size());
					jsonObj.put("sumInMoney", sumInMoney);
					jsonObj.put("sumOutMoney", sumOutMoney);
					jsonObj.put("result", retData);
					setResultData("00000", jsonObj);
					// this.log.businesslog("取得银行流水成功！",
					// Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
				} catch (Exception e) {
					this.log.error("数据转换失败：" + e.getMessage());
					setResultData("10104", null, e.getMessage());
					// this.log.businesslog("取得银行流水失败！",
					// Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
				}
			}
		} catch (Exception e) {
			this.log.debug(e.getMessage());
			setResultData("10104", null, e.getMessage());
			this.log.error("取得银行流水失败：" + e.getMessage());
			// this.log.businesslog("取得银行流水失败！", Constants.OPE_MODE_FINANCE,
			// Constants.OPE_FAIL);
		}

		this.log.info(this.getClass().getName() + " getCapitalList() End");
		return rtnData.toString();
	}

	/**
	 * 撤销所有报盘
	 */
	@Override
	public String backAllLeadsAndEnquiry() {
		this.log.info(this.getClass().getName() + " backAllLeadsAndEnquiry() Start");

		// 全部撤单
		if (!balanceMgr.backAllLeadsAndEnquiry()) {
			setResultData("10112", null, "全部撤单失败！");
			this.log.businesslog("全部撤单失败！", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		} else {
			setResultData("00000", null);
			this.log.businesslog("全部撤单成功！", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		}

		this.log.info(this.getClass().getName() + " backAllLeadsAndEnquiry() End");
		return rtnData.toString();
	}

	/**
	 * 撤销询盘
	 * 
	 * @return
	 */
	@Override
	public String backQXEnquiry(String params) {

		this.log.info(this.getClass().getName() + " backQXEnquiry() Start");
		this.log.debug(this.getClass().getName() + " backQXEnquiry() params:" + params);

		boolean checkPm = false;
		boolean checkPre = false;
		boolean checkBack = false;
		JSONObject JOParams = new JSONObject(params);
		int enquiryId = JOParams.optInt("enquiryId");
		int differ = JOParams.optInt("differ");

		// 参数检查
		if (Constants.BACK_END != differ && Constants.BACK_JOB != differ) {
			setResultData("10103", null, "撤销询盘的输入参数有误：" + params);
			this.log.error("撤销询盘的输入参数有误：" + params);
		} else {
			if (Constants.BACK_END == differ) {
				if (enquiryId == 0) {
					setResultData("10103", null, "撤销询盘的输入参数有误,没有询盘ID：" + params);
					this.log.error("撤销询盘的输入参数有误,没有询盘ID：" + params);
				} else {
					checkPm = true;
				}
			} else {
				checkPm = true;
			}
		}

		List<TEnquiry> enqLst = null;
		if (checkPm) {
			// 执行撤盘前检查，锁数据
			try {
				enqLst = balanceMgr.preBackQXEnquiry(differ, enquiryId);
				checkPre = true;
			} catch (Exception e) {
				setResultData("30000", null, "执行撤盘前检查错误：" + e.toString());
				this.log.error("执行撤盘前检查错误：" + e.toString());
			}
		}

		// 撤盘
		List<TEnquiry> enqLstFail = new ArrayList<TEnquiry>();
		if (checkPre) {
			TEnquiry enquiry = null;
			StringBuilder sb = new StringBuilder();
			
			this.log.error("执行撤询盘共计：" + (enqLst != null ? enqLst.size() : 0));
			for (int i = 0; i < (enqLst != null ? enqLst.size() : 0); i++) {

				enquiry = enqLst.get(i);
				this.log.error("执行撤询盘：" + enquiry.getEnquiryCode());
				try {
					// 执行撤盘
					balanceMgr.backQXEnquiry(differ, enquiry);
				} catch (Exception e) {
					enqLstFail.add(enquiry);
					sb.append("询盘(" + enquiry.getEnquiryId());
					if (i < enqLst.size() - 1) {
						sb.append(",");
					}
					this.log.error("执行撤盘错误(" + enquiry.getEnquiryId() + ")：" + e.toString());
					continue;
				}
			}
			if (enqLstFail.size() > 0) {
				sb.append(")");
				setResultData("30000", null, "执行撤盘错误：" + sb.toString());
			} else {
				checkBack = true;
			}
		}

		// 撤盘失败场合，恢复数据
		if (checkPre && !checkBack) {
			TEnquiry enquiry = null;
			for (int i = 0; i < (enqLstFail != null ? enqLstFail.size() : 0); i++) {

				enquiry = enqLstFail.get(i);
				try {
					// 执行撤盘失败恢复数据
					balanceMgr.postBackQXEnquiry(differ, enquiry);
				} catch (Exception e) {
					this.log.error("执行撤盘失败恢复数据错误(" + enquiry.getEnquiryId() + ")：" + e.toString());
				}
			}
		}

		if (checkBack) {
			setResultData("00000", null);
			this.log.businesslog("撤销询盘成功！", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		}

		this.log.info(this.getClass().getName() + " backQXEnquiry() End");
		return rtnData.toString();
	}

	/**
	 * 撤销挂盘
	 * 
	 * @return
	 */
	@Override
	public String backQXLeads(String params) {

		this.log.info(this.getClass().getName() + " backQXLeads() Start");
		this.log.debug(this.getClass().getName() + " backQXLeads() params:" + params);

		boolean checkPm = false;
		boolean checkPre = false;
		boolean checkBack = false;
		JSONObject JOParams = new JSONObject(params);
		int leadId = JOParams.optInt("leadId");
		int differ = JOParams.optInt("differ");

		// 参数检查
		if (Constants.BACK_FRONT != differ && Constants.BACK_JOB != differ) {
			setResultData("10103", null, "撤销挂盘的输入参数有误：" + params);
			this.log.error("撤销挂盘的输入参数有误：" + params);
		} else {
			if (Constants.BACK_FRONT == differ) {
				if (leadId == 0) {
					setResultData("10103", null, "撤销挂盘的输入参数有误,没有询盘ID：" + params);
					this.log.error("撤销挂盘的输入参数有误,没有询盘ID：" + params);
				} else {
					checkPm = true;
				}
			} else {
				checkPm = true;
			}
		}

		List<TLeads> leadsLst = null;
		if (checkPm) {
			// 执行撤盘前检查，锁数据
			try {
				leadsLst = balanceMgr.preBackQXLead(differ, leadId);
				checkPre = true;
			} catch (Exception e) {
				setResultData("30000", null, "执行撤盘前检查错误：" + e.toString());
				this.log.error("执行撤盘前检查错误：" + e.toString());
			}
		}

		// 撤盘
		List<TLeads> leadLstFail = new ArrayList<TLeads>();
		if (checkPre) {
			TLeads lead = null;
			StringBuilder sb = new StringBuilder();
			
			this.log.error("执行撤报盘共计：" + (leadsLst != null ? leadsLst.size() : 0));
			for (int i = 0; i < (leadsLst != null ? leadsLst.size() : 0); i++) {
				lead = leadsLst.get(i);
				
				this.log.error("执行撤报盘：" + lead.getLeadsCode());
				try {
					// 执行撤盘
					balanceMgr.backQXLead(differ, lead);
					checkBack = true;
				} catch (Exception e) {
					leadLstFail.add(lead);
					sb.append("挂盘(" + lead.getID());
					if (i < leadsLst.size() - 1) {
						sb.append(",");
					}
					this.log.error("执行撤盘错误(" + lead.getID() + ")：" + e.toString());
				}
			}
			if (leadLstFail.size() > 0) {
				sb.append(")");
				setResultData("30000", null, "执行撤盘错误：" + sb.toString());
			} else {
				checkBack = true;
			}
		}

		// 撤盘失败场合，恢复数据
		if (checkPre && !checkBack) {
			TLeads lead = null;
			for (int i = 0; i < (leadLstFail != null ? leadLstFail.size() : 0); i++) {
				lead = leadLstFail.get(i);
				try {
					// 执行撤盘失败恢复数据
					balanceMgr.postBackQXLead(differ, lead);
				} catch (Exception e) {
					this.log.error("执行撤盘失败恢复数据错误(" + lead.getID() + ")：" + e.toString());
				}
			}
		}

		if (checkBack) {
			setResultData("00000", null);
			this.log.businesslog("撤销挂盘成功！", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		}

		this.log.info(this.getClass().getName() + " backQXLeads() End");
		return rtnData.toString();
	}

	/**
	 * 中石化自动撤盘
	 */
	@Override
	public String backAllSinopecLeadsAndEnquiry() {
		this.log.info(this.getClass().getName() + "backAllSinopecLeadsAndEnquiry Service Start");
		boolean bolRst = false;
		bolRst = this.balanceMgr.backAllSinopecLeadsAndEnquiry();
		if (!bolRst) {
			setResultData("40006", null);
			this.log.businesslog("中石化自动撤盘失败！", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		} else {
			setResultData("00000", null);
			this.log.businesslog("中石化自动撤盘成功！", Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
		}
		this.log.info(this.getClass().getName() + "backAllSinopecLeadsAndEnquiry Service End");
		return rtnData.toString();
	}

	@Override
	public String getCanBackCount() {
		this.log.info(this.getClass().getName() + " getCanBackCount() Start");

		int count = 0;
		count = balanceMgr.getCanBackCount();
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("count", count);
		setResultData("00000", jsonObj);
		// this.log.businesslog("取得能撤单单数成功！", Constants.OPE_MODE_FINANCE,
		// Constants.OPE_SUCCESS);

		this.log.info(this.getClass().getName() + " getCanBackCount() End");
		return rtnData.toString();
	}

	/**
	 * 农业银行获取签名用信息
	 * 
	 * @param params
	 * @return
	 */
	@Override
	public String getAbcSignInfoString(String params) {
		this.log.info(this.getClass().getName() + " getAbcSignInfoString() Start");
		JSONObject JOParams = new JSONObject(params);
		String bankID = JOParams.getString("bankID");
		String firmID = JOParams.getString("firmID");
		String account = JOParams.getString("account");
		Double amount = JOParams.getDouble("payAmount");
		BigDecimal payAmount = BigDecimal.valueOf(amount);
		String functionID = JOParams.getString("functionID");

		boolean bolRst = false;
		AbcSignInfoModel retModel = null;
		try {
			retModel = BankInterfaceRMI.getAbcSignInfoString(bankID, firmID, account, payAmount, functionID, getMode());
			bolRst = true;
		} catch (Exception e) {
			this.log.debug(e.getMessage());
			this.log.businesslog("获取签名用信息失败！", Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
		}

		if (bolRst) {
			JSONObject retData;

			try {
				if (retModel.getResult() == 0) {
					retData = JsonUtil.coverModelToJSONObject(retModel);
					setResultData("00000", retData);
				} else if (retModel.getResult() == -1) {
					setResultData("10105", null, "无法获取银行注册信息");
				}
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getAbcSignInfoString() End");
		return rtnData.toString();
	}

	@Override
	public String payForCancel(String params) {
		this.log.info(this.getClass().getName() + " payForCancel() Start");
		JSONObject JOParams = new JSONObject(params);
		String ApplyID = JOParams.optString("ApplyID");
		String OptUserCode = JOParams.optString("OptUserCode");
		if (Common.isEmpty(ApplyID)) {
			setResultData("10103", null);
		}

		if (Common.isEmpty(OptUserCode)) {
			OptUserCode = getUserId();
		}

		int result;

		try {
			result = balanceMgr.payForCancel(ApplyID, OptUserCode);
			if (result == -99) {
				setResultData("30000", null, "申请解约数据异常！");
			} else if (result == -1) {
				setResultData("30000", null, "资金账户余额不足！");
			} else if (result == -3) {
				setResultData("30000", null, "授信账户余额不足！");
			} else if (result == -5) {
				setResultData("30000", null, "优惠券账户资金不足！");
			} else if (result < 0) {
				setResultData("10112", null, "结算失败！");
			} else {
				setResultData("00000", null);
			}
		} catch (Exception e) {
			this.log.debug("payForCancel发生异常 ： " + e.toString());
			setResultData("10112", null);
		}
		this.log.info(this.getClass().getName() + " payForCancel() End");
		return rtnData.toString();
	}
}
