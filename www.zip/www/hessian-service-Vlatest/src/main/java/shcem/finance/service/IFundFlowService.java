package shcem.finance.service;

public interface IFundFlowService {
	/**
	 * 资金流水列表
	 * @param params
	 * @return
	 */
	public String getFundFlowList(String params);
	/**
	 * 开票管理列表数据
	 * @param params
	 * @return
	 */
	public String getFinancialBillsList(String params);
	/**
	 * 
	 * @param params
	 * @return
	 */
	public String addInvoiceApply(String params);
}
