package shcem.finance.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.finance.component.IFirmBanlanceManager;
import shcem.finance.component.IFirmBanlanceOraManager;
import shcem.finance.dao.model.FBOutMoneyApply;
import shcem.finance.dao.model.FBanks;
import shcem.finance.dao.model.FirmBanlanceList;
import shcem.finance.dao.model.FirmBanlanceListForOra;
import shcem.finance.service.IBalanceMgrService;
import shcem.finance.service.model.BalanceModel;
import shcem.finance.service.model.BalanceServiceModel;
import shcem.finance.util.FinanceOraSysData;
import shcem.finance.util.FinanceSysData;
import shcem.util.CopyProperties;
import shcem.util.JsonUtil;

public class BalanceMgrServiceImpl extends BaseServiceImpl implements IBalanceMgrService {

	private IFirmBanlanceManager mgr = (IFirmBanlanceManager) FinanceSysData.getBean(Constants.BEAN_BALANCE_MGR);
	private IFirmBanlanceOraManager mgrOra = (IFirmBanlanceOraManager) FinanceOraSysData
			.getBean(Constants.BEAN_BALANCEORA_MGR);

	@Override
	public String queryFirmBanlance(String params) {
		this.log.info(this.getClass().getName() + " queryFirmBanlance() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);

		// 查询条件和pageInfo设置
		List<Condition> conditionList = new ArrayList<Condition>(); // 允许的查询参数列表，定义字段，操作符及类型,查询json固定模型queryModel
		conditionList.add(new Condition("t1.FIRMID", "like", "", "String", "FIRMID"));
		conditionList.add(new Condition("t3.FIRMNAME", "like", "", "String", "FIRMNAME"));
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<FirmBanlanceList> list = null;
		List<FirmBanlanceListForOra> listOra = null;
		// 查询交易商新专场授信资金
		try {
			list = mgr.queryFirmBanlance(qc, pageInfo);
		} catch (Exception err) {
			this.log.error("交易商资金取得失败：" + err.getMessage());
			setResultData("10104", null, err.getMessage());
			this.log.info(this.getClass().getName() + " queryFirmBanlance() End");
			return rtnData.toString();
		}

		// 新专场查询成功的时候，查询老专场的交易商当前资金
		try {
			listOra = mgrOra.queryFirmBanlance(null, null);
		} catch (Exception err) {
			this.log.error("交易商资金取得失败：" + err.getMessage());
			setResultData("10104", null, err.getMessage());
			this.log.info(this.getClass().getName() + " queryFirmBanlance() End");
			return rtnData.toString();
		}

		List<BalanceServiceModel> listServer = new ArrayList<BalanceServiceModel>();
		for (int i = 0; i < list.size(); i++) {
			FirmBanlanceList temp = list.get(i);
			String tempFirmId = temp.getFIRMID();

			for (int j = 0; j < listOra.size(); j++) {
				FirmBanlanceListForOra temp2 = listOra.get(j);

				if (tempFirmId.equals(temp2.getFIRMID())) {
					// 老砖厂资金数据copy到list里
					temp.setNAME(temp2.getNAME());
					temp.setFBALANCEFromOra(temp2.getF_BALANCE());
					temp.setLBALANCEFromOra(temp2.getL_BALANCE());
					temp.setYBALANCEFromOra(temp2.getY_BALANCE());
					temp.setBALANCESUBTRACTFromOra(temp2.getBALANCESUBTRACT());
					temp.setLASTWARRANTYFromOra(temp2.getLASTWARRANTY());
					temp.setFROZENFUNDSFromOra(temp2.getFROZENFUNDS());
					temp.setUSERBALANCEFromOra(temp2.getUSER_BALANCE());
					break;
				}
			}

			try {
				BalanceServiceModel serverModel = new BalanceServiceModel();
				CopyProperties.copyProperties(temp, serverModel);
				listServer.add(serverModel);
			} catch (Exception e) {
				this.log.error("交易商资金列表数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
				this.log.info(this.getClass().getName() + " queryFirmBanlance() End");
				return rtnData.toString();
			}
		}

		JSONArray retData;
		JSONObject jsonObj = new JSONObject();
		try {
			retData = JsonUtil.coverModelToJSONArray(listServer);
			jsonObj.put("total", pageInfo.getTotalRecords());
			jsonObj.put("result", retData);
			setResultData("00000", jsonObj);
		} catch (Exception e) {
			this.log.error("交易商资金列表数据转换失败：" + e.getMessage());
			setResultData("10105", null, e.getMessage());
		}
		this.log.info(this.getClass().getName() + " queryFirmBanlance() End");
		return rtnData.toString();
	}

	@Override
	public String queryOneFirmBanlance(String params) {
		this.log.info(this.getClass().getName() + " queryOneFirmBanlance() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		String firmId = (String) JOParams.opt("FIRMID");
		

		// 查询条件和pageInfo设置
		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("t1.FIRMID", "=", firmId));
		QueryConditions qc = new QueryConditions(conditionList);
		this.log.debug("qc=" + qc.toString());

		List<FirmBanlanceList> list = null;
		List<FirmBanlanceListForOra> listOra = null;
		// 查询交易商新专场授信资金
		try {
			if (firmId != null) list = mgr.queryFirmBanlance(qc, null);
		} catch (Exception err) {
			this.log.error("交易商资金取得失败：" + err.getMessage());
			setResultData("10104", null, err.getMessage());
			this.log.info(this.getClass().getName() + " queryOneFirmBanlance() End");
			return rtnData.toString();
		}

		// 新专场查询成功的时候，查询老专场的交易商当前资金
		try {
			if (firmId != null)listOra = mgrOra.queryFirmBanlance(qc, null);
		} catch (Exception err) {
			this.log.error("交易商资金取得失败：" + err.getMessage());
			setResultData("10104", null, err.getMessage());
			this.log.info(this.getClass().getName() + " queryOneFirmBanlance() End");
			return rtnData.toString();
		}

		if (list == null || list.size() != 1 || listOra == null || listOra.size() != 1) {
			this.log.error("没有这个交易商的资金数据！");
			setResultData("10104", null, "没有这个交易商的资金数据！");
			this.log.info(this.getClass().getName() + " queryOneFirmBanlance() End");
			return rtnData.toString();
		}

		BalanceModel balanceModel = new BalanceModel();
		balanceModel.setFIRMID(firmId);
		balanceModel.setFIRMNAME(list.get(0).getFIRMNAME());
		// 现货
		if (list.get(0).getBALANCEFromS() != null) {
			balanceModel.setBALANCEFromS(list.get(0).getBALANCEFromS());
		} else {
			balanceModel.setBALANCEFromS(new BigDecimal(0));
		}
		if (list.get(0).getLASTBALANCEFromS() != null) {
			balanceModel.setLASTBALANCEFromS(list.get(0).getLASTBALANCEFromS());
		} else {
			balanceModel.setLASTBALANCEFromS(new BigDecimal(0));
		}
		// 预售
		if (list.get(0).getPreSaleBALANCEFROMS() != null) {
			balanceModel.setPreSaleBALANCEFromS(list.get(0).getPreSaleBALANCEFROMS());
		} else {
			balanceModel.setPreSaleBALANCEFromS(new BigDecimal(0));
		}
		if (list.get(0).getPreSaleLASTBALANCEFROMS() != null) {
			balanceModel.setPreSaleLASTBALANCEFromS(list.get(0).getPreSaleLASTBALANCEFROMS());
		} else {
			balanceModel.setPreSaleLASTBALANCEFromS(new BigDecimal(0));
		}
		// 可提资金
//		if (listOra.get(0).getUSER_BALANCE() != null) {
//			balanceModel.setUSERBALANCEFromOra(listOra.get(0).getUSER_BALANCE());
//		} else {
//			balanceModel.setUSERBALANCEFromOra(new BigDecimal(0));
//		}
		if (listOra.get(0).getF_BALANCE() != null) {
			BigDecimal temp1 = new BigDecimal(0);
			BigDecimal temp2 = new BigDecimal(0);
			if (listOra.get(0).getRUNTIMEFL() != null){//浮动盈亏
				temp1 = listOra.get(0).getRUNTIMEFL();
			}
			if (listOra.get(0).getCLEARFL() != null){
				temp2= listOra.get(0).getCLEARFL();
			}
			BigDecimal temp = temp1.subtract(temp2);
			balanceModel.setUSERBALANCEFromOra(listOra.get(0).getF_BALANCE().add(temp));
		} else {
			balanceModel.setUSERBALANCEFromOra(new BigDecimal(0));
		}
		// 交易系统当前余额(暂时不用)
		if (listOra.get(0).getF_BALANCE() != null) {
			balanceModel.setFBALANCEFromOra(listOra.get(0).getF_BALANCE());
		} else {
			balanceModel.setFBALANCEFromOra(new BigDecimal(0));
		}
		JSONObject jsonObj = new JSONObject();
		try {
			jsonObj = JsonUtil.coverModelToJSONObject(balanceModel);
			setResultData("00000", jsonObj);
		} catch (Exception e) {
			this.log.error("交易商资金列表数据转换失败：" + e.getMessage());
			setResultData("10105", null, e.getMessage());
		}
		this.log.info(this.getClass().getName() + " queryOneFirmBanlance() End");
		return rtnData.toString();
	}

	@Override
	public String queryOutMoneyList(String params) {
		this.log.info(this.getClass().getName() + " queryOutMoneyList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);

		// 查询条件和pageInfo设置
		List<Condition> conditionList = new ArrayList<Condition>(); // 允许的查询参数列表，定义字段，操作符及类型,查询json固定模型queryModel
		conditionList.add(new Condition("t1.FIRMID", "like", "", "String", "FIRMID"));
		conditionList.add(new Condition("t2.FIRMNAME", "like", "", "String", "FIRMNAME"));
		conditionList.add(new Condition("t3.SignBankID", "=", "", "String", "SignBankID"));
		
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<FirmBanlanceList> list = null;
		List<FirmBanlanceListForOra> listOra = null;
		// 查询交易商新专场授信资金
		try {
			list = mgr.queryOutMoneyList(qc, pageInfo);
		} catch (Exception err) {
			this.log.error("交易商资金取得失败：" + err.getMessage());
			setResultData("10104", null, err.getMessage());
			this.log.info(this.getClass().getName() + " queryOutMoneyList() End");
			return rtnData.toString();
		}

		// 新专场查询成功的时候，查询老专场的交易商当前资金
		try {
			listOra = mgrOra.queryFirmBanlance(null, null);
		} catch (Exception err) {
			this.log.error("交易商资金取得失败：" + err.getMessage());
			setResultData("10104", null, err.getMessage());
			this.log.info(this.getClass().getName() + " queryOutMoneyList() End");
			return rtnData.toString();
		}

		
		for (int i = 0; i < list.size(); i++) {
			FirmBanlanceList temp = list.get(i);
			String tempFirmId = temp.getFIRMID();

			for (int j = 0; j < listOra.size(); j++) {
				FirmBanlanceListForOra temp2 = listOra.get(j);

				if (tempFirmId.equals(temp2.getFIRMID())) {
					// 老砖厂资金数据copy到list里
					temp.setFBALANCEFromOra(temp2.getF_BALANCE());
					temp.setUSERBALANCEFromOra(temp2.getUSER_BALANCE());
					break;
				}
			}
			list.set(i, temp);
		}

		JSONArray retData;
		JSONObject jsonObj = new JSONObject();
		try {
			retData = JsonUtil.coverModelToJSONArray(list);
			jsonObj.put("total", pageInfo.getTotalRecords());
			jsonObj.put("result", retData);
			setResultData("00000", jsonObj);
		} catch (Exception e) {
			this.log.error("交易商资金列表数据转换失败：" + e.getMessage());
			setResultData("10105", null, e.getMessage());
		}
		this.log.info(this.getClass().getName() + " queryOutMoneyList() End");
		return rtnData.toString();
	}

	@Override
	public String insertOutMoneyApply(String params) {
		this.log.info(this.getClass().getName() + " insertOutMoneyApply() Start");

		JSONObject JOParams = new JSONObject(params);
		FBOutMoneyApply applyModel = (FBOutMoneyApply) JsonUtil.jsonToBean(JOParams, FBOutMoneyApply.class);
		applyModel.setApplyer(this.getUserId());
		this.log.debug(params);
		try {
			this.mgr.insertOutMoneyApply(applyModel);
			setResultData("00000", null);
		} catch (Exception e) {
			this.log.error("增加出金申请情报失败：" + e.getMessage());
			setResultData("10106", null, e.getMessage());
		}

		this.log.info(this.getClass().getName() + " insertOutMoneyApply() End");
		return rtnData.toString();
	}

	@Override
	public String queryOutMoneyApplyList(String params) {
		this.log.info(this.getClass().getName() + " queryOutMoneyApplyList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);

		// 查询条件和pageInfo设置
		List<Condition> conditionList = new ArrayList<Condition>(); // 允许的查询参数列表，定义字段，操作符及类型,查询json固定模型queryModel
		conditionList.add(new Condition("FIRMID", "like", "", "String", "firmID"));
		conditionList.add(new Condition("FIRMNAME", "like", "", "String", "firmName"));
		conditionList.add(new Condition("status", "=", "", "String", "status"));
		
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<FBOutMoneyApply> list = null;
		// 查询交易商新专场授信资金
		try {
			list = mgr.getOutMoneyApplyList(qc, pageInfo);
		} catch (Exception err) {
			this.log.error("申请出金审核列表取得失败：" + err.getMessage());
			setResultData("10104", null, err.getMessage());
			this.log.info(this.getClass().getName() + " queryOutMoneyApplyList() End");
			return rtnData.toString();
		}

		JSONArray retData;
		JSONObject jsonObj = new JSONObject();
		try {
			retData = JsonUtil.coverModelToJSONArray(list);
			jsonObj.put("total", pageInfo.getTotalRecords());
			jsonObj.put("result", retData);
			setResultData("00000", jsonObj);
		} catch (Exception e) {
			this.log.error("申请出金审核列表转换失败：" + e.getMessage());
			setResultData("10105", null, e.getMessage());
		}
		this.log.info(this.getClass().getName() + " queryOutMoneyApplyList() End");
		return rtnData.toString();
	}

	@Override
	public String updateOutMoneyApply(String params) {
		this.log.info(this.getClass().getName() + " updateOutMoneyApply() Start");

		JSONObject JOParams = new JSONObject(params);
		Integer id = JOParams.optInt("id");
		Integer fromStatus = JOParams.optInt("fromStatus");
		Integer toStatus = JOParams.optInt("toStatus");
		String auditor = this.getUserId();
		String note = JOParams.optString("note");
		this.log.debug(params);
		int count=0;
		try {
			count = this.mgr.updateOutMoneyApply(id, fromStatus, toStatus, auditor, note);
			if(count == 1){
				setResultData("00000", null);	
			}else{
				setResultData("10101", null, "此申请已经被审核或者变动！");
			}
		} catch (Exception e) {
			this.log.error("增加出金申请情报失败：" + e.getMessage());
			setResultData("10106", null, e.getMessage());
		}

		this.log.info(this.getClass().getName() + " updateOutMoneyApply() End");
		return rtnData.toString();
	}
}
