/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: SApplyDAOImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　罗恒   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.impl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.jdbc.CannotGetJdbcConnectionException;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.SApplyDAO;
import shcem.finance.dao.model.*;
import shcem.util.CommonRowMapper;

public class SApplyDAOImpl extends BaseDAOImpl implements SApplyDAO {

	/**
	 * 授信申请记录查询
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	@Override
	public List<SApply> getSApplyList(QueryConditions qc, PageInfo pageInfo) {
		List<SApply> list = new ArrayList<SApply>();
		this.log.debug("getSApplyList DAO Start");
		String sql = sqlProperty.getProperty("SApplyDAO_001");
		list = queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new SApply()));
		return list;
	}

	/**
	 * 授信申请追加
	 * 
	 * @param sapply
	 * @return
	 */
	@Override
	public int addApply(SApply sapply) {
		String sql = sqlProperty.getProperty("SApplyDAO_002");
		Object[] params = { sapply.getApplyType(), sapply.getFirmID(), sapply.getAmount(), sapply.getApplyer(),
				sapply.getApplyTime(), sapply.getNote(),sapply.getDiffType()};
		return getJdbcTemplate().update(sql, params);
	}

	/**
	 * 更新申请状态
	 * 
	 * @param applyId
	 * @param status
	 * @return
	 */
	@Override
	public int updateStatus(Integer applyId, Integer status) {
		String sql = sqlProperty.getProperty("SApplyDAO_003");
		Object[] params = { status, applyId };
		return getJdbcTemplate().update(sql, params);
	}
	
	/**
	 * 更新拒绝原因
	 * 
	 * @param applyId
	 * @param status
	 * @return
	 */
	@Override
	public int updateRefuseReason(Integer applyId, String refuseReason) {
		String sql = sqlProperty.getProperty("SApplyDAO_013");
		Object[] params = { refuseReason, applyId };
		return getJdbcTemplate().update(sql, params);
	}

	/**
	 * 当前授信资金查询
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	@Override
	public List<SFirmFunds> getFirmFundsList(QueryConditions qc, PageInfo pageInfo) {
		List<SFirmFunds> list = new ArrayList<SFirmFunds>();
		this.log.debug("getFirmFundsList DAO Start");
		String sql = sqlProperty.getProperty("SApplyDAO_004");
		list = queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new SFirmFunds()));
		return list;
	}

	/**
	 * 交易商授信资金查询
	 * 
	 * @param firmId
	 * @return
	 */
	@Override
	public SFirmFunds getFirmFunds(String firmId) {
		this.log.debug("getFirmFunds DAO Start");
		String sql = sqlProperty.getProperty("SApplyDAO_005");
		Object[] params = new Object[] { firmId };

		return (SFirmFunds) queryForObject(sql, params, new CommonRowMapper(new SFirmFunds()));
	}

	/**
	 * 授信申请追加
	 * 
	 * @param sapply
	 * @return
	 */
	@Override
	public int addSFundFlow(SFundFlow sFundFlow) {
		String sql = sqlProperty.getProperty("SApplyDAO_006");
		Object[] params = { sFundFlow.getFirmID(), sFundFlow.getOperCode(), sFundFlow.getAmount(),
				sFundFlow.getBalance(), sFundFlow.getCreatetime(), sFundFlow.getObjectID(), sFundFlow.getFlowType() };
		 return getJdbcTemplate().update(sql, params);
	}

	/**
	 * 授信资金表更新（当前余额，期初额）
	 * 用于改变授信上限 
	 * @param firmId
	 * @param money
	 *            今次授信金额
	 * @return
	 */
	@Override
	public int updateSfirmFunds(String firmId, BigDecimal money, Date creditDate) {
		String sql = sqlProperty.getProperty("SApplyDAO_007");
		Object[] params = { money, money, creditDate, firmId };
		return getJdbcTemplate().update(sql, params);
	}

	/**
	 * 主键取得授信申请记录
	 * 
	 * @param applyId
	 * @return
	 */
	@Override
	public SApply getApply(Integer applyId) {
		this.log.debug("getApply DAO Start");
		String sql = sqlProperty.getProperty("SApplyDAO_008");
		Object[] params = new Object[] { applyId };

		return (SApply) queryForObject(sql, params, new CommonRowMapper(new SApply()));
	}

	/**
	 * 更新审核者，审核时间
	 * 
	 * @param applyId
	 * @param approver
	 * @param approveTime
	 * @return
	 */
	@Override
	public int updateApprover(Integer applyId, String approver, Date approveTime) {
		String sql = sqlProperty.getProperty("SApplyDAO_009");
		Object[] params = { approver, approveTime, applyId };
		return getJdbcTemplate().update(sql, params);
	}

	/**
	 * 授信资金表使用更新（当前余额，冻结额）
	 * 用于解冻/解冻 授信资金
	 * @param firmId
	 * @param money
	 *            今次金额
	 * @return
	 */
	@Override
	public int updateSfirmFundsByUse(String firmId, BigDecimal money) {
		String sql = sqlProperty.getProperty("SApplyDAO_010");
		Object[] params = { money, money, firmId };
		return getJdbcTemplate().update(sql, params);
	}

	@Override
	public void rollBack() {
		try {
			getConnection().rollback();
		} catch (CannotGetJdbcConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 授信资金流水list取得
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	@Override
	public List<SFundFlow> getSFundFlowList(QueryConditions qc, PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("SApplyDAO_011");
		List<SFundFlow> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new SFundFlow()));
		return list;
	}
	
	public List<SPreSaleFundFlow> getPreSaleFundFlowList(QueryConditions qc,
			PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("SApplyDAO_016");
		List<SPreSaleFundFlow> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new SPreSaleFundFlow()));
		return list;
	}

	/**
	 * 授信资金和市场资金流水list取得
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	@Override
	public List<AllFundFlow> getAllFundFlowList(QueryConditions qc, PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("SApplyDAO_012");
		List<AllFundFlow> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new AllFundFlow()));
		return list;
	}

	/**
	 * 增加预售授信流水表
	 *
	 * @param sPreSaleFundFlow
	 * @return
	 */
	public int addPreSaleFundFlow(SPreSaleFundFlow sPreSaleFundFlow) {
		String sql = sqlProperty.getProperty("SApplyDAO_014");
		Object[] params = { sPreSaleFundFlow.getFirmID(),sPreSaleFundFlow.getOperCode(),sPreSaleFundFlow.getAmount(),sPreSaleFundFlow.getBalance(),sPreSaleFundFlow.getObjectID(),sPreSaleFundFlow.getFlowType() };
		return getJdbcTemplate().update(sql, params);
	}

	/**
	 * 更新预售授信资金表
	 * @param firmId
	 * @param money
	 * @param creditDate
	 * @return
	 */
	public int updatePreSaleFirmFound(String firmId, BigDecimal money, Date creditDate) {
		String sql = sqlProperty.getProperty("SApplyDAO_015");
		Object[] params = {money,money,creditDate,firmId};
		return getJdbcTemplate().update(sql, params);
	}

	@Override
	public SPreSaleFirmFunds getPreSaleFirmFundsFirmFunds(String firmId) {
		this.log.debug("getPreSaleFirmFundsFirmFunds DAO Start");
		String sql = sqlProperty.getProperty("SApplyDAO_017");
		Object[] params = new Object[] { firmId };

		return (SPreSaleFirmFunds) queryForObject(sql, params, new CommonRowMapper(new SPreSaleFirmFunds()));
	}

	@Override
	public List<SPreSaleFirmFunds> getPreSaleFirmFundsList(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.debug("getPreSaleFirmFundsList DAO Start");
		String sql = sqlProperty.getProperty("SApplyDAO_018");
		return this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new SPreSaleFirmFunds()));
	}
}
