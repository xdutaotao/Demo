/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: BankMgrServiceModel
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.service.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Hashtable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.json.JSONObject;

import shcem.base.service.model.BaseServiceObject;

/**
 * BankMgrServiceModel
 * 
 * @author chiyong
 * @version 1.0
 */
public class BankMgrServiceModel extends BaseServiceObject implements Serializable {

	private static final long serialVersionUID = 3690197650654049810L;

	// ����A�����keyCode
	private String bankID;

	/**  */
	private String bankName;

	/**  */
	private BigDecimal maxPerSglTransMoney;

	/**  */
	private BigDecimal maxPerTransMoney;

	/**  */
	private Integer maxPerTransCount;

	/**  */
	private BigDecimal maxAuditMoney;

	/**  */
	private String adapterClassName;

	/**  */
	private Integer validFlag;

	/**  */
	private String beginTime;

	/**  */
	private String endTime;

	/**  */
	private Integer control;

	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof BankMgrServiceModel))
			return false;

		BankMgrServiceModel m = (BankMgrServiceModel) o;

		return this.bankID != null ? this.bankID.equals(m.bankID) : m.bankID == null;
	}

	/**
	 * @return the bankID
	 */
	public String getBankID() {
		return bankID;
	}

	/**
	 * @param bankID the bankID to set
	 */
	public void setBankID(String bankID) {
		this.bankID = bankID;
	}

	/**
	 * @return the bankName
	 */
	public String getBankName() {
		return bankName;
	}

	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * @return the maxPerSglTransMoney
	 */
	public BigDecimal getMaxPerSglTransMoney() {
		return maxPerSglTransMoney;
	}

	/**
	 * @param maxPerSglTransMoney the maxPerSglTransMoney to set
	 */
	public void setMaxPerSglTransMoney(BigDecimal maxPerSglTransMoney) {
		this.maxPerSglTransMoney = maxPerSglTransMoney;
	}

	/**
	 * @return the maxPerTransMoney
	 */
	public BigDecimal getMaxPerTransMoney() {
		return maxPerTransMoney;
	}

	/**
	 * @param maxPerTransMoney the maxPerTransMoney to set
	 */
	public void setMaxPerTransMoney(BigDecimal maxPerTransMoney) {
		this.maxPerTransMoney = maxPerTransMoney;
	}

	/**
	 * @return the maxPerTransCount
	 */
	public Integer getMaxPerTransCount() {
		return maxPerTransCount;
	}

	/**
	 * @param maxPerTransCount the maxPerTransCount to set
	 */
	public void setMaxPerTransCount(Integer maxPerTransCount) {
		this.maxPerTransCount = maxPerTransCount;
	}

	/**
	 * @return the maxAuditMoney
	 */
	public BigDecimal getMaxAuditMoney() {
		return maxAuditMoney;
	}

	/**
	 * @param maxAuditMoney the maxAuditMoney to set
	 */
	public void setMaxAuditMoney(BigDecimal maxAuditMoney) {
		this.maxAuditMoney = maxAuditMoney;
	}

	/**
	 * @return the validFlag
	 */
	public Integer getValidFlag() {
		return validFlag;
	}

	/**
	 * @param validFlag the validFlag to set
	 */
	public void setValidFlag(Integer validFlag) {
		this.validFlag = validFlag;
	}

	/**
	 * @return the beginTime
	 */
	public String getBeginTime() {
		return beginTime;
	}

	/**
	 * @param beginTime the beginTime to set
	 */
	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}

	/**
	 * @return the endTime
	 */
	public String getEndTime() {
		return endTime;
	}

	/**
	 * @param endTime the endTime to set
	 */
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	/**
	 * @return the control
	 */
	public Integer getControl() {
		return control;
	}

	/**
	 * @param control the control to set
	 */
	public void setControl(Integer control) {
		this.control = control;
	}

	public int hashCode() {
		return this.bankID != null ? this.bankID.hashCode() : 0;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public JSONObject toJSONObject() {

		Hashtable<String, Object> tb = new Hashtable<String, Object>();
		tb.put("bankID", this.bankID == null ? "" : this.bankID);

		return new JSONObject(tb);
	}


}
