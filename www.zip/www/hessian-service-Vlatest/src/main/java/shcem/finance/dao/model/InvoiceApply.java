package shcem.finance.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.Bidi;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * 开票申请流水表
 * 
 * @author zhangnan
 *
 */
public class InvoiceApply extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer id;

	/**开票类型 1:货款 5：手续费*/
	private Integer applyType;

	/**发票类型  1:增值税发票 5：普通发票*/
	private Integer invoiceType;
	
	/** 发票抬头 :买家交易商名称*/
	private String invoiceTitle;
	
	/**
	 * 优惠券号码
	 */
	private String couponNumber;
	
	/**税号*/
	private String taxNo;
	
	/**交易商ID*/
	private String firmId;
	
	/**开票银行帐号*/
	private String bankAccount;
	
	/**开票银行ID*/
	private Integer bankID;
	
	/**开票银行名称*/
	private String bankName;
	
	/**开票地址*/
	private String invoiceAddress;
	
	/**开票电话*/
	private String invoiceTel;
	
	/**税率*/
	private BigDecimal taxRate;
	
	/**开票数量（吨）*/
	private BigDecimal applyQuantity;
	
	/**开票单价（元)*/
	private BigDecimal applyPrice;
	
	/**开票金额*/
	private BigDecimal applyMoney;
	
	/**备注*/
	private String remark;
	
	/**申请人*/
	private BigDecimal applicantName;
	
	/**申请时间*/
	private Date applicantTime;
	
	/**审批人*/
	private String approveName;
	
	/**审批时间*/
	private Date ApproveTime;
	
	/**状态 1：已申请，待财务处理 5：已审批 ，10：已拒绝，15：开票完成 */
	private Integer applyStatus;
	
	/***/
	private Integer dISABLED;
	
	/***/
	private String rEC_CREATEBY;
	
	/***/
	private Date rEC_CREATETIME;
	
	/***/
	private String rEC_MODIFYBY;
	
	/***/
	private Date rEC_MODIFYTIME;
	
	/** 快递单号 */
	private String trackingNo;
	
	/**品类牌号*/
	private String goodName;
	
	/**品类*/
	private String categoryName;
	
	/**牌号*/
	private String brandName;
	
	/**交收单号*/
	private String deliveryID;
	
	/**订单号*/
	private String orderId;
	
	/** 发票号 */
	private String invoiceNo;
	
	/**开票申请关联表ID*/
	private Integer invoiceApplyRelID;
	
	/**开票支行名称*/
	private String branchName;
	/**收票地址*/    
	private String collectInvoiceAddress;
	/**收票电话*/
	private String collectTel;
	/**收票人*/
	private String collectInvoicePeople;
	
	private InvoiceApply4Check invoiceApply4Check;
	
	/**申请信息是否详细*/
	private Boolean isDetailed; 
	
	/** 开票申请来源 0:前台商城 1：化交后台*/
	private Integer applyOrigin;
	
	/**交易商名称*/
	private String firmName;
	
	/**交收数量*/
	private BigDecimal deliveryWeight;
	
	private Date tradeDate;
	
	/**
	 * 增值型优惠券开票信息是否完善：1 完善  2 不完善
	 */
	private Integer isFullDetailed;
	
	/**
	 * 是否开启开票 0否 1是
	 */
	private Integer isInvoiceOpen;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getApplyType() {
		return applyType;
	}

	public void setApplyType(Integer applyType) {
		this.applyType = applyType;
	}

	public Integer getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(Integer invoiceType) {
		this.invoiceType = invoiceType;
	}

	public String getTaxNo() {
		return taxNo;
	}

	public void setTaxNo(String taxNo) {
		this.taxNo = taxNo;
	}

	public String getFirmId() {
		return firmId;
	}

	public void setFirmId(String firmId) {
		this.firmId = firmId;
	}

	public String getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}

	public Integer getBankID() {
		return bankID;
	}

	public void setBankID(Integer bankID) {
		this.bankID = bankID;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getInvoiceAddress() {
		return invoiceAddress;
	}

	public void setInvoiceAddress(String invoiceAddress) {
		this.invoiceAddress = invoiceAddress;
	}

	public String getInvoiceTel() {
		return invoiceTel;
	}

	public void setInvoiceTel(String invoiceTel) {
		this.invoiceTel = invoiceTel;
	}

	public BigDecimal getTaxRate() {
		return taxRate;
	}

	public void setTaxRate(BigDecimal taxRate) {
		this.taxRate = taxRate;
	}

	public BigDecimal getApplyQuantity() {
		return applyQuantity;
	}

	public void setApplyQuantity(BigDecimal applyQuantity) {
		this.applyQuantity = applyQuantity;
	}

	public BigDecimal getApplyPrice() {
		return applyPrice;
	}

	public void setApplyPrice(BigDecimal applyPrice) {
		this.applyPrice = applyPrice;
	}

	public BigDecimal getApplyMoney() {
		return applyMoney;
	}

	public void setApplyMoney(BigDecimal applyMoney) {
		this.applyMoney = applyMoney;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public BigDecimal getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(BigDecimal applicantName) {
		this.applicantName = applicantName;
	}

	public Date getApplicantTime() {
		return applicantTime;
	}

	public void setApplicantTime(Date applicantTime) {
		this.applicantTime = applicantTime;
	}

	public String getApproveName() {
		return approveName;
	}

	public void setApproveName(String approveName) {
		this.approveName = approveName;
	}

	public Date getApproveTime() {
		return ApproveTime;
	}

	public void setApproveTime(Date approveTime) {
		ApproveTime = approveTime;
	}

	public Integer getApplyStatus() {
		return applyStatus;
	}

	public void setApplyStatus(Integer applyStatus) {
		this.applyStatus = applyStatus;
	}

	public Integer getDISABLED() {
		return dISABLED;
	}

	public void setDISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getInvoiceTitle() {
		return invoiceTitle;
	}

	public void setInvoiceTitle(String invoiceTitle) {
		this.invoiceTitle = invoiceTitle;
	}

	public String getTrackingNo() {
		return trackingNo;
	}

	public void setTrackingNo(String trackingNo) {
		this.trackingNo = trackingNo;
	}

	public String getGoodName() {
		return goodName;
	}

	public void setGoodName(String goodName) {
		this.goodName = goodName;
	}

	public String getDeliveryID() {
		return deliveryID;
	}

	public void setDeliveryID(String deliveryID) {
		this.deliveryID = deliveryID;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public Integer getInvoiceApplyRelID() {
		return invoiceApplyRelID;
	}

	public void setInvoiceApplyRelID(Integer invoiceApplyRelID) {
		this.invoiceApplyRelID = invoiceApplyRelID;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getCollectInvoiceAddress() {
		return collectInvoiceAddress;
	}

	public void setCollectInvoiceAddress(String collectInvoiceAddress) {
		this.collectInvoiceAddress = collectInvoiceAddress;
	}

	public String getCollectTel() {
		return collectTel;
	}

	public void setCollectTel(String collectTel) {
		this.collectTel = collectTel;
	}

	public String getCollectInvoicePeople() {
		return collectInvoicePeople;
	}

	public void setCollectInvoicePeople(String collectInvoicePeople) {
		this.collectInvoicePeople = collectInvoicePeople;
	}

	public InvoiceApply4Check getInvoiceApply4Check() {
		return invoiceApply4Check;
	}

	public void setInvoiceApply4Check(InvoiceApply4Check invoiceApply4Check) {
		this.invoiceApply4Check = invoiceApply4Check;
	}

	public Boolean getIsDetailed() {
		return isDetailed;
	}

	public void setIsDetailed(Boolean isDetailed) {
		this.isDetailed = isDetailed;
	}

	public Integer getApplyOrigin() {
		return applyOrigin;
	}

	public void setApplyOrigin(Integer applyOrigin) {
		this.applyOrigin = applyOrigin;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public BigDecimal getDeliveryWeight() {
		return deliveryWeight;
	}

	public void setDeliveryWeight(BigDecimal deliveryWeight) {
		this.deliveryWeight = deliveryWeight;
	}

	public Date getTradeDate() {
		return tradeDate;
	}

	public void setTradeDate(Date tradeDate) {
		this.tradeDate = tradeDate;
	}

	public Integer getIsFullDetailed() {
		return isFullDetailed;
	}

	public void setIsFullDetailed(Integer isFullDetailed) {
		this.isFullDetailed = isFullDetailed;
	}

	public String getCouponNumber() {
		return couponNumber;
	}

	public void setCouponNumber(String couponNumber) {
		this.couponNumber = couponNumber;
	}

	public Integer getIsInvoiceOpen() {
		return isInvoiceOpen;
	}

	public void setIsInvoiceOpen(Integer isInvoiceOpen) {
		this.isInvoiceOpen = isInvoiceOpen;
	}
	
}
