/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmBanlanceListForOra
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.model;

import java.math.BigDecimal;

import shcem.base.dao.model.BaseObject;

public class FirmBanlanceListForOra extends BaseObject implements java.io.Serializable, Cloneable {

	private static final long serialVersionUID = -7464587171301763763L;

	/** 交易商账号 */
	private String FIRMID;

	/** 交易商名称 */
	private String NAME;

	/** 交易系统当前余额 */
	private BigDecimal F_BALANCE;

	/** 财务结算余额 */
	private BigDecimal L_BALANCE;

	/** 财务未结算金额 */
	private BigDecimal Y_BALANCE;

	/** 差额 */
	private BigDecimal BALANCESUBTRACT;

	/** 担保金 */
	private BigDecimal LASTWARRANTY;

	/** 临时资金 */
	private BigDecimal FROZENFUNDS;

	/** 可提资金 */
	private BigDecimal USER_BALANCE;
	
	/** 当日浮动盈亏*/
	private BigDecimal RUNTIMEFL;
	
	/** 上日浮动盈亏 */
	private BigDecimal CLEARFL;

	public String getFIRMID() {
		return FIRMID;
	}

	public void setFIRMID(String fIRMID) {
		FIRMID = fIRMID;
	}

	public String getNAME() {
		return NAME;
	}

	public void setNAME(String nAME) {
		NAME = nAME;
	}

	public BigDecimal getF_BALANCE() {
		return F_BALANCE;
	}

	public void setF_BALANCE(BigDecimal f_BALANCE) {
		F_BALANCE = f_BALANCE;
	}

	public BigDecimal getL_BALANCE() {
		return L_BALANCE;
	}

	public void setL_BALANCE(BigDecimal l_BALANCE) {
		L_BALANCE = l_BALANCE;
	}

	public BigDecimal getY_BALANCE() {
		return Y_BALANCE;
	}

	public void setY_BALANCE(BigDecimal y_BALANCE) {
		Y_BALANCE = y_BALANCE;
	}

	public BigDecimal getBALANCESUBTRACT() {
		return BALANCESUBTRACT;
	}

	public void setBALANCESUBTRACT(BigDecimal bALANCESUBTRACT) {
		BALANCESUBTRACT = bALANCESUBTRACT;
	}

	public BigDecimal getLASTWARRANTY() {
		return LASTWARRANTY;
	}

	public void setLASTWARRANTY(BigDecimal lASTWARRANTY) {
		LASTWARRANTY = lASTWARRANTY;
	}

	public BigDecimal getFROZENFUNDS() {
		return FROZENFUNDS;
	}

	public void setFROZENFUNDS(BigDecimal fROZENFUNDS) {
		FROZENFUNDS = fROZENFUNDS;
	}

	public BigDecimal getUSER_BALANCE() {
		return USER_BALANCE;
	}

	public void setUSER_BALANCE(BigDecimal uSER_BALANCE) {
		USER_BALANCE = uSER_BALANCE;
	}

	public BigDecimal getRUNTIMEFL() {
		return RUNTIMEFL;
	}

	public void setRUNTIMEFL(BigDecimal rUNTIMEFL) {
		RUNTIMEFL = rUNTIMEFL;
	}

	public BigDecimal getCLEARFL() {
		return CLEARFL;
	}

	public void setCLEARFL(BigDecimal cLEARFL) {
		CLEARFL = cLEARFL;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}