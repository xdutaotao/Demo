/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: ReportServiceImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月15日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.constant.ResultCode;
import shcem.finance.component.IFirmBanlanceOraManager;
import shcem.finance.dao.model.FirmTradeFeeForOra;
import shcem.finance.service.IReportService;
import shcem.finance.service.model.ExportFirmTradeFeeForOra;
import shcem.finance.util.FinanceOraSysData;
import shcem.util.Common;
import shcem.util.CopyProperties;
import shcem.util.ExportExcel;
import shcem.util.JsonUtil;
import shcem.util.UploadHttpFile;

/**
 * @author wlpod
 *
 */
public class ReportServiceImpl extends BaseServiceImpl implements IReportService {

	private IFirmBanlanceOraManager mgrOra = (IFirmBanlanceOraManager) FinanceOraSysData
			.getBean(Constants.BEAN_BALANCEORA_MGR);

	@Override
	public String getTradeFeeSum(String params) {
		this.log.info(this.getClass().getName() + " getTradeFeeSum() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);

		// 查询条件和pageInfo设置
		List<Condition> conditionList = new ArrayList<Condition>(); // 允许的查询参数列表，定义字段，操作符及类型,查询json固定模型queryModel
		conditionList.add(new Condition("firmid", ">=", "", "String", "startFirmId"));
		conditionList.add(new Condition("firmid", "<=", "", "String", "endFirmId"));
		conditionList.add(new Condition("to_char(b_date, 'yyyy-mm-dd')", ">=", "", "String", "startDate"));
		conditionList.add(new Condition("to_char(b_date, 'yyyy-mm-dd')", "<=", "", "String", "endDate"));
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		String firmName = "";
		if (!queryModel.isNull("firmName")) {
			firmName = queryModel.getString("firmName");
		}

		List<FirmTradeFeeForOra> list = null;
		// 查询交易商手续费
		try {
			list = mgrOra.queryFirmTradeFee(qc, pageInfo, firmName);
		} catch (Exception err) {
			this.log.error("交易商手续费取得失败：" + err.getMessage());
			setResultData("10104", null, err.getMessage());
			this.log.info(this.getClass().getName() + " getTradeFeeSum() End");
			return rtnData.toString();
		}

		JSONArray retData;
		JSONObject jsonObj = new JSONObject();
		try {
			retData = JsonUtil.coverModelToJSONArray(list);
			jsonObj.put("total", pageInfo.getTotalRecords());
			jsonObj.put("result", retData);
			setResultData("00000", jsonObj);
		} catch (Exception e) {
			this.log.error("交易商手续费列表数据转换失败：" + e.getMessage());
			setResultData("10105", null, e.getMessage());
		}
		this.log.info(this.getClass().getName() + " getTradeFeeSum() End");
		return rtnData.toString();
	}

	@Override
	public String exportTradeFeeSum(String params) {
		this.log.info(this.getClass().getName() + " exportTradeFeeSum() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);

		// 查询条件和pageInfo设置
		List<Condition> conditionList = new ArrayList<Condition>(); // 允许的查询参数列表，定义字段，操作符及类型,查询json固定模型queryModel
		conditionList.add(new Condition("firmid", ">=", "", "String", "startFirmId"));
		conditionList.add(new Condition("firmid", "<=", "", "String", "endFirmId"));
		conditionList.add(new Condition("to_char(b_date, 'yyyy-mm-dd')", ">=", "", "String", "startDate"));
		conditionList.add(new Condition("to_char(b_date, 'yyyy-mm-dd')", "<=", "", "String", "endDate"));
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		String firmName = "";
		if (!queryModel.isNull("firmName")) {
			firmName = queryModel.getString("firmName");
		}
		List<FirmTradeFeeForOra> list = null;
		// 查询交易商手续费
		try {
			list = mgrOra.queryFirmTradeFee(qc, null, firmName);
		} catch (Exception err) {
			this.log.error("交易商手续费取得失败：" + err.getMessage());
			setResultData("10104", null, err.getMessage());
			this.log.info(this.getClass().getName() + " exportTradeFeeSum() End");
			return rtnData.toString();
		}

		try {
			JSONObject jsonObj = new JSONObject();
			// 手续费导出
			ExportExcel<ExportFirmTradeFeeForOra> ex = new ExportExcel<ExportFirmTradeFeeForOra>();
			String[] headers = { "交易商账号", "手续费", "交易商", "地址", "银行", "银行账号", "电话", "税号", "发票地址", "发票联系人" };
			ByteArrayOutputStream out = null;
			ByteArrayInputStream in = null;
			try {
				String time = Common.df6.format(new Date());
				String strfileName = "手续费导出报表" + time.toString() + ".xls";
				out = new ByteArrayOutputStream();

				List<ExportFirmTradeFeeForOra> exportList = new ArrayList<ExportFirmTradeFeeForOra>();
				for (FirmTradeFeeForOra before : list) {
					ExportFirmTradeFeeForOra after = new ExportFirmTradeFeeForOra();
					CopyProperties.copyProperties(before, after);
					exportList.add(after);
				}

				ex.exportExcel("手续费导出", headers, exportList, out, null);
				in = new ByteArrayInputStream(out.toByteArray());
				String uploadUrl = Common.getUploadUrl(this.getMode());
				String httpUrl = UploadHttpFile.uploadFile(in, strfileName, uploadUrl);
				// 清理资源
				out.close();
				in.close();
				if (null != httpUrl) {
					this.log.debug("httpUrl:" + httpUrl);
					jsonObj.put("httpUrl", httpUrl);
					jsonObj.put("fileName", strfileName);
					setResultData(ResultCode.CODE00000.getValue(), jsonObj);
				} else {
					setResultData(ResultCode.CODE10104.getValue(), null);
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				// 清理资源
				out.close();
				in.close();
			}
		} catch (Exception e) {
			this.log.error("手续费导出列表转换失败：" + e.getMessage());
			setResultData(ResultCode.CODE10104.getValue(), null, e.getMessage());
		}
		this.log.info(this.getClass().getName() + " exportTradeFeeSum() End");
		return rtnData.toString();
	}
}
