/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: TLeads
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.model;

import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * (TLeads)
 * 
 * @author wlpod
 * @version 1.0.0 2016-05-12
 */
public class TLeads extends BaseObject implements java.io.Serializable, Cloneable {

	private static final long serialVersionUID = -7464587171301763763L;

	private Long ID;
	private Integer dISABLED;
	private String rECCREATEBY;
	private Date rECCREATETIME;
	private String rECMODIFYBY;
	private Date rECMODIFYTIME;
	private String userCode;
	private String traderID;
	private String firmID;
	private Integer tradeTmptId;
	private Integer isAnonymity;
	private Integer categoryLeafID;
	private Integer brandID;
	private Integer sourcePlaceID;
	private Integer direction;
	private Integer tradeUnit;
	private BigDecimal tradeUnitNumber;
	private Integer quantity;
	private Integer minQuantity;
	private BigDecimal price;
	private Integer packageStandard;
	private Integer storeHouseId;
	private Integer settlementMethod;
	private Date deliveryDate;
	private Integer goodsType;
	private Integer paymentStatus;
	private Integer leadsStatus;
	private Integer addressID;
	private Integer deliveryPlaceId;
	private String storeHouseFN;
	private String storeContactName;
	private String storeContactTelNo;
	private String leadsCode;
	
	/**交易场类型**/
	private Integer tradeType;
	

	public Integer getTradeType() {
		return tradeType;
	}

	public void setTradeType(Integer tradeType) {
		this.tradeType = tradeType;
	}

	public Long getID() {
		return ID;
	}

	public void setID(Long iD) {
		ID = iD;
	}

	public Integer getdISABLED() {
		return dISABLED;
	}

	public void setdISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public String getrECCREATEBY() {
		return rECCREATEBY;
	}

	public void setrECCREATEBY(String rECCREATEBY) {
		this.rECCREATEBY = rECCREATEBY;
	}

	public Date getrECCREATETIME() {
		return rECCREATETIME;
	}

	public void setrECCREATETIME(Date rECCREATETIME) {
		this.rECCREATETIME = rECCREATETIME;
	}

	public String getrECMODIFYBY() {
		return rECMODIFYBY;
	}

	public void setrECMODIFYBY(String rECMODIFYBY) {
		this.rECMODIFYBY = rECMODIFYBY;
	}

	public Date getrECMODIFYTIME() {
		return rECMODIFYTIME;
	}

	public void setrECMODIFYTIME(Date rECMODIFYTIME) {
		this.rECMODIFYTIME = rECMODIFYTIME;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getTraderID() {
		return traderID;
	}

	public void setTraderID(String traderID) {
		this.traderID = traderID;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public Integer getTradeTmptId() {
		return tradeTmptId;
	}

	public void setTradeTmptId(Integer tradeTmptId) {
		this.tradeTmptId = tradeTmptId;
	}

	public Integer getIsAnonymity() {
		return isAnonymity;
	}

	public void setIsAnonymity(Integer isAnonymity) {
		this.isAnonymity = isAnonymity;
	}

	public Integer getCategoryLeafID() {
		return categoryLeafID;
	}

	public void setCategoryLeafID(Integer categoryLeafID) {
		this.categoryLeafID = categoryLeafID;
	}

	public Integer getBrandID() {
		return brandID;
	}

	public void setBrandID(Integer brandID) {
		this.brandID = brandID;
	}

	public Integer getSourcePlaceID() {
		return sourcePlaceID;
	}

	public void setSourcePlaceID(Integer sourcePlaceID) {
		this.sourcePlaceID = sourcePlaceID;
	}

	public Integer getDirection() {
		return direction;
	}

	public void setDirection(Integer direction) {
		this.direction = direction;
	}

	public Integer getTradeUnit() {
		return tradeUnit;
	}

	public void setTradeUnit(Integer tradeUnit) {
		this.tradeUnit = tradeUnit;
	}

	public BigDecimal getTradeUnitNumber() {
		return tradeUnitNumber;
	}

	public void setTradeUnitNumber(BigDecimal tradeUnitNumber) {
		this.tradeUnitNumber = tradeUnitNumber;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Integer getMinQuantity() {
		return minQuantity;
	}

	public void setMinQuantity(Integer minQuantity) {
		this.minQuantity = minQuantity;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Integer getPackageStandard() {
		return packageStandard;
	}

	public void setPackageStandard(Integer packageStandard) {
		this.packageStandard = packageStandard;
	}

	public Integer getStoreHouseId() {
		return storeHouseId;
	}

	public void setStoreHouseId(Integer storeHouseId) {
		this.storeHouseId = storeHouseId;
	}

	public Integer getSettlementMethod() {
		return settlementMethod;
	}

	public void setSettlementMethod(Integer settlementMethod) {
		this.settlementMethod = settlementMethod;
	}

	public Date getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public Integer getGoodsType() {
		return goodsType;
	}

	public void setGoodsType(Integer goodsType) {
		this.goodsType = goodsType;
	}

	public Integer getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(Integer paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public Integer getLeadsStatus() {
		return leadsStatus;
	}

	public void setLeadsStatus(Integer leadsStatus) {
		this.leadsStatus = leadsStatus;
	}

	public Integer getAddressID() {
		return addressID;
	}

	public void setAddressID(Integer addressID) {
		this.addressID = addressID;
	}

	public Integer getDeliveryPlaceId() {
		return deliveryPlaceId;
	}

	public void setDeliveryPlaceId(Integer deliveryPlaceId) {
		this.deliveryPlaceId = deliveryPlaceId;
	}

	public String getStoreHouseFN() {
		return storeHouseFN;
	}

	public void setStoreHouseFN(String storeHouseFN) {
		this.storeHouseFN = storeHouseFN;
	}

	public String getStoreContactName() {
		return storeContactName;
	}

	public void setStoreContactName(String storeContactName) {
		this.storeContactName = storeContactName;
	}

	public String getStoreContactTelNo() {
		return storeContactTelNo;
	}

	public void setStoreContactTelNo(String storeContactTelNo) {
		this.storeContactTelNo = storeContactTelNo;
	}

	public String getLeadsCode() {
		return leadsCode;
	}

	public void setLeadsCode(String leadsCode) {
		this.leadsCode = leadsCode;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}