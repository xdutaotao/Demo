/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FVoucher
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import shcem.base.dao.model.BaseObject;

/**
 * (f_Voucher)
 * 
 * @author wlpod
 * @version 1.0.0 2016-05-12
 */
public class FVoucher extends BaseObject implements java.io.Serializable, Cloneable {

	private static final long serialVersionUID = -7464587171301763763L;

	/** 记录号（凭证代码） */
	private Integer voucherno;

	/** 生成日期 */
	private Date bDate;

	/** 摘要代码 */
	private String summaryno;

	/** 摘要内容 */
	private String summary;

	/** 备注 */
	private String note;

	/** 录入人 */
	private String inputuser;

	/** 录入时间 */
	private String inputtime;

	/** 审核人 */
	private String auditor;

	/** 审核时间 */
	private String audittime;

	/** 审核内容 */
	private String auditnote;

	/** 状态 */
	private Integer status;

	/** 合同号/报盘ID */
	private String contractno;

	/** 资金流水号 */
	private Integer fundflowid;

	/** 交易商ID */
	private String firmid;

	/** 凭证分录信息 */
	private List<FVoucherEntry> voucherEntrys = new ArrayList<FVoucherEntry>();

	public Integer getVoucherno() {
		return voucherno;
	}

	public void setVoucherno(Integer voucherno) {
		this.voucherno = voucherno;
	}

	public Date getbDate() {
		return bDate;
	}

	public void setbDate(Date bDate) {
		this.bDate = bDate;
	}

	public String getSummaryno() {
		return summaryno;
	}

	public void setSummaryno(String summaryno) {
		this.summaryno = summaryno;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getInputuser() {
		return inputuser;
	}

	public void setInputuser(String inputuser) {
		this.inputuser = inputuser;
	}

	public String getInputtime() {
		return inputtime;
	}

	public void setInputtime(String inputtime) {
		this.inputtime = inputtime;
	}

	public String getAuditor() {
		return auditor;
	}

	public void setAuditor(String auditor) {
		this.auditor = auditor;
	}

	public String getAudittime() {
		return audittime;
	}

	public void setAudittime(String audittime) {
		this.audittime = audittime;
	}

	public String getAuditnote() {
		return auditnote;
	}

	public void setAuditnote(String auditnote) {
		this.auditnote = auditnote;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getContractno() {
		return contractno;
	}

	public void setContractno(String contractno) {
		this.contractno = contractno;
	}

	public Integer getFundflowid() {
		return fundflowid;
	}

	public void setFundflowid(Integer fundflowid) {
		this.fundflowid = fundflowid;
	}

	public String getFirmid() {
		return firmid;
	}

	public void setFirmid(String firmid) {
		this.firmid = firmid;
	}

	public List<FVoucherEntry> getVoucherEntrys() {
		return voucherEntrys;
	}

	public void setVoucherEntrys(List<FVoucherEntry> voucherEntrys) {
		this.voucherEntrys = voucherEntrys;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}