/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FinanceSysData
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.util;

import java.io.Serializable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * ProductSysData
 * 
 * @author chiyong
 * @version 1.0
 */
public class FinanceOraSysData implements Serializable {
	private static final long serialVersionUID = 1L;
	private static Log logger = LogFactory.getLog(FinanceOraSysData.class);
	private static final String beanConfig = "classpath:financeOraBeans.xml";
	private static ApplicationContext factory;

	public static void init() {
		factory = new ClassPathXmlApplicationContext(beanConfig);
	}

	public static Object getBean(String beanId) {
		Object obj = null;

		if (factory == null) {
			synchronized (FinanceOraSysData.class) {
				if (factory == null) {
					init();
				}
			}
		}
		if (factory != null)
			obj = factory.getBean(beanId);
		return obj;
	}

	public static BeanFactory getBeanFactory() {
		if (factory == null) {
			synchronized (FinanceOraSysData.class) {
				if (factory == null) {
					init();
				}
			}
		}
		return factory;
	}
}
