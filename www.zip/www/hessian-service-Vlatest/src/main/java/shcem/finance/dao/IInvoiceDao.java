package shcem.finance.dao;

import java.math.BigDecimal;
import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.ExportModel.InvoiceApply4Export;
import shcem.finance.ExportModel.InvoiceCollect4Export;
import shcem.finance.dao.model.ExportInvoiceCollectDetail;
import shcem.finance.dao.model.FinancialBills;
import shcem.finance.dao.model.InvoiceApply4Check;
import shcem.finance.dao.model.InvoiceApplyRel;
import shcem.finance.dao.model.InvoiceCollectDetail;
import shcem.finance.dao.model.InvoiceCollectDetailRel;
import shcem.finance.dao.model.InvoiceDetailRel;
import shcem.trade.dao.model.Order;
import shcem.finance.dao.model.InvoiceApply;
import shcem.finance.dao.model.InvoiceDetail;
import shcem.member.dao.model.Firminvoice;
/**
 * 发票相关
 * @author wangshuai
 *
 */
public abstract interface IInvoiceDao extends DAO {

	List<FinancialBills> getFinancialBillsList(QueryConditions qc,
			PageInfo pageInfo, int financialBillsType);
	
	/**
	 * 插入收票详细表
	 * @param invoiceCollectDetail
	 * @return 主键ID
	 */
	int insertInvoiceCollectDetail(InvoiceCollectDetail invoiceCollectDetail);
	
	/**
	 * 更新收票详细表
	 * @param invoiceCollectDetail
	 * @return
	 */
	int updateInvoiceCollectDetailByID(InvoiceCollectDetail invoiceCollectDetail);
	
	/**
	 * 根据id 查询收票详细表
	 * @param id
	 * @return
	 */
	InvoiceCollectDetail selectInvoiceCollectDetailByID(Integer id);
	
	/**
	 * 根据relationID 查询收票详细表列表
	 * @param relationID
	 * @return
	 */
	List<InvoiceCollectDetail> selectInvoiceCollectDetailListByRelationID(String relationID);
	
//	/**
//	 * 更新收票详细表的DISABLED
//	 * @return
//	 */
//	int updateInvoiceCollectDetailOfDISABLED(Integer id,Integer disabled,String modifyBy);
	
	/**
	 * 更新订单的收票状态（0：未收票  5：部分收票 10：全部收票）
	 * @return
	 */
	int updateOrderOfInvoiceCollectStatus(String orderId,Integer invoiceCollectStatus,String modifyBy);
	
	/**
	 * 统计成交单下所有收票记录状态是【正常】的总金额和【正常】的总数量（吨）
	 * @return
	 */
	InvoiceCollectDetail countInvoiceTotalMoneyByOrderId(String orderId);
	
	
	/**
	 * 插入收票关联表
	 * @param invoiceCollectDetailRel
	 * @return
	 */
	int insertInvoiceCollectDetailRel(InvoiceCollectDetailRel invoiceCollectDetailRel);
	
	/**
	 * 更新收票关联表
	 * @param invoiceCollectDetailRel
	 * @return
	 */
	int updateInvoiceCollectDetailRelByID(InvoiceCollectDetailRel invoiceCollectDetailRel);
	
	/**
	 * 更新收票记录的状态
	 * @param id 收票关联表ID
	 * @param status 收票关联表状态  1：正常 , 5：失效
	 * @param modifyBy 修改人
	 * @return
	 */
	int updateInvoiceCollectDetailRelOfStatus(Integer id,Integer status,String modifyBy);
	
	
	List<Order> selectOrderList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 根据订单ID 获取成交单收票的详情
	 * @param orderId
	 * @return
	 */
	Order getOrderInvoiceCollectDetail(String orderId);
	
	/**
	 * 根据ID查询 收票关联表信息
	 * @param id
	 * @return
	 */
	InvoiceCollectDetailRel selectInvoiceCollectDetailRelById(Integer id);


	int addInvoiceApply(InvoiceApply invoiceApply, String userName);

	/**
	 * 
	 * @param invoiceApplyID
	 * @param deliveryID
	 * @param userName
	 * @return
	 */
	String addInvoiceApplyRel(int invoiceApplyID, String deliveryID, String userName);

	void rollBack();

	int getInvoiceApplyRelCount(String string, Integer invoiceType);

	InvoiceApply getInvoiceDetail(String firmID);

	List<InvoiceApply> getInvoiceApplyList(QueryConditions qc,
			PageInfo pageInfo);
	
	List<InvoiceApply4Check> getInvoiceApply4CheckList(QueryConditions qc,
			PageInfo pageInfo, boolean replace);
	
	/**
	 * 更新申请流水
	 * @param invoiceApplyID
	 * @param applyStatus
	 * @return
	 */
	int updateInvoiceApply(int invoiceApplyID, int applyStatus);

	int deleteInvoiceDetailRel(int invoiceApplyRelID);

	InvoiceApply getInvoiceApply(int invoiceApplyID);

	int addInvoiceDetail(InvoiceDetail invoiceDetail, String userName);

	/**
	 * 新增  发票流水关联表
	 * @param invoiceDetailID
	 * @param applyRelID
	 * @param userName
	 * @return
	 */
	int addInvoiceDetailRel(int invoiceDetailID, Integer applyRelID,
			String userName);

	int getInvoiceDetailCount(String invoiceNo);

	/**
	 * 更新发票的快递单号
	 * @param trackingNo
	 * @param invoiceNo
	 * @param userName
	 * @return
	 */
	int updateInvoiceDetail(String trackingNo, String invoiceNo, String userName);

	/**
	 * 更新开票申请 状态  1：已申请，待财务处理 5：已审批 ，10：已拒绝，15：开票完成 
	 * @param applyRelID
	 * @param i
	 * @return
	 */
	int updateInvoiceApplyStatus(Integer applyRelID, int applyStatus,String userName);

	List<InvoiceDetailRel> getInvoiceDetailRel(int invoiceApplyID);

	int disabledInvoiceDetail(Integer invoiceDetailID);
	/**
	 * 导出收票详情列表
	 * @param qc
	 * @param pageInfo
	 * @param replace 
	 * @return
	 */
	List<InvoiceCollect4Export> exportInvoiceCollectDetailList(QueryConditions qc, PageInfo pageInfo, boolean replace);
	
	/**
	 * 查询 开票申请流水表的数据
	 * @return
	 */
	List<InvoiceApplyRel> getInvoiceApplyRelByInvoiceApplyID(Integer invoiceApplyID);
	
	/**
	 * 废弃 开票申请关联表的数据
	 * @return
	 */
	int disabledInvoiceApplyRelByInvoiceApplyID(Integer invoiceApplyID,String userName);
	
	/**
	 * 废弃 发票详细表
	 * @return
	 */
	int disabledInvoiceDetailRelByApplyRelID(Integer ApplyRelID,String userName);

	List<Firminvoice> getfirmInvoicePlaceList(String firmID);

	/**
	 * 
	 * @param deliveryID
	 * @param tableField
	 * @param enabled 
	 * @param userName
	 * @return
	 */
	int disOrEnabled(String deliveryID, String tableField, int enabled,
			String userName);

	/**
	 * 开票详情修改(未开票完成能修改)
	 * @param invoiceApply
	 * @param userName
	 * @return
	 */
	int updateInvoiceApplyDetail(InvoiceApply invoiceApply, String userName);

	int getInvoiceApplyList4ExportCount(QueryConditions qc);
	
	List<InvoiceApply4Export> getInvoiceApplyList4Export(QueryConditions qc,PageInfo pageInfo,boolean replace);

	int getExportInvoiceCollectDetailCount(QueryConditions qc, PageInfo pageInfo);

	/**
	 * @param qc
	 * @param pageInfo
	 * @param invoiceStatus 充值型优惠券列表展示位置：0展示在"开票管理"页面 2 展示在"开票申请流水"页面 
	 * @return
	 */
	List<InvoiceApply> getCouponInvoiceApplyListByCustomer(QueryConditions qc,
			PageInfo pageInfo, int invoiceStatus);

	int updateCouponInvoiceApplyListByCustomer(InvoiceApply invoiceApply,
			int invoiceApplyID, String userName);

	int updateIsInvoiceOpen(int invoiceApplyID, String userName,int IsInvoiceOpen);

	int getCouponInvoiceApplyListByCustomerCount(QueryConditions qc);

	List<InvoiceApply4Export> getCouponInvoiceApplyList4Export(
			QueryConditions qc, PageInfo pageInfo, boolean replace,
			int invoiceStatus);
}
