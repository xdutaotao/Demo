/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FBanks
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.model;

import java.math.BigDecimal;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import shcem.base.dao.model.BaseObject;

/**
 * (F_B_BANKS)
 * 
 * @author wlpod
 * @version 1.0.0 2016-05-12
 */
public class FBanks extends BaseObject implements java.io.Serializable,Cloneable {

	private static final long serialVersionUID = -7464587171301763763L;

	/**  */
	@NotNull
	@Size(max=32)
	private String bankID;

	/**  */
	@NotNull
	@Size(max=100)
	private String bankName;

	/**  */
	@NotNull
	@Digits(fraction = 2, integer = 18)
	private BigDecimal maxPerSglTransMoney;

	/**  */
	@NotNull
	@Digits(fraction = 2, integer = 18)
	private BigDecimal maxPerTransMoney;

	/**  */
	@NotNull
	@Digits(fraction = 0, integer = 10)
	private Integer maxPerTransCount;

	/**  */
	@NotNull
	@Digits(fraction = 2, integer = 18)
	private BigDecimal maxAuditMoney;

	/**  */
	@Size(max=100)
	private String adapterClassName;

	/**  */
	@NotNull
	@Digits(fraction = 0, integer = 10)
	private Integer validFlag;

	/**  */
	@NotNull
	@Size(max=8)
	private String beginTime;

	/**  */
	@NotNull
	@Size(max=8)
	private String endTime;

	/**  */
	@Digits(fraction = 0, integer = 10)
	private Integer control;

	
	/**
	 * @return the bankID
	 */
	public String getBankID() {
		return bankID;
	}

	/**
	 * @param bankID the bankID to set
	 */
	public void setBankID(String bankID) {
		this.bankID = bankID;
	}

	/**
	 * @return the bankName
	 */
	public String getBankName() {
		return bankName;
	}

	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * @return the maxPerSglTransMoney
	 */
	public BigDecimal getMaxPerSglTransMoney() {
		return maxPerSglTransMoney;
	}

	/**
	 * @param maxPerSglTransMoney the maxPerSglTransMoney to set
	 */
	public void setMaxPerSglTransMoney(BigDecimal maxPerSglTransMoney) {
		this.maxPerSglTransMoney = maxPerSglTransMoney;
	}

	/**
	 * @return the maxPerTransMoney
	 */
	public BigDecimal getMaxPerTransMoney() {
		return maxPerTransMoney;
	}

	/**
	 * @param maxPerTransMoney the maxPerTransMoney to set
	 */
	public void setMaxPerTransMoney(BigDecimal maxPerTransMoney) {
		this.maxPerTransMoney = maxPerTransMoney;
	}

	/**
	 * @return the maxPerTransCount
	 */
	public Integer getMaxPerTransCount() {
		return maxPerTransCount;
	}

	/**
	 * @param maxPerTransCount the maxPerTransCount to set
	 */
	public void setMaxPerTransCount(Integer maxPerTransCount) {
		this.maxPerTransCount = maxPerTransCount;
	}

	/**
	 * @return the maxAuditMoney
	 */
	public BigDecimal getMaxAuditMoney() {
		return maxAuditMoney;
	}

	/**
	 * @param maxAuditMoney the maxAuditMoney to set
	 */
	public void setMaxAuditMoney(BigDecimal maxAuditMoney) {
		this.maxAuditMoney = maxAuditMoney;
	}

	/**
	 * @return the adapterClassName
	 */
	public String getAdapterClassName() {
		return adapterClassName;
	}

	/**
	 * @param adapterClassName the adapterClassName to set
	 */
	public void setAdapterClassName(String adapterClassName) {
		this.adapterClassName = adapterClassName;
	}

	/**
	 * @return the validFlag
	 */
	public Integer getValidFlag() {
		return validFlag;
	}

	/**
	 * @param validFlag the validFlag to set
	 */
	public void setValidFlag(Integer validFlag) {
		this.validFlag = validFlag;
	}

	/**
	 * @return the beginTime
	 */
	public String getBeginTime() {
		return beginTime;
	}

	/**
	 * @param beginTime the beginTime to set
	 */
	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}

	/**
	 * @return the endTime
	 */
	public String getEndTime() {
		return endTime;
	}

	/**
	 * @param endTime the endTime to set
	 */
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	/**
	 * 获取control
	 * 
	 * @return control
	 */
	public Integer getControl() {
		return this.control;
	}

	/**
	 * 设置control
	 * 
	 * @param control
	 *            control
	 */
	public void setControl(Integer control) {
		this.control = control;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}