package shcem.finance.dao.model;

import shcem.base.dao.model.BaseObject;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by cwei on 2016/8/24.
 * 预售授信流水表
 */
public class SPreSaleFundFlow extends BaseObject implements java.io.Serializable, Cloneable{

    private static final long serialVersionUID = 2158171819872663891L;

    
	private Integer fundFlowID;
	private String firmID;
	private String operCode;
	private BigDecimal amount;
	private BigDecimal balance;
	private Date createtime;
	private String objectID;
	private Integer flowType;
	private String firmName;
	private String operName;
	private String fUNDDCFLAG;


    public Integer getFundFlowID() {
		return fundFlowID;
	}

	public void setFundFlowID(Integer fundFlowID) {
		this.fundFlowID = fundFlowID;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getOperCode() {
		return operCode;
	}

	public void setOperCode(String operCode) {
		this.operCode = operCode;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getObjectID() {
		return objectID;
	}

	public void setObjectID(String objectID) {
		this.objectID = objectID;
	}

	public Integer getFlowType() {
		return flowType;
	}

	public void setFlowType(Integer flowType) {
		this.flowType = flowType;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public String getOperName() {
		return operName;
	}

	public void setOperName(String operName) {
		this.operName = operName;
	}

	public String getFUNDDCFLAG() {
		return fUNDDCFLAG;
	}

	public void setFUNDDCFLAG(String fUNDDCFLAG) {
		this.fUNDDCFLAG = fUNDDCFLAG;
	}

	public String toString() {
        return null;
    }

    public boolean equals(Object paramObject) {
        return false;
    }

    public int hashCode() {
        return 0;
    }
}
