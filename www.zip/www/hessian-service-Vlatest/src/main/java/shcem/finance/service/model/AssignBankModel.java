/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: BalanceModel
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.service.model;

import java.io.Serializable;

import org.json.JSONObject;

import shcem.base.service.model.BaseServiceObject;

/**
 * @author wlpod
 *
 */
public class AssignBankModel extends BaseServiceObject implements Serializable {

	private static final long serialVersionUID = -7464587171301763763L;

	/**
	 * 银行代码
	 */
	private String bankID;
	/**
	 * 银行名称
	 */
	private String bankName;
	/**
	 * 默认出金审核金额
	 */
	private double maxAuditMoney;
	/**
	 * 默认每日最大转账金额
	 */
	private double maxPerTransMoney;
	/**
	 * 默认单笔最大转账金额
	 */
	private double maxPerSglTransMoney;
	/**
	 * 默认每日最大转账次数
	 */
	private int maxPerTransCount;

	/**
	 * 适配器实现类名称
	 */
	private String adapterClassname;
	/**
	 * 是否可用状态：0：可用1：不可用
	 */
	private int validFlag;
	/** 银行转账开始时间 */
	private String beginTime;
	/**
	 * 银行转账结束时间
	 */
	private String endTime;
	/**
	 * 转账交易是否收到约束 0 受到双重约束，1不受约束，2受交易日约束，3受交易时间约束
	 */
	private int control;

	public String getBankID() {
		return bankID;
	}

	public void setBankID(String bankID) {
		this.bankID = bankID;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public double getMaxAuditMoney() {
		return maxAuditMoney;
	}

	public void setMaxAuditMoney(double maxAuditMoney) {
		this.maxAuditMoney = maxAuditMoney;
	}

	public double getMaxPerTransMoney() {
		return maxPerTransMoney;
	}

	public void setMaxPerTransMoney(double maxPerTransMoney) {
		this.maxPerTransMoney = maxPerTransMoney;
	}

	public double getMaxPerSglTransMoney() {
		return maxPerSglTransMoney;
	}

	public void setMaxPerSglTransMoney(double maxPerSglTransMoney) {
		this.maxPerSglTransMoney = maxPerSglTransMoney;
	}

	public int getMaxPerTransCount() {
		return maxPerTransCount;
	}

	public void setMaxPerTransCount(int maxPerTransCount) {
		this.maxPerTransCount = maxPerTransCount;
	}

	public String getAdapterClassname() {
		return adapterClassname;
	}

	public void setAdapterClassname(String adapterClassname) {
		this.adapterClassname = adapterClassname;
	}

	public int getValidFlag() {
		return validFlag;
	}

	public void setValidFlag(int validFlag) {
		this.validFlag = validFlag;
	}

	public String getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public int getControl() {
		return control;
	}

	public void setControl(int control) {
		this.control = control;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toString()
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toJSONObject()
	 */
	@Override
	public JSONObject toJSONObject() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#hashCode()
	 */
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
