package shcem.finance.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;

import shcem.base.dao.model.BaseObject;

public class CancelDetail extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	
	//解约申请明细
	private String KeyID;
	private String ApplyID;
	private String DISABLED;
	private String REC_CREATEBY;
	private String REC_CREATETIME;
	private String REC_MODIFYBY;
	private String REC_MODIFYTIME;
	private String PayStatus;
	private String DetailType;
	private String TradeRole;
	private String FirmID;
	private String TraderID;
	private String TraderName;
	private String UserCode;
	private BigDecimal ReceivableAmount;
	private BigDecimal ReceivedAmount;
	private BigDecimal ReceivableFreight;
	private BigDecimal ReceivedFreight;
	private BigDecimal ReceivableTradeFee;
	private BigDecimal ReceivedTradeFee;
	private BigDecimal ReceivableTradeFeeFunds;
	private BigDecimal ReceivedTradeFeeFunds;
	private BigDecimal ReceivableTradeFeeCredit;
	private BigDecimal ReceivedTradeFeeCredit;
	private BigDecimal ReceivableTradeFeeAccountFunds;
	private BigDecimal ReceivedTradeFeeAccountFunds;
	private BigDecimal ReceivableTradeFeeCoupon;
	private BigDecimal ReceivedTradeFeeCoupon;
	private BigDecimal PayAmount;
	private BigDecimal PaidAmount;
	private BigDecimal PayFreight;
	private BigDecimal PaidFreight;
	private BigDecimal PayTradeFee;
	private BigDecimal PaidTradeFee;
	private BigDecimal PayTradeFeeFunds;
	private BigDecimal PaidTradeFeeFunds;
	private BigDecimal PayTradeFeeCredit;
	private BigDecimal PaidTradeFeeCredit;
	private BigDecimal PayTradeFeeAccountFunds;
	private BigDecimal PaidTradeFeeAccountFunds;
	private BigDecimal PayTradeFeeCoupon;
	private BigDecimal PaidTradeFeeCoupon;
	private BigDecimal PayTradeDeposit;
	private BigDecimal PaidTradeDeposit;
	private BigDecimal PayTradeDepositCredit;
	private BigDecimal PaidTradeDepositCredit;
	private BigDecimal PayTradeDepositFunds;
	private BigDecimal PaidTradeDepositFunds;


	private String DeliveryID;
	private int	GoodsType;
	private int	TradeType;


	public int getTradeType() {
		return TradeType;
	}

	public void setTradeType(int tradeType) {
		TradeType = tradeType;
	}

	public int getGoodsType() {
		return GoodsType;
	}

	public void setGoodsType(int goodsType) {
		GoodsType = goodsType;
	}

	public String getDeliveryID() {
		return DeliveryID;
	}

	public void setDeliveryID(String deliveryID) {
		DeliveryID = deliveryID;
	}

	public String getKeyID() {
		return KeyID;
	}

	public void setKeyID(String keyID) {
		KeyID = keyID;
	}

	public String getApplyID() {
		return ApplyID;
	}

	public void setApplyID(String applyID) {
		ApplyID = applyID;
	}

	public String getDISABLED() {
		return DISABLED;
	}

	public void setDISABLED(String dISABLED) {
		DISABLED = dISABLED;
	}

	public String getREC_CREATEBY() {
		return REC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		REC_CREATEBY = rEC_CREATEBY;
	}

	public String getREC_CREATETIME() {
		return REC_CREATETIME;
	}

	public void setREC_CREATETIME(String rEC_CREATETIME) {
		REC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return REC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		REC_MODIFYBY = rEC_MODIFYBY;
	}

	public String getREC_MODIFYTIME() {
		return REC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(String rEC_MODIFYTIME) {
		REC_MODIFYTIME = rEC_MODIFYTIME;
	}

	public String getPayStatus() {
		return PayStatus;
	}

	public void setPayStatus(String payStatus) {
		PayStatus = payStatus;
	}

	public String getDetailType() {
		return DetailType;
	}

	public void setDetailType(String detailType) {
		DetailType = detailType;
	}

	public String getTradeRole() {
		return TradeRole;
	}

	public void setTradeRole(String tradeRole) {
		TradeRole = tradeRole;
	}

	public String getFirmID() {
		return FirmID;
	}

	public void setFirmID(String firmID) {
		FirmID = firmID;
	}

	public String getTraderID() {
		return TraderID;
	}

	public void setTraderID(String traderID) {
		TraderID = traderID;
	}

	public String getTraderName() {
		return TraderName;
	}

	public void setTraderName(String traderName) {
		TraderName = traderName;
	}

	public String getUserCode() {
		return UserCode;
	}

	public void setUserCode(String userCode) {
		UserCode = userCode;
	}

	public BigDecimal getReceivableAmount() {
		return ReceivableAmount;
	}

	public void setReceivableAmount(BigDecimal receivableAmount) {
		ReceivableAmount = receivableAmount;
	}

	public BigDecimal getReceivedAmount() {
		return ReceivedAmount;
	}

	public void setReceivedAmount(BigDecimal receivedAmount) {
		ReceivedAmount = receivedAmount;
	}

	public BigDecimal getReceivableFreight() {
		return ReceivableFreight;
	}

	public void setReceivableFreight(BigDecimal receivableFreight) {
		ReceivableFreight = receivableFreight;
	}

	public BigDecimal getReceivedFreight() {
		return ReceivedFreight;
	}

	public void setReceivedFreight(BigDecimal receivedFreight) {
		ReceivedFreight = receivedFreight;
	}

	public BigDecimal getReceivableTradeFee() {
		return ReceivableTradeFee;
	}

	public void setReceivableTradeFee(BigDecimal receivableTradeFee) {
		ReceivableTradeFee = receivableTradeFee;
	}

	public BigDecimal getReceivedTradeFee() {
		return ReceivedTradeFee;
	}

	public void setReceivedTradeFee(BigDecimal receivedTradeFee) {
		ReceivedTradeFee = receivedTradeFee;
	}

	public BigDecimal getReceivableTradeFeeFunds() {
		return ReceivableTradeFeeFunds;
	}

	public void setReceivableTradeFeeFunds(BigDecimal receivableTradeFeeFunds) {
		ReceivableTradeFeeFunds = receivableTradeFeeFunds;
	}

	public BigDecimal getReceivedTradeFeeFunds() {
		return ReceivedTradeFeeFunds;
	}

	public void setReceivedTradeFeeFunds(BigDecimal receivedTradeFeeFunds) {
		ReceivedTradeFeeFunds = receivedTradeFeeFunds;
	}

	public BigDecimal getReceivableTradeFeeCredit() {
		return ReceivableTradeFeeCredit;
	}

	public void setReceivableTradeFeeCredit(BigDecimal receivableTradeFeeCredit) {
		ReceivableTradeFeeCredit = receivableTradeFeeCredit;
	}

	public BigDecimal getReceivedTradeFeeCredit() {
		return ReceivedTradeFeeCredit;
	}

	public void setReceivedTradeFeeCredit(BigDecimal receivedTradeFeeCredit) {
		ReceivedTradeFeeCredit = receivedTradeFeeCredit;
	}

	public BigDecimal getReceivableTradeFeeAccountFunds() {
		return ReceivableTradeFeeAccountFunds;
	}

	public void setReceivableTradeFeeAccountFunds(BigDecimal receivableTradeFeeAccountFunds) {
		ReceivableTradeFeeAccountFunds = receivableTradeFeeAccountFunds;
	}

	public BigDecimal getReceivedTradeFeeAccountFunds() {
		return ReceivedTradeFeeAccountFunds;
	}

	public void setReceivedTradeFeeAccountFunds(BigDecimal receivedTradeFeeAccountFunds) {
		ReceivedTradeFeeAccountFunds = receivedTradeFeeAccountFunds;
	}

	public BigDecimal getReceivableTradeFeeCoupon() {
		return ReceivableTradeFeeCoupon;
	}

	public void setReceivableTradeFeeCoupon(BigDecimal receivableTradeFeeCoupon) {
		ReceivableTradeFeeCoupon = receivableTradeFeeCoupon;
	}

	public BigDecimal getReceivedTradeFeeCoupon() {
		return ReceivedTradeFeeCoupon;
	}

	public void setReceivedTradeFeeCoupon(BigDecimal receivedTradeFeeCoupon) {
		ReceivedTradeFeeCoupon = receivedTradeFeeCoupon;
	}

	public BigDecimal getPayAmount() {
		return PayAmount;
	}

	public void setPayAmount(BigDecimal payAmount) {
		PayAmount = payAmount;
	}

	public BigDecimal getPaidAmount() {
		return PaidAmount;
	}

	public void setPaidAmount(BigDecimal paidAmount) {
		PaidAmount = paidAmount;
	}

	public BigDecimal getPayFreight() {
		return PayFreight;
	}

	public void setPayFreight(BigDecimal payFreight) {
		PayFreight = payFreight;
	}

	public BigDecimal getPaidFreight() {
		return PaidFreight;
	}

	public void setPaidFreight(BigDecimal paidFreight) {
		PaidFreight = paidFreight;
	}

	public BigDecimal getPayTradeFee() {
		return PayTradeFee;
	}

	public void setPayTradeFee(BigDecimal payTradeFee) {
		PayTradeFee = payTradeFee;
	}

	public BigDecimal getPaidTradeFee() {
		return PaidTradeFee;
	}

	public void setPaidTradeFee(BigDecimal paidTradeFee) {
		PaidTradeFee = paidTradeFee;
	}

	public BigDecimal getPayTradeFeeFunds() {
		return PayTradeFeeFunds;
	}

	public void setPayTradeFeeFunds(BigDecimal payTradeFeeFunds) {
		PayTradeFeeFunds = payTradeFeeFunds;
	}

	public BigDecimal getPaidTradeFeeFunds() {
		return PaidTradeFeeFunds;
	}

	public void setPaidTradeFeeFunds(BigDecimal paidTradeFeeFunds) {
		PaidTradeFeeFunds = paidTradeFeeFunds;
	}

	public BigDecimal getPayTradeFeeCredit() {
		return PayTradeFeeCredit;
	}

	public void setPayTradeFeeCredit(BigDecimal payTradeFeeCredit) {
		PayTradeFeeCredit = payTradeFeeCredit;
	}

	public BigDecimal getPaidTradeFeeCredit() {
		return PaidTradeFeeCredit;
	}

	public void setPaidTradeFeeCredit(BigDecimal paidTradeFeeCredit) {
		PaidTradeFeeCredit = paidTradeFeeCredit;
	}

	public BigDecimal getPayTradeFeeAccountFunds() {
		return PayTradeFeeAccountFunds;
	}

	public void setPayTradeFeeAccountFunds(BigDecimal payTradeFeeAccountFunds) {
		PayTradeFeeAccountFunds = payTradeFeeAccountFunds;
	}

	public BigDecimal getPaidTradeFeeAccountFunds() {
		return PaidTradeFeeAccountFunds;
	}

	public void setPaidTradeFeeAccountFunds(BigDecimal paidTradeFeeAccountFunds) {
		PaidTradeFeeAccountFunds = paidTradeFeeAccountFunds;
	}

	public BigDecimal getPayTradeFeeCoupon() {
		return PayTradeFeeCoupon;
	}

	public void setPayTradeFeeCoupon(BigDecimal payTradeFeeCoupon) {
		PayTradeFeeCoupon = payTradeFeeCoupon;
	}

	public BigDecimal getPaidTradeFeeCoupon() {
		return PaidTradeFeeCoupon;
	}

	public void setPaidTradeFeeCoupon(BigDecimal paidTradeFeeCoupon) {
		PaidTradeFeeCoupon = paidTradeFeeCoupon;
	}

	public BigDecimal getPayTradeDeposit() {
		return PayTradeDeposit;
	}

	public void setPayTradeDeposit(BigDecimal payTradeDeposit) {
		PayTradeDeposit = payTradeDeposit;
	}

	public BigDecimal getPaidTradeDeposit() {
		return PaidTradeDeposit;
	}

	public void setPaidTradeDeposit(BigDecimal paidTradeDeposit) {
		PaidTradeDeposit = paidTradeDeposit;
	}

	public BigDecimal getPayTradeDepositCredit() {
		return PayTradeDepositCredit;
	}

	public void setPayTradeDepositCredit(BigDecimal payTradeDepositCredit) {
		PayTradeDepositCredit = payTradeDepositCredit;
	}

	public BigDecimal getPaidTradeDepositCredit() {
		return PaidTradeDepositCredit;
	}

	public void setPaidTradeDepositCredit(BigDecimal paidTradeDepositCredit) {
		PaidTradeDepositCredit = paidTradeDepositCredit;
	}

	public BigDecimal getPayTradeDepositFunds() {
		return PayTradeDepositFunds;
	}

	public void setPayTradeDepositFunds(BigDecimal payTradeDepositFunds) {
		PayTradeDepositFunds = payTradeDepositFunds;
	}

	public BigDecimal getPaidTradeDepositFunds() {
		return PaidTradeDepositFunds;
	}

	public void setPaidTradeDepositFunds(BigDecimal paidTradeDepositFunds) {
		PaidTradeDepositFunds = paidTradeDepositFunds;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
