/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: TDelivery
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.model;

import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * (TDelivery)
 * 
 * @author wlpod
 * @version 1.0.0 2016-05-12
 */
public class TDelivery extends BaseObject implements java.io.Serializable, Cloneable {

	private static final long serialVersionUID = -7464587171301763763L;

	private String deliveryID;
	private String orderID;
	private Long leadsID;
	private Integer dISABLED;
	private Integer status;
	private String rEC_CREATEBY;
	private Date rEC_CREATETIME;
	private String rEC_MODIFYBY;
	private Date rEC_MODIFYTIME;
	private Integer deliveryQuantity;
	private BigDecimal takenQuantity;
	private BigDecimal money;
	private BigDecimal takenMoney;
	private BigDecimal payedMoney;
	private BigDecimal overloadFee;
	private BigDecimal price;
	private BigDecimal takenSSFee;
	private BigDecimal takenBSFee;
	private BigDecimal takenSSDeposit;
	private BigDecimal takenBSDeposit;
	private BigDecimal sellPenalty;
	private BigDecimal takenSellPenalty;
	private BigDecimal buyPenalty;
	private BigDecimal takenBuyPenalty;
	private BigDecimal sellCreditDeposit;
	private BigDecimal distributionFee;
	private Integer deliveryType;
	private Integer processStatus;
	private Integer violationStatus;

	public String getDeliveryID() {
		return deliveryID;
	}

	public void setDeliveryID(String deliveryID) {
		this.deliveryID = deliveryID;
	}

	public String getOrderID() {
		return orderID;
	}

	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}

	public Long getLeadsID() {
		return leadsID;
	}

	public void setLeadsID(Long leadsID) {
		this.leadsID = leadsID;
	}

	public Integer getdISABLED() {
		return dISABLED;
	}

	public void setdISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getrEC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setrEC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getrEC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setrEC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getrEC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setrEC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getrEC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setrEC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	public Integer getDeliveryQuantity() {
		return deliveryQuantity;
	}

	public void setDeliveryQuantity(Integer deliveryQuantity) {
		this.deliveryQuantity = deliveryQuantity;
	}

	public BigDecimal getTakenQuantity() {
		return takenQuantity;
	}

	public void setTakenQuantity(BigDecimal takenQuantity) {
		this.takenQuantity = takenQuantity;
	}

	public BigDecimal getMoney() {
		return money;
	}

	public void setMoney(BigDecimal money) {
		this.money = money;
	}

	public BigDecimal getTakenMoney() {
		return takenMoney;
	}

	public void setTakenMoney(BigDecimal takenMoney) {
		this.takenMoney = takenMoney;
	}

	public BigDecimal getPayedMoney() {
		return payedMoney;
	}

	public void setPayedMoney(BigDecimal payedMoney) {
		this.payedMoney = payedMoney;
	}

	public BigDecimal getOverloadFee() {
		return overloadFee;
	}

	public void setOverloadFee(BigDecimal overloadFee) {
		this.overloadFee = overloadFee;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public BigDecimal getTakenSSFee() {
		return takenSSFee;
	}

	public void setTakenSSFee(BigDecimal takenSSFee) {
		this.takenSSFee = takenSSFee;
	}

	public BigDecimal getTakenBSFee() {
		return takenBSFee;
	}

	public void setTakenBSFee(BigDecimal takenBSFee) {
		this.takenBSFee = takenBSFee;
	}

	public BigDecimal getTakenSSDeposit() {
		return takenSSDeposit;
	}

	public void setTakenSSDeposit(BigDecimal takenSSDeposit) {
		this.takenSSDeposit = takenSSDeposit;
	}

	public BigDecimal getTakenBSDeposit() {
		return takenBSDeposit;
	}

	public void setTakenBSDeposit(BigDecimal takenBSDeposit) {
		this.takenBSDeposit = takenBSDeposit;
	}

	public BigDecimal getSellPenalty() {
		return sellPenalty;
	}

	public void setSellPenalty(BigDecimal sellPenalty) {
		this.sellPenalty = sellPenalty;
	}

	public BigDecimal getTakenSellPenalty() {
		return takenSellPenalty;
	}

	public void setTakenSellPenalty(BigDecimal takenSellPenalty) {
		this.takenSellPenalty = takenSellPenalty;
	}

	public BigDecimal getBuyPenalty() {
		return buyPenalty;
	}

	public void setBuyPenalty(BigDecimal buyPenalty) {
		this.buyPenalty = buyPenalty;
	}

	public BigDecimal getTakenBuyPenalty() {
		return takenBuyPenalty;
	}

	public void setTakenBuyPenalty(BigDecimal takenBuyPenalty) {
		this.takenBuyPenalty = takenBuyPenalty;
	}

	public BigDecimal getSellCreditDeposit() {
		return sellCreditDeposit;
	}

	public void setSellCreditDeposit(BigDecimal sellCreditDeposit) {
		this.sellCreditDeposit = sellCreditDeposit;
	}

	public BigDecimal getDistributionFee() {
		return distributionFee;
	}

	public void setDistributionFee(BigDecimal distributionFee) {
		this.distributionFee = distributionFee;
	}

	public Integer getDeliveryType() {
		return deliveryType;
	}

	public void setDeliveryType(Integer deliveryType) {
		this.deliveryType = deliveryType;
	}

	public Integer getProcessStatus() {
		return processStatus;
	}

	public void setProcessStatus(Integer processStatus) {
		this.processStatus = processStatus;
	}

	public Integer getViolationStatus() {
		return violationStatus;
	}

	public void setViolationStatus(Integer violationStatus) {
		this.violationStatus = violationStatus;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}