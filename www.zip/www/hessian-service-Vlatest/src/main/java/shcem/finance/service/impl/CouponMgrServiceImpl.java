package shcem.finance.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.finance.component.ICouponComponnetManager;
import shcem.finance.dao.model.Coupon;
import shcem.finance.dao.model.CouponApply;
import shcem.finance.dao.model.CouponFlow;
import shcem.finance.dao.model.CouponFlowFront;
import shcem.finance.dao.model.FundflowServiceModel;
import shcem.finance.service.ICouponMgrService;
import shcem.finance.util.FinanceSysData;
import shcem.trade.dao.model.Order;
import shcem.util.JsonUtil;

public class CouponMgrServiceImpl  extends BaseServiceImpl implements ICouponMgrService {

	private ICouponComponnetManager couponComponnetManager = (ICouponComponnetManager) FinanceSysData.getBean(Constants.BEAN_COUPON_MGR);
	
	@Override
	public String addCouponApply(String params) {
		this.log.info(this.getClass().getName() + " addCouponApply() Start");
		JSONObject JOParams = new JSONObject(params);
		CouponApply couponApply = (CouponApply) JsonUtil.jsonToBean(JOParams, CouponApply.class);

		String userName = this.getUserName() == null ? "system" : (this.getUserName() == "") ? "system" : this.getUserName();
		try {
			couponApply.setApplyer(userName);
			couponComponnetManager.insertCouponApply(couponApply);
			setResultData("00000", null);
		} catch (Exception err) {
			this.log.error("添加申请优惠券失败：" + err.getMessage());
			setResultData("10106", null, err.getMessage());
		}
		this.log.info(this.getClass().getName() + " addCouponApply() End");
		return rtnData.toString();
	}

	@Override
	public String queryCouponApplyList(String params) {
		this.log.info(this.getClass().getName() + " queryCouponApplyList() Start");
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");

		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("ca.FirmID", "like", "", "String", "firmID"));
		conditionList.add(new Condition("firm.FirmName", "like", "", "String", "firmName"));
		conditionList.add(new Condition("ca.Status", "=", "", "Integer", "status"));
		conditionList.add(new Condition("convert(char(10),ca.ApplyTime,120)", ">=", "", "Date", "startDate"));
		conditionList.add(new Condition("convert(char(10),ca.ApplyTime,120)", "<=", "", "Date", "endDate"));
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<CouponApply> list = null;
		boolean bolRst = false;
		try {
			list = couponComponnetManager.queryCouponApplyList(qc, pageInfo);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("取得优惠券申请列表失败：" + err.getMessage());
			setResultData("10105", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);

				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " queryCouponApplyList() End");
		return rtnData.toString();
	}

	@Override
	public String passCouponApply(String params) {
		this.log.info(this.getClass().getName() + " passCouponApply() Start");
		this.log.debug(params);
		JSONObject JOParams = new JSONObject(params);
		CouponApply couponApply = (CouponApply) JsonUtil.jsonToBean(JOParams, CouponApply.class);

		String userName = this.getUserName() == null ? "system" : (this.getUserName() == "") ? "system" : this.getUserName();
		try {
			// 点击【审核通过】按钮时
			if (couponApply.getStatus() == 1){
				int resultCode = couponComponnetManager.passCouponApply(couponApply.getId(),userName,couponApply.getRefuseReason());
				if (resultCode < 0){
					setResultData(""+-resultCode, null);
				}else{
					setResultData("00000", null);
				}
			}else{// 点击【审核拒绝】按钮时
				CouponApply couponApplyInfo = couponComponnetManager.selectCouponApplyById(couponApply.getId());
				
				if (couponApplyInfo.getStatus() != 0){
					setResultData("90015", null);
				}else{
					couponApply.setApprover(userName);
					couponComponnetManager.updateCouponApplyOfStatusById(couponApply);
					this.log.debug("审核拒绝成功！");
					setResultData("00000", null);
				}
			}
		} catch (Exception err) {
			this.log.error("更新申请优惠券的审核状态失败：" + err.getMessage());
			setResultData("10106", null, err.getMessage());
		}
		this.log.info(this.getClass().getName() + " passCouponApply() End");
		return rtnData.toString();
	}

	@Override
	public String queryCouponList(String params) {
		this.log.info(this.getClass().getName() + " quertCouponList() Start");
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");

		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("ca.FirmID", "like", "", "String", "firmID"));
		conditionList.add(new Condition("firm.FirmName", "like", "", "String", "firmName"));
		conditionList.add(new Condition("convert(char(10),ca.CreditDate,120)", ">=", "", "Date", "startDate"));
		conditionList.add(new Condition("convert(char(10),ca.CreditDate,120)", "<=", "", "Date", "endDate"));
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<Coupon> list = null;
		boolean bolRst = false;
		try {
			list = couponComponnetManager.queryCouponList(qc, pageInfo);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("取得优惠券列表失败：" + err.getMessage());
			setResultData("10105", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);

				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " quertCouponList() End");
		return rtnData.toString();
	}

	@Override
	public String queryCouponFlowList(String params) {
		this.log.info(this.getClass().getName() + " quertCouponFlowList() Start");
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");

		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("ca.FirmID", "like", "", "String", "firmID"));
		conditionList.add(new Condition("firm.FirmName", "like", "", "String", "firmName"));
		conditionList.add(new Condition("convert(char(10),ca.Createtime,120)", ">=", "", "Date", "startDate"));
		conditionList.add(new Condition("convert(char(10),ca.Createtime,120)", "<=", "", "Date", "endDate"));
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<CouponFlow> list = null;
		boolean bolRst = false;
		try {
			list = couponComponnetManager.queryCouponFlowList(qc, pageInfo);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("取得优惠券流水列表失败：" + err.getMessage());
			setResultData("10105", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);

				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " quertCouponFlowList() End");
		return rtnData.toString();
	}

	@Override
	public String queryCouponFlowListForFront(String params) {

		this.log.info(this.getClass().getName() + " queryCouponFlowListForFront() Start");
		JSONObject JOParams = new JSONObject(params);

		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("ca.FirmID", "=", "", "String", "firmID"));
		conditionList.add(new Condition("firm.FirmName", "like", "", "String", "firmName"));
		if (!JOParams.isNull("flowType") && JOParams.getInt("flowType") != -1){
			conditionList.add(new Condition("ca.FlowType", "=", "", "int", "flowType"));//  流水类型：0充值 1扣除 2抵用
		}
		conditionList.add(new Condition("convert(char(10),ca.Createtime,120)", ">=", "", "Date", "startDate"));
		conditionList.add(new Condition("convert(char(10),ca.Createtime,120)", "<=", "", "Date", "endDate"));
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(JOParams, conditionList, "");
		
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		if (JOParams.isNull("firmID") || "".equals(JOParams.getString("firmID"))){
			setResultData("10103", null, "交易商ID不能为空！");
			return rtnData.toString();
		}
		// 交易商ID
		String firmID = JOParams.getString("firmID");
		List<CouponFlow> list = null;
		List<CouponFlowFront> couponFlowFrontList = new ArrayList<CouponFlowFront>();
		boolean bolRst = false;
		Coupon  coupon  = null;
		try {
			list = couponComponnetManager.queryCouponFlowList(qc, pageInfo);
			coupon = couponComponnetManager.selectCouponByFirmID(firmID);
			if (coupon == null){
				coupon = new Coupon();
				coupon.setBalance(new BigDecimal(0));
			}
			if (list != null){
				for (CouponFlow tempCouponFlow : list){
					CouponFlowFront couponFlowFront = new CouponFlowFront();
					couponFlowFront.setFundFlowID(tempCouponFlow.getFundFlowID());
					couponFlowFront.setFirmID(tempCouponFlow.getFirmID());
					couponFlowFront.setFirmName(tempCouponFlow.getFirmName());
					couponFlowFront.setOrderCode(tempCouponFlow.getObjectID());
					couponFlowFront.setMoney(tempCouponFlow.getAmount());
					couponFlowFront.setCreatetime(tempCouponFlow.getCreatetime());
					couponFlowFront.setCreateby(tempCouponFlow.getOperator());
					couponFlowFront.setStatus(tempCouponFlow.getFlowType());// 0充值 1扣除 2抵用
					couponFlowFrontList.add(couponFlowFront);
				}
			}
			bolRst = true;
		} catch (Exception err) {
			this.log.error("取得优惠券流水列表失败：" + err.getMessage());
			setResultData("10105", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(couponFlowFrontList);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("totalMoney", coupon.getBalance());// 交易商当前优惠券余额
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " queryCouponFlowListForFront() End");
		return rtnData.toString();
	}

}
