/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: BalanceModel
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.service.model;

import java.io.Serializable;
import java.math.BigDecimal;

import org.json.JSONObject;

import shcem.base.service.model.BaseServiceObject;

/**
 * @author wlpod
 *
 */
public class BalanceModel extends BaseServiceObject implements Serializable {

	private static final long serialVersionUID = -7464587171301763763L;

	// F_FirmFunds交易商资金表
	/** 交易商ID */
	private String FIRMID;

	/** 交易商名 */
	private String FIRMNAME;

	// S_FirmFunds交易商授信资金表（现货）
	/** 期初额（初期设置额度） */
	private BigDecimal LASTBALANCEFromS;
	
	/** 当前余额（现货） */
	private BigDecimal BALANCEFromS;
	
	// S_PreSale_FirmFunds交易商授信资金表（预售）
	/** 期初额（初期设置额度） */
	private BigDecimal preSaleLASTBALANCEFromS;
	
	/** 当前余额（预售） */
	private BigDecimal preSaleBALANCEFromS;

	// 老专场资金
	/** 可提资金 */
	private BigDecimal USERBALANCEFromOra;
	/** 交易系统当前余额 */
	private BigDecimal FBALANCEFromOra;
	
	public BigDecimal getFBALANCEFromOra() {
		return FBALANCEFromOra;
	}

	public void setFBALANCEFromOra(BigDecimal fBALANCEFromOra) {
		FBALANCEFromOra = fBALANCEFromOra;
	}

	public String getFIRMID() {
		return FIRMID;
	}

	public void setFIRMID(String fIRMID) {
		FIRMID = fIRMID;
	}

	public String getFIRMNAME() {
		return FIRMNAME;
	}

	public void setFIRMNAME(String fIRMNAME) {
		FIRMNAME = fIRMNAME;
	}

	public BigDecimal getBALANCEFromS() {
		return BALANCEFromS;
	}

	public void setBALANCEFromS(BigDecimal bALANCEFromS) {
		BALANCEFromS = bALANCEFromS;
	}

	public BigDecimal getUSERBALANCEFromOra() {
		return USERBALANCEFromOra;
	}

	public void setUSERBALANCEFromOra(BigDecimal uSERBALANCEFromOra) {
		USERBALANCEFromOra = uSERBALANCEFromOra;
	}

	public BigDecimal getLASTBALANCEFromS() {
		return LASTBALANCEFromS;
	}

	public void setLASTBALANCEFromS(BigDecimal lASTBALANCEFromS) {
		LASTBALANCEFromS = lASTBALANCEFromS;
	}
	
	public BigDecimal getPreSaleLASTBALANCEFromS() {
		return preSaleLASTBALANCEFromS;
	}

	public void setPreSaleLASTBALANCEFromS(BigDecimal preSaleLASTBALANCEFromS) {
		this.preSaleLASTBALANCEFromS = preSaleLASTBALANCEFromS;
	}

	public BigDecimal getPreSaleBALANCEFromS() {
		return preSaleBALANCEFromS;
	}

	public void setPreSaleBALANCEFromS(BigDecimal preSaleBALANCEFromS) {
		this.preSaleBALANCEFromS = preSaleBALANCEFromS;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toString()
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toJSONObject()
	 */
	@Override
	public JSONObject toJSONObject() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#hashCode()
	 */
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
