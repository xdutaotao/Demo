package shcem.finance.dao.model;

import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**资金流水详细表 
 * @author zhangnan
 *
 */
public class FundflowServiceModel extends BaseObject implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	/**
	 * 流水号
	 */
	private int fUNDFLOWID;
	/**
	 * 交易商ID
	 */
	private String fIRMID;
	/**
	 *业务代码
	 */
	private String oPRCODE;
	/**
	 * 合同号
	 */
	private String cONTRACTNO;
	/**
	 * 商品代码
	 */
	private String cOMMODITYID;
	/**
	 * 发生额
	 */
	private BigDecimal aMOUNT;
	/**
	 * 余额
	 */
	private BigDecimal bALANCE;
	/**
	 * 中远期(增值税,担保金)
	 */
	private BigDecimal aPPENDAMOUNT;
	/**
	 * 记录号（凭证代码）
	 */
	private int  vOUCHERNO;
	/**
	 * 创建日期
	 */
	private Date cREATETIME;
	/**
	 * 凭证创建日期
	 */
	private Date bDATE;
	/**
	 * 交易商名称
	 */
	private String firmName;
	
	/**
	 * 业务类型（如出金、入金）
	 */
	private String summary;
	
	
	public int getFUNDFLOWID() {
		return fUNDFLOWID;
	}

	public void setFUNDFLOWID(int fUNDFLOWID) {
		this.fUNDFLOWID = fUNDFLOWID;
	}

	public String getFIRMID() {
		return fIRMID;
	}

	public void setFIRMID(String fIRMID) {
		this.fIRMID = fIRMID;
	}

	public String getOPRCODE() {
		return oPRCODE;
	}

	public void setOPRCODE(String oPRCODE) {
		this.oPRCODE = oPRCODE;
	}

	public String getCONTRACTNO() {
		return cONTRACTNO;
	}

	public void setCONTRACTNO(String cONTRACTNO) {
		this.cONTRACTNO = cONTRACTNO;
	}

	public String getCOMMODITYID() {
		return cOMMODITYID;
	}

	public void setCOMMODITYID(String cOMMODITYID) {
		this.cOMMODITYID = cOMMODITYID;
	}

	public BigDecimal getAMOUNT() {
		return aMOUNT;
	}

	public void setAMOUNT(BigDecimal aMOUNT) {
		this.aMOUNT = aMOUNT;
	}

	public BigDecimal getBALANCE() {
		return bALANCE;
	}

	public void setBALANCE(BigDecimal bALANCE) {
		this.bALANCE = bALANCE;
	}

	public BigDecimal getAPPENDAMOUNT() {
		return aPPENDAMOUNT;
	}

	public void setAPPENDAMOUNT(BigDecimal aPPENDAMOUNT) {
		this.aPPENDAMOUNT = aPPENDAMOUNT;
	}

	public int getVOUCHERNO() {
		return vOUCHERNO;
	}

	public void setVOUCHERNO(int vOUCHERNO) {
		this.vOUCHERNO = vOUCHERNO;
	}

	public Date getCREATETIME() {
		return cREATETIME;
	}

	public void setCREATETIME(Date cREATETIME) {
		this.cREATETIME = cREATETIME;
	}

	public Date getBDATE() {
		return bDATE;
	}

	public void setBDATE(Date bDATE) {
		this.bDATE = bDATE;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

}

