package shcem.finance.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.finance.component.IFundFlowManager;
import shcem.finance.dao.model.FinancialBills;
import shcem.finance.dao.model.FundflowServiceModel;
import shcem.finance.service.IFundFlowService;
import shcem.finance.util.FinanceSysData;
import shcem.util.JsonUtil;

public class FundFlowMgrService extends BaseServiceImpl implements IFundFlowService {
	private IFundFlowManager mgr = (IFundFlowManager) FinanceSysData.getBean(Constants.BEAN_FUNDFLOW_MGR);
	
	@Override
	public String getFundFlowList(String params) {
		this.log.info(this.getClass().getName() + " getFundFlowList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<FundflowServiceModel> list = null;
		boolean bolRst = false;//
		List<Condition> conditionList = new ArrayList<Condition>(); //允许的查询参数列表，定义字段，操作符及类型,查询json固定模型queryModel
		conditionList.add(new Condition("fff.FUNDFLOWID","like","","String","fUNDFLOWID")); 
		conditionList.add(new Condition("fff.FIRMID","like","","String","fIRMID")); 
		conditionList.add(new Condition("fff.OPRCODE","=","","String","code")); 
		conditionList.add(new Condition("cf.FirmName","like","","String","firmName")); 
		conditionList.add(new Condition("convert(char(10),fff.CREATETIME,120)", " >= ", "", "String", "startDate"));
		conditionList.add(new Condition("convert(char(10),fff.CREATETIME,120)", " <= ", "", "String", "endDate"));
		
		
		JSONObject queryModel =JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			list = this.mgr.getFundFlowList(qc,pageInfo);
			bolRst = true;
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error("资金流水列表查询失败"+e.getMessage());
			setResultData("10105", null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("资金流水列表数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getFundFlowList() End");
		return rtnData.toString();
	}
	
	@Override
	public String getFinancialBillsList(String params) {
		this.log.info(this.getClass().getName() + " getFinancialBillsList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<FinancialBills> list = new ArrayList<FinancialBills>();
		boolean bolRst = false;//
		int financialBillsType = JOParams.optInt("financialBillsType");
		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("temp.DeliveryID","like","","String","deliveryID")); 
		conditionList.add(new Condition("temp.OrderId","like","","String","orderId")); 
		conditionList.add(new Condition("temp.firmName","like","","String","firmName")); 
		
		
		
		JSONObject queryModel =JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			list = this.mgr.getFinancialBillsList(qc,pageInfo,financialBillsType);
			bolRst = true;
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error("开票管理列表数据查询失败"+e.getMessage());
			setResultData("10105", null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);	
			} catch (Exception e) {
				this.log.error("开票管理列表数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getFinancialBillsList() End");
		return rtnData.toString();
	}
	@Override
	public String addInvoiceApply(String params) {
		// TODO Auto-generated method stub
		return null;
	}
}
