/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: SApplyManagerImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.component.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.constant.Constants;
import shcem.finance.component.ISApplayManager;
import shcem.finance.dao.SApplyDAO;
import shcem.finance.dao.model.*;
import shcem.trade.component.IOrderManager;
import shcem.trade.util.TradeSysData;
import shcem.util.Common;

public class SApplyManagerImpl extends BaseManager implements ISApplayManager {
	private SApplyDAO dao;
	
	private SApplyDAO sApplyDAO_read;
	

	public void setsApplyDAO_read(SApplyDAO sApplyDAO_read) {
		this.sApplyDAO_read = sApplyDAO_read;
	}

	public void setSApplyDAO(SApplyDAO dao) {
		this.dao = dao;
	}

	/**
	 * 授信申请记录查询
	 */
	@Override
	public List<SApply> getSApplyList(QueryConditions qc, PageInfo pageInfo) {
		return this.sApplyDAO_read.getSApplyList(qc, pageInfo);
	}

	/**
	 * 授信申请追加
	 */
	@Override
	public int addApply(SApply sapply) {
		return this.dao.addApply(sapply);
	}

	/**
	 * 当前授信资金查询
	 */
	@Override
	public List<SFirmFunds> getFirmFundsList(QueryConditions qc, PageInfo pageInfo) {
		return this.sApplyDAO_read.getFirmFundsList(qc, pageInfo);
	}

	/**
	 * 审核不通过
	 */
	@Override
	public int approveNot(Integer id, String refuseReason) {
		int result = this.dao.updateStatus(id, 2);
		if(refuseReason != null && result == 1){
			result = this.dao.updateRefuseReason(id, refuseReason);	
		}		
		return result;
	}

	/**
	 * 审核通过
	 */
	@Override
	public int approveYes(Integer id, String approver, String refuseReason) {
		int result = -1;
		SApply tempBean = this.dao.getApply(id);
		
		SFirmFunds sFirmFunds = new SFirmFunds();
		SPreSaleFirmFunds sPreSaleFirmFunds = new SPreSaleFirmFunds();
		// 申请类型（0：现货授信，1：预售授信）
		if (0 == tempBean.getDiffType()){
			sFirmFunds = this.dao.getFirmFunds(tempBean.getFirmID());
		}else{
			sPreSaleFirmFunds = dao.getPreSaleFirmFundsFirmFunds(tempBean.getFirmID());
		}
		
		if (tempBean.getApplyType() == 1) {
			if (0 == tempBean.getDiffType()){
				// 减授信额的时候，check余额不能小于减少额
				if (sFirmFunds.getBalance().compareTo(tempBean.getAmount()) == -1) {
					this.log.debug("授信额度不足以减少");
					return -2;
				}
			}else{
				// 减授信额的时候，check余额不能小于减少额
				if (sPreSaleFirmFunds.getBalance().compareTo(tempBean.getAmount()) == -1) {
					this.log.debug("授信额度不足以减少");
					return -2;
				}
			}
			
		}

		// S_APPLY授信申请表Status更新
		result = this.dao.updateStatus(tempBean.getID(), 1);
		if (result != 1) {
			this.log.debug("更新S_APPLY失败");
			return -3;
		}
		if(refuseReason != null){
			result = this.dao.updateRefuseReason(tempBean.getID(), refuseReason);
			if (result != 1) {
				this.log.debug("更新S_APPLY失败");
				return -3;
			}
		}
		result = this.dao.updateApprover(tempBean.getID(), approver, Common.getDate());
		if (result != 1) {
			this.log.debug("更新S_APPLY失败");
			return -3;
		}

		if(tempBean.getDiffType()==0){
			// 授信流水表追加
			SFundFlow sFundFlow = new SFundFlow();
			sFundFlow.setFirmID(tempBean.getFirmID());
			if (tempBean.getApplyType() == 1) {
				sFundFlow.setOperCode("102");
				sFundFlow.setBalance(sFirmFunds.getBalance().subtract(tempBean.getAmount()));
			} else {
				sFundFlow.setOperCode("101");
				sFundFlow.setBalance(sFirmFunds.getBalance().add(tempBean.getAmount()));
			}
			sFundFlow.setAmount(tempBean.getAmount());
			sFundFlow.setCreatetime(Common.getDate());
			sFundFlow.setObjectID(tempBean.getID().toString());
			sFundFlow.setFlowType(3);
			result = this.dao.addSFundFlow(sFundFlow);
			if (result != 1) {
				this.log.debug("授信流水表追加失败");
				return -4;
			}

			// 授信资金表更新
			if (tempBean.getApplyType() == 1) {
				result = this.dao.updateSfirmFunds(tempBean.getFirmID(), tempBean.getAmount().multiply(new BigDecimal(-1)),
						Common.getDate());
			} else {
				result = this.dao.updateSfirmFunds(tempBean.getFirmID(), tempBean.getAmount(), Common.getDate());
			}
			if (result != 1) {
				this.log.debug("授信资金表更新失败");
				return -5;
			}
		}else{
			// 预售授信流水表追加
			SPreSaleFundFlow sPreSaleFundFlow = new SPreSaleFundFlow();
			sPreSaleFundFlow.setFirmID(tempBean.getFirmID());
			if (tempBean.getApplyType() == 1) {
				sPreSaleFundFlow.setOperCode("102");
				sPreSaleFundFlow.setBalance(sPreSaleFirmFunds.getBalance().subtract(tempBean.getAmount()));
			} else {
				sPreSaleFundFlow.setOperCode("101");
				sPreSaleFundFlow.setBalance(sPreSaleFirmFunds.getBalance().add(tempBean.getAmount()));
			}
			sPreSaleFundFlow.setAmount(tempBean.getAmount());
			sPreSaleFundFlow.setObjectID(tempBean.getID().toString());
			sPreSaleFundFlow.setFlowType(3);
			result = this.dao.addPreSaleFundFlow(sPreSaleFundFlow);
			if (result != 1) {
				this.log.debug("预售授信流水表追加失败");
				return -4;
			}
			//预售授信资金表更新
			if (tempBean.getApplyType() == 1) {
				result = this.dao.updatePreSaleFirmFound(tempBean.getFirmID(), tempBean.getAmount().multiply(new BigDecimal(-1)),
						Common.getDate());
			} else {
				result = this.dao.updatePreSaleFirmFound(tempBean.getFirmID(), tempBean.getAmount(), Common.getDate());
			}
			if (result != 1) {
				this.log.debug("预售授信资金表更新失败");
				return -5;
			}
		}
		return result;
	}

	/**
	 * 收取授信交易手续费
	 * 
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public int getFee(String firmID, BigDecimal money, String ObjectID, int flowType) {
		return this.createSFirmFundFlow(firmID, "201", 0, money, ObjectID, flowType);
	}

	/**
	 * 退还授信交易手续费
	 * 
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public int backFee(String firmID, BigDecimal money, String ObjectID, int flowType) {
		return this.createSFirmFundFlow(firmID, "223", 1, money, ObjectID, flowType);
	}

	/**
	 * 收取授信交收手续费
	 * 
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public int getSettleFee(String firmID, BigDecimal money, String ObjectID, int flowType) {
		return this.createSFirmFundFlow(firmID, "210", 0, money, ObjectID, flowType);
	}

	/**
	 * 退还授信交收手续费
	 * 
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public int backSettleFee(String firmID, BigDecimal money, String ObjectID, int flowType) {
		return this.createSFirmFundFlow(firmID, "224", 1, money, ObjectID, flowType);
	}

	/**
	 * 收取授信交易保证金
	 * 
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public int getMargin(String firmID, BigDecimal money, String ObjectID, int flowType) {
		return this.createSFirmFundFlow(firmID, "202", 0, money, ObjectID, flowType);
	}

	/**
	 * 退还授信交易保证金
	 * 
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public int backMargin(String firmID, BigDecimal money, String ObjectID, int flowType) {
		return this.createSFirmFundFlow(firmID, "203", 1, money, ObjectID, flowType);
	}

	/**
	 * 收取授信交收保证金
	 * 
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public int getSettleMargin(String firmID, BigDecimal money, String ObjectID, int flowType) {
		return this.createSFirmFundFlow(firmID, "213", 0, money, ObjectID, flowType);
	}

	/**
	 * 退还授信交收保证金
	 * 
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public int backSettleMargin(String firmID, BigDecimal money, String ObjectID, int flowType) {
		return this.createSFirmFundFlow(firmID, "214", 1, money, ObjectID, flowType);
	}

	/**
	 * 
	 * @param oprCode
	 *            操作代码 101 入金，102 出金
	 * @param flag
	 *            使用 0：退还：1
	 * @param money
	 *            使用的资金
	 * @return
	 */
	private int createSFirmFundFlow(String firmID, String oprCode, int flag, BigDecimal money, String ObjectID,
			int flowType) {
		int result = -1;
		BigDecimal sBalance = new BigDecimal(0);
		SFirmFunds sFirmFunds = this.dao.getFirmFunds(firmID);
		if (sFirmFunds != null) {
			sBalance = sFirmFunds.getBalance();
		} else {
			return -2; // firm not exist
		}
		if (flag == 0) {
			// 减授信额的时候，check余额不能小于money
			if (sBalance.compareTo(money) == -1) {
				return -2;
			}
			money = money.multiply(new BigDecimal(-1));
		}
		
		// 授信流水表追加
		SFundFlow sFundFlow = new SFundFlow();

		sFundFlow.setFirmID(firmID);
		sFundFlow.setOperCode(oprCode);
		sFundFlow.setBalance(sFirmFunds.getBalance().add(money));
		sFundFlow.setAmount(money.abs());
		sFundFlow.setCreatetime(Common.getDate());
		sFundFlow.setObjectID(ObjectID);
		sFundFlow.setFlowType(flowType);
		result = this.dao.addSFundFlow(sFundFlow);
		if (result != 1) {
			return -4;
		}
		result = this.dao.updateSfirmFundsByUse(firmID, money);
		if (result != 1) {
			return -5;
		}
		result = 1;
		return result;
	}
	
	/**
	 * 创建预售流水
	 * @param oprCode
	 *            操作代码 101 入金，102 出金
	 * @param flag
	 *            使用 0：退还：1
	 * @param money
	 *            使用的资金
	 * @return
	 */
	private int createPreSaleFirmFundFlow(String firmID, String oprCode, int flag, BigDecimal money, String ObjectID,
			int flowType) {
		int result = -1;
		BigDecimal sBalance = new BigDecimal(0);
		SPreSaleFirmFunds preSaleFirmFunds = this.dao.getPreSaleFirmFundsFirmFunds(firmID);
		if (preSaleFirmFunds != null) {
			sBalance = preSaleFirmFunds.getBalance();
		} else {
			return -2; // firm not exist
		}
		if (flag == 0) {
			// 减授信额的时候，check余额不能小于money
			if (sBalance.compareTo(money) == -1) {
				return -2;
			}
			money = money.multiply(new BigDecimal(-1));
		}
		// 预售授信流水表追加
		SPreSaleFundFlow preSaleFundFlow = new SPreSaleFundFlow();

		preSaleFundFlow.setFirmID(firmID);
		preSaleFundFlow.setOperCode(oprCode);
		preSaleFundFlow.setBalance(preSaleFirmFunds.getBalance().add(money));
		preSaleFundFlow.setAmount(money.abs());
		preSaleFundFlow.setCreatetime(Common.getDate());
		preSaleFundFlow.setObjectID(ObjectID);
		preSaleFundFlow.setFlowType(flowType);
		result = this.dao.addPreSaleFundFlow(preSaleFundFlow);
		if (result != 1) {
			return -4;
		}
		result = this.dao.updatePreSaleFirmFound(firmID, money, new Date());
		if (result != 1) {
			return -5;
		}
		result = 1;
		return result;
	}
	
	@Override
	public void rollback() {
		this.dao.rollBack();
	}

	/**
	 * 授信资金流水list取得
	 */
	@Override
	public List<SFundFlow> getSFundFlowList(QueryConditions qc, PageInfo pageInfo) {
		return this.sApplyDAO_read.getSFundFlowList(qc, pageInfo);
	}
	
	/**
	 * 授信资金和市场资金流水list取得
	 */
	@Override
	public List<AllFundFlow> getAllFundFlowList(QueryConditions qc, PageInfo pageInfo) {
		return this.sApplyDAO_read.getAllFundFlowList(qc, pageInfo);
	}
	@Override
	public List<SPreSaleFundFlow> getPreSaleFundFlowList(QueryConditions qc,
			PageInfo pageInfo) {
		return sApplyDAO_read.getPreSaleFundFlowList(qc, pageInfo);
	}


	/**
	 * 收取授信交易手续费
	 * 
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public int getFeeForPreSale(String firmID, BigDecimal money, String ObjectID, int flowType) {
		return this.createPreSaleFirmFundFlow(firmID, "201", 0, money, ObjectID, flowType);
	}

	/**
	 * 退还授信交易手续费
	 * 
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public int backFeeForPreSale(String firmID, BigDecimal money, String ObjectID, int flowType) {
		return this.createPreSaleFirmFundFlow(firmID, "223", 1, money, ObjectID, flowType);
	}

	/**
	 * 收取授信交收手续费
	 * 
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public int getSettleFeeForPreSale(String firmID, BigDecimal money, String ObjectID, int flowType) {
		return this.createPreSaleFirmFundFlow(firmID, "210", 0, money, ObjectID, flowType);
	}

	/**
	 * 退还授信交收手续费
	 * 
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public int backSettleFeeForPreSale(String firmID, BigDecimal money, String ObjectID, int flowType) {
		return this.createPreSaleFirmFundFlow(firmID, "224", 1, money, ObjectID, flowType);
	}

	/**
	 * 收取授信交易保证金
	 * 
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public int getMarginForPreSale(String firmID, BigDecimal money, String ObjectID, int flowType) {
		return this.createPreSaleFirmFundFlow(firmID, "202", 0, money, ObjectID, flowType);
	}

	/**
	 * 退还授信交易保证金
	 * 
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public int backMarginForPreSale(String firmID, BigDecimal money, String ObjectID, int flowType) {
		return this.createPreSaleFirmFundFlow(firmID, "203", 1, money, ObjectID, flowType);
	}

	/**
	 * 收取授信交收保证金
	 * 
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public int getSettleMarginForPreSale(String firmID, BigDecimal money, String ObjectID, int flowType) {
		return this.createPreSaleFirmFundFlow(firmID, "213", 0, money, ObjectID, flowType);
	}

	/**
	 * 退还授信交收保证金
	 * 
	 * @param firmID
	 * @param money
	 * @param ObjectID
	 * @param flowType
	 * @return
	 */
	public int backSettleMarginForPreSale(String firmID, BigDecimal money, String ObjectID, int flowType) {
		return this.createPreSaleFirmFundFlow(firmID, "214", 1, money, ObjectID, flowType);
	}

	@Override
	public List<SPreSaleFirmFunds> getPreSaleFirmFundsList(QueryConditions qc,
			PageInfo pageInfo) {
		return sApplyDAO_read.getPreSaleFirmFundsList(qc, pageInfo);
	}

}
