package shcem.finance.component.impl;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.constant.Constants;
import shcem.finance.ExportModel.InvoiceApply4Export;
import shcem.finance.ExportModel.InvoiceCollect4Export;
import shcem.finance.component.IInvoiceComponentManager;
import shcem.finance.dao.IInvoiceDao;
import shcem.finance.dao.model.ExportInvoiceCollectDetail;
import shcem.finance.dao.model.FinancialBills;
import shcem.finance.dao.model.InvoiceApply;
import shcem.finance.dao.model.InvoiceApply4Check;
import shcem.finance.dao.model.InvoiceApplyRel;
import shcem.finance.dao.model.InvoiceCollectDetail;
import shcem.finance.dao.model.InvoiceCollectDetailRel;
import shcem.finance.dao.model.InvoiceDetail;
import shcem.finance.dao.model.InvoiceDetailRel;
import shcem.finance.service.model.ImportInvoiceDetail;
import shcem.finance.util.InvoiceApply4CheckUtil;
import shcem.finance.util.OrderTradeStatusUtil;
import shcem.market.dao.IInsurancePolicyDao;
import shcem.market.dao.model.InsuranceBack;
import shcem.market.dao.model.InsurancePolicy;
import shcem.member.dao.model.Firminvoice;
import shcem.trade.component.IOrderManager;
import shcem.trade.dao.IDeliveryDAO;
import shcem.trade.dao.model.DelDistributionDetail;
import shcem.trade.dao.model.Order;
import shcem.trade.util.TradeSysData;

/**
 * 发票相关
 * 
 * @author wangshuai
 *
 */
public class InvoiceComponentManagerImpl extends BaseManager implements
		IInvoiceComponentManager {

	private String className = this.getClass().getName();
	private IInvoiceDao invoiceDao;
	
	private IInvoiceDao invoiceDao_read;

	public void setInvoiceDao_read(IInvoiceDao invoiceDao_read) {
		this.invoiceDao_read = invoiceDao_read;
	}

	private IDeliveryDAO deliveryDAO;
	
	private IDeliveryDAO deliveryDAO_read;
	
	private IInsurancePolicyDao insurancePolicyDao_read;

	public void setDeliveryDAO_read(IDeliveryDAO deliveryDAO_read) {
		this.deliveryDAO_read = deliveryDAO_read;
	}

	public void setDeliveryDAO(IDeliveryDAO deliveryDAO) {
		this.deliveryDAO = deliveryDAO;
	}

	public void setInvoiceDao(IInvoiceDao invoiceDao) {
		this.invoiceDao = invoiceDao;
	}

	public void setInsurancePolicyDao_read(
			IInsurancePolicyDao insurancePolicyDao_read) {
		this.insurancePolicyDao_read = insurancePolicyDao_read;
	}

	private void rollBack() {
		invoiceDao.rollBack();
	}

	/**
	 * 
	 */
	@Override
	public List<FinancialBills> getFinancialBillsList(QueryConditions qc, PageInfo pageInfo, int financialBillsType) {
		List<FinancialBills> list = null;
		list = this.invoiceDao_read.getFinancialBillsList(qc, pageInfo, financialBillsType);
		if (list != null && list.size() > 0) {

			/**
			 * 1.中石化运费
			 */
			for (FinancialBills financialBills : list) {
				
				if (financialBills.getDeliveryType() == 1) {
					DelDistributionDetail delDistributionDetail = this.deliveryDAO_read.getDelDistributionDetail(financialBills.getDeliveryID());
					if (delDistributionDetail != null) {
//						//溢短数量
//						BigDecimal overLoadQuantity = financialBills.getDeliveryWeight().subtract(financialBills.getTakenQuantity()).divide(new BigDecimal(1),2,BigDecimal.ROUND_CEILING);
//						
//						//实际运费
//						BigDecimal freightFee = delDistributionDetail.getFreightFee().add(delDistributionDetail.getSmallFee()).subtract(
//								delDistributionDetail.getFreightFee().add(delDistributionDetail.getSmallFee()).multiply(overLoadQuantity).
//								divide(financialBills.getDeliveryWeight(),2,BigDecimal.ROUND_CEILING)
//								).divide(new BigDecimal(1),2,BigDecimal.ROUND_CEILING);
						//运费调整额
						BigDecimal overloadFreight = this.deliveryDAO.getSensedFreightFee(financialBills.getDeliveryID());
						BigDecimal freightFee = delDistributionDetail.getFreightFee().add(delDistributionDetail.getSmallFee()).add(
								overloadFreight).divide(new BigDecimal(1),2,BigDecimal.ROUND_CEILING);
						financialBills.setFreightFee(freightFee);
					} else {
						financialBills.setFreightFee(new BigDecimal(0));
					}
				} else {
					financialBills.setFreightFee(new BigDecimal(0));
				}
				
				//货款
				if(financialBills.getApplyType()==1){
					//判断是否有保单记录  并且是买方并且保单状态是10：已中保 的记录
					List<InsurancePolicy> insurancePolicyList = this.insurancePolicyDao_read.getInsurancePolicyByObjectID(financialBills.getOrderId(), 1, 10);
					if(insurancePolicyList!= null && insurancePolicyList.size() > 0){
						for (InsurancePolicy insurancePolicy : insurancePolicyList) {
							//如果存在保单记录,在看看是否有退保记录数据   并且是买方并且退保状态是5已执行
							InsuranceBack insuranceBack = this.insurancePolicyDao_read.getInsuranceBackByDeliveryID(financialBills.getDeliveryID(), Integer.valueOf(insurancePolicy.getId()), 5);
							if(insuranceBack != null){
								financialBills.setRealBackAmount(insuranceBack.getRealBackAmount());
								financialBills.setIsNeedInsurance(1); //可以参保
							}
							else{
								financialBills.setRealBackAmount(new BigDecimal(0)); //实退保金额
								financialBills.setIsNeedInsurance(0); //不能参保
							}
						}
					}else{
						financialBills.setRealBackAmount(new BigDecimal(0)); //实退保金额
						financialBills.setIsNeedInsurance(1);//可以参保
					}
				}else{
					financialBills.setRealBackAmount(new BigDecimal(0)); //实退保金额
					financialBills.setIsNeedInsurance(1);//可以参保
				}
			}

			/**
			 * 2.收票信息(多个取第一个，不存在的话，就为null;)
			 */
			for (int i = 0; i < list.size(); i++) {
				List<Firminvoice> firminvoiceList = this.invoiceDao.getfirmInvoicePlaceList(list.get(i).getFirmID());
				if (firminvoiceList != null && firminvoiceList.size() > 0) {
					/* 收票联系人电话 */
					list.get(i).setCollectTel(firminvoiceList.get(0).getCollectTel());
					/* 收件人姓名 */
					list.get(i).setCollectInvoicePeople(firminvoiceList.get(0).getCollectInvoicePeople());
					/* 收票地址：collectInvoiceAddress */
					list.get(i).setCollectInvoiceAddress(firminvoiceList.get(0).getCollectInvoiceAddress());
				}
			}
		}
		return list;
	}

	/**
	 * 新增收票记录 return 0:正常 -1:新增收票失败
	 * 
	 */
	@Override
	public int addInvoiceCollectDetail(InvoiceCollectDetail invoiceCollectDetail) {
		int resultCode = 0;
		this.log.info(className + " addInvoiceCollectDetail() Start");
		try {
			// 插入收票详细表
			int detailID = invoiceDao
					.insertInvoiceCollectDetail(invoiceCollectDetail);
			// 插入收票关联表
			InvoiceCollectDetailRel invoiceCollectDetailRel = new InvoiceCollectDetailRel();
			invoiceCollectDetailRel.setDetailID(detailID);
			invoiceCollectDetailRel.setRelationID(invoiceCollectDetail
					.getRelationID());// 成交ID
			invoiceCollectDetailRel.setStatus(1);// 1：正常 , 5：失效
			invoiceCollectDetailRel.setREC_CREATEBY(invoiceCollectDetail
					.getREC_CREATEBY());
			invoiceCollectDetailRel.setREC_MODIFYBY(invoiceCollectDetail
					.getREC_MODIFYBY());
			invoiceDao.insertInvoiceCollectDetailRel(invoiceCollectDetailRel);
			// 更新订单的发票状态
			resultCode = updateOrderInvoiceCollectStatus(invoiceCollectDetail,resultCode);
		} catch (Exception e) {
			this.log.error("新增收票记录失败" + e.getMessage());
			resultCode = -1;
			this.rollBack();
		}
		this.log.info(className + " addInvoiceCollectDetail() End");
		return resultCode;
	}

	@Override
	public int updateInvoiceCollectDetailByID(
			InvoiceCollectDetail invoiceCollectDetail) {
		int resultCode = 0;
		this.log.info(className + " updateInvoiceCollectDetailByID() Start");
		try {
			// 更新 收票详细表
			invoiceDao.updateInvoiceCollectDetailByID(invoiceCollectDetail);
			// 更新订单的发票状态
			resultCode = updateOrderInvoiceCollectStatus(invoiceCollectDetail,resultCode);
		} catch (Exception e) {
			this.log.error("更新收票记录失败" + e.getMessage());
			resultCode = -1;
			this.rollBack();
		}
		this.log.info(className + " updateInvoiceCollectDetailByID() End");
		return resultCode;
	}

	/**
	 * 更新订单的发票状态
	 */
	private int updateOrderInvoiceCollectStatus(
			InvoiceCollectDetail invoiceCollectDetail, int resultCode) {
		//IOrderManager orderManager = (IOrderManager) TradeSysData.getBean(Constants.BEAN_ORDERMGR_MGR);
		int invoiceCollectStatus = 0;// 收票状态 0：未收票 5：部分收票 10：全部收票
		//Order order = orderManager.getOrderByID(invoiceCollectDetail.getRelationID());
		String relationID = invoiceCollectDetail.getRelationID();
		Order order = this.invoiceDao_read.getOrderInvoiceCollectDetail(relationID);
		if (order != null) {
//			InvoiceCollectDetail countInvoiceCollectDetail = invoiceDao.countInvoiceTotalMoneyByOrderId(relationID);
//			BigDecimal allInvoiceTotalMoney = new BigDecimal(0);// 收票记录的总额 
//			BigDecimal allInvoiceQuantity = new BigDecimal(0);// 收票吨数
//			if (countInvoiceCollectDetail != null) {
//				allInvoiceTotalMoney = countInvoiceCollectDetail.getAllInvoiceTotalMoney();
//				allInvoiceQuantity = countInvoiceCollectDetail.getAllInvoiceQuantity();
//			}
//			// 货款金额 == 成交单下所有收票记录的总额 , 货物数量 = 收票吨数
//			if (order.getAmount().compareTo(allInvoiceTotalMoney) == 0 && order.getTotalQuantity().compareTo(allInvoiceQuantity) == 0) {
//				invoiceCollectStatus = 10;
//			} else if (allInvoiceTotalMoney.compareTo(new BigDecimal(0)) == 0
//					&& allInvoiceQuantity.compareTo(new BigDecimal(0)) == 0) {
//				invoiceCollectStatus = 0;
//			} else {
//				invoiceCollectStatus = 5;
//			}
			BigDecimal allInvoiceTotalMoney = order.getAllInvoiceTotalMoney();// 收票记录的总额 
//			BigDecimal sellPaidSellFreightTotal = order.getSellPaidSellFreightTotal();// 卖方已付运费
//			BigDecimal sellTakenTradeFee = order.getSellTakenTradeFee();// 卖方交易已收手续费
			
			// 应收票金额=货款+已付运费-已收手续费(不包含优惠券部分)
//			BigDecimal sellShouldInvoiceCollectMoney = order.getAmount().add(sellPaidSellFreightTotal).subtract(sellTakenTradeFee);
			
//			if (allInvoiceTotalMoney.compareTo(sellShouldInvoiceCollectMoney) == 0) {
//				invoiceCollectStatus = 10;
//			} else
			if (allInvoiceTotalMoney.compareTo(new BigDecimal(0)) == 0) {
				invoiceCollectStatus = 0;
			} else {
				invoiceCollectStatus = 5;
			}
			invoiceDao.updateOrderOfInvoiceCollectStatus(relationID, invoiceCollectStatus,invoiceCollectDetail.getREC_MODIFYBY());
		} else {
			resultCode = -1;
			this.log.info("没有查询到成交单信息,成交单ID："
					+ relationID);
		}
		return resultCode;
	}

	@Override
	public int updateInvoiceCollectDetailRelOfStatus(Integer id,
			Integer status, String modifyBy) {
		int resultCode = 0;
		this.log.info(className
				+ " updateInvoiceCollectDetailRelOfStatus() Start");
		try {
			// 更新 收票关联表的状态
			invoiceDao.updateInvoiceCollectDetailRelOfStatus(id, status,
					modifyBy);
			// 获取 收票关联表的信息
			InvoiceCollectDetailRel invoiceCollectDetailRel = invoiceDao
					.selectInvoiceCollectDetailRelById(id);
			if (invoiceCollectDetailRel != null) {
				// 获取收票详细表信息
				InvoiceCollectDetail invoiceCollectDetail = invoiceDao
						.selectInvoiceCollectDetailByID(invoiceCollectDetailRel
								.getDetailID());
				if (invoiceCollectDetail != null) {
					resultCode = updateOrderInvoiceCollectStatus(
							invoiceCollectDetail, resultCode);
				} else {
					resultCode = -1;
					this.log.info("没有查询到收票详细表的数据,DetailID:"
							+ invoiceCollectDetailRel.getDetailID());
				}

			} else {
				resultCode = -1;
				this.log.info("没有查询到收票关联表的数据,ID:" + id);
			}

		} catch (Exception e) {
			this.log.error("更新收票关联表状态失败" + e.getMessage());
			resultCode = -1;
			this.rollBack();
		}
		this.log.info(className
				+ " updateInvoiceCollectDetailRelOfStatus() End");
		return resultCode;
	}

	@Override
	public InvoiceCollectDetail getInvoiceCollectDetailByID(Integer id) {
		InvoiceCollectDetail invoiceCollectDetail = null;
		this.log.info(className + " getInvoiceCollectDetailByID() Start");
		try {
			invoiceCollectDetail = invoiceDao_read
					.selectInvoiceCollectDetailByID(id);
		} catch (Exception e) {
			this.log.error("查询收票记录失败,id=" + id + " " + e.getMessage());
		}
		this.log.info(className + " getInvoiceCollectDetailByID() End");
		return invoiceCollectDetail;
	}

	@Override
	public List<InvoiceCollectDetail> selectInvoiceCollectDetailListByRelationID(
			String relationID) {
		List<InvoiceCollectDetail> invoiceCollectDetailList = null;
		this.log.info(className
				+ " selectInvoiceCollectDetailListByRelationID() Start");
		try {
			invoiceCollectDetailList = invoiceDao_read
					.selectInvoiceCollectDetailListByRelationID(relationID);
		} catch (Exception e) {
			this.log.error("查询收票记录列表失败,relationID=" + relationID + " "
					+ e.getMessage());
		}
		this.log.info(className
				+ " selectInvoiceCollectDetailListByRelationID() End");
		return invoiceCollectDetailList;
	}

	@Override
	public int updateOrderOfInvoiceCollectStatus(String orderId,
			Integer invoiceCollectStatus, String modifyBy) {
		int resultCode = 0;
		this.log.info(className + " updateOrderOfInvoiceCollectStatus() Start");
		try {
			invoiceDao.updateOrderOfInvoiceCollectStatus(orderId,
					invoiceCollectStatus, modifyBy);
		} catch (Exception e) {
			this.log.error("更新订单的收票状态失败,orderId:=" + orderId + " "
					+ e.getMessage());
			resultCode = -1;
		}
		this.log.info(className + " updateOrderOfInvoiceCollectStatus() End");
		return resultCode;
	}

	@Override
	public List<Order> selectOrderList(QueryConditions qc, PageInfo pageInfo) {
		this.log.info(className + " selectOrderList() Start");
		List<Order> orderList = invoiceDao_read.selectOrderList(qc, pageInfo);
		if (orderList != null && orderList.size() > 0) {

			for (Order order : orderList) {
				//判断是否有保单记录  并且是买方并且保单状态是10：已中保 的记录
				List<InsurancePolicy> insurancePolicyList = this.insurancePolicyDao_read.getInsurancePolicyByObjectID(order.getOrderId(), 0, 10);
				if(insurancePolicyList!= null && insurancePolicyList.size() > 0){
					BigDecimal realBackAmount = new BigDecimal(0);
					
					for (InsurancePolicy insurancePolicy : insurancePolicyList) {
						//如果存在保单记录,在看看是否有退保记录数据   并且是买方并且退保状态是5已执行
						List<InsuranceBack> insuranceBackList = this.insurancePolicyDao_read.getInsuranceBackList(Integer.valueOf(insurancePolicy.getId()), 5);
						if(insuranceBackList!=null && insuranceBackList.size()>0){
							for(InsuranceBack insuranceBack : insuranceBackList) {
								realBackAmount = realBackAmount.add(insuranceBack.getRealBackAmount());
							}
							order.setRealBackAmount(realBackAmount);//实退保金额
						}else{
							order.setRealBackAmount(new BigDecimal(0)); //实退保金额
						}
					}
					
				}else{
					order.setRealBackAmount(new BigDecimal(0)); //实退保金额
				}
			}
		}
		
		this.log.info(className + " selectOrderList() End");
		return orderList;
	}

	@Override
	public InvoiceApply getInvoiceDetail(String firmID) {
		InvoiceApply invoiceApply = this.invoiceDao_read.getInvoiceDetail(firmID);
		return invoiceApply;
	}

	@Override
	public String addInvoiceApply(String[] deliveryIDArray,
			InvoiceApply invoiceApply, String userName) {
		int invoiceApplyID = this.invoiceDao.addInvoiceApply(invoiceApply,
				userName);
		if(invoiceApplyID < 0){
			return "-1";
		}
		String returnCode = "0";
		if (!(null == deliveryIDArray) && deliveryIDArray.length > 0) {
			for (int i = 0; i < deliveryIDArray.length; i++) {
				int invoiceApplyRelCount = this.invoiceDao
						.getInvoiceApplyRelCount(deliveryIDArray[i],
								invoiceApply.getApplyType());
				if (invoiceApplyRelCount > 0) {
					this.invoiceDao.rollBack();
					return "单号 【" + deliveryIDArray[i] + "】 已经申请开票，无须再次申请";
				}
				returnCode = this.invoiceDao.addInvoiceApplyRel(invoiceApplyID,
						deliveryIDArray[i], userName);
				if (returnCode.equals("-1")) {
					this.invoiceDao.rollBack();
					return returnCode;
				}
			}
		}
		return returnCode;
	}

	@Override
	public List<InvoiceApply> getInvoiceApplyList(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+" getInvoiceApplyList Start");
		List<InvoiceApply> list = this.invoiceDao.getInvoiceApplyList(qc,
				pageInfo);
		List<InvoiceApply4Check> listTemp = this.invoiceDao_read.getInvoiceApply4CheckList(qc,
				pageInfo,false);
		if(listTemp != null && listTemp.size()  > 0){
			for (int i = 0; i < listTemp.size(); i++) {
				boolean isDetailed = InvoiceApply4CheckUtil.CheckInvoiceApply4CheckData(listTemp.get(i));
				list.get(i).setIsDetailed(isDetailed);
			}
		}
		this.log.info(this.getClass().getName()+" getInvoiceApplyList End");
		return list;
	}
	
	@Override
	public int getInvoiceApplyList4ExportCount(QueryConditions qc) {
		this.log.info(this.getClass().getName()+" getInvoiceApplyList4ExportCount Start");
		int totalCount = this.invoiceDao_read.getInvoiceApplyList4ExportCount(qc);
		this.log.info(this.getClass().getName()+" getInvoiceApplyList4ExportCount End");
		return totalCount;
	}
	/**
	 *  导出开票流水数据
	 */
	@Override
	public List<InvoiceApply4Export> getInvoiceApplyList4Export(QueryConditions qc,PageInfo pageInfo,boolean replace) {
		this.log.info(this.getClass().getName()+" getInvoiceApplyList4Export Start");
		List<InvoiceApply4Export> list = new ArrayList<InvoiceApply4Export>();
		
		List<InvoiceApply4Export> list_all = this.invoiceDao_read.getInvoiceApplyList4Export(qc, pageInfo,replace);
		List<InvoiceApply4Check> listTemp = this.invoiceDao_read.getInvoiceApply4CheckList(qc,pageInfo,replace);
		
		if(listTemp != null && listTemp.size()  > 0){
			for (int i = 0; i < listTemp.size(); i++) {
				boolean isDetailed = InvoiceApply4CheckUtil.CheckInvoiceApply4CheckData(listTemp.get(i));
				list_all.get(i).setIsDetailed(isDetailed);
			}
		}
		
		
		if(list_all != null && list_all.size() > 0){
			for (InvoiceApply4Export invoiceApply4Export : list_all) {
				if(invoiceApply4Export.getIsDetailed())list.add(invoiceApply4Export);
			}
		}
		
		this.log.info(this.getClass().getName()+" getInvoiceApplyList4Export End");
		return list;
	}

	@Override
	public int cancelInvoiceApply(int invoiceApplyID, String userName) {
		int returnCode = 0;
		List<InvoiceDetailRel> list = this.invoiceDao
				.getInvoiceDetailRel(invoiceApplyID);
		if (list != null && list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				// 发票撤销失效
				returnCode = this.invoiceDao.disabledInvoiceDetail(list.get(i)
						.getInvoiceDetailID());
				if (returnCode == -1)
					return returnCode;
				returnCode = this.invoiceDao.deleteInvoiceDetailRel(list.get(i)
						.getId());
				if (returnCode == -1) {
					this.rollBack();
					return returnCode;
				}

			}
		}
		// 更新申请流水
		returnCode = this.invoiceDao.updateInvoiceApplyStatus(invoiceApplyID,
				1, userName);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}
		return returnCode;
	}

	@Override
	public int importInvoice(List<ImportInvoiceDetail> list, String userName) {
		int returnCode = 0;
		if (null != list && list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				// 发票导入的信息
				InvoiceDetail invoiceDetail = this.getImportInvoiceDetail(list
						.get(i));
				// 发票其他信息（从开票申请记录查询）
				if (invoiceDetail != null) {
					String[] invoiceNoArray = invoiceDetail.getInvoiceNoArray();
					for (int j = 0; j < invoiceNoArray.length; j++) {
						invoiceDetail.setInvoiceNo(invoiceNoArray[j]);
						invoiceDetail = this
								.getOtherInvoiceDetail(invoiceDetail);
						// 新增发票
						returnCode = this.addInvoiceDetail(invoiceDetail,
								userName);
						if (returnCode == -1)
							return returnCode;
						// 更新开票申请 状态 1：已申请，待财务处理 5：已审批 ，10：已拒绝，15：开票完成
						returnCode = this.invoiceDao.updateInvoiceApplyStatus(
								invoiceDetail.getApplyRelID(), 15, userName);
						if (returnCode == -1) {
							this.rollBack();
							return returnCode;
						}
					}
				}
			}
		}
		return returnCode;
	}

	private int addInvoiceDetail(InvoiceDetail invoiceDetail, String userName) {
		int returnCode = 0;
		// int count =
		// this.invoiceDao.getInvoiceDetailCount(invoiceDetail.getInvoiceNo());
		// 快递单号是否存在
		if (invoiceDetail.getTrackingNo().equals("")) {
			// if(count <= 0){
			int invoiceDetailID = this.invoiceDao.addInvoiceDetail(
					invoiceDetail, userName);
			if (invoiceDetailID == -1)
				return returnCode = -1;
			// 新增发票流水关联表
			returnCode = this.invoiceDao.addInvoiceDetailRel(invoiceDetailID,
					invoiceDetail.getInvoiceApplyRelID(), userName);
			if (returnCode == -1) {
				this.invoiceDao.rollBack();
				return returnCode;
			}
			// }
		} else {
			// if(count <= 0){
			int invoiceDetailID = this.invoiceDao.addInvoiceDetail(
					invoiceDetail, userName);
			if (invoiceDetailID == -1)
				return returnCode = -1;
			// 新增发票流水关联表
			returnCode = this.invoiceDao.addInvoiceDetailRel(invoiceDetailID,
					invoiceDetail.getInvoiceApplyRelID(), userName);
			if (returnCode == -1) {
				this.invoiceDao.rollBack();
				return returnCode;
			}
			// }else {
			returnCode = this.invoiceDao.updateInvoiceDetail(
					invoiceDetail.getTrackingNo(),
					invoiceDetail.getInvoiceNo(), userName);
			// }
		}
		return returnCode;
	}

	private InvoiceDetail getOtherInvoiceDetail(InvoiceDetail invoiceDetail) {
		InvoiceApply invoiceApply = this.invoiceDao
				.getInvoiceApply(invoiceDetail.getApplyRelID());
		// 税号
		invoiceDetail.setTaxNo(invoiceApply.getTaxNo());
		// 开票银行
		invoiceDetail.setBankName(invoiceApply.getBankName());
		// 开票银行帐号
		invoiceDetail.setBankAccount(invoiceApply.getBankAccount());
		// 开票地址
		invoiceDetail.setInvoiceAddress(invoiceApply.getInvoiceAddress());
		// 开票电话
		invoiceDetail.setInvoiceTel(invoiceApply.getInvoiceTel());
		// 发票内容
		invoiceDetail.setInvoiceContent("发票内容是啥，怎么填，是单号、商品名称、型号信息吗？");
		// /**开票申请关联表ID*/
		invoiceDetail.setInvoiceApplyRelID(invoiceApply.getInvoiceApplyRelID());
		return invoiceDetail;
	}

	/**
	 * 根据导入模板，获取发票数据
	 * 
	 * @param importInvoiceDetail
	 * @return
	 */
	private InvoiceDetail getImportInvoiceDetail(
			ImportInvoiceDetail importInvoiceDetail) {
		InvoiceDetail invoiceDetail = new InvoiceDetail();
		/***
		 * 发票类型，1增值税发票,5普通发票 InvoiceType 发票号 InvoiceNo 发票日期 InvoiceDate 发票抬头
		 * InvoiceTitle 税号 TaxNo 开票银行 BankName 开票银行帐号 BankAccount 开票地址
		 * InvoiceAddress 开票电话 InvoiceTel 发票内容 InvoiceContent 发票数量（吨）
		 * InvoiceQuantity 发票单价（元) InvoicePrice 税率 TaxRate 发票金额 InvoiceMoney
		 * 发票税额 InvoiceTax 发票总额（含税） InvoiceTotalMoney 快递单号 TrackingNo 备注 Remark
		 * 默认为 0：正常，1：失效 DISABLED 创建人 REC_CREATEBY 创建时间 REC_CREATETIME 最后修改人
		 * REC_MODIFYBY 最后修改时间 REC_MODIFYTIME
		 */
		// 发票单号 数组
		invoiceDetail.setInvoiceNoArray(importInvoiceDetail.getInvoiceNo());
		// 发票类型，1增值税发票,5普通发票
		invoiceDetail.setInvoiceType(importInvoiceDetail.getInvoiceType());
		// 发票抬头
		invoiceDetail.setInvoiceTitle(importInvoiceDetail.getCompanyName());
		// 发票数量（吨）
		invoiceDetail.setInvoiceQuantity(importInvoiceDetail.getQuantity());
		// 发票单价（元)
		invoiceDetail.setInvoicePrice(importInvoiceDetail.getPrice());
		// 税率
		invoiceDetail.setTaxRate(importInvoiceDetail.getTaxRate());
		// 发票金额
		invoiceDetail.setInvoiceMoney(new BigDecimal(0));
		// 发票税额
		invoiceDetail.setInvoiceTax(new BigDecimal(0));
		// 发票总额（含税）
		invoiceDetail.setInvoiceTotalMoney(importInvoiceDetail.getTotalMoney());
		// 快递单号
		invoiceDetail.setTrackingNo(importInvoiceDetail.getTrackingNo());
		// 备注
		invoiceDetail.setRemark(importInvoiceDetail.getRemark());
		// 关联单号
		invoiceDetail.setApplyRelID(importInvoiceDetail.getRelationNo());
		return invoiceDetail;
	}
	@Override
	public int getExportInvoiceCollectDetailCount(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+" getExportInvoiceCollectDetailCount Start");
		int totalCount = this.invoiceDao.getExportInvoiceCollectDetailCount(qc,pageInfo);
		this.log.info(this.getClass().getName()+" getExportInvoiceCollectDetailCount End");
		return totalCount;
	}
	
	@Override
	public List<ExportInvoiceCollectDetail> exportInvoiceCollectDetailList(
			QueryConditions qc, PageInfo pageInfo,boolean replace) {
		this.log.info(this.getClass().getName()
				+ ".exportInvoiceCollectDetailList() component Start");
		List<InvoiceCollect4Export> list = invoiceDao.exportInvoiceCollectDetailList(qc,
				pageInfo,replace);
		List<ExportInvoiceCollectDetail> exportList = new ArrayList<ExportInvoiceCollectDetail>();
		ExportInvoiceCollectDetail exportInvoiceCollectDetail = null;
		for (InvoiceCollect4Export invoiceCollect4Export : list) {
			exportInvoiceCollectDetail = new ExportInvoiceCollectDetail();
			exportInvoiceCollectDetail.setOrderId(invoiceCollect4Export.getOrderId());
			exportInvoiceCollectDetail.setTradeTmptName(invoiceCollect4Export
					.getTradeTmptName());
			exportInvoiceCollectDetail.setTradeDate(invoiceCollect4Export.getTradeDate());
			exportInvoiceCollectDetail.setTradeStatusName(OrderTradeStatusUtil
					.getTradeStatusName(invoiceCollect4Export.getTradeStatus()));
			exportInvoiceCollectDetail.setSellFirmName(invoiceCollect4Export.getSellFirmName());
			exportInvoiceCollectDetail.setGoodName(invoiceCollect4Export.getGoodName());
			exportInvoiceCollectDetail.setTotalQuantityTon(invoiceCollect4Export
					.getTotalQuantity());
			exportInvoiceCollectDetail.setSignQuantityTon(invoiceCollect4Export
					.getDeliveryTakenQuantity());
			exportInvoiceCollectDetail.setPrice(invoiceCollect4Export.getPrice());
			exportInvoiceCollectDetail.setAmount(invoiceCollect4Export.getAmount());
			exportInvoiceCollectDetail.setSignAmount(invoiceCollect4Export.getPrice().multiply(
					invoiceCollect4Export.getDeliveryTakenQuantity()));
			exportInvoiceCollectDetail.setCollectDate(invoiceCollect4Export
					.getInvoiceCollectDate());
			exportInvoiceCollectDetail.setShouldInvoiceMoney(invoiceCollect4Export.getShouldInvoiceMoney());
			exportInvoiceCollectDetail.setInvoiceTotalMoney(invoiceCollect4Export
					.getInvoiceTotalMoney());
			exportInvoiceCollectDetail.setInvoiceQuantity(invoiceCollect4Export
					.getInvoiceQuantity());
			exportInvoiceCollectDetail.setInvoiceNo(invoiceCollect4Export.getInvoiceNo());
			exportInvoiceCollectDetail.setRemark(invoiceCollect4Export.getInvoiceRemark());
			exportList.add(exportInvoiceCollectDetail);
		}
		this.log.info(this.getClass().getName()
				+ ".exportInvoiceCollectDetailList() component End");
		return exportList;
	}

	@Override
	public int invalidInvoiceApply(Integer applyID, String userName) {
		this.log.info(this.getClass().getName()
				+ ".invalidInvoiceApply() component Start");
		int resultCode = 0;
		try {
			List<InvoiceApplyRel> invoiceApplyRelList = invoiceDao
					.getInvoiceApplyRelByInvoiceApplyID(applyID);
			if (invoiceApplyRelList != null && invoiceApplyRelList.size() > 0) {
				for (InvoiceApplyRel invoiceApplyRel : invoiceApplyRelList) {
					invoiceDao.disabledInvoiceDetailRelByApplyRelID(
							invoiceApplyRel.getId(), userName);// 废弃
																// 发票详细ID和申请流水ID的关系
				}
			}
			invoiceDao.disabledInvoiceApplyRelByInvoiceApplyID(applyID,
					userName);// 废弃 开票申请ID和交收单号的关系
			invoiceDao.updateInvoiceApply(applyID, 10);// 更新 开票申请流水表 的状态为 已拒绝
		} catch (Exception e) {
			this.log.equals("作废开票申请流水失败," + e.getMessage());
			invoiceDao.rollBack();
			resultCode = -1;
			return resultCode;
		}
		this.log.info(this.getClass().getName()
				+ ".invalidInvoiceApply() component End");
		return resultCode;
	}

	@Override
	public List<Firminvoice> getfirmInvoicePlaceList(String firmID) {
		List<Firminvoice> list = this.invoiceDao_read
				.getfirmInvoicePlaceList(firmID);
		return list;
	}

	@Override
	public InvoiceApply getInvoiceApplyByID(Integer relationNo) {
		InvoiceApply invoiceApply = this.invoiceDao.getInvoiceApply(relationNo);
		return invoiceApply;
	}

	/**
	 * 开票申请，数据校验
	 */
	@Override
	public String checkInvoiceApply(List<InvoiceApply4Check> invoiceApplyList) {
		this.log.info(this.getClass().getName() + " checkInvoiceApply Start");
		String returnMessage = "";
		returnMessage = InvoiceApply4CheckUtil.checkInvoiceApply4Check(invoiceApplyList,log);
		this.log.info(this.getClass().getName() + " checkInvoiceApply End");
		return returnMessage.replace(" ", "");
	}
	
	/**
	 * 开票，批量申请
	 */ 
	@Override
	public int addInvoiceApplyList(List<InvoiceApply> invoiceApplyListTemp,String userName) {
		this.log.info(this.getClass().getName()+" addInvoiceApplyList Start");
		int returnCode = 0;
		/**
		 * 1.校验数据，剔除不完整的申请数据
		 */
		List<InvoiceApply> invoiceApplyList = InvoiceApply4CheckUtil.getFullInvoiceApplyList(invoiceApplyListTemp,log);
		
		/**
		 * 2.批量新增
		 */
		if(invoiceApplyList != null && invoiceApplyList.size() > 0){
			String[] deliveryIDArray = new String[1];
			for (int i = 0; i < invoiceApplyList.size(); i++) {
				deliveryIDArray[0] = invoiceApplyList.get(i).getDeliveryID();
				String returnCodeString = this.addInvoiceApply(deliveryIDArray, invoiceApplyList.get(i), userName);
				returnCode = Integer.parseInt(returnCodeString);
				if(returnCode < 0){
					this.rollBack();
					break;
				}
			}
		}else {
			returnCode = -1;
		}
		this.log.info(this.getClass().getName()+" addInvoiceApplyList End");
		return returnCode;
	}
	
	public static void main(String[] args) {
		InvoiceApply invoiceApply = new InvoiceApply();
		invoiceApply.setBankName("中国人民银行");
		invoiceApply.setRemark("  dfs         dasf   ");
		Class data = invoiceApply.getClass();
		Field[] fields = data.getDeclaredFields();
		for (int i = 0; i < fields.length; i++) {
			 	Field f = fields[i];
			 	f.setAccessible(true);
            	try {
            		if(f.get(invoiceApply) != null){
            			String fieldValue =  f.get(invoiceApply).toString().replace(" ", "");	
            			System.out.println("属性名:" + f.getName() + " 属性值:" + fieldValue);
            		}
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		String reString ="-40000";
		System.err.println(Integer.parseInt(reString));
	}
	
	@Override
	public int disOrEnabled(String deliveryID, int applyType, int enabled,
			String userName) {
		this.log.info(this.getClass().getName()+" disOrEnabled Start");
		int returnCode = 0;
		if(applyType == 1){//货款
			returnCode = this.invoiceDao.disOrEnabled(deliveryID, "IsInvoiceOpenAmout",enabled,userName);
		}else {//手续费
			returnCode = this.invoiceDao.disOrEnabled(deliveryID, "IsInvoiceOpenFee",enabled,userName);
		}
		
		this.log.info(this.getClass().getName()+" disOrEnabled End");
		return returnCode;
	}
	
	@Override
	public InvoiceApply getInvoiceApplyDetail(int invoiceApplyID) {
		this.log.info(this.getClass().getName()+" getInvoiceApplyDetail Start");
		InvoiceApply invoiceApply = new InvoiceApply();
		invoiceApply = this.invoiceDao_read.getInvoiceApply(invoiceApplyID);
		this.log.info(this.getClass().getName()+" getInvoiceApplyDetail End");
		return invoiceApply;
	}
	
	/**
	 * 开票详情修改(未开票完成能修改)
	 */
	@Override
	public int updateInvoiceApplyDetail(InvoiceApply invoiceApply,
			String userName) {
		this.log.info(this.getClass().getName()+" updateInvoiceApplyDetail Start");
		int returnCode = 0;
		InvoiceApply invoiceApplyTemp = this.invoiceDao.getInvoiceApply(invoiceApply.getId());
		if(invoiceApplyTemp.getApplyStatus() == 5)return returnCode = -80003;
		returnCode = this.invoiceDao.updateInvoiceApplyDetail(invoiceApply,userName);
		this.log.info(this.getClass().getName()+" updateInvoiceApplyDetail End");
		return returnCode;
	}
	
	/**
	 * 发票导入Excel校验
	 */
	@Override
	public String checkInvoceExcelToList(List<ImportInvoiceDetail> list) {
		this.log.info(this.getClass().getName()+" checkInvoceExcelToList Start");
		String returnMessage = "";
		int loopCount = 0;
		for (int i = 0; i < list.size(); i++) {
			boolean record = true;
			/*销售单号、备注(交收单号)匹配校验*/
			InvoiceApply invoiceApply = this.invoiceDao_read.getInvoiceApply(list.get(i).getRelationNo());
			if(invoiceApply == null){
				returnMessage += " 不存在销售单据号为：【 "+list.get(i).getRelationNo()+"】 : 的开票申请！^^ ";
				record = false;
			}else {
				if(!invoiceApply.getDeliveryID().equals(list.get(i).getRemark())){
					returnMessage += " 销售单据号为：【 "+list.get(i).getRelationNo()+"】  和发起的开票申请数据【"+list.get(i).getRemark()+"】 不匹配!^^ ";
					record = false;
				}
			
			
				/*价税合计 校验*/
				if(!(list.get(i).getTotalMoney().compareTo(invoiceApply.getApplyMoney()) == 0)){
					returnMessage += " 销售单据号为： 【"+list.get(i).getRelationNo()+"】 的'价税合计'和申请金额不匹配！^^ ";
					record = false;
				}
				
				/*是否已经导入校验:1：已申请，待财务处理 5：已审批 ，10：已拒绝，15：开票完成 */
				if(invoiceApply.getApplyStatus() == 15){
					returnMessage += " 销售单据号为： 【"+list.get(i).getRelationNo()+"】 的开票申请已经开票,无须再次开票！^^ ";
					record = false;
				}
			}
			if (!record) {
				loopCount++;
			}
		}
		returnMessage = "先生，您好！共 "+loopCount+" 条开票数据不能导入。原因：开票数据不匹配/不完善，错误信息：^^"+returnMessage;
		if(loopCount == 0)returnMessage = "数据校验全部通过！可以全部导入！";
		this.log.info(this.getClass().getName()+" checkInvoceExcelToList End");
		return returnMessage;
	}
	
	/**
	 * 发票导入Excel,剔除不正确的数据
	 */
	@Override
	public List<ImportInvoiceDetail> getCorrectImportInvoiceList(
			List<ImportInvoiceDetail> listTemp) {
		this.log.info(this.getClass().getName()+" getCorrectImportInvoiceList Start");
		List<ImportInvoiceDetail> list = InvoiceApply4CheckUtil.getCorrectImportInvoiceList(listTemp,invoiceDao,log);
		this.log.info(this.getClass().getName()+" getCorrectImportInvoiceList End");
		if(list != null && list.size() > 0){
			return list;
		}else {
			return null;
		}
	}
	
	@Override
	public InvoiceApply4Check getApplyAddress(String firmID) {
		this.log.info(this.getClass().getName()+" InvoiceApply4Check Start");
		
		this.log.info(this.getClass().getName()+" InvoiceApply4Check End");
		return null;
	}
	/**
	 *  @param invoiceStatus 充值型优惠券列表展示位置：0展示在"开票管理"页面 2 展示在"开票申请流水"页面 
	 */
	@Override
	public List<InvoiceApply> getCouponInvoiceApplyListByCustomer(
			QueryConditions qc, PageInfo pageInfo,int invoiceStatus) {
		this.log.info(this.getClass().getName()+" getCouponInvoiceApplyListByCustomer Start");
		List<InvoiceApply> list = this.invoiceDao_read.getCouponInvoiceApplyListByCustomer(qc,pageInfo,invoiceStatus);
		this.log.info(this.getClass().getName()+" getCouponInvoiceApplyListByCustomer End");	
		return list;
	}
	
	@Override
	public int updateCouponInvoiceApplyListByCustomer(int invoiceApplyID,
			InvoiceApply invoiceApply, String userName,InvoiceApply4Check invoiceApply4Check) {
		this.log.info(this.getClass().getName()+" updateCouponInvoiceApplyListByCustomer Start");
		int returnCode = 0;
		/**
		 * 1.后台校验开票信息是否完善
		 */
		boolean checkStatus = InvoiceApply4CheckUtil.CheckInvoiceApply4CheckData(invoiceApply4Check);
		if(!checkStatus) return -40024;
		
		/**
		 * 2.后台修改完善前台客户提请的开票申请数据
		 */
		returnCode = this.invoiceDao.updateCouponInvoiceApplyListByCustomer(invoiceApply,invoiceApplyID,userName);
		
		this.log.info(this.getClass().getName()+" updateCouponInvoiceApplyListByCustomer End");
		return returnCode;
	}
	
	@Override
	public int updateIsInvoiceOpen(int invoiceApplyID, String userName,int IsInvoiceOpen) {
		this.log.info(this.getClass().getName()+" updateIsInvoiceOpen Start");
		int returnCode = 0;
		returnCode = this.invoiceDao.updateIsInvoiceOpen(invoiceApplyID,userName,IsInvoiceOpen);
		this.log.info(this.getClass().getName()+" updateIsInvoiceOpen End");
		return returnCode;
	}
	
	@Override
	public int updateCouponInvoiceApplyListByCustomerWithLotSize(
			List<InvoiceApply> invoiceApplyListTemp, String userName) {
		this.log.info(this.getClass().getName()+" updateCouponInvoiceApplyListByCustomerWithLotSize Start");
		int returnCode = 0;
		/**
		 * 1.校验数据，剔除不完整的申请数据
		 */
		List<InvoiceApply> invoiceApplyList = InvoiceApply4CheckUtil.getFullInvoiceApplyList(invoiceApplyListTemp,log);
		
		/**
		 * 2.批量修改
		 */
		if(invoiceApplyList != null && invoiceApplyList.size() > 0){
			for (int i = 0; i < invoiceApplyList.size(); i++) {
				InvoiceApply invoiceApply = invoiceApplyList.get(i);
				int invoiceApplyID = invoiceApply.getId();
				returnCode = this.invoiceDao.updateCouponInvoiceApplyListByCustomer(invoiceApply, invoiceApplyID, userName);
				if(returnCode < 0){
					this.rollBack();
					return returnCode;
				}
			}
		}else {
			returnCode = -1;
		}
		
		this.log.info(this.getClass().getName()+" updateCouponInvoiceApplyListByCustomerWithLotSize End");
		return returnCode;
	}
	
	@Override
	public int getCouponInvoiceApplyListByCustomerCount(QueryConditions qc) {
		this.log.info(this.getClass().getName()+" getCouponInvoiceApplyListByCustomerCount Start");
		int totalCount = this.invoiceDao_read.getCouponInvoiceApplyListByCustomerCount(qc);
		this.log.info(this.getClass().getName()+" getCouponInvoiceApplyListByCustomerCount End");
		return totalCount;
	}
	
	@Override
	public List<InvoiceApply4Export> getCouponInvoiceApplyList4Export(
			QueryConditions qc, PageInfo pageInfo, boolean replace,int invoiceStatus) {
		this.log.info(this.getClass().getName()+" getCouponInvoiceApplyList4Export Start");
		List<InvoiceApply4Export> list = this.invoiceDao_read.getCouponInvoiceApplyList4Export(qc, pageInfo,replace,invoiceStatus);
		this.log.info(this.getClass().getName()+" getCouponInvoiceApplyList4Export End");
		return list;
	}

	@Override
	public Order getOrderInvoiceCollectDetail(String orderId) {
		this.log.info(this.getClass().getName()+" getOrderInvoiceCollectDetail Start");
		Order order = this.invoiceDao_read.getOrderInvoiceCollectDetail(orderId);
		this.log.info(this.getClass().getName()+" getOrderInvoiceCollectDetail End");
		return order;
	}

}
