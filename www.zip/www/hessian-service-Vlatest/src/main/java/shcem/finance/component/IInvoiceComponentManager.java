package shcem.finance.component;

import java.util.List;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.ExportModel.InvoiceApply4Export;
import shcem.finance.dao.model.ExportInvoiceCollectDetail;
import shcem.finance.dao.model.FinancialBills;
import shcem.finance.dao.model.InvoiceApply4Check;
import shcem.finance.dao.model.InvoiceCollectDetail;
import shcem.trade.dao.model.Order;
import shcem.finance.dao.model.InvoiceApply;
import shcem.finance.service.model.ImportInvoiceDetail;
import shcem.member.dao.model.Firminvoice;


/**
 * 发票相关
 * @author wangshuai
 *
 */
public interface IInvoiceComponentManager extends Manager {
	public abstract List<FinancialBills> getFinancialBillsList(
			QueryConditions qc, PageInfo pageInfo, int financialBillsType);

	
	/**
	 * 新增收票记录
	 * @param invoiceCollectDetail
	 * @return
	 */
	int addInvoiceCollectDetail(InvoiceCollectDetail invoiceCollectDetail);
	
	/**
	 * 更新收票记录
	 * @param invoiceCollectDetail
	 * @return
	 */
	int updateInvoiceCollectDetailByID(InvoiceCollectDetail invoiceCollectDetail);
	
	/**
	 * 更新收票记录的状态
	 * @param id 收票关联表ID
	 * @param status 收票关联表状态  1：正常 , 5：失效
	 * @param modifyBy 修改人
	 * @return
	 */
	int updateInvoiceCollectDetailRelOfStatus(Integer id,Integer status,String modifyBy);
	
	/**
	 * 更新收票记录的状态
	 * @return
	 */
	InvoiceCollectDetail getInvoiceCollectDetailByID(Integer id);
	
	/**
	 * 根据relationID 查询收票详细表列表
	 * @param relationID
	 * @return
	 */
	List<InvoiceCollectDetail> selectInvoiceCollectDetailListByRelationID(String relationID);
	
	
	/**
	 * 更新订单的收票状态（0：未收票  5：部分收票 10：全部收票）
	 * @return
	 */
	int updateOrderOfInvoiceCollectStatus(String orderId,Integer invoiceCollectStatus,String modifyBy);
	
	/**
	 * 查询开票管理的列表
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	List<Order> selectOrderList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 根据订单ID 获取成交单收票的详情
	 * @param orderId
	 * @return
	 */
	Order getOrderInvoiceCollectDetail(String orderId);
	
	

	public abstract String addInvoiceApply(String[] deliveryIDArray,
			InvoiceApply invoiceApply, String userName);

	public abstract InvoiceApply getInvoiceDetail(String firmID);

	public abstract List<InvoiceApply> getInvoiceApplyList(QueryConditions qc,
			PageInfo pageInfo);

	public abstract int cancelInvoiceApply(int invoiceApplyID,String userName);

	/**
	 * 开票数据导入，生成发票
	 * @param list
	 * @param userName 
	 * @return
	 */
	public abstract int importInvoice(List<ImportInvoiceDetail> list, String userName);
	
	/**
	 * 导出收票详情列表
	 * @param qc
	 * @param pageInfo
	 * @param replace 
	 * @return
	 */
	List<ExportInvoiceCollectDetail> exportInvoiceCollectDetailList(QueryConditions qc, PageInfo pageInfo, boolean replace);
	
	/**
	 * 开票流水作废
	 * @param params
	 * @return
	 */
	public int invalidInvoiceApply(Integer applyID,String userName);
	/**
	 * 收票地址列表
	 * @param firmID
	 * @return
	 */
	public abstract List<Firminvoice> getfirmInvoicePlaceList(String firmID);


	/**
	 * 发票申请
	 * @param relationNo
	 * @return
	 */
	public abstract InvoiceApply getInvoiceApplyByID(Integer relationNo);


	/**
	 * 开票申请，数据校验
	 * @param invoiceApplyList
	 * @return
	 */
	public abstract String checkInvoiceApply(List<InvoiceApply4Check> invoiceApplyList);

	/**
	 * 开票，批量申请
	 * @param invoiceApplyList
	 * @param userName 
	 * @return
	 */
	public abstract int addInvoiceApplyList(List<InvoiceApply> invoiceApplyList, String userName);


	/**
	 * 关闭/启用开票
	 * @param deliveryID 
	 * @param applyType 开票类型 
	 * @param enabled 禁用/启用
	 * @param userName
	 * @return
	 */
	public abstract int disOrEnabled(String deliveryID, int applyType,
			int enabled, String userName);


	public abstract InvoiceApply getInvoiceApplyDetail(int invoiceApplyID);


	/**
	 * 开票详情修改(未开票完成能修改)
	 * @param invoiceApply
	 * @param userName
	 * @return
	 */
	public abstract int updateInvoiceApplyDetail(InvoiceApply invoiceApply,
			String userName);


	/**
	 * 导出开票流水数据 总数
	 * @param qc
	 * @return
	 */
	public abstract int getInvoiceApplyList4ExportCount(QueryConditions qc);
	/**
	 * 导出开票流水数据
	 * @param qc
	 * @param pageInfo 
	 * @param replace 
	 * @return
	 */
	public abstract List<InvoiceApply4Export> getInvoiceApplyList4Export(
			QueryConditions qc, PageInfo pageInfo, boolean replace);


	/**
	 * 发票导入Excel校验
	 * @param list
	 * @return
	 */
	public abstract String checkInvoceExcelToList(List<ImportInvoiceDetail> list);


	/**
	 * 发票导入Excel,剔除不正确的数据
	 * @param listTemp
	 * @return
	 */
	public abstract List<ImportInvoiceDetail> getCorrectImportInvoiceList(
			List<ImportInvoiceDetail> listTemp);


	public abstract InvoiceApply4Check getApplyAddress(String firmID);


	public abstract int getExportInvoiceCollectDetailCount(QueryConditions qc,
			PageInfo pageInfo);


	/**
	 * 
	 * @param qc
	 * @param pageInfo
	 * @param invoiceStatus 充值型优惠券列表展示位置：0展示在"开票管理"页面 2 展示在"开票申请流水"页面 
	 * @return
	 */
	public abstract List<InvoiceApply> getCouponInvoiceApplyListByCustomer(
			QueryConditions qc, PageInfo pageInfo, int invoiceStatus);


	public abstract int updateCouponInvoiceApplyListByCustomer(
			int invoiceApplyID, InvoiceApply invoiceApply, String userName, InvoiceApply4Check invoiceApply4Check);


	public abstract int updateIsInvoiceOpen(int invoiceApplyID, String userName,int IsInvoiceOpen);


	public abstract int updateCouponInvoiceApplyListByCustomerWithLotSize(
			List<InvoiceApply> invoiceApplyList, String userName);


	public abstract int getCouponInvoiceApplyListByCustomerCount(
			QueryConditions qc);


	public abstract List<InvoiceApply4Export> getCouponInvoiceApplyList4Export(
			QueryConditions qc, PageInfo pageInfo, boolean replace, int invoiceStatus);

}
