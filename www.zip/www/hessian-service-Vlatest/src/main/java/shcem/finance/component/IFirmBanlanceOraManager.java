/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IFirmBanlanceOraManager
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.component;

import java.util.List;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.FirmBanlanceOraDAO;
import shcem.finance.dao.model.FirmBanlanceListForOra;
import shcem.finance.dao.model.FirmTradeFeeForOra;
import shcem.member.dao.model.FirmDetaiData;

/**
 * IFirmBanlanceOraManager
 * 
 * @author chiyong
 * @version 1.0
 */
public abstract interface IFirmBanlanceOraManager extends Manager {

	public abstract void setFirmBanlanceOraDAO(FirmBanlanceOraDAO paramDAO);

	/**
	 * 交易商当前资金查询
	 */
	public abstract List<FirmBanlanceListForOra> queryFirmBanlance(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 交易商期间手续费合计查询
	 */
	public abstract List<FirmTradeFeeForOra> queryFirmTradeFee(QueryConditions qc, PageInfo pageInfo, String firmName);

	/**
	 * 老专场也建一个交易商
	 * 
	 * @param firmId
	 * @param firmName
	 * @param firmDetaiData 
	 * @return 0： 成功 -1： 失败
	 */
	public abstract int addFirmForOra(String firmId, String firmName, FirmDetaiData firmDetaiData);
	
	/**
	 * 老专场交易商存在check
	 * 
	 * @param firmId
	 * @return 0： 成功 -1： 失败
	 */
	public abstract int checkFirmForOra(String firmId);

	public abstract int queryFirmTradeFeeCount(QueryConditions qc,
			Object object, String firmName);
}
