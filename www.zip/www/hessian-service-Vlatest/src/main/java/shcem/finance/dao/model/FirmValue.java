/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmValue.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月22日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.model;

import java.sql.Timestamp;

import shcem.base.dao.model.BaseObject;

/**
 * @author wlpod
 *
 */
public class FirmValue extends BaseObject implements java.io.Serializable, Cloneable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7552169590606916684L;
	public String firmID;
	public String name;
	public double maxAuditMoney;
	public double maxPerTransMoney;
	public double maxPerSglTransMoney;
	public int maxPerTransCount;
	public int status;
	public Timestamp registerDate;
	public Timestamp logoutDate;
	public String password;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @return the firmID
	 */
	public String getFirmID() {
		return firmID;
	}

	/**
	 * @param firmID
	 *            the firmID to set
	 */
	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the maxAuditMoney
	 */
	public double getMaxAuditMoney() {
		return maxAuditMoney;
	}

	/**
	 * @param maxAuditMoney
	 *            the maxAuditMoney to set
	 */
	public void setMaxAuditMoney(double maxAuditMoney) {
		this.maxAuditMoney = maxAuditMoney;
	}

	/**
	 * @return the maxPerTransMoney
	 */
	public double getMaxPerTransMoney() {
		return maxPerTransMoney;
	}

	/**
	 * @param maxPerTransMoney
	 *            the maxPerTransMoney to set
	 */
	public void setMaxPerTransMoney(double maxPerTransMoney) {
		this.maxPerTransMoney = maxPerTransMoney;
	}

	/**
	 * @return the maxPerSglTransMoney
	 */
	public double getMaxPerSglTransMoney() {
		return maxPerSglTransMoney;
	}

	/**
	 * @param maxPerSglTransMoney
	 *            the maxPerSglTransMoney to set
	 */
	public void setMaxPerSglTransMoney(double maxPerSglTransMoney) {
		this.maxPerSglTransMoney = maxPerSglTransMoney;
	}

	/**
	 * @return the maxPerTransCount
	 */
	public int getMaxPerTransCount() {
		return maxPerTransCount;
	}

	/**
	 * @param maxPerTransCount
	 *            the maxPerTransCount to set
	 */
	public void setMaxPerTransCount(int maxPerTransCount) {
		this.maxPerTransCount = maxPerTransCount;
	}

	/**
	 * @return the status
	 */
	public int getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(int status) {
		this.status = status;
	}

	/**
	 * @return the registerDate
	 */
	public Timestamp getRegisterDate() {
		return registerDate;
	}

	/**
	 * @param registerDate
	 *            the registerDate to set
	 */
	public void setRegisterDate(Timestamp registerDate) {
		this.registerDate = registerDate;
	}

	/**
	 * @return the logoutDate
	 */
	public Timestamp getLogoutDate() {
		return logoutDate;
	}

	/**
	 * @param logoutDate
	 *            the logoutDate to set
	 */
	public void setLogoutDate(Timestamp logoutDate) {
		this.logoutDate = logoutDate;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
}
