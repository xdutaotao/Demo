/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: AbcSignInfoModel
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.service.model;

import java.io.Serializable;
import java.math.BigDecimal;
import org.json.JSONObject;

import shcem.base.service.model.BaseServiceObject;

/**
 * @author caozhiwei
 *
 */
public class AbcSignInfoModel extends BaseServiceObject implements Serializable {

	private static final long serialVersionUID = -1L;

	/** 请求流水号 */
	private long requestID;
	
	/** 商户号 */
	private String merchantID;

	/** 商户名称 */
	private String merchantName;
	
	/** 业务ID */
	private String functionID;
	
	/** 客户名称 */
	private String custName;
	
	/** 账单号 */
	private String orderNo;
	
	/** 账单金额 */
	private BigDecimal payAmount;
	
	/** 处理结果 */
	private int result;

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public String getMerchantID() {
		return merchantID;
	}

	public void setMerchantID(String merchantID) {
		this.merchantID = merchantID;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getFunctionID() {
		return functionID;
	}

	public void setFunctionID(String functionID) {
		this.functionID = functionID;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public BigDecimal getPayAmount() {
		return payAmount;
	}

	public void setPayAmount(BigDecimal payAmount) {
		this.payAmount = payAmount;
	}

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toString()
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toJSONObject()
	 */
	@Override
	public JSONObject toJSONObject() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#hashCode()
	 */
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}
