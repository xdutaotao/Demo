/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IPaymentService.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月15日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.service;

/**
 * @author wlpod
 *
 */
public interface IPaymentService {

	/**
	 * 根据报盘ID支付保证金，手续费
	 * 
	 * @param params
	 * @return
	 */
	public String paymentByLeadsID(String params);

	/**
	 * 修改报盘ID支付保证金，手续费
	 * 
	 * @param params
	 * @return
	 */
	public String modifyLeads(String params);

	/**
	 * 撤盘根据报盘ID退回保证金，手续费
	 * 
	 * @param params
	 * @return
	 */
	public String backByLeadsID(String params);

	/**
	 * 根据询盘ID支付保证金，手续费
	 * 
	 * @param params
	 * @return
	 */
	public String paymentByEnquiryID(String params);

	/**
	 * 撤盘根据询盘ID退回保证金，手续费
	 * 
	 * @param params
	 * @return
	 */
	public String backByEnquiryID(String params);

	/**
	 * 成交时 补退/收，买/卖方的保证金，手续费。
	 * 
	 * 
	 * 
	 * @param params
	 * @return
	 */
	public String paymentByOrderID(String params);

	/**
	 * 根据交收数据，权限校验，资金校验，收买方货款，退买/卖方交易手续费，收买/卖方交收手续费，退买/卖方交易保证金，收买/卖方交易保证金（对应数量比例
	 * ），生成相应流水， 更新交收表的已收买/卖方保证金，已收买/卖方手续费，已收买方货款字段
	 * 
	 * @param params
	 * @return
	 */
	public String paymentForDelivery(String params);

	public String inMoney(String params);

	public String outMoney(String params);

	public String getAssignBankListByFirmID(String params);

	public String getFirmBankBalance(String params);

	public String getCapitalList(String params);

	public String getOneAssignBankByFirmID(String params);
	
	public String getCorrespond(String params);

	public String backAllLeadsAndEnquiry();
	
	/**
	 * 中石化撤盘
	 * @return
	 */
	public String backAllSinopecLeadsAndEnquiry();

	public String getCanBackCount();

	public String payMoney(String params);
	
	public String payForCouPon(String params);
	
	public String addDepositSeller(String params);
	public String addDepositBuyer(String params);

	/**
	 * 农业银行取得签名用信息
	 * 
	 * @param params
	 * @return
	 */
	public String getAbcSignInfoString(String params);
	
	/**
	 * 
	 * 
	 * @param params
	 * @return
	 */
	public String payForCancel(String params);
	
	/**
	 * 撤销询盘
	 * @return
	 */
	public String backQXEnquiry(String params);
	
	/**
	 * 撤销挂盘
	 * @return
	 */
	public String backQXLeads(String params);
}
