/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: BankMgrManagerImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.component.impl;

import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.component.IBankMgrManager;
import shcem.finance.dao.BankMgrDAO;
import shcem.finance.dao.model.FBanks;

/**
 * BankMgrManagerImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class BankMgrManagerImpl extends BaseManager implements IBankMgrManager {
	private BankMgrDAO dao;
	private BankMgrDAO bankMgrDAO_read;
	public void setBankMgrDAO(BankMgrDAO dao) {
		this.dao = dao;
	}

	public void setBankMgrDAO_read(BankMgrDAO bankMgrDAO_read) {
		this.bankMgrDAO_read = bankMgrDAO_read;
	}

	/**
	 * ȡ�������б�
	 * 
	 * @return �����б�
	 */
	public List<FBanks> getBankList(QueryConditions qc, PageInfo pageInfo) {
		this.log.debug("getBankList Component Start");
		return this.bankMgrDAO_read.getBankList(qc, pageInfo);
	}

	@Override
	public FBanks getBank(String bankId) {		
		return this.bankMgrDAO_read.getBank(bankId);
	}

	@Override
	public int updateBank(FBanks bank) {
		return this.dao.updateBank(bank);
	}

	@Override
	public int addBank(FBanks bank) {
		return this.dao.addBank(bank);
	}

	@Override
	public int validBank(String bankId) {
		return this.dao.validBank(bankId);
	}

	@Override
	public int invalidBank(String bankId) {
		return this.dao.invalidBank(bankId);
	}

}
