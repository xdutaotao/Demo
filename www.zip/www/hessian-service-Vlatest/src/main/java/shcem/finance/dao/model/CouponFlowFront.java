package shcem.finance.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * 优惠券流水表(前端用)
 * 
 * @author wangshuai
 *
 */
public class CouponFlowFront extends BaseObject implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4118309054755957309L;
	private Integer fundFlowID;
	private String firmID;
	private String firmName;
    // 优惠券状态（0：充值，1：抵用）
	private Integer status;
    // 成交号
	private String orderCode;
    // 发生额
	private BigDecimal money;
    // 操作时间
	private Date createtime;
    // 交易员
	private String createby;
    // 涨跌类型（0：涨 1：跌）
	private Integer type;
	
	public Integer getFundFlowID() {
		return fundFlowID;
	}

	public void setFundFlowID(Integer fundFlowID) {
		this.fundFlowID = fundFlowID;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}

	public BigDecimal getMoney() {
		return money;
	}

	public void setMoney(BigDecimal money) {
		this.money = money;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getCreateby() {
		return createby;
	}

	public void setCreateby(String createby) {
		this.createby = createby;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
