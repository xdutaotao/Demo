/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IVoucherOraManager
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.component;

import shcem.base.component.Manager;
import shcem.finance.dao.VoucherOraDAO;
import shcem.finance.dao.model.FBanks;
import shcem.finance.dao.model.FVoucherForOra;
import shcem.finance.dao.model.FirmValue;
import shcem.finance.dao.model.PaymentLog;
import shcem.finance.dao.model.PaymentLogDetail;
import shcem.finance.dao.model.VoucherModel;

/**
 * IVoucherOraManager
 * 
 * @author chiyong
 * @version 1.0
 */
public abstract interface IVoucherOraManager extends Manager {
	
	public abstract int createAndAuditVoucher(String summaryNo, String summary, String debitCode, String creditCode,
			String contractno, String inputUser, String money);


	public abstract void setVoucherOraDAO(VoucherOraDAO paramVoucherDAO);

	/**
	 * 快捷生成凭证
	 * 
	 * @param summaryNo
	 *            摘要号
	 * @param summary
	 *            摘要名称
	 * @param debitCode
	 *            借方科目代码
	 * @param creditCode
	 *            贷方科目代码
	 * @param contractno
	 *            合同号
	 * @param inputUser
	 *            数据更新者id
	 * @param money
	 *            金额
	 * @return 凭证号
	 */
	public abstract int fastVoucher(String summaryNo, String summary, String debitCode, String creditCode,
			String contractno, String inputUser, String money);

	/**
	 * 提交审核
	 * 
	 * @param allFlg
	 *            是否全部提交
	 * @param submitCodes
	 *            提交的凭证号
	 */
	public abstract void submitAuditVoucher(boolean allFlg, long[] submitCodes);

	/**
	 * 审核通过/失败
	 * 
	 * @param voucherNo
	 *            凭证号
	 * @param isPass
	 *            审核通过true/失败false
	 * @param loginUserId
	 *            登录者id
	 */
	public abstract int auditVoucher(Long voucherNo, boolean isPass, String loginUserId);

	/**
	 * 取得凭证信息
	 * 
	 * @param voucherNo
	 *            凭证号
	 */
	public abstract FVoucherForOra getVoucherByNo(Long voucherNo);

	/**
	 * 取得凭证模板
	 * 
	 * @param voucherNo
	 *            凭证号
	 */
	public abstract VoucherModel getVoucherModelByCode(String code);

	public abstract void rollback();

	public abstract FBanks getBank(String bankID);

	public abstract FirmValue getFirm(String firmID);
	
	public abstract int insertPaymentLog(PaymentLog paymentLog);
	public abstract int insertPaymentLogDetail(PaymentLogDetail paymentLogDetail);
	public abstract int updatePaymentLogStatus(long id, Integer status);
	public abstract int updatePaymentLogNote(long id, String note);
	public abstract int updatePaymentLogDetailStatus(long id,Integer detailId, Integer status);
	public abstract int updatePaymentLogDetailError(long id,Integer detailId, Integer errorType,String errorMsg);
	public abstract long getPaymentId();
	public abstract int updatePaymentLogEndTime(long id);
	public abstract int updatePaymentLogDetailEndTime(long id,Integer detailId);

}
