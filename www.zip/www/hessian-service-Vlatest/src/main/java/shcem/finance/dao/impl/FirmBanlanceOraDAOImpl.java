/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FirmBanlanceOraDAOImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.finance.dao.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;





import shcem.base.dao.DaoHelperForOra;
import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.finance.dao.FirmBanlanceOraDAO;
import shcem.finance.dao.model.FirmBanlanceListForOra;
import shcem.finance.dao.model.FirmForOra;
import shcem.finance.dao.model.FirmModuleForOra;
import shcem.finance.dao.model.FirmTradeFeeForOra;
import shcem.inform.util.InformOraSysData;
import shcem.util.Common;
import shcem.util.CommonRowMapper;

/**
 * FirmBanlanceOraDAOImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class FirmBanlanceOraDAOImpl extends BaseDAOImpl implements FirmBanlanceOraDAO {

	/**
	 * 交易商当前资金查询
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	@Override
	public List<FirmBanlanceListForOra> queryFirmBanlance(QueryConditions qc, PageInfo pageInfo) {
		List<FirmBanlanceListForOra> list = new ArrayList<FirmBanlanceListForOra>();
		this.log.debug("queryFirmBanlance DAO Start");
		String sql = sqlProperty.getProperty("FirmBanlanceDAO_003");
		list = queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new FirmBanlanceListForOra()));
		return list;
	}

	/**
	 * 交易商期间手续费合计查询
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	@Override
	public List<FirmTradeFeeForOra> queryFirmTradeFee(QueryConditions qc, PageInfo pageInfo, String firmName) {
		List<FirmTradeFeeForOra> list = new ArrayList<FirmTradeFeeForOra>();
		this.log.debug("queryFirmTradeFee DAO Start");
		DaoHelperForOra dbhelper = (DaoHelperForOra) InformOraSysData.getBean("daoHelperForOra");

		String sql = "select ledgerSum.firmid, ledgerSum.TradeFee, nvl(t1.name, ' ') fullname, nvl(t1.address, ' ') address, nvl(t1.bank, ' ') bank, nvl(t1.bankaccount, ' ') bankaccount, nvl(t1.phone, ' ') phone, nvl(t2.taxRegistrationNo, ' ') taxRegistrationNo, nvl(t2.businessScope, ' ') businessScope, nvl(t2.businessContacter, ' ') b_businessContacter from (select firmid, sum(decode(code, 'TradeFee', value, 0)) TradeFee from f_clientledger f where 1 = 1";
		Object[] params = new Object[] {};
		if ((qc != null) && (qc.getFieldsSqlClause() != null)) {
			params = qc.getValueArray();
			sql = sql + " and " + qc.getFieldsSqlClause();
		}
		sql = sql + " group by firmid) ledgerSum, m_firm t1, m_firm_temp t2 where ledgerSum.firmid = t1.firmid(+) and ledgerSum.firmid = t2.firmid(+)";
		if (!Common.isEmpty(firmName)) {
			sql = sql + " and t1.name like '%" + firmName + "%'";
		}
		list = dbhelper.queryBySQL(sql, params, null, pageInfo, new CommonRowMapper(new FirmTradeFeeForOra()));
		return list;
	}

	@Override
	public int verifyRepeat(String firmId) {
		Connection connet = this.getConnection();
		String sql = "select count(firmId) from m_firm where firmId='" + firmId + "'";
		return queryForInt(sql);
	}

	@Override
	public void createFirm(FirmForOra firm) {
		String sql = "insert into m_firm (firmId,name,fullname,bank,bankAccount,address,contactMan,phone,fax,"
				+ "postCode,eMail,createTime,modifyTime,note,status,zoneCode,industryCode,type,EXTENDDATA) "
				+ " values(?,?,?,?,?,?,?,?,?,?,?,";
		sql = sql + "sysdate,sysdate,?,'N',?,?,?,?)";
		Object[] params = { firm.getFirmId(), firm.getName(), firm.getFullname(), firm.getBank(), firm.getBankAccount(),
				firm.getAddress(), firm.getContactMan(), firm.getPhone(), firm.getFax(), firm.getPostCode(),
				firm.getEmail(), firm.getNote(), firm.getZoneCode(), firm.getIndustryCode(),
				Integer.valueOf(firm.getType()), firm.getExtendData() };
		int[] dataTypes = { 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12 };
		updateBySQL(sql, params, dataTypes);
	}

	@Override
	public List getTradeModuleList() {
		String sql = "select * from m_TradeModule where Enabled='Y' and moduleid<>'1' order by to_number(ModuleID)";
		return queryBySQL(sql);
	}

	@Override
	public int addFirmModule(FirmModuleForOra firmModule) {
		String sql = "insert into m_firmmodule values(?,?,?)";
		Object[] params = { firmModule.getModuleId(), firmModule.getFirmId(), firmModule.getEnabled() };
		return updateBySQL(sql, params);
	}

	@Override
	public int addFirm(String firmId) {
		this.log.debug("addFirm()====== start");
		M_FirmAdd func = new M_FirmAdd(getDataSource());
		Map<String, String> inputs = new HashMap<String, String>();
		inputs.put("p_firmid", firmId);
		func.execute(inputs);
		this.log.debug("addFirm()====== end");
		return 0;
	}

	@Override
	public void rollBack() {
		try {
			getConnection().rollback();
		} catch (CannotGetJdbcConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private class M_FirmAdd extends StoredProcedure {
		private static final String SFUNC_NAME = "SP_M_FirmAdd";

		public M_FirmAdd(DataSource ds) {
			super(ds, SFUNC_NAME);

			declareParameter(new SqlParameter("p_firmid", 12));
			compile();
		}

		public Map<String, Object> execute(Map map) {
			return super.execute(map);
		}
	}
	
	@Override
	public int queryFirmTradeFeeCount(QueryConditions qc, String firmName) {
		this.log.info(this.getClass().getName()+" getDeliveryInvoice4ExportCount Start");
		String sql = this.sqlProperty.getProperty("DeliveryInvoiceDAO_001");
		int totalRecords = 0;
		totalRecords = getTotalCount(sql,qc);
		this.log.info(this.getClass().getName()+" getDeliveryInvoice4ExportCount End");
		return totalRecords;
	}
}
