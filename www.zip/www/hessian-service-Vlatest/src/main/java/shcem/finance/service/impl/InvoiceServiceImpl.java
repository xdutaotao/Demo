package shcem.finance.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.constant.ResultCode;
import shcem.finance.ExportModel.InvoiceApply4Export;
import shcem.finance.component.IInvoiceComponentManager;
import shcem.finance.dao.model.ExportInvoiceApply;
import shcem.finance.dao.model.ExportInvoiceCollectDetail;
import shcem.finance.dao.model.FinancialBills;
import shcem.finance.dao.model.InvoiceApply;
import shcem.finance.dao.model.InvoiceApply4Check;
import shcem.finance.dao.model.InvoiceCollectDetail;
import shcem.finance.service.IInvoiceService;
import shcem.finance.service.model.ImportInvoiceDetail;
import shcem.finance.util.FinanceSysData;
import shcem.finance.util.JSONArrayUtil;
import shcem.member.dao.model.Firminvoice;
import shcem.util.Common;
import shcem.util.ExportExcel;
import shcem.trade.dao.model.Order;
import shcem.util.ImportHttpExecl;
import shcem.util.JsonUtil;
import shcem.util.UploadHttpFile;

public class InvoiceServiceImpl extends BaseServiceImpl implements
		IInvoiceService {
	private IInvoiceComponentManager mgr = (IInvoiceComponentManager) FinanceSysData
			.getBean(Constants.BEAN_INVOICE_MGR);

	@Override
	public String getFinancialBillsList(String params) {

		this.log.info(this.getClass().getName() + " getFinancialBillsList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<FinancialBills> list = new ArrayList<FinancialBills>();
		boolean bolRst = false;//
		int financialBillsType = JOParams.optInt("financialBillsType");
		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("temp.DeliveryID", "like", "", "String", "deliveryID"));
		conditionList.add(new Condition("temp.OrderId", "like", "", "String", "orderId"));
		conditionList.add(new Condition("temp.firmName", "like", "", "String", "firmName"));
		conditionList.add(new Condition("temp.applyType", "=", "", "String", "applyType"));
		conditionList.add(new Condition("temp.deliveryStatus", "=", "", "String", "deliveryStatus"));
		conditionList.add(new Condition("temp.financialBillsType", "=", "", "String", "financialBillsType"));
		// conditionList.add(new
		// Condition("temp.isInvoiceOpenAmout","=","","int","isInvoiceOpenAmout"));
		// conditionList.add(new
		// Condition("temp.isInvoiceOpenFee","=","","int","isInvoiceOpenFee"));
		conditionList.add(new Condition("convert(char(10),temp.tradeDate,120)", ">=", "", "string", "startDate"));
		conditionList.add(new Condition("convert(char(10),temp.tradeDate,120)", "<=", "", "string", "endDate"));
		conditionList.add(new Condition("convert(char(10),temp.REC_MODIFYTIME,120)", ">=", "", "string", "applystartDate"));
		conditionList.add(new Condition("convert(char(10),temp.REC_MODIFYTIME,120)", "<=", "", "string", "applyendDate"));

		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		Boolean inVoiceType = queryModel.optBoolean("inVoiceType");
		String isInvoice = queryModel.optString("isInvoice");

		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");

		// 能否开票业务逻辑
		if (StringUtils.isNotBlank(isInvoice) && inVoiceType) { // 能
			qc.addCondition("((temp.isInvoiceOpenFee ="
					+ Constants.INVOICEFE_ENABLE + " and temp.ApplyType="
					+ Constants.COUNTERFEE + ") "
					+ "or (temp.isInvoiceOpenAmout ="
					+ Constants.INVOICEFE_ENABLE + " and temp.ApplyType="
					+ Constants.FEEPAYMENT + ") ) and '1'=", " ", 1);
		} else if (StringUtils.isNotBlank(isInvoice) && !inVoiceType) { // 否
			qc.addCondition("((temp.isInvoiceOpenFee ="
					+ Constants.INVOICEFE_DISABLE + " and temp.ApplyType="
					+ Constants.COUNTERFEE + ") "
					+ "or (temp.isInvoiceOpenAmout ="
					+ Constants.INVOICEFE_DISABLE + " and temp.ApplyType="
					+ Constants.FEEPAYMENT + ") ) and '1'=", " ", 1);
		}

		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			list = this.mgr.getFinancialBillsList(qc, pageInfo, financialBillsType);
			bolRst = true;
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error("开票管理列表数据查询失败" + e.getMessage());
			setResultData("10105", null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("开票管理列表数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getFinancialBillsList() End");
		return rtnData.toString();
	}

	/**
	 * 交易商收票地址
	 */
	@Override
	public String getfirmInvoicePlaceList(String params) {
		this.log.info(this.getClass().getName()
				+ " getFinancialBillsList() Start");
		this.log.debug("JOParams=" + params);
		boolean bolRst = false;
		JSONObject JOParams = new JSONObject(params);
		String firmID = JOParams.getString("firmID");
		List<Firminvoice> list = new ArrayList<Firminvoice>();
		try {
			list = this.mgr.getfirmInvoicePlaceList(firmID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("收票地址查询失败：" + e.getMessage());
			setResultData("10105", null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("收票地址列表数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		return rtnData.toString();
	}

	@Override
	public String openInvoiceApplyForm(String params) {
		this.log.info(this.getClass().getName()
				+ " getFinancialBillsList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		String firmID = JOParams.getString("firmID");
		boolean bolRst = false;
		InvoiceApply invoiceApply = new InvoiceApply();
		try {
			invoiceApply = this.mgr.getInvoiceDetail(firmID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询交易商开票银行信息失败" + e.getMessage());
			setResultData("10105", null);
		}
		if (bolRst) {
			JSONObject retData;
			try {
				retData = JsonUtil.coverModelToJSONObject(invoiceApply);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error("交易商开票银行信息转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		return rtnData.toString();
	}

	/**
	 * 开票申请 新增
	 */
	@Override
	public String addInvoiceApply(String params) {
		this.log.info(this.getClass().getName() + " addInvoiceApply() Start");
		this.log.debug("updateFirmPositionLimitByFirmID Service Start debug");
		JSONObject JOParams = new JSONObject(params);

		JSONArray deliveryIDArrayTemp = JOParams
				.getJSONArray("deliveryIDArray");
		String[] deliveryIDArray = JSONArrayUtil
				.getJsonToStringArray(deliveryIDArrayTemp);

		InvoiceApply invoiceApply = (InvoiceApply) JsonUtil.jsonToBean(
				JOParams, InvoiceApply.class);
		this.log.debug(params);
		this.log.info(this.getClass().getName() + " 申请开票人：" + this.getUserId());
		String userName = this.getUserId() == null ? "system" : (this
				.getUserId().equals("")) ? "system" : this.getUserId();
		this.log.info(this.getClass().getName() + " 申请开票人：" + userName);
		String returnCode;
		try {
			returnCode = this.mgr.addInvoiceApply(deliveryIDArray,
					invoiceApply, userName);
			if (returnCode.equals("0") || returnCode.equals("1")) {
				this.log.businesslog("申请开票成功", Constants.OPE_MODE_FINANCE,
						Constants.OPE_SUCCESS);
				setResultData("00000", null);
			} else if (returnCode.equals("-1")) {
				setResultData("40001", null);
			} else {
				setResultData("40014", null, returnCode);
			}
		} catch (Exception e) {
			this.log.error("申请开票失败" + e.getMessage());
			setResultData("40001", null, e.getMessage());
		}
		this.log.info(this.getClass().getName() + " addInvoiceApply() End");
		return rtnData.toString();
	}

	/**
	 * 开票申请列表
	 */
	@Override
	public String getInvoiceApplyList(String params) {
		this.log.info(this.getClass().getName()
				+ " getInvoiceApplyList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<InvoiceApply> list = new ArrayList<InvoiceApply>();
		boolean bolRst = false;//
		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("temp.orderId", "like", "", "String",
				"orderId"));
		conditionList.add(new Condition("temp.InvoiceTitle", "like", "",
				"String", "invoiceTitle")); // 交易商名称
		conditionList.add(new Condition("temp.InvoiceNo", "like", "", "String",
				"invoiceNo")); // 发票号
		conditionList.add(new Condition("temp.TrackingNo", "like", "",
				"String", "trackingNo")); // 快递号
		conditionList.add(new Condition("temp.InvoiceType", "=", "", "String",
				"invoiceType")); // 发票类型
		conditionList.add(new Condition("temp.ApplyStatus", "=", "", "String",
				"applyStatus")); // 发票类型
		conditionList.add(new Condition("temp.ApplyType", "=", "String", "",
				"applyType")); // 发票类型
		conditionList.add(new Condition("temp.deliveryID", "like", "",
				"String", "deliveryID")); // 交收单号
		conditionList.add(new Condition(
				"convert(char(10),temp.ApplicantTime,120)", ">=", "", "String",
				"applicantTimeStart")); // 申请时间
		conditionList.add(new Condition(
				"convert(char(10),temp.ApplicantTime,120)", "<=", "", "String",
				"applicantTimeEnd"));
		conditionList.add(new Condition("convert(char(10),temp.tradeDate,120)",
				">=", "", "string", "startDate"));
		conditionList.add(new Condition("convert(char(10),temp.tradeDate,120)",
				"<=", "", "string", "endDate"));

		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel,
				conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			list = this.mgr.getInvoiceApplyList(qc, pageInfo);
			bolRst = true;
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error("开票申请列表数据查询失败" + e.getMessage());
			setResultData("30000", null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("开票申请列表数据转换失败：" + e.getMessage());
				setResultData("30000", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getInvoiceApplyList() End");
		return rtnData.toString();
	}

	@Override
	public String cancelInvoiceApply(String params) {
		this.log.info(this.getClass().getName()
				+ " getFinancialBillsList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		int invoiceApplyID = JOParams.getInt("invoiceApplyID");
		int returnCode;
		String userName = this.getUserId() == null ? "system" : (this
				.getUserId().equals("")) ? "system" : this.getUserId();
		try {
			returnCode = this.mgr.cancelInvoiceApply(invoiceApplyID, userName);
			if (returnCode >= 0) {
				this.log.businesslog("撤销发票成功", Constants.OPE_MODE_FINANCE,
						Constants.OPE_SUCCESS);
				setResultData("00000", null);
			} else {
				setResultData("40012", null);
			}
		} catch (Exception e) {
			this.log.error("撤销发票失败" + e.getMessage());
			setResultData("40012", null);
		}
		return rtnData.toString();
	}

	/**
	 * 校验经税系统生成的Excel
	 */
	@Override
	public String checkImportInvoiceExcel(String params) {
		this.log.info(this.getClass().getName()
				+ " checkImportInvoiceExcel() Start");
		JSONObject JOParams = new JSONObject(params);
		String url = JOParams.getString("url");
		String returnMessage = "";
		try {
			List<ImportInvoiceDetail> list = readInvoceExcelToList(url);
			if (list == null || (list != null && list.size() == 0)) {
				setResultData("40025", null);
				return rtnData.toString();
			}
			/* 校验数据 */
			returnMessage = this.mgr.checkInvoceExcelToList(list);
			setResultData("00000", returnMessage);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()
					+ " checkImportInvoiceExcel:校验经税系统生成的Excel出错 "
					+ e.getMessage());
			setResultData("30000", null);
		}
		this.log.info(this.getClass().getName()
				+ " checkImportInvoiceExcel() End");
		return rtnData.toString();
	}

	/**
	 * 发票导入
	 */
	public String importInvoiceExcel(String params) {
		this.log.info(this.getClass().getName() + " importInvoiceExcel() Start");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);

		String url = JOParams.getString("url");
		JSONArray retData = null;
		JSONObject jsonObj = new JSONObject();
		String userName = this.getUserId() == null ? "system" : (this
				.getUserId().equals("")) ? "system" : this.getUserId();
		int returnCode;
		try {
			List<ImportInvoiceDetail> listTemp = readInvoceExcelToList(url);
			if (listTemp == null) {
				setResultData("40021", null);
				return rtnData.toString();
			}
			/* 校验数据 */
			// returnCode = this.checkInvoceExcelToList(listTemp);
			// if(returnCode < 0){
			// setResultData(""+-returnCode+"", null);
			// this.log.info(this.getClass().getName() +
			// " importInvoiceExcel() End");
			// return rtnData.toString();
			// }
			List<ImportInvoiceDetail> list = this.mgr
					.getCorrectImportInvoiceList(listTemp);
			if (list == null) {
				setResultData("40023", null);
				return rtnData.toString();
			}
			returnCode = this.mgr.importInvoice(list, userName);
			if (returnCode >= 0) {
				this.log.businesslog("发票导入成功", Constants.OPE_MODE_FINANCE,
						Constants.OPE_SUCCESS);
				setResultData("00000", null);
			} else {
				setResultData("40015", null);
			}
			retData = JsonUtil.coverModelToJSONArray(list);
			jsonObj.put("total", list.size());
			jsonObj.put("result", retData);
			setResultData(ResultCode.CODE00000.getValue(), jsonObj);
		} catch (Exception e) {
			this.log.error("发票导入失败：" + e.getMessage());
			setResultData("40015", null);
		}
		this.log.info(this.getClass().getName() + " importInvoiceExcel() Start");
		return rtnData.toString();
	}

	/**
	 * 发票导入模板，校验
	 * 
	 * @param list
	 * @return
	 */
	private int checkInvoceExcelToList(List<ImportInvoiceDetail> list) {
		this.log.info(this.getClass().getName()
				+ "checkInvoceExcelToList Service Start");
		int returnCode = 0;
		if (list == null || (list != null && list.size() == 0)) {
			returnCode = -40016;
		} else {
			for (int i = 0; i < list.size(); i++) {
				/* 销售单号、备注(交收单号)匹配校验 */
				InvoiceApply invoiceApply = this.mgr.getInvoiceApplyByID(list
						.get(i).getRelationNo());
				if (invoiceApply == null) {
					returnCode = -40017;
					break;
				} else {
					if (!invoiceApply.getDeliveryID().equals(
							list.get(i).getRemark())) {
						returnCode = -40018;
						break;
					}
				}

				/* 价税合计 校验 */
				if (!(list.get(i).getTotalMoney()
						.compareTo(invoiceApply.getApplyMoney()) == 0)) {
					returnCode = -40019;
					break;
				}

				/* 是否已经导入校验:1：已申请，待财务处理 5：已审批 ，10：已拒绝，15：开票完成 */
				if (invoiceApply.getApplyStatus() == 15) {
					returnCode = -40020;
					break;
				}
			}
		}
		this.log.info(this.getClass().getName()
				+ "checkInvoceExcelToList Service End");
		return returnCode;
	}

	/**
	 * 读取发票模版
	 * 
	 * @param filePath
	 * @return
	 */
	private List<ImportInvoiceDetail> readInvoceExcelToList(String filePath) {
		this.log.debug("readInvoceExcelToList() Start");
		List<ImportInvoiceDetail> rtnLst = new ArrayList<ImportInvoiceDetail>();
		ImportInvoiceDetail detail = null;
		ImportHttpExecl ihe = new ImportHttpExecl();
		int sheetNo = 0;

		// 读取Excel2007
		List<List<String>> list = ihe.read(filePath, sheetNo, true);

		String err = ihe.getErrorInfo();
		if (null != err && !err.isEmpty()) {
			// Excel2007失败，再次尝试读取Excel2003
			ihe = new ImportHttpExecl();
			list = ihe.read(filePath, sheetNo, false);
		}
		err = null;
		err = ihe.getErrorInfo();
		if (null != err && !err.isEmpty()) {
			this.log.error(err);
			setResultData(ResultCode.CODE10103.getValue(), null, err);
			return null;
		}

		if (list == null || list.isEmpty()) {
			this.log.error("发票模板读取失败");
			setResultData(ResultCode.CODE10104.getValue(), null, "发票模板读取失败");
			return null;
		}

		for (int i = 1; i < list.size(); i++) {
			detail = new ImportInvoiceDetail();
			List<String> cellList = list.get(i);
			java.util.Date date = null;
			try {
				String invoiceNos = cellList.get(0);// 发票号
				if (null == invoiceNos || "".equals(invoiceNos)) {
					break;
				}
				/** 发票号码 字符串数组 */
				detail.setInvoiceNo(invoiceNos.split(","));
				/** 销售单据号 */
				detail.setRelationNo(Integer.parseInt(cellList.get(1)));
				/** 单位名称 */
				detail.setCompanyName(cellList.get(2));
				/** 产品名称 */
				detail.setProductName(cellList.get(3));
				/** 规格型号 */
				detail.setBrandName(cellList.get(4));
				/** 计量单位 */
				detail.setUnit(cellList.get(5));
				/** 产品数量 */
				detail.setQuantity(new BigDecimal(cellList.get(6).trim()
						.equals("") ? "0"
						: cellList.get(6).trim().equals("0") ? "0" : cellList
								.get(6)));
				/** 含税单价 */
				detail.setPrice(new BigDecimal(cellList.get(7).trim()
						.equals("") ? "0"
						: cellList.get(7).trim().equals("0") ? "0" : cellList
								.get(7)));
				/** 价税合计 */
				detail.setTotalMoney(new BigDecimal(cellList.get(8)));
				/** 税率 */
				detail.setTaxRate(new BigDecimal(cellList.get(9)));
				/** 备注 */
				detail.setRemark(cellList.get(10));
				/***/
				String invoiceTypeString = cellList.get(11);
				/** 发票类型，1增值税发票,5普通发票 */
				if (invoiceTypeString.equals("增票")) {
					detail.setInvoiceType(1);
				} else {
					detail.setInvoiceType(5);
				}

				/** 快递单号 */
				detail.setTrackingNo(cellList.get(12));

				rtnLst.add(detail);
			} catch (Exception e) {
				this.log.error("发票模板实体类设定失败");
				e.printStackTrace();
				rtnLst = null;
				break;
			}
		}
		this.log.debug("readInvoceExcelToList() End");
		return rtnLst;
	}

	@Override
	public String exportInvoiceApply(String params) {
		this.log.info(this.getClass().getName()
				+ " getInvoiceApplyList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		int invoiceType = queryModel.isNull("invoiceType") == true ? 1 : 2;// 导出类型
																			// 1:货款&手续费
																			// 2:充值型优惠券
		List<InvoiceApply4Export> list = new ArrayList<InvoiceApply4Export>();
		List<ExportInvoiceApply> exportlist = new ArrayList<ExportInvoiceApply>();
		boolean bolRst = false;//
		int totalCount = 0;
		List<Condition> conditionList = new ArrayList<Condition>();
		if (invoiceType == 1) {
			conditionList.add(new Condition("temp.orderId", "like", "",
					"String", "orderId"));
			conditionList.add(new Condition("temp.InvoiceTitle", "like", "",
					"String", "invoiceTitle")); // 交易商名称
			conditionList.add(new Condition("temp.InvoiceNo", "like", "",
					"String", "invoiceNo")); // 发票号
			conditionList.add(new Condition("temp.TrackingNo", "like", "",
					"String", "trackingNo")); // 快递号
			conditionList.add(new Condition("temp.InvoiceType", "=", "",
					"String", "invoiceType")); // 发票类型
			conditionList.add(new Condition("temp.ApplyType", "=", "",
					"String", "applyType")); // 发票类型
			conditionList.add(new Condition("temp.ApplyStatus", "=", "",
					"String", "applyStatus")); // 开票状态
			conditionList.add(new Condition("temp.deliveryID", "like", "",
					"String", "deliveryID")); // 交收单号
			conditionList.add(new Condition(
					"convert(char(10),temp.ApplicantTime,120)", ">=", "",
					"String", "applicantTimeStart")); // 申请时间
			conditionList.add(new Condition(
					"convert(char(10),temp.ApplicantTime,120)", "<=", "",
					"String", "applicantTimeEnd"));
			conditionList.add(new Condition(
					"convert(char(10),temp.tradeDate,120)", ">=", "", "string",
					"startDate"));
			conditionList.add(new Condition(
					"convert(char(10),temp.tradeDate,120)", "<=", "", "string",
					"endDate"));
		} else if (invoiceType == 2) {
			conditionList.add(new Condition("temp.couponNumber", "like", "",
					"String", "couponNumber")); // 优惠券号
			conditionList.add(new Condition("temp.FirmName", "like", "",
					"String", "firmName")); // 交易商名称
			conditionList.add(new Condition("temp.ApplyStatus", "=", "",
					"String", "applyStatus")); // 开票状态
			conditionList.add(new Condition("temp.IsInvoiceOpen", "=", "",
					"String", "isInvoiceOpen")); // 是否开启开票 0否 1是
			conditionList.add(new Condition(
					"convert(char(10),temp.ApplicantTime,120)", ">=", "",
					"String", "applicantTimeStart")); // 申请时间
			conditionList.add(new Condition(
					"convert(char(10),temp.ApplicantTime,120)", "<=", "",
					"String", "applicantTimeEnd"));

			conditionList.add(new Condition("temp.InvoiceNo", "like", "",
					"String", "invoiceNo")); // 发票号
			conditionList.add(new Condition("temp.TrackingNo", "like", "",
					"String", "trackingNo")); // 快递号
		} else {
			conditionList.add(new Condition("temp.orderId", "like", "",
					"String", "orderId"));
			conditionList.add(new Condition("temp.InvoiceTitle", "like", "",
					"String", "invoiceTitle")); // 交易商名称
			conditionList.add(new Condition("temp.InvoiceNo", "like", "",
					"String", "invoiceNo")); // 发票号
			conditionList.add(new Condition("temp.TrackingNo", "like", "",
					"String", "trackingNo")); // 快递号
			conditionList.add(new Condition("temp.InvoiceType", "=", "",
					"String", "invoiceType")); // 发票类型
			conditionList.add(new Condition("temp.ApplyType", "=", "",
					"String", "applyType")); // 发票类型
			conditionList.add(new Condition("temp.ApplyStatus", "=", "",
					"String", "applyStatus")); // 开票状态
			conditionList.add(new Condition("temp.deliveryID", "like", "",
					"String", "deliveryID")); // 交收单号
			conditionList.add(new Condition(
					"convert(char(10),temp.ApplicantTime,120)", ">=", "",
					"String", "applicantTimeStart")); // 申请时间
			conditionList.add(new Condition(
					"convert(char(10),temp.ApplicantTime,120)", "<=", "",
					"String", "applicantTimeEnd"));
			conditionList.add(new Condition(
					"convert(char(10),temp.tradeDate,120)", ">=", "", "string",
					"startDate"));
			conditionList.add(new Condition(
					"convert(char(10),temp.tradeDate,120)", "<=", "", "string",
					"endDate"));
		}

		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel,
				conditionList, "");
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		this.log.debug("qc=" + qc.toString());
		try {
			if (invoiceType == 1) {
				totalCount = this.mgr.getInvoiceApplyList4ExportCount(qc);
				if (totalCount > Constants.EXPORT_MAX_COUNT) {
					list = this.mgr.getInvoiceApplyList4Export(qc, pageInfo,
							true);
				} else {
					list = this.mgr.getInvoiceApplyList4Export(qc, pageInfo,
							false);
				}
				bolRst = true;
			} else if (invoiceType == 2) {
				int invoiceStatus = 2;// 充值型优惠券列表展示位置：0展示在"开票管理"页面 2
										// 展示在"开票申请流水"页面
				totalCount = this.mgr
						.getCouponInvoiceApplyListByCustomerCount(qc);
				if (totalCount > Constants.EXPORT_MAX_COUNT) {
					list = this.mgr.getCouponInvoiceApplyList4Export(qc,
							pageInfo, true, invoiceStatus);
				} else {
					list = this.mgr.getCouponInvoiceApplyList4Export(qc,
							pageInfo, false, invoiceStatus);
				}
				bolRst = true;
			} else {// 拓展，以后可能增加导出类型
				totalCount = this.mgr.getInvoiceApplyList4ExportCount(qc);
				if (totalCount > Constants.EXPORT_MAX_COUNT) {
					list = this.mgr.getInvoiceApplyList4Export(qc, pageInfo,
							true);
				} else {
					list = this.mgr.getInvoiceApplyList4Export(qc, pageInfo,
							false);
				}
				bolRst = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error("导出开票申请流水失败" + e.getMessage());
			setResultData("40013", null);
		}
		if (bolRst) {
			if (list != null && list.size() > 0) {
				JSONObject jsonObj = new JSONObject();
				this.exportInvoiceApplyList(jsonObj, list, exportlist,
						totalCount);
			} else {
				setResultData("10123", null);
			}
		}
		this.log.info(this.getClass().getName() + " getInvoiceApplyList() End");
		return rtnData.toString();
	}

	private void exportInvoiceApplyList(JSONObject jsonObj,
			List<InvoiceApply4Export> list,
			List<ExportInvoiceApply> exportlist, int totalCount) {
		if (list != null && list.size() > 0) {
			ExportExcel<ExportInvoiceApply> ex = new ExportExcel<ExportInvoiceApply>();
			for (int i = 0; i < list.size(); i++) {
				/**
				 * 单据编号 购货单位 商品名称 规格型号 商品单位 商品数量 税率 商品含税单价 商品含税金额 备注 开票要求 税号
				 * 地址电话 银行账号 快递收件人 快递收件人地址 快递收件人电话
				 */

				/** 单据编号 */
				Integer id = list.get(i).getId();
				/** 购货单位 */
				String invoiceTitle = list.get(i).getInvoiceTitle() == null ? ""
						: list.get(i).getInvoiceTitle().trim().equals("") ? ""
								: list.get(i).getInvoiceTitle();
				/** 商品名称 */
				String categoryName = list.get(i).getCategoryName() == null ? ""
						: list.get(i).getCategoryName().trim().equals("") ? ""
								: list.get(i).getCategoryName();
				/** 规格型号 */
				String brandName = list.get(i).getBrandName() == null ? ""
						: list.get(i).getBrandName().trim().equals("") ? ""
								: list.get(i).getBrandName();
				/** 产地名称 */
				String sourcePlaceName = list.get(i).getSourcePlaceName() == null ? ""
						: list.get(i).getSourcePlaceName().trim().equals("") ? ""
								: list.get(i).getSourcePlaceName();
				/** 商品单位 */
				String goodUnit = list.get(i).getGoodUnit() == null ? "" : list
						.get(i).getGoodUnit();
				/** 商品数量 */
				BigDecimal applyQuantity = list.get(i).getApplyQuantity();
				/** 税率 */
				BigDecimal taxRate = list.get(i).getTaxRate();
				/** 商品含税单价 */
				BigDecimal applyPrice = list.get(i).getApplyPrice();
				/** 商品含税金额 */
				BigDecimal applyMoney = list.get(i).getApplyMoney();
				/** 交收单号 */
				String deliveryID = list.get(i).getDeliveryID();
				/** 成交单号 */
				String orderID = list.get(i).getOrderID();
				/** 线下合同号 */
				String XSSFNumber = list.get(i).getXSSFNumber();
				/** 开票要求 */
				String remark = list.get(i).getRemark() == null ? "" : list
						.get(i).getRemark().trim().equals("") ? "" : list
						.get(i).getRemark();
				/** 税号 */
				String taxNo = list.get(i).getTaxNo();
				/** 开票地址 */
				String invoiceAddress = list.get(i).getInvoiceAddress();
				/** 开票电话 */
				String invoiceTel = list.get(i).getInvoiceTel();
				/** 开票银行 */
				String bankName = list.get(i).getBankName();
				Integer bankId = list.get(i).getBankID();
				if (bankId == 0 || bankName.startsWith("其他")) {// 银行名是 其他
					bankName = "";
				}
				/** 开票银行支行名称 */
				String branchName = list.get(i).getBranchName() == null ? ""
						: list.get(i).getBranchName().trim().equals("") ? ""
								: list.get(i).getBranchName();
				/** 开票银行帐号 */
				String bankAccount = list.get(i).getBankAccount();
				/** 收票人 */
				String collectInvoicePeople = list.get(i)
						.getCollectInvoicePeople();
				/** 收票地址 */
				String collectInvoiceAddress = list.get(i)
						.getCollectInvoiceAddress();
				/** 收票电话 */
				String collectTel = list.get(i).getCollectTel();

				ExportInvoiceApply exObject = new ExportInvoiceApply();
				exObject.setId(id);
				exObject.setInvoiceTitle(invoiceTitle);
				exObject.setCategoryName(categoryName);
				exObject.setBrandName(brandName);
				if (!sourcePlaceName.equals(""))
					exObject.setBrandName(brandName + "/" + sourcePlaceName);// 添加产地

				exObject.setGoodUnit(goodUnit);
				exObject.setApplyQuantity(applyQuantity
						.compareTo(new BigDecimal(0)) == 0 ? "" : applyQuantity
						.toString());// 数量
				exObject.setTaxRate(taxRate);
				exObject.setApplyPrice(applyPrice.compareTo(new BigDecimal(0)) == 0 ? ""
						: applyPrice.toString());// 单价
				exObject.setApplyMoney(applyMoney);
				if(Common.isEmpty(XSSFNumber)){
					exObject.setDeliveryID(deliveryID);// 备注	
				}else{
					exObject.setDeliveryID(deliveryID+"-"+XSSFNumber);// 备注
				}
				exObject.setOrderID(orderID);//成交单号
				exObject.setRemark(remark);// 开票要求
				exObject.setTaxNo(taxNo);
				exObject.setInvoiceAddressTel(invoiceAddress + invoiceTel);
				exObject.setBankNameBranchAccount(bankName + branchName
						+ bankAccount);
				exObject.setCollectInvoicePeople(collectInvoicePeople);
				exObject.setCollectInvoiceAddress(collectInvoiceAddress);
				exObject.setCollectTel(collectTel);
				exportlist.add(exObject);
			}
			String[] excelHeaders = { "单据编号", "购货单位", "商品名称", "规格型号/产地",
					"商品单位", "商品数量", "税率", "商品含税单价", "商品含税金额", "备注","成交单号", "税号",
					"地址电话", "银行账号", "快递收件人", "快递收件人地址", "快递收件人电话", "开票申请备注", };
			// 文件流
			ByteArrayOutputStream out = null;
			ByteArrayInputStream in = null;
			try {
				String time = Common.df6.format(new Date());
				String excelName = "开票申请记录" + time.toString() + ".xls";
				out = new ByteArrayOutputStream();
				ex.exportExcel("开票申请", excelHeaders, exportlist, out, null);
				in = new ByteArrayInputStream(out.toByteArray());
				String uploadUrl = Common.getUploadUrl(this.getMode());
				String httpUrl = UploadHttpFile.uploadFile(in, excelName,
						uploadUrl);
				out.close();
				in.close();
				if (null != httpUrl) {
					this.log.debug("httpUrl:" + httpUrl);
					jsonObj.put("httpUrl", httpUrl);
					jsonObj.put("fileName", excelName);
					setResultData(ResultCode.CODE00000.getValue(), jsonObj);
					if (totalCount > Constants.EXPORT_MAX_COUNT)
						setResultData("10122", jsonObj);
					;
				} else {
					setResultData(ResultCode.CODE40013.getValue(), null);
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				// 清理资源
				try {
					out.close();
				} catch (IOException e1) {
					e1.printStackTrace();
					setResultData(ResultCode.CODE40013.getValue(), null);
				}
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
					setResultData(ResultCode.CODE40013.getValue(), null);
				}
			}
		} else {
			setResultData("10101", null);
		}

	}

	@Override
	public String addInvoiceCollectDetail(String params) {
		this.log.info(this.getClass().getName()
				+ " addInvoiceCollectDetail() Start");
		this.log.debug("addInvoiceCollectDetail Service Start debug");
		JSONObject JOParams = new JSONObject(params);

		InvoiceCollectDetail invoiceCollectDetail = (InvoiceCollectDetail) JsonUtil
				.jsonToBean(JOParams, InvoiceCollectDetail.class);
		this.log.debug(params);
		String userName = this.getUserId() == null ? "system" : (this
				.getUserId().equals("")) ? "system" : this.getUserId();
		int returnCode;
		try {
			invoiceCollectDetail.setInvoiceTitle("上海化交");
			invoiceCollectDetail.setInvoiceType(1);// 发票类型，1增值税发票,5普通发票
			invoiceCollectDetail.setREC_CREATEBY(userName);
			invoiceCollectDetail.setREC_MODIFYBY(userName);
			returnCode = this.mgr.addInvoiceCollectDetail(invoiceCollectDetail);
			if (returnCode == 0) {
				this.log.businesslog("收票成功", Constants.OPE_MODE_FINANCE,
						Constants.OPE_SUCCESS);
				setResultData("00000", null);
			} else {
				setResultData("40003", null);
			}
		} catch (Exception e) {
			this.log.error("收票失败" + e.getMessage());
			setResultData("40003", null, e.getMessage());
		}
		this.log.info(this.getClass().getName()
				+ " addInvoiceCollectDetail() End");
		return rtnData.toString();
	}

	@Override
	public String updateInvoiceCollectDetailByID(String params) {
		this.log.info(this.getClass().getName()
				+ " updateInvoiceCollectDetailByID() Start");
		this.log.debug("updateInvoiceCollectDetailByID Service Start debug");
		JSONObject JOParams = new JSONObject(params);

		InvoiceCollectDetail invoiceCollectDetail = (InvoiceCollectDetail) JsonUtil
				.jsonToBean(JOParams, InvoiceCollectDetail.class);
		this.log.debug(params);
		String userName = this.getUserId() == null ? "system" : (this
				.getUserId().equals("")) ? "system" : this.getUserId();
		int returnCode;
		if (invoiceCollectDetail.getId() == null) {
			setResultData("40005", "收票记录ID不能为空!");
			return rtnData.toString();
		}
		try {
			invoiceCollectDetail.setInvoiceTitle("上海化交");
			invoiceCollectDetail.setInvoiceType(1);// 发票类型，1增值税发票,5普通发票
			invoiceCollectDetail.setREC_MODIFYBY(userName);
			returnCode = this.mgr
					.updateInvoiceCollectDetailByID(invoiceCollectDetail);
			if (returnCode == 0) {
				this.log.businesslog("更新收票记录成功", Constants.OPE_MODE_FINANCE,
						Constants.OPE_SUCCESS);
				setResultData("00000", null);
			} else {
				setResultData("40005", null);
			}
		} catch (Exception e) {
			this.log.error("更新收票失败" + e.getMessage());
			setResultData("40005", null, e.getMessage());
		}
		this.log.info(this.getClass().getName()
				+ " updateInvoiceCollectDetailByID() End");
		return rtnData.toString();
	}

	@Override
	public String updateInvoiceCollectDetailRelOfStatus(String params) {
		this.log.info(this.getClass().getName()
				+ " updateInvoiceCollectDetailByID() Start");
		this.log.debug("updateInvoiceCollectDetailByID Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		String userName = this.getUserId() == null ? "system" : (this
				.getUserId().equals("")) ? "system" : this.getUserId();
		Integer id = JOParams.optInt("invoiceCollectDetailRelID");
		Integer status = JOParams.optInt("status");
		if (id == null) {
			setResultData("40004", null, "收票记录ID不能为空！");
			return rtnData.toString();
		}
		int returnCode;
		try {
			returnCode = this.mgr.updateInvoiceCollectDetailRelOfStatus(id,
					status, userName);
			if (returnCode == 0) {
				this.log.businesslog("作废收票记录成功", Constants.OPE_MODE_FINANCE,
						Constants.OPE_SUCCESS);
				setResultData("00000", null);
			} else {
				setResultData("40004", null);
			}
		} catch (Exception e) {
			this.log.error("作废收票记录失败" + e.getMessage());
			setResultData("40004", null, e.getMessage());
		}
		this.log.info(this.getClass().getName()
				+ " updateInvoiceCollectDetailByID() End");
		return rtnData.toString();
	}

	@Override
	public String getInvoiceCollectDetailByID(String params) {
		this.log.info(this.getClass().getName()
				+ " getInvoiceCollectDetailByID() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		InvoiceCollectDetail invoiceCollectDetail = null;
		boolean bolRst = false;//
		Integer id = JOParams.optInt("id");
		if (id == null) {
			setResultData("10105", null, "收票记录ID不能为空！");
			return rtnData.toString();
		}
		try {
			invoiceCollectDetail = this.mgr.getInvoiceCollectDetailByID(id);
			bolRst = true;
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error("查询收票记录失败" + e.getMessage());
			setResultData("10105", null);
		}
		if (bolRst) {
			JSONObject jsonObj = new JSONObject();
			try {
				jsonObj = JsonUtil.coverModelToJSONObject(invoiceCollectDetail);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("收票记录数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName()
				+ " getInvoiceCollectDetailByID() End");
		return rtnData.toString();
	}

	@Override
	public String selectInvoiceCollectDetailListByRelationID(String params) {
		this.log.info(this.getClass().getName()
				+ " selectInvoiceCollectDetailListByRelationID() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<InvoiceCollectDetail> list = new ArrayList<InvoiceCollectDetail>();
		boolean bolRst = false;//
		String relationID = JOParams.optString("relationID");
		if (relationID == null) {
			setResultData("10105", null, "订单ID不能为空！");
			return rtnData.toString();
		}
		try {
			list = this.mgr
					.selectInvoiceCollectDetailListByRelationID(relationID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询收票列表数据失败" + e.getMessage());
			setResultData("10105", null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("收票列表数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName()
				+ " selectInvoiceCollectDetailListByRelationID() End");
		return rtnData.toString();
	}

	@Override
	public String updateOrderOfInvoiceCollectStatus(String params) {
		this.log.info(this.getClass().getName()
				+ " updateOrderOfInvoiceCollectStatus() Start");
		this.log.debug("updateOrderOfInvoiceCollectStatus Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		String userName = this.getUserId() == null ? "system" : (this
				.getUserId().equals("")) ? "system" : this.getUserId();
		String orderId = JOParams.optString("orderId");
		Integer invoiceCollectStatus = JOParams.optInt("invoiceCollectStatus");
		if (orderId == null) {
			setResultData("10105", null, "订单ID不能为空！");
			return rtnData.toString();
		}
		int returnCode;
		try {
			returnCode = this.mgr.updateOrderOfInvoiceCollectStatus(orderId,
					invoiceCollectStatus, userName);
			if (returnCode == 0) {
				this.log.businesslog("全部收票记录成功", Constants.OPE_MODE_FINANCE,
						Constants.OPE_SUCCESS);
				setResultData("00000", null);
			} else {
				setResultData("40003", null);
			}
		} catch (Exception e) {
			this.log.error("全部收票记录失败" + e.getMessage());
			setResultData("40003", null, e.getMessage());
		}
		this.log.info(this.getClass().getName()
				+ " updateOrderOfInvoiceCollectStatus() End");
		return rtnData.toString();
	}

	@Override
	public String selectInvoiceOrderList(String params) {
		this.log.info(this.getClass().getName() + " selectOrderList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<Order> list = new ArrayList<Order>();
		boolean bolRst = false;//
		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("temp.sellFirmName", "like", "", "String", "sellFirmName"));
		conditionList.add(new Condition("temp.goodName", "like", "", "String", "goodName"));
		conditionList.add(new Condition("temp.Price", "like", "", "String", "price"));
		conditionList.add(new Condition("temp.TotalQuantity", "like", "", "String", "totalQuantity"));
		conditionList.add(new Condition("temp.surplusQuantity", "=", "", "String", "surplusQuantity"));
		conditionList.add(new Condition("temp.OrderId", "like", "", "String", "orderId"));
		conditionList.add(new Condition("temp.invoiceNoStr", "like", "", "String", "invoiceNo"));
		conditionList.add(new Condition("temp.InvoiceCollectStatus", "=", "", "String", "invoiceCollectStatus"));
		conditionList.add(new Condition("temp.TradeStatus", "=", "", "String", "tradeStatus"));
		conditionList.add(new Condition("convert(char(10),temp.TradeDate,120)", ">=", "", "String", "tradeDateStart"));
		conditionList.add(new Condition("convert(char(10),temp.TradeDate,120)", "<=", "", "String", "tradeDateEnd"));
		conditionList.add(new Condition("convert(char(10),temp.invoiceCollectDate,120)", ">=", "", "String", "invoiceCollectDateStart"));
		conditionList.add(new Condition("convert(char(10),temp.invoiceCollectDate,120)", "<=", "", "String", "invoiceCollectDateEnd"));
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			list = this.mgr.selectOrderList(qc, pageInfo);
			bolRst = true;
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error("收票列表数据查询失败" + e.getMessage());
			setResultData("10105", null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("收票申请列表数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " selectOrderList() End");
		return rtnData.toString();
	}

	@Override
	public String exportInvoiceCollectDetailList(String params) {
		this.log.info(this.getClass().getName()
				+ " exportInvoiceCollectDetailList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<ExportInvoiceCollectDetail> list = new ArrayList<ExportInvoiceCollectDetail>();
		boolean bolRst = false;//
		int totoalCount = 0;
		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("tmp.sellFirmName", "like", "",
				"String", "sellFirmName"));
		conditionList.add(new Condition("tmp.goodName", "like", "", "String",
				"goodName"));
		conditionList.add(new Condition("tmp.Price", "like", "", "String",
				"price"));
		conditionList.add(new Condition("tmp.TotalQuantity", "like", "",
				"String", "totalQuantity"));
		conditionList.add(new Condition("tmp.surplusQuantity", "=", "",
				"String", "surplusQuantity"));
		conditionList.add(new Condition("tmp.OrderId", "like", "", "String",
				"orderId"));
		conditionList.add(new Condition("tmp.invoiceNo", "like", "", "String",
				"invoiceNo"));
		conditionList.add(new Condition("tmp.InvoiceCollectStatus", "=", "",
				"String", "invoiceCollectStatus"));
		conditionList.add(new Condition("tmp.TradeStatus", "=", "", "String",
				"tradeStatus"));
		conditionList.add(new Condition("convert(char(10),tmp.TradeDate,120)",
				">=", "", "String", "tradeDateStart"));
		conditionList.add(new Condition("convert(char(10),tmp.TradeDate,120)",
				"<=", "", "String", "tradeDateEnd"));
		conditionList.add(new Condition(
				"convert(char(10),tmp.invoiceCollectDate,120)", ">=", "",
				"String", "invoiceCollectDateStart"));
		conditionList.add(new Condition(
				"convert(char(10),tmp.invoiceCollectDate,120)", "<=", "",
				"String", "invoiceCollectDateEnd"));
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel,
				conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			totoalCount = this.mgr.getExportInvoiceCollectDetailCount(qc,
					pageInfo);
			if (totoalCount > Constants.EXPORT_MAX_COUNT) {
				list = this.mgr.exportInvoiceCollectDetailList(qc, pageInfo,
						true);
			} else {
				list = this.mgr.exportInvoiceCollectDetailList(qc, pageInfo,
						false);
			}
			bolRst = true;
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error("收票列表数据查询失败" + e.getMessage());
			setResultData("10105", null);
		}
		if (bolRst) {
			JSONObject jsonObj = new JSONObject();
			exportInvoiceCollectDetailList(jsonObj, list, totoalCount);
		}
		this.log.info(this.getClass().getName()
				+ " exportInvoiceCollectDetailList() End");
		return rtnData.toString();
	}

	private void exportInvoiceCollectDetailList(JSONObject jsonObj,
			List<ExportInvoiceCollectDetail> exportlist, int totoalCount) {
		if (exportlist != null && exportlist.size() > 0) {
			ExportExcel<ExportInvoiceCollectDetail> ex = new ExportExcel<ExportInvoiceCollectDetail>();
			String[] excelHeaders = { "成交单号", "交易场", "卖方交易商", "品类牌号", "成交单价",
					"成交数量（吨）", "签收数量（吨）", "货款金额", "实发金额", "成交时间", "成交状态",
					"收票时间", "应收票金额", "收票金额(含税)", "收票吨数", "发票号", "备注" };
			// 文件流
			ByteArrayOutputStream out = null;
			ByteArrayInputStream in = null;
			try {
				String time = Common.df6.format(new Date());
				String excelName = "收票记录" + time.toString() + ".xls";
				out = new ByteArrayOutputStream();
				ex.exportExcel("收票记录", excelHeaders, exportlist, out, null);
				in = new ByteArrayInputStream(out.toByteArray());
				String uploadUrl = Common.getUploadUrl(this.getMode());
				String httpUrl = UploadHttpFile.uploadFile(in, excelName,
						uploadUrl);
				out.close();
				in.close();
				if (null != httpUrl) {
					this.log.debug("httpUrl:" + httpUrl);
					jsonObj.put("httpUrl", httpUrl);
					jsonObj.put("fileName", excelName);
					setResultData(ResultCode.CODE00000.getValue(), jsonObj);
					if (totoalCount > Constants.EXPORT_MAX_COUNT)
						setResultData("10122", jsonObj);
					;

				} else {
					setResultData(ResultCode.CODE40013.getValue(), null);
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				// 清理资源
				try {
					out.close();
				} catch (IOException e1) {
					e1.printStackTrace();
					setResultData(ResultCode.CODE40013.getValue(), null);
				}
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
					setResultData(ResultCode.CODE40013.getValue(), null);
				}
			}
		} else {
			setResultData("10101", null);
		}
	}

	@Override
	public String invalidInvoiceApply(String params) {
		this.log.info(this.getClass().getName()
				+ " invalidInvoiceDetail() Start");
		this.log.debug("invalidInvoiceDetail Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		String userName = this.getUserId() == null ? "system" : (this
				.getUserId().equals("")) ? "system" : this.getUserId();
		Integer invoiceApplyId = JOParams.optInt("invoiceApplyId");
		if (invoiceApplyId == null) {
			setResultData("10105", null, "开票申请流水ID不能为空！");
			return rtnData.toString();
		}
		int returnCode;
		try {
			returnCode = this.mgr.invalidInvoiceApply(invoiceApplyId, userName);
			if (returnCode == 0) {
				this.log.businesslog("废弃申请流水成功", Constants.OPE_MODE_FINANCE,
						Constants.OPE_SUCCESS);
				setResultData("00000", null);
			} else {
				setResultData("40004", null);
			}
		} catch (Exception e) {
			this.log.error("废弃申请流水失败" + e.getMessage());
			setResultData("40004", null, e.getMessage());
		}
		this.log.info(this.getClass().getName() + " invalidInvoiceDetail() End");
		return rtnData.toString();
	}

	/**
	 * 开篇申请，数据校验
	 * 
	 * @param params
	 * @return
	 */
	@Override
	public String checkInvoiceApply(String params) {
		this.log.info(this.getClass().getName() + " checkInvoiceApply Start");
		JSONObject JOParams = new JSONObject(params);
		List<InvoiceApply4Check> invoiceApplyList = new ArrayList<InvoiceApply4Check>();
		JSONArray invoiceApplyListTemp = JOParams
				.getJSONArray("invoiceApplyList");
		if (invoiceApplyListTemp.length() > 0) {
			for (int i = 0; i < invoiceApplyListTemp.length(); i++) {
				invoiceApplyList.add((InvoiceApply4Check) JsonUtil.jsonToBean(
						(JSONObject) invoiceApplyListTemp.get(i),
						InvoiceApply4Check.class));
			}
		} else {
			setResultData("80002", null);
			return rtnData.toString();
		}
		String returnMessage = null;
		try {
			returnMessage = this.mgr.checkInvoiceApply(invoiceApplyList);
			setResultData("00000", returnMessage);
		} catch (Exception e) {
			this.log.error(this.getClass().getName() + " checkInvoiceApply: "
					+ e.getMessage());
			setResultData("30000", null);
		}
		this.log.info(this.getClass().getName() + " checkInvoiceApply End");
		return rtnData.toString();
	}

	/**
	 * 开票，批量申请
	 */
	@Override
	public String addInvoiceApplyList(String params) {
		this.log.info(this.getClass().getName() + " addInvoiceApplyList Start");
		JSONObject JOParams = new JSONObject(params);
		List<InvoiceApply> invoiceApplyList = new ArrayList<InvoiceApply>();
		JSONArray invoiceApplyListTemp = JOParams
				.getJSONArray("invoiceApplyList");
		if (invoiceApplyListTemp.length() > 0) {
			for (int i = 0; i < invoiceApplyListTemp.length(); i++) {
				InvoiceApply4Check invoiceApply4Check = (InvoiceApply4Check) JsonUtil
						.jsonToBean((JSONObject) invoiceApplyListTemp.get(i),
								InvoiceApply4Check.class);
				InvoiceApply invoiceApply = (InvoiceApply) JsonUtil.jsonToBean(
						(JSONObject) invoiceApplyListTemp.get(i),
						InvoiceApply.class);
				invoiceApply.setInvoiceApply4Check(invoiceApply4Check);
				invoiceApplyList.add(invoiceApply);
			}
		} else {
			setResultData("80002", null);
			return rtnData.toString();
		}
		String userName = this.getUserId() == null ? "system" : (this
				.getUserId().equals("")) ? "system" : this.getUserId();
		int returnCode;
		try {
			returnCode = this.mgr.addInvoiceApplyList(invoiceApplyList,
					userName);
			if (returnCode >= 0) {
				this.log.businesslog("申请开票成功", Constants.OPE_MODE_FINANCE,
						Constants.OPE_SUCCESS);
				setResultData("00000", null);
			} else if (returnCode == -1) {
				setResultData("40001", null);
			} else {
				setResultData("40014", null);
			}
		} catch (Exception e) {
			this.log.error(this.getClass().getName() + " addInvoiceApplyList: "
					+ e.getMessage());
			setResultData("40001", null);
		}

		this.log.info(this.getClass().getName() + " addInvoiceApplyList End");
		return rtnData.toString();
	}

	/**
	 * 关闭/启用开票
	 */
	@Override
	public String disOrEnabled(String params) {
		this.log.info(this.getClass().getName() + "  disOrEnabled Start");
		JSONObject JOParams = new JSONObject(params);
		String deliveryID = JOParams.getString("deliveryID");
		int applyType = JOParams.getInt("applyType");
		int enabled = JOParams.getInt("enabled");
		String userName = this.getUserId() == null ? "system" : (this
				.getUserId().equals("")) ? "system" : this.getUserId();
		int returnCode;
		try {
			returnCode = this.mgr.disOrEnabled(deliveryID, applyType, enabled,
					userName);
			if (returnCode > 0) {
				setResultData("00000", null);
			} else if (returnCode == 0) {
				setResultData("80003", null);
				return rtnData.toString();
			} else {
				setResultData("30000", null);
			}
		} catch (Exception e) {
			this.log.error(this.getClass().getName() + " disOrEnabled： "
					+ e.getMessage());
			setResultData("30000", null);
		}
		this.log.info(this.getClass().getName() + "  disOrEnabled End");
		return rtnData.toString();
	}

	/**
	 * 开票详情
	 */
	@Override
	public String getInvoiceApplyDetail(String params) {
		this.log.info(this.getClass().getName()
				+ "  getInvoiceApplyDetail Start");
		JSONObject JOParams = new JSONObject(params);
		int invoiceApplyID = JOParams.getInt("invoiceApplyID");
		boolean bolRst = false;
		InvoiceApply invoiceApply = new InvoiceApply();
		try {
			invoiceApply = this.mgr.getInvoiceApplyDetail(invoiceApplyID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error(this.getClass().getName()
					+ " getInvoiceApplyDetail: " + e.getMessage());
			setResultData("24015", null);
		}
		if (bolRst) {
			JSONObject jsonObj = new JSONObject();
			try {
				jsonObj = JsonUtil.coverModelToJSONObject(invoiceApply);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("开票申请数据转换失败：" + e.getMessage());
				setResultData("24015", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + "  getInvoiceApplyDetail End");
		return rtnData.toString();
	}

	/**
	 * 开票详情修改(未开票完成能修改)
	 */
	@Override
	public String updateInvoiceApplyDetail(String params) {
		this.log.info(this.getClass().getName()
				+ "  updateInvoiceApplyDetail Start");
		JSONObject JOParams = new JSONObject(params);
		InvoiceApply invoiceApply = (InvoiceApply) JsonUtil.jsonToBean(
				JOParams, InvoiceApply.class);
		this.log.debug(params);
		String userName = this.getUserId() == null ? "system" : (this
				.getUserId().equals("")) ? "system" : this.getUserId();
		int returnCode;
		try {
			returnCode = this.mgr.updateInvoiceApplyDetail(invoiceApply,
					userName);
			if (returnCode >= 0) {
				this.log.businesslog("开票流水详情修改(未开票完成能修改)",
						Constants.OPE_MODE_FINANCE, Constants.OPE_SUCCESS);
				setResultData("00000", null);
			} else if (returnCode == -80003) {
				this.log.businesslog("开票流水详情修改(未开票完成能修改)",
						Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
				setResultData("80003", null);
			} else {
				this.log.businesslog("开票流水详情修改(未开票完成能修改)",
						Constants.OPE_MODE_FINANCE, Constants.OPE_FAIL);
				setResultData("30000", null);
			}
		} catch (Exception e) {
			this.log.error(this.getClass().getName()
					+ " updateInvoiceApplyDetail: " + e.getMessage());
			setResultData("30000", null);
		}
		this.log.info(this.getClass().getName()
				+ "  updateInvoiceApplyDetail End");
		return rtnData.toString();
	}

	/**
	 * 开票申请的一些地址信息
	 */
	@Override
	public String getApplyAddress(String params) {
		this.log.info(this.getClass().getName() + " getApplyAddress Start");
		JSONObject JOParams = new JSONObject(params);
		String firmID = JOParams.getString("firmID");
		InvoiceApply4Check data = new InvoiceApply4Check();
		try {
			data = this.mgr.getApplyAddress(firmID);
		} catch (Exception e) {
			// TODO: handle exception
		}
		this.log.info(this.getClass().getName() + " getApplyAddress End");
		return rtnData.toString();
	}

	/**
	 * 增值性优惠券开票申请列表(前台客户申请)
	 */
	@Override
	public String getCouponInvoiceApplyListByCustomer(String params) {
		this.log.info(this.getClass().getName()
				+ " getCouponInvoiceApplyListByCustomer() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<InvoiceApply> list = new ArrayList<InvoiceApply>();

		boolean bolRst = false;//
		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("temp.couponNumber", "like", "",
				"String", "couponNumber")); // 优惠券号
		conditionList.add(new Condition("temp.FirmName", "like", "", "String",
				"firmName")); // 交易商名称
		conditionList.add(new Condition("temp.ApplyStatus", "=", "", "String",
				"applyStatus")); // 开票状态
		conditionList.add(new Condition("temp.isFullDetailed", "=", "",
				"String", "isFullDetailed")); // 能否开票 1能 2否
		conditionList.add(new Condition("temp.IsInvoiceOpen", "=", "",
				"String", "isInvoiceOpen")); // 是否开启开票 0否 1是
		conditionList.add(new Condition(
				"convert(char(10),temp.ApplicantTime,120)", ">=", "", "String",
				"applicantTimeStart")); // 申请时间
		conditionList.add(new Condition(
				"convert(char(10),temp.ApplicantTime,120)", "<=", "", "String",
				"applicantTimeEnd"));

		conditionList.add(new Condition("temp.InvoiceNo", "like", "", "String",
				"invoiceNo")); // 发票号
		conditionList.add(new Condition("temp.TrackingNo", "like", "",
				"String", "trackingNo")); // 快递号

		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		int invoiceStatus = queryModel.optInt("invoiceStatus");// 充值型优惠券列表展示位置：0展示在"开票管理"页面
																// 2
																// 展示在"开票申请流水"页面
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel,
				conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			list = this.mgr.getCouponInvoiceApplyListByCustomer(qc, pageInfo,
					invoiceStatus);
			bolRst = true;
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error("增值性优惠券开票申请列表查询失败" + e.getMessage());
			setResultData("30000", null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("增值性优惠券开票申请列表转换失败：" + e.getMessage());
				setResultData("30000", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName()
				+ " getCouponInvoiceApplyListByCustomer() End");
		return rtnData.toString();
	}

	@Override
	public String updateCouponInvoiceApplyListByCustomer(String params) {
		this.log.info(this.getClass().getName()
				+ " updateCouponInvoiceApplyListByCustomer() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		int invoiceApplyID = JOParams.getInt("invoiceApplyID");

		InvoiceApply invoiceApply = (InvoiceApply) JsonUtil.jsonToBean(
				JOParams, InvoiceApply.class);
		InvoiceApply4Check invoiceApply4Check = (InvoiceApply4Check) JsonUtil
				.jsonToBean(JOParams, InvoiceApply4Check.class);
		this.log.debug(params);
		this.log.info(this.getClass().getName() + " 申请开票人：" + this.getUserId());
		String userName = this.getUserId() == null ? "system" : (this
				.getUserId().equals("")) ? "system" : this.getUserId();
		this.log.info(this.getClass().getName() + " 申请开票人：" + userName);
		int returnCode;
		try {
			returnCode = this.mgr.updateCouponInvoiceApplyListByCustomer(
					invoiceApplyID, invoiceApply, userName, invoiceApply4Check);
			if (returnCode > 0) {
				setResultData("00000", null);
			} else if (returnCode == -40024) {
				setResultData("40024", null);
			} else {
				setResultData("30000", null);
			}
		} catch (Exception e) {
			this.log.error("增值性优惠券开票后台修改失败：" + e.getMessage());
			setResultData("30000", null);
		}
		this.log.info(this.getClass().getName()
				+ " updateCouponInvoiceApplyListByCustomer() End");
		return rtnData.toString();
	}

	@Override
	public String openInvoice(String params) {
		this.log.info(this.getClass().getName() + " openInvoice() Start");
		JSONObject JOParams = new JSONObject(params);
		int invoiceApplyID = JOParams.getInt("invoiceApplyID");
		String userName = this.getUserId() == null ? "system" : (this
				.getUserId().equals("")) ? "system" : this.getUserId();
		int returnCode;
		try {
			returnCode = this.mgr.updateIsInvoiceOpen(invoiceApplyID, userName,
					1);
			if (returnCode >= 0) {
				setResultData("00000", null);
			} else {
				setResultData("30000", null);
			}
		} catch (Exception e) {
			this.log.error(this.getClass().getName()
					+ " openInvoice 开启 审核前台客户申请的开票信息(置标) 失败：" + e.getMessage());
			setResultData("30000", null);
		}
		this.log.info(this.getClass().getName() + " openInvoice() Start");
		return rtnData.toString();
	}

	@Override
	public String CloseInvoice(String params) {
		this.log.info(this.getClass().getName() + " CloseInvoice() Start");
		JSONObject JOParams = new JSONObject(params);
		int invoiceApplyID = JOParams.getInt("invoiceApplyID");
		String userName = this.getUserId() == null ? "system" : (this
				.getUserId().equals("")) ? "system" : this.getUserId();
		int returnCode;
		try {
			returnCode = this.mgr.updateIsInvoiceOpen(invoiceApplyID, userName,
					0);
			if (returnCode >= 0) {
				setResultData("00000", null);
			} else {
				setResultData("30000", null);
			}
		} catch (Exception e) {
			this.log.error(this.getClass().getName()
					+ " openInvoice 关闭 审核前台客户申请的开票信息(置标) 失败：" + e.getMessage());
			setResultData("30000", null);
		}
		this.log.info(this.getClass().getName() + " CloseInvoice() Start");
		return rtnData.toString();
	}

	/**
	 * 审核前台客户申请的开票信息
	 */
	@Override
	public String updateCouponInvoiceApplyListByCustomerWithLotSize(
			String params) {
		this.log.info(this.getClass().getName()
				+ " updateCouponInvoiceApplyListByCustomerWithLotSize() Start");
		List<InvoiceApply> invoiceApplyList = new ArrayList<InvoiceApply>();
		JSONObject JOParams = new JSONObject(params);
		JSONArray invoiceApplyListTemp = JOParams
				.getJSONArray("invoiceApplyList");
		if (invoiceApplyListTemp.length() > 0) {
			for (int i = 0; i < invoiceApplyListTemp.length(); i++) {
				InvoiceApply4Check invoiceApply4Check = (InvoiceApply4Check) JsonUtil
						.jsonToBean((JSONObject) invoiceApplyListTemp.get(i),
								InvoiceApply4Check.class);
				InvoiceApply invoiceApply = (InvoiceApply) JsonUtil.jsonToBean(
						(JSONObject) invoiceApplyListTemp.get(i),
						InvoiceApply.class);
				invoiceApply.setInvoiceApply4Check(invoiceApply4Check);
				invoiceApplyList.add(invoiceApply);
			}
		} else {
			setResultData("80002", null);
			return rtnData.toString();
		}
		String userName = this.getUserId() == null ? "system" : (this
				.getUserId().equals("")) ? "system" : this.getUserId();
		int returnCode;
		try {
			returnCode = this.mgr
					.updateCouponInvoiceApplyListByCustomerWithLotSize(
							invoiceApplyList, userName);
			if (returnCode >= 0) {
				setResultData("00000", null);
			} else {
				setResultData("30000", null);
			}
		} catch (Exception e) {
			this.log.error("增值性优惠券开票后台修改失败：" + e.getMessage());
			setResultData("30000", null);
		}

		this.log.info(this.getClass().getName()
				+ " updateCouponInvoiceApplyListByCustomerWithLotSize() End");
		return rtnData.toString();
	}

	public static void main(String[] args) {
		System.err.println("git-提交测试.....dddd....addd...");
	}
}
