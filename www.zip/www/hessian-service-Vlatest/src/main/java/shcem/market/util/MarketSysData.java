package shcem.market.util;

import java.io.Serializable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import shcem.finance.util.FinanceSysData;

public class MarketSysData implements Serializable {
	private static final long serialVersionUID = 1L;
	private static Log logger = LogFactory.getLog(FinanceSysData.class);
	private static final String beanConfig = "classpath:marketbeans.xml";
	private static ApplicationContext factory;

	public static void init() {
		factory = new ClassPathXmlApplicationContext(beanConfig);
	}

	public static Object getBean(String beanId) {
		Object obj = null;

		if (factory == null) {
			synchronized (FinanceSysData.class) {
				if (factory == null) {
					init();
				}
			}
		}
		if (factory != null)
			obj = factory.getBean(beanId);
		return obj;
	}

	public static BeanFactory getBeanFactory() {
		if (factory == null) {
			synchronized (FinanceSysData.class) {
				if (factory == null) {
					init();
				}
			}
		}
		return factory;
	}
}
