package shcem.market.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * 竞猜中奖结果
 * @author wangshuai
 *
 */
public class QuizWinningResult extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5189194658170915956L;
	// 默认为 0：正常，1：失效
	private Integer dISABLED;
	// 竞猜id
	private Integer quizHistoryID;
	// 中奖等级
	private Integer moneyTerm;
	// 中奖金额
	private BigDecimal bonus;
	// 竞猜日期
	private Date quizDate;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Integer getdISABLED() {
		return dISABLED;
	}

	public void setdISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public Integer getQuizHistoryID() {
		return quizHistoryID;
	}

	public void setQuizHistoryID(Integer quizHistoryID) {
		this.quizHistoryID = quizHistoryID;
	}

	public Integer getMoneyTerm() {
		return moneyTerm;
	}

	public void setMoneyTerm(Integer moneyTerm) {
		this.moneyTerm = moneyTerm;
	}

	public BigDecimal getBonus() {
		return bonus;
	}

	public void setBonus(BigDecimal bonus) {
		this.bonus = bonus;
	}

	public Date getQuizDate() {
		return quizDate;
	}

	public void setQuizDate(Date quizDate) {
		this.quizDate = quizDate;
	}

}
