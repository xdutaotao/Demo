package shcem.market.dao.model;

import java.math.BigDecimal;
import java.util.Date;

public class ExportUnNewCouponTrans{

	/**
	 * 优惠券号码
	 */
	private String couponNumber;

	/**
	 * 兑换码
	 */
	private String exchangeCode;

	/**
	 * 活动名称
	 */
	private String activityName;
	
//	/**
//	 * 优惠券名称
//	 */
//	private String couponName;
	
	/**
	 * 优惠券类型 (1:抵扣型 2:充值型)
	 */
	private String couponTypeName; 
	
	/**
	 * 优惠劵面额（元）
	 */
	private BigDecimal amount;

//	/**
//	 * 抵扣金额
//	 */
//	private BigDecimal deductibleAmount;
//	
//	/**
//	 * 领取时间
//	 */
//	private Date receiveDate;
//
//	/**
//	 * 使用时间
//	 */
//	private Date useDate; 
//
//	/**
//	 * 交易商编码
//	 */
//	private String firmId;
//	
//	/**
//	 * 交易商
//	 */
//	private String firmName;
//
//	/**
//	 * 交易员
//	 */
//	private String traderName;
//	
//	/**
//	 * 用户名
//	 */
//	private String userName;
//	
//	/**
//	 * 使用订单号
//	 */
//	private String orderId;

	/**
	 * 状态(0：未领取 1:已发放(已领取) 5：已使用 10：已失效)
	 */
	private String statusName;

	public String getCouponNumber() {
		return couponNumber;
	}

	public void setCouponNumber(String couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getExchangeCode() {
		return exchangeCode;
	}

	public void setExchangeCode(String exchangeCode) {
		this.exchangeCode = exchangeCode;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

//	public String getCouponName() {
//		return couponName;
//	}
//
//	public void setCouponName(String couponName) {
//		this.couponName = couponName;
//	}

	public String getCouponTypeName() {
		return couponTypeName;
	}

	public void setCouponTypeName(String couponTypeName) {
		this.couponTypeName = couponTypeName;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

//	public BigDecimal getDeductibleAmount() {
//		return deductibleAmount;
//	}
//
//	public void setDeductibleAmount(BigDecimal deductibleAmount) {
//		this.deductibleAmount = deductibleAmount;
//	}
//
//	public Date getReceiveDate() {
//		return receiveDate;
//	}
//
//	public void setReceiveDate(Date receiveDate) {
//		this.receiveDate = receiveDate;
//	}
//
//	public Date getUseDate() {
//		return useDate;
//	}
//
//	public void setUseDate(Date useDate) {
//		this.useDate = useDate;
//	}
//	
//	public String getFirmId() {
//		return firmId;
//	}
//
//	public void setFirmId(String firmId) {
//		this.firmId = firmId;
//	}
//
//	public String getFirmName() {
//		return firmName;
//	}
//
//	public void setFirmName(String firmName) {
//		this.firmName = firmName;
//	}
//
//	public String getTraderName() {
//		return traderName;
//	}
//
//	public void setTraderName(String traderName) {
//		this.traderName = traderName;
//	}
//
//	public String getUserName() {
//		return userName;
//	}
//
//	public void setUserName(String userName) {
//		this.userName = userName;
//	}
//
//	public String getOrderId() {
//		return orderId;
//	}
//
//	public void setOrderId(String orderId) {
//		this.orderId = orderId;
//	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}


