package shcem.market.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

public class QuizHistoryAndQuizActivity extends BaseObject implements
		Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2857420133721019696L;
	// 主键ID
	private Integer quizHistoryId;
	/** 竞猜日期 */
	private Date quizDate;
	// 竞猜价格
	private BigDecimal quizPrice;
	/** 品类 1.PP 2.PE */
	private Integer category;
	/** 合约名称 */
	private String contractName;
	/** 合约价格 */
	private BigDecimal contractPrice;
	/** 浮动值 */
	private BigDecimal floatValue;
	/** 竞猜记录状态:0：未开奖 1：未中奖  2：已中奖 */
	private Integer quizHistoryStatus;
	/**竞猜活动状态： 1：未审核  5：审核通过 */
	private Integer quizActivityStatus;
	/** 竞猜活动合约价格表id */
	private Integer quizActivityID;
	/** 交易员编号 */
	private Integer traderID;

	public Integer getQuizHistoryId() {
		return quizHistoryId;
	}

	public void setQuizHistoryId(Integer quizHistoryId) {
		this.quizHistoryId = quizHistoryId;
	}

	public Date getQuizDate() {
		return quizDate;
	}

	public void setQuizDate(Date quizDate) {
		this.quizDate = quizDate;
	}

	public BigDecimal getQuizPrice() {
		return quizPrice;
	}

	public void setQuizPrice(BigDecimal quizPrice) {
		this.quizPrice = quizPrice;
	}

	public Integer getCategory() {
		return category;
	}

	public void setCategory(Integer category) {
		this.category = category;
	}

	public String getContractName() {
		return contractName;
	}

	public void setContractName(String contractName) {
		this.contractName = contractName;
	}

	public BigDecimal getContractPrice() {
		return contractPrice;
	}

	public void setContractPrice(BigDecimal contractPrice) {
		this.contractPrice = contractPrice;
	}

	public BigDecimal getFloatValue() {
		return floatValue;
	}

	public void setFloatValue(BigDecimal floatValue) {
		this.floatValue = floatValue;
	}

	public Integer getQuizHistoryStatus() {
		return quizHistoryStatus;
	}

	public void setQuizHistoryStatus(Integer quizHistoryStatus) {
		this.quizHistoryStatus = quizHistoryStatus;
	}

	public Integer getQuizActivityStatus() {
		return quizActivityStatus;
	}

	public void setQuizActivityStatus(Integer quizActivityStatus) {
		this.quizActivityStatus = quizActivityStatus;
	}

	public Integer getQuizActivityID() {
		return quizActivityID;
	}

	public void setQuizActivityID(Integer quizActivityID) {
		this.quizActivityID = quizActivityID;
	}

	public Integer getTraderID() {
		return traderID;
	}

	public void setTraderID(Integer traderID) {
		this.traderID = traderID;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
