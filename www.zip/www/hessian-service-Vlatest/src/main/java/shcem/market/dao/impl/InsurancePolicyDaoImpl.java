package shcem.market.dao.impl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.jdbc.CannotGetJdbcConnectionException;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.market.dao.IInsurancePolicyDao;
import shcem.market.dao.model.InsuranceBack;
import shcem.market.dao.model.InsurancePolicy;
import shcem.market.dao.model.InsurancePolicyDetail;
import shcem.market.dao.model.InsurancePolicyPrice;
import shcem.market.dao.model.InsurancePolicyType;
import shcem.market.dao.model.QueryOrderPolicy;
import shcem.market.service.model.AuditInsuranceBackVo;
import shcem.market.service.model.InsurancePolicyPriceVo;
import shcem.trade.dao.model.DelDistributionDetail;
import shcem.trade.dao.model.DeliveryFreightFee;
import shcem.util.CommonRowMapper;
import shcem.util.DateUtil;

/**
 * 保单相关DAO实现
 * @author wangshuai
 *
 */
public class InsurancePolicyDaoImpl extends BaseDAOImpl implements IInsurancePolicyDao {

	private String className = InsurancePolicyDaoImpl.class.getName()+" ";
	
	@Override
	public int insertInsurancePolicyPrice(InsurancePolicyPrice insurancePolicyPrice) {
		this.log.debug(className+"insertInsurancePolicyPrice DAO Start");
		String sql = sqlProperty.getProperty("InsurancePolicyDao_001");
		Object[] params = {
				0,
				insurancePolicyPrice.getREC_CREATEBY(),
				insurancePolicyPrice.getREC_MODIFYBY(),
				DateUtil.convert(insurancePolicyPrice.getPolicyDate(), "yyyy-MM-dd"),
				insurancePolicyPrice.getCategoryName(),
				insurancePolicyPrice.getCategoryType(),
				insurancePolicyPrice.getSettlementPrice() == null ? 0 : insurancePolicyPrice.getSettlementPrice(),
				insurancePolicyPrice.getAverageDeltaPrice() == null ? 0 : insurancePolicyPrice.getAverageDeltaPrice(),
				1
		};
		int count = this.updateBySQL(sql, params);
		this.log.debug(className+"insertInsurancePolicyPrice DAO End");
		return count;
	}

	@Override
	public List<InsurancePolicyPriceVo> getInsurancePolicyPriceList(QueryConditions qc, PageInfo pageInfo) {
		this.log.debug(className+"getInsurancePolicyPriceList DAO Start");
		String sql = sqlProperty.getProperty("InsurancePolicyDao_002");
		List<InsurancePolicyPriceVo> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new InsurancePolicyPriceVo()));
		this.log.debug(className+"getInsurancePolicyPriceList DAO End");
		return list; 
	}

	@Override
	public InsurancePolicyPriceVo getInsurancePolicyPrice(String policyDateStr) {
		this.log.debug(className+"getInsurancePolicyPrice DAO Start");
		String sql = sqlProperty.getProperty("InsurancePolicyDao_003");
		Object[] params = {policyDateStr};
		InsurancePolicyPriceVo vo = (InsurancePolicyPriceVo) this.queryForObject(sql, params, new CommonRowMapper(new InsurancePolicyPriceVo()));
		this.log.debug(className+"getInsurancePolicyPrice DAO End");
		return vo;
	}
	
	@Override
	public int updateInsurancePolicyPrice(InsurancePolicyPrice insurancePolicyPrice) {
		this.log.debug(className+"updateInsurancePolicyPrice DAO Start");
		String sql = sqlProperty.getProperty("InsurancePolicyDao_004");
		Object[] params = {
				insurancePolicyPrice.getREC_MODIFYBY(),
				insurancePolicyPrice.getSettlementPrice(),
				insurancePolicyPrice.getAverageDeltaPrice()==null ? 0 : insurancePolicyPrice.getAverageDeltaPrice(),
				insurancePolicyPrice.getStatus(),
				DateUtil.convert(insurancePolicyPrice.getPolicyDate(), "yyyy-MM-dd"),
				insurancePolicyPrice.getCategoryType()
		};
		int count = this.updateBySQL(sql, params);
		this.log.debug(className+"updateInsurancePolicyPrice DAO End");
		return count;
	}
	
	@Override
	public Date getPreviousInsurancePolicyPriceOfPolicyDate(Date policyDate) {
		this.log.debug(className+"getPreviousInsurancePolicyPriceOfPolicyDate DAO Start");
		String sql = sqlProperty.getProperty("InsurancePolicyDao_005");
		Date policyDateDB = null;
		Object[] params = {
				policyDate
		};
		InsurancePolicyPriceVo vo = (InsurancePolicyPriceVo) this.queryForObject(sql, params, new CommonRowMapper(new InsurancePolicyPriceVo()));
		if (vo != null){
			policyDateDB = vo.getPolicyDate();
		}
		this.log.debug(className+"getPreviousInsurancePolicyPriceOfPolicyDate DAO End");
		return policyDateDB;
	}

	@Override
	public List<InsurancePolicyPrice> getInsurancePolicyPriceListByPolicyDate(Date policyDate) {
		this.log.debug(className+"getInsurancePolicyPriceListByPolicyDate DAO Start");
		String sql = sqlProperty.getProperty("InsurancePolicyDao_006");
		Object[] params = {
				DateUtil.convert(policyDate, "yyyy-MM-dd")
		};
		List<InsurancePolicyPrice> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new InsurancePolicyPrice()));
		this.log.debug(className+"getInsurancePolicyPriceListByPolicyDate DAO End");
		return list;
	}
	
	
	@Override
	public List<QueryOrderPolicy> getOrderPolicyList(QueryConditions qc, PageInfo pageInfo) {
		this.log.debug(className+"getOrderPolicyList DAO Start");
		String sql = sqlProperty.getProperty("InsurancePolicyDao_00101");
		List<QueryOrderPolicy> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new QueryOrderPolicy()));
		this.log.debug(className+"getOrderPolicyList DAO End");
		return list;
	}

	/**
	 * @param modifyBy 更新人
	 * @param policyDateStr 保单日期(yyyy-MM-dd)
	 * @param firmType 0：卖方交易商 1:买方交易商 
	 * @param categoryType  保单品类:1:PE 2:PP
	 * @param newStatus 1：未处理 5：未中保 10：已中保
	 * @param oldStatus 1：未处理 5：未中保 10：已中保
	 * @return
	 */
	@Override
	public int updateInsurancePolicy(String modifyBy, String policyDateStr,Integer firmType,Integer categoryType,Integer newStatus,Integer oldStatus){
		this.log.debug(className+"updateInsurancePolicy DAO Start");
		String sql = sqlProperty.getProperty("InsurancePolicyDao_008");
		Object[] params = {
				newStatus,
				modifyBy,
				policyDateStr,
				firmType,
				categoryType,
				oldStatus
		};
		int count = this.updateBySQL(sql, params);
		this.log.debug(className+"updateInsurancePolicy DAO End");
		return count;
	}
	
	

	@Override
	public List<InsurancePolicyType> getInsurancePolicyTypeList() {
		this.log.debug(className+"getInsurancePolicyTypeList DAO Start");
		String sql = sqlProperty.getProperty("InsurancePolicyDao_009");
		Object[] params = {};
		List<InsurancePolicyType> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new InsurancePolicyType()));
		this.log.debug(className+"getInsurancePolicyTypeList DAO End");
		return list;
	}

	@Override
	public int deleteInsurancePolicyPrice(String policyDateStr) {
		this.log.debug(className+"deleteInsurancePolicyPrice DAO Start");
//		String sql = sqlProperty.getProperty("InsurancePolicyDao_010");
//		Object[] params = {
//				1,
//				modifyBy,
//				policyDateStr
//		};
		String sql = sqlProperty.getProperty("InsurancePolicyDao_011");
		Object[] params = {
			policyDateStr
		};
		int count = this.updateBySQL(sql, params);
		this.log.debug(className+"deleteInsurancePolicyPrice DAO End");
		return count;
	}

	@Override
	public InsurancePolicyDetail getInsurancePolicyDetailById(int policyId) {
		this.log.debug(className+"getInsurancePolicyDetailById DAO Start,policyId="+policyId);
		String sql=sqlProperty.getProperty("InsurancePolicyDao_00102");
		InsurancePolicyDetail model=(InsurancePolicyDetail)this.queryForObject(sql,new Object[]{policyId},new CommonRowMapper(new InsurancePolicyDetail()));
		this.log.debug(className+"getInsurancePolicyDetailById DAO End");
		return model;
	}

	@Override
	public int insertInsuranceBack(InsuranceBack model) {
		this.log.debug(className+"insertInsuranceBack DAO Start");
		String sql = sqlProperty.getProperty("InsurancePolicyDao_00103");
		Object[] params = {
				model.getREC_CREATEBY(),
				model.getREC_MODIFYBY(),
				model.getInsurancePolicyTypeID(),
				model.getInsurancePolicyID(),
				DateUtil.convert(model.getPolicyDate(), "yyyy-MM-dd"),
				model.getShouldBackAmount(),
				model.getRealBackAmount()== null ? 0 : model.getRealBackAmount(),
				model.getApplicant(),
				model.getDeliveryID(),
				model.getRemarks()
		};
		int count = this.updateBySQL(sql, params);
		this.log.debug(className+"insertInsuranceBack DAO End");
		return count;
	}

	@Override
	public InsuranceBack getInsuranceBackByID(Integer id) {
		this.log.debug(className+"getInsuranceBackByID DAO Start");
		String sql=sqlProperty.getProperty("InsurancePolicyDao_012");
		Object[] params = {id};
		InsuranceBack model=(InsuranceBack)this.queryForObject(sql,params,new CommonRowMapper(new InsuranceBack()));
		this.log.debug(className+"getInsuranceBackByID DAO End");
		return model;
	}
	
	/**
	 * 更新 退保
	 * @param id 退保ID
	 * @param oldStatus 退保状态 1已申请 5已执行
	 * @param newStatus 退保状态 1已申请 5已执行
	 * @param reviewer 审核人
	 * @param realBackAmount 实退保金额
	 * @return
	 */
	@Override
	public int updateInsuranceBackByID(AuditInsuranceBackVo vo) {
		this.log.debug(className+"updateInsuranceBackByID DAO Start");
		String sql = sqlProperty.getProperty("InsurancePolicyDao_013");
		Object[] params = {
				vo.getModifyBy(),
				vo.getRealBackAmount(),
				vo.getReviewer(),
				vo.getNewStatus(),
				vo.getId(),
				vo.getOldStatus()
		};
		int count = this.updateBySQL(sql, params);
		this.log.debug(className+"updateInsuranceBackByID DAO End");
		return count;
	}

	@Override
	public InsurancePolicy getInsurancePolicyByID(Integer id) {
		this.log.debug(className+"getInsurancePolicyByID DAO Start");
		String sql=sqlProperty.getProperty("InsurancePolicyDao_014");
		Object[] params = {id};
		InsurancePolicy model=(InsurancePolicy)this.queryForObject(sql,params,new CommonRowMapper(new InsurancePolicy()));
		this.log.debug(className+"getInsurancePolicyByID DAO End");
		return model;
	}

	@Override
	public void rollBack() {
		try {
			getConnection().rollback();
		} catch (CannotGetJdbcConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public int totalOrderPolicyList(QueryConditions qc) {
		this.log.debug(className+"totalOrderPolicyList DAO Start");
		String sql=sqlProperty.getProperty("InsurancePolicyDao_00101");
		 int totalCount=0;
		 totalCount=this.getTotalCount(sql, qc);
		this.log.debug(className+"totalOrderPolicyList DAO End");
		return totalCount;
	}
	
	/**
	 * 根据成交单获取保价单记录
	 * @param orderId 成交单号
	 * @param firmType 0：卖方交易商 1:买方交易商 
	 * @param status 1：未处理 5：未中保 10：已中保
	 * @return
	 */
	@Override
	public List<InsurancePolicy> getInsurancePolicyByObjectID(String orderId, Integer firmType, Integer status) {
		this.log.info(this.getClass().getName()+" getInsurancePolicyByObjectID dao Start");
		String sql = this.sqlProperty.getProperty("InsurancePolicyDao_00104");
		Object[] params = {orderId, firmType, status};
		List<InsurancePolicy> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new InsurancePolicy()));
		this.log.info(this.getClass().getName()+" getInsurancePolicyByObjectID dao End");
		return list;
	}
	
	/**
	 * 根据交收单获取退保表记录
	 * @param deliveryId 交收单号
	 * @param insurancePolicyId 保单ID
	 * @param firmType 0：卖方交易商 1:买方交易商 
	 * @param status 退保状态： 1已申请  5已执行
	 * @return
	 */
	@Override
	public InsuranceBack getInsuranceBackByDeliveryID(String deliveryId, Integer insurancePolicyId, Integer status) {
		this.log.info(this.getClass().getName()+" getInsuranceBackByDeliveryID dao Start");
		String sql = this.sqlProperty.getProperty("InsurancePolicyDao_00105");
		Object[] params = {deliveryId, insurancePolicyId, status};
		InsuranceBack insuranceBack = (InsuranceBack) this.queryForObject(sql, params,new CommonRowMapper(new InsuranceBack()));
		this.log.info(this.getClass().getName()+" getInsuranceBackByDeliveryID dao End");
		return insuranceBack;
	}
	
	/**
	 * 根据成交单获取退保表记录
	 * @param insurancePolicyId 保单ID
	 * @param firmType 0：卖方交易商 1:买方交易商 
	 * @param status 退保状态： 1已申请  5已执行
	 * @return
	 */
	@Override
	public List<InsuranceBack> getInsuranceBackList(Integer insurancePolicyId, Integer status) {
		this.log.info(this.getClass().getName()+" getInsurancePolicyList dao Start");
		String sql = this.sqlProperty.getProperty("InsurancePolicyDao_00106");
		Object[] params = {insurancePolicyId, status};
		List<InsuranceBack> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new InsuranceBack()));
		this.log.info(this.getClass().getName()+" getInsurancePolicyList dao End");
		return list;
	}
	
	/**
	 * 更新保单中的支付状态
	 * @param InsurancePolicyId 保单ID
	 * @param payStatus 支付状态 1：未支付 5：已支付
	 * @param modifyBy 更新人
	 * @return
	 */
	@Override
	public int updateInsurancePolicyPayStatus(Integer insurancePolicyId, Integer payStatus, String modifyBy) {
		this.log.debug(className+"updateInsurancePolicyPayStatus DAO Start");
		String sql = sqlProperty.getProperty("InsurancePolicyDao_00107");
		Object[] params = {
				payStatus,
				modifyBy,
				insurancePolicyId
		};
		int count = this.updateBySQL(sql, params);
		this.log.debug(className+"updateInsurancePolicyPayStatus DAO End");
		return count;
	}

	@Override
	public List<InsurancePolicy> getInsurancePolicyListByPolicyDate(String policyDateStr,Integer categoryType) {
		this.log.debug(className+"getInsurancePolicyListByPolicyDate DAO Start");
		String sql = this.sqlProperty.getProperty("InsurancePolicyDao_015");
		Object[] params = {policyDateStr,categoryType};
		List<InsurancePolicy> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new InsurancePolicy()));
		this.log.debug(className+"getInsurancePolicyListByPolicyDate DAO End");
		return list;
	}

	@Override
	public InsurancePolicyType getInsurancePolicyTypeByID(Integer id) {
		this.log.debug(className+"getInsurancePolicyTypeByID DAO Start");
		String sql = this.sqlProperty.getProperty("InsurancePolicyDao_016");
		Object[] params = {id};
		InsurancePolicyType ipt = (InsurancePolicyType) this.queryForObject(sql, params, new CommonRowMapper(new InsurancePolicyType()));
		this.log.debug(className+"getInsurancePolicyTypeByID DAO End");
		return ipt;
	}

	@Override
	public int updateInsurancePolicyByID(Integer id,Integer status,String modifyby) {
		this.log.debug(className+"getInsurancePolicyTypeByID DAO Start");
		String sql = this.sqlProperty.getProperty("InsurancePolicyDao_017");
		Object[] params = {status,modifyby,id};
		int count = this.updateBySQL(sql, params);
		this.log.debug(className+"getInsurancePolicyTypeByID DAO End");
		return count;
	}

	@Override
	public InsuranceBack getInsuranceBackByDeliveryID(String deliveryId) {
		this.log.debug(className+"getInsuranceBackByDeliveryID DAO Start");
		String sql = this.sqlProperty.getProperty("InsurancePolicyDao_00108");
		Object[] params = {deliveryId};
		InsuranceBack ib = (InsuranceBack) this.queryForObject(sql, params, new CommonRowMapper(new InsuranceBack()));
		this.log.debug(className+"getInsuranceBackByDeliveryID DAO End");
		return ib;
	}


}
