package shcem.market.component;

import java.util.List;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.market.dao.model.ExportNewCouponTrans;
import shcem.market.dao.model.NewCoupon;
import shcem.market.dao.model.NewCouponTrans;
import shcem.market.dao.model.NewCouponActivity;
import shcem.market.service.model.ActivityTempCoupon;

public abstract interface ICouponActivityComponentManager extends Manager{
	/**
	 * 查询新增优惠券列表
	 */
	List<NewCoupon> queryCouponTypeList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 插入或编辑 优惠券
	 * @param newCoupon
	 * @return
	 */
	int insertCouponType(NewCoupon newCoupon);
	
	/**
	 * 删除 优惠券
	 * @param newCoupon
	 * @return
	 */
	int delCouponType(int id, int dISABLED);
	
	/**
	 * 查询优惠券使用记录
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	List<NewCouponTrans> getCouponFlowingWaterList(QueryConditions qc,PageInfo pageInfo);
	
	/**
	 * 查询过滤未发送的优惠券[去掉已经过期的优惠券]
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	List<NewCouponTrans> getCouponNoUsedList(QueryConditions qc,PageInfo pageInfo,boolean replace);
	
	/**
	 * 导出优惠券使用记录流水
	 * @param replace 
	 * @param params
	 * @return
	 */
	List<ExportNewCouponTrans> exportCouponFlowingWaterList(QueryConditions qc, PageInfo pageInfo, boolean replace);
	
	/**
	 * 导出未发放优惠券记录
	 * @param replace 
	 * @param params
	 * @return
	 */
	List<ExportNewCouponTrans> exportCouponUnissuedList(QueryConditions qc, PageInfo pageInfo, boolean replace);
	
	/**
	 * 查询活动列表
	 */
	List<NewCouponActivity> queryCouponActivityList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 插入或编辑 活动
	 * @param newCoupon
	 * @return
	 */
	int insertOrUpdateActivity(ActivityTempCoupon activityTempCoupon, String userName);

	/**
	 * 审核活动
	 * @param newCouponActivity
	 * @param userName
	 * @param auditFlag 
	 * @return
	 */
	int auditActivity(NewCouponActivity newCouponActivity, String userName, boolean auditFlag);
	
	/**
	 * 审核活动（补发审核用）
	 * @param newCouponActivity
	 * @param userName
	 * @param auditFlag 
	 * @return
	 */
	int reissueAuditActivity(NewCouponActivity newCouponActivity, String userName, boolean auditFlag);
	
	
	/**
	 * 获取优惠券列表
	 * @return
	 */
	List<NewCoupon> getCouponList(Integer[] IDArray);

	/**
	 * 活动详情
	 * @param activityID
	 * @return
	 */
	ActivityTempCoupon getActivityByID(int activityID);

//	/**
//	 * 优惠券增发！
//	 * @param activityTempCoupon
//	 * @param userName 
//	 * @return
//	 */
//	int addMoreActivity(ActivityTempCoupon activityTempCoupon, String userName);
	
	/**
	 * 新增补发或编辑补发优惠券
	 * @param activityTempCoupon
	 * @param userName 
	 * @return
	 */
	int addOrEditReissueActivity(ActivityTempCoupon activityTempCoupon, String userName);
	/**
	 * 发送优惠券给用户
	 * @param Id
	 * @param userCode 用户code
	 * @param userID
	 * @param status 优惠券状态
	 * @param traderID 交易员编码
	 * @param firmID 交易商编码
	 * @return
	 */
	int sendCouponForUserCode(Integer Id,String userCode,String userID, Integer status, String traderID, String firmID);
	
	/**
	 * 发送兑换码
	 * @param Id
	 * @param userID
	 * @param status 优惠券状态
	 * @return
	 */
	int sendCouponForUserCodeExchangeCode(Integer Id, String userID, Integer status);
	
	/**
	 * 批量更新 优惠券的使用状态为【已发放】
	 * @param IdArr
	 * @param userID
	 * @return 置标成功的条数
	 */
	int markupNewCouponTransOfStatus(int[] IdArr,String userID);
	
	/**
	 * 启用或禁用活动
	 * @param id
	 * @param flag
	 * @return
	 */
	int resetActivityStatus(Integer id, Integer flag);

	int getExportCouponFlowingWaterCount(QueryConditions qc, PageInfo pageInfo);

	int getExportCouponUnissuedCount(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 活动详情
	 * @param activityID
	 * @return
	 */
	ActivityTempCoupon getReissueActivityByID(int activityID);
	
	/**
	 * 通过ID获取优惠券信息
	 * @param ID
	 * @return
	 */
	public NewCoupon getNewCouponInfoByID(Integer ID);
	
	/**
	 * 修改审核通过的活动时间
	 * @param ID
	 * @param userName
	 * @param activityStartDate
	 * @param activityEndDate
	 * @return
	 */
	int modifyAuditActivityDate(Integer ID, String userName, String activityStartDate, String activityEndDate);
	
}
