package shcem.market.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import shcem.base.dao.model.BaseObject;

/**
 * 竞猜记录查询
 * 
 * @author sunf
 *
 */
public class QueryGuizHistory extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5060996908741785728L;

	// 主键ID
	private Long iD;
	// 默认为 0：正常，1：失效
	private Integer dISABLED;
	private String REC_CREATEBY;
	private Date REC_CREATETIME;
	private String REC_MODIFYBY;
	private Date REC_MODIFYTIME;
	// 交易员编号
	private String traderID;
	// 交易员名称
	private String traderName;
	// 交易员手机号
	private String mobile;
	// 竞猜价格
	private BigDecimal quizPrice;
	// 状态
	private Integer status;
	// 竞猜活动合约价格ID
	private Integer quizActivity_ID;
	// 竞猜id
	private Integer quizHistoryID;
	// 中奖等级
	private Integer moneyTerm;
	// 中奖金额
	private BigDecimal bonus;
	// 竞猜日期
	private Date quizDate; 
	// 用户名
	private String userName;
	/**
	 * 交易商名称
	 */
	private String firmName;
	
	/**
	 * 合约名称
	 */
	private String contractName;
	
	/**
	 * 合约价格
	 */
	private BigDecimal contractPrice;

	/**
	 * 竞猜活动状态
	 */
	private Integer activityStatus;

	public Long getiD() {
		return iD;
	}

	public void setiD(Long iD) {
		this.iD = iD;
	}

	public Integer getdISABLED() {
		return dISABLED;
	}

	public void setdISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public String getREC_CREATEBY() {
		return REC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.REC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return REC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.REC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return REC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.REC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return REC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.REC_MODIFYTIME = rEC_MODIFYTIME;
	}

	public String getTraderID() {
		return traderID;
	}

	public void setTraderID(String traderID) {
		this.traderID = traderID;
	}

	public String getTraderName() {
		return traderName;
	}

	public void setTraderName(String traderName) {
		this.traderName = traderName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public BigDecimal getQuizPrice() {
		return quizPrice;
	}

	public void setQuizPrice(BigDecimal quizPrice) {
		this.quizPrice = quizPrice;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getQuizActivity_ID() {
		return quizActivity_ID;
	}

	public void setQuizActivity_ID(Integer quizActivity_ID) {
		this.quizActivity_ID = quizActivity_ID;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public Integer getActivityStatus() {
		return activityStatus;
	}

	public void setActivityStatus(Integer activityStatus) {
		this.activityStatus = activityStatus;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Integer getQuizHistoryID() {
		return quizHistoryID;
	}

	public void setQuizHistoryID(Integer quizHistoryID) {
		this.quizHistoryID = quizHistoryID;
	}

	public Integer getMoneyTerm() {
		return moneyTerm;
	}

	public void setMoneyTerm(Integer moneyTerm) {
		this.moneyTerm = moneyTerm;
	}

	public BigDecimal getBonus() {
		return bonus;
	}

	public void setBonus(BigDecimal bonus) {
		this.bonus = bonus;
	}

	public Date getQuizDate() {
		return quizDate;
	}

	public void setQuizDate(Date quizDate) {
		this.quizDate = quizDate;
	}

	public String getContractName() {
		return contractName;
	}

	public void setContractName(String contractName) {
		this.contractName = contractName;
	}

	public BigDecimal getContractPrice() {
		return contractPrice;
	}

	public void setContractPrice(BigDecimal contractPrice) {
		this.contractPrice = contractPrice;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
