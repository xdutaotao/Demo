package shcem.market.dao.model;

import java.io.Serializable;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

public class NewCouponActivity extends BaseObject implements Serializable {

	/**
	 * 默认的序列id
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 主键id
	 */
	private Integer id;
	/**
	 * 活动名称
	 */
	private String activityName; 
	/**
	 * 活动说明
	 */
	private String remark;
	/**
	 * 审核状态(1:待审核 5:审核通过 10:审核拒绝)
	 */
	private Integer auditStates;
	/**
	 * 活动起始时间
	 */
	private Date activityStartDate;
	/**
	 * 活动结束时间
	 */
	private Date activityEndDate;
	/**
	 * 审核时间
	 */
	private Date auditTime;
	/**
	 * 审核人
	 */
	private String auditBy;
	/**
	 * 状态(0:未启用 1:已启用)
	 */
	private Integer states;
	private Integer dISABLED;
	private String rEC_CREATEBY;
	private Date rEC_CREATETIME;
	private String rEC_MODIFYBY;
	private Date rEC_MODIFYTIME;
	
	private Boolean auditFlag;
	
	/*活动过期 :true 有效  false 过期*/
	private Boolean outDateFlag = true;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getAuditStates() {
		return auditStates;
	}

	public void setAuditStates(Integer auditStates) {
		this.auditStates = auditStates;
	}

	public Date getActivityStartDate() {
		return activityStartDate;
	}

	public void setActivityStartDate(Date activityStartDate) {
		this.activityStartDate = activityStartDate;
	}

	public Date getActivityEndDate() {
		return activityEndDate;
	}

	public void setActivityEndDate(Date activityEndDate) {
		this.activityEndDate = activityEndDate;
	}

	public Date getAuditTime() {
		return auditTime;
	}

	public void setAuditTime(Date auditTime) {
		this.auditTime = auditTime;
	}

	public String getAuditBy() {
		return auditBy;
	}

	public void setAuditBy(String auditBy) {
		this.auditBy = auditBy;
	}

	public Integer getStates() {
		return states;
	}

	public void setStates(Integer states) {
		this.states = states;
	}

	public Integer getDISABLED() {
		return dISABLED;
	}

	public void setDISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Boolean getAuditFlag() {
		return auditFlag;
	}

	public void setAuditFlag(Boolean auditFlag) {
		this.auditFlag = auditFlag;
	}

	public Boolean getOutDateFlag() {
		return outDateFlag;
	}

	public void setOutDateFlag(Boolean outDateFlag) {
		this.outDateFlag = outDateFlag;
	}

}
