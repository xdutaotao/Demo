package shcem.market.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import shcem.base.dao.model.BaseObject;
import shcem.constant.Constants;
import shcem.util.DataUtil;

/**
 * 
 * @author zhangnan 竞猜活动合约
 *
 */
public class QuizActivity extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** 主键 */
	private Integer id;
	/** 品类 1.PP 2.PE */
	private Integer category;
	/** 合约名称 */
	private String contractName;
	/** 合约价格 */
	private BigDecimal contractPrice;
	/**竞猜活动状态 1:未审核 5:审核通过*/
	private Integer status;
	/** 竞猜日期 */
	private Date quizDate;
	/***/
	private Integer DISABLED;
	/***/
	private String REC_CREATEBY;
	/***/
	private Date REC_CREATETIME;
	/***/
	private String REC_MODIFYBY;
	/***/
	private String REC_MODIFYTIME;
	
	/**该天是否已经存在*/
	private boolean quizDateBoolean;
	
	/** PP/PE组合合约价格 */
	private String pp_pe_contractPrice;
	
	/** PP/PE组合结算价格 */
	private String pp_pe_settlementPrice;
	
	private String Date;
	
	/***
	 * 是否工作日
	 *  1：工作日
	 *  0：节假日
	 */
	private Integer IsTradedate;
	
	/**
	 * 是否可修改
	 *  true：可以
	 *  false：不可以
	 */
	private boolean isUpdate;
	
	/**
	 * 是否可修改
	 *  true：可以
	 *  false：不可以
	 */
	private boolean isDelete;
	
	
	/**奖金池金额*/
	private BigDecimal poolMoney;
	
	
	/**
	 * 结算价格
	 */
	private BigDecimal settlementPrice;
	
	/**
	 * 官方解读
	 */
	private String answer;

	
	public BigDecimal getContractPrice() {
		return contractPrice;
	}

	public void setContractPrice(BigDecimal contractPrice) {
		this.contractPrice = contractPrice;
	}

	public Date getQuizDate() {
		return quizDate;
	}

	public void setQuizDate(Date quizDate) {
		this.quizDate = quizDate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCategory() {
		return category;
	}

	public void setCategory(Integer category) {
		this.category = category;
	}

	public String getContractName() {
		return contractName;
	}

	public void setContractName(String contractName) {
		this.contractName = contractName;
	}

	public Integer getDISABLED() {
		return DISABLED;
	}

	public void setDISABLED(Integer dISABLED) {
		DISABLED = dISABLED;
	}

	public String getREC_CREATEBY() {
		return REC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		REC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return REC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		REC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return REC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		REC_MODIFYBY = rEC_MODIFYBY;
	}

	public String getREC_MODIFYTIME() {
		return REC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(String rEC_MODIFYTIME) {
		REC_MODIFYTIME = rEC_MODIFYTIME;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public BigDecimal getPoolMoney() {
		return poolMoney;
	}

	public void setPoolMoney(BigDecimal poolMoney) {
		this.poolMoney = poolMoney;
	}

	public boolean getQuizDateBoolean() {
		return quizDateBoolean;
	}

	public void setQuizDateBoolean(boolean quizDateBoolean) {
		this.quizDateBoolean = quizDateBoolean;
	}

	public String getPp_pe_contractPrice() {
		return pp_pe_contractPrice;
	}

	public void setPp_pe_contractPrice(String pp_pe_contractPrice) {
		this.pp_pe_contractPrice = pp_pe_contractPrice;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}

	
	public Integer getIsTradedate() {
		return IsTradedate;
	}

	public void setIsTradedate(Integer isTradedate) {
		IsTradedate = isTradedate;
	}

	public boolean getIsUpdate() {
		return isUpdate;
	}

	public void setIsUpdate(boolean isUpdate) {
		this.isUpdate = isUpdate;
	}

	public boolean getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}

	public BigDecimal getSettlementPrice() {
		return settlementPrice;
	}

	public void setSettlementPrice(BigDecimal settlementPrice) {
		this.settlementPrice = settlementPrice;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getPp_pe_settlementPrice() {
		return pp_pe_settlementPrice;
	}

	public void setPp_pe_settlementPrice(String pp_pe_settlementPrice) {
		this.pp_pe_settlementPrice = pp_pe_settlementPrice;
	}
	
	
}
