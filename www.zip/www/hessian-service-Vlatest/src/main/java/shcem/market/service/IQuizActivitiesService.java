package shcem.market.service;

public interface IQuizActivitiesService {
	
	/**
	 * 新增合约
	 * @param params
	 * @return
	 */
	public String addQuizActivities(String params);
	
	/**
	 * 合约详情
	 * @param params
	 * @return
	 */
	public String getQuizActivitiesDetail(String params);
	
	/**
	 * 添加合约价格
	 * @param params
	 * @return
	 */
	public String updateQuizActivitiesPrice(String params);
	
	/**
	 * 合约列表
	 * @param params
	 * @return
	 */
	public String getQuizActivitiesList(String params);
	
	/**
	 * 竞猜记录列表
	 * @param params
	 * @return
	 */
	public String getGuizHistoryList(String params);
	
	/**
	 * 竞猜开奖(Job每个工作日下午四点触发)
	 * @param params
	 * @return
	 */
	public String runLottery(String params);
	
	
	/**
	 * 竞猜开奖(Job每个工作日下午四点触发)至尊预言帝奖
	 * @param params
	 * @return
	 */
	public String runSupremacy(String params);
	
	/**
	 * 删除合约
	 * @param params
	 * @return
	 */
	public String deleteQuizActivitie(String params);
	
	/**
	 * 合约重复校验(日期为主键)
	 * @param params
	 * @return
	 */
	public String CheckValidationQuizDate(String params);
	
	/**
	 * 更新 竞猜活动合约价格表 的官方解读
	 * @param params
	 * @return
	 */
	public String updateAnswer(String params);
	
	/**
	 * 获取 竞猜活动合约价格表 的官方解读
	 * @param params
	 * @return
	 */
	public String getAnswer(String params);
	
	/**
	 * 后台竞猜
	 * @param params
	 * @return
	 */
	public String guess(String params);
	
}
