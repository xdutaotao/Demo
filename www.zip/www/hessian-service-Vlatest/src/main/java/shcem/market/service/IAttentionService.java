package shcem.market.service;

/**
 * Created by lihaifeng on 2017/2/24.
 */
public interface IAttentionService {

    /**
     * 查询获取关注明细
     * @param params
     * @return
     */
    public String getAttentionDetailedList(String params);

    /**
     * 获取关注类型
     * @return
     */
    public String getAttentionTypeList();

    /**
     * 导出关注明细
     * @param params
     * @return
     */
    public String getExportAttentionDetailedExcel(String params);
    
    /**
     * 关注统计
     * @param params
     * @return
     */
    public String getAttentionStatistics(String params);
    
}
