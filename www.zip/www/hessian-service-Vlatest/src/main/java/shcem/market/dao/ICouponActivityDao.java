package shcem.market.dao;

import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.service.model.ValueTxtView;
import shcem.market.dao.model.CouponTrans;
import shcem.market.dao.model.NewCoupon;
import shcem.market.dao.model.NewCouponTemplateRel;
import shcem.market.dao.model.NewCouponTrans;
import shcem.market.dao.model.NewCouponActivity;
import shcem.market.service.model.ActivityTempCoupon;
import shcem.market.service.model.amoutDateModel;

public abstract interface ICouponActivityDao  extends DAO{
	
	/**
	 * 查询优惠券申请列表
	 */
	List<NewCoupon> queryCouponTypeList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 插入 优惠券
	 * @param newCoupon
	 * @return
	 */
	int insertCouponType(NewCoupon newCoupon);
	
	/**
	 * 更新 优惠券
	 * @param newCoupon
	 * @return
	 */
	int updateCouponType(NewCoupon newCoupon);
	
	/**
	 * 删除 优惠券
	 * @param newCoupon
	 * @return
	 */
	int delCouponType(int id,int dISABLED);
	
	/**
	 * 查询优惠券使用记录
	 * @param qc
	 * @param pageInfo
	 * @param replace 
	 * @return
	 */
	List<NewCouponTrans> getCouponFlowingWaterList(QueryConditions qc, PageInfo pageInfo, boolean replace);
	
	/**
	 * 查询过滤未发送的优惠券[去掉已经过期的优惠券]
	 * @param qc
	 * @param pageInfo
	 * @param replace 
	 * @return
	 */
	List<NewCouponTrans> getCouponNoUsedList(QueryConditions qc, PageInfo pageInfo, boolean replace);
	
	/**
	 * 查询活动列表
	 */
	List<NewCouponActivity> queryCouponActivityList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 发送优惠券 更新 活动优惠券发放流水表 的发放状态
	 * @param Id 
	 * @param userCode 用户编码
	 * @param status 状态
	 * @param traderID 交易员编码
	 * @param firmID 交易商编码
	 * @return
	 */
	int sendCouponForUserCode(Integer Id,String userCode, Integer status,String userID, String traderID, String firmID);
	
	/**
	 * 发送优惠券兑换码 更新 活动优惠券发放流水表 的发放状态
	 * @param Id 
	 * @param status 状态
	 * @return
	 */
	int sendCouponForUserCodeExchangeCode(Integer Id, Integer status, String userID);
	
	/**
	 * 获取优惠券使用记录
	 * @param Id 
	 * @return
	 */
	NewCouponTrans getNewCouponTransByID(Integer id);
	
	
	/**
	 * 更新 活动优惠券发放流水表 的发放状态
	 * @param Id 
	 * @param userCode 用户编码
	 * @param status 状态
	 * @return
	 */
	int updateNewCouponTransOfStatusByID(Integer Id,Integer status,String userID);

	/**
	 * 异常，事务回滚
	 */
	void rollBack();

	/**
	 * 新增，活动
	 * @param newCouponActivity
	 * @return
	 */
	int insertActivity(ActivityTempCoupon activityTempCoupon);
	
	/**
	 * 活动交易场关系表插入数据
	 * @param activityTempCoupon
	 * @return
	 */
	int insertActivityTempRel(int tempID, Integer activityID);
	
	/**
	 * 活动优惠券关系表插入数据
	 * @param amoutDateModel
	 * @param activityID
	 * @param userName
	 * @param auditStates
	 * @return
	 */
	int insertActivityCouponRel(amoutDateModel amoutDateModel, int activityID,
			String userName, int auditStates);
	
	
	/**
	 * 删除活动交易场关系表数据
	 * @param id
	 * @return
	 */
	int delActivityTemp(Integer id);
	
	/**
	 * 更新活动表
	 * @param activityTempCoupon
	 * @return
	 */
	int updateActivity(ActivityTempCoupon activityTempCoupon);
	
	/**
	 * 往优惠券流水表插入数据
	 * @param amoutDateModel
	 * @param activityID
	 * @param userName
	 * @param couponNumber
	 * @param exchangeCode
	 * @return
	 */
	int insertCouponTrans(amoutDateModel amoutDateModel, int activityID,
			String userName, String couponNumber, String exchangeCode);
	
	/**
	 * 审核活动
	 * @param newCouponActivity
	 * @param userName
	 * @param auditFlag  审核状态
	 * @return
	 */
	int updateAuditStatus(NewCouponActivity newCouponActivity, String userName, boolean auditFlag);

	/**
	 * 查询活动和优惠券的关系记录表
	 * @param activityID
	 * @return
	 */
	List<amoutDateModel> getAmoutDateList(Integer activityID);
	
	/**
	 * 查询活动和优惠券的关系记录表(补发用)
	 * @param activityID
	 * @return
	 */
	List<amoutDateModel> getReissueAmoutDateList(Integer activityID);
	
	/**
	 * 获取优惠券列表
	 * @return
	 */
	List<NewCoupon> getCouponList(Integer[] templateIDArray);
	
	/**
	 * 通过活动id获取活动详情
	 * @param activityID
	 * @return
	 */
	ActivityTempCoupon getActivityByID(int activityID);

	/**
	 * 交易场IDList
	 * @param activityID
	 * @return
	 */
	List<ValueTxtView> getTempList(int activityID);
	
	/**
	 * 通过活动ID获取关系表数据List(审核)
	 * @param activityID
	 * @return
	 */
	List<amoutDateModel> getcouponActivityRelList(int activityID);
	
	/**
	 * 通过活动ID获取补发优惠会券关系表数据List
	 * @param activityID
	 * @return
	 */
	List<amoutDateModel> getReissueCouponActivityRelList(int activityID);

	/**
	 * 通过活动ID获取关系表数据List(编辑)
	 * @param activityID
	 * @return
	 */
	List<amoutDateModel> getgetcouponActivityRelEditList(int activityID);

	/**
	 * 先删除'活动优惠券发放情况表'相关记录
	 * @param id
	 * @return
	 */
	int delNewCouponActivityRel(Integer activityID);
	
	/**
	 * 先删除'活动优惠券发放情况表'相关记录
	 * @param id
	 * @param auditStates 审核状态(1:待审核 3:补发待审核 5:审核通过 10:审核拒绝)
	 * @return
	 */
	int delNewCouponActivityRel(Integer activityID,Integer auditStates);

	/**
	 * 优惠券类型名称校验
	 * @param couponName
	 * @return
	 */
	boolean getNewCouponList(String couponName);

	/**
	 * 活动名称校验
	 * @param activityName
	 * @return
	 */
	boolean getNewCouponActivity(String activityName);

	/**
	 * 校验优惠券类型关联的活动是否通过审核
	 * @param id
	 * @return
	 */
	Boolean checkCouponTypeAuditFlag(Integer id);

	/**
	 * 
	 * @param id
	 * @return
	 */
	int delNewCouponActivityRelByCouponID(int id);

	/** 
	 * 更新'F_NewCouponActivityRel' auditStatus
	 * @param activityID
	 * @param auditStatus
	 * @return
	 */
	int updateNewCouponActivityRelAuditStatus(Integer activityID, int auditStatus);
	
	/** 
	 * 更新'F_NewCouponActivityRel' auditStatus
	 * @param activityID
	 * @param oldAuditStatus
	 * @param newAuditStatus
	 * @return
	 */
	int updateNewCouponActivityRelAuditStatus(Integer activityID,String userName, int oldAuditStatus,int newAuditStatus);

	/**
	 * 校验优惠券号码是否重复
	 * @param couponNumber
	 * @return
	 */
	boolean checkCouponNumber(String couponNumber);

	/**
	 * 优惠券类型
	 * @param couponID
	 * @return
	 */
	Integer getCouponType(Integer couponID);
	
	/**
	 * 启用或禁用活动
	 * @param id
	 * @param flag
	 * @return
	 */
	int resetActivityStatus(Integer id, Integer flag);

	int getExportCouponFlowingWaterCount(QueryConditions qc, PageInfo pageInfo);

	int getExportCouponUnissuedCount(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 优惠券批量新增
	 * @param amoutDateModel
	 * @param id
	 * @param userName
	 * @param couponNumberList
	 * @return
	 */
	int addBatchCouponTrans(amoutDateModel amoutDateModel, Integer id,
			String userName, List<CouponTrans> couponNumberList);

	int getNewCouponTransCount();
	
	/**
	 * 更新活动的审核状态
	 * @param activityId 活动ID
	 * @param userName 
	 * @param oldAuditStates  审核状态(1:待审核 3:补发待审核 5:审核通过 10:审核拒绝  15:补发拒绝)
	 * @param newAuditStates  审核状态(1:待审核 3:补发待审核 5:审核通过 10:审核拒绝  15:补发拒绝 )
	 * @return
	 */
	int updateNewCouponActivityAuditStatus(Integer activityId, String userName,Integer oldAuditStates,Integer newAuditStates);
	
	/**
	 * 批量 插入 优惠券类型交易场关联表
	 * @param newCouponTemplateRelList
	 * @return
	 */
	int insertNewCouponTemplateRel(List<NewCouponTemplateRel> newCouponTemplateRelList);
	
	/**
	 * 删除 优惠券类型交易场关联表
	 * @param newCouponID
	 * @return
	 */
	int deleteNewCouponTemplateRelByNewCouponID(Integer newCouponID);
	
	
	/**
	 * 查询  优惠券类型交易场关联表
	 * @param newCouponID
	 * @return
	 */
	List<NewCouponTemplateRel> selectNewCouponTemplateRelByNewCouponID(Integer newCouponID);
	
	/**
	 * 查询  优惠券
	 * @param ID
	 * @return
	 */
	NewCoupon selectNewCouponByID(Integer ID);
	
	/**
	 * 修改审核通过的活动时间
	 * @param ID
	 * @param userName
	 * @param activityStartDate
	 * @param activityEndDate
	 * @return
	 */
	int modifyAuditActivityDate(Integer ID, String userName, String activityStartDate, String activityEndDate); 
	
}
