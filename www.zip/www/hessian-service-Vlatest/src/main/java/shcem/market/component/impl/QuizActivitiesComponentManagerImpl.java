package shcem.market.component.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.constant.Constants;
import shcem.market.component.IQuizActivitiesComponentManager;
import shcem.market.dao.IQuizActivitiesDao;
import shcem.market.dao.model.QueryGuizHistory;
import shcem.market.dao.model.QuizActivity;
import shcem.market.dao.model.QuizHistory;
import shcem.market.dao.model.QuizHistoryAndQuizActivity;
import shcem.market.dao.model.QuizMoney;
import shcem.market.dao.model.QuizMoneyPool;
import shcem.market.dao.model.QuizWinningResult;
import shcem.market.service.model.QuizHistoryVo;
import shcem.util.Common;
import shcem.util.DataUtil;
import shcem.util.DateUtil;
import shcem.util.JsonUtil;
import shcem.util.RemoteCallDotNetUtil;

public class QuizActivitiesComponentManagerImpl extends BaseManager implements
		IQuizActivitiesComponentManager{
	
	private IQuizActivitiesDao  quizActivitiesDao;
	
	private IQuizActivitiesDao  quizActivitiesDao_read;

	public void setQuizActivitiesDao(IQuizActivitiesDao quizActivitiesDao) {
		this.quizActivitiesDao = quizActivitiesDao;
	}

	public void setQuizActivitiesDao_read(IQuizActivitiesDao quizActivitiesDao_read) {
		this.quizActivitiesDao_read = quizActivitiesDao_read;
	}

	@Override
	public List<QueryGuizHistory> queryCouponTypeList(QueryConditions qc, PageInfo pageInfo) { 
		return this.quizActivitiesDao_read.queryCouponTypeList(qc, pageInfo);
	}
	
	@Override
	public int addQuizActivities(String userName,
			List<QuizActivity> quizActivityList,String mode, String requestId) {
		this.log.debug(QuizActivitiesComponentManagerImpl.class.getName()+"  addQuizActivities Start");
		int returnCode = 0;
		/**
		 * 1.剔除提交数据中非工作日的记录(工作日以国务院发布为准)
		 */
		List<QuizActivity> quizActivityList_workDay = this.getWorkDayQuizActivityList(quizActivityList,mode,requestId,userName);
		
		if(quizActivityList_workDay == null){
			return returnCode = -100010;
		}
		if(quizActivityList_workDay != null && quizActivityList_workDay.size() == 0){
			return returnCode = -100011;
		}
		/**
		 * 2.新增合约价格
		 */
		if (quizActivityList_workDay != null && quizActivityList_workDay.size() > 0) {
			for (int i = 0; i < quizActivityList_workDay.size(); i++) {
				int quizActivityID = this.quizActivitiesDao.addQuizActivities(userName,quizActivityList_workDay.get(i));
				if(quizActivityID < 0){
					this.rollBack();
					returnCode = -1;
					break;
				}
				for (int moneyTerm = 1; moneyTerm < 4; moneyTerm++) {
					//奖项设置重复校验
					int quizMoneyCount = this.quizActivitiesDao.getQuizMoneyCount(moneyTerm, quizActivityList_workDay.get(i).getQuizDate());
					if(quizMoneyCount < 1){
						returnCode = this.quizActivitiesDao.addQuizMoney(userName,moneyTerm,Constants.getQuizMoney(moneyTerm),quizActivityList_workDay.get(i).getQuizDate());
						if (returnCode < 0) {
							this.rollBack();
							returnCode = -1;	
							break;
						}
						//查询奖金池是否有资金，有的话，累积到下一天合约活动的一等奖里
						if(moneyTerm ==1){
							BigDecimal quizMoney = new BigDecimal(0);
							quizMoney = this.quizActivitiesDao.getQuizMoneyPoolMoney();
							returnCode = this.quizActivitiesDao.updateQuizMoney(userName,quizMoney,moneyTerm,quizActivityList_workDay.get(i).getQuizDate());
							if(returnCode < 0){
								this.rollBack();
								returnCode = -1;
								break;
							}else {
								//更新自己池余额为0
								returnCode = this.quizActivitiesDao.updateQuizMoneyPoolMoney();	
								if(returnCode < 0){
									this.rollBack();
									returnCode = -1;
									break;
								}else {
									continue;
								}
							}
						}
					}else {
						continue;
					}
				}
			}
		}else {
			returnCode = -100010;
		}
		this.log.debug(QuizActivitiesComponentManagerImpl.class.getName()+"  addQuizActivities End");
		return returnCode;
	}
	
	@Override
	public int updateQuizActivitiesPrice(String userName,
			List<QuizActivity> quizActivityList) {
		this.log.debug(QuizActivitiesComponentManagerImpl.class.getName()+"  updateQuizActivitiesPrice Start");
		int returnCode = 0;
		for (int i = 0; i < quizActivityList.size(); i++) {
			returnCode = this.quizActivitiesDao.updateQuizActivitiesPrice(userName,quizActivityList.get(i));
			if(returnCode < 0){
				this.rollBack();
				return returnCode;
			}
		}
		this.log.debug(QuizActivitiesComponentManagerImpl.class.getName()+"  updateQuizActivitiesPrice End");
		return returnCode;
	}
	
	@Override
	public List<QuizActivity> getQuizActivitiesList(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.debug(QuizActivitiesComponentManagerImpl.class.getName()+"  getQuizActivitiesList Start");
		List<QuizActivity> list = this.quizActivitiesDao_read.getQuizActivitiesList(qc,pageInfo);
		//每天下午三点五十之后，开奖之前价格不能再修改
		//删除,当天以后能删除
		if(list != null && list.size() > 0 ){
			for (int i = 0; i < list.size(); i++) {
				list.get(i).setIsUpdate(compareUpdateTime(list.get(i).getQuizDate()));
				list.get(i).setIsDelete(compareDeleteTime(list.get(i).getQuizDate()));
			}
		}
		this.log.debug(QuizActivitiesComponentManagerImpl.class.getName()+"  getQuizActivitiesList End");
		return list;
	}
	/**
	 * 判断是否能删除
	 * @param quizDate
	 * @return
	 */
	private boolean compareDeleteTime(Date quizDate) {
		boolean isDelete = false;
		//修改只能修改当天的合约价格
		SimpleDateFormat timeFormater = new SimpleDateFormat("yyyy-MM-dd");
		String  currentTimeString = timeFormater.format(new Date());
		String  quizDateString = timeFormater.format(quizDate);
		int tempCount = DataUtil.StringToDate(currentTimeString, "yyyy-MM-dd").compareTo(DataUtil.StringToDate(quizDateString, "yyyy-MM-dd"));
		if(tempCount < 0)isDelete = true;
		return isDelete;
	}
	/**
	 * 判断是够能修改
	 * @param quizDate
	 * @return
	 */
	private boolean compareUpdateTime(Date quizDate) {
		boolean isUpdate = false;
		//修改只能修改当天的合约价格
		SimpleDateFormat timeFormater = new SimpleDateFormat("yyyy-MM-dd");
		String  currentTimeString = timeFormater.format(new Date());
		String  quizDateString = timeFormater.format(quizDate);
		int tempCount = DataUtil.StringToDate(currentTimeString, "yyyy-MM-dd").compareTo(DataUtil.StringToDate(quizDateString, "yyyy-MM-dd"));
		if(tempCount <= 0){
			isUpdate = true;
			if(tempCount == 0){
				System.err.println(Constants.CLOSE_TIME);//设置价格最后截止时间
				System.err.println(DataUtil.TimeToString(new Date()));//当前时间
				int temp = DataUtil.StringToTime(Constants.CLOSE_TIME).compareTo(DataUtil.StringToTime(DataUtil.TimeToString(new Date())));
				if(temp < 0)isUpdate = false;
			}
		}
		return isUpdate;
	}
	
	/**
	 * 奖金设置
	 * @param quizDate
	 */
	private int addQuizMoney(Date quizDate) {
		this.log.info(this.getClass().getName()+" addQuizMoney Start");
		int returnCode = 0;
		for (int moneyTerm = 1; moneyTerm < 4; moneyTerm++) {
			returnCode = this.quizActivitiesDao.addQuizMoney("system",moneyTerm,Constants.getQuizMoney(moneyTerm),quizDate);
			if (returnCode < 0) {
				this.rollBack();
				returnCode = -1;	
				break;
			}
			//查询奖金池是否有资金，有的话，累积到下一天合约活动的一等奖里
			if(moneyTerm ==1){
				BigDecimal quizMoney = new BigDecimal(0);
				quizMoney = this.quizActivitiesDao.getQuizMoneyPoolMoney();
				returnCode = this.quizActivitiesDao.updateQuizMoney("system",quizMoney,moneyTerm,quizDate);
				if(returnCode < 0){
					this.rollBack();
					returnCode = -1;
					break;
				}else {
					//更新自己池余额为0
					returnCode = this.quizActivitiesDao.updateQuizMoneyPoolMoney();	
					if(returnCode < 0){
						this.rollBack();
						returnCode = -1;
						break;
					}else {
						continue;
					}
				}
			}
		}
		this.log.info(this.getClass().getName()+" addQuizMoney End");
		return returnCode;
	}
	
	@Override
	public List<QuizActivity> getQuizActivitiesDetail(String quizDate) {
		this.log.info(this.getClass().getName()+"getQuizActivitiesDetail Start");
		List<QuizActivity> list = new ArrayList<QuizActivity>();
		list = this.quizActivitiesDao_read.getQuizActivitiesDetail(quizDate);
		this.log.info(this.getClass().getName()+"getQuizActivitiesDetail End");
		return list;
	}
	
	/**
	 * 剔除提交数据中非工作日的记录(工作日以国务院发布为准)
	 * @param quizActivityList
	 * @param requestId 
	 * @param mode 
	 * @param userName 
	 * @return
	 */
	public List<QuizActivity> getWorkDayQuizActivityList(
			List<QuizActivity> quizActivityList, String mode, String requestId, String userName) {
		this.log.info(this.getClass().getName()+"getWorkDayQuizActivityList Start");
		List<QuizActivity> quizActivityList_workDay = new ArrayList<QuizActivity>();
		String[] quizDateArray = new String[quizActivityList.size()];
		for (int i = 0; i < quizActivityList.size(); i++) {
			Date dateTemp = quizActivityList.get(i).getQuizDate();
			String dateTempString = DataUtil.DateToString(dateTemp, "yyyy-MM-dd");
			System.err.println(DataUtil.DateTimeToString(DataUtil.StringToDate(dateTempString)));
			quizDateArray[i] = DataUtil.DateToString(DataUtil.StringToDate(dateTempString));
			
		}
		Map<String,Object> paramsMap = new HashMap<String, Object>();
		paramsMap.put("DateList", quizDateArray);
		/**
		 * 前台接口,判断是否节假日
		 */
		JSONObject rtnJOParams = RemoteCallDotNetUtil.call("Shcem.Trade.ServiceContract.ITradeDateService", "CheckIsTradeDate",paramsMap, userName,mode, requestId);
		JSONObject rtnJOParamsTemp = new JSONObject();
		try {
			rtnJOParamsTemp = new JSONObject(rtnJOParams.getString("DATA"));
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" 调用.net接口判断节假日出错，返回参数："+rtnJOParams);
			rtnJOParamsTemp =null;
		}
		
		if(rtnJOParamsTemp != null){
			JSONArray quizActivityListListTemp = rtnJOParamsTemp.optJSONArray("ResultList");
			if(quizActivityListListTemp != null && quizActivityListListTemp.length() > 0){
				for (int i = 0; i < quizActivityListListTemp.length(); i++) {
					JSONObject temp = (JSONObject) quizActivityListListTemp.get(i);
					String tempString = temp.toString().replace("Date", "date");
					tempString = tempString.replace("IsTradedate", "isTradedate");
					try {
						temp = new JSONObject(tempString);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					QuizActivity quizActivity = (QuizActivity) JsonUtil.jsonToBean(temp,QuizActivity.class);
					if(quizActivity.getIsTradedate() == 1){
						for (int j = 0; j < quizActivityList.size(); j++) {
							String aa = DataUtil.DateToString(quizActivityList.get(i).getQuizDate(), "yyyy-MM-dd");
							Date bb = DataUtil.StringToDate(aa);
							String dateTemp = DataUtil.DateTimeToString( bb);
							if(dateTemp.equals(quizActivity.getDate())){
								quizActivityList.get(i).setIsTradedate(1);//工作日
							}
						}
					}
				}
				//取得工作日
				for (int i = 0; i < quizActivityList.size(); i++) {
					if(quizActivityList.get(i).getIsTradedate() == 1)quizActivityList_workDay.add(quizActivityList.get(i));
				}
				
			}else {
				return null;
			}
		}else {
			return new ArrayList<QuizActivity>();
		}
		this.log.info(this.getClass().getName()+"getWorkDayQuizActivityList End");
		return quizActivityList_workDay;
	}
	
	
	/**
	 * 开至尊8888元大奖
	 * @param exeDate
	 * @return
	 */
	private String getPrize10(String exeDate) {
		// 获得至尊预言帝的8888元大奖竞猜记录
		List<QuizHistory> prize10List = quizActivitiesDao_read.getPrize10(exeDate);

		String traderId10 = "";
		Map<String, Map<String, Object>> traderPPPEMap = new HashMap<String, Map<String, Object>>();
		for (QuizHistory quizHistory : prize10List) {
			Integer id = quizHistory.getId();
			Integer category = quizHistory.getCategory();
			String traderId = quizHistory.getTraderID();

			Map<String, Object> property = null;
			if (traderPPPEMap.containsKey(traderId)) {
				property = traderPPPEMap.get(traderId);
			} else {
				property = new HashMap<String, Object>();
				property.put("PP", false);
				property.put("PPID", 0);
				property.put("PE", false);
				property.put("PEID", 0);
			}

			if (category == 1) {
				property.put("PP", true);
				property.put("PPID", id);
			} else if (category == 2) {
				property.put("PE", true);
				property.put("PEID", id);
			}
			traderPPPEMap.put(traderId, property);

			// 最先PP PE都猜中的客户,竞猜中奖结果表插入数据
			if ((Boolean) property.get("PP") && (Boolean) property.get("PE")) {
				traderId10 = traderId;
				QuizWinningResult qwResult = new QuizWinningResult();
				qwResult.setdISABLED(0);
				qwResult.setQuizHistoryID((Integer) property.get("PPID"));
				qwResult.setMoneyTerm(10);
				qwResult.setBonus(new BigDecimal("8888"));
				qwResult.setQuizDate(Common.strToDate(exeDate));
				quizActivitiesDao.insertQuizWinningResult(qwResult);

				qwResult.setQuizHistoryID((Integer) property.get("PEID"));
				quizActivitiesDao.insertQuizWinningResult(qwResult);
				return traderId10;
			}
		}

		return traderId10;
	}
	
	/**
	 * 开至尊1888元大奖
	 * @param exeDate
	 * @param winnerCnt 整个活动内还剩1888大奖的个数(总数3个)
	 * @return
	 */
	private List<String> getPrize20(String exeDate, int winnerCnt) {
		// 获得至尊预言帝的1888元大奖竞猜记录
		List<QuizHistory> prize20List = quizActivitiesDao_read.getPrize20(exeDate);

		List<String> traderId20 = new ArrayList<String>();
		// 至尊1888元大奖中奖人数计数
		int count = 0;

		Map<String, Map<String, Object>> traderPPPEMap = new HashMap<String, Map<String, Object>>();
		for (QuizHistory quizHistory : prize20List) {
			Integer id = quizHistory.getId();
			Integer category = quizHistory.getCategory();
			String traderId = quizHistory.getTraderID();

			// 中过至尊预言奖的交易员不再此次中奖
			if (traderId20.contains(traderId)) {
				continue;
			}

			Map<String, Object> property = null;
			if (traderPPPEMap.containsKey(traderId)) {
				property = traderPPPEMap.get(traderId);
			} else {
				property = new HashMap<String, Object>();
				property.put("PP", false);
				property.put("PPID", 0);
				property.put("PE", false);
				property.put("PEID", 0);
			}

			if (category == 1) {
				property.put("PP", true);
				property.put("PPID", id);
			} else if (category == 2) {
				property.put("PE", true);
				property.put("PEID", id);
			}
			traderPPPEMap.put(traderId, property);

			// 最先猜中PP或猜中PE的客户,竞猜中奖结果表插入数据
			if ((Boolean) property.get("PP") || (Boolean) property.get("PE")) {
				// 中奖人数+1
				count++;
				traderId20.add(traderId);

				QuizWinningResult qwResult = new QuizWinningResult();
				qwResult.setdISABLED(0);
				if ((Boolean) property.get("PP")) {
					qwResult.setQuizHistoryID((Integer) property.get("PPID"));
				} else {
					qwResult.setQuizHistoryID((Integer) property.get("PEID"));
				}
				qwResult.setMoneyTerm(20);
				qwResult.setBonus(new BigDecimal("1888"));
				qwResult.setQuizDate(Common.strToDate(exeDate));
				quizActivitiesDao.insertQuizWinningResult(qwResult);
			}

			// 中奖人数到数后结束
			if (count == winnerCnt) {
				return traderId20;
			}
		}

		return traderId20;
	}
	
	/**
	 * 开入围50元大奖
	 * @param exeDate
	 * @return
	 */
	private List<String> getPrize30(String exeDate, String traderId10, List<String> traderId20) {
		// 获得入围奖50元大奖竞猜记录
		List<QuizHistory> prize30List = quizActivitiesDao_read.getPrize30(exeDate);

		List<String> traderId30 = new ArrayList<String>();
		// 入围奖中奖人数计数
		int count = 0;

		for (QuizHistory quizHistory : prize30List) {
			Integer id = quizHistory.getId();
			String traderId = quizHistory.getTraderID();
			
			// 中过至尊预言奖8888的交易员不再此次中奖
			if (traderId.equals(traderId10)) {
				continue;
			}

			// 中过至尊预言奖1888的交易员不再此次中奖
			if (traderId20.contains(traderId)) {
				continue;
			}

			// 中过本次入围奖的交易员不再此次中奖
			if (traderId30.contains(traderId)) {
				continue;
			}

			// 最先猜中PP或猜中PE的客户,竞猜中奖结果表插入数据
			count++;
			traderId30.add(traderId);
			QuizWinningResult qwResult = new QuizWinningResult();
			qwResult.setdISABLED(0);
			qwResult.setQuizHistoryID(id);
			qwResult.setMoneyTerm(30);
			qwResult.setBonus(new BigDecimal("50"));
			qwResult.setQuizDate(Common.strToDate(exeDate));
			quizActivitiesDao.insertQuizWinningResult(qwResult);
			if (count == 5) {
				return traderId30;
			}
		}

		return traderId30;
	}
	
	@Override
	public Integer exeSupremacy(String exeDate) {
		this.log.debug(QuizActivitiesComponentManagerImpl.class.getName() + " exeSupremacy Component Start");
		this.log.debug("当前执行日期：" + exeDate);
		Integer resultCode = 0;
		
		//检查竞猜记录表有没有被更新过
		List<QuizHistory> modifiedQhList = quizActivitiesDao_read.getModifiedQuizHistoryList(exeDate);
		if(modifiedQhList.size() != 0){
			this.log.error("当前执行日期：" + exeDate + ", 竞猜记录表已经被更新，请确认！");
			resultCode = -100015;
			return resultCode;
		}
		
		//检查竞猜中奖结果表有没有被更新过
		String filter1 = " AND CONVERT(CHAR(10), QuizDate, 120) = '" + exeDate + "'";
		List<QuizWinningResult> modifiedQwrList = quizActivitiesDao_read.getWinningResultList(filter1);
		if(modifiedQwrList.size() != 0){
			this.log.error("当前执行日期：" + exeDate + ", 竞猜中奖结果表已经被更新，请确认！");
			resultCode = -100016;
			return resultCode;
		}
		

		// 取得至尊8888元中奖纪录,如果有人中过就不再开8888元大奖
		List<QuizWinningResult> wr8888List = quizActivitiesDao_read.getWinningResultList(" and MoneyTerm = '10'");
		// 此次中8888元的交易员id
		String traderId10 = "";
		// 一个活动周期，同时竞猜PP1709和PE1709合约收盘价，价差为0的第一位客户
		if (wr8888List.size() == 0) {
			// 开至尊8888元大奖
			traderId10 = this.getPrize10(exeDate);
		}

		// 取得至尊1888元中奖纪录,如果有3人中过就不再开1888元大奖
		List<QuizWinningResult> wr1888List = quizActivitiesDao_read.getWinningResultList(" and MoneyTerm = '20'");
		// 此次中1888元的交易员id
		List<String> traderId20 = new ArrayList<String>();
		// 一个活动周期，竞猜PP1709/PE1709任意一个合约收盘价，价差为0的前三位客户
		if (wr1888List.size() < 3) {
			// 开至尊1888元大奖
			traderId20 = this.getPrize20(exeDate, 3 - wr1888List.size());
		}

		// 此次中50元的交易员id
		List<String> traderId30 = new ArrayList<String>();
		// 每日竞猜PP1709/PE1709合约收盘价价差最小的前五位客户（价差需在±25元以内）
		// 获得入围奖的50元大奖竞猜记录
		traderId30 = this.getPrize30(exeDate, traderId10, traderId20);

		this.log.debug("至尊8888大奖交易员：" + traderId10);
		this.log.debug("至尊1888大奖交易员：" + traderId20);
		this.log.debug("入围50大奖交易员：" + traderId30);

		// 此次的竞猜记录表的中奖状态更新
		String filter2 = " and MoneyTerm in ('10','20','30') AND CONVERT(CHAR(10), QuizDate, 120) = '" + exeDate + "'";
		List<QuizWinningResult> allWrList = quizActivitiesDao_read.getWinningResultList(filter2);
		List<Integer> winningIdList = new ArrayList<Integer>();
		for (QuizWinningResult dto : allWrList) {
			winningIdList.add(dto.getQuizHistoryID());
		}
		if (winningIdList.size() > 0) {
			quizActivitiesDao.updateQueryGuizHistoryInIdList(2, winningIdList, exeDate);// 已中奖
			quizActivitiesDao.updateQueryGuizHistoryNotInIdList(1, winningIdList, exeDate);// 未中奖
		}

		this.log.debug(QuizActivitiesComponentManagerImpl.class.getName() + " exeSupremacy Component End");
		return resultCode;
	}
	/**
	 * 执行开奖
	 */
	@Override
	public Integer exeTheLottery(String exeDate) {
		this.log.debug(QuizActivitiesComponentManagerImpl.class.getName()+" exeTheLottery Component Start");
		this.log.debug("当前执行日期："+exeDate);
		Integer resultCode = 0;
		// 判断 奖金池中 是否有数据，有：取出一等奖的金额 无：初始化奖金池
		List<QuizMoneyPool> quizMoneyPoolList = quizActivitiesDao_read.selectQuizMoneyPoolList();
		if (quizMoneyPoolList.size() == 0){
			QuizMoneyPool quizMoneyPool = new QuizMoneyPool();
			quizMoneyPool.setMoneyTerm(1);
			quizMoneyPool.setPoolMoney(new BigDecimal(0));
			quizMoneyPool.setREC_CREATEBY("system");
			quizMoneyPool.setREC_MODIFYBY("system");
			quizActivitiesDao.insertQuizMoneyPool(quizMoneyPool);
			this.log.debug("初始化奖金池参数");
		}
		// 竞猜活动合约价格表
		List<QuizActivity> quizActivityList = quizActivitiesDao_read.selectQuizActivityByQuizDate(exeDate);
		// 竞猜活动奖金设置表
		List<QuizMoney> quizMoneyList = quizActivitiesDao_read.selectQuizMoneyListByDate(exeDate);
		int quizActivityListSize = quizActivityList.size();
		int quizMoneyListSize = quizMoneyList.size();
		if (quizActivityListSize > 0 && quizMoneyListSize > 0){
			// 竞猜活动奖金设置表一天只能有三条数据
			if (quizMoneyListSize == 3){
				// 竞猜活动奖金设置表  一等奖 2：二等奖  3：三等奖
				BigDecimal moneyTermTempOne = new BigDecimal(0);
				BigDecimal moneyTermTempTwo = new BigDecimal(0);
				BigDecimal moneyTermTempThree = new BigDecimal(0);
				// 取出 竞猜活动奖金设置表的   一等奖 ，二等奖  ，三等奖
				for(QuizMoney qm : quizMoneyList){
					if (qm.getMoneyTerm() == 1){
						moneyTermTempOne = qm.getMoney();
					}
					if (qm.getMoneyTerm() == 2){
						moneyTermTempTwo =  qm.getMoney();
					}
					if (qm.getMoneyTerm() == 3){
						moneyTermTempThree =  qm.getMoney();
					}
				}
				// 获取 竞猜记录 列表
				List<QuizHistoryAndQuizActivity> db1List = quizActivitiesDao_read.selectGuizHistoryList(exeDate,Constants.FOLAT_VALUE);
				// 中奖人列表
				List<QuizHistoryAndQuizActivity> bkDbList = new ArrayList<QuizHistoryAndQuizActivity>();
				// 排除重复中奖人
				Map<Integer,QuizHistoryAndQuizActivity> map = new HashMap<Integer,QuizHistoryAndQuizActivity>();
				for (QuizHistoryAndQuizActivity qh : db1List){
					if (!map.containsKey(qh.getTraderID())){
						map.put(qh.getTraderID(), qh);
						bkDbList.add(qh);
					}
					if (map.size() >= 3){
						break;
					}
				}
				// 更新 竞猜记录
				resultCode = updateWinningResult(resultCode,exeDate,bkDbList,moneyTermTempOne,moneyTermTempTwo,moneyTermTempThree);
				if (resultCode < 0){
					return resultCode;
				}
				int size = bkDbList.size();
				// 统计流拍的金额
				BigDecimal total = new BigDecimal(0);
				// 全部中奖
				if(size == 3){
					this.log.debug("一等奖，二等奖，三等奖，全部被猜中！");
				}else if (size == 2){
					this.log.debug("一等奖，二等奖被猜中！，三等奖没有被猜中!");
					total = moneyTermTempThree;
				}else if (size == 1){
					this.log.debug("一等奖被猜中！二等奖,三等奖没有被猜中!");
					total = moneyTermTempTwo.add(moneyTermTempThree);
				}else{
					this.log.debug("一等奖，二等奖，三等奖，全部没有被猜中！");
					total = moneyTermTempOne.add(moneyTermTempTwo).add(moneyTermTempThree);
				}
				this.log.debug("流拍的金额："+total);
				// 查询下一天的 竞猜活动奖金设置表的数据
				Date nextQuizMoneyQuizDate = quizActivitiesDao_read.getCurrentDateOfNextQuizDateFormQuizMoney(exeDate);
				
				if (nextQuizMoneyQuizDate != null){
					QuizMoney quizMoney = new QuizMoney();
					quizMoney.setREC_MODIFYBY("system");
					quizMoney.setMoneyTerm(1);
					quizMoney.setMoney(total);
					quizActivitiesDao.updateQuizMoneyByQuizDate(quizMoney, DateUtil.convert(nextQuizMoneyQuizDate, "yyyy-MM-dd"));
				}else{
					this.log.debug("更新奖金池一等奖的金额："+total);
					// 更新奖金池
					quizActivitiesDao.updateQuizMoneyPoolByMoneyTerm(total, 1);
					// 根据：当前日期 获取 [竞猜活动合约价格表] 中的  下一个竞猜日期
					Date nextQuizActivityQuizDate = quizActivitiesDao_read.getCurrentDateOfNextQuizDateFormQuizActivity(exeDate);
					
					if(nextQuizActivityQuizDate != null){
						// 添加奖金设置表
						int code = addQuizMoney(nextQuizActivityQuizDate);
						if (code < 0){
							resultCode = -100012;//新增【竞猜活动奖金设置】异常！
							this.log.debug("新增【竞猜活动奖金设置】异常！");
						}
					}else{
						this.log.warn("下个【竞猜活动合约价格】的[竞猜日期]数据还未设定。");
					}
				}
			}else{
				this.log.debug("当前时间："+exeDate+",竞猜活动奖金设置表的数据不正确，条数："+quizMoneyListSize);
				resultCode = -100003;
			}
		}else{
			if (quizActivityListSize == 0){
				resultCode = -100007;//
				this.log.debug("未查询到当前执行时间的【竞猜活动合约】数据！原因可能是合约状态是未完善！");
			}else{
				resultCode = -100008;// 未查询到当前执行时间的【竞猜活动奖金设置】数据！
				this.log.debug("未查询到当前执行时间的【竞猜活动奖金设置】数据！");
			}
		}
		this.log.debug(QuizActivitiesComponentManagerImpl.class.getName()+" exeTheLottery Component End");
		return resultCode;
	}
	
	/**
	 * 更新中奖记录
	 */
	private Integer updateWinningResult(Integer resultCode,String date,List<QuizHistoryAndQuizActivity> qhaqaList,BigDecimal one,BigDecimal two,BigDecimal three){
		this.log.debug(QuizActivitiesComponentManagerImpl.class.getName()+" updateWinningResult Component Start");
		int code = resultCode;
		if (qhaqaList.size() > 0){
			// 插入竞猜中奖结果表
			QuizWinningResult quizWinningResult = new QuizWinningResult();
			List<Integer> idList = new ArrayList<Integer>();
			// 插入 竞猜中奖结果
			for (int i = 0; i < qhaqaList.size(); i++){
				QuizHistoryAndQuizActivity quizHistoryAndQuizActivity = qhaqaList.get(i);
				Integer quizHistoryId = quizHistoryAndQuizActivity.getQuizHistoryId();
				Integer quizActivityStatus = quizHistoryAndQuizActivity.getQuizActivityStatus();
				Integer quizHistoryStatus = quizHistoryAndQuizActivity.getQuizHistoryStatus();
				String contractName = quizHistoryAndQuizActivity.getContractName();
				Integer quizActivityID = quizHistoryAndQuizActivity.getQuizActivityID();
				this.log.debug("竞猜记录ID："+quizHistoryId+",竞猜活动状态："+quizActivityStatus +",竞猜记录状态:"+quizHistoryStatus);
				// 未开奖，审核通过
				if (quizHistoryStatus == 0 && quizActivityStatus == 5){
					quizWinningResult.setQuizHistoryID(quizHistoryId);
					quizWinningResult.setMoneyTerm(i+1);
					quizWinningResult.setQuizDate(DateUtil.formatDate(date, "yyyy-MM-dd"));
					if (i == 0){
						quizWinningResult.setBonus(one);
					}else if(i == 1){
						quizWinningResult.setBonus(two);
					}else if(i == 2){
						quizWinningResult.setBonus(three);
					}
					quizActivitiesDao.insertQuizWinningResult(quizWinningResult);
					
					idList.add(quizHistoryId);
				}else{
					// 竞猜活动合约 没有审核通过
					if (quizActivityStatus != 5){
						this.log.debug("竞猜活动合约:"+contractName+",竞猜活动合约ID:"+quizActivityID+",没有审核通过");
						code = -100005;
						break;
					}
					if (quizHistoryStatus != 0 ){
						this.log.debug("竞猜记录ID："+quizHistoryId+",竞猜活动状态:"+quizHistoryStatus+",当前竞猜记录已经被开奖！");
						code = -100006;
						break;
					}
				}
			}
			if(code >= 0 && idList.size() > 0){
				quizActivitiesDao.updateQueryGuizHistoryInIdList(2, idList, date);// 已中奖
				quizActivitiesDao.updateQueryGuizHistoryNotInIdList(1, idList, date);// 未中奖
			}
		}else{
			this.log.debug("date："+date+"，没有人猜中!");
			quizActivitiesDao.updateQueryGuizHistoryNotInIdList(1, null, date);// 未中奖
		}
		this.log.debug(QuizActivitiesComponentManagerImpl.class.getName()+" updateWinningResult Component End");
		return code;
	}
	
	@Override
	public int deleteQuizActivitie(String[] quizDateArray) {
		this.log.debug(QuizActivitiesComponentManagerImpl.class.getName()+" deleteQuizActivitie Component Start");
		int returnCode = 0;
		String quizDateString="'";
		for (int i = 0; i < quizDateArray.length; i++) {
			if(i>0)quizDateString += ",'";
			quizDateString += DataUtil.DateToString(DataUtil.StringToDate(quizDateArray[i]), "yyyy-MM-dd")+"'";
		}
		returnCode = this.quizActivitiesDao.deleteQuizActivitie(quizDateString);
		if(returnCode >= 0){
			returnCode = this.quizActivitiesDao.deleteQuizMoney(quizDateString);
			if(returnCode < 0){
				this.rollBack();
				return returnCode;
			}
		}
		this.log.debug(QuizActivitiesComponentManagerImpl.class.getName()+" deleteQuizActivitie Component End");
		return returnCode;
	}
	
	@Override
	public List<QuizActivity> getQuizActivitiesListByQuizDate(String[] quizDateArray) {
		this.log.info(this.getClass().getName()+" getQuizActivitiesListByQuizDate Start");
		List<QuizActivity> list = new ArrayList<QuizActivity>();
		for (int i = 0; i < quizDateArray.length; i++) {
			List<QuizActivity> listTemp = this.quizActivitiesDao_read.getQuizActivitieDetailByQuizDate(DataUtil.DateToString(DataUtil.StringToDate(quizDateArray[i]), "yyyy-MM-dd"));
			QuizActivity quizActivity = new QuizActivity();
			quizActivity.setQuizDate(DataUtil.StringToDate(quizDateArray[i]));
			if(listTemp != null && listTemp.size() > 0){
				quizActivity.setQuizDateBoolean(false);
			}else {
				quizActivity.setQuizDateBoolean(true);
			}
			list.add(quizActivity);
		}

		//日志
		this.log.info(this.getClass().getName()+" getQuizActivitiesListByQuizDate End ");
		return list;
	}
	
	private void rollBack() {
		quizActivitiesDao.rollBack();
	}
	@Override
	public boolean existsQuizActivity(Date quizDate) {
		this.log.info(this.getClass().getName()+" existsQuizActivity Start");
		boolean exists = false;
		String quizDateString = DataUtil.DateToString(quizDate);
		List<QuizActivity> list = this.quizActivitiesDao.getQuizActivitiesDetail(quizDateString);
		if(list != null && list.size() > 0)exists = true;
		this.log.info(this.getClass().getName()+" existsQuizActivity End");
		return exists;
	}
	
	/**
	 * 更新 竞猜活动合约价格表 的官方解读
	 * @param answer 官方解读
	 * @param modifyby 修改人
	 * @param quizDateStr 竞猜日期
	 * @param category 品类
	 * @return
	 */
	@Override
	public int updateQuizActivityOfAnswer(String answer, String modifyby, String quizDateStr) {
		this.log.info(this.getClass().getName()+" updateQuizActivityOfAnswer Start");
		int count = quizActivitiesDao.updateQuizActivityOfAnswer(answer, modifyby, quizDateStr);
		this.log.info(this.getClass().getName()+" updateQuizActivityOfAnswer End");
		return count;
	}

	@Override
	public QuizActivity getQuizActivityOfAnswer(String quizDateStr) {
		this.log.info(this.getClass().getName()+" getQuizActivityOfAnswer Start");
		String answer = "";
		QuizActivity qa = quizActivitiesDao_read.getQuizActivity(quizDateStr);
//		if (qa != null){
//			answer = qa.getAnswer();
//		}else{
//			this.log.info(this.getClass().getName()+" 没有查询到竞猜活动合约数据！");
//		}
		this.log.info(this.getClass().getName()+" getQuizActivityOfAnswer End");
		return qa;
	}

	@Override
	public int createQuizHistory(List<QuizHistoryVo> qhvList,Date quizDate,String userName) {
		this.log.info(this.getClass().getName()+" createQuizHistory Start");
		int resultCode = 0;
		List<QuizActivity> qaList = quizActivitiesDao_read.getQuizActivitiesDetail(DateUtil.convert(quizDate, "yyyy-MM-dd"));
		if (qaList.size() > 0){
			for (QuizHistoryVo qhv : qhvList){
				Integer category = qhv.getCategory();
				BigDecimal quizPrice = qhv.getQuizPrice();
				Integer cycleIndex = qhv.getCycleIndex();
				if (cycleIndex > 20){// 循环次数最多20
					cycleIndex = 20;
				}
				
				Integer quizActivityID = 0;
				for (QuizActivity qa : qaList){
					if (category.equals(qa.getCategory())){
						quizActivityID = qa.getId();
						break;
					}
				}
				
				if (quizActivityID != 0){
					for (int i = 0; i < cycleIndex; i++){
						QuizHistory qh = new QuizHistory();
						qh.setREC_CREATEBY(userName);
						qh.setREC_CREATETIME(quizDate);
						qh.setREC_MODIFYBY(userName);
						qh.setREC_MODIFYTIME(quizDate);
						qh.setQuizActivity_ID(quizActivityID);
						qh.setQuizPrice(quizPrice);
						qh.setSourceFrom(2);// 来源  后台
						quizActivitiesDao.insertQuizHistory(qh);
					}
				}
			}
		}else{
			resultCode = -100014;// 【竞猜日期】不存在！
		}
		this.log.info(this.getClass().getName()+" createQuizHistory End");
		return resultCode;
	}

	@Override
	public boolean getValidateQuizActivitiesList(String quizDate) {
		List<QuizActivity> list1 = new ArrayList<QuizActivity>();
		list1 = this.quizActivitiesDao_read.getValidateQuizActivitiesList(quizDate, " and Category = 1");
		
		List<QuizActivity> list2 = new ArrayList<QuizActivity>();
		list2 = this.quizActivitiesDao_read.getValidateQuizActivitiesList(quizDate, " and Category = 2");
		
		if(list1.size() == 1 && list2.size() == 1){
			return true;
		}else{
			return false;
		}
	}


	
}
