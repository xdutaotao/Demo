package shcem.market.service.model;

import java.io.Serializable;
import java.math.BigDecimal;
import shcem.base.dao.model.BaseObject;

public class QuizHistoryVo extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7684246128684884736L;
	// 竞猜价格
	private BigDecimal quizPrice;
	// 循环次数
	private Integer cycleIndex;
	// 品类 1.PP 2.PE
	private Integer category;


	public BigDecimal getQuizPrice() {
		return quizPrice;
	}

	public void setQuizPrice(BigDecimal quizPrice) {
		this.quizPrice = quizPrice;
	}

	public Integer getCycleIndex() {
		return cycleIndex;
	}

	public void setCycleIndex(Integer cycleIndex) {
		this.cycleIndex = cycleIndex;
	}

	public Integer getCategory() {
		return category;
	}

	public void setCategory(Integer category) {
		this.category = category;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
