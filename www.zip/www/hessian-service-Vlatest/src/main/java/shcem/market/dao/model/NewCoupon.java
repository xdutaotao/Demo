package shcem.market.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import shcem.base.dao.model.BaseObject;

public class NewCoupon extends BaseObject implements Serializable{

	/**
	 * 默认的序列id
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 主键id
	 */
	private Integer id;
	/**
	 * 优惠券名称
	 */
	private String couponName;
	/**
	 * 优惠券类型(1:抵扣型 2:充值型)
	 */
	private Integer couponType;
	/**
	 * 充值金额
	 */
	private BigDecimal rechargeAmount;
	/**
	 * 充值后的赠送送的金额
	 */
	private BigDecimal deductionAmount;
	/**
	 * 优惠券面额
	 */
	private BigDecimal amount;
	/**
	 * 优惠券状态(0:未启用 1:已启用)
	 */
	private Integer status;
	/**
	 * 优惠券说明
	 */
	private String remark;
	/**
	 * 是否删除(0:正常 1:失效)
	 */
	private Integer dISABLED;
	/**
	 * 创建人
	 */
	private String rEC_CREATEBY;
	/**
	 * 创建时间
	 */
	private Date rEC_CREATETIME;
	private String rEC_MODIFYBY;
	private Date rEC_MODIFYTIME;
	
	private Boolean auditFlag;
	//  约束最小交易金额
	private BigDecimal minAmount;
	// 约束最小交易重量
	private BigDecimal minWeight;
	// 优惠券类型交易场关联表
	List<NewCouponTemplateRel> newCouponTemplateRelList;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCouponName() {
		return couponName;
	}

	public void setCouponName(String couponName) {
		this.couponName = couponName;
	}

	public Integer getCouponType() {
		return couponType;
	}

	public void setCouponType(Integer couponType) {
		this.couponType = couponType;
	}

	public BigDecimal getRechargeAmount() {
		return rechargeAmount;
	}

	public void setRechargeAmount(BigDecimal rechargeAmount) {
		this.rechargeAmount = rechargeAmount;
	}

	public BigDecimal getDeductionAmount() {
		return deductionAmount;
	}

	public void setDeductionAmount(BigDecimal deductionAmount) {
		this.deductionAmount = deductionAmount;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getDISABLED() {
		return dISABLED;
	}

	public void setDISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Boolean getAuditFlag() {
		return auditFlag;
	}

	public void setAuditFlag(Boolean auditFlag) {
		this.auditFlag = auditFlag;
	}

	public BigDecimal getMinAmount() {
		return minAmount;
	}

	public void setMinAmount(BigDecimal minAmount) {
		this.minAmount = minAmount;
	}

	public BigDecimal getMinWeight() {
		return minWeight;
	}

	public void setMinWeight(BigDecimal minWeight) {
		this.minWeight = minWeight;
	}

	public List<NewCouponTemplateRel> getNewCouponTemplateRelList() {
		return newCouponTemplateRelList;
	}

	public void setNewCouponTemplateRelList(
			List<NewCouponTemplateRel> newCouponTemplateRelList) {
		this.newCouponTemplateRelList = newCouponTemplateRelList;
	}

}
