package shcem.market.component;

import java.util.List;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.market.dao.model.Attention;
import shcem.market.dao.model.ExportNewCouponTrans;
import shcem.market.dao.model.FollowStatistics;

/**
 * Created by lihaifeng on 2017/2/24.
 */
public interface IAttentionComponentManager extends Manager {

    /**
     * 查询获取关注明细
     * @param queryConditions
     * @param pageInfo
     * @return
     */
    List<Attention> getAttentionDetailedList(QueryConditions queryConditions, PageInfo pageInfo);

    /**
     * 获取关注类型
     * @return
     */
    List<Attention> getAttentionTypeList();
    
    /**
     * 查询关注明细总数
     * @param queryConditions
     * @param pageInfo
     * @return
     */
    int getExportAttentionDetailedCount(QueryConditions queryConditions, PageInfo pageInfo);
    
	/**
	 * 导出关注明细到Excel中
	 * @param replace 
	 * @param params
	 * @return
	 */
	List<Attention> getExportAttentionDetailedExcel(QueryConditions queryConditions, PageInfo pageInfo, boolean replace);
	
    /**
     * 关注统计
     * @param size
     * @return
     */
    List<FollowStatistics> getAttentionStatistics(int size);
    

}
