package shcem.market.component.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;

import scala.annotation.bridge;
import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.service.model.ValueTxtView;
import shcem.market.component.ICouponActivityComponentManager;
import shcem.market.dao.ICouponActivityDao;
import shcem.market.dao.model.CouponTrans;
import shcem.market.dao.model.ExportNewCouponTrans;
import shcem.market.dao.model.NewCoupon;
import shcem.market.dao.model.NewCouponTemplateRel;
import shcem.market.dao.model.NewCouponTrans;
import shcem.market.dao.model.NewCouponActivity;
import shcem.market.service.model.ActivityTempCoupon;
import shcem.market.service.model.amoutDateModel;
import shcem.systemMgr.util.GenerateRandomUtil;
import shcem.util.DataUtil;
import shcem.util.DateUtil;

/**
 * 
 * @author wangj
 *
 */
public class CouponActivityComponnetManagerImpl  extends BaseManager implements ICouponActivityComponentManager{
	
	private ICouponActivityDao couponActivityDao;
	private ICouponActivityDao couponActivityDao_read;

	public void setCouponActivityDao(ICouponActivityDao couponActivityDao) {
		this.couponActivityDao = couponActivityDao;
	}

	public void setCouponActivityDao_read(ICouponActivityDao couponActivityDao_read) {
		this.couponActivityDao_read = couponActivityDao_read;
	}

	@Override
	public List<NewCoupon> queryCouponTypeList(QueryConditions qc,
			PageInfo pageInfo) {
		// TODO Auto-generated method stub
		List<NewCoupon> list = couponActivityDao_read.queryCouponTypeList(qc, pageInfo);
		if (list !=null && list.size() > 0) {
			for (NewCoupon newCoupon : list) {
				newCoupon.setAuditFlag(this.couponActivityDao_read.checkCouponTypeAuditFlag(newCoupon.getId()));
			}
		}   
		return list;
	}

	@Override
	public int insertCouponType(NewCoupon newCoupon) {
		int code = 0;
		if(newCoupon.getId()!=null){
			Integer ID = newCoupon.getId();
			// 更新 优惠券定义表
			couponActivityDao.updateCouponType(newCoupon);
			if (newCoupon.getCouponType() == 1){
				// 删除 优惠券类型交易场关联表
				couponActivityDao.deleteNewCouponTemplateRelByNewCouponID(ID);
				List<NewCouponTemplateRel> list = newCoupon.getNewCouponTemplateRelList();
				for (NewCouponTemplateRel rel : list){
					rel.setNewCouponID(ID);
				}
				// 插入 优惠券类型交易场关联表
				couponActivityDao.insertNewCouponTemplateRel(list);
			}
			
		}else{
			if(this.couponActivityDao.getNewCouponList(newCoupon.getCouponName())){
				code = -80001;
			}else {
				// 插入  优惠券定义表
				int ID = couponActivityDao.insertCouponType(newCoupon);
				if (newCoupon.getCouponType() == 1){
					List<NewCouponTemplateRel> list = newCoupon.getNewCouponTemplateRelList();
					for (NewCouponTemplateRel rel : list){
						rel.setNewCouponID(ID);
					}
					// 插入 优惠券类型交易场关联表
					couponActivityDao.insertNewCouponTemplateRel(list);
				}
			}
		}
		return code;
	}

	@Override
	public int delCouponType(int id, int dISABLED) {
		this.log.info(this.getClass().getName()+" delCouponType Start");
		int returnCode = 0;
		/**
		 * 1.删除优惠券类型
		 */
		returnCode = couponActivityDao.delCouponType(id,dISABLED);
		/**
		 * 2.删除优惠券活动关联表(待审核、审核拒绝)
		 */
		returnCode = this.couponActivityDao.delNewCouponActivityRelByCouponID(id);
		/**
		 * 3.优惠券类型交易场关联表
		 */
		this.couponActivityDao.deleteNewCouponTemplateRelByNewCouponID(id);
		this.log.info(this.getClass().getName()+" delCouponType End");
		if(returnCode == -1)this.rollBack();
		return returnCode;
	}

	/**
	 * 优惠券使用记录
	 */
	@Override
	public List<NewCouponTrans> getCouponFlowingWaterList(QueryConditions qc, PageInfo pageInfo) {
		// TODO Auto-generated method stub
		return couponActivityDao_read.getCouponFlowingWaterList(qc, pageInfo,false);
	}
	
	/**
	 * 查询过滤未发送的优惠券[去掉已经过期的优惠券]
	 */
	@Override
	public List<NewCouponTrans> getCouponNoUsedList(QueryConditions qc, PageInfo pageInfo,boolean replace) {
		// TODO Auto-generated method stub
		return couponActivityDao_read.getCouponNoUsedList(qc, pageInfo,false);
	}
	
	
	@Override
	public int getExportCouponFlowingWaterCount(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+" getExportCouponFlowingWaterCount Start");
		int totalCount = this.couponActivityDao_read.getExportCouponFlowingWaterCount(qc,pageInfo);
		this.log.info(this.getClass().getName()+" getExportCouponFlowingWaterCount End");
		return totalCount;
	}
	/**
	 * 导出优惠券使用记录
	 */
	@Override
	public List<ExportNewCouponTrans> exportCouponFlowingWaterList(QueryConditions qc, PageInfo pageInfo,boolean replace) {
		// TODO Auto-generated method stub
		this.log.info(this.getClass().getName()+".exportCouponFlowingWaterList() component Start");
		List<NewCouponTrans> list = couponActivityDao_read.getCouponFlowingWaterList(qc, pageInfo,replace);
		List<ExportNewCouponTrans> exportList = new ArrayList<ExportNewCouponTrans>();
		ExportNewCouponTrans exportNewCouponTrans = null;
		for (NewCouponTrans newCouponTrans : list ){
			
			exportNewCouponTrans = new ExportNewCouponTrans();
			
			exportNewCouponTrans.setCouponNumber(newCouponTrans.getCouponNumber());
			exportNewCouponTrans.setExchangeCode(newCouponTrans.getExchangeCode());
			exportNewCouponTrans.setActivityName(newCouponTrans.getActivityName());
			exportNewCouponTrans.setCouponName(newCouponTrans.getCouponName());
			//1抵扣型 2充值型
			String couponTypeName = "";
			switch (newCouponTrans.getCouponType()) {
			case 1: couponTypeName = "抵扣型"; break;
			case 2: couponTypeName = "充值型"; break;
			default:
				break;
			}
			exportNewCouponTrans.setCouponTypeName(couponTypeName);
			exportNewCouponTrans.setAmount(newCouponTrans.getAmount());
			if(newCouponTrans.getBuyCouponTradeFee() == null){
				if(newCouponTrans.getCouponType() ==2 ){
					exportNewCouponTrans.setBuyCouponTradeFee("-"); 
				}else{
					exportNewCouponTrans.setBuyCouponTradeFee("0元");
				}
			}else{
				exportNewCouponTrans.setBuyCouponTradeFee(newCouponTrans.getBuyCouponTradeFee()+"元"); 
			}
			//exportNewCouponTrans.setDeductibleAmount(newCouponTrans.getDeductibleAmount()); 
			exportNewCouponTrans.setReceiveDate(DateUtil.convert(newCouponTrans.getReceiveDate(), "yyyy/MM/dd HH:mm:ss"));
			exportNewCouponTrans.setUseDate(DateUtil.convert(newCouponTrans.getUseDate(), "yyyy/MM/dd HH:mm:ss"));
			exportNewCouponTrans.setFirmId(newCouponTrans.getFirmId());
			exportNewCouponTrans.setFirmName(newCouponTrans.getFirmName());
			exportNewCouponTrans.setTraderID(newCouponTrans.getTraderID());
			exportNewCouponTrans.setTraderName(newCouponTrans.getTraderName());
			exportNewCouponTrans.setOrderId(newCouponTrans.getOrderId());
			//exportNewCouponTrans.setUserName(newCouponTrans.getUserName());
			
			//状态(0：未领取 1:已发放(已领取) 3：已领取（已兑换） 5：已使用 10：已失效)
		    String statusName = "";
		    switch (newCouponTrans.getStatus()) {
		    case 0: statusName = "未领取"; break;
		    case 1: statusName = "已发放"; break;
		    case 3: statusName = "已领取"; break;
		    case 5: statusName = "已使用"; break;
		    case 10: statusName = "已失效 ";break;
		    default:
		       break;
		    }
			
			exportNewCouponTrans.setStatusName(statusName);
			
			exportList.add(exportNewCouponTrans);
		}
		this.log.info(this.getClass().getName()+".exportCouponFlowingWaterList() component End");
		return exportList;
	}
	
	/**
	 * 导出未发放优惠券记录
	 */
	@Override
	public List<ExportNewCouponTrans> exportCouponUnissuedList(QueryConditions qc, PageInfo pageInfo, boolean replace) {
		// TODO Auto-generated method stub
		this.log.info(this.getClass().getName()+".exportCouponUnissuedList() component Start");
		List<NewCouponTrans> list = couponActivityDao_read.getCouponNoUsedList(qc, pageInfo,replace);
		List<ExportNewCouponTrans> exportList = new ArrayList<ExportNewCouponTrans>();
		ExportNewCouponTrans exportNewCouponTrans = null;
		for (NewCouponTrans newCouponTrans : list ){
			
			exportNewCouponTrans = new ExportNewCouponTrans();
			
			exportNewCouponTrans.setCouponNumber(newCouponTrans.getCouponNumber());
			exportNewCouponTrans.setExchangeCode(newCouponTrans.getExchangeCode());
			exportNewCouponTrans.setActivityName(newCouponTrans.getActivityName());
			exportNewCouponTrans.setCouponName(newCouponTrans.getCouponName());
			//1抵扣型 2充值型
			String couponTypeName = "";
			switch (newCouponTrans.getCouponType()) {
			case 1: couponTypeName = "抵扣型"; break;
			case 2: couponTypeName = "充值型"; break;
			default:
				break;
			}
			exportNewCouponTrans.setCouponTypeName(couponTypeName);
			exportNewCouponTrans.setAmount(newCouponTrans.getAmount());
			if(newCouponTrans.getBuyCouponTradeFee() == null){
				if(newCouponTrans.getCouponType() ==2 ){
					exportNewCouponTrans.setBuyCouponTradeFee("-"); 
				}else{
					exportNewCouponTrans.setBuyCouponTradeFee("0元");
				}
			}else{
				exportNewCouponTrans.setBuyCouponTradeFee(newCouponTrans.getBuyCouponTradeFee()+"元"); 
			}
			//exportNewCouponTrans.setDeductibleAmount(newCouponTrans.getDeductibleAmount()); 
			exportNewCouponTrans.setReceiveDate(DateUtil.convert(newCouponTrans.getReceiveDate(), "yyyy/MM/dd HH:mm:ss"));
			exportNewCouponTrans.setUseDate(DateUtil.convert(newCouponTrans.getUseDate(), "yyyy/MM/dd HH:mm:ss"));
			exportNewCouponTrans.setFirmId(newCouponTrans.getFirmId());
			exportNewCouponTrans.setFirmName(newCouponTrans.getFirmName());
			exportNewCouponTrans.setTraderID(newCouponTrans.getTraderID());
			exportNewCouponTrans.setTraderName(newCouponTrans.getTraderName());
			exportNewCouponTrans.setOrderId(newCouponTrans.getOrderId());
			//exportNewCouponTrans.setUserName(newCouponTrans.getUserName());
			
			//状态(0：未领取 1:已发放(已领取) 3：已领取（已兑换） 5：已使用 10：已失效)
		    String statusName = "";
		    switch (newCouponTrans.getStatus()) {
		    case 0: statusName = "未领取"; break;
		    case 1: statusName = "已发放"; break;
		    case 3: statusName = "已领取"; break;
		    case 5: statusName = "已使用"; break;
		    case 10: statusName = "已失效 ";break;
		    default:
		       break;
		    }
			
			exportNewCouponTrans.setStatusName(statusName);
			
			exportList.add(exportNewCouponTrans);
		}
		this.log.info(this.getClass().getName()+".exportCouponUnissuedList() component End");
		return exportList;
	}
	
	
	@Override
	public List<NewCouponActivity> queryCouponActivityList(QueryConditions qc,
			PageInfo pageInfo) {
		// TODO Auto-generated method stub
		List<NewCouponActivity> list = couponActivityDao_read.queryCouponActivityList(qc,pageInfo);
		if(list != null && list.size() > 0){
			for (NewCouponActivity newCouponActivity : list) {
				Date tempDate = DataUtil.getDateWithOutTime(new Date());
				Date activityEndDate = DataUtil.getDateWithOutTime(newCouponActivity.getActivityEndDate());
				newCouponActivity.setOutDateFlag(tempDate.compareTo(activityEndDate) <= 0 ? true:false);
//				Date tempDate = new Date();
//				newCouponActivity.setOutDateFlag(!tempDate.after(newCouponActivity.getActivityEndDate()));
			}
		}
		return list;
	}

	@Override
	public int sendCouponForUserCode(Integer Id, String userCode, String userID, Integer couponStatus,String traderID, String firmID) {
		this.log.info(this.getClass().getName()+".sendCouponForUserCode() component Start");
		int resultCode = 0;
		// 查询当前优惠券是否已经产生
		NewCouponTrans newCouponTrans = couponActivityDao.getNewCouponTransByID(Id);
		if (newCouponTrans != null){
			Integer status = newCouponTrans.getStatus();
			if (status == 0){
				// 更新发放优惠券 状态 为已领取
				int count = couponActivityDao.sendCouponForUserCode(Id, userCode, couponStatus, userID, traderID, firmID);
				if (count > 0){
					this.log.debug("发送给【userCode:"+userCode+"】优惠券成功！");
				}else{
					this.log.debug("未更新成功");
				}
			}else{
				if (status == 1){
					resultCode = -90002;// 
				}else if (status == 3){
					resultCode = -90007;// 
				}else if (status == 5){
					resultCode = -90003;// 
				}else if (status == 10){
					resultCode = -90004;// 
				}else{
					resultCode = -90006;
				}
			}
		}else{
			resultCode = -90005;// 
		}
		this.log.info(this.getClass().getName()+".sendCouponForUserCode() component End");
		return resultCode;
	}
	
	/**
	 * 发送兑换码
	 */
	@Override
	public int sendCouponForUserCodeExchangeCode(Integer Id, String userID, Integer couponStatus) {
		this.log.info(this.getClass().getName()+".sendCouponForUserCodeExchangeCode() component Start");
		int resultCode = 0;
		// 查询当前优惠券是否已经产生
		NewCouponTrans newCouponTrans = couponActivityDao.getNewCouponTransByID(Id);
		if (newCouponTrans != null){
			Integer status = newCouponTrans.getStatus();
			if (status == 0){
				// 更新发放优惠券 状态 为已发放
				int count = couponActivityDao.sendCouponForUserCodeExchangeCode(Id, couponStatus, userID);
				if (count > 0){
					this.log.debug("发送给【userID:"+userID+"】优惠券成功！");
				}else{
					this.log.debug("未更新成功");
				}
			}else{
				if (status == 1){
					resultCode = -90002;// 
				}else if (status == 3){
					resultCode = -90007;// 
				}else if (status == 5){
					resultCode = -90003;// 
				}else if (status == 10){
					resultCode = -90004;// 
				}else{
					resultCode = -90006;
				}
			}
		}else{
			resultCode = -90005;// 
		}
		this.log.info(this.getClass().getName()+".sendCouponForUserCodeExchangeCode() component End");
		return resultCode;
	}

	@Override
	public int markupNewCouponTransOfStatus(int[] IdArr, String userID) {
		int count = 0;
		for (Integer id : IdArr){
			NewCouponTrans newCouponTrans = couponActivityDao.getNewCouponTransByID(id);
			if (newCouponTrans != null){
				if(newCouponTrans.getStatus() == 0){// 未领取
					couponActivityDao.updateNewCouponTransOfStatusByID(id, 1, userID);
					count++;
				}else{
					this.log.debug("当时优惠券的状态是Status："+newCouponTrans.getStatus());
				}
			}
		}
		return count;
	}

	@Override
	public int insertOrUpdateActivity(ActivityTempCoupon activityTempCoupon, String userName) {
		// TODO Auto-generated method stub
		int returnCode = 0;
		if(activityTempCoupon.getId()!=null){//编辑
			returnCode =  this.updateActivity(activityTempCoupon,userName);
		}else{//创建
			returnCode = this.insertActivity(activityTempCoupon,userName);
		}
		return returnCode;
	}


	@Override
	public int auditActivity(NewCouponActivity newCouponActivity,
			String userName,boolean auditFlag) {
		this.log.info(this.getClass().getName()+" auditActivity Start");
		long start = System.currentTimeMillis();
		int returnCode = 0;
		/**
		 * 1.更新活动表(通过/拒绝)
		 */
		returnCode = couponActivityDao.updateAuditStatus(newCouponActivity, userName,auditFlag);
		if(returnCode == -1) return returnCode;
		
		if(auditFlag){
			returnCode = this.couponActivityDao.updateNewCouponActivityRelAuditStatus(newCouponActivity.getId(),5);
			if(returnCode == -1) {
				this.rollBack();
				return returnCode;
			}
			/**
			 * 2.查询活动和优惠券的关系记录表，记录到优惠券流水记录中
			 */
			List<amoutDateModel> amoutDateList = this.couponActivityDao.getAmoutDateList(newCouponActivity.getId());
			if (amoutDateList != null && amoutDateList.size() > 0) {
				for (amoutDateModel amoutDateModel : amoutDateList) {
					int maxQuantity = amoutDateModel.getMaxQuantity();
					String headChar = amoutDateModel.getCouponType()==1?"D":"C";//D:抵扣型优惠券;C:充值型优惠券
					String sysDate = DataUtil.DateToString(new Date(), "yyMMdd");
					String couponNumber = newCouponActivity.getId()+headChar+sysDate;//生成优惠券号码（生成规则:活动ID+手续费类型（D:抵扣型优惠券;C:充值型优惠券）+生成时间（YYMMDD）+SEQ（6位）） 
					int newCouponTransCount = this.couponActivityDao.getNewCouponTransCount();
					if( maxQuantity > 0){
						List<CouponTrans> couponNumberList = getCouponNumberList(couponNumber, maxQuantity,newCouponTransCount);
						returnCode = this.couponActivityDao.addBatchCouponTrans(amoutDateModel, newCouponActivity.getId(), userName, couponNumberList);
						if(returnCode < 0)break;
					}else {
						this.rollBack();
						returnCode = -1;
						break;
					}					
				}
			}
		}else {
			returnCode = this.couponActivityDao.updateNewCouponActivityRelAuditStatus(newCouponActivity.getId(),10);
			if(returnCode == -1) {
				this.rollBack();
				return returnCode;
			}
		}
		this.log.info(this.getClass().getName()+" auditActivity End");
		long end = System.currentTimeMillis();
		long tempCount = end - start;
		System.out.println("批量新增用时: "+tempCount+" 毫秒");//
		return returnCode;
	}
	
	/**
	 * 校验优惠券号码是否重复
	 * @param couponNumber
	 * @return
	 */
	private String checkCouponNumber(String couponNumber) {
		couponNumber += GenerateRandomUtil.generateShortUuid(6);
		boolean checkStatus = false;
		checkStatus = this.couponActivityDao.checkCouponNumber(couponNumber);
		if(checkStatus){
			this.checkCouponNumber(couponNumber);
		}
		return couponNumber;
	}
	
	
	/**
	 * 
	 * @param couponNumber 
	 * @param maxQuantity 本次批量新增优惠券个数
	 * @param newCouponTransCount 现有库中优惠券个数
	 * @return
	 */
	private List<CouponTrans> getCouponNumberList(String couponNumber,int maxQuantity,int newCouponTransCount){
		this.log.info(this.getClass().getName()+" getCouponNumberList Start");
		long start = System.currentTimeMillis();
		List<CouponTrans> couponNumberList = new ArrayList<CouponTrans>();
		for (int i = 0; i < maxQuantity; i++) {
			String couponNumberTemp = couponNumber;
			int total = newCouponTransCount+maxQuantity/10;
			if(total == 0){
				couponNumberTemp = couponNumber+""+GenerateRandomUtil.generateShortUuid(2)+"00000"+(newCouponTransCount+i);
			}else if(total >= 1 && total <= 9){
				couponNumberTemp = couponNumber+""+GenerateRandomUtil.generateShortUuid(2)+"0000"+(newCouponTransCount+i);
			}else if(total >= 10 && total <= 99){
				couponNumberTemp = couponNumber+""+GenerateRandomUtil.generateShortUuid(2)+"000"+(newCouponTransCount+i);
			}else if(total >= 100 && total <= 999){
				couponNumberTemp = couponNumber+""+GenerateRandomUtil.generateShortUuid(2)+"00"+(newCouponTransCount+i);
			}else if(total >= 1000 && total <= 9999){
				couponNumberTemp = couponNumber+""+GenerateRandomUtil.generateShortUuid(2)+"0"+(newCouponTransCount+i);
			}else if(total >= 10000 && total <= 99999){
				couponNumberTemp = couponNumber+""+GenerateRandomUtil.generateShortUuid(2)+""+(newCouponTransCount+i);
			}else if(total >= 100000 && total <= 999999){
				couponNumberTemp = couponNumber+""+GenerateRandomUtil.generateShortUuid(1)+""+(newCouponTransCount+i);
			}else {
				couponNumberTemp = couponNumber+""+(newCouponTransCount+i);
			}
			CouponTrans couponTrans = new CouponTrans();
			couponTrans.setCouponNumber(couponNumberTemp);
			couponTrans.setExchangeCode(GenerateRandomUtil.generateShortUuid(8));
			couponNumberList.add(couponTrans);
		}
		this.log.info(this.getClass().getName()+" getCouponNumberList Start");
		long end = System.currentTimeMillis();
		long tempCount = end - start;
		System.out.println("批量新增用时: "+tempCount+" 毫秒");//
		return couponNumberList;
	}
	
	private int insertActivity(ActivityTempCoupon activityTempCoupon,String userName) {
		int returnCode = 0;
		/**
		 * 1.活动表插入数据
		 */
		if(this.couponActivityDao.getNewCouponActivity(activityTempCoupon.getActivityName())){
			return -80001;
		}
		returnCode = couponActivityDao.insertActivity(activityTempCoupon);
		activityTempCoupon.setId(returnCode);
		if(returnCode == -1) return returnCode;
		
		/**
		 * 2.活动交易场表插数据
		 */
		int[] tempArray;
		if(activityTempCoupon.getTempArray() != null && activityTempCoupon.getTempArray().length > 0){
			tempArray = activityTempCoupon.getTempArray(); 
			for (int i = 0; i < tempArray.length; i++) {
				returnCode = couponActivityDao.insertActivityTempRel(tempArray[i],activityTempCoupon.getId());
				if(returnCode ==-1){
					this.rollBack();
					return returnCode;
				}
			}
		}
		
		/**
		 * 3.判断优惠券发放上限是否大于0，和优惠券有效期是否为null（都满足:往优惠券活动关系表插入数据）
		 */
		int activityID = activityTempCoupon.getId();
		List<amoutDateModel> list = activityTempCoupon.getAmoutDateModelList();
		if(list != null && list.size()>0){
			for (int i = 0; i < list.size(); i++) {
				if(list.get(i).getMaxQuantity() > 0  && list.get(i).getCouponValidStartDate() != null && list.get(i).getCouponValidEndDate() != null){
					returnCode = couponActivityDao.insertActivityCouponRel(list.get(i),activityID,userName,1);
					if(returnCode == -1){
						this.rollBack();
						return returnCode;
					}
				}
			}
		}
		return returnCode;
	}
	
	private int updateActivity(ActivityTempCoupon activityTempCoupon,String userName) {
		int returnCode = 0;
		/**
		 * 1.先删除关系表（交易场活动关系表）
		 */
		returnCode = couponActivityDao.delActivityTemp(activityTempCoupon.getId());
		if(returnCode == -1) return returnCode;
		
		/**
		 * 2.删除'活动优惠券发放情况表'相关记录
		 */
		
		returnCode = this.couponActivityDao.delNewCouponActivityRel(activityTempCoupon.getId());
		if(returnCode == -1){
			this.rollBack();
			return returnCode;
		}
		/**
		 * 3.更新活动表
		 */
		returnCode = couponActivityDao.updateActivity(activityTempCoupon);
		if(returnCode == -1){
			this.rollBack();
			return returnCode;
		}
		
		/**
		 * 4.新增交易场活动关系表
		 */
		int[] tempArray;
		if(activityTempCoupon.getTempArray() != null && activityTempCoupon.getTempArray().length > 0){
			tempArray = activityTempCoupon.getTempArray(); 
			for (int i = 0; i < tempArray.length; i++) {
				returnCode = couponActivityDao.insertActivityTempRel(tempArray[i],activityTempCoupon.getId());
				if(returnCode ==-1){
					this.rollBack();
					return returnCode;
				}
			}
		}
		
		/**
		 * 5.判断优惠券发放上限是否大于0，和优惠券有效期是否为null（都满足:往优惠券活动关系表插入数据）
		 */
		int activityID = activityTempCoupon.getId();
		List<amoutDateModel> list = activityTempCoupon.getAmoutDateModelList();
		if(list != null && list.size()>0){
			for (int i = 0; i < list.size(); i++) {
				if(list.get(i).getMaxQuantity() > 0  && list.get(i).getCouponValidStartDate() != null && list.get(i).getCouponValidEndDate() != null){
					returnCode = couponActivityDao.insertActivityCouponRel(list.get(i),activityID,userName,1);
					if(returnCode == -1){
						this.rollBack();
						return returnCode;
					}
				}
			}
		}
		
		return returnCode;
	}
	
	@Override
	public List<NewCoupon> getCouponList(Integer[] IDArray) {
		return this.couponActivityDao_read.getCouponList(IDArray);
	}
	
	
	@Override
	public ActivityTempCoupon getActivityByID(int activityID) {
		this.log.info(this.getClass().getName()+" getActivityByID Start");
		/**
		 * 1.活动详情 
		 */
		ActivityTempCoupon activityTempCoupon = this.couponActivityDao_read.getActivityByID(activityID);
		
		/**
		 * 2.获取交易场id数组
		 */
		List<ValueTxtView> tempList = this.couponActivityDao_read.getTempList(activityID);
		if(tempList != null && tempList.size() > 0){
			int[] tempArrayIDs = new int[tempList.size()];
			for (int i = 0; i < tempList.size(); i++) {
				tempArrayIDs[i] = tempList.get(i).getTagID();
			}
			activityTempCoupon.setTempArray(tempArrayIDs);
		}
		
		/**
		 * 3.获取相关优惠券对象数组(编辑和审核的)
		 */
		//编辑Or审核
		List<amoutDateModel> couponactivityRelEditList = this.couponActivityDao_read.getgetcouponActivityRelEditList(activityID);
		activityTempCoupon.setAmoutDateModelEditList(couponactivityRelEditList);
		//所有活动详情
		List<amoutDateModel> couponactivityRelList = this.couponActivityDao_read.getcouponActivityRelList(activityID);
		activityTempCoupon.setAmoutDateModelList(couponactivityRelList);
		
		this.log.info(this.getClass().getName()+" getActivityByID End");
		return activityTempCoupon;
	}
	
	@Override
	public int addOrEditReissueActivity(ActivityTempCoupon activityTempCoupon,String userName) {
		this.log.info(this.getClass().getName()+" addOrEditReissueActivity Start");
		int returnCode = 0;
		// 查询活动信息
		ActivityTempCoupon activity = couponActivityDao.getActivityByID(activityTempCoupon.getId());
		if (activity != null){
			Integer auditStates = activity.getAuditStates();// 审核状态(1:待审核 3:补发待审核 5:审核通过 10:审核拒绝)
			if (auditStates == 5){// 审核通过后才能补发优惠券
				returnCode = reissueAddCoupon(activityTempCoupon,userName);// 新增补发优惠券
			}else{
				if (auditStates == 3 || auditStates == 15){// 审核状态是3或15时，才能编辑
					if (auditStates == 15){
						couponActivityDao.updateNewCouponActivityAuditStatus(activityTempCoupon.getId(), userName,15, 3);// 补发待审核
					}
					reissueEditCoupon(activityTempCoupon,userName,auditStates);//  编辑补发优惠券
				}else{
					returnCode = -90018;// 当前活动的审核状态不能进行补发操作！
				}
			}
		}else{
			returnCode = -90017; // 未查询到活动信息！
		}
		this.log.info(this.getClass().getName()+" addOrEditReissueActivity End");
		return returnCode;
	}
	
	private void rollBack(){
		this.couponActivityDao.rollBack();
	}
	
	@Override
	public int resetActivityStatus(Integer id, Integer flag) {
		this.log.info(this.getClass().getName()+" resetActivityStatus Start");
		int returnCode = 0;
		returnCode = couponActivityDao.resetActivityStatus(id,flag);
		this.log.info(this.getClass().getName()+" resetActivityStatus End");
		return returnCode;
	}
	
	@Override
	public int getExportCouponUnissuedCount(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+" getExportCouponUnissuedCount Start");
		int totalCount = this.couponActivityDao_read.getExportCouponUnissuedCount(qc,pageInfo);
		this.log.info(this.getClass().getName()+" getExportCouponUnissuedCount End");
		return totalCount;
	}
	
	/**
	 * 新增补发优惠券
	 * @param activityTempCoupon
	 * @param userName
	 * @return
	 */
	private int reissueAddCoupon(ActivityTempCoupon activityTempCoupon,String userName){
		this.log.debug(this.getClass().getName()+"reissueAddCoupon Start");
		int code = 0;
		// 更新
		int count = couponActivityDao.updateNewCouponActivityAuditStatus(activityTempCoupon.getId(), userName,5, 3);// 补发待审核
		if (count > 0){
			addNewCouponActivityRel(activityTempCoupon,userName);//  新增 活动优惠券发放情况表 
		}else{
			code = -90016;// 更新活动的审核状态异常！
		}
		this.log.debug(this.getClass().getName()+"reissueAddCoupon End");
		return code;
	}
	
	/**
	 * 编辑补发优惠券
	 * @param activityTempCoupon
	 * @param userName
	 * @return
	 */
	private int reissueEditCoupon(ActivityTempCoupon activityTempCoupon,String userName,Integer state){
		this.log.debug(this.getClass().getName()+"reissueEditCoupon Start");
		int code = 0;
		// 删除 当前活动下 【活动优惠券发放情况表】中 审核状态是补发待审核的数据
		int count = this.couponActivityDao.delNewCouponActivityRel(activityTempCoupon.getId(),state);
		if (count > 0){
			addNewCouponActivityRel(activityTempCoupon,userName);//  新增 活动优惠券发放情况表 
		}else{
			this.log.debug("活动ID:"+activityTempCoupon.getId()+",【活动优惠券发放情况表】中 没有 审核状态是[补发待审核]的数据。");
		}
		this.log.debug(this.getClass().getName()+"reissueEditCoupon End");
		return code;
	}
	
	/**
	 * 新增 活动优惠券发放情况表 
	 */
	private void addNewCouponActivityRel(ActivityTempCoupon activityTempCoupon,String userName){
		this.log.debug("addNewCouponActivityRel Start");
		for (amoutDateModel data : activityTempCoupon.getAmoutDateModelList()) {
			//优惠券类型
			data.setCouponType(this.couponActivityDao.getCouponType(data.getCouponID()));
			if(data.getMaxQuantity() > 0  && data.getCouponValidStartDate() != null && data.getCouponValidEndDate() != null){
				int code = this.couponActivityDao.insertActivityCouponRel(data, activityTempCoupon.getId(),userName,3);// 补发待审核
				if(code == -1){
					this.log.error(this.getClass().getName()+" addMoreActivity 参数有误");
					break;
				}
			}
		}
		this.log.debug("addNewCouponActivityRel End");
	}

	
	@Override
	public int reissueAuditActivity(NewCouponActivity newCouponActivity,String userName, boolean auditFlag) {

		this.log.info(this.getClass().getName()+" reissueAuditActivity Start");
		int returnCode = 0;
		// 活动ID
		Integer activityId = newCouponActivity.getId();
		
		ActivityTempCoupon activity = couponActivityDao.getActivityByID(activityId);
		if (activity != null){
			Integer auditStates = activity.getAuditStates();// 审核状态(1:待审核 3:补发待审核 5:审核通过 10:审核拒绝 15:补发拒绝)
			if (auditStates == 3){
				Integer  newAuditStates = 5;
				if(!auditFlag){// 拒绝
					newAuditStates = 15;
				}
				// 查询待补发的优惠券
				List<amoutDateModel> amoutDateList = this.couponActivityDao.getReissueAmoutDateList(activityId);
				// 更新活动表
				couponActivityDao.updateNewCouponActivityAuditStatus(activityId, userName, auditStates,newAuditStates);
				// 更新 活动优惠券发放情况表
				this.couponActivityDao.updateNewCouponActivityRelAuditStatus(activityId, userName, auditStates, newAuditStates);
				if (auditFlag){
					for (amoutDateModel amoutDateModel : amoutDateList) {
						int maxQuantity = amoutDateModel.getMaxQuantity();
						String headChar = amoutDateModel.getCouponType()==1?"D":"C";//D:抵扣型优惠券;C:充值型优惠券
						String sysDate = DataUtil.DateToString(new Date(), "yyMMdd");
						String couponNumber = newCouponActivity.getId()+headChar+sysDate;//生成优惠券号码（生成规则:活动ID+手续费类型（D:抵扣型优惠券;C:充值型优惠券）+生成时间（YYMMDD）+SEQ（6位）） 
						int newCouponTransCount = this.couponActivityDao.getNewCouponTransCount();
						if( maxQuantity > 0){
							List<CouponTrans> couponNumberList = getCouponNumberList(couponNumber, maxQuantity,newCouponTransCount);
							returnCode = this.couponActivityDao.addBatchCouponTrans(amoutDateModel, newCouponActivity.getId(), userName, couponNumberList);
							if(returnCode < 0)break;
						}else {
							this.rollBack();
							returnCode = -1;
							break;
						}					
					}
				}
			
			}else{
				returnCode = -90018;// 当前活动的审核状态不能进行补发操作！
			}
		}else{
			returnCode = -90017;// 未查询到活动信息！
		}
		this.log.info(this.getClass().getName()+" reissueAuditActivity End");
		return returnCode;
	}

	@Override
	public ActivityTempCoupon getReissueActivityByID(int activityID) {
		this.log.info(this.getClass().getName()+" getReissueActivityByID Start");
		/**
		 * 1.活动详情 
		 */
		ActivityTempCoupon activityTempCoupon = this.couponActivityDao_read.getActivityByID(activityID);
		
		/**
		 * 2.获取交易场id数组
		 */
		List<ValueTxtView> tempList = this.couponActivityDao_read.getTempList(activityID);
		if(tempList != null && tempList.size() > 0){
			int[] tempArrayIDs = new int[tempList.size()];
			for (int i = 0; i < tempList.size(); i++) {
				tempArrayIDs[i] = tempList.get(i).getTagID();
			}
			activityTempCoupon.setTempArray(tempArrayIDs);
		}
		
		/**
		 * 3.获取相关优惠券对象数组
		 */
		List<amoutDateModel> couponactivityRelEditList = this.couponActivityDao_read.getReissueCouponActivityRelList(activityID);
		activityTempCoupon.setAmoutDateModelEditList(couponactivityRelEditList);
		
		this.log.info(this.getClass().getName()+" getReissueActivityByID End");
		return activityTempCoupon;
	}

	@Override
	public NewCoupon getNewCouponInfoByID(Integer ID) {
		this.log.info(this.getClass().getName()+" getNewCouponInfoByID Start");
		NewCoupon newCoupon = couponActivityDao_read.selectNewCouponByID(ID);
		if (newCoupon != null){
			List<NewCouponTemplateRel> list = couponActivityDao_read.selectNewCouponTemplateRelByNewCouponID(ID);
			newCoupon.setNewCouponTemplateRelList(list);
		}else{
			newCoupon = new NewCoupon();
		}
		this.log.info(this.getClass().getName()+" getNewCouponInfoByID End");
		return newCoupon;
	}
	
	/**
	 * 修改审核通过的活动时间
	 * @param modifyAuditActivityDate
	 * @param userName   
	 * @return
	 */
	public int modifyAuditActivityDate(Integer ID, String userName, String activityStartDate, String activityEndDate){
		this.log.debug(this.getClass().getName()+"modifyAuditActivityDate Start");
		int code = 0;
		// 更新
		int count = couponActivityDao.modifyAuditActivityDate(ID, userName,activityStartDate, activityEndDate);// 补发待审核
		if (count > 0){
		}else{
			code = -90019;// 更新活动的审核状态异常！
		}
		this.log.debug(this.getClass().getName()+"modifyAuditActivityDate End");
		return code;
	}
	
}
