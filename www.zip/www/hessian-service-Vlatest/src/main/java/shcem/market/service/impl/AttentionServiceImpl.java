package shcem.market.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.constant.ResultCode;
import shcem.market.component.IAttentionComponentManager;
import shcem.market.dao.model.Attention;
import shcem.market.dao.model.ExportAttentionBrandCategory;
import shcem.market.dao.model.ExportAttention;
import shcem.market.dao.model.ExportNewCouponTrans;
import shcem.market.dao.model.FollowStatistics;
import shcem.market.service.IAttentionService;
import shcem.market.util.MarketSysData;
import shcem.util.Common;
import shcem.util.ExportExcel;
import shcem.util.JsonUtil;
import shcem.util.UploadHttpFile;

/**
 * Created by lihaifeng on 2017/2/24.
 */
public class AttentionServiceImpl extends BaseServiceImpl implements IAttentionService {

	private IAttentionComponentManager attentionComponentManager = (IAttentionComponentManager) MarketSysData
			.getBean(Constants.BEAN_ATTENTION__MGR);

	/**
	 * 查询获取关注明细
	 * 
	 * @param params
	 * @return
	 */
	@Override
	public String getAttentionDetailedList(String params) {
		// System.out.print("测试数据!!");
		this.log.info(this.getClass().getName() + " getAttentionDetailedList() Start");
		this.log.debug("JOParams=" + params);
		boolean bolRst = false;
		List<Attention> list = new ArrayList<Attention>();
		// 表头查询条件
		JSONObject JSONParams = new JSONObject(params);
		JSONObject queryModel = JSONParams.optJSONObject("queryModel");
		List<Condition> conditionsList = new ArrayList<Condition>();
		conditionsList.add(new Condition("attention.traderID", "like", "", "string","traderID")); //交易员编码
		conditionsList.add(new Condition("attention.traderName", "like", "", "string","traderName")); //交易员名称
	    conditionsList.add(new Condition("attention.firmID", "like", "", "string","firmID")); // 交易商编码
	    conditionsList.add(new Condition("attention.firmName", "like", "", "string","firmName")); //交易商名称
	    conditionsList.add(new Condition("attention.searchKeys", "like", "", "string","searchKeys")); // 品类-牌号、交货地
	    conditionsList.add(new Condition("attention.AttentionType", "=", "", "Integer", "attentionType"));// 类型
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionsList, "");
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JSONParams);
		try {
			list = this.attentionComponentManager.getAttentionDetailedList(qc, pageInfo);
			bolRst = true;
		} catch (Exception e) {
			this.log.error(this.getClass().getName() + " getAttentionDetailedList 查询关注失败：" + e.getMessage());
			setResultData("30000", null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error(this.getClass().getName() + " getAttentionDetailedList 查询关注失败：" + e.getMessage());
				setResultData("30000", null);
			}

		}
		this.log.info(this.getClass().getName() + " getAttentionDetailedList() End");
		return rtnData.toString();
	}

	/**
	 * 获取关注类型
	 * 
	 * @return
	 */
	@Override
	public String getAttentionTypeList() {
		this.log.info(this.getClass().getName() + " getAttentionTypeList() Start");

		List<Attention> list = null;
		boolean bolRst = false;
		try {
			list = this.attentionComponentManager.getAttentionTypeList();
			bolRst = true;
		} catch (Exception e) {
			this.log.error("获取关注类型失败" + e.getMessage());
			setResultData("30000", null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("查询优惠券列表出错：" + e.getMessage());
				setResultData("30000", null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getAttentionTypeList() End");
		return rtnData.toString();
	}
	
	/**
	 * 导出导出关注明细记录
	 */
	@Override
	public String getExportAttentionDetailedExcel(String params) {
		// TODO Auto-generated method stub
		this.log.info(this.getClass().getName() + " getExportAttentionDetailedExcel() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		// 类型
		int attentionType = queryModel.getInt("attentionType");
		
		List<Attention> list = new ArrayList<Attention>();
		boolean bolRst = false;
		int totalCount = 0;
		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("attention.traderID", "like", "", "string","traderID")); //交易员编码
		conditionList.add(new Condition("attention.traderName", "like", "", "string","traderName")); //交易员名称
		conditionList.add(new Condition("attention.firmID", "like", "", "string","firmID")); // 交易商编码
		conditionList.add(new Condition("attention.firmName", "like", "", "string","firmName")); //交易商名称
		conditionList.add(new Condition("attention.searchKeys", "like", "", "string","searchKeys")); // 品类-牌号、交货地
		conditionList.add(new Condition("attention.AttentionType", "=", "", "Integer", "attentionType"));// 类型
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			totalCount = this.attentionComponentManager.getExportAttentionDetailedCount(qc, pageInfo);
			if(totalCount > Constants.EXPORT_MAX_COUNT){
				list =  this.attentionComponentManager.getExportAttentionDetailedExcel(qc, pageInfo,true);
			}else {
				list =  this.attentionComponentManager.getExportAttentionDetailedExcel(qc, pageInfo,false);
			}
			bolRst = true;
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error("取得客户关注记录列表数据查询失败"+e.getMessage());
			setResultData("10105", null);
		}
		if (bolRst) {
			JSONObject jsonObj = new JSONObject();
			exportAttentionDetailedExcelList(jsonObj, list, totalCount, attentionType);
		}
		this.log.info(this.getClass().getName() + " getExportAttentionDetailedExcel() End");
		return rtnData.toString();
	}
	
	/**
	 * 导出到Excel文件
	 * @param jsonObj
	 * @param exportlist
	 * @param totalCount 
	 * @param attentionType 
	 */
	private void exportAttentionDetailedExcelList(JSONObject jsonObj,List<Attention> exportlist, int totalCount, int attentionType) {
		if (exportlist != null && exportlist.size() > 0){
			
			int headersLength=0;
			if(attentionType==1){
				headersLength=6;
			}
			else{
				headersLength=5;
			}
			String[] excelHeaders = new String[headersLength];
			switch (attentionType) {
			case 1: 
				excelHeaders = new String[] { "交易员编码", "交易员名称", "交易商编码", "交易商名称", "品类-牌号", "产地" };
				break;
			case 2: 
				excelHeaders = new String[] { "交易员编码", "交易员名称", "交易商编码", "交易商名称", "交收方式" };
				break;
			case 3: 
				excelHeaders = new String[] { "交易员编码", "交易员名称", "交易商编码", "交易商名称", "交易场名称" }; 
				break;
			case 4: 
				excelHeaders = new String[] { "交易员编码", "交易员名称", "交易商编码", "交易商名称", "交货地名称" };
				break;
			default:
				break;
			}
			
			//文件流
			ByteArrayOutputStream out = null;
			ByteArrayInputStream in = null;
			try {
				String time = Common.df6.format(new Date());
				String excelName = "客户关注明细记录"+time.toString()+".xls";
				out = new ByteArrayOutputStream(); 
				
				
				if(attentionType==1){
					ExportExcel<ExportAttentionBrandCategory> ex = new ExportExcel<ExportAttentionBrandCategory>();
					List<ExportAttentionBrandCategory> brandCategoryList = new ArrayList<ExportAttentionBrandCategory>();
					ExportAttentionBrandCategory brandCategory = null;
					for (Attention model: exportlist){
						brandCategory = new ExportAttentionBrandCategory();
						
						brandCategory.setTraderID(model.getTraderID());
						brandCategory.setTraderName(model.getTraderName());
						brandCategory.setFirmID(model.getFirmID());
						brandCategory.setFirmName(model.getFirmName());
						
						brandCategory.setSearchKeys(model.getSearchKeys());
						brandCategory.setSearchKeysExtend(model.getSearchKeysExtend());
						
						brandCategoryList.add(brandCategory);
					}
					ex.exportExcel("客户关注明细记录", excelHeaders, brandCategoryList, out, null);
				}else{
					ExportExcel<ExportAttention> ex = new ExportExcel<ExportAttention>();
					List<ExportAttention> attentionList = new ArrayList<ExportAttention>();
					ExportAttention attention = null;
					for (Attention model: exportlist){
						attention = new ExportAttention();
						attention.setTraderID(model.getTraderID());
						attention.setTraderName(model.getTraderName());
						attention.setFirmID(model.getFirmID());
						attention.setFirmName(model.getFirmName());
						attention.setSearchKeys(model.getSearchKeys());
						attentionList.add(attention);
					}
					ex.exportExcel("客户关注明细记录", excelHeaders, attentionList, out, null);
				}
				
				in = new ByteArrayInputStream(out.toByteArray());
				String uploadUrl = Common.getUploadUrl(this.getMode());
				String httpUrl = UploadHttpFile.uploadFile(in,excelName,uploadUrl);
				out.close();
				in.close();
				if (null != httpUrl) {
					this.log.debug("httpUrl:"+httpUrl);
					jsonObj.put("httpUrl", httpUrl);
					jsonObj.put("fileName", excelName);
					setResultData(ResultCode.CODE00000.getValue(), jsonObj);
					if (totalCount > Constants.EXPORT_MAX_COUNT)setResultData("10122", jsonObj);
				} else {
					setResultData(ResultCode.CODE40013.getValue(), null);
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally { 
				// 清理资源
				try {
					out.close();
				} catch (IOException e1) {
					e1.printStackTrace();
					setResultData(ResultCode.CODE40013.getValue(), null);
				}
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
					setResultData(ResultCode.CODE40013.getValue(), null);
				}
			}
		}else{
			setResultData("10101",null);
		}
	}
	

	/**
	 * 关注统计
	 * 
	 * @param params
	 * @return
	 */ 
	@Override
	public String getAttentionStatistics(String params) {
		this.log.info(this.getClass().getName() + " getAttentionTypeList() Start");
		JSONObject JSONParams = new JSONObject(params);
		int size = 10;
		boolean bolRst=false;
		List<FollowStatistics> list=null;
		if (!JSONParams.isNull("size")) {
			size = JSONParams.optInt("size");
		}
		try {
			list = this.attentionComponentManager.getAttentionStatistics(size);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("获取关注统计列表失败" + e.getMessage());
			setResultData("30000", null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("查询关注统计列表出错：" + e.getMessage());
				setResultData("30000", null, e.getMessage());
			}
		}
		

		this.log.info(this.getClass().getName() + " getAttentionTypeList() End");
		return rtnData.toString();
	}

}
