package shcem.market.service.model;

import java.io.Serializable;
import java.math.BigDecimal;

import shcem.base.dao.model.BaseObject;

public class AuditInsuranceBackVo extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8066643263153522153L;
	// 退保ID
	private Integer id;
	// 更新前的 退保状态 1已申请 5已执行
	private Integer oldStatus;
	// 更新后的 退保状态 1已申请 5已执行
	private Integer newStatus;
	// 审核人
	private String reviewer;
	// 修改人
	private String modifyBy;
	// 实退保金额
	private BigDecimal realBackAmount;
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getOldStatus() {
		return oldStatus;
	}

	public void setOldStatus(Integer oldStatus) {
		this.oldStatus = oldStatus;
	}

	public Integer getNewStatus() {
		return newStatus;
	}

	public void setNewStatus(Integer newStatus) {
		this.newStatus = newStatus;
	}

	public String getReviewer() {
		return reviewer;
	}

	public void setReviewer(String reviewer) {
		this.reviewer = reviewer;
	}

	public String getModifyBy() {
		return modifyBy;
	}

	public void setModifyBy(String modifyBy) {
		this.modifyBy = modifyBy;
	}

	public BigDecimal getRealBackAmount() {
		return realBackAmount;
	}

	public void setRealBackAmount(BigDecimal realBackAmount) {
		this.realBackAmount = realBackAmount;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
