package shcem.market.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.constant.ResultCode;
import shcem.finance.util.JSONArrayUtil;
import shcem.market.component.ICouponActivityComponentManager;
import shcem.market.dao.model.ExportNewCouponTrans;
import shcem.market.dao.model.ExportUnNewCouponTrans;
import shcem.market.dao.model.NewCoupon;
import shcem.market.dao.model.NewCouponTemplateRel;
import shcem.market.dao.model.NewCouponTrans;
import shcem.market.dao.model.NewCouponActivity;
import shcem.market.service.ICouponActivityMgrService;
import shcem.market.service.model.ActivityTempCoupon;
import shcem.market.service.model.amoutDateModel;
import shcem.market.util.MarketSysData;
import shcem.util.Common;
import shcem.util.CopyProperties;
import shcem.util.ExportExcel;
import shcem.util.JsonUtil;
import shcem.util.UploadHttpFile;

/**
 * 
 * @author wangj
 *
 */
public class CouponActivityMgrServiceImpl  extends BaseServiceImpl implements ICouponActivityMgrService{
	
	private ICouponActivityComponentManager couponActivityComponnetManager = (ICouponActivityComponentManager)MarketSysData.getBean(Constants.BEAN_NEWMARKET_MGR);
	
	@Override
	public String queryCouponTypeList(String params) {
		// TODO Auto-generated method stub
		this.log.info(this.getClass().getName() + " queryCouponTypeList() Start");
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");

		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("nc.CouponName", "like", "", "String", "couponName"));
		conditionList.add(new Condition("nc.Status", "=", "", "Integer", "status"));
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<NewCoupon> list = null;
		boolean bolRst = false;
		try {
			list = couponActivityComponnetManager.queryCouponTypeList(qc, pageInfo);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("取得优惠券列表失败：" + err.getMessage());
			setResultData("30000", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("30000", null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " queryCouponTypeList() End");
		return rtnData.toString();
	}

	@Override
	public String addCouponType(String params) {
		// TODO Auto-generated method stub
		this.log.info(this.getClass().getName() + " addCouponType() Start");
		JSONObject JOParams = new JSONObject(params);
		NewCoupon newCoupon = (NewCoupon)JsonUtil.jsonToBean(JOParams,NewCoupon.class);
		String userName = this.getUserName() == null ? "system" : (this.getUserName() == "") ? "system" : this.getUserName();
		int returnCode;
		try{
			newCoupon.setREC_CREATEBY(userName);
			newCoupon.setREC_MODIFYBY(userName);
			if (newCoupon.getCouponType() == 1){// 优惠券类型 1抵扣型 2充值型
				/**
				 * 获取交易场列表
				 */
				List<NewCouponTemplateRel> newCouponTemplateRelList = new ArrayList<NewCouponTemplateRel>();
				JSONArray newCouponTemplateRelArray = JOParams.getJSONArray("newCouponTemplateRelArray");
				int newCouponTemplateRelArraySize = newCouponTemplateRelArray.length();
				NewCouponTemplateRel  newCouponTemplateRel = null;
				for (int i = 0; i < newCouponTemplateRelArraySize; i++) {
					newCouponTemplateRel = new NewCouponTemplateRel();
					newCouponTemplateRel.setTemplateID(newCouponTemplateRelArray.getInt(i));
					newCouponTemplateRelList.add(newCouponTemplateRel);
				}
				newCoupon.setNewCouponTemplateRelList(newCouponTemplateRelList);
				newCoupon.setRechargeAmount(new BigDecimal(0));
				newCoupon.setDeductionAmount(new BigDecimal(0));
			}else{
				BigDecimal amount = newCoupon.getRechargeAmount().add(newCoupon.getDeductionAmount());
				newCoupon.setAmount(amount);
			}
			returnCode = couponActivityComponnetManager.insertCouponType(newCoupon);
			if(returnCode >= 0){
				setResultData("00000", null);
			}else if (returnCode == -80001) {
				setResultData("80001", null);
			}else {
				setResultData("30000", null);
			}
		}catch (Exception err){
			this.log.error("添加优惠券失败：" + err.getMessage());
			setResultData("30000", null);
		}
		this.log.info(this.getClass().getName() + " addCouponApply() End");
		return rtnData.toString();
	}

	@Override
	public String delCouponType(String params) {
		// TODO Auto-generated method stub
		this.log.info(this.getClass().getName() + " delCouponType() Start");
		JSONObject JOParams = new JSONObject(params);
		Integer id = JOParams.getInt("id");
		Integer dISABLED=JOParams.getInt("dISABLED");
		int returnCode;
		try{
			returnCode = couponActivityComponnetManager.delCouponType(id, dISABLED);
			if(returnCode >= 0){
				setResultData("00000",null);
			}else {
				setResultData("30000",null);
			}
		}catch (Exception err){
			this.log.error("删除优惠券失败：" + err.getMessage());
			setResultData("30000",null);
		}
		this.log.info(this.getClass().getName() + " addCouponApply() End");
		return rtnData.toString();
	}
	
	/**
	 * 查询优惠券使用记录
	 */
	@Override
	public String getCouponFlowingWaterList(String params) {
		this.log.info(this.getClass().getName() + " getCouponFlowingWaterList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");

		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("ncTrans.CouponNumber", "like", "", "String", "couponNumber"));//优惠券号码
		conditionList.add(new Condition("ncTrans.CouponName", "like", "", "String", "couponName"));//优惠券名称
		conditionList.add(new Condition("ncTrans.CouponType", "=", "", "Integer", "couponType"));//优惠券类型
		conditionList.add(new Condition("ncTrans.FirmID", "like", "", "String", "firmId"));//交易商ID
		conditionList.add(new Condition("ncTrans.firmName", "like", "", "String", "firmName"));//交易商名称
		conditionList.add(new Condition("ncTrans.OrderId", "like", "", "String", "orderId"));//订单号
		conditionList.add(new Condition("ncTrans.Status", "=", "", "Integer", "status"));//状态
		conditionList.add(new Condition("convert(char(10),ncTrans.UseDate,120)",">=","","String","useDateStart")); //使用开始日期
		conditionList.add(new Condition("convert(char(10),ncTrans.UseDate,120)","<=","","String","useDateEnd")); //使用结束日期
		conditionList.add(new Condition("ncTrans.activityName","like","","String","activityName")); //活动名称
		
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<NewCouponTrans> list = null;
		boolean bolRst = false;
		try {
			list = couponActivityComponnetManager.getCouponFlowingWaterList(qc, pageInfo);
			bolRst = true;
		} catch (Exception err) {
			err.printStackTrace();
			this.log.error("取得优惠券使用记录列表失败：" + err.getMessage());
			setResultData("10105", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getCouponFlowingWaterList() End");
		return rtnData.toString();
	}

	/**
	 * 查询过滤未发送的优惠券[去掉已经过期的优惠券]
	 */
	@Override
	public String getCouponNoUsedList(String params) {
		this.log.info(this.getClass().getName() + " getCouponNoUsedList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");

		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("ncTrans.CouponNumber", "like", "", "String", "couponNumber"));//优惠券号码
		conditionList.add(new Condition("ncTrans.CouponName", "like", "", "String", "couponName"));//优惠券名称
		conditionList.add(new Condition("ncTrans.CouponType", "=", "", "Integer", "couponType"));//优惠券类型
		conditionList.add(new Condition("ncTrans.FirmID", "like", "", "String", "firmId"));//交易商ID
		conditionList.add(new Condition("ncTrans.firmName", "like", "", "String", "firmName"));//交易商名称
		conditionList.add(new Condition("ncTrans.OrderId", "like", "", "String", "orderId"));//订单号
		conditionList.add(new Condition("ncTrans.Status", "=", "", "Integer", "status"));//状态
		conditionList.add(new Condition("convert(char(10),ncTrans.UseDate,120)",">=","","String","useDateStart")); //使用开始日期
		conditionList.add(new Condition("convert(char(10),ncTrans.UseDate,120)","<=","","String","useDateEnd")); //使用结束日期
		conditionList.add(new Condition("ncTrans.activityName","like","","String","activityName")); //活动名称
		
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<NewCouponTrans> list = null;
		boolean bolRst = false;
		try {
			list = couponActivityComponnetManager.getCouponNoUsedList(qc, pageInfo,false);
			bolRst = true;
		} catch (Exception err) {
			err.printStackTrace();
			this.log.error("取得优惠券记录列表失败：" + err.getMessage());
			setResultData("10105", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getCouponNoUsedList() End");
		return rtnData.toString();
	}
	
	/**
	 * 导出优惠券使用记录
	 */
	@Override
	public String exportCouponFlowingWaterList(String params) {
		// TODO Auto-generated method stub
		this.log.info(this.getClass().getName() + " getCouponFlowingWaterList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		List<ExportNewCouponTrans> list = new ArrayList<ExportNewCouponTrans>();
		boolean bolRst = false;
		int totalCount = 0;
		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("ncTrans.CouponNumber", "like", "", "String", "couponNumber"));//优惠券号码
		conditionList.add(new Condition("ncTrans.CouponName", "like", "", "String", "couponName"));//优惠券名称
		conditionList.add(new Condition("ncTrans.CouponType", "=", "", "Integer", "couponType"));//优惠券类型
		conditionList.add(new Condition("ncTrans.FirmID", "like", "", "String", "firmId"));//交易商ID
		conditionList.add(new Condition("ncTrans.firmName", "like", "", "String", "firmName"));//交易商名称
		conditionList.add(new Condition("ncTrans.OrderId", "like", "", "String", "orderId"));//订单号
		conditionList.add(new Condition("ncTrans.Status", "=", "", "Integer", "status"));//状态
		conditionList.add(new Condition("convert(char(10),ncTrans.UseDate,120)",">=","","String","useDateStart")); //使用开始日期
		conditionList.add(new Condition("convert(char(10),ncTrans.UseDate,120)","<=","","String","useDateEnd")); //使用结束日期
		conditionList.add(new Condition("ncTrans.activityName","like","","String","activityName")); //活动名称
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			totalCount = couponActivityComponnetManager.getExportCouponFlowingWaterCount(qc, pageInfo);
			if(totalCount > Constants.EXPORT_MAX_COUNT){
				list =  couponActivityComponnetManager.exportCouponFlowingWaterList(qc, pageInfo,true);
			}else {
				list =  couponActivityComponnetManager.exportCouponFlowingWaterList(qc, pageInfo,false);
			}
			bolRst = true;
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error("取得优惠券使用记录列表数据查询失败"+e.getMessage());
			setResultData("10105", null);
		}
		if (bolRst) {
			JSONObject jsonObj = new JSONObject();
			exportCouponFlowingWaterDetailList(jsonObj, list,totalCount);
		}
		this.log.info(this.getClass().getName() + " exportInvoiceCollectDetailList() End");
		return rtnData.toString();
	}
	
	/**
	 * 导出到Excel文件
	 * @param jsonObj
	 * @param exportlist
	 * @param totalCount 
	 */
	private void exportCouponFlowingWaterDetailList(JSONObject jsonObj,List<ExportNewCouponTrans> exportlist, int totalCount) {
		if (exportlist != null && exportlist.size() > 0){
			ExportExcel<ExportNewCouponTrans> ex = new ExportExcel<ExportNewCouponTrans>();
			
			String [] excelHeaders ={
					"优惠券号码",	
					"兑换码",	
					"活动名称",	
					"优惠券名称",	
					"优惠券类型",	
					"优惠劵面额（元）",	
					"抵扣金额（元）",	
					"发放时间",	
					"使用时间",	
					"使用交易商编码",
					"交易商",
					"使用交易员编码",
					"用户名称",
					//"用户",
					"成交单号",
					"状态"
			};
			//文件流
			ByteArrayOutputStream out = null;
			ByteArrayInputStream in = null;
			try {
				String time = Common.df6.format(new Date());
				String excelName = "优惠券使用记录"+time.toString()+".xls";
				out = new ByteArrayOutputStream(); 
				ex.exportExcel("优惠券使用记录", excelHeaders, exportlist, out, null);
				in = new ByteArrayInputStream(out.toByteArray());
				String uploadUrl = Common.getUploadUrl(this.getMode());
				String httpUrl = UploadHttpFile.uploadFile(in,excelName,uploadUrl);
				out.close();
				in.close();
				if (null != httpUrl) {
					this.log.debug("httpUrl:"+httpUrl);
					jsonObj.put("httpUrl", httpUrl);
					jsonObj.put("fileName", excelName);
					setResultData(ResultCode.CODE00000.getValue(), jsonObj);
					if (totalCount > Constants.EXPORT_MAX_COUNT)setResultData("10122", jsonObj);
				} else {
					setResultData(ResultCode.CODE40013.getValue(), null);
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally { 
				// 清理资源
				try {
					out.close();
				} catch (IOException e1) {
					e1.printStackTrace();
					setResultData(ResultCode.CODE40013.getValue(), null);
				}
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
					setResultData(ResultCode.CODE40013.getValue(), null);
				}
			}
		}else{
			setResultData("10101",null);
		}
	}
	
	/**
	 * 导出到Excel文件
	 * @param jsonObj
	 * @param exportlist
	 * @param totalCount 
	 */
	private void exportUnCouponFlowingWaterDetailList(JSONObject jsonObj,List<ExportUnNewCouponTrans> exportlist, int totalCount) {
		this.log.debug("exportUnCouponFlowingWaterDetailList Start");
		
		
		if (exportlist != null && exportlist.size() > 0){
			ExportExcel<ExportUnNewCouponTrans> ex = new ExportExcel<ExportUnNewCouponTrans>();
			String [] excelHeaders ={
					"优惠券号码",	
					"兑换码",	
					"活动名称",	
					//"优惠券名称",	
					"优惠券类型",	
					"优惠劵面额（元）",	
//					"抵扣金额",	
//					"领取时间",	
//					"使用时间",	
//					"交易商编码",
//					"交易商",
//					"交易员",
//					"用户",
//					"使用订单号",
					"状态"
			};
			//文件流
			ByteArrayOutputStream out = null;
			ByteArrayInputStream in = null;
			try {
				String time = Common.df6.format(new Date());
				String excelName = "未发放优惠券记录"+time.toString()+".xls";
				out = new ByteArrayOutputStream(); 
				ex.exportExcel("未发放优惠券记录", excelHeaders, exportlist, out, null);
				in = new ByteArrayInputStream(out.toByteArray());
				String uploadUrl = Common.getUploadUrl(this.getMode());
				String httpUrl = UploadHttpFile.uploadFile(in,excelName,uploadUrl);
				out.close();
				in.close();
				if (null != httpUrl) {
					this.log.debug("httpUrl:"+httpUrl);
					jsonObj.put("httpUrl", httpUrl);
					jsonObj.put("fileName", excelName);
					setResultData(ResultCode.CODE00000.getValue(), jsonObj);
					if(totalCount > Constants.EXPORT_MAX_COUNT)setResultData("10122",jsonObj);
				} else {
					setResultData(ResultCode.CODE40013.getValue(), null);
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally { 
				// 清理资源
				try {
					out.close();
				} catch (IOException e1) {
					e1.printStackTrace();
					setResultData(ResultCode.CODE40013.getValue(), null);
				}
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
					setResultData(ResultCode.CODE40013.getValue(), null);
				}
			}
		}else{
			setResultData("10101",null);
		}
		this.log.debug("exportUnCouponFlowingWaterDetailList End");
	}
	
	@Override
	public String queryCouponActivityList(String params) {
		// TODO Auto-generated method stub
		this.log.info(this.getClass().getName() + " queryCouponActivityList() Start");
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");

		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("nca.ActivityName", "like", "", "String", "activityName"));
		conditionList.add(new Condition("nca.States", "=", "", "Integer", "states"));
		conditionList.add(new Condition("nca.AuditStates", "=", "", "Integer", "auditStates"));
		conditionList.add(new Condition("convert(char(10),nca.ActivityStartDate,120)",">=","","String","activityStartDate")); //活动开始时间
		conditionList.add(new Condition("convert(char(10),nca.ActivityEndDate,120)","<=","","String","activityEndDate")); //活动结束时间
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<NewCouponActivity> list = null;
		boolean bolRst = false;
		try {
			list = couponActivityComponnetManager.queryCouponActivityList(qc, pageInfo);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("取得活动列表失败：" + err.getMessage());
			setResultData("10105", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " queryCouponActivityList() End");
		return rtnData.toString();
	}

	/**
	 * 发送优惠券
	 */
	@Override
	public String sendCouponForUserCode(String params) {
		this.log.info(this.getClass().getName() + " sendCouponForUserCode() Start");
		this.log.debug(params);
		JSONObject JOParams = new JSONObject(params);
		String id = JOParams.optString("id");
		String userCode = JOParams.optString("userCode");
		Integer couponStatus = JOParams.optInt("status"); //优惠券状态
		String traderID = JOParams.optString("traderID"); //交易员编码 
		String firmID = JOParams.optString("firmID"); //交易商编码
		if (id == null ){
			setResultData("10103", null, "id不能为空！");
			return rtnData.toString();
		}
		if (userCode == null ){
			setResultData("10103", null, "userCode不能为空！");
			return rtnData.toString();
		}
		if(traderID == null ){
			setResultData("10103", null, "traderID交易员编码不能为空！");
			return rtnData.toString();
		}
		if (firmID == null ){
			setResultData("10103", null, "userCode交易商编码不能为空！");
			return rtnData.toString();
		}
		String userID = this.getUserName() == null ? "system" : (this.getUserName() == "") ? "system" : this.getUserName();
		try{
			int resultCode = couponActivityComponnetManager.sendCouponForUserCode(Integer.valueOf(id), userCode, userID, couponStatus,traderID, firmID);
			if (resultCode >= 0){
				setResultData("00000", null);
			}else{
				setResultData(""+-resultCode, null);
			}
		}catch (Exception err){
			this.log.error("发送优惠券失败：" + err.getMessage());
			setResultData("90001", null);
		}
		this.log.info(this.getClass().getName() + " sendCouponForUserCode() End");
		return rtnData.toString();
	}

	/**
	 * 发送优惠券兑换码
	 */
	@Override
	public String sendCouponForUserCodeExchangeCode(String params) {
		this.log.info(this.getClass().getName() + " sendCouponForUserCodeExchangeCode() Start");
		this.log.debug(params);
		JSONObject JOParams = new JSONObject(params);
		String id = JOParams.optString("id");
		Integer couponStatus = JOParams.optInt("status"); //优惠券状态
		
		if (id == null ){
			setResultData("10103", null, "id不能为空！");
			return rtnData.toString();
		}
		if(couponStatus == 0 ){
			setResultData("10103", null, "status不能为空！");
			return rtnData.toString();
		}
		String userID = this.getUserName() == null ? "system" : (this.getUserName() == "") ? "system" : this.getUserName();
		try{
			int resultCode = couponActivityComponnetManager.sendCouponForUserCodeExchangeCode(Integer.valueOf(id), userID, couponStatus);
			if (resultCode >= 0){
				setResultData("00000", null);
			}else{
				setResultData(""+-resultCode, null);
			}
		}catch (Exception err){
			this.log.error("发送优惠券兑换码失败：" + err.getMessage());
			setResultData("90001", null);
		}
		this.log.info(this.getClass().getName() + " sendCouponForUserCodeExchangeCode() End");
		return rtnData.toString();
	}
	
	@Override
	public String markupNewCouponTransOfStatus(String params) {
		this.log.info(this.getClass().getName() + " markupNewCouponTransOfStatus() Start");
		this.log.debug(params);
		JSONObject JOParams = new JSONObject(params);
		JSONArray jSONArray = JOParams.optJSONArray("IdArr");
		int[] IdArr = JSONArrayUtil.getJsonToIntArray(jSONArray);
		if (IdArr.length <= 0){
			setResultData("10103", null, "IdArr不能为空！");
			return rtnData.toString();
		}
		String userID = this.getUserName() == null ? "system" : (this.getUserName() == "") ? "system" : this.getUserName();
		try{
			int count = couponActivityComponnetManager.markupNewCouponTransOfStatus(IdArr, userID);
			this.log.debug("需要置标的条数:"+IdArr.length+"，成功置标优惠券状态条数:"+count);
			if (count > 0){
				setResultData("00000", null);
			}else{
				setResultData("90008", null,"需要置标的条数:"+IdArr.length+"，成功置标优惠券状态条数:"+count);
			}
		}catch (Exception err){
			this.log.error("置标优惠券状态失败：" + err.getMessage());
			setResultData("90008", null);
		}
		this.log.info(this.getClass().getName() + " markupNewCouponTransOfStatus() End");
		return rtnData.toString();
	}

	@Override
	public String addOrEditActivity(String params) {
		// TODO Auto-generated method stub
		this.log.info(this.getClass().getName() + " addOrEditActivity() Start");
		JSONObject JOParams = new JSONObject(params);
		ActivityTempCoupon activityTempCoupon = (ActivityTempCoupon)JsonUtil.jsonToBean(JOParams,ActivityTempCoupon.class);
		/**
		 * 1.获取交易场ID
		 */
		JSONArray tempArrayTemp = JOParams.getJSONArray("tempArray");
		int[] tempArray = JSONArrayUtil.getJsonToIntArray(tempArrayTemp);
		activityTempCoupon.setTempArray(tempArray);
		
		/**
		 * 2.优惠券类型
		 */
		List<amoutDateModel> amoutDateModelList = new ArrayList<amoutDateModel>();
		JSONArray amoutDateModelListTemp = JOParams.getJSONArray("amoutDateModelList");
		if (amoutDateModelListTemp.length() > 0) {
			for (int i = 0; i < amoutDateModelListTemp.length(); i++) {
				amoutDateModelList.add((amoutDateModel)JsonUtil.jsonToBean((JSONObject) amoutDateModelListTemp.get(i), amoutDateModel.class));
			}
		}
		activityTempCoupon.setAmoutDateModelList(amoutDateModelList);
		
		String userName = this.getUserName() == null ? "system" : (this.getUserName() == "") ? "system" : this.getUserName();
		int returnCode;
		try{
			activityTempCoupon.setREC_CREATEBY(userName);
			activityTempCoupon.setREC_MODIFYBY(userName);
			returnCode = couponActivityComponnetManager.insertOrUpdateActivity(activityTempCoupon,userName);
			if(returnCode >=0){
				setResultData("00000", null);
			}else if(returnCode == -80001){
				setResultData("80001", null);
			}else {
				setResultData("30000", null);
			}
		}catch (Exception err){
			this.log.error("添加活动失败：" + err.getMessage());
			setResultData("30000", null);
		}
		this.log.info(this.getClass().getName() + " addOrEditActivity() End");
		return rtnData.toString();
	}

	/**
	 * 活动审核
	 */
	@Override
	public String auditActivity(String params) {
		// TODO Auto-generated method stub
		this.log.info(this.getClass().getName() + " auditActivity() Start");
		JSONObject JOParams = new JSONObject(params);
		NewCouponActivity newCouponActivity = (NewCouponActivity)JsonUtil.jsonToBean(JOParams,NewCouponActivity.class);
		String userName = this.getUserName() == null ? "system" : (this.getUserName() == "") ? "system" : this.getUserName();
		boolean auditFlag = newCouponActivity.getAuditFlag();
		int returnCode;
		try {
			returnCode = couponActivityComponnetManager.auditActivity(newCouponActivity,userName,auditFlag);
			if(returnCode >= 0){
				setResultData("00000",null);
			}else {
				this.log.error(this.getClass().getName()+" 审核活动失败：");
				setResultData("80000", null);
			}
		} catch (Exception err) {
			this.log.error(this.getClass().getName()+" 审核活动失败：" + err.getMessage());
			setResultData("80000", null, err.getMessage());
		}
		this.log.info(this.getClass().getName() + " auditActivity() End");
		return rtnData.toString();
	}

	@Override
	public String getCouponList(String params) {
		this.log.info(this.getClass().getName() + " getCouponList() Start");
		List<NewCoupon> list = null;
		boolean bolRst = false;
		JSONObject JOParams = new JSONObject(params);
		try {
			JSONArray templateIDArray = JOParams.getJSONArray("templateIDArray");
			int templateIDArraySize  = templateIDArray.length();
			Integer[] IDArray = new Integer[templateIDArraySize];
			if (templateIDArraySize > 0 ) {
				for (int i = 0; i < templateIDArraySize; i++) {
					IDArray[i] = templateIDArray.getInt(i);
				}
			}
			list = couponActivityComponnetManager.getCouponList(IDArray);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询优惠券列表出错" + e.getMessage());
			setResultData("30000", null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("查询优惠券列表出错：" + e.getMessage());
				setResultData("30000", null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getCouponList() End");
		return rtnData.toString();
	}

	/**
	 * 活动详情
	 */
	@Override
	public String getActivityByID(String params) {
		this.log.info(this.getClass().getName() +" getActivityByID Start");
		JSONObject JOParams = new JSONObject(params);
		int activityID = JOParams.getInt("activityID");
		boolean bolRest = false;
		ActivityTempCoupon activityTempCoupon = new ActivityTempCoupon();
		try {
			activityTempCoupon = this.couponActivityComponnetManager.getActivityByID(activityID);
			bolRest = true;
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" "+e.getMessage());
		}
		if (bolRest) {
			JSONObject retData;
			try {
				retData = JsonUtil.coverModelToJSONObject(activityTempCoupon);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error(this.getClass().getName()+" getActivityByID"+e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() +" getActivityByID End");
		return rtnData.toString();
	}
	/**
	 *  在审核通过活动的基础上增发优惠券！
	 */
	@Override
	public String addOrEditReissueActivity(String params) {
		this.log.info(this.getClass().getName()+" addOrEditReissueActivity Start");
		JSONObject JOParams = new JSONObject(params);
		ActivityTempCoupon activityTempCoupon = (ActivityTempCoupon)JsonUtil.jsonToBean(JOParams,ActivityTempCoupon.class);
		/**
		 * 优惠券类型
		 */
		List<amoutDateModel> amoutDateModelList = new ArrayList<amoutDateModel>();
		JSONArray amoutDateModelListTemp = JOParams.getJSONArray("amoutDateModelList");
		if (amoutDateModelListTemp.length() > 0 ) {
			for (int i = 0; i < amoutDateModelListTemp.length(); i++) {
				amoutDateModelList.add((amoutDateModel)JsonUtil.jsonToBean((JSONObject) amoutDateModelListTemp.get(i), amoutDateModel.class));
			}
		}else {
			this.log.error(this.getClass().getName()+" 优惠券参数为null");
			setResultData("30000",null);
			return rtnData.toString();
		}
		activityTempCoupon.setAmoutDateModelList(amoutDateModelList);
		String userName = this.getUserId() == null ? "system" : ("".equals(this.getUserId()) == true ? "system" : this.getUserId());
		int returnCode;
		try {
			returnCode = this.couponActivityComponnetManager.addOrEditReissueActivity(activityTempCoupon,userName);
			if(returnCode >= 0){
				this.log.businesslog("增发优惠券成功",Constants.OPE_MODE_MARKET,Constants.OPE_SUCCESS);
				setResultData("00000",null);
			}else {
				setResultData(-returnCode+"",null);
			}
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" addMoreActivity 异常："+e.getMessage());
			setResultData("30000",null);
		}
		this.log.info(this.getClass().getName()+" addOrEditReissueActivity End");
		return rtnData.toString();
	}

	@Override
	public String exportUnCouponFlowingWaterList(String params) {
		// TODO Auto-generated method stub
		this.log.info(this.getClass().getName() + " exportUnCouponFlowingWaterList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		List<ExportNewCouponTrans> list = new ArrayList<ExportNewCouponTrans>();
		boolean bolRst = false;
		int totalCount = 0;
		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("ncTrans.CouponNumber", "like", "", "String", "couponNumber"));//优惠券号码
		conditionList.add(new Condition("ncTrans.CouponName", "like", "", "String", "couponName"));//优惠券名称
		conditionList.add(new Condition("ncTrans.CouponType", "=", "", "Integer", "couponType"));//优惠券类型
		conditionList.add(new Condition("ncTrans.FirmID", "like", "", "String", "firmId"));//交易商ID
		conditionList.add(new Condition("ncTrans.firmName", "like", "", "String", "firmName"));//交易商名称
		conditionList.add(new Condition("ncTrans.OrderId", "like", "", "String", "orderId"));//订单号
		conditionList.add(new Condition("ncTrans.Status", "=", "", "Integer", "status"));//状态
		conditionList.add(new Condition("convert(char(10),ncTrans.UseDate,120)",">=","","String","useDateStart")); //使用开始日期
		conditionList.add(new Condition("convert(char(10),ncTrans.UseDate,120)","<=","","String","useDateEnd")); //使用结束日期
		conditionList.add(new Condition("ncTrans.activityName","like","","String","activityName")); //活动名称
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		List<ExportUnNewCouponTrans> newExportlist = new ArrayList<ExportUnNewCouponTrans>();
		try {
			totalCount = this.couponActivityComponnetManager.getExportCouponUnissuedCount(qc, pageInfo);
			if(totalCount > Constants.EXPORT_MAX_COUNT){
				list =  couponActivityComponnetManager.exportCouponUnissuedList(qc, pageInfo,true);
			}else {
				list =  couponActivityComponnetManager.exportCouponUnissuedList(qc, pageInfo,false);
			}
			ExportUnNewCouponTrans exportUnNewCouponTrans = null;
			for(ExportNewCouponTrans temp : list){
				exportUnNewCouponTrans = new ExportUnNewCouponTrans();
				CopyProperties.copyProperties(temp, exportUnNewCouponTrans);
				newExportlist.add(exportUnNewCouponTrans);
			}
			bolRst = true;
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error("取得优惠券使用记录列表数据查询失败"+e.getMessage());
			setResultData("10105", null);
		}
		if (bolRst) {
			JSONObject jsonObj = new JSONObject();
			exportUnCouponFlowingWaterDetailList(jsonObj, newExportlist,totalCount);
		}
		this.log.info(this.getClass().getName() + " exportUnCouponFlowingWaterList() End");
		return rtnData.toString();
	}

	@Override
	public String resetActivityStatus(String params) {
		this.log.info(this.getClass().getName() + " resetActivityStatus() Start");
		JSONObject JOParams = new JSONObject(params);
		Integer id = JOParams.getInt("id");
		Integer flag=JOParams.getInt("flag");
		int returnCode;
		try{
			returnCode = couponActivityComponnetManager.resetActivityStatus(id, flag);
			if(returnCode >= 0){
				setResultData("00000",null);
			}else {
				setResultData("30000",null);
			}
		}catch (Exception err){
			this.log.error("操作失败：" + err.getMessage());
			setResultData("30000",null);
		}
		this.log.info(this.getClass().getName() + " resetActivityStatus() End");
		return rtnData.toString();
	}

	@Override
	public String reissueAuditActivity(String params) {
		this.log.info(this.getClass().getName() + " reissueAuditActivity() Start");
		JSONObject JOParams = new JSONObject(params);
		NewCouponActivity newCouponActivity = (NewCouponActivity)JsonUtil.jsonToBean(JOParams,NewCouponActivity.class);
		String userName = this.getUserName() == null ? "system" : (this.getUserName() == "") ? "system" : this.getUserName();
		boolean auditFlag = newCouponActivity.getAuditFlag();
		int returnCode;
		try {
			returnCode = couponActivityComponnetManager.reissueAuditActivity(newCouponActivity, userName, auditFlag);
			if(returnCode >= 0){
				setResultData("00000",null);
			}else {
				this.log.error(this.getClass().getName()+" 审核活动失败：");
				setResultData(-returnCode+"", null);
			}
		} catch (Exception err) {
			this.log.error(this.getClass().getName()+" 审核活动失败：" + err.getMessage());
			setResultData("80000", null, err.getMessage());
		}
		this.log.info(this.getClass().getName() + " reissueAuditActivity() End");
		return rtnData.toString();
	}

	@Override
	public String getReissueActivityByID(String params) {
		this.log.info(this.getClass().getName() +" getReissueActivityByID Start");
		JSONObject JOParams = new JSONObject(params);
		int activityID = JOParams.getInt("activityID");
		boolean bolRest = false;
		ActivityTempCoupon activityTempCoupon = new ActivityTempCoupon();
		try {
			activityTempCoupon = this.couponActivityComponnetManager.getReissueActivityByID(activityID);
			bolRest = true;
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" "+e.getMessage());
		}
		if (bolRest) {
			JSONObject retData;
			try {
				retData = JsonUtil.coverModelToJSONObject(activityTempCoupon);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error(this.getClass().getName()+" getReissueActivityByID"+e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() +" getReissueActivityByID End");
		return rtnData.toString();
	}

	@Override
	public String getNewCouponInfoByID(String params) {
		this.log.info(this.getClass().getName() +" getNewCouponInfoByID Start");
		JSONObject JOParams = new JSONObject(params);
		int ID = JOParams.getInt("ID");
		boolean bolRest = false;
		NewCoupon newCoupon = null;
		try {
			newCoupon = this.couponActivityComponnetManager.getNewCouponInfoByID(ID);
			bolRest = true;
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" "+e.getMessage());
		}
		if (bolRest) {
			JSONObject retData;
			try {
				retData = JsonUtil.coverModelToJSONObject(newCoupon);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error(this.getClass().getName()+" getNewCouponInfoByID"+e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() +" getNewCouponInfoByID End");
		return rtnData.toString();
	}
	
	/**
	 * 修改审核通过的活动时间
	 * @param params
	 * @return
	 */
	@Override
	public String modifyAuditActivityDate(String params) {
		// TODO Auto-generated method stub
		
		this.log.info(this.getClass().getName() + " modifyAuditActivityDate() Start");
		this.log.debug(params);
		JSONObject JOParams = new JSONObject(params);
		String id = JOParams.optString("id");
		String activityStartDate = JOParams.optString("activityStartDate"); //优惠券有效起始时间
		String activityEndDate = JOParams.optString("activityEndDate"); //优惠券有效结束时间
		String userID = this.getUserName() == null ? "system" : (this.getUserName() == "") ? "system" : this.getUserName();
		if (id == null ){
			setResultData("10103", null, "id不能为空！");
			return rtnData.toString();
		}
		if (activityStartDate == null ){
			setResultData("10103", null, "优惠券有效起始时间不能为空！");
			return rtnData.toString();
		}
		if(activityEndDate == null ){
			setResultData("10103", null, "优惠券有效结束时间不能为空！");
			return rtnData.toString();
		}
		try{
			int resultCode = couponActivityComponnetManager.modifyAuditActivityDate(Integer.valueOf(id), userID, activityStartDate, activityEndDate);
			if (resultCode >= 0){
				setResultData("00000", null);
			}else{
				setResultData(""+-resultCode, null);
			}
		}catch (Exception err){
			this.log.error("修改活动失败：" + err.getMessage());
			setResultData("90019", null);
		}
		
		this.log.info(this.getClass().getName() + " modifyAuditActivityDate() End");
		return rtnData.toString();
		
	}
	
	
}
