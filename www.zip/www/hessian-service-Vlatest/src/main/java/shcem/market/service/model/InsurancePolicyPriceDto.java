package shcem.market.service.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import shcem.base.dao.model.BaseObject;

/**
 * 保价DTO
 * @author wangshuai
 *
 */
public class InsurancePolicyPriceDto extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8333148464576385043L;
	// 保单日期列表
	private List<Date> policyDateList;
	// 保单日期
	private Date policyDate;
	// 品类名称
	private String[] categoryName;
	// 品类类型
	private Integer[] categoryType;
	// 结算价格
	private BigDecimal[] settlementPrice;
	// 均价差
	private BigDecimal[] averageDeltaPrice;
	// 当前用户
	private String currentUser;

	public List<Date> getPolicyDateList() {
		return policyDateList;
	}

	public void setPolicyDateList(List<Date> policyDateList) {
		this.policyDateList = policyDateList;
	}

	public Date getPolicyDate() {
		return policyDate;
	}

	public void setPolicyDate(Date policyDate) {
		this.policyDate = policyDate;
	}

	public String[] getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String[] categoryName) {
		this.categoryName = categoryName;
	}

	public Integer[] getCategoryType() {
		return categoryType;
	}

	public void setCategoryType(Integer[] categoryType) {
		this.categoryType = categoryType;
	}

	public BigDecimal[] getSettlementPrice() {
		return settlementPrice;
	}

	public void setSettlementPrice(BigDecimal[] settlementPrice) {
		this.settlementPrice = settlementPrice;
	}

	public BigDecimal[] getAverageDeltaPrice() {
		return averageDeltaPrice;
	}

	public void setAverageDeltaPrice(BigDecimal[] averageDeltaPrice) {
		this.averageDeltaPrice = averageDeltaPrice;
	}

	public String getCurrentUser() {
		return currentUser;
	}

	public void setCurrentUser(String currentUser) {
		this.currentUser = currentUser;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}
