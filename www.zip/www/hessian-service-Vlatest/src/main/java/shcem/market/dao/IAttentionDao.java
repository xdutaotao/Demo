package shcem.market.dao;

import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.market.dao.model.Attention;
import shcem.market.dao.model.FollowStatistics;

/**
 * Created by lihaifeng on 2017/2/24.
 */
public interface IAttentionDao extends DAO {

    /**
     * 查询获取关注明细
     * @param queryConditions
     * @param pageInfo
     * @return
     */
    List<Attention> getAttentionDetailedList(QueryConditions queryConditions, PageInfo pageInfo, boolean replace);

    /**
     * 获取关注类型
     * @return
     */
    List<Attention> getAttentionTypeList();
    
    /**
     * 导出关注明细到Excel中
     * @param qc
     * @param pageInfo
     * @return
     */
	int getExportAttentionDetailedCount(QueryConditions queryConditions, PageInfo pageInfo);
    
    /**
     * 关注统计
     * @return
     */
    List<FollowStatistics> getAttentionStatistics(int size);

}
