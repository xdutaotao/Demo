package shcem.market.dao.impl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.jdbc.CannotGetJdbcConnectionException;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.market.dao.IQuizActivitiesDao;
import shcem.market.dao.model.QuizActivity;
import shcem.market.dao.model.QuizHistory;
import shcem.market.dao.model.QuizHistoryAndQuizActivity;
import shcem.market.dao.model.QuizMoney;
import shcem.market.dao.model.QuizMoneyPool;
import shcem.market.dao.model.QuizWinningResult;
import shcem.market.dao.model.GuizHistory;
import shcem.util.CommonRowMapper;
import shcem.util.DataUtil;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.market.dao.model.QueryGuizHistory;

public class QuizActivitiesDaoImpl extends BaseDAOImpl implements
		IQuizActivitiesDao {

	@Override
	public int addQuizActivities(String userName, QuizActivity quizActivity) {
		this.log.info("addQuizActivities DAO Start");
		String sql = this.sqlProperty.getProperty("QuizDao_001");
		Object [] params = {
				quizActivity.getCategory(),//品类
			quizActivity.getContractName(),//合约名称
			new BigDecimal(0),//合约价格
			quizActivity.getQuizDate(),//竞猜日期
			0,//当前禁用类型
			userName,//创建人
			userName,//修改人
			1,//竞猜活动
			quizActivity.getSettlementPrice() == null ? new BigDecimal(0) : quizActivity.getSettlementPrice(),// 结算价格
			quizActivity.getAnswer()// 官方解读
		};
		int quizActivityID = 0;
		try {
			quizActivityID = this.queryForIntID(sql, params);
		} catch (Exception e) {
			this.log.info(this.getClass().getName()+"新增合约失败,原因:"+e.getMessage());
			quizActivityID = -1;
		}
		this.log.info("addQuizActivities DAO End");
		return quizActivityID;
	}
	
	@Override
	public int addQuizMoney(String userName,int moneyTerm,
			BigDecimal quizMoney,Date quizDate) {
		this.log.info("addQuizMoney DAO Start");
		int returnCode = 0;
		String sql = this.sqlProperty.getProperty("QuizDao_002");
		Object [] params = {
				moneyTerm,//中奖等级
				quizMoney,//中奖金额
				DataUtil.StringToDate(DataUtil.DateToString(quizDate, "yyyy-MM-dd")),//竞猜日期
				userName,//创建人
				userName//修改人
		};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.info(this.getClass().getName()+"新增合约设置奖金失败,原因:"+e.getMessage());
			returnCode = -1;
		}
		
		this.log.info("addQuizMoney DAO End");
		return returnCode;
	}
	
	@Override
	public List<QueryGuizHistory> queryCouponTypeList(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.debug("queryCouponTypeList DAO Start");
		String sql = sqlProperty.getProperty("QuizDao_004");
		return super.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(
				new QueryGuizHistory()));
	}

	/**
	 * 获取 前3条 竞猜记录 列表
	 * 条件 当前查询日期下，竞猜金额是在 (合约金额 - folatValue <= 竞猜金额 <= 合约金额 + folatValue)
	 * 排序：取正（竞猜金额 -合约金额） ASC，竞猜日期 ASC
	 * @param date
	 * @param folatValue 浮动值  正负
	 * 获取 竞猜记录 列表
	 * 
	 * @param date
	 *            时间(yyyy-mm-dd)
	 * @return
	 */
	@Override
	public List<QuizHistoryAndQuizActivity> selectGuizHistoryList(String date,Integer folatValue) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"selectGuizHistoryList DAO Start");
		String sql = sqlProperty.getProperty("Market_001");
		Object[] params = {date,folatValue,folatValue};
		List<QuizHistoryAndQuizActivity> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new QuizHistoryAndQuizActivity()));
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"selectGuizHistoryList DAO End");
		return list;
	}
	
	@Override
	public int insertQuizWinningResult(QuizWinningResult quizWinningResult) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"insertQuizWinningResult DAO Start");
		String sql = sqlProperty.getProperty("Market_002");
		Object[] params = {0,
				quizWinningResult.getQuizHistoryID(),
				quizWinningResult.getMoneyTerm(),
				quizWinningResult.getBonus(),
				quizWinningResult.getQuizDate()
				};
		int count = this.updateBySQL(sql, params);
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"insertQuizWinningResult DAO End");
		return count;
	}

	@Override
	public List<QuizMoneyPool> selectQuizMoneyPoolList() {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"selectQuizMoneyPoolList DAO Start");
		String sql = sqlProperty.getProperty("Market_003");
		Object[] params = {};
		List<QuizMoneyPool>  list = this.queryBySQL(sql, params, null, new CommonRowMapper(new QuizMoneyPool()));
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"selectQuizMoneyPoolList DAO End");
		return list;
	}

	@Override
	public int insertQuizMoney(QuizMoney quizMoney) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"insertQuizMoney DAO Start");
		String sql = sqlProperty.getProperty("Market_004");
		Object[] params = {
				quizMoney.getMoneyTerm(),
				quizMoney.getMoney(),
				quizMoney.getQuizDate(),
				quizMoney.getREC_CREATEBY(),
				quizMoney.getREC_MODIFYBY()
				};
		int count = this.updateBySQL(sql, params);
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"insertQuizMoney DAO End");
		return count;
	}
	@Override
	public List<QuizMoney> selectQuizMoneyListByDate(String date) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"selectQuizMoneyListByDate DAO Start");
		String sql = sqlProperty.getProperty("Market_005");
		Object[] params = {date};
		List<QuizMoney>  list = this.queryBySQL(sql, params, null, new CommonRowMapper(new QuizMoney()));
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"selectQuizMoneyListByDate DAO End");
		return list;
	}

	@Override
	public int insertQuizMoneyPool(QuizMoneyPool quizMoneyPool) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"insertQuizMoneyPool DAO Start");
		String sql = sqlProperty.getProperty("Market_006");
		Object[] params = {
				quizMoneyPool.getPoolMoney(),
				quizMoneyPool.getMoneyTerm(),
				quizMoneyPool.getREC_CREATEBY(),
				quizMoneyPool.getREC_MODIFYBY()
				};
		int count = this.updateBySQL(sql, params);
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"insertQuizMoneyPool DAO End");
		return count;
	}

	@Override
	public int updateQuizMoneyByQuizDate(QuizMoney quizMoney,String quizDateStr) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"updateQuizMoneyByQuizDate DAO Start");
		String sql = sqlProperty.getProperty("Market_007");
		Object[] params = {
				quizMoney.getMoney(),
				quizMoney.getREC_MODIFYBY(),
				quizMoney.getMoneyTerm(),
				quizDateStr
				};
		int count = this.updateBySQL(sql, params);
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"updateQuizMoneyByQuizDate DAO End");
		return count;
	}

	@Override
	public QuizMoney selectQuizMoney(String date, Integer moneyTerm) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"selectQuizMoney DAO Start");
		String sql = sqlProperty.getProperty("Market_008");
		Object[] params = {date,moneyTerm};
		QuizMoney  quizMoney = (QuizMoney) this.queryForObject(sql, params, new CommonRowMapper(new QuizMoney()));
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"selectQuizMoney DAO End");
		return quizMoney;
	}

	@Override
	public List<QuizActivity> selectQuizActivityByQuizDate(String date) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"selectQuizActivityByQuizDate DAO Start");
		String sql = sqlProperty.getProperty("Market_009");
		Object[] params = {date};
		List<QuizActivity>  list = this.queryBySQL(sql, params, null, new CommonRowMapper(new QuizActivity()));
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"selectQuizActivityByQuizDate DAO End");
		return list;
	}

	@Override
	public int updateQuizMoneyPoolByMoneyTerm(BigDecimal poolMoney,Integer moneyTerm) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"updateQuizMoneyPoolByMoneyTerm DAO Start");
		String sql = sqlProperty.getProperty("Market_010");
		Object[] params = {poolMoney,moneyTerm};
		int count = this.updateBySQL(sql, params);
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"updateQuizMoneyPoolByMoneyTerm DAO End");
		return count;
	}
	
	public BigDecimal getQuizMoneyPoolMoney() {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()
				+ "getQuizMoneyPoolMoney DAO Start");
		String sql = this.sqlProperty.getProperty("QuizDao_003");
		Object [] params = {};
		QuizActivity quizActivity = (QuizActivity) this.queryForObject(sql, params, new CommonRowMapper(new QuizActivity()));
		this.log.debug(QuizActivitiesDaoImpl.class.getName()
				+ "getQuizMoneyPoolMoney DAO End");
		return quizActivity.getPoolMoney();
	}
	@Override
	public int updateQuizMoneyPoolMoney() {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()
				+ "updateQuizMoneyPoolMoney DAO Start");
		String sql = this.sqlProperty.getProperty("QuizDao_007");
		Object [] params = {};
		int returnCode = 0;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" 修改资金池金额出错："+e.getMessage());
			returnCode = -1;
		}
		this.log.debug(QuizActivitiesDaoImpl.class.getName()
				+ "updateQuizMoneyPoolMoney DAO End");
		return returnCode;
	}

	@Override
	public int updateQuizActivitiesPrice(String userName,
			QuizActivity quizActivity) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()
				+ "updateQuizActivitiesPrice DAO Start");
		String sql = this.sqlProperty.getProperty("QuizDao_008");
		Object [] params = {
				quizActivity.getContractName(),//合约名称
				quizActivity.getContractPrice(),//价格
				userName,
				quizActivity.getSettlementPrice(),// 结算价格
				quizActivity.getCategory(),//品类
				DataUtil.DateToString(quizActivity.getQuizDate(),"yyyy-MM-dd")
		};
		int returnCode = 0;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" 修改资金池金额出错："+e.getMessage());
			returnCode = -1;
		}
		this.log.debug(QuizActivitiesDaoImpl.class.getName()
				+ "updateQuizActivitiesPrice DAO End");
		return returnCode;
	}
	@Override
	public List<QuizActivity> getQuizActivitiesList(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()
				+ "getQuizActivitiesList DAO Start");
		String sql = this.sqlProperty.getProperty("QuizDao_006");
		List<QuizActivity> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new QuizActivity()));
		this.log.debug(QuizActivitiesDaoImpl.class.getName()
				+ "getQuizActivitiesList DAO End");
		return list;
	}
	
	@Override
	public List<QuizActivity> getQuizActivitiesDetail(String quizDate) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()
				+ "getQuizActivitiesDetail DAO Start");
		String sql = this.sqlProperty.getProperty("QuizDao_005");
		Object [] params = {
				DataUtil.DateToString(DataUtil.StringToDate(quizDate,"yyyy-MM-dd"))
//				DataUtil.StringToDate(quizDate,"yyyy-MM-dd")
		};
		List<QuizActivity> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new QuizActivity()));
		this.log.debug(QuizActivitiesDaoImpl.class.getName()
				+ "getQuizActivitiesDetail DAO End");
		return list;
	}
	
	@Override
	public void rollBack() {
		try {
			getConnection().setAutoCommit(false);// 事务设置为手动
			getConnection().rollback();
		} catch (CannotGetJdbcConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public int updateQueryGuizHistoryInIdList(Integer status, List<Integer> idList,
			String date) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+".updateQueryGuizHistoryInIdList DAO Start");
		
		List<QuizActivity> quizActivityList = this.getQuizActivitiesDetail(date);
		String quizActivityIDStr = "";
		boolean bool = true;
		for (QuizActivity qizActivity : quizActivityList){
			if (bool){
				quizActivityIDStr+= qizActivity.getId();
				bool = false;
			}else{
				quizActivityIDStr+= ","+qizActivity.getId();
			}
		}
		String sql = sqlProperty.getProperty("Market_011") + " and QuizActivity_ID IN ("+quizActivityIDStr+") ";
		String sqltemp = "";
		if (idList != null && idList.size() > 0){
			String idStr = "";
			for (int i = 0; i < idList.size(); i++ ){
				Integer id = idList.get(i);
				if (i==0){
					idStr += ""+id;
				}else{
					idStr += ","+id;
				}
			}
			sqltemp = " and ID IN("+idStr+")";
		}
		sql = sql +sqltemp;
		Object[] params = {status,"system"};
		int count = this.updateBySQL(sql, params);
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+".updateQueryGuizHistoryInIdList DAO End");
		return count;
	}

	@Override
	public int updateQueryGuizHistoryNotInIdList(Integer status,
			List<Integer> idList, String date) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+".updateQueryGuizHistoryNotInIdList DAO Start");
		List<QuizActivity> quizActivityList = this.getQuizActivitiesDetail(date);
		String quizActivityIDStr = "";
		boolean bool = true;
		for (QuizActivity qizActivity : quizActivityList){
			if (bool){
				quizActivityIDStr+= qizActivity.getId();
				bool = false;
			}else{
				quizActivityIDStr+= ","+qizActivity.getId();
			}
		}
		String sql = sqlProperty.getProperty("Market_011") + " and QuizActivity_ID IN ("+quizActivityIDStr+") ";
		String sqltemp = "";
		if (idList != null && idList.size() > 0){
			String idStr = "";
			for (int i = 0; i < idList.size(); i++ ){
				Integer id = idList.get(i);
				if (i==0){
					idStr += ""+id;
				}else{
					idStr += ","+id;
				}
			}
			sqltemp = " and ID NOT IN("+idStr+")";
		}
		sql = sql +sqltemp;
		Object[] params = {status,"system"};
		int count = this.updateBySQL(sql, params);
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+".updateQueryGuizHistoryNotInIdList DAO End");
		return count;
	}
	
	@Override
	public int deleteQuizActivitie(String quizDateString) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+".deleteQuizActivitie DAO Start");
		int returnCode = 0;
		Object [] params = {};
		String sql = this.sqlProperty.getProperty("QuizDao_009")+" in ("+quizDateString+")";
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" deleteQuizActivitie 删除失败:"+e.getMessage());
			returnCode = -1;
		}
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+".deleteQuizActivitie DAO End");
		return returnCode;
	}
	
	@Override
	public int deleteQuizMoney(String quizDateString) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+".deleteQuizMoney DAO Start");
		int returnCode = 0;
		Object [] params = {};
		String sql = this.sqlProperty.getProperty("QuizDao_010")+" in ("+quizDateString+")";
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" deleteQuizMoney 删除失败:"+e.getMessage());
			returnCode = -1;
		}
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+".deleteQuizMoney DAO End");
		return returnCode;
	}
	
	@Override
	public List<QuizActivity> getQuizActivitiesListByQuizDate(
			String quizDateString) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()
				+ "getQuizActivitiesListByQuizDate DAO Start");
		String sql = this.sqlProperty.getProperty("QuizDao_011");
		Object [] params ={
				quizDateString
		};
		List<QuizActivity> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new QuizActivity()));
		this.log.debug(QuizActivitiesDaoImpl.class.getName()
				+ "getQuizActivitiesListByQuizDate DAO End");
		return list;
	}
	
	@Override
	public List<QuizActivity> getQuizActivitieDetailByQuizDate(String quizDateString) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()
				+ "getQuizActivitieDetailByQuizDate DAO Start");
		String sql = this.sqlProperty.getProperty("QuizDao_011");
		Object [] params ={
				quizDateString
		};
		List<QuizActivity> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new QuizActivity()));
		this.log.debug(QuizActivitiesDaoImpl.class.getName()
				+ "getQuizActivitieDetailByQuizDate DAO End");
		return list;
	}

	@Override
	public int updateQuizMoney(String userName, BigDecimal quizMoney,
			int moneyTerm, Date quizDate) {
		this.log.info("updateQuizMoney DAO Start");
		String sql = this.sqlProperty.getProperty("QuizDao_012");
		Object [] params = {
			quizMoney,
			userName,
			moneyTerm,
			DataUtil.DateToString(quizDate, "yyyy-MM-dd")
		};
		int returnCode = 0;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.info(this.getClass().getName()+"修改合约奖金失败,原因:"+e.getMessage());
			returnCode = -1;
		}
		this.log.info("updateQuizMoney DAO End");
		return returnCode;
	}
	
	@Override
	public int getQuizMoneyCount(int moneyTerm, Date quizDate) {
		this.log.info("getQuizMoneyCount DAO Start");
		String sql = this.sqlProperty.getProperty("QuizDao_013");
		Object [] params = {
				moneyTerm,
			DataUtil.DateToString(quizDate, "yyyy-MM-dd")
		};
		int count = this.queryForInt(sql, params);
		this.log.info("getQuizMoneyCount DAO End");
		return count;
	}
	
	@Override
	public Integer countGuizHistory(String date) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"countGuizHistory DAO Start");
		String sql = sqlProperty.getProperty("Market_012");
		Object[] params = {date};
		GuizHistory guizHistory = (GuizHistory) this.queryForObject(sql, params, new CommonRowMapper(new GuizHistory()));
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"countGuizHistory DAO End");
		return guizHistory.getCounts();
	}

	
	/**
	 * 根据：当前日期 获取 [竞猜活动合约价格表] 中的  下一个竞猜日期
	 * @param date 当前日期
	 * @return
	 */
	@Override
	public Date getCurrentDateOfNextQuizDateFormQuizActivity(String date){
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+ "getCurrentDateOfNextQuizDate DAO Start");
		Date quizDate = null;
		String sql = this.sqlProperty.getProperty("Market_013");
		Object [] params ={date};
		QuizActivity obj = (QuizActivity) this.queryForObject(sql, params, new CommonRowMapper(new QuizActivity()));
		if (obj != null){
			quizDate = obj.getQuizDate();
		}
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+ "getCurrentDateOfNextQuizDate DAO End");
		return quizDate;
	}
	
	/**
	 * 根据：当前日期 获取 [竞猜活动奖金设置表] 中的  下一个竞猜日期
	 * @param date 当前日期
	 * @return
	 */
	@Override
	public Date getCurrentDateOfNextQuizDateFormQuizMoney(String date) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+ "getCurrentDateOfNextQuizDateFormQuizMoney DAO Start");
		Date quizDate = null;
		String sql = this.sqlProperty.getProperty("Market_014");
		Object [] params ={date};
		QuizMoney obj = (QuizMoney) this.queryForObject(sql, params, new CommonRowMapper(new QuizMoney()));
		if (obj != null){
			quizDate = obj.getQuizDate();
		}
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+ "getCurrentDateOfNextQuizDateFormQuizMoney DAO End");
		return quizDate;
	}

	@Override
	public int updateQuizActivityOfAnswer(String answer,String modifyby,String quizDateStr) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"updateQuizActivityOfAnswer DAO Start");
		String sql = sqlProperty.getProperty("Market_015");
		Object[] params = {answer,modifyby,DataUtil.DateToString(DataUtil.StringToDate(quizDateStr,"yyyy-MM-dd"))};
		int count = this.updateBySQL(sql, params);
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"updateQuizActivityOfAnswer DAO End");
		return count;
	}

	@Override
	public QuizActivity getQuizActivity(String quizDateStr) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"getQuizActivity DAO Start");
		String sql = sqlProperty.getProperty("Market_016");
		Object [] params = {
				DataUtil.DateToString(DataUtil.StringToDate(quizDateStr,"yyyy-MM-dd"))
		};
		QuizActivity qa = (QuizActivity) this.queryForObject(sql, params, new CommonRowMapper(new QuizActivity()));
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"getQuizActivity DAO End");
		return qa;
	}

	@Override
	public int insertQuizHistory(QuizHistory quizHistory) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"insertQuizHistory DAO Start");
		String sql = sqlProperty.getProperty("Market_017");
		Object[] params = {
				0,
				quizHistory.getREC_CREATEBY(),
				quizHistory.getREC_CREATETIME(),
				quizHistory.getREC_MODIFYBY(),
				quizHistory.getREC_MODIFYTIME(),
				quizHistory.getTraderID() == null ? "" : quizHistory.getTraderID(),
				quizHistory.getTraderName() == null ? "" : quizHistory.getTraderName(),
				quizHistory.getMobile() == null ? "" : quizHistory.getMobile(),
				quizHistory.getQuizPrice() == null ? 0 : quizHistory.getQuizPrice(),
				0,
				quizHistory.getQuizActivity_ID(),
				quizHistory.getSourceFrom()
		};
		int count = this.updateBySQL(sql, params);
		this.log.debug(QuizActivitiesDaoImpl.class.getName()+"insertQuizHistory DAO End");
		return count;
	}

	@Override
	public List<QuizActivity> getValidateQuizActivitiesList(String quizDate, String filter) {
		this.log.debug(QuizActivitiesDaoImpl.class.getName()
				+ "getValidateQuizActivitiesList DAO Start");
		String sql = this.sqlProperty.getProperty("QuizDao_017") + filter;
		Object [] params = {
				DataUtil.DateToString(DataUtil.StringToDate(quizDate,"yyyy-MM-dd"))
		};
		List<QuizActivity> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new QuizActivity()));
		this.log.debug(QuizActivitiesDaoImpl.class.getName()
				+ "getValidateQuizActivitiesList DAO End");
		return list;
	}

	@Override
	public List<QuizHistory> getPrize10(String quizDate) {
		
		String sql = this.sqlProperty.getProperty("QuizDao_018");
		Object [] params = {
				DataUtil.DateToString(DataUtil.StringToDate(quizDate,"yyyy-MM-dd")),
				DataUtil.DateToString(DataUtil.StringToDate(quizDate,"yyyy-MM-dd")),
				DataUtil.DateToString(DataUtil.StringToDate(quizDate,"yyyy-MM-dd")),
				DataUtil.DateToString(DataUtil.StringToDate(quizDate,"yyyy-MM-dd"))
		};
		List<QuizHistory> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new QuizHistory()));
		return list;
	}
	
	@Override
	public List<QuizHistory> getPrize20(String quizDate) {
		
		String sql = this.sqlProperty.getProperty("QuizDao_019");
		Object [] params = {
				DataUtil.DateToString(DataUtil.StringToDate(quizDate,"yyyy-MM-dd")),
				DataUtil.DateToString(DataUtil.StringToDate(quizDate,"yyyy-MM-dd"))
		};
		List<QuizHistory> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new QuizHistory()));
		this.log.debug(QuizActivitiesDaoImpl.class.getName()
				+ "getValidateQuizActivitiesList DAO End");
		return list;
	}
	
	@Override
	public List<QuizHistory> getPrize30(String quizDate) {
		
		String sql = this.sqlProperty.getProperty("QuizDao_020");
		Object [] params = {
				DataUtil.DateToString(DataUtil.StringToDate(quizDate,"yyyy-MM-dd"))
		};
		List<QuizHistory> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new QuizHistory()));
		this.log.debug(QuizActivitiesDaoImpl.class.getName()
				+ "getValidateQuizActivitiesList DAO End");
		return list;
	}

	@Override
	public List<QuizWinningResult> getWinningResultList(String filter) {
		String sql = this.sqlProperty.getProperty("QuizDao_021");
		sql = sql + filter;
		List<QuizWinningResult> list = getJdbcTemplate().query(sql, new CommonRowMapper(new QuizWinningResult()));
		return list;
	}

	@Override
	public List<QuizHistory> getModifiedQuizHistoryList(String quizDate) {
		String sql = this.sqlProperty.getProperty("QuizDao_022");
		Object [] params = {
				DataUtil.DateToString(DataUtil.StringToDate(quizDate,"yyyy-MM-dd"))
		};
		List<QuizHistory> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new QuizHistory()));
		return list;
	}
	
}
