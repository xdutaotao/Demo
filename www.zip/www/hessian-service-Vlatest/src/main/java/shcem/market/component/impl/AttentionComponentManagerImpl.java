package shcem.market.component.impl;

import java.util.ArrayList;
import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.market.component.IAttentionComponentManager;
import shcem.market.dao.IAttentionDao;
import shcem.market.dao.model.Attention;
import shcem.market.dao.model.ExportNewCouponTrans;
import shcem.market.dao.model.FollowStatistics;
import shcem.market.dao.model.NewCouponTrans;
import shcem.util.DateUtil;

/**
 * Created by lihaifeng on 2017/2/24.
 */
public class AttentionComponentManagerImpl extends BaseManager implements IAttentionComponentManager {

    private IAttentionDao attentionDao;

    private IAttentionDao attentionDao_read;

    public void setAttentionDao(IAttentionDao attentionDao) {
        this.attentionDao = attentionDao;
    }

    public void setAttentionDao_read(IAttentionDao attentionDao_read) {
        this.attentionDao_read = attentionDao_read;
    }

    @Override
    public List<Attention> getAttentionDetailedList(QueryConditions queryConditions, PageInfo pageInfo) {
        return this.attentionDao_read.getAttentionDetailedList(queryConditions, pageInfo, false);
    }


    @Override
	public List<Attention> getAttentionTypeList() {
		this.log.info(this.getClass().getName()+"getAttentionTypeList Start");
		List<Attention> list = new ArrayList<Attention>();
		list = this.attentionDao_read.getAttentionTypeList();
		this.log.info(this.getClass().getName()+"getAttentionTypeList End");
		return list;
	}
    
	@Override
	public int getExportAttentionDetailedCount(QueryConditions queryConditions, PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+" getExportAttentionDetailedCount Start");
		int totalCount = this.attentionDao_read.getExportAttentionDetailedCount(queryConditions,pageInfo);
		this.log.info(this.getClass().getName()+" getExportAttentionDetailedCount End");
		return totalCount;
	}
    
	/**
	 * 导出关注明细到Excel中
	 */
	@Override
	public List<Attention> getExportAttentionDetailedExcel(QueryConditions queryConditions, PageInfo pageInfo, boolean replace) {
		// TODO Auto-generated method stub
		this.log.info(this.getClass().getName()+".getExportAttentionDetailedExcel() component Start");
		List<Attention> list = attentionDao_read.getAttentionDetailedList(queryConditions, pageInfo, replace);
		List<Attention> attentionList = new ArrayList<Attention>();
		Attention attention = null;
		for (Attention model : list ){
			attention = new Attention();
			
			attention.setTraderID(model.getTraderID());
			attention.setTraderName(model.getTraderName());
			attention.setFirmID(model.getFirmID());
			attention.setFirmName(model.getFirmName());
			if(model.getAttentionType()==1){
				String searchKeys = model.getSearchKeys();
				String[] searchKeysList = searchKeys.split("-", searchKeys.length()); 
				int numLength = searchKeysList.length-1;
				String searchKeysName = "";
				for(int i=0;i <numLength; i++){
					if(i > 0)searchKeysName+="-";
					searchKeysName+=searchKeysList[i];
				}
				attention.setSearchKeys(searchKeysName); //品类-牌号//searchKeysList[0]+"-"+searchKeysList[1]
				attention.setSearchKeysExtend(searchKeysList[searchKeysList.length - 1]); //产地
			}else{
				attention.setSearchKeys(model.getSearchKeys()); //交收方式 、交易场名称、交货地名称
			}
			attentionList.add(attention);
		}
		this.log.info(this.getClass().getName()+".getExportAttentionDetailedExcel() component End");
		return attentionList;
	}
	
    @Override
	public List<FollowStatistics> getAttentionStatistics(int size) {
		this.log.info(this.getClass().getName()+"getAttentionStatistics Start");
		List<FollowStatistics> list= this.attentionDao_read.getAttentionStatistics(size);
		this.log.info(this.getClass().getName()+"getAttentionStatistics End");
		return list;
	}

}
