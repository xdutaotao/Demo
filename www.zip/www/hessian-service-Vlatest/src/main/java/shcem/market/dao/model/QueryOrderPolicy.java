package shcem.market.dao.model;

import java.math.BigDecimal;

import shcem.base.dao.model.BaseObject;

/**
 * 订单报价列表模型
 * @author sunf
 *
 */
public class QueryOrderPolicy extends BaseObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5883376942472221470L;

	
	private Integer policyId;
	/**
	 * 成交ID
	 */
	private String orderId;
	/**
	 * 交收ID
	 */
	private String deliveryID;
	/**
	 * 交易商ID
	 */
	private String firmID;
	/**
	 * 交易商名称
	 */
	private String firmName;
	/**
	 * 保单类型
	 */
	private String typeName;
	/**
	 * 均差价
	 */
	private BigDecimal averageDeltaPrice;
	/**
	 * 实收数量
	 */
	private BigDecimal takenQuantity;
	/**
	 * 成交价
	 */
	private BigDecimal price;
	/**
	 * 已付保额
	 */
	private BigDecimal paidAmount;
	/**
	 * 应退保金额
	 */
	private BigDecimal shouldBackAmount;
	/**
	 * 实退保金额
	 */
	private BigDecimal realBackAmount;
	/**
	 * 保单费用
	 */
	private BigDecimal premium;
	
	/**
	 * 退保状态
	 * 0:未申请
	 * 5：已申请
	 * 10：已支付
	 */
	private Integer backStatus;
	
	/**
	 * 差价
	 */
	private BigDecimal deltaPrice;
	
	/**
	 * 交易商类型
	 * 0：卖方交易商 1:买方交易商 
	 */
	private Integer firmType;
	
	/**
	 * 保单状态
	 * 1：未处理 5：未中保 10：已中保
	 */
	private Integer policyStatus;
	
	/**
	 * 申请人
	 */
	private String applicant;
	
	/**
	 * 申请日期
	 */
	private String applicationTime;
	// 备注
	private String remarks;
	// 退保表ID
	private Integer backID;
	
	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getBackID() {
		return backID;
	}

	public void setBackID(Integer backID) {
		this.backID = backID;
	}

	public String getApplicant() {
		return applicant;
	}

	public void setApplicant(String applicant) {
		this.applicant = applicant;
	}

	public String getApplicationTime() {
		return applicationTime;
	}

	public void setApplicationTime(String applicationTime) {
		this.applicationTime = applicationTime;
	}

	public Integer getPolicyId() {
		return policyId;
	}

	public void setPolicyId(Integer policyId) {
		this.policyId = policyId;
	}

	public Integer getPolicyStatus() {
		return policyStatus;
	}

	public void setPolicyStatus(Integer policyStatus) {
		this.policyStatus = policyStatus;
	}

	public BigDecimal getDeltaPrice() {
		return deltaPrice;
	}

	public void setDeltaPrice(BigDecimal deltaPrice) {
		this.deltaPrice = deltaPrice;
	}

	public Integer getFirmType() {
		return firmType;
	}

	public void setFirmType(Integer firmType) {
		this.firmType = firmType;
	}

	public Integer getBackStatus() {
		return backStatus;
	}

	public void setBackStatus(Integer backStatus) {
		this.backStatus = backStatus;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getDeliveryID() {
		return deliveryID;
	}

	public void setDeliveryID(String deliveryID) {
		this.deliveryID = deliveryID;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public BigDecimal getAverageDeltaPrice() {
		return averageDeltaPrice;
	}

	public void setAverageDeltaPrice(BigDecimal averageDeltaPrice) {
		this.averageDeltaPrice = averageDeltaPrice;
	}

	public BigDecimal getTakenQuantity() {
		return takenQuantity;
	}

	public void setTakenQuantity(BigDecimal takenQuantity) {
		this.takenQuantity = takenQuantity;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public BigDecimal getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(BigDecimal paidAmount) {
		this.paidAmount = paidAmount;
	}

	public BigDecimal getShouldBackAmount() {
		return shouldBackAmount;
	}

	public void setShouldBackAmount(BigDecimal shouldBackAmount) {
		this.shouldBackAmount = shouldBackAmount;
	}

	public BigDecimal getRealBackAmount() {
		return realBackAmount;
	}

	public void setRealBackAmount(BigDecimal realBackAmount) {
		this.realBackAmount = realBackAmount;
	}

	public BigDecimal getPremium() {
		return premium;
	}

	public void setPremium(BigDecimal premium) {
		this.premium = premium;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
