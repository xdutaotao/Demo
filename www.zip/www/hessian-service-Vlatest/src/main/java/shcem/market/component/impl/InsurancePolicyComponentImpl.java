package shcem.market.component.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.constant.Constants;
import shcem.finance.component.IVoucherManager;
import shcem.finance.util.FinanceSysData;
import shcem.market.component.IInsurancePolicyComponent;
import shcem.market.dao.IInsurancePolicyDao;
import shcem.market.dao.model.ExportInsuranceBack;
import shcem.market.dao.model.ExportOrderPolicy;
import shcem.market.dao.model.InsuranceBack;
import shcem.market.dao.model.InsurancePolicy;
import shcem.market.dao.model.InsurancePolicyDetail;
import shcem.market.dao.model.InsurancePolicyPrice;
import shcem.market.dao.model.InsurancePolicyType;
import shcem.market.dao.model.QueryOrderPolicy;
import shcem.market.service.model.AuditInsuranceBackVo;
import shcem.market.service.model.InsurancePolicyPriceDto;
import shcem.market.service.model.InsurancePolicyPriceVo;
import shcem.market.service.model.PolicyBackApplyDto;
import shcem.trade.dao.IDeliveryDAO;
import shcem.trade.dao.OrderDAO;
import shcem.trade.dao.model.Delivery;
import shcem.trade.dao.model.Order;
import shcem.util.CommonUtils;
import shcem.util.DateUtil;

/**
 * 保单相关Component实现
 * 
 * @author wangshuai
 *
 */
public class InsurancePolicyComponentImpl extends BaseManager implements IInsurancePolicyComponent {

	private String className = InsurancePolicyComponentImpl.class.getName() + " ";

	private IInsurancePolicyDao insurancePolicyDao;
	private IInsurancePolicyDao insurancePolicyDao_read;
	private IDeliveryDAO deliveryDAO;
	private OrderDAO orderDAO;
	public void setDeliveryDAO(IDeliveryDAO deliveryDAO) {
		this.deliveryDAO = deliveryDAO;
	}

	public void setOrderDAO(OrderDAO orderDAO) {
		this.orderDAO = orderDAO;
	}

	public void setInsurancePolicyDao(IInsurancePolicyDao insurancePolicyDao) {
		this.insurancePolicyDao = insurancePolicyDao;
	}

	public void setInsurancePolicyDao_read(IInsurancePolicyDao insurancePolicyDao_read) {
		this.insurancePolicyDao_read = insurancePolicyDao_read;
	}

	@Override
	public int addInsurancePolicyPrice(InsurancePolicyPriceDto insurancePolicyPriceDto) {
		this.log.debug(className + "addInsurancePolicyPrice Component Start");
		int resultCode = 0;
		// 检查传入的日期在保价中是否存在
		Map<String, Object> map = checkPolicyDate(insurancePolicyPriceDto.getPolicyDateList());
		// 不存在日期
		List<Date> newDateList = (List<Date>) map.get("newDateList");
		// 存在的日期
		String dateStr = (String) map.get("dateStr");
		if (dateStr.length() > 0) {
			this.log.debug("存在的日期：" + dateStr);
		}

		Integer[] categoryType = insurancePolicyPriceDto.getCategoryType() == null ? new Integer[0]
				: insurancePolicyPriceDto.getCategoryType();
		// String[] categoryName = insurancePolicyPriceDto.getCategoryName() ==
		// null ? new String[0] : insurancePolicyPriceDto.getCategoryName();
		BigDecimal[] settlementPrice = insurancePolicyPriceDto.getSettlementPrice() == null ? new BigDecimal[0]
				: insurancePolicyPriceDto.getSettlementPrice();
		Integer newDateListSize = newDateList.size();

		if (newDateListSize > 0) {
			Integer size = categoryType.length;
			InsurancePolicyPrice ipp = new InsurancePolicyPrice();
			ipp.setREC_CREATEBY(insurancePolicyPriceDto.getCurrentUser());
			ipp.setREC_MODIFYBY(insurancePolicyPriceDto.getCurrentUser());
			for (int i = 0; i < size; i++) {
				if (categoryType[i] == 1) {
					ipp.setCategoryName("PE");
				}
				if (categoryType[i] == 2) {
					ipp.setCategoryName("PP");
				}
				// ipp.setCategoryName(categoryName[i]);
				ipp.setCategoryType(categoryType[i]);
				ipp.setSettlementPrice(settlementPrice[i]);
				for (Date newDate : newDateList) {
					ipp.setPolicyDate(newDate);
					insurancePolicyDao.insertInsurancePolicyPrice(ipp);
				}
			}
		} else {
			resultCode = -110002;// 您选择的日期范围的数据已经存在，请重新选择！
		}
		this.log.debug(className + "addInsurancePolicyPrice Component End");
		return resultCode;
	}

	private Map<String, Object> checkPolicyDate(List<Date> dateList) {
		this.log.debug(className + "checkPolicyDate Start");
		Map<String, Object> map = new HashMap<String, Object>();
		StringBuilder sb = new StringBuilder();
		List<Date> newDateList = new ArrayList<Date>();
		for (Date date : dateList) {
			String dateStr = DateUtil.convert(date, "yyyy-MM-dd");
			InsurancePolicyPriceVo vo = this.getInsurancePolicyPrice(dateStr);
			if (vo != null) {
				sb.append(dateStr + ",");
			} else {
				newDateList.add(date);
			}
		}
		map.put("newDateList", newDateList);// 保价表中没有的保单日期
		map.put("dateStr", sb.toString());// 保价表中有的保单日期
		this.log.debug(className + "checkPolicyDate End");
		return map;
	}

	@Override
	public List<InsurancePolicyPriceVo> getInsurancePolicyPriceList(QueryConditions qc, PageInfo pageInfo) {
		this.log.debug(className + "getInsurancePolicyPriceList Component Start");
		List<InsurancePolicyPriceVo> list = insurancePolicyDao_read.getInsurancePolicyPriceList(qc, pageInfo);
		for (InsurancePolicyPriceVo vo : list) {
			if (DateUtil.convert(new Date(), "yyyy-MM-dd").equals(DateUtil.convert(vo.getPolicyDate(), "yyyy-MM-dd"))) {
				vo.setCurrentDateStatus(1);
			} else {
				vo.setCurrentDateStatus(0);
			}
		}

		this.log.debug(className + "getInsurancePolicyPriceList Component End");
		return list;
	}

	@Override
	public List<QueryOrderPolicy> getOrderPolicyList(QueryConditions qc, PageInfo pageInfo) {
		this.log.debug(className + "getOrderPolicyList Component Start");
		List<QueryOrderPolicy> list = insurancePolicyDao_read.getOrderPolicyList(qc, pageInfo);
		this.log.debug(className + "getOrderPolicyList Component Start");
		return list;
	}

	@Override
	public InsurancePolicyPriceVo getInsurancePolicyPrice(String policyDateStr) {
		this.log.debug(className + "getInsurancePolicyPrice Component Start");
		InsurancePolicyPriceVo vo = insurancePolicyDao_read.getInsurancePolicyPrice(policyDateStr);
		this.log.debug(className + "getInsurancePolicyPrice Component End");
		return vo;
	}

	@Override
	public int updateInsurancePolicyPrice(InsurancePolicyPriceDto insurancePolicyPriceDto) {
		this.log.debug(className + "updateInsurancePolicyPrice Component Start");
		int resultCode = 0;
		Integer[] categoryType = insurancePolicyPriceDto.getCategoryType() == null ? new Integer[0]
				: insurancePolicyPriceDto.getCategoryType();
		// String[] categoryName = insurancePolicyPriceDto.getCategoryName() ==
		// null ? new String[0] : insurancePolicyPriceDto.getCategoryName();
		BigDecimal[] settlementPrice = insurancePolicyPriceDto.getSettlementPrice() == null ? new BigDecimal[0]
				: insurancePolicyPriceDto.getSettlementPrice();
		this.log.debug(className + "updateInsurancePolicyPrice Component Start");

		int categoryTypeArrayLength = categoryType.length;

		BigDecimal[] averageDeltaPrice = new BigDecimal[categoryTypeArrayLength];
		Date policyDate = insurancePolicyPriceDto.getPolicyDate();
		// 获得上一个交割日期
		Date previousPolicyDate = insurancePolicyDao_read.getPreviousInsurancePolicyPriceOfPolicyDate(policyDate);
		List<InsurancePolicyPrice> ippList = null;
		int ippListSize = 0;
		if (previousPolicyDate != null) {
			ippList = insurancePolicyDao_read.getInsurancePolicyPriceListByPolicyDate(previousPolicyDate);
			ippListSize = ippList.size();
		}

		for (int i = 0; i < categoryTypeArrayLength; i++) {
			InsurancePolicyPrice iip = new InsurancePolicyPrice();
			iip.setREC_MODIFYBY(insurancePolicyPriceDto.getCurrentUser());
			iip.setSettlementPrice(settlementPrice[i]);
			if (ippList != null && ippListSize > 0) {
				for (int j = 0; j < ippListSize; j++) {
					InsurancePolicyPrice ipp = ippList.get(j);
					if (ipp.getCategoryType().equals(categoryType[i])) {
						averageDeltaPrice[i] = settlementPrice[i].subtract(ipp.getSettlementPrice());
						break;
					}
				}
			}
			iip.setAverageDeltaPrice(averageDeltaPrice[i]);
			iip.setStatus(5);// 审核通过
			iip.setPolicyDate(policyDate);
			iip.setCategoryType(categoryType[i]);
//
//			/**
//			 * 更新保单状态
//			 */
//			if (averageDeltaPrice[i] != null && averageDeltaPrice[i].compareTo(new BigDecimal(0)) != 0) {
//				int code = this.updateInsurancePolicy(averageDeltaPrice[i], categoryType[i],
//						DateUtil.convert(previousPolicyDate, "yyyy-MM-dd"), insurancePolicyPriceDto.getCurrentUser());
//				if (code < 0) {
//					resultCode = code;
//					break;
//				}
//			}

			/**
			 * 更新保价
			 */
			insurancePolicyDao.updateInsurancePolicyPrice(iip);
		}
		this.log.debug(className + "updateInsurancePolicyPrice Component End");
		return resultCode;
	}

	@Override
	public int applyPolicyBack(List<PolicyBackApplyDto> applyList) {
		this.log.debug(className + "applyPolicyBack Component Start");
		if (applyList == null || applyList.size() == 0) {
			return -110012; // 参数有误
		}
		List<InsuranceBack> backList = new ArrayList<InsuranceBack>();
		int retStatus = 0;
		for (PolicyBackApplyDto item : applyList) {
			String deliveryId = item.getDeliveryId();
			// 校验当前交收单在退保表中是否存在
			InsuranceBack insuranceBack = insurancePolicyDao_read.getInsuranceBackByDeliveryID(deliveryId);
			if (insuranceBack != null){
				this.log.debug("当前申请的交收单ID已经被申请，DeliveryID="+insuranceBack.getDeliveryID());
				retStatus = -110011;// 存在已申请交收单，请刷新后再申请！
				break;
			}
			
			
			Delivery delivery = this.deliveryDAO.getDeliveryByID(deliveryId);
			InsurancePolicyDetail detail = this.insurancePolicyDao.getInsurancePolicyDetailById(item.getPolicyId());
			if (delivery == null || detail == null || !delivery.getDeliveryStatus().equals(55)
					|| !delivery.getOrderID().equals(detail.getObjectID())) {
				// 提交信息有误
				retStatus = -110013;
				break;
			}

			InsuranceBack backModel = new InsuranceBack();
			backModel.setApplicant(item.getUserName());
			backModel.setInsurancePolicyID(new Integer(detail.getId()));
			backModel.setInsurancePolicyTypeID(detail.getInsurancePolicyTypeID());
			backModel.setREC_CREATEBY(item.getUserName());
			backModel.setREC_MODIFYBY(item.getUserName());
			backModel.setPolicyDate(detail.getPolicyDate());
			backModel.setShouldBackAmount(delivery.getTakenQuantity().multiply(detail.getPremium()));
			backModel.setDeliveryID(deliveryId);
			backModel.setRemarks(item.getRemarks());
			backList.add(backModel);
		}
		if (retStatus == 0) {
			for (InsuranceBack item : backList) {
				this.insurancePolicyDao.insertInsuranceBack(item);
			}
		}

		this.log.debug(className + "applyPolicyBack Component End");
		return retStatus;
	}

	@Override
	public List<InsurancePolicyPrice> getInsurancePolicyPriceByPolicyDate(String[] policyDateArray) {
		this.log.info(this.getClass().getName() + " getInsurancePolicyPriceByPolicyDate Start");
		List<InsurancePolicyPrice> list = new ArrayList<InsurancePolicyPrice>();
		for (int i = 0; i < policyDateArray.length; i++) {
			List<InsurancePolicyPrice> listTemp = this.insurancePolicyDao_read
					.getInsurancePolicyPriceListByPolicyDate(DateUtil.formatDate(policyDateArray[i], "yyyy-MM-dd"));
			InsurancePolicyPrice ipp = new InsurancePolicyPrice();
			ipp.setPolicyDate(DateUtil.formatDate(policyDateArray[i], "yyyy-MM-dd"));
			if (listTemp != null && listTemp.size() > 0) {
				ipp.setPolicyDateStatus(1);
			} else {
				ipp.setPolicyDateStatus(0);
			}
			list.add(ipp);
		}
		this.log.info(this.getClass().getName() + " getInsurancePolicyPriceByPolicyDate End ");
		return list;
	}

	@Override
	public List<InsurancePolicyPrice> getInsurancePolicyPriceByPolicyDate(Date policyDate) {
		this.log.info(this.getClass().getName() + " getInsurancePolicyPriceByPolicyDate Start");
		List<InsurancePolicyPrice> list = this.insurancePolicyDao_read
				.getInsurancePolicyPriceListByPolicyDate(policyDate);
		this.log.info(this.getClass().getName() + " getInsurancePolicyPriceByPolicyDate End ");
		return list;
	}

	/**
	 * 更新保单
	 * 
	 * @param averageDeltaPrice
	 *            均价差
	 * @param categoryType
	 *            保单品类:1:PE 2:PP
	 * @param policyDateStr
	 *            保单日期(yyyy-MM-dd)
	 * @param modifyby
	 *            修改人
	 * @return
	 */
	@Override
	public int updateInsurancePolicy(BigDecimal averageDeltaPrice, Integer categoryType, String policyDateStr,
			String modifyby) {
		this.log.info(this.getClass().getName() + " updateInsurancePolicy Start");
		int resultCode = 0;
		List<InsurancePolicyType> iptList = insurancePolicyDao_read.getInsurancePolicyTypeList();
		int iptListSize = iptList.size();
		if (iptListSize > 0) {
			if (iptListSize == 1) {
				InsurancePolicyType ipt = iptList.get(0);
				BigDecimal deltaPrice = ipt.getDeltaPrice(); // 差价
				BigDecimal averageDeltaPriceABS = averageDeltaPrice.abs();// 均价差的绝对值
				if (averageDeltaPriceABS.compareTo(deltaPrice) <= 0) { // 均价差的绝对值
																		// <=
																		// 差价,更新保单为未中保
					insurancePolicyDao.updateInsurancePolicy(modifyby, policyDateStr, 0, categoryType, 5, 1);// 更新卖方交易商未中保
					insurancePolicyDao.updateInsurancePolicy(modifyby, policyDateStr, 1, categoryType, 5, 1);// 更新买方交易商未中保
				} else {
					if (averageDeltaPrice.compareTo(new BigDecimal(0)) > 0) { // 均价差
																				// >
																				// 0
						insurancePolicyDao.updateInsurancePolicy(modifyby, policyDateStr, 0, categoryType, 10, 1);// 更新卖方交易商为
																													// 已中保
						insurancePolicyDao.updateInsurancePolicy(modifyby, policyDateStr, 1, categoryType, 5, 1);// 更新买方交易商为
																													// 未中保
					} else {
						insurancePolicyDao.updateInsurancePolicy(modifyby, policyDateStr, 0, categoryType, 5, 1);// 更新卖方交易商为
																													// 未中保
						insurancePolicyDao.updateInsurancePolicy(modifyby, policyDateStr, 1, categoryType, 10, 1);// 更新买方交易商为
																													// 已中保
					}
				}
			} else {
				resultCode = -110004;// 保单类型表的数据条数不正确!
				this.log.debug("保单类型表的数据条数:" + iptListSize);
			}
		} else {
			resultCode = -110003;// 保单类型表的数据没有!
		}
		this.log.info(this.getClass().getName() + " updateInsurancePolicy End");
		return resultCode;
	}
	
	@Override
	public int deleteInsurancePolicyPrice(String policyDateStr) {
		this.log.info(this.getClass().getName() + " deleteInsurancePolicyPrice Start");
		int count = insurancePolicyDao.deleteInsurancePolicyPrice(policyDateStr);
		this.log.info(this.getClass().getName() + " deleteInsurancePolicyPrice End");
		return count;
	}

	@Override
	public int exePolicyBack(Integer id, String modifyBy, String reviewer) {
		this.log.info(this.getClass().getName() + " exePolicyBack Start");
		// 获取凭证的Component
		IVoucherManager voucherManager = (IVoucherManager) FinanceSysData.getBean(Constants.BEAN_VOUCHER_MGR);
//		ICouponComponnetManager couponComponnetManager = (ICouponComponnetManager) FinanceSysData
//				.getBean(Constants.BEAN_COUPON_MGR);
		this.log.debug("ID:" + id);
		int resultCode = 0;
		InsuranceBack ib = insurancePolicyDao_read.getInsuranceBackByID(id);
		if (ib != null) {
			Integer status = ib.getStatus();
			if (status == 1) {// 退保状态 1已申请 5已执行
				// 保单ID
				Integer insurancePolicyID = ib.getInsurancePolicyID();
				// 获取保单信息
				InsurancePolicy ip = insurancePolicyDao_read.getInsurancePolicyByID(insurancePolicyID);
				if (ip != null) {
					// 交易商类型 0：卖方交易商 1:买方交易商
					Integer firmType = ip.getFirmType();
					// 保单状态 1：未处理 5：未中保 10：已中保
					Integer ipStatus = ip.getStatus();
					if (ipStatus == 10) {// 已中保
						// 退保表的 应退保金额
						BigDecimal shouldBackAmount = ib.getShouldBackAmount();
						if (firmType == 0) {// 卖方交易商
							/**
							 * 1.更新退保表 为 审核通过(已执行)
							 */
							updateInsuranceBackInfo(id, modifyBy, reviewer, status, shouldBackAmount);
							//更新保单表中的支付状态支付状态							

							/**
							 * 1、通过退保表中的交收DeliveryID获取保单表中的成交单OrderId，在通过成交单OrderId获取成交表中的TotalQuantity总数量
							 * 2、通过成交单OrderId获取退保表中的保单ID，通过交收单DeliveryID获取交收表中的交收总数量
							 * 3、如果成交的总数量=等于交收总数量，就更新保单表中的支付状态PayStatus=5
							 * 4、如果成交的总数量不等于交收总数量，就查询当前的交收单中是否有的违约的，如果有违约的就查询违约数量+没有违约的交收数量
							 * 5、如果有违约的就查询违约数量+没有违约的交收数量==成交的总数量，就更新保单表中的支付状态PayStatus=5 
							 */
							Order order = orderDAO.getOrderByID(ip.getObjectID()); //通过保单表中的成交单OrderId查询成交单表中的总数量
							if(order!=null){
								BigDecimal totalQuantity = order.getTotalQuantity().abs(); //获取总数量（吨）
								BigDecimal totalDeliveryQuantity = new BigDecimal(0); //交收数量
								//查询交收数量
								List<InsuranceBack> insuranceBackList = insurancePolicyDao_read.getInsuranceBackList(Integer.valueOf(ip.getId()), 5);
								if(insuranceBackList!=null && insuranceBackList.size()>0){
									for (InsuranceBack insuranceBack : insuranceBackList) {
										Delivery delivery = deliveryDAO.getDeliveryByDeliveryID(insuranceBack.getDeliveryID());
										if(delivery!=null){
											//交收数量
											BigDecimal deliveryQuantity = order.getTradeUnitNumber().multiply(new BigDecimal(delivery.getDeliveryQuantity())); 
											totalDeliveryQuantity = totalDeliveryQuantity.add(deliveryQuantity);
										}
									}
								}
								//比较成交数量和交收数量 ，如果成交数量==交收数量
								if(totalQuantity.compareTo(totalDeliveryQuantity.abs()) == 0){
									insurancePolicyDao.updateInsurancePolicyPayStatus(Integer.valueOf(ip.getId()), 5, modifyBy);
								}else{
									List<Delivery> deliveryList = deliveryDAO.getAllDeliveryListByOrderID(ip.getObjectID());
									BigDecimal totalDeliveryQuantityWy = new BigDecimal(0); //交收数量
									if(deliveryList!=null && deliveryList.size()>0){
										for (Delivery delivery : deliveryList) {
											//买家违约、卖家违约
											if(delivery.getDeliveryStatus()==60 || delivery.getDeliveryStatus()==65){
												//交收数量
												BigDecimal deliveryQuantity = order.getTradeUnitNumber().multiply(new BigDecimal(delivery.getDeliveryQuantity())); 
												totalDeliveryQuantityWy = totalDeliveryQuantityWy.add(deliveryQuantity);
											}
										}
									}
									//退保表中已经执行的交收数量+违约的交收数量
									BigDecimal totalDelivery = totalDeliveryQuantity.add(totalDeliveryQuantityWy.abs());
									//比较成交数量和交收数量
									if(totalQuantity.compareTo(totalDelivery.abs()) == 0){
										insurancePolicyDao.updateInsurancePolicyPayStatus(Integer.valueOf(ip.getId()), 5, modifyBy);
									}
								}
							}
							
//							/**
//							 *2.【应退保金额】退到 卖方优惠券账户
//							 */
//							int code = couponComponnetManager.operationCoupon(ip.getFirmID(), shouldBackAmount, "801", ib.getDeliveryID(), 5, 0, modifyBy);						
							/**
							 * 2.【应退保金额】退到 卖方资金账户
							 */
							Integer code = voucherManager.createNewOldVoucher(Constants.VOUCHERMODE_INSURED_PAYMENT, shouldBackAmount, ib.getDeliveryID(),ip.getFirmID() , "赔付卖家中保资金", modifyBy);
							if (code < 0){
								resultCode = -110021;// 支付卖家中保资金失败！！
								this.rollback();
							}
							
							
						} else if (firmType == 1) { // 买方交易商
							/**
							 * 1.更新退保表 为 审核通过(已执行)
							 */
							updateInsuranceBackInfo(id, modifyBy, reviewer, status, shouldBackAmount);
							//更新保单表中的支付状态
							/**
							 * 1、通过退保表中的交收DeliveryID获取保单表中的成交单OrderId，在通过成交单OrderId获取成交表中的TotalQuantity总数量
							 * 2、通过成交单OrderId获取退保表中的保单ID，通过交收单DeliveryID获取交收表中的交收总数量
							 * 3、如果成交的总数量=等于交收总数量，就更新保单表中的支付状态PayStatus=5
							 * 4、如果成交的总数量不等于交收总数量，就查询当前的交收单中是否有的违约的，如果有违约的就查询违约数量+没有违约的交收数量
							 * 5、如果有违约的就查询违约数量+没有违约的交收数量==成交的总数量，就更新保单表中的支付状态PayStatus=5 
							 */
							Order order = orderDAO.getOrderByID(ip.getObjectID()); //通过保单表中的成交单OrderId查询成交单表中的总数量
							if(order!=null){
								BigDecimal totalQuantity = order.getTotalQuantity().abs(); //获取总数量（吨）
								BigDecimal totalDeliveryQuantity = new BigDecimal(0); //交收数量
								//查询交收数量
								List<InsuranceBack> insuranceBackList = insurancePolicyDao_read.getInsuranceBackList(Integer.valueOf(ip.getId()), 5);
								if(insuranceBackList!=null && insuranceBackList.size()>0){
									for (InsuranceBack insuranceBack : insuranceBackList) {
										Delivery delivery = deliveryDAO.getDeliveryByDeliveryID(insuranceBack.getDeliveryID());
										if(delivery!=null){
											//交收数量
											BigDecimal deliveryQuantity = order.getTradeUnitNumber().multiply(new BigDecimal(delivery.getDeliveryQuantity())); 
											totalDeliveryQuantity = totalDeliveryQuantity.add(deliveryQuantity);
										}
									}
								}
								//比较成交数量和交收数量 ，如果成交数量==交收数量
								if(totalQuantity.compareTo(totalDeliveryQuantity.abs()) == 0){
									insurancePolicyDao.updateInsurancePolicyPayStatus(Integer.valueOf(ip.getId()), 5, modifyBy);
								}else{
									List<Delivery> deliveryList = deliveryDAO.getAllDeliveryListByOrderID(ip.getObjectID());
									BigDecimal totalDeliveryQuantityWy = new BigDecimal(0); //交收数量
									if(deliveryList!=null && deliveryList.size()>0){
										for (Delivery delivery : deliveryList) {
											//买家违约
											if(delivery.getDeliveryStatus()==60 || delivery.getDeliveryStatus()==65){
												//交收数量
												BigDecimal deliveryQuantity = order.getTradeUnitNumber().multiply(new BigDecimal(delivery.getDeliveryQuantity())); 
												totalDeliveryQuantityWy = totalDeliveryQuantityWy.add(deliveryQuantity);
											}
										}
									}
									//退保表中已经执行的交收数量+违约的交收数量
									BigDecimal totalDelivery = totalDeliveryQuantity.add(totalDeliveryQuantityWy.abs());
									//比较成交数量和交收数量
									if(totalQuantity.compareTo(totalDelivery.abs()) == 0 ){
										insurancePolicyDao.updateInsurancePolicyPayStatus(Integer.valueOf(ip.getId()), 5, modifyBy);
									}
								}
							}
							
							/**
							 * 2.【应退保金额】退到 买方资金账户
							 */
							Integer code = voucherManager.createNewOldVoucher(Constants.VOUCHERMODE_INSURED_PAYMENT, shouldBackAmount, ib.getDeliveryID(),ip.getFirmID() , "赔付买家中保资金", modifyBy);
							if (code < 0){
								resultCode = -110022;//支付买家中保资金失败！！
								this.rollback();
							}
						} else {
							resultCode = -110009;// 交易商类型不存在，请核实保单信息！
						}
					} else {
						resultCode = -110008;// 保单状态不是【已中保】，请核实保单信息！
					}
				} else {
					resultCode = -110007;// 保单信息不存在！
				}
			} else {
				resultCode = -110006;// 当前执行的退保单状态不正确,可能已经执行，请确认！
			}
		} else {
			resultCode = -110005;// 当前执行的退保ID不存在！
		}
		this.log.info(this.getClass().getName() + " exePolicyBack End");
		return resultCode;
	}

	private void updateInsuranceBackInfo(Integer id, String modifyBy, String reviewer, Integer status,
			BigDecimal shouldBackAmount) {
		this.log.debug("updateInsuranceBackInfo Start");
		AuditInsuranceBackVo vo = new AuditInsuranceBackVo();
		vo.setId(id);
		vo.setModifyBy(modifyBy);
		vo.setReviewer(reviewer);
		vo.setOldStatus(status);
		vo.setNewStatus(5);// 5已执行
		vo.setRealBackAmount(shouldBackAmount);
		insurancePolicyDao.updateInsuranceBackByID(vo);
		this.log.debug("updateInsuranceBackInfo End");
	}

	@Override
	public void rollback() {
		insurancePolicyDao.rollBack();
	}

	@Override
	public List<ExportOrderPolicy> exportOrderPolicy(QueryConditions qc, PageInfo pageInfo) throws Exception {
		this.log.debug(className + "exportOrderPolicy Component Start");
		List<QueryOrderPolicy> list = insurancePolicyDao_read.getOrderPolicyList(qc, pageInfo);
		List<ExportOrderPolicy> retList = new ArrayList<ExportOrderPolicy>();
		if (list != null && list.size() > 0) {
			for (QueryOrderPolicy item : list) {
				ExportOrderPolicy model = new ExportOrderPolicy();
				
				CommonUtils.copyItems(item, model);
				// 未申请 计算应退金额
				if(item.getBackStatus().equals(0)){
					model.setShouldBackAmount(item.getTakenQuantity().multiply(item.getPremium()));
				}
				model.setBackStatus(formatBackStatus(item.getBackStatus()));
				retList.add(model);
			}
		}

		this.log.debug(className + "exportOrderPolicy Component Start");

		return retList;
	}

	@Override
	public List<ExportInsuranceBack> exportInsuranceBack(QueryConditions qc, PageInfo pageInfo) throws Exception {
		this.log.debug(className + "exportInsuranceBack Component Start");
		List<QueryOrderPolicy> list = insurancePolicyDao_read.getOrderPolicyList(qc, pageInfo);
		List<ExportInsuranceBack> retList = new ArrayList<ExportInsuranceBack>();
		if (list != null && list.size() > 0) {
			for (QueryOrderPolicy item : list) {
				ExportInsuranceBack model = new ExportInsuranceBack();
				CommonUtils.copyItems(item, model);
				model.setBackStatus(formatBackStatus(item.getBackStatus()));
				retList.add(model);
			}
		}
		this.log.debug(className + "exportInsuranceBack Component Start");

		return retList;
	}

	private String formatBackStatus(Integer backStatus) {
		String backStatusDesc = "待申请";
		int stauts = backStatus.intValue();
		switch (stauts) {
		case 0:
			backStatusDesc = "待申请";
			break;
		case 5:
			backStatusDesc = "已申请";
			break;
		case 10:
			backStatusDesc = "已支付";
			break;
		default:
			break;
		}
		return backStatusDesc;
	}

	@Override
	public int totalOrderPolicyList(QueryConditions qc) {
		this.log.debug(className + "totalOrderPolicyList Component Start");
		int totalCount = insurancePolicyDao_read.totalOrderPolicyList(qc);  
		this.log.debug(className + "totalOrderPolicyList Component End");
		return totalCount;
	}
	
	/**
	 * 根据成交单获取保价单记录
	 * @param orderId 成交单号
	 * @param firmType 0：卖方交易商 1:买方交易商 
	 * @param status 1：未处理 5：未中保 10：已中保
	 * @return
	 */
	@Override
	public List<InsurancePolicy> getInsurancePolicyByObjectID(String orderId, Integer firmType, Integer status) {
		this.log.info(this.getClass().getName() + " getInsurancePolicyByObjectID Start");
		List<InsurancePolicy> list = this.insurancePolicyDao_read.getInsurancePolicyByObjectID(orderId, firmType, status);
		this.log.info(this.getClass().getName() + " getInsurancePolicyByObjectID End ");
		return list;
	}
	
	/**
	 * 根据交收单获取退保表记录
	 * @param deliveryId 交收单号
	 * @param insurancePolicyId 保单ID
	 * @param firmType 0：卖方交易商 1:买方交易商 
	 * @param status 退保状态： 1已申请  5已执行
	 * @return
	 */
	@Override
	public InsuranceBack getInsuranceBackByDeliveryID(String deliveryId, Integer insurancePolicyId, Integer status){
		this.log.info(this.getClass().getName() + " getInsuranceBackByDeliveryID Start");
		InsuranceBack insuranceBack = this.insurancePolicyDao_read.getInsuranceBackByDeliveryID(deliveryId, insurancePolicyId, status);
		this.log.info(this.getClass().getName() + " getInsuranceBackByDeliveryID End ");
		return insuranceBack;
	}

	/**
	 * 根据成交单获取退保表记录
	 * @param insurancePolicyId 保单ID
	 * @param firmType 0：卖方交易商 1:买方交易商 
	 * @param status 退保状态： 1已申请  5已执行
	 * @return
	 */
	@Override
	public List<InsuranceBack> getInsuranceBackList(Integer insurancePolicyId, Integer status){
		this.log.info(this.getClass().getName() + " getInsurancePolicyList Start");
		List<InsuranceBack> list = this.insurancePolicyDao_read.getInsuranceBackList(insurancePolicyId, status);
		this.log.info(this.getClass().getName() + " getInsurancePolicyList End ");
		return list;
	}
	
	/**
	 * 更新保单中的支付状态
	 * @param InsurancePolicyId 保单ID
	 * @param payStatus 支付状态 1：未支付 5：已支付
	 * @param modifyBy 更新人
	 * @return
	 */
	@Override
	public int updateInsurancePolicyPayStatus(Integer InsurancePolicyId, Integer payStatus, String modifyBy) {
		this.log.debug(className + "updateInsurancePolicyPayStatus Component Start");
		int resultCode = this.updateInsurancePolicyPayStatus(InsurancePolicyId, payStatus, modifyBy);
		this.log.debug(className + "updateInsurancePolicyPayStatus Component End");
		return resultCode;
	}

	@Override
	public int updateInsurancePolicyStatus(String policyDate, String modifyBy) {
		this.log.debug(this.getClass().getName()+" updateInsurancePolicyStatus Component Start");
		int resultCode = 0;
		Date newPolicyDate = DateUtil.formatDate(policyDate, "yyyy-MM-dd");
		List<InsurancePolicyPrice> list = this.insurancePolicyDao_read.getInsurancePolicyPriceListByPolicyDate(newPolicyDate);
		for (InsurancePolicyPrice ipp : list){
			Integer status = ipp.getStatus();// 1:未审核 5：审核通过
			if (status == 1){
				resultCode = -110023;// 保价状态是未完善，不能执行job！
				break;
			}
			// 上一个保价日期
			Date previousInsurancePolicyPriceDate = insurancePolicyDao_read.getPreviousInsurancePolicyPriceOfPolicyDate(newPolicyDate);
			if (previousInsurancePolicyPriceDate == null){
				resultCode = -110024;// 前一天的保价数据不存在，不能执行job！
			}
			
			// 更新保单
			//resultCode = updateInsurancePolicy(ipp.getAverageDeltaPrice(), ipp.getCategoryType(), DateUtil.convert(previousInsurancePolicyPriceDate, "yyyy-MM-dd"), modifyBy);
			// 当保单类型表中是多条数据是使用下面的方法
			resultCode = updateInsurancePolicy_new(ipp.getAverageDeltaPrice(),ipp.getCategoryType(), DateUtil.convert(previousInsurancePolicyPriceDate, "yyyy-MM-dd"), modifyBy);
		}
		this.log.debug(this.getClass().getName()+" updateInsurancePolicyStatus Component End");
		return resultCode;
	}
	

	/**
	 * 更新保单 
	 * @param averageDeltaPrice 均价差
	 * @param policyDateStr 保单日期(yyyy-MM-dd)
	 * @param modifyby  修改人
	 * @return
	 */
	private int updateInsurancePolicy_new(BigDecimal averageDeltaPrice,Integer categoryType,String policyDateStr, String modifyby) {
		this.log.info(this.getClass().getName() + " updateInsurancePolicy_new Start");
		int resultCode = 0;
		List<InsurancePolicy> ipList = insurancePolicyDao_read.getInsurancePolicyListByPolicyDate(policyDateStr,categoryType);
		for (InsurancePolicy ip : ipList){
			InsurancePolicyType ipt = insurancePolicyDao_read.getInsurancePolicyTypeByID(ip.getInsurancePolicyTypeID());
			if (ipt == null){
				resultCode = -110003;// 保单类型表的数据没有!
				break;
			}
			BigDecimal deltaPrice = ipt.getDeltaPrice(); // 差价
			BigDecimal averageDeltaPriceABS = averageDeltaPrice.abs();// 均价差的绝对值
			if (averageDeltaPriceABS.compareTo(deltaPrice) <= 0) { // 均价差的绝对值 <=差价,更新保单为未中保
				insurancePolicyDao.updateInsurancePolicyByID(Integer.valueOf(ip.getId()), 5, modifyby);
			} else {
				Integer firmType = ip.getFirmType();// 0：卖方交易商 1:买方交易商 
				if (averageDeltaPrice.compareTo(new BigDecimal(0)) > 0) { // 均价差 > 0
					if (firmType == 0){// 卖方
						insurancePolicyDao.updateInsurancePolicyByID(Integer.valueOf(ip.getId()), 10, modifyby);
					}else{// 买方
						insurancePolicyDao.updateInsurancePolicyByID(Integer.valueOf(ip.getId()), 5, modifyby);
					}
				} else {
					if (firmType == 0){// 卖方
						insurancePolicyDao.updateInsurancePolicyByID(Integer.valueOf(ip.getId()), 5, modifyby);
					}else{// 买方
						insurancePolicyDao.updateInsurancePolicyByID(Integer.valueOf(ip.getId()), 10, modifyby);
					}
				}
			}
		}
		this.log.info(this.getClass().getName() + " updateInsurancePolicy_new End");
		return resultCode;
	}
	

}
