package shcem.market.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.finance.util.JSONArrayUtil;
import shcem.market.component.IQuizActivitiesComponentManager;
import shcem.market.dao.model.QueryGuizHistory;
import shcem.market.dao.model.QuizActivity;
import shcem.market.service.IQuizActivitiesService;
import shcem.market.service.model.QuizHistoryVo;
import shcem.market.util.MarketSysData;
import shcem.util.Common;
import shcem.util.DataUtil;
import shcem.util.DateUtil;
import shcem.util.JsonUtil;
import shcem.util.RemoteCallDotNetUtil;

public class QuizActivitiesServiceImpl extends BaseServiceImpl implements
		IQuizActivitiesService {
	private IQuizActivitiesComponentManager quizMgr =(IQuizActivitiesComponentManager) MarketSysData.getBean(Constants.BEAN_QUIZ_ACTIVITIES_MGR);


	@Override
	public String addQuizActivities(String params) {
		this.log.info(this.getClass().getName() + " addQuizActivities() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<QuizActivity> quizActivityList = new ArrayList<QuizActivity>();
		JSONArray quizActivityListListTemp = JOParams.getJSONArray("quizActivityList");
		if (quizActivityListListTemp != null && quizActivityListListTemp.length() > 0) {
			for (int i = 0; i < quizActivityListListTemp.length(); i++) {
				QuizActivity quizActivity = (QuizActivity) JsonUtil.jsonToBean(
						(JSONObject) quizActivityListListTemp.get(i),
						QuizActivity.class);
				quizActivityList.add(quizActivity);
			}
		}else {
			setResultData("80002", null);
			return rtnData.toString();
		}
		String mode = this.getMode();
		String userName = this.getUserId() == null ? "system" : (this.getUserId().equals("")) ? "system" : this.getUserId();
		String requestId =  this.getRequestId();
		int returnCode;
		try {
			returnCode = this.quizMgr.addQuizActivities(userName,quizActivityList,mode,requestId);
			if (returnCode >= 0) {
				setResultData("00000",null);
			}else if (returnCode == -100010) {
				setResultData("100010",null);
			}else if (returnCode == -100011) {
				setResultData("100011",null);
			}else {
				setResultData("30000",null);
			}
		} catch (Exception e) {
			this.log.info(this.getClass().getName()+" quizActivityList 新增合约失败,原因:"+e.getMessage());
			setResultData("30000",null);
		}
		this.log.info(this.getClass().getName() + " addQuizActivities() End");
		return rtnData.toString();
	}
	
	@Override
	public String getQuizActivitiesDetail(String params) {
		this.log.info(this.getClass().getName() + " getQuizActivitiesDetail() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		String quizDate = JOParams.getString("quizDate");
		List<QuizActivity> list = new ArrayList<QuizActivity>();
		boolean bolRst = false;
		try {
			list = this.quizMgr.getQuizActivitiesDetail(quizDate);
			bolRst = true;
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" getQuizActivitiesDetail 查询合约详情失败："+e.getMessage());
			setResultData("30000",null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error(this.getClass().getName()+" getQuizActivitiesList 查询合约失败："+e.getMessage());
				setResultData("30000",null);
			}

		}
		this.log.info(this.getClass().getName() + " getQuizActivitiesDetail() End");
		return rtnData.toString();
	}

	@Override
	public String updateQuizActivitiesPrice(String params) {
		this.log.info(this.getClass().getName() + " updateQuizActivitiesPrice() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<QuizActivity> quizActivityList = new ArrayList<QuizActivity>();
		JSONArray quizActivityListListTemp = JOParams.getJSONArray("quizActivityList");
		if (quizActivityListListTemp != null && quizActivityListListTemp.length() > 0) {
			for (int i = 0; i < quizActivityListListTemp.length(); i++) {
				QuizActivity quizActivity = (QuizActivity) JsonUtil.jsonToBean(
						(JSONObject) quizActivityListListTemp.get(i),
						QuizActivity.class);
				quizActivityList.add(quizActivity);
			}
		}else {
			setResultData("80002", null);
			return rtnData.toString();
		}
		
		/**
		 * 当天合约在 下午三点五十之后不能再修改
		 */
		SimpleDateFormat timeFormater = new SimpleDateFormat("yyyy-MM-dd");
		String  currentTimeString = timeFormater.format(new Date());
		String  quizDateString = timeFormater.format(quizActivityList.get(0).getQuizDate());
		int tempCount = DataUtil.StringToDate(currentTimeString, "yyyy-MM-dd").compareTo(DataUtil.StringToDate(quizDateString, "yyyy-MM-dd"));
		if(tempCount == 0 && DataUtil.StringToTime(Constants.CLOSE_TIME).compareTo(DataUtil.StringToTime(DataUtil.TimeToString(new Date())))<0){
			setResultData("10124",null);
			this.log.info(this.getClass().getName()+" updateQuizActivitiesPrice 修改合约价格已经超过时间，不能再修改，每天最晚修改时间是:"+Constants.CLOSE_TIME);
			this.log.info(this.getClass().getName() + " updateQuizActivitiesPrice() End");
			return rtnData.toString();
		}
		
		String userName = this.getUserId() == null ? "system" : (this.getUserId().equals("")) ? "system" : this.getUserId();
		int returnCode;
		try {
			returnCode = this.quizMgr.updateQuizActivitiesPrice(userName,quizActivityList);
			if(returnCode >= 0){
				setResultData("00000",null);
			}else {
				setResultData("30000",null);
			}
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" 修改合约价格失败："+e.getMessage());
			setResultData("30000",null);
		}
		this.log.info(this.getClass().getName() + " updateQuizActivitiesPrice() End");
		return rtnData.toString();
	}

	@Override
	public String getQuizActivitiesList(String params) {
		this.log.info(this.getClass().getName() + " getQuizActivitiesList() Start");
		this.log.debug("JOParams=" + params);
		boolean bolRst = false;
		List<QuizActivity> list = new ArrayList<QuizActivity>();
		//表头查询条件
		JSONObject JSONParams = new JSONObject(params);
		JSONObject queryModel =JSONParams.optJSONObject("queryModel");
		List<Condition> conditionsList = new ArrayList<Condition>();
		conditionsList.add(new Condition("temp.ContractName", "like", "", "string","contractName"));
		conditionsList.add(new Condition("temp.status", "=", "", "string","quizStatus"));
		conditionsList.add(new Condition(
				"convert(char(10),temp.QuizDate,120)", ">=", "",
				"string", "quizDateStart"));
		conditionsList.add(new Condition(
				"convert(char(10),temp.QuizDate,120)", "<=", "",
				"string", "quizDateEnd"));

		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionsList, "");
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JSONParams);
		try {
			list = this.quizMgr.getQuizActivitiesList(qc,pageInfo);
			bolRst = true;
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" getQuizActivitiesList 查询合约失败："+e.getMessage());
			setResultData("30000",null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error(this.getClass().getName()+" getQuizActivitiesList 查询合约失败："+e.getMessage());
				setResultData("30000",null);
			}

		}
		this.log.info(this.getClass().getName() + " getQuizActivitiesList() End");
		return rtnData.toString();
	}

	@Override
	public String getGuizHistoryList(String params) {
		// TODO Auto-generated method stub
		this.log.info(this.getClass().getName() + " getGuizHistoryList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		List<QueryGuizHistory> list = new ArrayList<QueryGuizHistory>();
		 
		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("temp.TraderID", "like", "", "String", "traderId"));// 交易员编码
		conditionList.add(new Condition("temp.UserName", "like", "", "String", "userName"));// 交易员姓名
		conditionList.add(new Condition("temp.FirmName", "like", "", "String", "firmName"));//	交易商名称
		conditionList.add(new Condition("temp.Status", "=", "", "Integer", "status"));// 状态
		conditionList.add(new Condition("temp.Mobile", "like", "", "String", "mobile"));// 手机号码
		conditionList.add(new Condition("temp.ContractName", "like", "", "String", "contractName"));// 品类合约名称
		conditionList.add(new Condition("temp.Status", "=", "", "Integer", "status"));// 状态
		conditionList.add(new Condition("convert(char(10),temp.REC_CREATETIME,120)", ">=", "", "String", "startDate")); // 使用开始日期
		conditionList.add(new Condition("convert(char(10),temp.REC_CREATETIME,120)", "<=", "", "String", "endDate")); // 使用结束日期 
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		Boolean bolRst=false;
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			qc.addCondition("temp.SourceFrom", "=", 1);// 来源：1前台 
			list=quizMgr.queryCouponTypeList(qc, pageInfo);
			bolRst=true;
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error("竞猜记录列表查询失败" + e.getMessage());
			setResultData("10105", null);
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		
		this.log.info(this.getClass().getName() + " getGuizHistoryList() End");
		return rtnData.toString();
	}

	@Override
	public String runLottery(String params) {
		this.log.info(this.getClass().getName() + " runLottery() Start");
		this.log.debug("JOParams=" + params);
		String exeDate = "";
		try {
			JSONObject JOParams = new JSONObject(params);
			if (JOParams.opt("exeDate") != null && !"".equals(JOParams.getString("exeDate"))){
				exeDate = JOParams.optString("exeDate");
			}else{
				exeDate =  DateUtil.convert(new Date(), "yyyy-MM-dd");
			}
		} catch (Exception e) {
			exeDate =  DateUtil.convert(new Date(), "yyyy-MM-dd");
		}
		
		String nowDate = DateUtil.convert(new Date(), "yyyy-MM-dd");
		if (nowDate.equals("2017-04-05") || exeDate.equals("2017-04-05")){
			setResultData("00000", null,"2017-04-05 不执行开奖！");
			return rtnData.toString();
		}
		
		try {
			// 查询当前执行时间在合约表中的数据
			List<QuizActivity> list = quizMgr.getQuizActivitiesDetail(exeDate);
			if (list.size() > 0){
				int resultCode = quizMgr.exeTheLottery(exeDate);
				if (resultCode < 0){
					setResultData(-resultCode+"", null);
				}else{
					setResultData("00000", null);
				}
			}else{
				setResultData("00000", null,"当前时间不在竞猜活动时间范围内，不执行开奖！");
			}
		} catch (Exception e) {
			this.log.error("异常信息：" + e.getMessage());
			setResultData("100002", null, e.getMessage());
		}
		this.log.info(this.getClass().getName() + " runLottery() End");
		return rtnData.toString();
	}
	
	@Override
	public String runSupremacy(String params) {
		this.log.info(this.getClass().getName() + " runSupremacy() Start");
		this.log.debug("JOParams=" + params);
		String exeDate = "";
		try {
			JSONObject JOParams = new JSONObject(params);
			if (!Common.isEmpty(JOParams.optString("exeDate"))) {
				exeDate = JOParams.optString("exeDate");
			} else {
				exeDate = DateUtil.convert(new Date(), "yyyy-MM-dd");
			}
		} catch (Exception e) {
			exeDate = DateUtil.convert(new Date(), "yyyy-MM-dd");
		}

		try {
			// 查询当前执行时间在合约表中的数据
			boolean QaReadyFlg = quizMgr.getValidateQuizActivitiesList(exeDate);

			if (QaReadyFlg) {
				int resultCode = quizMgr.exeSupremacy(exeDate);
				if (resultCode < 0) {
					setResultData(-resultCode + "", null);
				} else {
					setResultData("00000", null);
				}
			} else {
				setResultData("00000", null, "当前时间不在竞猜活动时间范围内，不执行开奖！(合约价格没数据或者数据重复)");
			}
		} catch (Exception e) {
			this.log.error("异常信息：" + e.toString());
			setResultData("100002", null, e.toString());
		}
		this.log.info(this.getClass().getName() + " runSupremacy() End");
		return rtnData.toString();
	}

	@Override
	public String deleteQuizActivitie(String params) {
		this.log.info(this.getClass().getName() + " deleteQuizActivitie() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		JSONArray quizDateArrayTemp = JOParams.getJSONArray("quizDateArray");
		String[] quizDateArray = JSONArrayUtil.getJsonToStringArray(quizDateArrayTemp);
		if(quizDateArray.length == 0){
			setResultData("30000",null);
			return rtnData.toString();
		}
		int returnCode = 0;
		try {
			returnCode = this.quizMgr.deleteQuizActivitie(quizDateArray);
			if(returnCode >= 0){
				setResultData("00000",null);
			}else {
				setResultData("30000",null);
			}
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" deleteQuizActivitie 删除合约失败："+e.getMessage());
			setResultData("30000", null);
		}
		this.log.info(this.getClass().getName() + " deleteQuizActivitie() End");
		return rtnData.toString();
	}
	
	@Override
	public String CheckValidationQuizDate(String params) {
		this.log.info(this.getClass().getName() + " CheckValidationQuizDate() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		boolean bolRst = false;
		JSONArray quizDateArrayTemp = JOParams.getJSONArray("quizDateArray");
		String[] quizDateArray = JSONArrayUtil.getJsonToStringArray(quizDateArrayTemp);
		if(quizDateArray.length == 0){
			setResultData("30000",null);
			return rtnData.toString();
		}
		List<QuizActivity> list = new ArrayList<QuizActivity>();
		try {
			list = this.quizMgr.getQuizActivitiesListByQuizDate(quizDateArray);
			bolRst = true;
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" CheckValidationQuizDate 重复校验失败："+e.getMessage());
			setResultData("30000", null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error(this.getClass().getName()+" getQuizActivitiesList 查询合约失败："+e.getMessage());
				setResultData("30000",null);
			}

		}
		this.log.info(this.getClass().getName() + " CheckValidationQuizDate() End");
		return rtnData.toString();
	}

	@Override
	public String updateAnswer(String params) {
		this.log.info(this.getClass().getName() + " updateAnswer() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		String userName = this.getUserId() == null ? "system" : (this.getUserId().equals("")) ? "system" : this.getUserId();
		String answer = JOParams.getString("answer");//quizDateStr: model.quizDateStr,answer: model.answer
		String quizDateStr = JOParams.getString("quizDateStr");
		//Integer category = JOParams.getInt("category");
		try {
			int returnCode = this.quizMgr.updateQuizActivityOfAnswer(answer, userName, quizDateStr);
			if (returnCode < 0) {
				setResultData(-returnCode+"",null);
			}else{
				setResultData("00000",null);
			}
		} catch (Exception e) {
			this.log.info(this.getClass().getName()+" updateAnswer 更新官方解读,原因:"+e.getMessage());
			setResultData("30000",null);
		}
		this.log.info(this.getClass().getName() + " updateAnswer() End");
		return rtnData.toString();
	}

	@Override
	public String getAnswer(String params) {
		this.log.info(this.getClass().getName() + " getAnswer() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		String quizDateStr = JOParams.getString("quizDateStr");
		//Integer category = JOParams.getInt("category");
		QuizActivity answer=new QuizActivity();;
		boolean bolRst = false;
		try {
			answer = this.quizMgr.getQuizActivityOfAnswer(quizDateStr);
			bolRst = true;
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" getAnswer 获取官方解读失败："+e.getMessage());
			setResultData("30000", null);
		}
		if (bolRst) {
			JSONObject jsonObj = new JSONObject();
			try {
				jsonObj = JsonUtil.coverModelToJSONObject(answer);
				setResultData("00000", jsonObj);
				
				//jsonObj.put("result", answer);
				//setResultData("00000", jsonObj);
			} catch (Exception e) {
				setResultData("30000",null);
			}
		}
		this.log.info(this.getClass().getName() + " getAnswer() End");
		return rtnData.toString();
	}
	
	@Override
	public String guess(String params) {
		this.log.info(this.getClass().getName() + " guess() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		String userName = this.getUserId() == null ? "system" : (this.getUserId().equals("")) ? "system" : this.getUserId();
		
		Date quizDate = null;
		List<QuizHistoryVo> qhvList = new ArrayList<QuizHistoryVo>();
		try {
			quizDate = DateUtil.formatDate(JOParams.getString("quizDateStr"), "yyyy-MM-dd");
			JSONArray qhvArray = JOParams.getJSONArray("qhvArray");
			for (int i = 0; i < qhvArray.length(); i++) {
				QuizHistoryVo qhv = (QuizHistoryVo) JsonUtil.jsonToBean((JSONObject) qhvArray.get(i),QuizHistoryVo.class);
				qhvList.add(qhv);
			}
		} catch (Exception e) {
			this.log.error("传入的参数格式不正确！"+e.getMessage());
			setResultData("10103",null);
			return rtnData.toString();
		}
		
		try {
			if (qhvList != null && qhvList.size() > 0  && quizDate != null){
				int returnCode = this.quizMgr.createQuizHistory(qhvList, quizDate, userName);
				if (returnCode < 0) {
					setResultData(-returnCode+"",null);
				}else{
					setResultData("00000",null);
				}
			}else{
				setResultData("10103",null);
			}
		} catch (Exception e) {
			this.log.info(this.getClass().getName()+" guess 猜失败,原因:"+e.getMessage());
			setResultData("30000",null);
		}
		this.log.info(this.getClass().getName() + " guess() End");
		return rtnData.toString();
	}
}
