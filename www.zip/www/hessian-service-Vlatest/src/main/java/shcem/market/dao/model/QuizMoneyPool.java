package shcem.market.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * 竞猜活动奖金池
 * @author zhangnan
 *
 */
public class QuizMoneyPool extends BaseObject implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** 主键 */
	private Integer id;			
	/**奖池金额*/
	private BigDecimal poolMoney;	
	/**奖池等级 1：一等奖 2：二等奖  3：三等奖(此字段备用)*/
	private Integer moneyTerm;
	/***/
	private String REC_CREATEBY;
	/***/
	private Date REC_CREATETIME;
	/***/
	private String REC_MODIFYBY;
	/***/
	private Date REC_MODIFYTIME;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public BigDecimal getPoolMoney() {
		return poolMoney;
	}

	public void setPoolMoney(BigDecimal poolMoney) {
		this.poolMoney = poolMoney;
	}

	public Integer getMoneyTerm() {
		return moneyTerm;
	}

	public void setMoneyTerm(Integer moneyTerm) {
		this.moneyTerm = moneyTerm;
	}

	public String getREC_CREATEBY() {
		return REC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		REC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return REC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		REC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return REC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		REC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return REC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		REC_MODIFYTIME = rEC_MODIFYTIME;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
