package shcem.market.dao.model;

import java.io.Serializable;

import shcem.base.dao.model.BaseObject;

public class NewCouponTemplateRel extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2526074666909470052L;
	// 关联优惠券类型ID
	private Integer  newCouponID;
	// 关联交易场ID
	private Integer templateID;
	
	public Integer getNewCouponID() {
		return newCouponID;
	}

	public void setNewCouponID(Integer newCouponID) {
		this.newCouponID = newCouponID;
	}

	public Integer getTemplateID() {
		return templateID;
	}

	public void setTemplateID(Integer templateID) {
		this.templateID = templateID;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
