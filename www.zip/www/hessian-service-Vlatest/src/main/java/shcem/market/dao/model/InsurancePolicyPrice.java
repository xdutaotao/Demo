package shcem.market.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * 保价
 * @author wangshuai
 *
 */
public class InsurancePolicyPrice extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6583699978769353854L;
	
	// 主键ID
	private Integer id;
	// 默认为 0：正常，1：失效
	private Integer disabled;
	// 创建人
	private String rEC_CREATEBY;
	// 创建时间
	private Date rEC_CREATETIME;
	// 最后修改人
	private String rEC_MODIFYBY;
	// 最后修改时间
	private Date rEC_MODIFYTIME;
	// 保单日期
	private Date policyDate;
	// 品类名称
	private String categoryName;
	// 品类类型
	private Integer categoryType;
	// 结算价格
	private BigDecimal settlementPrice;
	// 均价差
	private BigDecimal averageDeltaPrice;
	// 1:未审核 5：审核通过
	private Integer status;
	// 0:不存在 1存在
	private Integer policyDateStatus;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	public Date getPolicyDate() {
		return policyDate;
	}

	public void setPolicyDate(Date policyDate) {
		this.policyDate = policyDate;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public Integer getCategoryType() {
		return categoryType;
	}

	public void setCategoryType(Integer categoryType) {
		this.categoryType = categoryType;
	}

	public BigDecimal getSettlementPrice() {
		return settlementPrice;
	}

	public void setSettlementPrice(BigDecimal settlementPrice) {
		this.settlementPrice = settlementPrice;
	}

	public BigDecimal getAverageDeltaPrice() {
		return averageDeltaPrice;
	}

	public void setAverageDeltaPrice(BigDecimal averageDeltaPrice) {
		this.averageDeltaPrice = averageDeltaPrice;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}


	public Integer getPolicyDateStatus() {
		return policyDateStatus;
	}

	public void setPolicyDateStatus(Integer policyDateStatus) {
		this.policyDateStatus = policyDateStatus;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
