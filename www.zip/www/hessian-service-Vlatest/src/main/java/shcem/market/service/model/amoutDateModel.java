package shcem.market.service.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

public class amoutDateModel extends BaseObject implements Serializable {

	/**
	 * 序列id
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 活动ID
	 */
	private Integer activityID;
	/**
	 * 优惠券名字
	 */
	private String couponName;
	/**
	 * 优惠券类型
	 */
	private Integer couponType;
	/**
	 * 充值金额
	 */
	private BigDecimal rechargeAmount;
	/**
	 * 赠送金额
	 */
	private BigDecimal deductionAmount;
	/**
	 * 优惠券面额
	 */
	private BigDecimal amount;
	/**
	 * 优惠券id
	 */
	private Integer couponID;
	/**
	 * 优惠券id
	 */
	private Integer id;
	/**
	 * 优惠券发放张数
	 */
	private Integer maxQuantity;
	
	/**
	 * 优惠券起始有效时间
	 */
	private Date couponValidStartDate;
	
	/**
	 * 优惠券结束有效时间
	 */
	private Date couponValidEndDate;
	
	/**
	 * 审核状态(1:待审核 3:补发待审核 5:审核通过 10:审核拒绝 15:补发拒绝)
	 */
	private Integer auditStates;
	/**
	 * 发放记录ID
	 */
	private Integer relID;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCouponName() {
		return couponName;
	}

	public void setCouponName(String couponName) {
		this.couponName = couponName;
	}

	public Integer getCouponType() {
		return couponType;
	}

	public void setCouponType(Integer couponType) {
		this.couponType = couponType;
	}

	public BigDecimal getRechargeAmount() {
		return rechargeAmount;
	}

	public void setRechargeAmount(BigDecimal rechargeAmount) {
		this.rechargeAmount = rechargeAmount;
	}

	public BigDecimal getDeductionAmount() {
		return deductionAmount;
	}

	public void setDeductionAmount(BigDecimal deductionAmount) {
		this.deductionAmount = deductionAmount;
	}

	public Integer getCouponID() {
		return couponID;
	}

	public void setCouponID(Integer couponID) {
		this.couponID = couponID;
	}

	public Integer getMaxQuantity() {
		return maxQuantity;
	}

	public void setMaxQuantity(Integer maxQuantity) {
		this.maxQuantity = maxQuantity;
	}

	public Date getCouponValidStartDate() {
		return couponValidStartDate;
	}

	public void setCouponValidStartDate(Date couponValidStartDate) {
		this.couponValidStartDate = couponValidStartDate;
	}

	public Date getCouponValidEndDate() {
		return couponValidEndDate;
	}

	public void setCouponValidEndDate(Date couponValidEndDate) {
		this.couponValidEndDate = couponValidEndDate;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Integer getActivityID() {
		return activityID;
	}

	public void setActivityID(Integer activityID) {
		this.activityID = activityID;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public Integer getAuditStates() {
		return auditStates;
	}

	public void setAuditStates(Integer auditStates) {
		this.auditStates = auditStates;
	}

	public Integer getRelID() {
		return relID;
	}

	public void setRelID(Integer relID) {
		this.relID = relID;
	}

}
