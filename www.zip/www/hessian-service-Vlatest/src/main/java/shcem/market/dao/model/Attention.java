package shcem.market.dao.model;

import java.io.Serializable;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * Created by lihaifeng on 2017/2/24.
 */
public class Attention extends BaseObject implements Serializable {

    /**
     * 默认的序列id 
     */
    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    private Integer attentionId;

    /**
     * 交易员的ID编码
     */
    private String traderID;

    /**
     * 交易员名称
     */
    private String traderName;

    /**
     * 交易商编码
     */
    private String firmID;

    /**
     * 交易商名称
     */
    private String firmName;

    /**
     * 用户code
     */
    private String userCode;

    /**
     * 类型：1牌号 2交货方式 3交易场 4交货地
     */
    private Integer attentionType;

    /**
     * 查询关键字
     */
    private String searchKeys;
    
    /**
     * 扩展字段
     */
    private String searchKeysExtend;

    /**
     * 默认为 0：显示，1：不显示
     */
    private Integer DISABLED;

    /**
     * 创建人
     */
    private String REC_CREATEBY;

    /**
     * 创建时间
     */
    private Date REC_CREATETIME;

    /**
     * 修改人
     */
    private String REC_MODIFYBY;

    /**
     * 修改稿时间
     */
    private Date REC_MODIFYTIME;

    public Integer getAttentionId() {
        return attentionId;
    }

    public void setAttentionId(Integer attentionId) {
        this.attentionId = attentionId;
    }

    public String getTraderID() {
        return traderID;
    }

    public void setTraderID(String traderID) {
        this.traderID = traderID;
    }

    public String getTraderName() {
        return traderName;
    }

    public void setTraderName(String traderName) {
        this.traderName = traderName;
    }

    public String getFirmID() {
        return firmID;
    }

    public void setFirmID(String firmID) {
        this.firmID = firmID;
    }

    public String getFirmName() {
        return firmName;
    }

    public void setFirmName(String firmName) {
        this.firmName = firmName;
    }

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public Integer getAttentionType() {
        return attentionType;
    }

    public void setAttentionType(Integer attentionType) {
        this.attentionType = attentionType;
    }

    public String getSearchKeys() {
        return searchKeys;
    }

    public void setSearchKeys(String searchKeys) {
        this.searchKeys = searchKeys;
    }

    public String getSearchKeysExtend() {
		return searchKeysExtend;
	}

	public void setSearchKeysExtend(String searchKeysExtend) {
		this.searchKeysExtend = searchKeysExtend;
	}

	public Integer getDISABLED() {
        return DISABLED;
    }

    public void setDISABLED(Integer DISABLED) {
        this.DISABLED = DISABLED;
    }

    public String getREC_CREATEBY() {
        return REC_CREATEBY;
    }

    public void setREC_CREATEBY(String REC_CREATEBY) {
        this.REC_CREATEBY = REC_CREATEBY;
    }

    public Date getREC_CREATETIME() {
        return REC_CREATETIME;
    }

    public void setREC_CREATETIME(Date REC_CREATETIME) {
        this.REC_CREATETIME = REC_CREATETIME;
    }

    public String getREC_MODIFYBY() {
        return REC_MODIFYBY;
    }

    public void setREC_MODIFYBY(String REC_MODIFYBY) {
        this.REC_MODIFYBY = REC_MODIFYBY;
    }

    public Date getREC_MODIFYTIME() {
        return REC_MODIFYTIME;
    }

    public void setREC_MODIFYTIME(Date REC_MODIFYTIME) {
        this.REC_MODIFYTIME = REC_MODIFYTIME;
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean equals(Object paramObject) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public int hashCode() {
        // TODO Auto-generated method stub
        return 0;
    }

}
