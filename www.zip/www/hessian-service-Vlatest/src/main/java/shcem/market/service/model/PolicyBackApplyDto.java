package shcem.market.service.model;

import java.io.Serializable;
import java.math.BigDecimal;

import shcem.base.dao.model.BaseObject;

public class PolicyBackApplyDto extends BaseObject implements Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5225096741966363400L;
	
	/**
	 * 交收单号
	 */
	private String deliveryId;
	/**
	 * 保单ID
	 */
	private Integer policyId;
	/**
	 * 支付金额
	 */
	private BigDecimal price;
	
	/**
	 * 备注
	 */
	private String remarks;
	
	private String userName;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}

	public Integer getPolicyId() {
		return policyId;
	}

	public void setPolicyId(Integer policyId) {
		this.policyId = policyId;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public PolicyBackApplyDto() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
