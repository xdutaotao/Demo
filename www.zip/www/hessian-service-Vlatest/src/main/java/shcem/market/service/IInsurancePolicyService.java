package shcem.market.service;

/**
 * 保单相关api
 * @author wangshuai
 *
 */
public interface IInsurancePolicyService {

	/**
	 * 创建保价
	 * @param params
	 * @return
	 */
	public String createInsurancePolicyPrice(String params);
	
	
	/**
	 * 更新保价
	 * @param params
	 * @return
	 */
	public String updateInsurancePolicyPrice(String params);
	
	/**
	 * 获取保价列表
	 * @param params
	 * @return                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
	 */
	public String getInsurancePolicyPriceList(String params);
	
	/**
	 * 交割日期重复校验(日期为主键)
	 * @param params
	 * @return
	 */
	public String CheckValidationPolicyDate(String params);
	
	/**
	 * 根据交割日期获取保价列表
	 * @param params
	 * @return
	 */
	public String getInsurancePolicyPriceDetailByPolicyDate(String params);
	
	
	/**
	 * 根据交割日删除保价数据
	 * @return
	 */
	public String disableInsurancePolicyPrice(String params);
	
	/**
	 * 查询订单报价列表
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	String getOrderPolicyList(String params);
	
	/**
	 * 退保申请
	 * @param params
	 * @return
	 */
	String applyPolicyBack(String params);
	
	
	/**
	 * 退保执行
	 * @param params
	 * @return
	 */
	String exePolicyBack(String params);
	
	
	/**
	 * 订单保价列表导出
	 * @param params
	 * @return
	 */
	String exportOrderPolicy(String params);
	
	/**
	 * 保价付款审核列表导出
	 * @param params
	 * @return
	 */
	String exportInsuranceBack(String params);
	
	/**
	 * 更新中保名单
	 * @param params
	 * @return
	 */
	String runJobWinningPolicy(String params);
}
