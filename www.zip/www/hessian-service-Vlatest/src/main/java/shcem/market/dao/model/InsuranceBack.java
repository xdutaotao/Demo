package shcem.market.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * 退保表
 * @author wangshuai
 *
 */
public class InsuranceBack extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5161479619613282664L;

	// 主键ID
	private Integer id;
	// 默认为 0：正常，1：失效
	private Integer disabled;
	// 创建人
	private String rEC_CREATEBY;
	// 创建时间
	private Date rEC_CREATETIME;
	// 最后修改人
	private String rEC_MODIFYBY;
	// 最后修改时间
	private Date rEC_MODIFYTIME;
	// 保单类型ID
	private Integer insurancePolicyTypeID;
	// 保单ID
	private Integer insurancePolicyID;
	// 保单日期
	private Date policyDate;
	// 应退保金额
	private BigDecimal shouldBackAmount;
	// 实退保金额
	private BigDecimal realBackAmount;
	// 实际差价
	private BigDecimal realDeltaPrice;
	// 申请人
	private String applicant;
	// 申请时间
	private Date applicationTime;
	// 审核人
	private String reviewer;
	// 审核时间
	private Date auditTime;
	// 交收单号
	private String deliveryID;
	// 备注
	private String remarks;
	// 退保状态 1已申请 5已执行
	private Integer status;

	public String getDeliveryID() {
		return deliveryID;
	}

	public void setDeliveryID(String deliveryID) {
		this.deliveryID = deliveryID;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	public Integer getInsurancePolicyTypeID() {
		return insurancePolicyTypeID;
	}

	public void setInsurancePolicyTypeID(Integer insurancePolicyTypeID) {
		this.insurancePolicyTypeID = insurancePolicyTypeID;
	}

	public Integer getInsurancePolicyID() {
		return insurancePolicyID;
	}

	public void setInsurancePolicyID(Integer insurancePolicyID) {
		this.insurancePolicyID = insurancePolicyID;
	}

	public Date getPolicyDate() {
		return policyDate;
	}

	public void setPolicyDate(Date policyDate) {
		this.policyDate = policyDate;
	}

	public BigDecimal getShouldBackAmount() {
		return shouldBackAmount;
	}

	public void setShouldBackAmount(BigDecimal shouldBackAmount) {
		this.shouldBackAmount = shouldBackAmount;
	}

	public BigDecimal getRealBackAmount() {
		return realBackAmount;
	}

	public void setRealBackAmount(BigDecimal realBackAmount) {
		this.realBackAmount = realBackAmount;
	}

	public BigDecimal getRealDeltaPrice() {
		return realDeltaPrice;
	}

	public void setRealDeltaPrice(BigDecimal realDeltaPrice) {
		this.realDeltaPrice = realDeltaPrice;
	}

	public String getApplicant() {
		return applicant;
	}

	public void setApplicant(String applicant) {
		this.applicant = applicant;
	}

	public Date getApplicationTime() {
		return applicationTime;
	}

	public void setApplicationTime(Date applicationTime) {
		this.applicationTime = applicationTime;
	}

	public String getReviewer() {
		return reviewer;
	}

	public void setReviewer(String reviewer) {
		this.reviewer = reviewer;
	}

	public Date getAuditTime() {
		return auditTime;
	}

	public void setAuditTime(Date auditTime) {
		this.auditTime = auditTime;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
