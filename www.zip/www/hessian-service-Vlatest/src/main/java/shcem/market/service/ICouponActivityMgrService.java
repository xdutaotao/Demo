package shcem.market.service;

/**
 * 
 * @author wangj
 *
 */
public interface ICouponActivityMgrService {
	/**
	 * 查询新增过的优惠券列表
	 * @param params
	 * @return
	 */
	public String queryCouponTypeList(String params);
	/**
	 * 添加&编辑优惠券
	 * @param params
	 * @return
	 */
	public String addCouponType(String params);
	/**
	 * 删除优惠券
	 * @param params
	 * @return
	 */
	public String delCouponType(String params);
	/**
	 * 查询优惠券使用记录
	 * @param params 查询参数实体
	 * @return
	 */
	public String getCouponFlowingWaterList(String params);

	/**
	 * 查询过滤未发送的优惠券[去掉已经过期的优惠券]
	 * @param params
	 * @return
	 */
	public String getCouponNoUsedList(String params);
	
	/**
	 * 导出优惠券使用记录流水
	 * @param params
	 * @return
	 */
	public String exportCouponFlowingWaterList(String params);
	
	/**
	 * 导出未领取优惠券使用记录流水
	 * @param params
	 * @return
	 */
	public String exportUnCouponFlowingWaterList(String params);
	
	/**
	 * 查询活动列表
	 * @param params
	 * @return
	 */
	public String queryCouponActivityList(String params);
	
	/**
	 * 发送优惠券
	 * @param params 查询参数实体
	 * @return
	 */
	public String sendCouponForUserCode(String params);
	
	/**
	 * 发送优惠券兑换码
	 * @param params 参数实体
	 * @return
	 */
	public String sendCouponForUserCodeExchangeCode(String params);
	
	/**
	 * 置标 优惠券的使用状态为【已发放】
	 */
	public String  markupNewCouponTransOfStatus(String params);
	
	/**
	 * 添加&编辑活动
	 * @param params
	 * @return
	 */
	public String addOrEditActivity(String params);
	
	/**
	 * 审核活动
	 * @param params
	 * @return
	 */
	public String auditActivity(String params);
	
	/**
	 * 审核活动（补发审核用）
	 * @param params
	 * @return
	 */
	public String reissueAuditActivity(String params);
	
	/**
	 * 获取优惠券列表
	 * @return
	 */
	public String getCouponList(String params);
	
	/**
	 * 活动详情
	 * @param params
	 */
	public String getActivityByID(String params);
	
	/**
	 * 活动详情(补发用)
	 * @param params
	 */
	public String getReissueActivityByID(String params);
	
//	/**
//	 * 在审核通过活动的基础上增发优惠券！
//	 * @param params
//	 * @return
//	 */
//	public String addMoreActivity(String params);
	
	/**
	 * 新增补发或编辑补发 优惠券
	 * @param params
	 * @return
	 */
	public String addOrEditReissueActivity(String params);
	
	
	/**
	 * 启用或禁用活动
	 * @param params
	 * @return
	 */
	public String resetActivityStatus(String params);
	
	/**
	 * 通过ID获取优惠券信息
	 * @param params
	 * @return
	 */
	public String getNewCouponInfoByID(String params);
	
	/**
	 * 修改审核通过的活动时间
	 * @param params
	 * @return
	 */
	public String modifyAuditActivityDate(String params);
	
	
}
