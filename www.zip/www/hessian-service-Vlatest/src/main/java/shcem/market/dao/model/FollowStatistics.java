package shcem.market.dao.model;

import shcem.base.dao.model.BaseObject;

/**
 * 我的关注统计
 * @author sunf
 *
 */
public class FollowStatistics extends BaseObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1634556518584569449L;
	
	/**
	 * 关注类型
	 * 1：牌号
	 * 2：交货方式
	 * 3：交易场
	 * 4：交货地
	 */
	private int attentionType;
	/**
	 * 分类
	 */
	private String searchKeys;
	/**
	 * 关注数
	 */
	private int followCount;
	/**
	 * 排名
	 */
	private int ranking;
	
	

	public int getAttentionType() {
		return attentionType;
	}

	public void setAttentionType(int attentionType) {
		this.attentionType = attentionType;
	}

	public String getSearchKeys() {
		return searchKeys;
	}

	public void setSearchKeys(String searchKeys) {
		this.searchKeys = searchKeys;
	}

	public int getFollowCount() {
		return followCount;
	}

	public void setFollowCount(int followCount) {
		this.followCount = followCount;
	}

	public int getRanking() {
		return ranking;
	}

	public void setRanking(int ranking) {
		this.ranking = ranking;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
