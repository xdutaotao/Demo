package shcem.market.dao.impl;

import java.util.List;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.constant.Constants;
import shcem.market.dao.IAttentionDao;
import shcem.market.dao.model.Attention;
import shcem.market.dao.model.FollowStatistics;
import shcem.util.CommonRowMapper;

/**
 * Created by lihaifeng on 2017/2/24.
 */
public class AttentionDaoImpl extends BaseDAOImpl implements IAttentionDao {

    @Override
    public List<Attention> getAttentionDetailedList(QueryConditions queryConditions, PageInfo pageInfo,boolean replace){
        this.log.debug(AttentionDaoImpl.class.getName()+"getAttentionDetailedList DAO Start");
        String sql = this.sqlProperty.getProperty("Attention_001");
        if(replace)sql = sql.replaceFirst("SELECT", "SELECT top "+Constants.EXPORT_MAX_COUNT+" ");
		List<Attention> list= this.queryBySQL(sql, queryConditions, pageInfo, new CommonRowMapper(new Attention()));
        this.log.debug(AttentionDaoImpl.class.getName() + "getAttentionDetailedList DAO End");
        return list;
    }
    
    @Override
	public List<Attention> getAttentionTypeList() {
		this.log.debug(AttentionDaoImpl.class.getName()+"getAttentionTypeList DAO Start");
		String sql = sqlProperty.getProperty("Attention_002");
		Object[] params = { };
		List<Attention> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new Attention()));
		this.log.debug(AttentionDaoImpl.class.getName()+"getAttentionTypeList DAO End");
		return list;
	}
    
	@Override
	public int getExportAttentionDetailedCount(QueryConditions qc, PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+" getExportAttentionDetailedCount Start");
		String sql=sqlProperty.getProperty("Attention_001");
		int totalRecords = 0;
		totalRecords = getTotalCount(sql,qc);
		this.log.info(this.getClass().getName()+" getExportAttentionDetailedCount End");
		return totalRecords;
	}
    
    @Override
    public List<FollowStatistics> getAttentionStatistics(int size){
        this.log.debug(AttentionDaoImpl.class.getName()+"getAttentionStatistics DAO Start");
        String sql = this.sqlProperty.getProperty("Attention_003");//
        Object[] params = { size};
        List<FollowStatistics> list= this.queryBySQL(sql, params, null, new CommonRowMapper(new FollowStatistics()));

        this.log.debug(AttentionDaoImpl.class.getName() + "getAttentionStatistics DAO End");
        return list;
    }

}
