package shcem.market.service.model;

import java.io.Serializable;
import java.util.Date;
import shcem.base.dao.model.BaseObject;

public class InsurancePolicyPriceVo extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3124877419654793579L;
	// 保单日期
	private Date policyDate;
	// 品类名称
	private String categoryNameStr;
	// 品类类型
	private String categoryTypeStr;
	// 结算价格
	private String settlementPriceStr;
	// 更新时间
	private Date rec_modifytime;
	// 操作人
	private String rec_modifyby;
	// 状态 1:未审核 5：审核通过
	private Integer status;
	// 当前日期：0 非当日 1当日
	private Integer currentDateStatus;

	public Date getPolicyDate() {
		return policyDate;
	}

	public void setPolicyDate(Date policyDate) {
		this.policyDate = policyDate;
	}

	public String getCategoryNameStr() {
		return categoryNameStr;
	}

	public void setCategoryNameStr(String categoryNameStr) {
		this.categoryNameStr = categoryNameStr;
	}

	public String getCategoryTypeStr() {
		return categoryTypeStr;
	}

	public void setCategoryTypeStr(String categoryTypeStr) {
		this.categoryTypeStr = categoryTypeStr;
	}

	public String getSettlementPriceStr() {
		return settlementPriceStr;
	}

	public void setSettlementPriceStr(String settlementPriceStr) {
		this.settlementPriceStr = settlementPriceStr;
	}

	public Date getRec_modifytime() {
		return rec_modifytime;
	}

	public void setRec_modifytime(Date rec_modifytime) {
		this.rec_modifytime = rec_modifytime;
	}

	public String getRec_modifyby() {
		return rec_modifyby;
	}

	public void setRec_modifyby(String rec_modifyby) {
		this.rec_modifyby = rec_modifyby;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getCurrentDateStatus() {
		return currentDateStatus;
	}

	public void setCurrentDateStatus(Integer currentDateStatus) {
		this.currentDateStatus = currentDateStatus;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
