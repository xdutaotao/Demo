package shcem.market.component;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.market.dao.model.ExportInsuranceBack;
import shcem.market.dao.model.ExportOrderPolicy;
import shcem.market.dao.model.InsuranceBack;
import shcem.market.dao.model.InsurancePolicy;
import shcem.market.dao.model.InsurancePolicyPrice;
import shcem.market.dao.model.QueryOrderPolicy;
import shcem.market.service.model.InsurancePolicyPriceDto;
import shcem.market.service.model.InsurancePolicyPriceVo;
import shcem.market.service.model.PolicyBackApplyDto;
/**
 * 保单相关Component
 * @author wangshuai
 *
 */
public interface IInsurancePolicyComponent extends Manager{
	
	/**
	 * 创建保价
	 * @param params
	 * @return
	 */
	public int addInsurancePolicyPrice(InsurancePolicyPriceDto insurancePolicyPriceDto);
	
	
	/**
	 * 查询保价列表
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	List<InsurancePolicyPriceVo> getInsurancePolicyPriceList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 获取保价详情
	 * @param params
	 * @return
	 */
	public InsurancePolicyPriceVo getInsurancePolicyPrice(String policyDateStr);
	
	
	/**
	 * 更新保价
	 * @param params
	 * @return
	 */
	public int updateInsurancePolicyPrice(InsurancePolicyPriceDto insurancePolicyPriceDto);
	
	/**
	 * 获取保价列表
	 * @param params
	 * @return
	 */
	public List<InsurancePolicyPrice> getInsurancePolicyPriceByPolicyDate(String[] policyDateArray);
	
	/**
	 * 获取保价列表
	 * @param params
	 * @return
	 */
	public List<InsurancePolicyPrice> getInsurancePolicyPriceByPolicyDate(Date policyDate);
	
 
	/**
	 * 查询订单报价列表
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	List<QueryOrderPolicy> getOrderPolicyList(QueryConditions qc, PageInfo pageInfo); 
	
	/**
	 *  更新保单
	 * @param averageDeltaPrice 均价差
	 * @param categoryType 保单品类:1:PE 2:PP
	 * @param policyDateStr 保单日期(yyyy-MM-dd) 
	 * @param modifyby 修改人
	 * @return
	 */
	int updateInsurancePolicy(BigDecimal averageDeltaPrice,Integer categoryType,String policyDateStr,String modifyby);
	
	
	/**
	 * 删除保价数据
	 * @return
	 */
	int deleteInsurancePolicyPrice(String policyDateStr);
	
	/**
	 * 申请保价退保
	 * @return
	 */
	int applyPolicyBack(List<PolicyBackApplyDto> applyList);
	
	/**
	 * 执行保价退保
	 * @param id
	 * @param modifyBy
	 * @param reviewer
	 * @return
	 */
	int exePolicyBack(Integer id,String modifyBy,String reviewer);
	
	
	public abstract void rollback();
	
	/**
	 * 订单保价列表导出
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	List<ExportOrderPolicy> exportOrderPolicy(QueryConditions qc, PageInfo pageInfo)  throws Exception;
	
	/**
	 * 保价付款审核列表导出
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	List<ExportInsuranceBack> exportInsuranceBack(QueryConditions qc, PageInfo pageInfo)  throws Exception;
	
	/**
	 * 统计表单列表个数
	 * @return
	 */
	int totalOrderPolicyList(QueryConditions qc);
	
	/**
	 * 根据成交单获取保价单记录
	 * @param orderId 成交单号
	 * @param firmType 0：卖方交易商 1:买方交易商 
	 * @param status 1：未处理 5：未中保 10：已中保
	 * @return
	 */
	List<InsurancePolicy> getInsurancePolicyByObjectID(String orderId, Integer firmType, Integer status);
	
	/**
	 * 根据交收单获取退保表记录
	 * @param deliveryId 交收单号
	 * @param insurancePolicyId 保单ID
	 * @param firmType 0：卖方交易商 1:买方交易商 
	 * @param status 退保状态： 1已申请  5已执行
	 * @return
	 */
	InsuranceBack getInsuranceBackByDeliveryID(String deliveryId, Integer insurancePolicyId, Integer status);
	
	/**
	 * 根据成交单获取退保表记录
	 * @param insurancePolicyId 保单ID
	 * @param firmType 0：卖方交易商 1:买方交易商 
	 * @param status 退保状态： 1已申请  5已执行
	 * @return
	 */
	List<InsuranceBack> getInsuranceBackList(Integer insurancePolicyId, Integer status);
	
	/**
	 * 更新保单中的支付状态
	 * @param InsurancePolicyId 保单ID
	 * @param payStatus 支付状态 1：未支付 5：已支付
	 * @param modifyBy 更新人
	 * @return
	 */
	public int updateInsurancePolicyPayStatus(Integer InsurancePolicyId, Integer payStatus, String modifyBy);
	
	/**
	 * 更新保单的保单状态
	 * @param policyDate 保单时间
	 * @param modifyBy 修改人
	 * @return
	 */
	public int updateInsurancePolicyStatus(String policyDate,String modifyBy);
	
}
