package shcem.market.dao.impl;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.SqlProvider;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.service.model.ValueTxtView;
import shcem.constant.Constants;
import shcem.market.dao.ICouponActivityDao;
import shcem.market.dao.model.CouponTrans;
import shcem.market.dao.model.NewCoupon;
import shcem.market.dao.model.NewCouponTemplateRel;
import shcem.market.dao.model.NewCouponTrans;
import shcem.market.dao.model.NewCouponActivity;
import shcem.market.service.model.ActivityTempCoupon;
import shcem.market.service.model.amoutDateModel;
import shcem.trade.dao.model.Delivery;
import shcem.util.CommonRowMapper;
import shcem.util.DataUtil;

/**
 * 
 * @author wangj
 *
 */
public class CouponActivityDaoImpl  extends BaseDAOImpl implements ICouponActivityDao{

	@Override
	public List<NewCoupon> queryCouponTypeList(QueryConditions qc,
			PageInfo pageInfo) {
		// TODO Auto-generated method stub
		this.log.debug("queryCouponTypeList DAO Start");
		String sql = sqlProperty.getProperty("CouponActivityDao_001");
		return this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new NewCoupon()));
	}

	@Override
	public int insertCouponType(NewCoupon newCoupon) {
		this.log.debug("insertCouponApply DAO Start");
		String sql = sqlProperty.getProperty("CouponActivityDao_002");
		Object[] params = {
			newCoupon.getCouponName(),newCoupon.getCouponType(),
			newCoupon.getRechargeAmount(),newCoupon.getDeductionAmount(),
			newCoupon.getAmount(),newCoupon.getStatus(),
			newCoupon.getRemark(),0,
			newCoupon.getREC_CREATEBY(),newCoupon.getREC_MODIFYBY(),
			newCoupon.getMinAmount() == null ? 0 : newCoupon.getMinAmount(),
			newCoupon.getMinWeight() == null ? 0 : newCoupon.getMinWeight()
		};
		return this.queryForIntID(sql, params);
	}

	@Override
	public int updateCouponType(NewCoupon newCoupon) {
		// TODO Auto-generated method stub
		this.log.debug("updateCouponType DAO Start");
		String sql = sqlProperty.getProperty("CouponActivityDao_003");
		Object[] params = {
				newCoupon.getCouponType(),newCoupon.getRechargeAmount(),
				newCoupon.getDeductionAmount(),newCoupon.getAmount(),
				newCoupon.getStatus(),newCoupon.getRemark(),
				newCoupon.getREC_MODIFYBY(),
				newCoupon.getMinAmount(),newCoupon.getMinWeight(),
				newCoupon.getId()
			};
		return this.updateBySQL(sql, params);
	}

	@Override
	public int delCouponType(int id, int dISABLED) {
		// TODO Auto-generated method stub
		this.log.debug("delCouponType DAO Start");
		String sql = sqlProperty.getProperty("CouponActivityDao_004");
		Object[] params = {dISABLED,id};
		return this.updateBySQL(sql, params);
	}
	
	/**
	 * 查询优惠券使用记录
	 */
	@Override
	public List<NewCouponTrans> getCouponFlowingWaterList(QueryConditions qc, PageInfo pageInfo,boolean replace) {
		// TODO Auto-generated method stub
		this.log.debug("getCouponFlowingWaterList DAO Start");
		String sql=sqlProperty.getProperty("CouponActivityDao_005");
		if(replace)sql = sql.replaceFirst("SELECT", "SELECT top "+Constants.EXPORT_MAX_COUNT+" ");
		return this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new NewCouponTrans()));
	}
	
	/**
	 * 查询过滤未发送的优惠券[去掉已经过期的优惠券]
	 */
	@Override
	public List<NewCouponTrans> getCouponNoUsedList(QueryConditions qc, PageInfo pageInfo,boolean replace) {
		// TODO Auto-generated method stub
		this.log.debug("getCouponNoUsedList DAO Start");
		String sql=sqlProperty.getProperty("CouponActivityDao_026");
		if(replace)sql = sql.replaceFirst("SELECT", "SELECT top "+Constants.EXPORT_MAX_COUNT+" ");
		return this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new NewCouponTrans()));
	}

	@Override
	public List<NewCouponActivity> queryCouponActivityList(QueryConditions qc,
			PageInfo pageInfo) {
		// TODO Auto-generated method stub
		this.log.debug("queryCouponActivityList DAO Start");
		String sql = sqlProperty.getProperty("CouponActivityDao_007");
		return this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new NewCouponActivity()));
	}

	@Override
	public int sendCouponForUserCode(Integer Id,String userCode, Integer status,String userID, String traderID, String firmID) {
		this.log.debug(this.getClass().getName()+".updateNewCouponTransOfStatusByID DAO Start");
		String sql = sqlProperty.getProperty("CouponActivityDao_019");
		Object[] params = {userCode,status,userID,traderID,firmID,Id};
		int  count = this.updateBySQL(sql, params);
		this.log.debug(this.getClass().getName()+".updateNewCouponTransOfStatusByID DAO End");
		return count;
	}
	
	@Override
	public int sendCouponForUserCodeExchangeCode(Integer Id, Integer status,String userID) {
		this.log.debug(this.getClass().getName()+".updateNewCouponTransOfStatusByID DAO Start");
		String sql = sqlProperty.getProperty("CouponActivityDao_025");
		Object[] params = {status,userID,Id};
		int  count = this.updateBySQL(sql, params);
		this.log.debug(this.getClass().getName()+".updateNewCouponTransOfStatusByID DAO End");
		return count;
	}

	@Override
	public NewCouponTrans getNewCouponTransByID(Integer id) {
		this.log.debug(this.getClass().getName()+".getNewCouponTransByID DAO Start");
		String sql = sqlProperty.getProperty("CouponActivityDao_020");
		Object[] params = {id};
		NewCouponTrans  newCouponTrans = (NewCouponTrans) this.queryForObject(sql, params,new CommonRowMapper(new NewCouponTrans()));
		this.log.debug(this.getClass().getName()+".getNewCouponTransByID DAO End");
		return newCouponTrans;
	}

	@Override
	public int updateNewCouponTransOfStatusByID(Integer Id, Integer status,String userID) {
		this.log.debug(this.getClass().getName()+".updateNewCouponTransOfStatusByID DAO Start");
		String sql = sqlProperty.getProperty("CouponActivityDao_021");
		Object[] params = {status,userID,Id};
		int  count = this.updateBySQL(sql, params);
		this.log.debug(this.getClass().getName()+".updateNewCouponTransOfStatusByID DAO End");
		return count;
	}

	@Override
	public void rollBack() {
		try {
			getConnection().setAutoCommit(false);//事务设置为手动
			getConnection().rollback();
		} catch (CannotGetJdbcConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public int insertActivity(ActivityTempCoupon activityTempCoupon) {
		this.log.info(this.getClass().getName()+" insertActivity Start");
		String sql = this.sqlProperty.getProperty("CouponActivityDao_008");
		Object [] params={
				activityTempCoupon.getActivityName(),activityTempCoupon.getRemark(),1,
				activityTempCoupon.getActivityStartDate(),activityTempCoupon.getActivityEndDate(),
				activityTempCoupon.getStates()==null?1:activityTempCoupon.getStates(),0,activityTempCoupon.getREC_CREATEBY(),activityTempCoupon.getREC_MODIFYBY()
		};
		int returnCode;
		try {
			returnCode = this.queryForIntID(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" insertActivity"+e.getMessage());
			returnCode = -1;
		}
		this.log.info(this.getClass().getName()+" insertActivity Start");
		return returnCode;
	}

	@Override
	public int insertActivityTempRel(int tempID, Integer activityID) {
		this.log.info(this.getClass().getName()+" insertActivityTempRel Start");
		String sql = this.sqlProperty.getProperty("CouponActivityDao_009");
		Object [] params={
				activityID,tempID
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" insertActivityTempRel"+e.getMessage());
			returnCode = -1;
		}
		return returnCode;
	}

	@Override
	public int insertActivityCouponRel(amoutDateModel amoutDateModel,
			int activityID, String userName,int auditStates) {
		this.log.info(this.getClass().getName()+" insertActivityCouponRel Start");
		String sql = this.sqlProperty.getProperty("CouponActivityDao_010");
		Object [] params={
				amoutDateModel.getCouponID(),activityID,amoutDateModel.getMaxQuantity(),
				amoutDateModel.getCouponValidStartDate(),amoutDateModel.getCouponValidEndDate(),0,
				userName,userName,auditStates
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" insertActivityCouponRel"+e.getMessage());
			returnCode = -1;
		}
		return returnCode;
	}

	@Override
	public int delActivityTemp(Integer id) {
		this.log.info(this.getClass().getName()+" delActivityTemp Start");
		String sql = this.sqlProperty.getProperty("CouponActivityDao_011");
		Object[] params={
				id
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" delActivityTemp"+e.getMessage());
			returnCode = -1;
		}
		return returnCode;
	}

	@Override
	public int updateActivity(ActivityTempCoupon activityTempCoupon) {
		this.log.info(this.getClass().getName()+" updateActivity Start");
		String sql = this.sqlProperty.getProperty("CouponActivityDao_012");
		Object [] params={
				activityTempCoupon.getRemark(),activityTempCoupon.getActivityStartDate(),
				activityTempCoupon.getActivityEndDate(),activityTempCoupon.getStates()==null?1:activityTempCoupon.getStates(),
				activityTempCoupon.getREC_MODIFYBY(),1,activityTempCoupon.getId()
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" updateActivity"+e.getMessage());
			returnCode = -1;
		}
		return returnCode;
	}

	@Override
	public int insertCouponTrans(amoutDateModel amoutDateModel, int activityID,
			String userName, String couponNumber, String exchangeCode) {
		this.log.info(this.getClass().getName()+" insertCouponTrans Start");
		String sql = this.sqlProperty.getProperty("CouponActivityDao_013");
		Object [] params={
				activityID,amoutDateModel.getCouponID(),couponNumber,
				amoutDateModel.getCouponValidStartDate(),amoutDateModel.getCouponValidEndDate(),
				exchangeCode,0,0,0,userName,userName
		};
		this.log.info(this.getClass().getName()+" insertCouponTrans 新增活动参数："+Arrays.asList(params));
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" insertCouponTrans"+e.getMessage());
			returnCode = -1;
		}
		return returnCode;
	}

	@Override
	public int updateAuditStatus(NewCouponActivity newCouponActivity,
			String userName,boolean auditFlag) {
		this.log.info(this.getClass().getName()+" updateAuditStatus Start");
		String sql = this.sqlProperty.getProperty("CouponActivityDao_014");
		//审核状态
		int auditStatus = auditFlag == true?5:10;
		Object [] params={
				auditStatus,userName,newCouponActivity.getId()
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" insertCouponTrans"+e.getMessage());
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public List<amoutDateModel> getAmoutDateList(Integer activityID) {
		this.log.info(this.getClass().getName()+" getAmoutDateList Start");
		String sql = this.sqlProperty.getProperty("CouponActivityDao_022");
		Object [] params = {
					activityID
				};
		List<amoutDateModel> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new amoutDateModel()));
		this.log.info(this.getClass().getName()+" getAmoutDateList End");
		return list;
	}

	@Override
	public List<NewCoupon> getCouponList(Integer[] templateIDArray) {
		this.log.debug(this.getClass().getName()+" getCouponList DAO Start");
		String sql = sqlProperty.getProperty("CouponActivityDao_006");
		if (templateIDArray !=null && templateIDArray.length > 0) {
			StringBuilder sqlSB = new StringBuilder();
			sqlSB.append(" and ( rel.TemplateID in (");
			boolean bool = false;
			for (Integer ID : templateIDArray){
				if(bool){
					sqlSB.append(",");
				}else{
					bool = true;
				}
				sqlSB.append(ID);
			}
			sqlSB.append(")");
			sqlSB.append(" or coupon.CouponType = 2 )");// 充值型的全部查询出来
			sql+=sqlSB.toString();
		}else{// 如果数组为空时，只查询出充值型的优惠券
			sql+= " and coupon.CouponType = 2";
		}
		Object[] params = new Object[] {};
		List<NewCoupon> list  = queryBySQL(sql, params, null, new CommonRowMapper(new NewCoupon()));
		this.log.debug(this.getClass().getName()+" getCouponList DAO Start");
		return list;
	}
	
	@Override
	public ActivityTempCoupon getActivityByID(int activityID) {
		this.log.info(this.getClass().getName()+ " getActivityByID Start");
		String sql = sqlProperty.getProperty("CouponActivityDao_018");
		ActivityTempCoupon activityTempCoupon = null;
		Object [] params = {activityID};
		try {
			activityTempCoupon = (ActivityTempCoupon)this.queryForObject(sql, params, new CommonRowMapper(new ActivityTempCoupon()));
		} catch (Exception e) {
			this.log.debug(this.getClass().getName()+"getActivityByID.. 失败"+e.getMessage());
			activityTempCoupon = null;
		}
		this.log.info(this.getClass().getName()+ " getActivityByID End");
		return activityTempCoupon;
	}
	
	@Override
	public List<ValueTxtView> getTempList(int activityID) {
		this.log.info(this.getClass().getName()+ " getTempList Start");
		String sql = "select TemplateID as tagID from F_NewCouponActTemplateRel act inner join F_NewCouponActivity nat on act.ActivityID = nat.ID where nat.ID ="+activityID;
		Object [] params ={};
		List<ValueTxtView> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView()));
		this.log.info(this.getClass().getName()+ " getTempList Start");
		return list;
	}

	@Override
	public List<amoutDateModel> getcouponActivityRelList(int activityID) {
		this.log.info(this.getClass().getName()+ " getcouponActivityRelList Start");
		String sql = sqlProperty.getProperty("CouponActivityDao_024");
		Object [] params = {activityID,0};
		List<amoutDateModel> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new amoutDateModel()));
		this.log.info(this.getClass().getName()+ " getcouponActivityRelList End");
		return list;
	}
	
	@Override
	public List<amoutDateModel> getgetcouponActivityRelEditList(int activityID) {
		this.log.info(this.getClass().getName()+ " getgetcouponActivityRelEditList Start");
		String sql = sqlProperty.getProperty("CouponActivityDao_017");
		Object [] params = {activityID,0};
		List<amoutDateModel> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new amoutDateModel()));
		this.log.info(this.getClass().getName()+ " getgetcouponActivityRelEditList End");
		return list;
	}
	
	@Override
	public int delNewCouponActivityRel(Integer activityID) {
		this.log.info(this.getClass().getName()+" delNewCouponActivityRel Start");
		String sql = this.sqlProperty.getProperty("CouponActivityDao_030");
		Object [] params = {
				activityID
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			// TODO: handle exception
			this.log.error(this.getClass().getName()+" delNewCouponActivityRel 出错："+e.getMessage());
			returnCode = -1;
		}
		this.log.info(this.getClass().getName()+" delNewCouponActivityRel End");
		return returnCode;
	}
	
	@Override
	public boolean getNewCouponList(String couponName) {
		this.log.info(this.getClass().getName()+" getNewCouponList Start");
		String sql = "select * from F_NewCoupon where CouponName ='"+couponName+"' AND DISABLED=0";
		Object [] params = {};
		List<NewCoupon> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new NewCoupon()));
		if(list != null && list.size() > 0){
			return true;
		}else {
			return false;
		}
	}
	
	@Override
	public boolean getNewCouponActivity(String activityName) {
		this.log.info(this.getClass().getName()+" getNewCouponList Start");
		String sql = "select * from F_NewCouponActivity where ActivityName ='"+activityName+"'";
		Object [] params = {};
		List<NewCouponActivity> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new NewCouponActivity()));
		if(list != null && list.size() > 0){
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * 校验优惠券类型关联的活动是否通过审核
	 */
	@Override
	public Boolean checkCouponTypeAuditFlag(Integer couponID) {
		this.log.info(this.getClass().getName()+" getNewCouponList Start");
		String sql = "select distinct CouponID from F_NewCouponActivityRel where AuditStates = 5 and CouponID ="+couponID+"";
		Object [] params = {};
		List<amoutDateModel> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new amoutDateModel()));
		if(list != null && list.size() > 0){
			return true;
		}
		return false;
	}
	
	/**
	 * 删除优惠券活动关联表(待审核、审核拒绝)
	 */
	@Override
	public int delNewCouponActivityRelByCouponID(int couponID) {
		this.log.info(this.getClass().getName()+" delNewCouponActivityRelByCouponID Start");
		String sql = "delete from F_NewCouponActivityRel where CouponID = "+couponID+" and AuditStates in(1,10)";
		int returnCode;
		Object [] params = {};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.info(this.getClass().getName()+" delNewCouponActivityRelByCouponID :"+e.getMessage());
			returnCode =  -1;
		}
		this.log.info(this.getClass().getName()+" delNewCouponActivityRelByCouponID End");
		return returnCode;
	}
	
	@Override
	public int updateNewCouponActivityRelAuditStatus(Integer activityID,
			int auditStatus) {
		this.log.info(this.getClass().getName()+" updateNewCouponActivityRelAuditStatus Start");
		String sql = "update F_NewCouponActivityRel set AuditStates = "+auditStatus+" where ActivityID="+activityID;
		int returnCode;
		Object [] params = {};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.info(this.getClass().getName()+" updateNewCouponActivityRelAuditStatus :"+e.getMessage());
			returnCode =  -1;
		}
		this.log.info(this.getClass().getName()+" updateNewCouponActivityRelAuditStatus End");
		return returnCode;
	}
	
	@Override
	public boolean checkCouponNumber(String couponNumber) {
		this.log.info(this.getClass().getName()+" checkCouponNumber Start");
		String sql = " select * from F_NewCouponTrans where CouponNumber ='"+couponNumber+"'";
		Object [] params ={};
		List<NewCouponTrans> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new NewCouponTrans()));
		if(list != null && list.size() > 0){
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * 优惠券类型
	 */
	@Override
	public Integer getCouponType(Integer couponID) {
		this.log.info(this.getClass().getName()+" getCouponType Start");
		String sql = "select CouponType from F_NewCoupon where ID="+couponID;
		int couponType = this.queryForInt(sql);
		this.log.info(this.getClass().getName()+" getCouponType End");
		return couponType;
	}

	@Override
	public int resetActivityStatus(Integer id, Integer flag) {
		this.log.info(this.getClass().getName()+" resetActivityStatus Start");
		String sql = sqlProperty.getProperty("CouponActivityDao_023");
		Object[] params = {flag,id};
		return this.updateBySQL(sql, params);
	}
	
	@Override
	public int getExportCouponFlowingWaterCount(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+" getExportCouponFlowingWaterCount Start");
		String sql=sqlProperty.getProperty("CouponActivityDao_005");
		int totalRecords = 0;
		totalRecords = getTotalCount(sql,qc);
		this.log.info(this.getClass().getName()+" getExportCouponFlowingWaterCount End");
		return totalRecords;
	}
	
	@Override
	public int getExportCouponUnissuedCount(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+" getExportCouponUnissuedCount Start");
		String sql=sqlProperty.getProperty("CouponActivityDao_026");
		int totalRecords = 0;
		totalRecords = getTotalCount(sql,qc);
		this.log.info(this.getClass().getName()+" getExportCouponUnissuedCount End");
		return totalRecords;
	}
	
	@Override
	public int addBatchCouponTrans(amoutDateModel amoutDateModel, Integer id,
			String userName, List<CouponTrans> couponNumberList) {
		this.log.info(this.getClass().getName()+" addBatchCouponTrans Start");
		long start = System.currentTimeMillis();
		int returnCode = 0;
		String sql = "insert into F_NewCouponTrans(ActivityID,CouponID,CouponNumber,CouponValidStartDate,CouponValidEndDate,ExchangeCode,Status,DISABLED,DeductibleAmount,REC_CREATETIME,REC_CREATEBY,REC_MODIFYTIME,REC_MODIFYBY) "
				+ "values ";
		if (couponNumberList != null && couponNumberList.size() > 0) {
			for (int i = 0; i < couponNumberList.size(); i++) {
				if(i > 0) sql += ",";
				sql += " ("+amoutDateModel.getActivityID()+","+amoutDateModel.getCouponID()+",'"+couponNumberList.get(i).getCouponNumber()+"','"+
						amoutDateModel.getCouponValidStartDate()+"','"+amoutDateModel.getCouponValidEndDate()+"','"+
						couponNumberList.get(i).getExchangeCode()+"',"+0+","+0+","+new BigDecimal(0)+",getDate(),'"+userName+"',getDate(),'"+userName+"')";
			}
		}
		Object [] params = {};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode = -1;
		}
		this.log.info(this.getClass().getName()+" addBatchCouponTrans End");
		long end = System.currentTimeMillis();
		System.err.println(start-end);
		return returnCode;
	}
	
//	@Override
//	public int addBatchCouponTrans(amoutDateModel amoutDateModel, Integer id,
//			String userName, List<CouponTrans> couponNumberList) {
//		this.log.info(this.getClass().getName()+" addBatchCouponTrans Start");
//		long start = System.currentTimeMillis();
//		int returnCode = 0;
//		String sql = "insert into F_NewCouponTrans(ActivityID,CouponID,CouponNumber,CouponValidStartDate,CouponValidEndDate,ExchangeCode,Status,DISABLED,DeductibleAmount,REC_CREATETIME,REC_CREATEBY,REC_MODIFYTIME,REC_MODIFYBY) "
//				+ "values(?,?,?,?,?,?,?,?,?,getDate(),?,getDate(),?)";
//		Connection connection = null;
//		try {
//			connection = this.getConnection();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		
//		try {
//			connection.setAutoCommit(true);
//			PreparedStatement cmd = connection
//					 .prepareStatement(sql);
//			for (int i = 0; i < couponNumberList.size(); i++) {
//				cmd.setInt(1, amoutDateModel.getActivityID());//
//				cmd.setInt(2, amoutDateModel.getCouponID());//
//				cmd.setString(3, couponNumberList.get(i).getCouponNumber());//
//				cmd.setDate(4, amoutDateModel.getCouponValidStartDate());//
//				cmd.setDate(5, amoutDateModel.getCouponValidEndDate());//
//				cmd.setString(6, couponNumberList.get(i).getExchangeCode());//
//				cmd.setInt(7, 0);//状态(0：未领取 1:已发放 3:已领取(已兑换) 5：已使用 10：已失效)
//				cmd.setInt(8, 0);//0：正常，1：失效
//				cmd.setBigDecimal(9, new BigDecimal(0));//抵扣运费金额
//				cmd.setString(10, userName);//创建人
//				cmd.setString(11, userName);//修改人
//			}
//			cmd.executeBatch();
//			connection.commit();
//			cmd.close();
//			connection.close();
//		} catch (SQLException e) {
//			e.printStackTrace();
//			this.log.error(this.getClass().getName()+" addBatchCouponTrans 批量新增："+e.getMessage());
//			return returnCode = -1;
//		}
//		this.log.info(this.getClass().getName()+" addBatchCouponTrans End");
//		long end = System.currentTimeMillis();
//		System.err.println(start-end);
//		return returnCode;
//	}
	
	@Override
	public int getNewCouponTransCount() {
		this.log.info(this.getClass().getName()+" getNewCouponTransCount Start");
		String sql = this.sqlProperty.getProperty("CouponActivityDao_027");
		int newCouponTransCount = this.queryForInt(sql);
		this.log.info(this.getClass().getName()+" getNewCouponTransCount End");
		return newCouponTransCount;
	}
		/**
	 * 更新活动的审核状态
	 * @param activityId 活动ID
	 * @param userName 
	 * @param oldAuditStates  审核状态(1:待审核 3:补发待审核 5:审核通过 10:审核拒绝)
	 * @param newAuditStates  审核状态(1:待审核 3:补发待审核 5:审核通过 10:审核拒绝)
	 * @return
	 */
	@Override
	public int updateNewCouponActivityAuditStatus(Integer activityId, String userName,Integer oldAuditStates,Integer newAuditStates) {
		this.log.info(this.getClass().getName()+" updateNewCouponActivityAuditStatus Start");
		String sql = this.sqlProperty.getProperty("CouponActivityDao_031");
		Object [] params={
				newAuditStates,userName,activityId,oldAuditStates
		};
		int returnCode = this.updateBySQL(sql, params);
		this.log.info(this.getClass().getName()+" updateNewCouponActivityAuditStatus End");
		return returnCode;
	}

	@Override
	public int delNewCouponActivityRel(Integer activityID, Integer auditStates) {
		this.log.info(this.getClass().getName()+" delNewCouponActivityRel Start");
		String sql = this.sqlProperty.getProperty("CouponActivityDao_032");
		Object [] params = {
				activityID,auditStates
		};
		int returnCode = this.updateBySQL(sql, params);
		this.log.info(this.getClass().getName()+" delNewCouponActivityRel End");
		return returnCode;
	}

	@Override
	public int updateNewCouponActivityRelAuditStatus(Integer activityID,String userName,int oldAuditStatus, int newAuditStatus) {
		this.log.info(this.getClass().getName()+" updateNewCouponActivityRelAuditStatus Start");
		String sql = this.sqlProperty.getProperty("CouponActivityDao_033");
		int returnCode;
		Object [] params = {
				newAuditStatus,userName,activityID,oldAuditStatus
		};
		returnCode = this.updateBySQL(sql, params);
		this.log.info(this.getClass().getName()+" updateNewCouponActivityRelAuditStatus End");
		return returnCode;
	}

	@Override
	public List<amoutDateModel> getReissueCouponActivityRelList(int activityID) {
		this.log.info(this.getClass().getName()+ " getReissueCouponActivityRelList Start");
		String sql = sqlProperty.getProperty("CouponActivityDao_034");
		Object [] params = {activityID};
		List<amoutDateModel> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new amoutDateModel()));
		this.log.info(this.getClass().getName()+ " getReissueCouponActivityRelList End");
		return list;
	}

	@Override
	public List<amoutDateModel> getReissueAmoutDateList(Integer activityID) {
		this.log.info(this.getClass().getName()+" getReissueAmoutDateList Start");
		String sql = this.sqlProperty.getProperty("CouponActivityDao_035");
		Object [] params = {activityID};
		List<amoutDateModel> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new amoutDateModel()));
		this.log.info(this.getClass().getName()+" getReissueAmoutDateList End");
		return list;
	}

	@Override
	public int insertNewCouponTemplateRel(List<NewCouponTemplateRel> newCouponTemplateRelList) {
		this.log.info(this.getClass().getName()+" insertNewCouponTemplateRel Start");
		int count = 0;
		if (newCouponTemplateRelList != null && newCouponTemplateRelList.size() > 0){
			StringBuilder sqlSB = new StringBuilder();
			sqlSB.append("INSERT INTO F_NewCouponTemplateRel (NewCouponID,TemplateID) VALUES");
			boolean falg = false;
			for (NewCouponTemplateRel rel : newCouponTemplateRelList){
				if (falg){
					sqlSB.append(",");
				}else{
					falg = true;
				}
				sqlSB.append("(");
				sqlSB.append(rel.getNewCouponID());
				sqlSB.append(",");
				sqlSB.append(rel.getTemplateID());
				sqlSB.append(")");
			}
			Object [] params = {};
			count = this.updateBySQL(sqlSB.toString(), params);
		}
		this.log.info(this.getClass().getName()+" insertNewCouponTemplateRel End");
		return count;
	}

	@Override
	public int deleteNewCouponTemplateRelByNewCouponID(Integer newCouponID) {
		this.log.info(this.getClass().getName()+" deleteNewCouponTemplateRelByNewCouponID Start");
		String sql = this.sqlProperty.getProperty("CouponActivityDao_036");
		Object [] params = {newCouponID};
		int count = this.updateBySQL(sql, params);
		this.log.info(this.getClass().getName()+" deleteNewCouponTemplateRelByNewCouponID End");
		return count;
	}

	@Override
	public List<NewCouponTemplateRel> selectNewCouponTemplateRelByNewCouponID(Integer newCouponID) {
		this.log.info(this.getClass().getName()+" selectNewCouponTemplateRelByNewCouponID Start");
		String sql = this.sqlProperty.getProperty("CouponActivityDao_037");
		Object [] params = {newCouponID};
		List<NewCouponTemplateRel> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new NewCouponTemplateRel()));
		this.log.info(this.getClass().getName()+" selectNewCouponTemplateRelByNewCouponID End");
		return list;
	}

	@Override
	public NewCoupon selectNewCouponByID(Integer ID) {
		this.log.info(this.getClass().getName()+" selectNewCouponByID Start");
		String sql = this.sqlProperty.getProperty("CouponActivityDao_038");
		Object [] params = {ID};
		NewCoupon newCoupon = (NewCoupon) this.queryForObject(sql, params, new CommonRowMapper(new NewCoupon()));
		this.log.info(this.getClass().getName()+" selectNewCouponByID End");
		return newCoupon;
	}
	
	/**
	 * 更新活动的审核状态
	 * @param 活动ID
	 * @param userName 
	 * @param activityStartDate  活动起始时间
	 * @param activityEndDate  活动结束时间
	 * @return
	 */
	@Override
	public int modifyAuditActivityDate(Integer ID, String userName, String activityStartDate, String activityEndDate) {
		this.log.info(this.getClass().getName()+" modifyAuditActivityDate Start");
		String sql = this.sqlProperty.getProperty("CouponActivityDao_039");
		Object [] params={
				DataUtil.StringToDate(activityStartDate, "yyyy-MM-dd"),
				DataUtil.StringToDate(activityEndDate, "yyyy-MM-dd"),
				userName,ID
		};
		int returnCode = this.updateBySQL(sql, params);
		this.log.info(this.getClass().getName()+" modifyAuditActivityDate End");
		return returnCode;
	}
	
}
