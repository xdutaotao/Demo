package shcem.market.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * 保单类型
 * @author wangshuai
 *
 */
public class InsurancePolicyType extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1965454832085347210L;
	// 主键ID
	private Integer id;
	// 默认为 0：正常，1：失效
	private Integer disabled;
	// 创建人
	private String rEC_CREATEBY;
	// 创建时间
	private Date rEC_CREATETIME;
	// 最后修改人
	private String rEC_MODIFYBY;
	// 最后修改时间
	private Date rEC_MODIFYTIME;
	// 类型名称
	private String typeName;
	// 支付金额
	private BigDecimal payAmount;
	// 保单费用（每吨）
	private BigDecimal premium;
	// 差价（每吨）
	private BigDecimal deltaPrice;
	// 差价类型,1:涨 2：跌
	private Integer deltaPriceType;
	// 说明
	private String remarks;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getrEC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public BigDecimal getPayAmount() {
		return payAmount;
	}

	public void setPayAmount(BigDecimal payAmount) {
		this.payAmount = payAmount;
	}

	public BigDecimal getPremium() {
		return premium;
	}

	public void setPremium(BigDecimal premium) {
		this.premium = premium;
	}

	public BigDecimal getDeltaPrice() {
		return deltaPrice;
	}

	public void setDeltaPrice(BigDecimal deltaPrice) {
		this.deltaPrice = deltaPrice;
	}

	public Integer getDeltaPriceType() {
		return deltaPriceType;
	}

	public void setDeltaPriceType(Integer deltaPriceType) {
		this.deltaPriceType = deltaPriceType;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}
