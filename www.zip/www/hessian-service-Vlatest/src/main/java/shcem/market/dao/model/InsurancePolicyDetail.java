package shcem.market.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * 保单详情 保单+保单类型+保价
 * 
 * @author sunf
 *
 */
public class InsurancePolicyDetail extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3314355855996917395L;
	// 主键ID
	private String id;
	// 默认为 0：正常，1：失效
	private Integer disabled;
	// 创建人
	private String rEC_CREATEBY;
	// 创建时间
	private Date rEC_CREATETIME;
	// 最后修改人
	private String rEC_MODIFYBY;
	// 最后修改时间
	private Date rEC_MODIFYTIME;
	// 保单类型ID
	private Integer insurancePolicyTypeID;
	// 已付保额
	private BigDecimal paidAmount;
	// 对象ID
	private String objectID;
	// 对象类型
	private Integer objectType;
	// 交易商ID
	private String firmID;
	// 交易员ID
	private String traderID;
	// 交易商类型
	private Integer firmType;
	// 保单状态
	private Integer status;
	// 保单日期
	private Date policyDate;
	// 保单品类
	private Integer categoryType;
	// 支付金额
	private BigDecimal payAmount;
	// 保单费用（每吨）
	private BigDecimal premium;
	// 差价（每吨）
	private BigDecimal deltaPrice;
	// 差价类型,1:涨 2：跌
	private Integer deltaPriceType;
	
	//品类名称
	private String categoryName;
 
	// 结算价格
	private BigDecimal settlementPrice;
	// 均价差
	private BigDecimal averageDeltaPrice;

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public BigDecimal getSettlementPrice() {
		return settlementPrice;
	}

	public void setSettlementPrice(BigDecimal settlementPrice) {
		this.settlementPrice = settlementPrice;
	}

	public BigDecimal getAverageDeltaPrice() {
		return averageDeltaPrice;
	}

	public void setAverageDeltaPrice(BigDecimal averageDeltaPrice) {
		this.averageDeltaPrice = averageDeltaPrice;
	}

	public String getrEC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setrEC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getrEC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setrEC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getrEC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setrEC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getrEC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setrEC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	public BigDecimal getPayAmount() {
		return payAmount;
	}

	public void setPayAmount(BigDecimal payAmount) {
		this.payAmount = payAmount;
	}

	public BigDecimal getPremium() {
		return premium;
	}

	public void setPremium(BigDecimal premium) {
		this.premium = premium;
	}

	public BigDecimal getDeltaPrice() {
		return deltaPrice;
	}

	public void setDeltaPrice(BigDecimal deltaPrice) {
		this.deltaPrice = deltaPrice;
	}

	public Integer getDeltaPriceType() {
		return deltaPriceType;
	}

	public void setDeltaPriceType(Integer deltaPriceType) {
		this.deltaPriceType = deltaPriceType;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	public Integer getInsurancePolicyTypeID() {
		return insurancePolicyTypeID;
	}

	public void setInsurancePolicyTypeID(Integer insurancePolicyTypeID) {
		this.insurancePolicyTypeID = insurancePolicyTypeID;
	}

	public BigDecimal getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(BigDecimal paidAmount) {
		this.paidAmount = paidAmount;
	}

	public String getObjectID() {
		return objectID;
	}

	public void setObjectID(String objectID) {
		this.objectID = objectID;
	}

	public Integer getObjectType() {
		return objectType;
	}

	public void setObjectType(Integer objectType) {
		this.objectType = objectType;
	}

	public String getFirmID() {
		return firmID;
	}

	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}

	public String getTraderID() {
		return traderID;
	}

	public void setTraderID(String traderID) {
		this.traderID = traderID;
	}

	public Integer getFirmType() {
		return firmType;
	}

	public void setFirmType(Integer firmType) {
		this.firmType = firmType;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Date getPolicyDate() {
		return policyDate;
	}

	public void setPolicyDate(Date policyDate) {
		this.policyDate = policyDate;
	}

	public Integer getCategoryType() {
		return categoryType;
	}

	public void setCategoryType(Integer categoryType) {
		this.categoryType = categoryType;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
