package shcem.market.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.market.dao.model.InsuranceBack;
import shcem.market.dao.model.InsurancePolicy;
import shcem.market.dao.model.InsurancePolicyDetail;
import shcem.market.dao.model.InsurancePolicyPrice;
import shcem.market.dao.model.InsurancePolicyType;
import shcem.market.dao.model.QueryOrderPolicy;
import shcem.market.service.model.AuditInsuranceBackVo;
import shcem.market.service.model.InsurancePolicyPriceVo;

/**
 * 保单相关DAO
 * 
 * @author wangshuai
 *
 */
public interface IInsurancePolicyDao extends DAO {

	/**
	 * 插入
	 * 
	 * @param insurancePolicyPrice
	 * @return
	 */
	int insertInsurancePolicyPrice(InsurancePolicyPrice insurancePolicyPrice);

	/**
	 * 查询保价列表
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	List<InsurancePolicyPriceVo> getInsurancePolicyPriceList(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 查询保价
	 * 
	 * @param policyDateStr
	 *            保单日期
	 * @return
	 */
	InsurancePolicyPriceVo getInsurancePolicyPrice(String policyDateStr);

	/**
	 * 查询订单报价列表
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	List<QueryOrderPolicy> getOrderPolicyList(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 更新保价表
	 * 
	 * @param insurancePolicyPrice
	 * @return
	 */
	int updateInsurancePolicyPrice(InsurancePolicyPrice insurancePolicyPrice);

	/**
	 * 根据传入保单日期 获得上一个保单日期
	 * 
	 * @param insurancePolicyPrice
	 * @return
	 */
	Date getPreviousInsurancePolicyPriceOfPolicyDate(Date policyDate);

	/**
	 * 获取保价列表
	 * 
	 * @param insurancePolicyPrice
	 * @return
	 */
	List<InsurancePolicyPrice> getInsurancePolicyPriceListByPolicyDate(Date policyDate);
	
	/**
	 * 更新保单
	 * @param modifyBy 更新人
	 * @param policyDateStr 保单日期(yyyy-MM-dd)
	 * @param firmType 0：卖方交易商 1:买方交易商 
	 * @param categoryType  保单品类:1:PE 2:PP
	 * @param newStatus 1：未处理 5：未中保 10：已中保
	 * @param oldStatus 1：未处理 5：未中保 10：已中保
	 * @return
	 */
	int updateInsurancePolicy(String modifyBy, String policyDateStr,Integer firmType,Integer categoryType,Integer newStatus,Integer oldStatus);
	
	/**
	 * 获取保单类型列表
	 * @return
	 */
	List<InsurancePolicyType> getInsurancePolicyTypeList();
	
	
	/**
	 * 删除保价数据
	 * @return
	 */
	int deleteInsurancePolicyPrice(String policyDateStr);

	/**
	 * 根据保单 ID 获取保单详情
	 * @param policyId
	 * @return
	 */
	InsurancePolicyDetail getInsurancePolicyDetailById(int policyId);

	/**
	 * 新增退保
	 * @param model
	 * @return
	 */
	int insertInsuranceBack(InsuranceBack model);
	
	/**
	 * 根据ＩＤ获取退保表信息
	 * @return
	 */
	InsuranceBack getInsuranceBackByID(Integer id);
	
	/**
	 * 更新 退保
	 * @param id 退保ID
	 * @param oldStatus 退保状态 1已申请 5已执行
	 * @param newStatus 退保状态 1已申请 5已执行
	 * @param reviewer 审核人
	 * @param realBackAmount 实退保金额
	 * @return
	 */
	int updateInsuranceBackByID(AuditInsuranceBackVo vo);
	
	
	/**
	 * 根据ＩＤ获取保单表信息
	 * @return
	 */
	InsurancePolicy getInsurancePolicyByID(Integer id);
	
	public abstract void rollBack();
	
	/**
	 * 统计表单列表个数
	 * @return
	 */
	int totalOrderPolicyList(QueryConditions qc);
	
	/**
	 * 根据成交单获取保价单记录
	 * @param orderId 成交单号
	 * @param firmType 0：卖方交易商 1:买方交易商 
	 * @param status 1：未处理 5：未中保 10：已中保
	 * @return 
	 */
	List<InsurancePolicy> getInsurancePolicyByObjectID(String orderId, Integer firmType, Integer status);
	
	/**
	 * 根据交收单获取退保表记录
	 * @param deliveryId 交收单号
	 * @param insurancePolicyId 保单ID
	 * @param firmType 0：卖方交易商 1:买方交易商 
	 * @param status 退保状态： 1已申请  5已执行
	 * @return
	 */
	InsuranceBack getInsuranceBackByDeliveryID(String deliveryId, Integer insurancePolicyId, Integer status); 
	
	/**
	 * 根据成交单获取退保表记录
	 * @param insurancePolicyId 保单ID
	 * @param firmType 0：卖方交易商 1:买方交易商 
	 * @param status 退保状态： 1已申请  5已执行
	 * @return
	 */
	List<InsuranceBack> getInsuranceBackList(Integer insurancePolicyId, Integer status);
	 
	/**
	 * 更新保单中的支付状态
	 * @param InsurancePolicyId 保单ID
	 * @param payStatus 支付状态 1：未支付 5：已支付
	 * @param modifyBy 更新人
	 * @return
	 */
	int updateInsurancePolicyPayStatus(Integer InsurancePolicyId, Integer payStatus, String modifyBy);
	
	/**
	 * 根据 保单日期 获取 保单列表
	 * @param policyDateStr
	 * @return
	 */
	List<InsurancePolicy> getInsurancePolicyListByPolicyDate(String policyDateStr,Integer categoryType);
	
	
	/**
	 * 获取保单类型表
	 * @param policyDateStr
	 * @return
	 */
	InsurancePolicyType getInsurancePolicyTypeByID(Integer id);
	
	/**
	 * 更细 保单状态
	 * @return
	 */
	int updateInsurancePolicyByID(Integer id,Integer status,String modifyby);
	
	/**
	 * 获取保单类型表
	 * @param deliveryId 交收单ID
	 * @return
	 */
	InsuranceBack getInsuranceBackByDeliveryID(String deliveryId);
}

