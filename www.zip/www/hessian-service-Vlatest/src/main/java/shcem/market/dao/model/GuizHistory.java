package shcem.market.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * 竞猜记录表
 * 
 * @author wangshuai
 *
 */
public class GuizHistory extends BaseObject implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -919562867729015884L;
	// 主键ID
	private Long iD;
	// 默认为 0：正常，1：失效
	private Integer dISABLED;
	private String rEC_CREATEBY;
	private Date rEC_CREATETIME;
	private String rEC_MODIFYBY;
	private Date rEC_MODIFYTIME;
	// 交易员编号
	private String traderID;
	// 交易员名称
	private String traderName;
	// 交易员手机号
	private String mobile;
	// 竞猜价格
	private BigDecimal quizPrice;
	// 状态
	private Integer status;
	// 竞猜活动合约价格ID
	private Integer quizActivity_ID;
	
	private Integer counts;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Long getiD() {
		return iD;
	}

	public void setiD(Long iD) {
		this.iD = iD;
	}

	public Integer getdISABLED() {
		return dISABLED;
	}

	public void setdISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public String getrEC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setrEC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getrEC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setrEC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getrEC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setrEC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getrEC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setrEC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	public String getTraderID() {
		return traderID;
	}

	public void setTraderID(String traderID) {
		this.traderID = traderID;
	}

	public String getTraderName() {
		return traderName;
	}

	public void setTraderName(String traderName) {
		this.traderName = traderName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public BigDecimal getQuizPrice() {
		return quizPrice;
	}

	public void setQuizPrice(BigDecimal quizPrice) {
		this.quizPrice = quizPrice;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getQuizActivity_ID() {
		return quizActivity_ID;
	}

	public void setQuizActivity_ID(Integer quizActivity_ID) {
		this.quizActivity_ID = quizActivity_ID;
	}

	public Integer getCounts() {
		return counts;
	}

	public void setCounts(Integer counts) {
		this.counts = counts;
	}


}
