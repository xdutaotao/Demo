package shcem.market.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.constant.ResultCode;
import shcem.finance.util.JSONArrayUtil;
import shcem.market.component.IInsurancePolicyComponent;
import shcem.market.dao.model.ExportInsuranceBack;
import shcem.market.dao.model.ExportOrderPolicy;
import shcem.market.dao.model.InsurancePolicyPrice;
import shcem.market.dao.model.QueryOrderPolicy;
import shcem.market.service.IInsurancePolicyService;
import shcem.market.service.model.InsurancePolicyPriceDto;
import shcem.market.service.model.InsurancePolicyPriceVo;
import shcem.market.service.model.PolicyBackApplyDto;
import shcem.market.service.model.PolicyBackApplyVo;
import shcem.market.util.MarketSysData;
import shcem.util.Common;
import shcem.util.DateUtil;
import shcem.util.ExportExcel;
import shcem.util.JsonUtil;
import shcem.util.UploadHttpFile;

/**
 * 保单相关api实现
 * 
 * @author wangshuai
 *
 */
public class InsurancePolicyServiceImpl extends BaseServiceImpl implements IInsurancePolicyService {

	private IInsurancePolicyComponent insurancePolicyComponent = (IInsurancePolicyComponent) MarketSysData
			.getBean(Constants.BEAN_INSURANCE_POLICY__MGR);

	private String className = InsurancePolicyServiceImpl.class.getName() + " ";

	@Override
	public String createInsurancePolicyPrice(String params) {
		this.log.info(className + " createInsurancePolicyPrice() Start");
		String userName = this.getUserName() == null ? "system"
				: (this.getUserName() == "") ? "system" : this.getUserName();
		InsurancePolicyPriceDto dto = new InsurancePolicyPriceDto();
		try {
			JSONObject JOParams = new JSONObject(params);
			// dto.setCategoryName(JSONArrayUtil.getJsonToStringArray(JOParams.getJSONArray("categoryName")));
			dto.setCategoryType(JSONArrayUtil.getJsonToIntegerArray(JOParams.getJSONArray("categoryType")));
			dto.setSettlementPrice(JSONArrayUtil.getJsonToBigDecimalArray(JOParams.getJSONArray("settlementPrice")));
			dto.setCurrentUser(userName);
			List<Date> list = new ArrayList<Date>();
			Date[] dateArray = JSONArrayUtil.getJsonToDateArray(JOParams.getJSONArray("policyDateList"));
			if (dateArray.length > 0) {
				for (Date date : dateArray) {
					list.add(date);
				}
			} else {
				setResultData("10103", null, "交割日期不能为空！");
				return rtnData.toString();
			}
			dto.setPolicyDateList(list);
		} catch (Exception e) {
			this.log.error("转换JSON异常，" + e.getMessage());
			setResultData("10103", null);
			return rtnData.toString();
		}

		try {
			int resultCode = insurancePolicyComponent.addInsurancePolicyPrice(dto);
			if (resultCode < 0) {
				setResultData(-resultCode + "", null);
			} else {
				setResultData("00000", null);
			}
		} catch (Exception err) {
			this.log.error("添加保价数据失败：" + err.getMessage());
			setResultData("30000", null);
		}
		this.log.info(this.getClass().getName() + " createInsurancePolicyPrice() End");
		return rtnData.toString();

	}

	@Override
	public String updateInsurancePolicyPrice(String params) {
		this.log.info(className + " updateInsurancePolicyPrice() Start");
		String userName = this.getUserName() == null ? "system"
				: (this.getUserName() == "") ? "system" : this.getUserName();
		InsurancePolicyPriceDto dto = new InsurancePolicyPriceDto();
		try {
			JSONObject JOParams = new JSONObject(params);
			// dto.setCategoryName(JSONArrayUtil.getJsonToStringArray(JOParams.getJSONArray("categoryName")));
			dto.setCategoryType(JSONArrayUtil.getJsonToIntegerArray(JOParams.getJSONArray("categoryType")));
			dto.setSettlementPrice(JSONArrayUtil.getJsonToBigDecimalArray(JOParams.getJSONArray("settlementPrice")));
			dto.setCurrentUser(userName);
			dto.setPolicyDate(DateUtil.formatDate(JOParams.getString("policyDate"), "yyyy-MM-dd"));
		} catch (Exception e) {
			this.log.error("转换JSON异常，" + e.getMessage());
			setResultData("10103", null);
			return rtnData.toString();
		}

		try {
			int resultCode = insurancePolicyComponent.updateInsurancePolicyPrice(dto);
			if (resultCode < 0) {
				setResultData(-resultCode + "", null);
			} else {
				setResultData("00000", null);
			}
		} catch (Exception err) {
			this.log.error("更新保价数据失败：" + err.getMessage());
			setResultData("30000", null);
		}
		this.log.info(this.getClass().getName() + " updateInsurancePolicyPrice() End");
		return rtnData.toString();
	}

	@Override
	public String getInsurancePolicyPriceList(String params) {
		this.log.info(className + " getInsurancePolicyPriceList() Start");
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");

		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(
				new Condition("CONVERT(VARCHAR(10), temp.PolicyDate, 120)", ">=", "", "String", "policyDateStart"));
		conditionList
				.add(new Condition("CONVERT(VARCHAR(10), temp.PolicyDate, 120)", "<=", "", "String", "policyDateEnd"));
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");

		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<InsurancePolicyPriceVo> list = null;
		boolean bolRst = false;
		try {
			list = insurancePolicyComponent.getInsurancePolicyPriceList(qc, pageInfo);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("取得保价列表失败：" + err.getMessage());
			setResultData("30000", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("30000", null, e.getMessage());
			}
		}
		this.log.info(className + " getInsurancePolicyPriceList() End");
		return rtnData.toString();
	}

	private QueryConditions buildOrderPolicyConditions(JSONObject JOParams) {

		JSONObject queryModel = JOParams.optJSONObject("queryModel");

		List<Condition> conditionList = new ArrayList<Condition>();
		conditionList.add(new Condition("CONVERT(VARCHAR(10), temp.TradeDate, 120)", ">=", "", "String", "startDate"));
		conditionList.add(new Condition("CONVERT(VARCHAR(10), temp.TradeDate, 120)", "<=", "", "String", "endDate"));
		conditionList.add(new Condition("temp.deliveryId", "=", "", "String", "deliveryID"));
		conditionList.add(new Condition("temp.orderId", "=", "", "String", "orderID"));
		conditionList.add(new Condition("temp.backStatus", "=", "", "String", "status"));
		conditionList.add(new Condition("temp.firmType", "=", "", "Integer", "firmType"));
		conditionList.add(new Condition("temp.PolicyStatus","=","","Integer","policyStatus"));
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		if (null != queryModel) {
			// 交易商检索条件追加
			String traderName = queryModel.optString("traderName");
			if (traderName != null && !"".equals(traderName)) {
				qc.addCondition("(temp.FirmName like '%" + traderName + "%' or temp.FirmId like '%" + traderName
						+ "%') and '1'=", " ", 1);
			}
		}
		return qc;

	}

	@Override
	public String getOrderPolicyList(String params) {
		this.log.info(className + " getOrderPolicyList() Start");
		JSONObject JOParams = new JSONObject(params);
		QueryConditions qc = buildOrderPolicyConditions(JOParams);
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<QueryOrderPolicy> list = null;
		boolean bolRst = false;
		try {
			list = insurancePolicyComponent.getOrderPolicyList(qc, pageInfo);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("取得订单保价列表失败：" + err.getMessage());
			setResultData("30000", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("30000", null, e.getMessage());
			}
		}
		this.log.info(className + " getOrderPolicyList() End");
		return rtnData.toString();
	}

	@Override
	public String applyPolicyBack(String params) {
		this.log.info(className + " applyPolicyBack() Start");
		try {
			JSONObject joParams=new JSONObject(params);
			JSONArray jsonArray = joParams.getJSONArray("applyArr");
			List<PolicyBackApplyDto> list = new ArrayList<PolicyBackApplyDto>();
			String userName = this.getUserName() == null ? "system"
					: (this.getUserName() == "") ? "system" : this.getUserName();
			for (int i = 0; i < jsonArray.length(); i++) {
				PolicyBackApplyVo voModel = (PolicyBackApplyVo) JsonUtil.jsonToBean(jsonArray.getJSONObject(i),
						PolicyBackApplyVo.class);
				PolicyBackApplyDto dtoModel = new PolicyBackApplyDto();
				dtoModel.setDeliveryId(voModel.getDeliveryId());
				dtoModel.setPolicyId(voModel.getPolicyId());
				dtoModel.setUserName(userName);
				list.add(dtoModel);
			}

			int retCode = this.insurancePolicyComponent.applyPolicyBack(list);
			if (retCode < 0) {
				setResultData(-retCode+"", null);
			} else {
				setResultData("00000", null);
			}
		} catch (JSONException ex) {
			this.log.error("JSON 转换失败 :" + ex.getMessage());
			setResultData("10103", null);
		} catch (Exception ex) {
			this.log.error("保价付款申请失败:" + ex.getMessage());
			setResultData("30000", null);
		}

		this.log.info(className + " applyPolicyBack() End");
		return rtnData.toString();
	}

	public String CheckValidationPolicyDate(String params) {
		this.log.info(this.getClass().getName() + " CheckValidationPolicyDate() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		boolean bolRst = false;
		JSONArray quizDateArrayTemp = JOParams.getJSONArray("policyDateArray");
		String[] policyDateArray = JSONArrayUtil.getJsonToStringArray(quizDateArrayTemp);
		if (policyDateArray.length == 0) {
			setResultData("30000", null);
			return rtnData.toString();
		}
		List<InsurancePolicyPrice> list = new ArrayList<InsurancePolicyPrice>();
		try {
			list = insurancePolicyComponent.getInsurancePolicyPriceByPolicyDate(policyDateArray);
			bolRst = true;
		} catch (Exception e) {
			this.log.error(this.getClass().getName() + " CheckValidationPolicyDate 重复校验失败：" + e.getMessage());
			setResultData("30000", null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error(this.getClass().getName() + " CheckValidationPolicyDate 查询保价失败：" + e.getMessage());
				setResultData("30000", null);
			}

		}
		this.log.info(this.getClass().getName() + " CheckValidationPolicyDate() End");
		return rtnData.toString();
	}

	@Override
	public String getInsurancePolicyPriceDetailByPolicyDate(String params) {
		this.log.info(this.getClass().getName() + " getInsurancePolicyPriceListByPolicyDate() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		boolean bolRst = false;
		String policyDateStr = JOParams.getString("policyDate");
		List<InsurancePolicyPrice> list = null;
		try {
			list = insurancePolicyComponent
					.getInsurancePolicyPriceByPolicyDate(DateUtil.formatDate(policyDateStr, "yyyy-MM-dd"));
			bolRst = true;
		} catch (Exception e) {
			this.log.error(
					this.getClass().getName() + " getInsurancePolicyPriceListByPolicyDate 查询保价列表失败" + e.getMessage());
			setResultData("30000", null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error(
						this.getClass().getName() + " getInsurancePolicyPriceListByPolicyDate 转换列表失败" + e.getMessage());
				setResultData("30000", null);
			}
		}
		this.log.info(this.getClass().getName() + " getInsurancePolicyPriceListByPolicyDate() End");
		return rtnData.toString();
	}

	@Override
	public String disableInsurancePolicyPrice(String params) {
		this.log.info(className + " deleteInsurancePolicyPrice() Start");
		this.log.debug("JOParams=" + params);
		// String userName = this.getUserName() == null ? "system" :
		// (this.getUserName() == "") ? "system" : this.getUserName();
		Date policyDate = null;
		try {
			JSONObject JOParams = new JSONObject(params);
			policyDate = DateUtil.formatDate(JOParams.getString("policyDate"), "yyyy-MM-dd");
		} catch (Exception e) {
			this.log.error("转换JSON异常，" + e.getMessage());
			setResultData("10103", null);
			return rtnData.toString();
		}
		try {
			int resultCode = insurancePolicyComponent
					.deleteInsurancePolicyPrice(DateUtil.convert(policyDate, "yyyy-MM-dd"));
			if (resultCode < 0) {
				setResultData(-resultCode + "", null);
			} else {
				setResultData("00000", null);
			}
		} catch (Exception err) {
			this.log.error("删除保价数据失败：" + err.getMessage());
			setResultData("30000", null);
		}
		this.log.info(this.getClass().getName() + " deleteInsurancePolicyPrice() End");
		return rtnData.toString();
	}

	@Override
	public String exePolicyBack(String params) {
		this.log.info(className + " exePolicyBack() Start");
		this.log.debug("JOParams=" + params);
		String userName = this.getUserName() == null ? "system"
				: (this.getUserName() == "") ? "system" : this.getUserName();
		JSONObject JOParams = new JSONObject(params);
		Integer id = JOParams.getInt("id");
		try {
			int resultCode = insurancePolicyComponent.exePolicyBack(id, userName, userName);
			if (resultCode < 0) {
				setResultData(-resultCode + "", null);
			} else {
				setResultData("00000", null);
			}
		} catch (Exception err) {
			this.log.error("支付中保金失败！" + err.getMessage());
			setResultData("110020", null);
		}
		this.log.info(className + " exePolicyBack() End");
		return rtnData.toString();
	}

	@Override
	public String exportOrderPolicy(String params) {
		this.log.info(className + " exportOrderPolicy() Start");
		JSONObject JOParams = new JSONObject(params);
		QueryConditions qc = buildOrderPolicyConditions(JOParams);
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<ExportOrderPolicy> list = null;
		boolean bolRst = false;
		try {
			list = insurancePolicyComponent.exportOrderPolicy(qc, pageInfo);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("导出订单保价列表查询失败：" + err.getMessage());
			setResultData("30000", null, err.getMessage());
		}

		if (bolRst) {
			List<String> headers = new ArrayList<String>();
			headers.add("交收单号");
			headers.add("成交单号");
			headers.add("交易商编码");
			headers.add("交易商名称");
			headers.add("活动方式");
			headers.add("均差价");
			headers.add("签收数量(吨)");
			headers.add("成交单价");
			headers.add("参保已收金额");
			headers.add("应退金额");
			headers.add("已退金额");
			headers.add("状态");
			JSONObject queryModel = JOParams.optJSONObject("queryModel");
			String fileName = "订单保价列表(卖)";
			String sheetName = "订单保价列表(卖)";
			if (queryModel != null) {
				if (queryModel.optInt("firmType", 0) == 1) {
					fileName = "订单保价列表(买)";
					sheetName = "订单保价列表(买)";
				}
			}

			int totalCount = this.insurancePolicyComponent.totalOrderPolicyList(qc);;
			this.exportToExcel(headers, fileName, sheetName, list, totalCount);
		}
		this.log.info(className + " exportOrderPolicy() End");
		return rtnData.toString();
	}

	@Override
	public String exportInsuranceBack(String params) {
		this.log.info(className + " exportInsuranceBack() Start");
		JSONObject JOParams = new JSONObject(params);
		QueryConditions qc = buildOrderPolicyConditions(JOParams);
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);

		List<ExportInsuranceBack> list = null;
		boolean bolRst = false;
		try {
			list = insurancePolicyComponent.exportInsuranceBack(qc, pageInfo);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("导出保价付款审核列表查询失败：" + err.getMessage());
			setResultData("30000", null, err.getMessage());
		}

		if (bolRst) {
			List<String> headers = new ArrayList<String>();
			headers.add("交收单号");
			headers.add("成交单号");
			headers.add("交易商编码");
			headers.add("交易商名称");
			headers.add("活动方式");
			headers.add("均差价");
			headers.add("签收数量(吨)");
			headers.add("成交单价");
			headers.add("参保已收金额");
			headers.add("应退金额");
			headers.add("已退金额");
			headers.add("申请人");
			headers.add("申请时间");
			headers.add("状态");
			JSONObject queryModel = JOParams.optJSONObject("queryModel");
			String fileName = "保单付款审核(卖)";
			String sheetName = "保单付款审核(卖)";
			if (queryModel != null) {
				if (queryModel.optInt("firmType", 0) == 1) {
					fileName = "保单付款审核(买)";
					sheetName = "保单付款审核(买)";
				}
			}

			int totalCount =this.insurancePolicyComponent.totalOrderPolicyList(qc);
			this.exportToExcel(headers, fileName, sheetName, list, totalCount);
		}
		this.log.info(className + " exportInsuranceBack() End");
		return rtnData.toString();
	}

	/**
	 * 导出到Excel文件
	 */
	private <T> void exportToExcel(List<String> excelHeaders, String fileName, String sheetName, List<T> exportlist,
			int totalCount) {
		if (exportlist != null && exportlist.size() > 0) {
			JSONObject jsonObj = new JSONObject();
			ExportExcel<T> ex = new ExportExcel<T>();

			String[] headers = new String[excelHeaders.size()];

			ByteArrayOutputStream out = null;
			ByteArrayInputStream in = null;
			try {
				String time = Common.df6.format(new Date());
				String excelName = fileName + time.toString() + ".xls";
				out = new ByteArrayOutputStream();
				ex.exportExcel(sheetName, excelHeaders.toArray(headers), exportlist, out, null);
				in = new ByteArrayInputStream(out.toByteArray());
				String uploadUrl = Common.getUploadUrl(this.getMode());
				String httpUrl = UploadHttpFile.uploadFile(in, excelName, uploadUrl);
				out.close();
				in.close();
				if (null != httpUrl) {
					this.log.debug("httpUrl:" + httpUrl);
					jsonObj.put("httpUrl", httpUrl);
					jsonObj.put("fileName", excelName);
					setResultData(ResultCode.CODE00000.getValue(), jsonObj);
					if (totalCount > Constants.EXPORT_MAX_COUNT)
						setResultData("10122", jsonObj);
				} else {
					setResultData(ResultCode.CODE40013.getValue(), null);
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				// 清理资源
				try {
					out.close();
				} catch (IOException e1) {
					e1.printStackTrace();
					setResultData(ResultCode.CODE40013.getValue(), null);
				}
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
					setResultData(ResultCode.CODE40013.getValue(), null);
				}
			}
		} else {
			setResultData("10101", null);
		}
	}

	@Override
	public String runJobWinningPolicy(String params) {
		this.log.info(this.getClass().getName() + " runJobWinningPolicy() Start");
		this.log.debug("JOParams=" + params);
		String exeDate = "";
		try {
			JSONObject JOParams = new JSONObject(params);
			if (JOParams.opt("exeDate") != null && !"".equals(JOParams.getString("exeDate"))){
				exeDate = JOParams.optString("exeDate");
			}else{
				exeDate =  DateUtil.convert(new Date(), "yyyy-MM-dd");
			}
		} catch (Exception e) {
			exeDate =  DateUtil.convert(new Date(), "yyyy-MM-dd");
		}
		
		try {
			InsurancePolicyPriceVo vo = insurancePolicyComponent.getInsurancePolicyPrice(exeDate);
			if (vo != null){
				int resultCode = insurancePolicyComponent.updateInsurancePolicyStatus(exeDate, "system");
				if (resultCode < 0){
					setResultData(-resultCode+"", null);
				}else{
					setResultData("00000", null);
				}
			}else{
				setResultData("00000", null,"当前时间不在保价活动时间范围内，不执行job！");
			}
		} catch (Exception e) {
			this.log.error("异常信息：" + e.getMessage());
			setResultData("100002", null, e.getMessage());
		}
		this.log.info(this.getClass().getName() + " runJobWinningPolicy() End");
		return rtnData.toString();
	}

}
