package shcem.market.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import shcem.base.dao.DAO;
import shcem.market.dao.model.GuizHistory;
import shcem.market.dao.model.QuizActivity;
import shcem.market.dao.model.QuizHistory;
import shcem.market.dao.model.QuizHistoryAndQuizActivity;
import shcem.market.dao.model.QuizMoney;
import shcem.market.dao.model.QuizMoneyPool;
import shcem.market.dao.model.QuizWinningResult;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.market.dao.model.QueryGuizHistory;

public interface IQuizActivitiesDao extends DAO {

	/**
	 * 获取 前3条 竞猜记录 列表 条件 当前查询日期下，竞猜金额是在 (合约金额 - folatValue <= 竞猜金额 <= 合约金额 +
	 * folatValue) 排序：取正（竞猜金额 -合约金额） ASC，竞猜日期 ASC
	 * 
	 * @param date
	 * @param folatValue
	 *            浮动值 正负
	 * @return
	 */
	public List<QuizHistoryAndQuizActivity> selectGuizHistoryList(String date,
			Integer folatValue);

	/**
	 * 竞猜活动奖金池表
	 * 
	 * @return
	 */
	public List<QuizMoneyPool> selectQuizMoneyPoolList();

	/**
	 * 插入竞猜中奖结果表
	 * 
	 * @param quizWinningResult
	 * @return
	 */
	public int insertQuizWinningResult(QuizWinningResult quizWinningResult);

	/**
	 * 插入竞猜活动奖金设置表
	 * 
	 * @param quizMoney
	 * @return
	 */
	public int insertQuizMoney(QuizMoney quizMoney);

	/**
	 * 更新 竞猜活动奖金设置表
	 * 
	 * @param quizMoney
	 * @param quizDateStr
	 * @return
	 */
	public int updateQuizMoneyByQuizDate(QuizMoney quizMoney, String quizDateStr);

	/**
	 * 查询竞猜活动奖金设置表
	 * 
	 * @param quizMoney
	 * @return
	 */
	public List<QuizMoney> selectQuizMoneyListByDate(String date);

	/**
	 * 查询竞猜活动奖金设置表
	 * 
	 * @param date
	 * @param moneyTerm
	 * @return
	 */
	public QuizMoney selectQuizMoney(String date, Integer moneyTerm);

	/**
	 * 更新 竞猜活动奖金池表
	 * 
	 * @param moneyTerm
	 * @return
	 */
	public int updateQuizMoneyPoolByMoneyTerm(BigDecimal poolMoney,
			Integer moneyTerm);

	/**
	 * 插入竞猜活动奖金池表
	 * 
	 * @param quizMoneyPool
	 * @return
	 */
	public int insertQuizMoneyPool(QuizMoneyPool quizMoneyPool);

	/**
	 * 获取 竞猜活动合约价格列表
	 * 
	 * @param date
	 *            时间(yyyy-mm-dd)
	 * @return
	 */
	public List<QuizActivity> selectQuizActivityByQuizDate(String date);

	/**
	 * 竞猜历史记录查询
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	List<QueryGuizHistory> queryCouponTypeList(QueryConditions qc,
			PageInfo pageInfo);

	/**
	 * 统计 竞猜历史记录的条数
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	Integer countGuizHistory(String date);

	public void rollBack();

	public int addQuizActivities(String userName, QuizActivity quizActivity);

	public int addQuizMoney(String userName, int moneyTerm,
			BigDecimal quizMoney, Date quizDate);

	/**
	 * 查询奖金池中累计金额
	 * 
	 * @return
	 */
	public BigDecimal getQuizMoneyPoolMoney();

	/**
	 * 更新 包含idArr 竞猜记录表
	 * 
	 * @param status
	 * @param idList
	 * @param date
	 * @return
	 */
	int updateQueryGuizHistoryInIdList(Integer status, List<Integer> idList,
			String date);

	/**
	 * 更新 包含idArr竞猜记录表
	 * 
	 * @param status
	 * @param idList
	 * @param date
	 * @return
	 */
	int updateQueryGuizHistoryNotInIdList(Integer status, List<Integer> idList,
			String date);

	public List<QuizActivity> getQuizActivitiesDetail(String quizDate);

	public List<QuizActivity> getQuizActivitiesList(QueryConditions qc,
			PageInfo pageInfo);

	public int updateQuizMoneyPoolMoney();

	public int updateQuizActivitiesPrice(String userName,
			QuizActivity quizActivity);

	public int deleteQuizActivitie(String quizDateString);

	public int deleteQuizMoney(String quizDateString);

	public List<QuizActivity> getQuizActivitiesListByQuizDate(
			String quizDateString);

	public List<QuizActivity> getQuizActivitieDetailByQuizDate(
			String quizDateString);

	public int updateQuizMoney(String userName, BigDecimal quizMoney,
			int moneyTerm, Date quizDate);

	public int getQuizMoneyCount(int moneyTerm, Date quizDate);
	
	/**
	 * 根据：当前日期 获取 [竞猜活动合约价格表] 中的  下一个竞猜日期
	 * @param date 当前日期
	 * @return
	 */
	public Date getCurrentDateOfNextQuizDateFormQuizActivity(String date);
	
	/**
	 * 根据：当前日期 获取 [竞猜活动奖金设置表] 中的  下一个竞猜日期
	 * @param date 当前日期
	 * @return
	 */
	public Date getCurrentDateOfNextQuizDateFormQuizMoney(String date);
	
	/**
	 * 更新 竞猜活动合约价格表 的官方解读
	 * @param answer 官方解读
	 * @param modifyby 修改人
	 * @param quizDateStr 竞猜日期
	 * @param category 品类
	 * @return
	 */
	public int updateQuizActivityOfAnswer(String answer,String modifyby,String quizDateStr);
	
	
	/**
	 * 获得竞猜活动合约价格的解读
	 * @param quizDateStr
	 * @param category
	 * @return
	 */
	public QuizActivity getQuizActivity(String quizDateStr);
	
	/**
	 * 插入竞猜记录表(后台用)
	 * @param quizHistory
	 * @return
	 */
	public int insertQuizHistory(QuizHistory quizHistory);
	
	
	public List<QuizActivity> getValidateQuizActivitiesList(String quizDate, String filter);
	
	public List<QuizHistory> getModifiedQuizHistoryList(String quizDate);
	
	
	public List<QuizWinningResult> getWinningResultList(String filter);
	
	/**
	 * 至尊预言帝8888元
	 * @param quizDate
	 * @return
	 */
	public List<QuizHistory> getPrize10(String quizDate);
	
	/**
	 * 至尊预言帝1888元
	 * @param quizDate
	 * @return
	 */
	public List<QuizHistory> getPrize20(String quizDate);
	
	/**
	 * 入围奖50元
	 * @param quizDate
	 * @return
	 */
	public List<QuizHistory> getPrize30(String quizDate);
}
