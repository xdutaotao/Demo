package shcem.market.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * 优惠券使用记录实体
 * @author lihaifeng 
 *
 */
public class NewCouponTrans extends BaseObject implements Serializable{

	/**
	 * 默认的序列id
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 主键id
	 */
	private Integer id;
	
	/**
	 * 优惠券号码
	 */
	private String couponNumber;

	/**
	 * 兑换码
	 */
	private String exchangeCode;

	/**
	 * 活动名称
	 */
	private String activityName;
	
	/**
	 * 优惠券名称
	 */
	private String couponName;
	
	/**
	 * 优惠券类型 (1:抵扣型 2:充值型)
	 */
	private Integer couponType; 
	
	/**
	 * 优惠劵面额（元）
	 */
	private BigDecimal amount;

	/**
	 * 抵扣金额
	 */
	private BigDecimal deductibleAmount;
	
	/**
	 * 领取时间
	 */
	private Date receiveDate;

	/**
	 * 使用时间
	 */
	private Date useDate; 

	/**
	 * 交易商编码
	 */
	private String firmId;
	
	/**
	 * 交易商
	 */
	private String firmName;

	/**
	 * 交易员编码
	 */
	private String traderID;
	
	/**
	 * 用户名
	 */
	private String traderName;
	
	/**
	 * 使用订单号
	 */
	private String orderId;

	/**
	 * 状态(0：未领取 1:已发放(已领取) 5：已使用 10：已失效)
	 */
	private Integer status;
	// 优惠券有效起始时间
	private Date couponValidStartDate;
	// 优惠券有效结束时间
	private Date couponValidEndDate;
	// 用户名
//	private String userName;
	// 用户手机号
	private String userMobile;
	/**
	 * 抵扣金额
	 */
	private BigDecimal buyCouponTradeFee;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCouponNumber() {
		return couponNumber;
	}

	public void setCouponNumber(String couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getExchangeCode() {
		return exchangeCode;
	}

	public void setExchangeCode(String exchangeCode) {
		this.exchangeCode = exchangeCode;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public String getCouponName() {
		return couponName;
	}

	public void setCouponName(String couponName) {
		this.couponName = couponName;
	}

	public Integer getCouponType() {
		return couponType;
	}

	public void setCouponType(Integer couponType) {
		this.couponType = couponType;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getDeductibleAmount() {
		return deductibleAmount;
	}

	public void setDeductibleAmount(BigDecimal deductibleAmount) {
		this.deductibleAmount = deductibleAmount;
	}

	public Date getReceiveDate() {
		return receiveDate;
	}

	public void setReceiveDate(Date receiveDate) {
		this.receiveDate = receiveDate;
	}

	public Date getUseDate() {
		return useDate;
	}

	public void setUseDate(Date useDate) {
		this.useDate = useDate;
	}

	public String getFirmId() {
		return firmId;
	}

	public void setFirmId(String firmId) {
		this.firmId = firmId;
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}
	
	public String getTraderID() {
		return traderID;
	}

	public void setTraderID(String traderID) {
		this.traderID = traderID;
	}
	
	public String getTraderName() {
		return traderName;
	}

	public void setTraderName(String traderName) {
		this.traderName = traderName;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Date getCouponValidStartDate() {
		return couponValidStartDate;
	}

	public void setCouponValidStartDate(Date couponValidStartDate) {
		this.couponValidStartDate = couponValidStartDate;
	}

	public Date getCouponValidEndDate() {
		return couponValidEndDate;
	}

	public void setCouponValidEndDate(Date couponValidEndDate) {
		this.couponValidEndDate = couponValidEndDate;
	}

//	public String getUserName() {
//		return userName;
//	}
//
//	public void setUserName(String userName) {
//		this.userName = userName;
//	}

	public String getUserMobile() {
		return userMobile;
	}

	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}
	
	public BigDecimal getBuyCouponTradeFee() {
		return buyCouponTradeFee;
	}

	public void setBuyCouponTradeFee(BigDecimal buyCouponTradeFee) {
		this.buyCouponTradeFee = buyCouponTradeFee;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	
}
