package shcem.market.dao.model;

import java.math.BigDecimal;

/**
 * 订单保价列表导出
 * @author sunf
 *
 */
public class ExportOrderPolicy {

	public ExportOrderPolicy() {
		// TODO Auto-generated constructor stub
	}
	
	
	/**
	 * 交收ID
	 */
	private String deliveryID;
	/**
	 * 成交ID
	 */
	private String orderId;
	/**
	 * 交易商编码
	 */
	private String firmID;
	/**
	 * 交易商名称
	 */
	private String firmName;
	/**
	 * 保单类型
	 */
	private String typeName;
	/**
	 * 均差价
	 */
	private BigDecimal averageDeltaPrice;
	/**
	 * 实收数量
	 */
	private BigDecimal takenQuantity;
	/**
	 * 成交单价
	 */
	private BigDecimal price;
	/**
	 * 已付保额
	 */
	private BigDecimal paidAmount;
	/**
	 * 应退保金额
	 */
	private BigDecimal shouldBackAmount;
	/**
	 * 实退保金额
	 */
	private BigDecimal realBackAmount;
 
	
	/**
	 * 退保状态
	 * 0:未申请
	 * 5：已申请
	 * 10：已支付
	 */
	private String backStatus;


	public String getDeliveryID() {
		return deliveryID;
	}


	public void setDeliveryID(String deliveryID) {
		this.deliveryID = deliveryID;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public String getFirmID() {
		return firmID;
	}


	public void setFirmID(String firmID) {
		this.firmID = firmID;
	}


	public String getFirmName() {
		return firmName;
	}


	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}


	public String getTypeName() {
		return typeName;
	}


	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}


	public BigDecimal getAverageDeltaPrice() {
		return averageDeltaPrice;
	}


	public void setAverageDeltaPrice(BigDecimal averageDeltaPrice) {
		this.averageDeltaPrice = averageDeltaPrice;
	}


	public BigDecimal getTakenQuantity() {
		return takenQuantity;
	}


	public void setTakenQuantity(BigDecimal takenQuantity) {
		this.takenQuantity = takenQuantity;
	}


	public BigDecimal getPrice() {
		return price;
	}


	public void setPrice(BigDecimal price) {
		this.price = price;
	}


	public BigDecimal getPaidAmount() {
		return paidAmount;
	}


	public void setPaidAmount(BigDecimal paidAmount) {
		this.paidAmount = paidAmount;
	}


	public BigDecimal getShouldBackAmount() {
		return shouldBackAmount;
	}


	public void setShouldBackAmount(BigDecimal shouldBackAmount) {
		this.shouldBackAmount = shouldBackAmount;
	}


	public BigDecimal getRealBackAmount() {
		return realBackAmount;
	}


	public void setRealBackAmount(BigDecimal realBackAmount) {
		this.realBackAmount = realBackAmount;
	}


	public String getBackStatus() {
		return backStatus;
	}


	public void setBackStatus(String backStatus) {
		this.backStatus = backStatus;
	}
	
	

}
