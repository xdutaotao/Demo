package shcem.market.component;

import java.util.Date;
import java.util.List;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.market.dao.model.QueryGuizHistory;
import shcem.market.dao.model.QuizActivity;
import shcem.market.service.model.QuizHistoryVo;

public interface IQuizActivitiesComponentManager extends Manager{

	/**
	 * 竞猜历史记录查询
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	List<QueryGuizHistory> queryCouponTypeList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 执行开奖
	 * @return
	 */
	public Integer exeTheLottery(String exeDate);
	
	/**
	 * 执行开奖 至尊预言帝奖
	 * @return
	 */
	public Integer exeSupremacy(String exeDate);

	int addQuizActivities(String userName, List<QuizActivity> quizActivityList,String mode, String requestId);

	List<QuizActivity> getQuizActivitiesDetail(String quizDate);
	
	boolean getValidateQuizActivitiesList(String quizDate);

	List<QuizActivity> getQuizActivitiesList(QueryConditions qc,
			PageInfo pageInfo);

	int updateQuizActivitiesPrice(String userName,
			List<QuizActivity> quizActivityList);

	int deleteQuizActivitie(String[] quizDateArray);

	List<QuizActivity> getQuizActivitiesListByQuizDate(String[] quizDateArray);
	
	boolean existsQuizActivity(Date quizDate);
	
	
	/**
	 * 更新 竞猜活动合约价格表 的官方解读
	 * @param answer 官方解读
	 * @param modifyby 修改人
	 * @param quizDateStr 竞猜日期
	 * @param category 品类
	 * @return
	 */
	public int updateQuizActivityOfAnswer(String answer,String modifyby,String quizDateStr);
	
	
	/**
	 * 获取 竞猜活动合约价格表 的官方解读
	 * @param quizDateStr
	 * @param category
	 * @return
	 */
	public QuizActivity getQuizActivityOfAnswer(String quizDateStr);
	
	/**
	 * 创建竞猜记录
	 * @param qhvList
	 * @param quizDate
	 * @return
	 */
	public int createQuizHistory(List<QuizHistoryVo> qhvList,Date quizDate,String userName);
	
}
