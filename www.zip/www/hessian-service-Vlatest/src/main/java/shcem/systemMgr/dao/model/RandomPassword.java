package shcem.systemMgr.dao.model;

import java.io.Serializable;

import shcem.base.dao.model.BaseObject;

/**
 * 随机数据
 * @author zhangnan
 *
 */
public class RandomPassword extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	
	private String hammigCodes;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getHammigCodes() {
		return hammigCodes;
	}

	public void setHammigCodes(String hammigCodes) {
		this.hammigCodes = hammigCodes;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

}
