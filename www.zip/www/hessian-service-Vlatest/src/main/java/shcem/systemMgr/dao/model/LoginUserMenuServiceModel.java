package shcem.systemMgr.dao.model;

import java.io.Serializable;
import java.util.List;

import shcem.base.dao.model.BaseObject;

public class LoginUserMenuServiceModel extends BaseObject implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String text;//菜单名称
	
	private String heading;
	
	private String sref;//菜单Url
	
	private String icon; //菜单图标
	
	private List<LoginUserMenuServiceModel> submenu;//子集菜单

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getHeading() {
		return heading;
	}

	public void setHeading(String heading) {
		this.heading = heading;
	}

	public String getSref() {
		return sref;
	}

	public void setSref(String sref) {
		this.sref = sref;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public List<LoginUserMenuServiceModel> getSubmenu() {
		return submenu;
	}

	public void setSubmenu(List<LoginUserMenuServiceModel> submenu) {
		this.submenu = submenu;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}
