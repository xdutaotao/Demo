package shcem.systemMgr.dao.model;

import java.io.Serializable;

import shcem.base.dao.model.BaseObject;
/**
 * uaac 系统用户
 * @author zhangnan
 *
 */
public class UaacUser extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private Integer id;
	
	private Integer loginName;

	private Integer trueName;
	
	
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getLoginName() {
		return loginName;
	}

	public void setLoginName(Integer loginName) {
		this.loginName = loginName;
	}

	public Integer getTrueName() {
		return trueName;
	}

	public void setTrueName(Integer trueName) {
		this.trueName = trueName;
	}

	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
