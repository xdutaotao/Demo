package shcem.systemMgr.component;

import java.util.List;

import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.systemMgr.dao.ISystemMgrDAO;
import shcem.systemMgr.dao.model.LoginUserMenu;
import shcem.systemMgr.dao.model.MRole;
import shcem.systemMgr.dao.model.MUser;
import shcem.systemMgr.dao.model.Right;
import shcem.systemMgr.dao.model.UserPasswordReset;

public interface ISystemMgrManager {
	public abstract void setiSystemMgrDAO(ISystemMgrDAO iSystemMgrDAO);

	public abstract List<MUser> getMgrUserList(QueryConditions qc,PageInfo pageInfo);

	public abstract String addMgrUser(MUser user);

	public abstract String updMgrUserPsd(MUser user);

	public abstract int delMgrUser(int[] userIds);

	public abstract List<Right> getMgrUserAuths(int userId);

	public abstract List<Right> getAllAuth();

	public abstract String updMgrUserAuths(int userID, int[] userAuths);

	public abstract List<MRole> getRoleList(QueryConditions qc,
			PageInfo pageInfo);

	public abstract void addMgrRole(MRole role);

	public abstract void delMgrRole(int[] roleIds);

	public abstract void addUserForRole(int roleID, int[] userIDs);

	public abstract List<MUser> getUserByRole(QueryConditions qc, PageInfo pageInfo);

	public abstract void delUserForRole(int roleID, int[] userIDs);

	public abstract List<MUser> getUserListWithoutRole(int roleID, PageInfo pageInfo, QueryConditions qc);

	public abstract List<Right> getMgrRoleAuths(int roleID);

	public abstract void addAuthsForRole(int roleID, int[] roleAuths);

	public abstract void updMgrUser(MUser user);

	public abstract List<LoginUserMenu> getLoginUserAuths(String userID);

	public abstract MUser checkPassword(String userID);

	public abstract boolean checkUserID(String userID);

	public abstract MUser getMUserByLoginName(String userID);

	public abstract void enableUser(int[] Right);
	
	/**
	 * 更新菜单 Id有时更新，没时添加
	 * @param right
	 * @return 
	 */
	public abstract void changeRight(Right right);
	
	/**
	 * 根据角色ID查询当前角色下的按钮列表
	 * @param roleID
	 * @return
	 */
	public abstract List<Right> selectRightButtonListByRoleId(int roleID);
	
	/**
	 * 查询权限列表
	 * @param roleID
	 * @return
	 */
	List<Right> selectAllRightList();
	
	/**
	 * 查询权限列表
	 * @param roleID
	 * @return
	 */
	Right selectRightById(Integer id);
	
	/**
	 * 根据 roleCode  查询 用户列表
	 */
	public List<MUser> selectMUserListByRoleCode(String roleCode);
	
	/**
	 * 根据用户ID 获取角色列表
	 * @param userId 用户ID
	 * @return
	 */
	List<MRole> getRoleListByUserId(String userId);

	/**
	 * 后台重置前台客户密码
	 * @param userName 后台操作人员
	 * @return
	 */
	public abstract int resetPassword(UserPasswordReset user, String userName);

	/**
	 * 前台用户
	 * @param userCode
	 * @return
	 */
	public abstract MUser getCUserByID(String userCode);
}
