package shcem.systemMgr.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.BusinessEnumConstants;
import shcem.constant.BusinessEnumConstants.RoleType;
import shcem.constant.Constants;
import shcem.finance.util.JSONArrayUtil;
import shcem.systemMgr.component.ISystemMgrManager;
import shcem.systemMgr.dao.model.LoginUserMenu;
import shcem.systemMgr.dao.model.MRole;
import shcem.systemMgr.dao.model.MUser;
import shcem.systemMgr.dao.model.RandomPassword;
import shcem.systemMgr.dao.model.Right;
import shcem.systemMgr.dao.model.UserPasswordReset;
import shcem.systemMgr.service.ISystemMgrService;
import shcem.systemMgr.service.model.RoleTypeDto;
import shcem.systemMgr.util.GenerateRandomUtil;
import shcem.systemMgr.util.SystemMgrSysData;
import shcem.util.EncrypMD5;
import shcem.util.JsonUtil;

public class SystemMgrServiceImpl extends BaseServiceImpl implements ISystemMgrService {
	private ISystemMgrManager mgr = (ISystemMgrManager) SystemMgrSysData.getBean(Constants.BEAN_SYSTEMMGR_MGR);

	@Override
	public String getMgrUserList(String param) {
		this.log.info(this.getClass().getName() + " getMgrUserList() Start");
		this.log.debug("JSONParams=" + param);
		List<MUser> list = null;
		boolean bolRst = false;
		//表头查询条件
		JSONObject JSONParams = new JSONObject(param);
		List<Condition> conditionsList = new ArrayList<Condition>();
		conditionsList.add(new Condition("mu.UserID", "like", "", "string","userID"));
		conditionsList.add(new Condition("mu.Status", "like", "", "string","status"));
	
		String userID = this.getUserId();
		System.out.println(userID);
		
		JSONObject queryModel =JSONParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionsList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JSONParams);
		try {
			list = this.mgr.getMgrUserList(qc,pageInfo);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询用户列表出错" + e.getMessage());
			setResultData("00000", null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("用户列表转换失败：" + e.getMessage());
				setResultData("10106", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getMgrUserList() End");
		return rtnData.toString();
	}

	@Override
	public String addMgrUser(String param) {
		this.log.info(this.getClass().getName() + " addMgrUser() Start");
		this.log.debug("addFirm Service Start debug");
		JSONObject JOParams = new JSONObject(param);
		this.log.debug(param);
		MUser user = (MUser) JsonUtil.jsonToBean(JOParams, MUser.class);
		user.setRecCreateBy("");
		user.setRecModifyBy("");
		user.setStatus(1);
		String result;
		try {
			result = this.mgr.addMgrUser(user);
			this.log.businesslog("新增系统用户  "+user.getName()+" 成功",Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_SUCCESS);
			setResultData("00000", null);
		} catch (Exception e) {
			this.log.error("新增系统用户  "+user.getName()+" 出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("新增系统用户 "+user.getName()+" 失败"+e.getMessage(),Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " addMgrUser() End");
		return rtnData.toString();
	}

	@Override
	public String updMgrUserPsd(String param) {
		this.log.info(this.getClass().getName() + " updMgrUserPsd() Start");
		this.log.debug("addFirm Service Start debug");
		JSONObject JOParams = new JSONObject(param);
		this.log.debug(param);
		MUser user = (MUser) JsonUtil.jsonToBean(JOParams, MUser.class);
		user.setRecModifyBy("");
		String result;
		try {
			result = this.mgr.updMgrUserPsd(user);
			this.log.businesslog("更新编码为 "+user.getId()+" 的系统用户密码成功",Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_SUCCESS);
			setResultData("00000", null);
		} catch (Exception e) {
			this.log.error("更新编码为 "+user.getId()+" 的系统用户密码出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("更新编码为 "+user.getId()+" 的系统用户密码出错"+e.getMessage(),Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " updMgrUserPsd() End");
		return rtnData.toString();
	}

	@Override
	public String delMgrUser(String param) {
		this.log.info(this.getClass().getName() + " delMgrUser() Start");
		JSONObject JOParams = new JSONObject(param);
		// 提交的凭证号数组
		JSONArray userIdsTemp = JOParams.getJSONArray("userIds");
		int[] userIds = JSONArrayUtil.getJsonToIntArray(userIdsTemp);
		try {
			int returnCode = this.mgr.delMgrUser(userIds);
			if(returnCode >= 0 ){
				this.log.businesslog("删除编码为  "+userIds+" 的系统用户成功",Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_SUCCESS);
				setResultData("00000", null);
			}else {
				this.log.businesslog("删除编码为  "+userIds+" 的系统用户失败",Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_FAIL);
				setResultData("10106", null);
			}
			
		} catch (Exception e) {
			this.log.error("删除编码为  "+userIds+" 的系统用户出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("删除编码为  "+userIds+" 的系统用户出错"+e.getMessage(),Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " delMgrUser() End");
		return rtnData.toString();
	}

	@Override
	public String enableUser(String param) {
		this.log.info(this.getClass().getName() + " enableUser() Start");
		JSONObject JOParams = new JSONObject(param);
		// 提交的凭证号数组
		JSONArray userIdsTemp = JOParams.getJSONArray("userIds");
		int[] userIds = JSONArrayUtil.getJsonToIntArray(userIdsTemp);
		try {
			this.mgr.enableUser(userIds);
			this.log.businesslog("启用编码为  "+userIds+" 的系统用户成功",Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_SUCCESS);
			setResultData("00000", null);
		} catch (Exception e) {
			this.log.error("启用编码为  "+userIds+" 的系统用户出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("启用编码为  "+userIds+" 的系统用户出错"+e.getMessage(),Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " enableUser() End");
		return rtnData.toString();
	}
	@Override
	public String getMgrUserAuths(String param) {
		this.log.info(this.getClass().getName() + " getMgrUserAuths() Start");
		this.log.debug("JSONParams=" + param);
		List<Right> userAuthsList = null;
		boolean bolRst = false;
		//查询条件
		JSONObject JSONParams = new JSONObject(param);
		int userId = JSONParams.getInt("userID");
		try {
			userAuthsList = this.mgr.getMgrUserAuths(userId);
			setResultData("00000",userAuthsList);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("用户权限查询出错"+e.getMessage());
			setResultData("10106", null, e.getMessage());
		}
		if (bolRst) {
			JSONObject jsonObj = new JSONObject();
			try {
//				retData = JsonUtil.coverModelToJSONArray(roleAuthsList);
				
				if (userAuthsList != null && userAuthsList.size() > 0 ) {
					int[] userAuthArray = new int[userAuthsList.size()];
					for (int i = 0; i < userAuthsList.size(); i++) {
						userAuthArray[i] = userAuthsList.get(i).getId();
					}
					jsonObj.put("result", userAuthArray);
					setResultData("00000", jsonObj);
				}else {
					jsonObj.put("result", new int[0]);
					setResultData("00000", jsonObj);
				}
				
			} catch (Exception e) {
				this.log.error("角色列表转换失败：" + e.getMessage());
				setResultData("10106", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getMgrUserAuths() End");
		return rtnData.toString();
	}

	@Override
	public String updMgrUserAuths(String param) {
		this.log.info(this.getClass().getName() + " updMgrUserAuths() Start");
		this.log.debug("addFirm Service Start debug");
		JSONObject JOParams = new JSONObject(param);
		this.log.debug(param);
		int userID = JOParams.getInt("userID");
		JSONArray userAuthsTemp = JOParams.getJSONArray("userAuths");
		int[] userAuths = JSONArrayUtil.getJsonToIntArray(userAuthsTemp);
		try {
			this.mgr.updMgrUserAuths(userID,userAuths);
			this.log.businesslog("设置编码为 "+userID+" 的用户权限成功",Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_SUCCESS);
			setResultData("00000", null);
		} catch (Exception e) {
			this.log.error("设置编码为 "+userID+" 的用户权限出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("设置编码为 "+userID+" 的用户权限出错"+e.getMessage(),Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + "updMgrUserAuths() End");
		return rtnData.toString();
	}

	@Override
	public String getRoleList(String param) {
		this.log.info(this.getClass().getName() + " getMgrUserList() Start");
		this.log.debug("JSONParams=" + param);
		List<MRole> list = null;
		boolean bolRst = false;
		//表头查询条件
		JSONObject JSONParams = new JSONObject(param);
		List<Condition> conditionsList = new ArrayList<Condition>();
		conditionsList.add(new Condition("mr.id", "like", "", "string","roleID"));
		conditionsList.add(new Condition("mr.name", "like", "", "string","roleName"));
		
		JSONObject queryModel =JSONParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionsList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JSONParams);
		try {
			list = this.mgr.getRoleList(qc,pageInfo);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("角色列表出错" + e.getMessage());
			setResultData("00000", null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("角色列表转换失败：" + e.getMessage());
				setResultData("10106", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getMgrUserList() End");
		return rtnData.toString();
	}

	@Override
	public String addMgrRole(String param) {
		this.log.info(this.getClass().getName() + " addMgrUser() Start");
		this.log.debug("addFirm Service Start debug");
		JSONObject JOParams = new JSONObject(param);
		this.log.debug(param);
		MRole role = (MRole) JsonUtil.jsonToBean(JOParams, MRole.class);
		try {
			this.mgr.addMgrRole(role);
			this.log.businesslog("新增系统角色 "+role.getName()+" 成功",Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_SUCCESS);
			setResultData("00000", null);
		} catch (Exception e) {
			this.log.error("新增系统角色 "+role.getName()+" 出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("新增系统角色 "+role.getName()+" 成功"+e.getMessage(),Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " addMgrUser() End");
		return rtnData.toString();
	}

	@Override
	public String delMgrRole(String param) {
		this.log.info(this.getClass().getName() + " delMgrUser() Start");
		JSONObject JOParams = new JSONObject(param);
		// 提交的凭证号数组
		JSONArray roleIdsTemp = JOParams.getJSONArray("roleIDs");
		int[] roleIds = JSONArrayUtil.getJsonToIntArray(roleIdsTemp);
		try {
			this.mgr.delMgrRole(roleIds);
			this.log.businesslog("删除编号为 "+roleIds+" 的角色成功",Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_SUCCESS);
			setResultData("00000", null);
		} catch (Exception e) {
			this.log.error("删除编号为 "+roleIds+" 的角色出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("删除编号为 "+roleIds+" 的角色出错"+e.getMessage(),Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " delMgrUser() End");
		return rtnData.toString();
	}

	/**
	 * 为某一个角色添加用户
	 */
	@Override
	public String addUserForRole(String param) {
		this.log.info(this.getClass().getName() + " addUserForRole() Start");
		JSONObject JOParams = new JSONObject(param);
		// 提交的凭证号数组
		JSONArray userIDsTemp = JOParams.getJSONArray("userIDs");
		int[] userIDs = JSONArrayUtil.getJsonToIntArray(userIDsTemp);
		int roleID = JOParams.getInt("roleID");
		try {
			this.mgr.addUserForRole(roleID,userIDs);
			this.log.businesslog("为编号为 "+roleID+"的角色添加编码为 "+userIDs+" 的用户成功",Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_SUCCESS);
			setResultData("00000", null);
			
		} catch (Exception e) {
			this.log.error("为编号为 "+roleID+"的角色添加编码为 "+userIDs+" 的用户出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("为编号为 "+roleID+"的角色添加编码为 "+userIDs+" 的用户出错"+e.getMessage(),Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " addUserForRole() End");
		return rtnData.toString();
	}

	/**
	 * 查看用户权限
	 */
	@Override
	public String getMgrRoleAuths(String param) {
		this.log.info(this.getClass().getName() + " getMgrUserAuths() Start");
		this.log.debug("JSONParams=" + param);
		List<Right> roleAuthsList = null;
		boolean bolRst = false;
		//查询条件
		JSONObject JSONParams = new JSONObject(param);
		int roleID = JSONParams.getInt("roleID");
		try {
			roleAuthsList = this.mgr.getMgrRoleAuths(roleID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("角色权限查询出错"+e.getMessage());
			setResultData("10106", null, e.getMessage());
		}
		if (bolRst) {
			JSONObject jsonObj = new JSONObject();
			try {
//				retData = JsonUtil.coverModelToJSONArray(roleAuthsList);
				
				if (roleAuthsList != null && roleAuthsList.size() > 0 ) {
					int[] roleAuthArray = new int[roleAuthsList.size()];
					for (int i = 0; i < roleAuthsList.size(); i++) {
						roleAuthArray[i] = roleAuthsList.get(i).getId();
					}
					jsonObj.put("result", roleAuthArray);
					setResultData("00000", jsonObj);
				}else {
					jsonObj.put("result", new int[0]);
					setResultData("00000", jsonObj);
				}
				
			} catch (Exception e) {
				this.log.error("角色列表转换失败：" + e.getMessage());
				setResultData("10106", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getMgrUserAuths() End");
		return rtnData.toString();
	}

	@Override
	public String addAuthsForRole(String param) {
		this.log.info(this.getClass().getName() + " updMgrUserAuths() Start");
		this.log.debug("addFirm Service Start debug");
		JSONObject JOParams = new JSONObject(param);
		this.log.debug(param);
		int roleID = JOParams.getInt("roleID");
		JSONArray roleAuthsTemp = JOParams.getJSONArray("roleAuths");
		int[] roleAuths = JSONArrayUtil.getJsonToIntArray(roleAuthsTemp);
		try {
			this.mgr.addAuthsForRole(roleID,roleAuths);
			this.log.businesslog("为编号为"+roleID+" 的角色设置权限成功",Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_SUCCESS);
			setResultData("00000", null);
		} catch (Exception e) {
			this.log.error("为编号为"+roleID+" 的角色设置权限出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("为编号为"+roleID+" 的角色设置权限出错"+e.getMessage(),Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + "updMgrUserAuths() End");
		return rtnData.toString();
	}

	@Override
	public String getAllAuth(String param) {
		this.log.info(this.getClass().getName() + " getAllAuth() Start");
		this.log.debug("JSONParams=" + param);
		List<Right> allAuthList = null;
		boolean bolRst = false;
		//查询条件
		JSONObject JSONParams = new JSONObject(param);
		try {
			allAuthList = this.mgr.getAllAuth();
			bolRst = true;
		} catch (Exception e) {
			this.log.error("菜单查询出错"+e.getMessage());
			setResultData("10106", null, e.getMessage());
		}
		if (bolRst) {
			try {
				if (allAuthList != null && allAuthList.size() > 0) {
					JSONObject menuTree = createMenuTree(allAuthList, null);
					setResultData("00000", menuTree);
				}else {
					setResultData("00000", null);	
				}
			} catch (Exception e) {
				this.log.error("菜单转换失败：" + e.getMessage());
				setResultData("10104", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getAllAuth() End");
		return rtnData.toString();
	}


	
	@Override
	public String getUserByRole(String param) {
		this.log.info(this.getClass().getName() + " getMgrUserList() Start");
		this.log.debug("JSONParams=" + param);
		List<MUser> list = null;
		boolean bolRst = false;
		//表头查询条件
		JSONObject JSONParams = new JSONObject(param);
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JSONParams);
		
		List<Condition> conditionsList = new ArrayList<Condition>();
		conditionsList.add(new Condition("mr.id", "=", "", "string","roleID"));
		
		JSONObject queryModel =JSONParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionsList, "");
		this.log.debug("qc=" + qc.toString());
		
		try {
			list = this.mgr.getUserByRole(qc,pageInfo);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询角色的用户列表出错" + e.getMessage());
			setResultData("00000", null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("角色的用户列表转换失败：" + e.getMessage());
				setResultData("10106", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getMgrUserList() End");
		return rtnData.toString();
	}

	@Override
	public String delUserForRole(String param) {
		this.log.info(this.getClass().getName() + " delUserForRole() Start");
		JSONObject JOParams = new JSONObject(param);
		// 提交的凭证号数组
		JSONArray userIDsTemp = JOParams.getJSONArray("userIDs");
		int[] userIDs = JSONArrayUtil.getJsonToIntArray(userIDsTemp);
		int roleID = JOParams.getInt("roleID");
		try {
			this.mgr.delUserForRole(roleID,userIDs);
			this.log.businesslog("为编号为 "+roleID+" 的角色删除编号为"+userIDs+" 的用户成功",Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_SUCCESS);
			setResultData("00000", null);
			
		} catch (Exception e) {
			this.log.error("为编号为 "+roleID+" 的角色删除编号为"+userIDs+" 的用户出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("为编号为 "+roleID+" 的角色删除编号为"+userIDs+" 的用户出错"+e.getMessage(),Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " delUserForRole() End");
		return rtnData.toString();
	}

	@Override
	public String getUserListWithoutRole(String param) {
		this.log.info(this.getClass().getName() + " getMgrUserList() Start");
		this.log.debug("JSONParams=" + param);
		List<MUser> list = null;
		boolean bolRst = false;
		//表头查询条件
		JSONObject JSONParams = new JSONObject(param);
		List<Condition> conditionsList = new ArrayList<Condition>();
		
//		conditionsList.add(new Condition("mu.Name", "like", "", "String","userCode"));
//		conditionsList.add(new Condition(" OR++OR mu.UserID", "like", "", "String","userCode"));
		
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JSONParams);
		int roleID = JSONParams.getInt("roleID");
		
		JSONObject queryModel =JSONParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionsList, "");
		if(queryModel != null){
			String userCode = queryModel.optString("userCode");
			if (userCode != null && !"".equals(userCode)) {
				qc.addCondition("(mu.Name like '%" + userCode + "%' or mu.UserID like '%" + userCode
						+ "%') and '1'=", " ", 1);
			}
		}
		try {
			list = this.mgr.getUserListWithoutRole(roleID,pageInfo,qc);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询角色的用户列表出错" + e.getMessage());
			setResultData("00000", null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("角色的用户列表转换失败：" + e.getMessage());
				setResultData("10106", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getMgrUserList() End");
		return rtnData.toString();
	}

	@Override
	public String updMgrUser(String param) {
		this.log.info(this.getClass().getName() + " updMgrUserPsd() Start");
		this.log.debug("updMgrUser Service Start debug");
		JSONObject JOParams = new JSONObject(param);
		this.log.debug(param);
		MUser user = (MUser) JsonUtil.jsonToBean(JOParams, MUser.class);
		user.setRecModifyBy("");
		try {
			this.mgr.updMgrUser(user);
			this.log.businesslog("更新系统用户"+user.getName()+"成功",Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_SUCCESS);
			setResultData("00000", null);
		} catch (Exception e) {
			this.log.error("更新系统用户"+user.getName()+"出错" + e.getMessage());
			setResultData("10106", null, e.getMessage());
			this.log.businesslog("更新系统用户"+user.getName()+"出错"+e.getMessage(),Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_FAIL);
		}
		this.log.info(this.getClass().getName() + " updMgrUserPsd() End");
		return rtnData.toString();
	}

	/**
	 * 获取登录用户权限菜单
	 */
	@Override
	public String getLoginUserAuths(String param) {
		this.log.info(this.getClass().getName() + " getMenuListByRole() Start");
		this.log.debug("getMenuListByRole Service Start debug");
		JSONObject JOParams = new JSONObject(param);
		this.log.debug(param);
		String userID = JOParams.getString("userID");
		boolean bolRst = false;
		List<LoginUserMenu> loginUserAuths = new ArrayList<LoginUserMenu>();
		try {
			loginUserAuths = this.mgr.getLoginUserAuths(userID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("获取权限失败"+e.getMessage());
			setResultData("10106", null,e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(loginUserAuths);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("用户列表转换失败：" + e.getMessage());
				setResultData("10106", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getLoginUserAuths() End");
		return rtnData.toString();
	}
	
	@Override
	public String loginCheck(String param) {
		this.log.info(this.getClass().getName() + " loginCheck() Start");
		JSONObject JOParams = new JSONObject(param);
		this.log.debug(param);
		String userID = JOParams.getString("userID");
		
		String password = JOParams.getString("password");
		try {
			MUser user = this.mgr.checkPassword(userID);
			if (user != null) {
				if (EncrypMD5.eccrypt(password).equals(user.getPassword())) {
					user.setPassword("");
					setResultData("10108",user);
				}else {
					setResultData("10109",null);
				}
			}else {
				setResultData("10113",null);
			}
			
		} catch (Exception e) {
			this.log.error("登录出错"+e.getMessage());
			setResultData("10112",null);
		}
		this.log.info(this.getClass().getName() + " loginCheck() End");
		return rtnData.toString();
	}
	
	@Override
	public String checkUserID(String param) {
		this.log.info(this.getClass().getName() + " checkUserID() Start");
		JSONObject JOParams = new JSONObject(param);
		this.log.debug(param);
		String userID = JOParams.getString("userID");
		
		boolean flag;
		try {
			flag = this.mgr.checkUserID(userID);
			if (flag) {
				setResultData("10110", null);
			}else {
				setResultData("10111", null);
			}
		} catch (Exception e) {
			this.log.error("校验用户编码出错"+e.getMessage());
			setResultData("10112", null);
		}
		return rtnData.toString();
	}

	private JSONObject createMenuTree(List<Right> userAuthsList, String inputId) {

		// 节点列表（散列表，用于临时存储节点对象）
		HashMap<String, JSONArray> parentList = new HashMap<String, JSONArray>();
		int rootId = 0;
		if (inputId != null && !"".equals(inputId)) {
			rootId = Integer.parseInt(inputId);
		}
		
		JSONObject rootModel = new JSONObject();
		rootModel.put("label", "资源权限");
		rootModel.put("data",(new JSONObject().put("id", rootId)));

		// 根据结果集构造节点列表（存入散列表）
		JSONObject rightModel;
		JSONArray parentModelList;
		for (Right right : userAuthsList) {
			rightModel = new JSONObject();
			rightModel.put("label", right.getTreeName());
			rightModel.put("data",(new JSONObject().put("id",right.getId())));

			parentModelList = (JSONArray) parentList.get(String.valueOf(right.getParentID()));
			if (parentModelList == null) {
				parentModelList = new JSONArray();
			}
			parentModelList.put(rightModel);
			parentList.put(String.valueOf(right.getParentID()), parentModelList);
		}

		JSONObject root = setModel(rootModel, parentList);

		return root;
	}
	
	
	private JSONObject setModel(JSONObject model, HashMap<String, JSONArray> parentList) {
		JSONObject data = (JSONObject) model.get("data");
		int id = data.getInt("id");
		JSONArray child = parentList.get(Integer.toString(id));

		if (child != null) {
			model.put("children", child);

			JSONObject node;
			for (int i = 0; i < child.length(); i++) {
				node = (JSONObject) child.get(i);
				setModel(node, parentList);
			}
		}
		return model;
	}

	/**
	 * 变更菜单项
	 */
	@Override
	public String changeMenuItem(String param) {
		this.log.info(this.getClass().getName() + " changeMenuItem() Start");
		JSONObject JOParams = new JSONObject(param);
		JSONObject queryModel =JOParams.optJSONObject("queryModel");
		this.log.debug(param);
		Right right = (Right) JsonUtil.jsonToBean(queryModel, Right.class);
		try {
			this.mgr.changeRight(right);
			setResultData("00000", null);
		} catch (Exception e) {
			setResultData("10106", null, e.getMessage());
		}
		this.log.info(this.getClass().getName() + " changeMenuItem() End");
		return rtnData.toString();
	
	}
	
	/**
	 * 根据角色ID获取按钮列表
	 */
	@Override
	public String getRoleMenuButtonListByRoleId(String param) {
		this.log.info(this.getClass().getName() + " getRoleMenuButtonListByRoleId() Start");
		this.log.debug(param);
		JSONObject JSONParams = new JSONObject(param);		
		JSONObject queryModel =JSONParams.optJSONObject("queryModel");
		String roleId = queryModel.getString("roleId");
		List<Right> resultList = new ArrayList<Right>();
		boolean bolRst = false;
		try {
			resultList = this.mgr.selectRightButtonListByRoleId(Integer.parseInt(roleId));
			bolRst = true;
			setResultData("00000", null);
		} catch (Exception e) {
			this.log.error("查询角色下单按钮列表出错，角色ID："+ roleId);
			setResultData("10106", null, e.getMessage());
		}
		
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(resultList);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("角色按钮列表转换失败：" + e.getMessage());
				setResultData("10106", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getRoleMenuButtonListByRoleId() End");
		return rtnData.toString();
	}

	/**获取所有资源列表
	 * @param param
	 * @return
	 */
	@Override
	public String getAllRightList(String param) {
		this.log.info(this.getClass().getName() + " getAllRightList() Start");
		this.log.debug(param);
		List<Right> resultList = new ArrayList<Right>();
		boolean bolRst = false;
		try {
			resultList = this.mgr.selectAllRightList();
			bolRst = true;
			setResultData("00000", null);
		} catch (Exception e) {
			setResultData("10106", null, e.getMessage());
		}
		
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(resultList);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				setResultData("10106", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getAllRightList() End");
		return rtnData.toString();
	}

	@Override
	public String getRightById(String param) {
		this.log.info(this.getClass().getName() + " getRightById() Start");
		this.log.debug(param);
		JSONObject JSONParams = new JSONObject(param);		
		Integer id = JSONParams.getInt("id");
		boolean bolRst = false;
		Right right = null;
		try {
			right = this.mgr.selectRightById(id);
			bolRst = true;
			setResultData("00000", null);
		} catch (Exception e) {
			setResultData("10105", null, e.getMessage());
		}
		
		if (bolRst) {
			JSONObject retData;
			try {
				retData = JsonUtil.coverModelToJSONObject(right);
				setResultData("00000", retData);
			} catch (Exception e) {
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getRightById() End");
		return rtnData.toString();
	}
	
	@Override
	public String getCustomerServiceList(String params) {
		this.log.info(this.getClass().getName() + " getCustomerServiceList() Start");
		this.log.debug(params);
		List<MUser> resultList = new ArrayList<MUser>();
		boolean bolRst = false;
		try {
			resultList = this.mgr.selectMUserListByRoleCode(BusinessEnumConstants.RoleType.CSRoleCode.getValue());// 设置客服角色
			bolRst = true;
			setResultData("00000", null);
		} catch (Exception e) {
			setResultData("10105", null, e.getMessage());
		}
		
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(resultList);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getCustomerServiceList() End");
		return rtnData.toString();
	}

	@Override
	public String getRoleTypeList(String params) {
		this.log.info(this.getClass().getName() + " getRoleTypeList() Start");
		this.log.debug(params);
		List<RoleTypeDto> resultList = new ArrayList<RoleTypeDto>(); 
		try {
			RoleType[] roleType = BusinessEnumConstants.RoleType.values();
			RoleTypeDto dto = null;
			for (RoleType temp : roleType){
				dto = new RoleTypeDto();
				dto.setName(temp.getName());
				dto.setValue(temp.getValue());
				resultList.add(dto);
			}
			JSONObject jsonObj = new JSONObject();
			JSONArray retData = JsonUtil.coverModelToJSONArray(resultList);
			jsonObj.put("result", retData);
			setResultData("00000", jsonObj);
		} catch (Exception e) {
			setResultData("10105", null, e.getMessage());
		}
		this.log.info(this.getClass().getName() + " getRoleTypeList() End");
		return rtnData.toString();
	}
	
	@Override
	public String generateRandom(String params) {
		this.log.info(this.getClass().getName() + " generateRandom() Start");
		this.log.debug(params);
		JSONObject JSONParams = new JSONObject(params);
		int figures = JSONParams.getInt("figures");
		boolean bolRst = false;
		RandomPassword randompad = new RandomPassword();
		try {
			String password = GenerateRandomUtil.generateRandom(figures);
			randompad.setHammigCodes(password);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("获取随机密码出错："+e.getMessage());
			setResultData("10119",00000);
		}
		this.log.info(this.getClass().getName() + " resetPassword() End");
		if (bolRst) {
			JSONObject retData;			
			try {
				retData = JsonUtil.coverModelToJSONObject(randompad);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error("随机密码数据转换失败：" + e.getMessage());
				setResultData("10119", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " generateRandom() End");
		return rtnData.toString();
	}
	
	@Override
	public String getCUserByID(String params) {
		this.log.info(this.getClass().getName() + " resetPassword() Start");
		this.log.debug(params);
		JSONObject JSONParams = new JSONObject(params);
		String userCode  = JSONParams.getString("userCode");
		MUser user = new MUser();
		boolean bolRst = false;
		try {
			user = this.mgr.getCUserByID(userCode);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("前台用户数据查询失败："+e.getMessage());
			setResultData("10101",null);
		}
		this.log.info(this.getClass().getName() + " resetPassword() End");
		if (bolRst) {
			JSONObject retData;			
			try {
				retData = JsonUtil.coverModelToJSONObject(user);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error("前台用户数据转换失败：" + e.getMessage());
				setResultData("10101", null, e.getMessage());
			}
		}
		return rtnData.toString();
	}
	
	@Override
	public String resetPassword(String params) {
		this.log.info(this.getClass().getName() + " resetPassword() Start");
		this.log.debug(params);
		JSONObject JSONParams = new JSONObject(params);
		String userName = this.getUserId() == null ? "system" : (this.getUserId() == "") ? "system" : this.getUserId();
		UserPasswordReset user = (UserPasswordReset) JsonUtil.jsonToBean(JSONParams, UserPasswordReset.class);
		int returnCode;
		try {
			returnCode = this.mgr.resetPassword(user,userName);
			if(returnCode >= 0){
				this.log.businesslog("重置前台用户密码成功",Constants.OPE_MODE_SYSTEMMGR,Constants.OPE_SUCCESS);
				setResultData("00000",null);
			}else {
				setResultData("10118",null);
			}
		} catch (Exception e) {
			this.log.error("后台重置前台用户密码失败,用户姓名："+user.getUserName()+""+e.getMessage());
			setResultData("10118",00000);
		}
		this.log.info(this.getClass().getName() + " resetPassword() End");
		return rtnData.toString();
	}
}
