package shcem.systemMgr.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.CannotGetJdbcConnectionException;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.member.service.model.userMobileModel;
import shcem.systemMgr.dao.ISystemMgrDAO;
import shcem.systemMgr.dao.model.LoginUserMenu;
import shcem.systemMgr.dao.model.MRole;
import shcem.systemMgr.dao.model.MUser;
import shcem.systemMgr.dao.model.Right;
import shcem.systemMgr.dao.model.UaacUser;
import shcem.systemMgr.dao.model.UserPasswordReset;
import shcem.util.CommonRowMapper;

public class SystemMgrDAOImpl extends BaseDAOImpl implements ISystemMgrDAO{

	@Override
	public List<MUser> getMgrUserList(QueryConditions qc, PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_001");
		String sql_temp = this.sqlProperty.getProperty("SystemMgrDAO_020");
		List<MUser> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new MUser()));
		if (list != null && list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				String roleName="";
				Object[] param = {
						list.get(i).getId()
				};
				
				List<MUser> tempList = this.queryBySQL(sql_temp, param, null, new CommonRowMapper(new MUser()));
				if (tempList != null && tempList.size() > 0) {
					for (int j = 0; j < tempList.size(); j++) {
						if (tempList.get(j).getRoleName() != null) {
							if(j>0) roleName +=",";
							roleName +=tempList.get(j).getRoleName();
						}
						
					}
				}
				list.get(i).setRoleName(roleName);
			}
		}
		return list;
	}

	@Override
	public void addMgrUser(MUser user) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_002");
		Object[] params = {
				user.getUserID(),user.getName(),user.getPassword(),user.getDescription(),user.getStatus(),
			user.getRecCreateBy(),user.getRecModifyBy()
		};
		this.updateBySQL(sql, params);
	}

	@Override
	public void updMgrUserPsd(MUser user) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_003");
		Object[] params = {
				user.getPassword(),user.getRecModifyBy(),user.getId()
		};
		this.updateBySQL(sql, params);
	}

	@Override
	public int delMgrUser(String userIds, int userStatus) {
		String sql = "update M_User SET   Status ="+userStatus+"  where id in "+"("+userIds+")";
		int returnCode;
		try {
			returnCode = getJdbcTemplate().update(sql);
		} catch (Exception e) {
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public int deMUserRole(String userIds) {
		String sql = "delete from  M_User_Role  where UserID in "+"("+userIds+")";
		int returnCode;
		try {
			returnCode = getJdbcTemplate().update(sql);
		} catch (Exception e) {
			returnCode = -1;
		}
		return returnCode;
	}

	/**
	 * @param userCName 前台用户
	 * @param userMobile 用户电话
	 * @param userName 后台操作人员
	 */
	@Override
	public int addUserPasswordReset(UserPasswordReset user,
			String userName) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_035");
		Object [] params = {
				user.getUserCode(),
				userName,
				user.getRemark()==null?"":user.getRemark()
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public List<Right> getMgrUserAuths(int userId) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_005");
		Object [] param = {
				userId
		};
		List<Right> list = this.queryBySQL(sql, param, null, null, new CommonRowMapper(new Right()));
		return list;
	}

	@Override
	public List<Right> getAllAuth() {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_007");
		return this.queryBySQL(sql, null, null, null, new CommonRowMapper(new Right()));
	}

	@Override
	public void delUserRight(int userID) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_008");
		Object[] params = {
				userID
		};
		this.updateBySQL(sql, params);
	}

	@Override
	public void addUserRight(int userID, int rightID) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_009");
		Object[] params = {
				userID,rightID
		};
		this.updateBySQL(sql, params);
	}

	@Override
	public List<MRole> getRoleList(QueryConditions qc, PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_010");
		List<MRole> list = null;
		try {
			list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new MRole()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public void addMgrRole(MRole role) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_011");
		Object[] params = {
				role.getName(),role.getDescription(),role.getRoleCode()
		};
		this.updateBySQL(sql, params);
	}

	@Override
	public void delMgrRole(int[] roleIds) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_012");
		if (roleIds != null && roleIds.length > 0) {
			for (int i = 0; i < roleIds.length; i++) {
				Object[] param = {roleIds[i]};
				this.updateBySQL(sql, param);
			}
		}
		
	}

	@Override
	public void addUserForRole(int roleID, int[] userIDs) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_013");
		if (userIDs != null && userIDs.length > 0) {
			for(int userID:userIDs){
				Object[] param = {roleID,userID};
				this.updateBySQL(sql, param);
			}
		}
	}

	@Override
	public List<MUser> getUserByRole(QueryConditions qc, PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_014");
		return this.queryBySQL(sql, qc, pageInfo,new CommonRowMapper(new MUser()));
	}

	@Override
	public void delUserForRole(int roleID, int[] userIDs) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_015");
		if (userIDs != null && userIDs.length > 0) {
			for(int userID:userIDs){
				Object[] param = {roleID,userID};
				this.updateBySQL(sql, param);
			}
		}
	}

	@Override
	public List<MUser> getUserListWithoutRole(int roleID, PageInfo pageInfo, QueryConditions qc) {//new CommonRowMapper(new MUser()));
		String sql  = this.sqlProperty.getProperty("SystemMgrDAO_016")+"(SELECT UserID from M_User_Role WHERE RoleID = "+roleID+") AND mu.Status = 1";
		//SELECT mu.id,mu.Name,mu.Description,mu.Status,mu.UserID,mu.REC_CREATEBY as recCreateBy,mu.REC_CREATETIME as recCreateTime,mu.REC_MODIFYBY as recModifyBy,mu.REC_MODIFYTIME as recModifyTime FROM M_User mu 
		//WHERE id NOT IN (SELECT UserID from M_User_Role WHERE RoleID =?) AND mu.Status = 1
		
		return this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new MUser()));
	}

	@Override
	public List<Right> getMgrRoleAuths(int roleID) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_017");
		Object[] param = {roleID};
		return this.queryBySQL(sql, param, null, null, new CommonRowMapper(new Right()));
	}

	@Override
	public void delRoleRight(int roleID) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_018");
		Object[] params = {
				roleID
		};
		this.updateBySQL(sql, params);
	}

	@Override
	public void addRoleRight(int roleID, int rightID) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_019");
		Object[] params = {
				roleID,rightID
		};
		this.updateBySQL(sql, params);
	}

	@Override
	public void updMgrUser(MUser user) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_021");
		Object[] params = {
				user.getName(),user.getDescription(),user.getRecModifyBy(),user.getId()
		};
		this.updateBySQL(sql, params);
	}

	@Override
	public List<Right> getMgrUserAuth(int userID) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_022");
		Object[] param = {userID};
		return this.queryBySQL(sql, param, null, null, new CommonRowMapper(new Right()));
	}

	@Override
	public List<LoginUserMenu> getLoginUserAuths(String userID) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_023");
		Object[] param = {
				userID
			};
		return this.queryBySQL(sql, param, null, null, new CommonRowMapper(new LoginUserMenu()));
	}

	@Override
	public List<LoginUserMenu> getChildRightList(String userID,int pid) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_024");
		Object[] param = {
				userID,pid
			};
		return this.queryBySQL(sql, param, null, null, new CommonRowMapper(new LoginUserMenu()));
	}

	@Override
	public List<MUser> getUserListByRoleID(int roleID) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_025");
		Object[] params = {roleID};
		return this.queryBySQL(sql, params, null, new CommonRowMapper(new MUser()));
	}

	@Override
	public List<LoginUserMenu> getLoginUserAuthTemp(String userID, int pid) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_026");
		Object[] param = {
				userID,pid
			};
		return this.queryBySQL(sql, param, null, null, new CommonRowMapper(new LoginUserMenu()));
	}

	@Override
	public MUser getUserByLoginName(String userID) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_027");
		Object[] params = {userID};
		return (MUser) this.queryForObject(sql, params, new CommonRowMapper(new MUser()));
	}

	/**
	 * 添加菜单
	 */
	@Override
	public void addRight(Right right) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_028");
		Object[] params = {right.getParentID(),right.getTreeName(),right.getIcon(),right.getTreeUrl(),
				right.getModuleID(),right.getSeq(),right.getIsVisible(),right.getTreeType()
		};
		this.updateBySQL(sql, params);
	}
	
	/**
	 * 更新菜单
	 */
	@Override
	public void updateRight(Right right) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_029");
		Object[] params = {right.getParentID(),right.getTreeName(),right.getIcon(),right.getTreeUrl(),
				right.getModuleID(),right.getSeq(),right.getIsVisible(),right.getTreeType(),right.getId()
		};
		this.updateBySQL(sql, params);
		
	}
	
	/**
	 * 根据角色ID查询当前角色下的 权限列表
	 * @param roleID
	 * @return
	 */
	@Override
	public List<Right> selectRightList(int roleID, int type) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_030");
		Object[] param = {roleID,type};
		return this.queryBySQL(sql, param, null, new CommonRowMapper(new Right()));
	}
	
	/**
	 * 查询权限列表
	 * @param roleID
	 * @return
	 */
	@Override
	public List<Right> selectAllRightList() {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_031");
		return this.queryBySQL(sql, new String[]{}, null, new CommonRowMapper(new Right()));
	}

	@Override
	public Right selectRightById(Integer id) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_032");
		Object[] param = {id};
		return (Right) this.queryForObject(sql, param, new CommonRowMapper(new Right()));
	}
	
	/**
	 * 根据 roleid  查询 用户列表
	 * @param cusInfoCscfg
	 */
	@Override
	public List<MUser> selectMUserListByRoleCode(String roleCode) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_033");
		Object[] params={roleCode};
		return this.queryBySQL(sql, params, null, new CommonRowMapper(new MUser()));
	}
	
	@Override
	public List<MUser> getUserListByRoleCode(String roleCode) {
		String sql = "SELECT * FROM M_User mu INNER JOIN M_User_Role mur ON mur.UserID = mu.id INNER "
				+ "JOIN M_Role mr ON mr.id = mur.RoleID WHERE mr.RoleCode in ('"+roleCode+"')";
		Object[] params={};
		return this.queryBySQL(sql, params, null, new CommonRowMapper(new MUser()));
	}

	@Override
	public List<MRole> getRoleListByUserId(String userId) {
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_034");
		Object[] params={userId};
		return this.queryBySQL(sql, params, null, new CommonRowMapper(new MRole()));
	}
	
	@Override
	public List<UaacUser> getUaacUserList(String userNames) {
		String sql = "select * from vw_UaacUser where LoginName in ("+userNames+")";
		Object[] params={};
		return this.queryBySQL(sql, params, null, new CommonRowMapper(new UaacUser()));
	}
	
	@Override
	public MUser getgetCUserByID(String userCode) {
		String sql = "select * from C_User where UserCode='"+userCode+"'";
		Object[] params = {
				
		};
		MUser user = (MUser) this.queryForObject(sql, params, new CommonRowMapper(new MUser()));
		return user;
	}
	@Override
	public void rollBack() {
		try {
			getConnection().setAutoCommit(false);//事务设置为手动
			getConnection().rollback();
		} catch (CannotGetJdbcConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public List<userMobileModel> getUserMobileList(String userCode) {
		this.log.info(this.getClass().getName()+" getUserMobileList Start");
		String sql = this.sqlProperty.getProperty("SystemMgrDAO_036");
		Object [] params = {
				userCode 
		};
		List<userMobileModel> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new userMobileModel()));
		this.log.info(this.getClass().getName()+" getUserMobileList End");
		return list;
	}
}
