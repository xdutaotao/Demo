package shcem.systemMgr.dao.model;

import java.io.Serializable;
import java.util.List;

import shcem.base.dao.model.BaseObject;

/**登录用户菜单权限
 * @author zhangnan
 */
public class LoginUserMenu extends BaseObject implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String text;//菜单名称
	
	private String heading;
	
	private String sref;//菜单Url
	
	private String icon; //菜单图标
	
	private List<LoginUserMenu> submenu;//子集菜单
	
	private int id;//菜单id
	
	private int type;

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getHeading() {
		return heading;
	}

	public void setHeading(String heading) {
		this.heading = heading;
	}

	public String getSref() {
		return sref;
	}

	public void setSref(String sref) {
		this.sref = sref;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public List<LoginUserMenu> getSubmenu() {
		return submenu;
	}

	public void setSubmenu(List<LoginUserMenu> submenu) {
		this.submenu = submenu;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

}
