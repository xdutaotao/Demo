package shcem.systemMgr.service;

/**后台管理（用户、角色等）
 * @author zhangnan
 *
 */
public interface ISystemMgrService {

	/**取得系统用户列表
	 * @param param
	 * @return
	 */
	public String getMgrUserList(String param);
	
	/**添加用户
	 * @param param
	 * @return
	 */
	public String addMgrUser(String param);
	
	/**修改用户密码
	 * @param param
	 * @return
	 */
	public String updMgrUserPsd(String param);
	
	/**删除用户
	 * @param param
	 * @return
	 */
	public String delMgrUser(String param);
	
	/**查看用户权限
	 * @param param
	 * @return
	 */
	public String getMgrUserAuths(String param);
	
	/**修改用户权限
	 * @param param
	 * @return
	 */
	public String updMgrUserAuths(String param);
	
	/**取得角色列表
	 * @param param
	 * @return
	 */
	public String getRoleList(String param);
	
	/**添加角色
	 * @param param
	 * @return
	 */
	public String addMgrRole(String param);
	
	/**删除角色
	 * @param param
	 * @return
	 */
	public String delMgrRole(String param);
	
	/**为某一角色添加用户
	 * @param param
	 * @return
	 */
	public String addUserForRole(String param);
	
	/**查看角色权限
	 * @param param
	 * @return
	 */
	public String getMgrRoleAuths(String param);
	
	/**为角色设置权限
	 * @param param
	 * @return
	 */
	public String addAuthsForRole(String param);
	
	/**获取所有资源权限
	 * @param param
	 * @return
	 */
	public String getAllAuth(String param);
	
	/**
	 * 通过某一个角色查询所有用户
	 * @param param
	 * @return
	 */
	public String getUserByRole(String param);
	
	/**
	 * 删除某一角色下的用户
	 * @param param
	 * @return
	 */
	public String delUserForRole(String param);
	/**
	 * 某一角色可添加的用户列表
	 * @param param
	 * @return
	 */
	public String getUserListWithoutRole(String param);
	/**
	 * 更新用户信息
	 * @param param
	 * @return
	 */
	public String updMgrUser(String param);
	
	/**
	 * 获取登录用户的权限资源
	 * @param param
	 * @return
	 */
	public String getLoginUserAuths(String param);
	/**后台系统用户登录校验
	 * @param param
	 * @return
	 */
	public String loginCheck(String param);
	
	/**后台系统用户编码重复校验
	 * @param param
	 * @return
	 */
	public String checkUserID(String param);
	/**
	 * 启用用户
	 * @return
	 */
	public String enableUser(String param);
	
	/**
	 * 变更菜单项
	 */
	public String changeMenuItem(String param);
	
	/**
	 * 根据角色ID获取按钮列表
	 */
	public String getRoleMenuButtonListByRoleId(String param);
	
	
	/**获取所有资源列表
	 * @param param
	 * @return
	 */
	public String getAllRightList(String param);
	
	/**
	 * 根据ID获取权限信息
	 * @param param
	 * @return
	 */
	public String getRightById(String param);
	
	/**
	 * 获取客服列表
	 * @param params
	 * @return
	 */
	public String getCustomerServiceList(String params);
	
	/**
	 * 获取角色类型列表
	 * @param params
	 * @return
	 */
	public String getRoleTypeList(String params);
	
	/**
	 * 随机获取指定位数的明码
	 * @param params
	 * @return
	 */
	public String generateRandom(String params);
	/**
	 * 获取用户信息
	 * @param params
	 * @return
	 */
	public String getCUserByID(String params);
	
	/**
	 * 后台重置前台客户密码，记录操作记录
	 * @param params
	 * @return
	 */
	public String resetPassword(String params);
}
