package shcem.systemMgr.dao.model;

import java.io.Serializable;

import shcem.base.dao.model.BaseObject;

/**后台系统用户
 * @author zhangnan
 *
 */
public class MUser extends BaseObject implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer id;
	
	private String userID;
	
	private String name;
	
	private String password;
	
	private String description;
	
	private Integer status;
	
	private String recCreateBy;
	
	private String recCreateTime;
	
	private String recModifyBy;
	
	private String recModifyTime;
	
	//模块
	private Integer moduleID;
	
	//角色
	private String roleName;
	
	private Integer roleID;
	
	private Integer registerAppType;
	
	
	public Integer getId() {
		return id;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public Integer getRoleID() {
		return roleID;
	}

	public void setRoleID(Integer roleID) {
		this.roleID = roleID;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getRecCreateBy() {
		return recCreateBy;
	}

	public void setRecCreateBy(String recCreateBy) {
		this.recCreateBy = recCreateBy;
	}

	public String getRecCreateTime() {
		return recCreateTime;
	}

	public void setRecCreateTime(String recCreateTime) {
		this.recCreateTime = recCreateTime;
	}

	public String getRecModifyBy() {
		return recModifyBy;
	}

	public void setRecModifyBy(String recModifyBy) {
		this.recModifyBy = recModifyBy;
	}

	public String getRecModifyTime() {
		return recModifyTime;
	}

	public void setRecModifyTime(String recModifyTime) {
		this.recModifyTime = recModifyTime;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getModuleID() {
		return moduleID;
	}

	public void setModuleID(Integer moduleID) {
		this.moduleID = moduleID;
	}

	public Integer getRegisterAppType() {
		return registerAppType;
	}

	public void setRegisterAppType(Integer registerAppType) {
		this.registerAppType = registerAppType;
	}

}
