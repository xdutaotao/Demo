package shcem.systemMgr.component.impl;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.systemMgr.component.ISystemMgrManager;
import shcem.systemMgr.dao.ISystemMgrDAO;
import shcem.systemMgr.dao.model.LoginUserMenu;
import shcem.systemMgr.dao.model.MRole;
import shcem.systemMgr.dao.model.MUser;
import shcem.systemMgr.dao.model.Right;
import shcem.systemMgr.dao.model.UserPasswordReset;
import shcem.systemMgr.util.GenerateRandomUtil;
import shcem.util.EncrypMD5;

public class SystemMgrManagerImpl extends BaseManager implements ISystemMgrManager {
	private ISystemMgrDAO iSystemMgrDAO;
	private ISystemMgrDAO iSystemMgrDAO_read;
	public void setiSystemMgrDAO(ISystemMgrDAO iSystemMgrDAO) {
		this.iSystemMgrDAO = iSystemMgrDAO;
	}

	public void setiSystemMgrDAO_read(ISystemMgrDAO iSystemMgrDAO_read) {
		this.iSystemMgrDAO_read = iSystemMgrDAO_read;
	}

	@Override
	public List<MUser> getMgrUserList(QueryConditions qc, PageInfo pageInfo) {
		List<MUser> list = this.iSystemMgrDAO_read.getMgrUserList(qc,pageInfo);
		return list;
	}

	@Override
	public String addMgrUser(MUser user) {
		String result;
		user.setPassword(EncrypMD5.eccrypt(user.getPassword()));
		try {
			this.iSystemMgrDAO.addMgrUser(user);
			result = "新增成功";
		} catch (Exception e) {
			e.printStackTrace();
			result = "新增失败";
		}
		return result;
	}

	@Override
	public String updMgrUserPsd(MUser user) {
		String result;
		user.setPassword(EncrypMD5.eccrypt(user.getPassword()));
		try {
			this.iSystemMgrDAO.updMgrUserPsd(user);
			result = "成功";
		} catch (Exception e) {
			e.printStackTrace();
			result = "新增失败";
		}
		return result;
	}

	@Override
	public int delMgrUser(int[] userIds) throws RuntimeException{
		int returnCode = 0 ;
		if (userIds != null && userIds.length > 0) {
			String ids = "";
			for (int j = 0; j < userIds.length; j++) {
				if (j  > 0)ids +=",";
				ids += userIds[j];
			}
			returnCode = this.iSystemMgrDAO.delMgrUser(ids,0);
			if(returnCode == -1)return returnCode;
			returnCode = this.iSystemMgrDAO.deMUserRole(ids);
			if(returnCode == -1){
				this.rollBack();
				return returnCode;
			}
		}
		return returnCode;
	}
	@Override
	public void enableUser(int[] userIds) {
		if (userIds != null && userIds.length > 0) {
			String ids = "";
			for (int j = 0; j < userIds.length; j++) {
				if (j  > 0)ids +=",";
				ids += userIds[j];
			}
			this.iSystemMgrDAO.delMgrUser(ids,1);
		}
	}

	@Override
	public List<Right> getMgrUserAuths(int userId)  throws RuntimeException{
		List<Right> list = this.iSystemMgrDAO_read.getMgrUserAuths(userId);
//		if (list != null && list.size() > 0) {
//			for (int i = 0; i < list.size(); i++) {
//				for (int j = list.size()-1; j>i; j--) {
//					if (list.get(i).getId() != null && list.get(j).getId() != null && list.get(i).getId() == list.get(j).getId()) {
//						list.remove(j);
//					}
//				}
//			}
//		}
		return list;
	}

	@Override
	public List<Right> getAllAuth() {
		return this.iSystemMgrDAO_read.getAllAuth();
	}

	@Override
	public String updMgrUserAuths(int userID, int[] userAuths)throws RuntimeException {
		
		this.iSystemMgrDAO.delUserRight(userID);
		if (userAuths != null && userAuths.length > 0) {
			for(int rightID:userAuths){
				this.iSystemMgrDAO.addUserRight(userID,rightID);
			}
		}
		return "success";
	}

	@Override
	public List<MRole> getRoleList(QueryConditions qc, PageInfo pageInfo) {
		return this.iSystemMgrDAO_read.getRoleList(qc,pageInfo);
	}

	@Override
	public void addMgrRole(MRole role)throws RuntimeException {
		this.iSystemMgrDAO.addMgrRole(role);
	}

	@Override
	public void delMgrRole(int[] roleIds) throws RuntimeException{
		this.iSystemMgrDAO.delMgrRole(roleIds);
	}

	@Override
	public void addUserForRole(int roleID, int[] userIDs) throws RuntimeException{
		List<Right> roleAuthList = this.iSystemMgrDAO.getMgrRoleAuths(roleID);
		ArrayList<Integer> arrList = new ArrayList<Integer>();
		//该角色具有的权限
		if (roleAuthList != null && roleAuthList.size() > 0) {
			int[] roleAuthArray = new int[roleAuthList.size()];
			for (int i = 0; i < roleAuthList.size(); i++) {
				roleAuthArray[i] = roleAuthList.get(i).getId();
			}
			
			for(int i=0; i<roleAuthArray.length; i++){
				if(!arrList.contains(roleAuthArray[i]))
					arrList.add(roleAuthArray[i]);
			}
		}
		if (userIDs != null && userIDs.length > 0) {
			for (int i = 0; i < userIDs.length; i++) {
				//该用户具有的权限
				List<Right> userAuthList = this.iSystemMgrDAO.getMgrUserAuth(userIDs[i]);
				if (userAuthList != null && userAuthList.size() > 0) {
					for (int j = 0; j < userAuthList.size(); j++) {
						if(arrList.contains(userAuthList.get(j).getId()))
							arrList.remove(userAuthList.get(j).getId());
					}
					
				}
				for (int j = 0; j < arrList.size(); j++) {
					this.iSystemMgrDAO.addUserRight(userIDs[i], arrList.get(j));
				}
			}
		}
//		if (arrList !=null && arrList.size() > 0) {
//			for (int i = 0; i < arrList.size(); i++) {
//				if (userIDs != null && userIDs.length > 0 ) {
//					for (int j = 0; j < userIDs.length; j++) {
//						this.iSystemMgrDAO.addUserRight(userIDs[j], arrList.get(i));
//					}
//				}
//				
//			}
//			
//			
//		}
		
		this.iSystemMgrDAO.addUserForRole(roleID, userIDs);
	}

	@Override
	public List<MUser> getUserByRole(QueryConditions qc, PageInfo pageInfo) throws RuntimeException{
		return this.iSystemMgrDAO_read.getUserByRole(qc,pageInfo);
	}

	@Override
	public void delUserForRole(int roleID, int[] userIDs) throws RuntimeException {
		this.iSystemMgrDAO.delUserForRole(roleID,userIDs);
	}

	@Override
	public List<MUser> getUserListWithoutRole(int roleID,PageInfo pageInfo, QueryConditions qc) throws RuntimeException  {
		return this.iSystemMgrDAO_read.getUserListWithoutRole(roleID,pageInfo,qc);
		
//		List<MUser> list1 = this.iSystemMgrDAO.getUserByRole(roleID,pageInfo);
//		if (list1 != null && list1.size() > 0) {
//			pageInfo.setPageSize(pageInfo.getPageSize()+list1.size());
//			
//		}
//		List<MUser> list2 = this.iSystemMgrDAO.getMgrUserList(null, pageInfo);
//		if (list1 != null && list1.size() > 0 && list2 != null && list2.size() > 0) {
//			for (int i = 0; i < list2.size(); i++) {
//				for (int j = 0; j < list1.size(); j++) {
//					if (list1.get(j).getId() == list2.get(i).getId()) {
//						list2.remove(i);
//					}
//				}
//			}
//		}
//		return list2;
	}

	@Override
	public List<Right> getMgrRoleAuths(int roleID)  throws RuntimeException  {
		return this.iSystemMgrDAO_read.getMgrRoleAuths(roleID);
	}

	@Override
	public void addAuthsForRole(int roleID, int[] roleAuths) throws RuntimeException   {
		this.iSystemMgrDAO.delRoleRight(roleID);
		if (roleAuths != null && roleAuths.length > 0) {
			for(int rightID:roleAuths){
				this.iSystemMgrDAO.addRoleRight(roleID,rightID);
			}
			//相应的也要更新用户权限
			//该角色对应的用户
			List<MUser> userList = this.iSystemMgrDAO.getUserListByRoleID(roleID);
			
			if (userList != null && userList.size() > 0) {
				for (int i = 0; i < userList.size(); i++) {
					//该用户具有的权限
					List<Right> userAuthList = this.iSystemMgrDAO.getMgrUserAuth(userList.get(i).getId());
					
					if (userAuthList != null && userAuthList.size() > 0) {
						ArrayList<Integer> arrList = new ArrayList<Integer>();
						for (int k = 0; k < userAuthList.size(); k++) {
							arrList.add(userAuthList.get(k).getId());
						}
							//要更新的角色权限
						for (int h = 0; h < roleAuths.length; h++) {
							if(!arrList.contains(roleAuths[h]))
							this.iSystemMgrDAO.addUserRight(userList.get(i).getId(),roleAuths[h]);
						}
						
					}else {
						for (int j = 0; j < roleAuths.length; j++) {
							this.iSystemMgrDAO.addUserRight(userList.get(i).getId(),roleAuths[j]);
						}
					}
				}
			}
		}
		
	}

	@Override
	public void updMgrUser(MUser user)throws RuntimeException{
		this.iSystemMgrDAO.updMgrUser(user);
	}

	@Override
	public List<LoginUserMenu> getLoginUserAuths(String userID)throws RuntimeException{
		//:heading类型 菜单
		List<LoginUserMenu> loginUserAuths = new LinkedList<LoginUserMenu>();
		//长度不确定的list
		List<LoginUserMenu> loginUserAuthsTemp = new LinkedList<LoginUserMenu>();
		loginUserAuths = this.iSystemMgrDAO_read.getLoginUserAuths(userID);
		if (loginUserAuths != null && loginUserAuths.size() > 0) {
			for (int i = 0; i < loginUserAuths.size(); i++) {
				loginUserAuths.get(i).setHeading("true");
				List<LoginUserMenu>  loginUserAuthsBy = this.iSystemMgrDAO_read.getLoginUserAuthTemp(userID,loginUserAuths.get(i).getId());
				if (loginUserAuthsBy != null && loginUserAuthsBy.size() > 0) {
					loginUserAuthsTemp.add(loginUserAuths.get(i));
					for (int j = 0; j < loginUserAuthsBy.size(); j++) {
						this.setSubmenuList(userID, loginUserAuthsBy.get(j));
						loginUserAuthsTemp.add(loginUserAuthsBy.get(j));
					}
				}
			}
		}
		return loginUserAuthsTemp;
	}
	
	@Override
	public MUser checkPassword(String userID) {
		MUser user = this.iSystemMgrDAO_read.getUserByLoginName(userID);
		return user;
	}

	@Override
	public boolean checkUserID(String userID) {
		boolean flag = false;
		MUser user = this.iSystemMgrDAO_read.getUserByLoginName(userID);
		if (user != null) {
			flag = true;
		}
		return flag;
	}

	//设置子节点
	private void setSubmenuList(String userID,LoginUserMenu loginUserMenu) {
		List<LoginUserMenu> childRiglist = new ArrayList<LoginUserMenu>();
		childRiglist = this.iSystemMgrDAO_read.getChildRightList(userID,loginUserMenu.getId());
		if (childRiglist != null && childRiglist.size() > 0) {
			for (int i = 0; i < childRiglist.size() ; i++) {
				this.setSubmenuList(userID,childRiglist.get(i));
			}
		}
		loginUserMenu.setSubmenu(childRiglist);
	}
	
	@Override
	public MUser getMUserByLoginName(String userID) {
		return this.iSystemMgrDAO_read.getUserByLoginName(userID);
	}
	
	/**
	 * 更新菜单 Id有时更新，没时添加
	 * @param right
	 */
	@Override
	public void changeRight(Right right) {
		if (right.getId() == null){
			this.iSystemMgrDAO.addRight(right);
		}else{
			this.iSystemMgrDAO.updateRight(right);
		}
	}
	
	/**
	 * 根据角色ID查询当前角色下的按钮列表
	 * @param roleID
	 * @return
	 */
	@Override
	public List<Right> selectRightButtonListByRoleId(int roleID) {
		return this.iSystemMgrDAO_read.selectRightList(roleID, 1);
	}
	
	/**
	 * 查询权限列表
	 * @param roleID
	 * @return
	 */
	@Override
	public List<Right> selectAllRightList() {
		return this.iSystemMgrDAO_read.selectAllRightList();
	}

	@Override
	public Right selectRightById(Integer id) {
		return this.iSystemMgrDAO_read.selectRightById(id);
	}

	@Override
	public List<MUser> selectMUserListByRoleCode(String roleCode) {
		return this.iSystemMgrDAO_read.selectMUserListByRoleCode(roleCode);
	}

	@Override
	public List<MRole> getRoleListByUserId(String userId) {
		return iSystemMgrDAO_read.getRoleListByUserId(userId);
	}
	
	/**
	 * 后台重置前台客户密码
	 * @param userCName 前台用户
	 * @param userMobile 用户电话
	 * @param userName 后台操作人员
	 */
	@Override
	public int resetPassword(UserPasswordReset user,
			String userName) {
		int returnCode;
		returnCode = this.iSystemMgrDAO.addUserPasswordReset(user,userName);
		return returnCode;
	}
	
	@Override
	public MUser getCUserByID(String userCode) {
		MUser user = this.iSystemMgrDAO_read.getgetCUserByID(userCode);
		return user;
	}
	
	private void rollBack() {
		this.iSystemMgrDAO.rollBack();
	}
}
