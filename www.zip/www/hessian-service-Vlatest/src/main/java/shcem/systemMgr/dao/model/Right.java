package shcem.systemMgr.dao.model;

import java.io.Serializable;
import java.util.List;

import shcem.base.dao.model.BaseObject;


/**系统资源权限
 * @author zhangnan
 *
 */
public class Right extends BaseObject implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	
	private Integer parentID; 
	
	private String treeName;
	/**
	 * 图标名称
	 */
	private String icon;
	
	/**
	 * 模块ID 对应后台的权限模块如（交易：1，财务：2，风控：3，PIC：4），保留
	 */
	private Integer moduleID; 
	
	private Integer seq; 
	
	/**
	 * 菜单是否可见（角色、用户是否拥有该菜单的查看权限）
	 */
	private Integer isVisible;
	
	private Integer treeType;
	
	private String treeUrl;
	
	//子集
	private List<Right> childRiglist;
	
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getParentID() {
		return parentID;
	}

	public void setParentID(Integer parentID) {
		this.parentID = parentID;
	}

	public String getTreeName() {
		return treeName;
	}

	public void setTreeName(String treeName) {
		this.treeName = treeName;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public Integer getModuleID() {
		return moduleID;
	}

	public void setModuleID(Integer moduleID) {
		this.moduleID = moduleID;
	}

	public Integer getSeq() {
		return seq;
	}

	public void setSeq(Integer seq) {
		this.seq = seq;
	}

	public Integer getIsVisible() {
		return isVisible;
	}

	public void setIsVisible(Integer isVisible) {
		this.isVisible = isVisible;
	}

	public Integer getTreeType() {
		return treeType;
	}

	public void setTreeType(Integer treeType) {
		this.treeType = treeType;
	}

	public String getTreeUrl() {
		return treeUrl;
	}

	public void setTreeUrl(String treeUrl) {
		this.treeUrl = treeUrl;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public List<Right> getChildRiglist() {
		return childRiglist;
	}

	public void setChildRiglist(List<Right> childRiglist) {
		this.childRiglist = childRiglist;
	}

}
