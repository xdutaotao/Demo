package shcem.systemMgr.dao;

import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.member.service.model.userMobileModel;
import shcem.systemMgr.dao.model.LoginUserMenu;
import shcem.systemMgr.dao.model.MRole;
import shcem.systemMgr.dao.model.MUser;
import shcem.systemMgr.dao.model.Right;
import shcem.systemMgr.dao.model.UaacUser;
import shcem.systemMgr.dao.model.UserPasswordReset;

public abstract interface  ISystemMgrDAO extends DAO {

	List<MUser> getMgrUserList(QueryConditions qc, PageInfo pageInfo);

	public void addMgrUser(MUser user);

	void updMgrUserPsd(MUser user);

	int delMgrUser(String userIds, int userStatus);

	List<Right> getMgrUserAuths(int userId);

	List<Right> getAllAuth();

	void delUserRight(int userID);

	void addUserRight(int userID, int rightID);

	List<MRole> getRoleList(QueryConditions qc, PageInfo pageInfo);

	void addMgrRole(MRole role);

	void delMgrRole(int[] roleIds);

	void addUserForRole(int roleID, int[] userIDs);

	List<MUser> getUserByRole(QueryConditions qc, PageInfo pageInfo);

	void delUserForRole(int roleID, int[] userIDs);

	List<MUser> getUserListWithoutRole(int roleID, PageInfo pageInfo, QueryConditions qc);

	List<Right> getMgrRoleAuths(int roleID);

	void delRoleRight(int roleID);

	void addRoleRight(int roleID, int rightID);

	void updMgrUser(MUser user);

	List<Right> getMgrUserAuth(int userID);

	List<LoginUserMenu> getLoginUserAuths(String userID);

	List<LoginUserMenu> getChildRightList(String userID,int pid);

	List<MUser> getUserListByRoleID(int roleID);

	List<LoginUserMenu> getLoginUserAuthTemp(String userID, int pid);

	MUser getUserByLoginName(String userID);
	
	/**
	 * 添加菜单
	 */
	void addRight(Right right);
	
	/**
	 * 更新菜单
	 */
	void updateRight(Right right);
	
	/**
	 * 根据角色ID查询当前角色下的 权限列表
	 * @param roleID
	 * @return
	 */
	List<Right> selectRightList(int roleID,int type);
	
	/**
	 * 查询权限列表
	 * @param roleID
	 * @return
	 */
	List<Right> selectAllRightList();
	
	/**
	 * 查询权限列表
	 * @param roleID
	 * @return
	 */
	Right selectRightById(Integer id);
	
	/**
	 * 根据 roleCode 查询 用户列表
	 * @param cusInfoCscfg
	 */
	public List<MUser> selectMUserListByRoleCode(String roleCode);
	/**
	 * 
	 * @param roleCode 角色类型
	 * @return
	 */
	List<MUser> getUserListByRoleCode(String roleCode);

	List<UaacUser> getUaacUserList(String userNames);
	
	/**
	 * 根据用户ID 获取角色列表
	 * @param userId 用户ID
	 * @return
	 */
	List<MRole> getRoleListByUserId(String userId);

	void rollBack();

	int deMUserRole(String userIds);

	/**
	 * @param userName 后台操作人员
	 * @return
	 */

	int addUserPasswordReset(UserPasswordReset user, String userName);

	MUser getgetCUserByID(String userCode);

	List<userMobileModel> getUserMobileList(String userCode);
	
}
