package shcem.trade.component;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.List;

import org.json.JSONArray;

import scem.drools.DealStatus;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.member.service.model.userMobileModel;
import shcem.systemMgr.dao.model.MUser;
import shcem.trade.ExportModel.Delivery4Export;
import shcem.trade.ExportModel.DeliveryInvoice4Export;
import shcem.trade.dao.IDeliveryDAO;
import shcem.trade.dao.model.BreachContractApply;
import shcem.trade.dao.model.Delivery;
import shcem.trade.dao.model.DeliveryInvoice;
import shcem.trade.dao.model.DeliveryOpeLog;
import shcem.trade.dao.model.ExportDelivery;
import shcem.trade.dao.model.ExportFirmfunds;
import shcem.trade.dao.model.Order;
import shcem.trade.dao.model.OrderSinopec;
import shcem.trade.dao.model.ProcessTask;
import shcem.trade.service.model.DeliveryDto;

public interface IDeliveryManager {
	public abstract void setDeliveryDAO(IDeliveryDAO deliveryDAO);

	public abstract List<Delivery> getDeliveryList(QueryConditions qc,
			PageInfo pageInfo);

	public abstract Delivery getDeliveryDetail(String deliveryID, String userID, String mode);

	public abstract int handleDelivery(String deliveryID, String userID);
	
	public abstract int paySellerMoney(String deliveryID,BigDecimal money,String userID, boolean isCheck, String orderID);
	
	public abstract void addDeliveryOpeLog(String deliveryID, String userID, String opeContent, String setOpeComment);

	public abstract List<DeliveryOpeLog> getDeliveryOpeLogList(String deliveryID);

	public abstract int takeBuyerMoney(String deliveryID, 
			BigDecimal money, String userID);

	public abstract MUser getUserByLoginName(String userID);

	public abstract Order getOrderByDeliveryID(String deliveryID);

	public abstract int releaseCreditMoneyForSeller(String deliveryID,String userID);
	
	public abstract int releaseCreditMoneyForSellerByOrderID(String orderID,String userID);

	public abstract int refundForBuyFirm(String deliveryID, String userID,
			BigDecimal money);

	public abstract int takePenaltyMoneyForSeller(String deliveryID,
			BigDecimal money, String userName);

	/**退保证金给卖家
	 * @param deliveryID
	 * @param money
	 */
	public abstract void updateFirmfundsForBuyFirm(String deliveryID,
			BigDecimal money);

	/**
	 * 收买方违约金
	 * @param deliveryID
	 * @param userID
	 * @param money
	 * @return
	 */
	public abstract int takePenaltyMoneyForBuyer(String deliveryID,
			String userName, BigDecimal money);

	/**
	 * 调整实发货数量，调整溢短金额
	 * @param deliveryID
	 * @param userID
	 * @param money
	 * @param takenQuantity
	 * @param deliveryComment 
	 * @param mode 
	 * @param taskID 
	 * @param userID 
	 * @param deliveryOrderFileID 
	 * @return
	 */
	public abstract int adJustTakenQuantity(String deliveryID, String userName,
			 BigDecimal takenQuantity, String deliveryComment, String taskID, String mode, String userID, int deliveryOrderFileID);

	/**调整金额
	 * @param deliveryID
	 * @param userID
	 * @param money
	 * @param userID 
	 * @param taskID 
	 * @param mode 
	 */
	public abstract int adJustOverLoadMoney(String deliveryID, String userName,
			BigDecimal money, String mode, String userID);

	/**
	 * @param replace 
	 * 
	 */
	public abstract List<Delivery4Export> getExportDeliveryList(QueryConditions qc,PageInfo pageInfo, boolean replace);
	
	/**
	 * 
	 */
	public abstract List<ExportFirmfunds> getExportFirmFundsList(QueryConditions qc,PageInfo pageInfo);

	/**
	 * 补收订单卖方手续费
	 * @param orderID
	 * @param money
	 * @param userID
	 * @return
	 */
	public abstract int takeSettleFeeForOrderSeller(String orderID,String userID);

	public abstract Order getOrderFile(String orderID);
	
	/**
	 * @param mode 
	 * @param userID 
	 * @param userName 
	 * @param taskID 
	 * 
	 */
	public abstract int updDeliveryDetail(Delivery delivery, String userName, String userID, String mode, String taskID);
	/**
	 * 更新提货信息 ：自提或者转货权
	 * @param delivery
	 * @param userName
	 * @return
	 */
	public abstract int updateDelLogisticsInfo(Delivery delivery, String userName);

	public abstract int updateDeliveryDetailStatus(String deliveryID,
			String userID);
	
	/**
	 * 
	 */
	public abstract List<DeliveryInvoice> getDeliveryInvoiceList(QueryConditions qc,PageInfo pageInfo);

	public abstract int updateDeliveryLogisticsStatus(String deliveryID,
			String userID,String mode);

	public abstract String[] getRecordArray(QueryConditions qc,PageInfo pageInfo);

	public abstract int finishedOrder(int tradeStatus, String orderId, boolean equal,
			int deliveryQuantity, int quantity);

	public abstract List<Delivery> getLogisticalDeliveryList(
			QueryConditions qc, PageInfo pageInfo);

	public abstract String[] getLogisticalRecordArray(QueryConditions qc,
			PageInfo pageInfo);

	public abstract int paySellerPenalty(String deliveryID, String userName, BigDecimal payMoney);

	public abstract int payBuyerPenalty(String deliveryID, String userName,
			BigDecimal payMoney);

	public abstract BigDecimal getNotPaidSellerPenalty(String deliveryID, String firmID, int penaltyType);
	
	public abstract int reviewPassedDelivery(String deliveryID, String userName, String mode, String userID, String taskID);

	public abstract int reviewNotPassedDelivery(String deliveryID, String userName, String taskID, String mode,String userID);

	public abstract int reviewPassedDeliverySignedQuantity(String deliveryID, String userName, 
			String mode, String userID, String taskID);
	/**
	 * 风控审核签收数量--通过物流部门的签收数量,卖家确认
	 * @param deliveryID
	 * @param userName
	 * @return
	 */
	public abstract int confirmSignedQuantityBySeller(String deliveryID,
			String userName);

	public abstract int reviewNotPassedDeliverySignedQuantity(String deliveryID, String userName,
			String taskID, String mode, String userID);

	public abstract int addNormalDelivery(Delivery delivery, String userName,String mode, String userID) throws ParseException;

	public abstract int submitDelivery(Delivery delivery,String userName,String userID,String mode);
	
	public abstract int startProcessByCustomer(String[] deliveryIDArray,
			 String userID, String userName, String mode);

	public abstract int disabledNormalDelivery(String deliveryID, String userName);

	/**
	 * 
	 * @param unNormalApplyID  客户违约申请号
	 * @return
	 */
	public abstract int disabledUnNormalDelivery(String unNormalApplyID);
	/**
	 * 客户申请违约 后台确认(调整实际能够违约的数量)
	 * @param breachContractApplyArray 
	 * @param deliveryIDArray 
	 * @param unNormalApplyID 客户违约申请号
	 * @param userName 
	 * @return
	 * @throws ParseException 
	 * @throws RuntimeException 
	 */
	public abstract int confirmUnNormalDelivery(JSONArray breachContractApplyArray, String unNormalApplyID, String userName) throws RuntimeException, ParseException;

	/**
	 * 风控部门 调整溢短金额 提交审核
	 * @param deliveryID
	 * @param userName
	 * @param taskID 
	 * @param userID 
	 * @param mode 
	 * @return
	 */
	public abstract int submitOverLordMoney(String deliveryID, String userName, String mode, String userID, String taskID);
	
	/**
	 * 风控部门 审核通过 收违约金/付违约金 
	 * @param deliveryID
	 * @param userName
	 * @param userID 
	 * @param mode 
	 * @param taskId 
	 * @param userID 
	 * @param mode 
	 * @param taskID 
	 * @return
	 */
	public abstract int passedDeleveryPenalty(String deliveryID, String userName, String taskId, String mode, String userID);
	
	/**
	 * 风控审核 通过溢短金额
	 * @param deliveryID
	 * @param userName
	 * @param mode
	 * @param userID
	 * @param taskID
	 * @return
	 */
	public abstract int reviewPassedOverLordMoney(String deliveryID,
			String userName, String mode, String userID, String taskID);
	/**
	 * 风控审核 拒绝溢短金额
	 * @param deliveryID
	 * @param userName
	 * @param mode
	 * @param userID
	 * @param taskID
	 * @return
	 */
	public abstract int reviewNotPassedOverLordMoney(String deliveryID,
			String userName, String mode, String userID, String taskID);
	/**
	 * 传上家委托书
	 * @param deliveryID
	 * @param userName
	 * @param taskID
	 * @param mode
	 * @param userID
	 * @return
	 */
	public abstract int uploadReceiptForm(String deliveryID, String userName,
			 String mode, String userID,String taskID);
	/**
	 * 买家确认上传签收单(前台客户确认签收)
	 * @param deliveryID
	 * @param deliveryArray 
	 * @param userName
	 * @return
	 */
	public abstract int uploadReceiptFormByBuyer(String orderID,
			JSONArray deliveryArray,JSONArray fileIDArray,String userName);
	
	/**
	 * 获取交收流程
	 * @param deliveryID
	 * @param userName
	 * @param userID
	 * @param mode
	 * @return
	 */
	public abstract ProcessTask getCandidateUserTaskList(String deliveryID,
			String userName, String userID, String mode);
	
	/**
	 * 查询 客户违约申请 列表(分页)
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	List<BreachContractApply> queryBreachContractApplyList(QueryConditions qc, PageInfo pageInfo);
	/**
	 * 收买家/卖家违约金 提请审核
	 * @param deliveryID
	 * @param userName
	 * @param userID
	 * @param mode
	 * @return
	 */
	public abstract int subDeleveryPenalty(String deliveryID, String userName,
			String userID, String mode);
	/**
	 * 风控部门 审核拒绝 收违约金/付违约金 
	 * @param deliveryID
	 * @param userName
	 * @param taskId
	 * @param mode
	 * @param userID
	 * @return
	 */
	public abstract int refusedDeleveryPenalty(String deliveryID,
			String userName, String taskId, String mode, String userID);

//	public Map<String,Object> createImage(String deliveryID, String mode, int type, DeliveryDto deliveryDtoOfPage);
	
	/**
	 * 根据OrderID 查询交收单状态列表
	 * @param orderId
	 * @return
	 */
	public List<String> findDeliveryStatusByOrderId(String orderId);
	
	/**
	 * 获取成交的状态
	 * @param orderID
	 * @param mode
	 * @param orderQuantity
	 * @param delieveryQuantity
	 * @param deliveryType 
	 * @return
	 */
	public DealStatus findOrderStatusFormDrools(String orderID, String mode,Integer orderQuantity, Integer delieveryQuantity, 
			int deliveryTypefindOrderStatusFormDrools,int deliverySinopecQuantity);

	/**
	 * 生成委托书
	 * @param deliveryDto
	 * @param mode
	 * @return
	 */
	public abstract int creatProxyFile(DeliveryDto deliveryDto, String mode,String userName);

	/**
	 *  风控部门审核通过后，如果卖家24小时之内没有确认，后台自动触发确认
	 * @param deliveryID
	 * @param userName
	 * @param userID 
	 * @return
	 */
	public abstract int sellConfirmDelivery(String deliveryID, String userName,String mode, String userID);
	/**
	 * 风控部门审核通过后，如果卖家24小时之内没有确认，自动触发确认
	 * @param userName
	 * @param mode
	 * @return
	 */
	public abstract int sellConfirmDeliveryPolled(String userName, String mode, String userID);
	
	/**
	 * 更新记录操作日志
	 * @param notes
	 * @param deliveryID
	 * @return
	 */
	int updateOperNotes(String notes,String userId, String deliveryID);
	
	/**
	 * 查询记录操作日志
	 * @return
	 */
	String findOperNotes(String deliveryID);

	/**
	 * 客户违约申请添加备注
	 * @param
	 * @return
	 */
	 int addReamrkBreach(String remark, String userId, String deliveryID);

	/**
	 *客户违约申请获取备注
	 */
	 String readRemarkBreach(String deliveryID);
	 
	/**
	 * 根据DeliveryID 更新 交收表的【已付货款(PayedMoney)】
	 */
	int updateDeliveryOfPayedMoneyByDeliveryID(String deliveryID,String userID,BigDecimal payedMoney);

	public abstract Delivery getDeliveryByID(String deliveryID);
		
	/**
	 * 更新运费调整额
	 * @param deliveryID
	 * @param backFreightFree 运费调整额
	 * @param userId
	 * @return
	 */
	public abstract int updateDeliveryFreightFeeOfOverloadFreight(String deliveryID,BigDecimal backFreightFree,String userId);
	
	
	/**
	 * 扣买方运费
	 * @return
	 */
	public int subtractBuyFirmFreight(String orderId,String userID);
	
	/**
	 * 根据申请ID获取申请列表
	 * @param ID 申请ID
	 * @return
	 */
	List<BreachContractApply> getBreachContractApplyListByID(String ID);
	
	int updateOrderTradeStatus(String orderID, String mode, Integer deliveryType);

	public abstract int pushMessage(String orderID, String userID, String mode);

	/**
	 * 中石化"交收"上传文件
	 * @param deliveryID
	 * @return
	 */
	public abstract List<OrderSinopec> getDeliverySinopecFile(String deliveryID);
	
	/**
	 * 更新 交收表 是否取得中石化订单号
	 * @param deliveryID
	 * @param isGetSinopecNumber
	 * @param userName
	 * @return
	 */
	int updateDeliveryOfIsGetSinopecNumber(String deliveryID,Integer isGetSinopecNumber,String userName);
	
	int doReceive(String deliveryID,String userName);
	
	
	/**
	 * 查询  交收配送明细表的列表
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	List<Delivery> getDeliveryOfDelDistributionDetailList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 所有交收单
	 * @param replace 
	 * @param orderId
	 * @return
	 */
	List<Delivery4Export> exportNewDeliveryList(QueryConditions qc, PageInfo pageInfo, boolean replace);

	public abstract List<DeliveryInvoice4Export> getDeliveryInvoice4ExportList(
			QueryConditions qc, PageInfo pageInfo, boolean replace);

	public abstract int getExportDeliveryListCount(QueryConditions qc,
			PageInfo pageInfo);

	public abstract int exportNewDeliveryListListCount(QueryConditions qc,
			PageInfo pageInfo);

	/**
	 * 交易员手机号列表
	 * @param userCode
	 * @return
	 */
	public abstract List<userMobileModel> getUserMobileList(String userCode);

	public abstract int getDeliveryInvoice4ExportCount(QueryConditions qc,
			PageInfo pageInfo);	
	
	public abstract Delivery getDeliveryByDeliveryID(String deliveryID);

}
