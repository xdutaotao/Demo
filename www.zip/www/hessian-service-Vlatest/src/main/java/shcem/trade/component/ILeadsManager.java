/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: ILeadsManager.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月12日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.trade.component;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.trade.dao.LeadsDAO;
import shcem.trade.dao.model.Leads;
import shcem.trade.dao.model.LeadsLiner;
import shcem.trade.dao.model.LeadsTemplatePrice;
import shcem.trade.service.model.LeadsForIMServiceModel;
import shcem.trade.service.model.LeadsListLinerQueryModel;

/**
 * @author wlpod
 *
 */
public interface ILeadsManager extends Manager {
	public abstract void setLeadsDAO(LeadsDAO paramLeadsDAO);

	public abstract Leads getLeadsByID(Integer leadsID);

	public abstract List<Leads> getLeadsList(QueryConditions qc, PageInfo pageInfo);
	
	public abstract List<LeadsForIMServiceModel> getLeadsListForIM(QueryConditions qc, PageInfo pageInfo);

	public abstract List<LeadsLiner> getLeadsListLiner(LeadsListLinerQueryModel model, PageInfo pageInfo);
	
	
	/**
	 * 查看报盘配送范围列表
	 * @param leadsID
	 * @return
	 */
	public abstract List<LeadsTemplatePrice> getLeadsTemplatePriceList(Integer leadsID);
	
	
	public abstract Map<String, BigDecimal> GetFirmDailyTradeInfoLiner(QueryConditions qcLeads, QueryConditions qcOrder, String firmId);
	
	/**
	 * 挂盘锁单
	 * @param enquiryid
	 * @throws Exception
	 */
	public abstract void lockLead(int enquiryid) throws Exception;
}
