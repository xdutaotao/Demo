/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: OrderManagerImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月12日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.trade.component.impl;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import scem.drools.PaymentStatus;
import scem.drools.PaymentStatusPost;
import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.constant.BusinessEnumConstants;
import shcem.constant.Constants;
import shcem.constant.TradeTemplateConstant;
import shcem.finance.component.ICouponComponnetManager;
import shcem.finance.component.IFirmBanlanceManager;
import shcem.finance.component.ISApplayManager;
import shcem.finance.component.IVoucherManager;
import shcem.finance.dao.model.Coupon;
import shcem.finance.util.FinanceSysData;
import shcem.member.dao.model.FirmAllData;
import shcem.systemMgr.dao.ISystemMgrDAO;
import shcem.systemMgr.dao.model.MRole;
import shcem.trade.ExportModel.Order4Export;
import shcem.trade.component.IDeliveryManager;
import shcem.trade.component.IOrderManager;
import shcem.trade.component.ITraderManager;
import shcem.trade.dao.IDeliveryDAO;
import shcem.trade.dao.OrderDAO;
import shcem.trade.dao.model.BreachContractApply;
import shcem.trade.dao.model.CancelContract;
import shcem.trade.dao.model.DailyTons;
import shcem.trade.dao.model.Delivery;
import shcem.trade.dao.model.DeliveryFreightFee;
import shcem.trade.dao.model.MailConfig;
import shcem.trade.dao.model.Order;
import shcem.trade.dao.model.OrderLiner;
import shcem.trade.dao.model.OrderOprRecord;
import shcem.trade.dao.model.OrderSinopec;
import shcem.trade.dao.model.OrderSumByTradeTemplate;
import shcem.trade.dao.model.ProductOrder;
import shcem.trade.dao.model.TradeTemplate;
import shcem.trade.dao.model.UploadFileModel;
import shcem.trade.service.model.OrderDto;
import shcem.trade.util.DeliveryExpenseUtil;
import shcem.trade.util.TradeSysData;
import shcem.util.Common;
import shcem.util.DateUtil;
import shcem.util.JsonUtil;

/**
 * @author wlpod
 *
 */
public class OrderManagerImpl extends BaseManager implements IOrderManager {

	private OrderDAO dao;
	
	private OrderDAO orderDAO_read;
	
	private IVoucherManager voucherMgr; 
	
	
	public void setOrderDAO_read(OrderDAO orderDAO_read) {
		this.orderDAO_read = orderDAO_read;
	}

	private ISystemMgrDAO systemMgrDAO;
	
	private ISystemMgrDAO systemMgrDAO_read;
	
	public void setSystemMgrDAO_read(ISystemMgrDAO systemMgrDAO_read) {
		this.systemMgrDAO_read = systemMgrDAO_read;
	}

	private IFirmBanlanceManager firmBanlanceManager = null; 
	private IDeliveryManager deliveryManager = null;
	private ISApplayManager sApplyManagerImpl;
	
	private IDeliveryDAO deliveryDAO;
	
	private IDeliveryDAO deliveryDAO_read;
	
	public void setDeliveryDAO_read(IDeliveryDAO deliveryDAO_read) {
		this.deliveryDAO_read = deliveryDAO_read;
	}
	public void setDeliveryDAO(IDeliveryDAO iDeliveryDAO) {
		this.deliveryDAO = iDeliveryDAO;
	}
	public void setSystemMgrDAO(ISystemMgrDAO systemMgrDAO) {
		this.systemMgrDAO = systemMgrDAO;
	}


	@Override
	public void setOrderDAO(OrderDAO paramOrderDAO) {
		this.dao = paramOrderDAO;

	}

	/**
	 * 通过OrderId主键查询一条Order记录
	 * 
	 * @param orderID
	 * @return
	 */
	@Override
	public Order getOrderByID(String orderID) {
		return this.orderDAO_read.getOrderByID(orderID);
	}

	/**
	 * 通过检索条件查询一条或多条Order记录
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	@Override
	public List<Order> getOrderList(QueryConditions qc, PageInfo pageInfo) {
		return this.orderDAO_read.getOrderList(qc, pageInfo);
	}
	
	/**
	 * 通过成交号查询一条或多条Order记录
	 * 
	 * @param orderIds
	 * @return
	 */
	@Override
	public List<Order> getOrderListByOrderIds(String orderIds) {
		return this.orderDAO_read.getOrderListByOrderIds(orderIds);
	}

	@Override
	public List<Order> getUnpayFeeSellerOrderList(QueryConditions qc, PageInfo pageInfo) {
		return this.orderDAO_read.getUnpayFeeSellerOrderList(qc, pageInfo);
	}
	
	@Override
	public void updateSellCreditFeeAndSellTakenTradeFee(Order order) {
		this.dao.updateSellCreditFeeAndSellTakenTradeFee(order);
	}
	@Override
	public Order getOrderByOrderID(String orderID) {
		Order order = this.dao.getOrderByOrderID(orderID);
		
		int appliedQiamtity = this.orderDAO_read.getRemainQiamtity(orderID);//订单 已申请交收数量（不可违约交收单数量+违约数量）
		
		int remainQiamtity  = order.getQuantity()-appliedQiamtity;//订单 未申请数量
		
		order.setDeliveryQuantity(remainQiamtity);
		//可申请违约数量
		order.setRemainQiamtity(remainQiamtity);//订单 未申请数量
		//已申请交收数量
		order.setDeliveryQuantity(appliedQiamtity);
		
		//买卖双方剩余保证金
		BigDecimal remainBuyTradeDeposit = new BigDecimal(0);
		BigDecimal remianSellTradeDeposit = new BigDecimal(0);
		List<Delivery> deliveryList = this.orderDAO_read.getDeliveryList(orderID);
		if (deliveryList !=null && deliveryList.size() > 0) {
			for (int i = 0; i < deliveryList.size(); i++) {
				remainBuyTradeDeposit = remainBuyTradeDeposit.add(deliveryList.get(i).getTakenBSDeposit());
				remianSellTradeDeposit = remianSellTradeDeposit.add(deliveryList.get(i).getSellTakenSSDeposit());
			}
		}
		order.setRemainBuyTradeDeposit(remainBuyTradeDeposit);
		order.setRemianSellTradeDeposit(remianSellTradeDeposit);
		return order;
	}
	/**
	 * 交收违约
	 * @param
	 * orderID：订单ID
	 * userID：申请人
	 * unnormalQuantity：申请违约数量 (买方未付化交，是整体违约；买方已付化交，是申请部分违约)
	 * unnormalFirm:违约方：0：买家违约  1：卖家违约
	 * deliveryComment 备注：违约原因
	 * @throws ParseException 
	 */
	@Override
	public int insertViolationDelivery(String orderID,String userName,int unnormalQuantity,int unnormalFirm,
			String deliveryComment,String mode)throws RuntimeException, ParseException{
		this.log.info(this.getClass().getName()+" insertViolationDelivery Start");
		deliveryManager = (IDeliveryManager) TradeSysData
				.getBean(Constants.BEAN_DELIVERY_MGR);
		
		firmBanlanceManager = (IFirmBanlanceManager) FinanceSysData.getBean(Constants.BEAN_BALANCE_MGR);
		int returnCode = 0;
		Order order = this.dao.getOrderByOrderID(orderID);
		int goodTypes = Common.getGoodsType(order.getTradeType());
		int canDeliveryQuantity = order.getQuantity()
				- order.getDeliveryQuantity();
		if(unnormalQuantity > canDeliveryQuantity){
			return -24001;
		}
		
		
		
		int minQuantity = order.getMinQuantity();
		
		/*订单总量*/
		int totalQuantity = order.getQuantity()-order.getDeliveryQuantity();
		int numQuantity = totalQuantity - minQuantity;
		if((unnormalQuantity > numQuantity)&&(unnormalQuantity != totalQuantity)){
			deliveryDAO.rollBack();
			return -24028;
		}
		
		
		// 订单已经申请的数量更新
		returnCode = this.deliveryDAO.updateDeliveryQuantity(unnormalQuantity,
				orderID, userName);
		if(returnCode == -1)return returnCode;
		
		Delivery delivery = new Delivery();
		
		/**
		 * 买方违约：买方未付化交，是整体违约
		 */
		if (order.getTradeStatus() == 1 && unnormalFirm == 0) {
			int quantity = order.getQuantity();
			if(unnormalQuantity != quantity ){
				this.rollBack();
				return -24021;
			}
			this.deliveryDAO.finishedOrder(55, orderID);//订单状态 "买家违约"
			
			delivery.setDeliveryQuantity(order.getQuantity());//违约数量 整体违约
			order.setUnnormalFirm(unnormalFirm);
			DeliveryExpenseUtil.setDeliveryExpenses(order, delivery, userName,deliveryDAO);
			
			
			String deliveryID = DeliveryExpenseUtil.setDeliveryID(orderID, dao);
			delivery.setDeliveryID(deliveryID);
			delivery.setDeliveryComment(deliveryComment);
			delivery.setLeadsID(order.getLeadsID());
			TradeTemplate tradeTemplate = this.deliveryDAO.getTradeTemplateByID(order.getTradeTmptId());//交易场信息
			DeliveryExpenseUtil.setViolationDeliveryExpenses(tradeTemplate, delivery);
			delivery.setProcessStatus(1);
			returnCode = this.dao.insertViolationDelivery(delivery,unnormalFirm);
			if (returnCode == -1) {
				this.rollBack();
			}
			returnCode = deliveryManager.updateOrderTradeStatus(orderID, mode,delivery.getDeliveryType());
			if (returnCode == -1) {
				this.rollBack();
				return returnCode;
			}
			
			sApplyManagerImpl = (ISApplayManager) FinanceSysData
					.getBean(Constants.BEAN_SAPPLYMGR_MGR);
			//释放买方保证金授信金额	BuyCreditDeposit	
			BigDecimal buyCreditDeposit = order.getBuyCreditDeposit();
			returnCode = this.deliveryDAO.updateBuyCreditDeposit(order.getOrderId(),buyCreditDeposit,userName);
			if (returnCode == -1) {
				this.rollBack();
				return returnCode;
			}
			/**
			 * 释放授信流水
			 */
			
			try {
				if (goodTypes == 0) { // 现货
					returnCode = sApplyManagerImpl
							.backMargin(order.getBuyFirmId(), buyCreditDeposit,
									deliveryID, 3);
				} else {// 预售
					returnCode = sApplyManagerImpl
							.backMarginForPreSale(order.getBuyFirmId(), buyCreditDeposit,
									deliveryID, 3);
				}
				if(returnCode < 0){
					this.rollBack();
					return -1;
				}
			} catch (Exception e) {
				returnCode = -1;
				this.rollBack();
				return -1;
			}
			
			

		}else if (order.getTradeStatus() == 1 && unnormalFirm == 1) {
			this.deliveryDAO.finishedOrder(60, orderID);//订单状态 "卖家违约"
			int quantity = order.getQuantity();
			if(unnormalQuantity != quantity ){
				this.rollBack();
				return -24021;
			}
			
			delivery.setDeliveryQuantity(order.getQuantity());//违约数量 整体违约
			order.setUnnormalFirm(unnormalFirm);
			DeliveryExpenseUtil.setDeliveryExpenses(order, delivery, userName,deliveryDAO);
			
			
			String deliveryID = DeliveryExpenseUtil.setDeliveryID(orderID, dao);
			delivery.setDeliveryID(deliveryID);
			delivery.setDeliveryComment(deliveryComment);
			delivery.setLeadsID(order.getLeadsID());
			
			//交易场信息
			TradeTemplate tradeTemplate = this.deliveryDAO.getTradeTemplateByID(order.getTradeTmptId());
			DeliveryExpenseUtil.setViolationDeliveryExpenses(tradeTemplate, delivery);
			delivery.setProcessStatus(1);
			returnCode = this.dao.insertViolationDelivery(delivery,unnormalFirm);
			if (returnCode == -1) {
				this.rollBack();
			}
			returnCode = deliveryManager.updateOrderTradeStatus(orderID, mode,delivery.getDeliveryType());
			if (returnCode == -1) {
				this.rollBack();
				return returnCode;
			}
			
			sApplyManagerImpl = (ISApplayManager) FinanceSysData
					.getBean(Constants.BEAN_SAPPLYMGR_MGR);
			//释放买方保证金授信金额	BuyCreditDeposit	
			BigDecimal buyCreditDeposit = order.getBuyCreditDeposit();
			returnCode = this.deliveryDAO.updateBuyCreditDeposit(order.getOrderId(),buyCreditDeposit,userName);
			if (returnCode == -1) {
				this.rollBack();
				return returnCode;
			}
			/**
			 * 释放授信流水
			 */
			
			try {
				if (goodTypes == 0) { // 现货
					returnCode = sApplyManagerImpl
							.backMargin(order.getBuyFirmId(), buyCreditDeposit,
									deliveryID, 3);
				} else {// 预售
					returnCode = sApplyManagerImpl
							.backMarginForPreSale(order.getBuyFirmId(), buyCreditDeposit,
									deliveryID, 3);
				}
				if(returnCode < 0){
					this.rollBack();
					return -1;
				}
			} catch (Exception e) {
				returnCode = -1;
				this.rollBack();
				return -1;
			}
		}else {
			String deliveryID = DeliveryExpenseUtil.setDeliveryID(orderID, dao);
			
			int appliedQiamtity = this.dao.getAppliedQiamtity(orderID);
			int remainQiamtity  = order.getQuantity()-appliedQiamtity;//订单 未申请数量
			if (unnormalQuantity > remainQiamtity) {
				returnCode = -1;//交收违约 大于 可违约数量
			}

			delivery.setDeliveryQuantity(unnormalQuantity);
			order.setUnnormalFirm(unnormalFirm);
			DeliveryExpenseUtil.setDeliveryExpenses(order, delivery, userName,deliveryDAO);
			delivery.setDeliveryID(deliveryID);
			delivery.setDeliveryComment(deliveryComment);
			delivery.setLeadsID(order.getLeadsID());
			
			//交易场信息
			TradeTemplate tradeTemplate = this.deliveryDAO.getTradeTemplateByID(order.getTradeTmptId());
			//货品类型
			DeliveryExpenseUtil.setViolationDeliveryExpenses(tradeTemplate, delivery);
			delivery.setProcessStatus(1);
			returnCode = this.setOrderStatus(orderID,returnCode,unnormalQuantity,unnormalFirm);
			if(returnCode < 0){
				this.rollBack();
				return returnCode;
			}
			returnCode = this.dao.insertViolationDelivery(delivery,unnormalFirm);
			if (returnCode == -1) {
				this.rollBack();
				return returnCode;
			}
			returnCode = deliveryManager.updateOrderTradeStatus(orderID, mode,delivery.getDeliveryType());
			if (returnCode == -1) {
				this.rollBack();
				return returnCode;
			}
		}
//		int flag = 0;
//		if (deliveryList != null && deliveryList.size() > 0) {
//			
//			if (flag == deliveryList.size()) {
//				returnCode = this.deliveryDAO.finishedOrder(10,orderID);
//			}
//		}else {
//			order.setTradeStatus(5);
//			order.setREC_MODIFYBY(user.getName());
//			order.setREC_MODIFYTIME(new Date());
//			this.dao.updateOrderTradeStatus(order);
//		}
//		returnCode = this.dao.insertViolationDelivery(delivery,unnormalFirm);
//		if(returnCode == 1){
//			BigDecimal sellTakenTradeDeposit  = order.getSellTakenTradeDeposit();
//			BigDecimal sellCreditDeposit = order.getSellCreditDeposit();
//			BigDecimal buyTakenTradeDeposit = order.getBuyTakenTradeDeposit();
//			
//			// 退卖家交易保证金,收卖家交收保证金
//			FeeModel feeModelTmp = new FeeModel();
//			feeModelTmp.setTakenTradeFee(BigDecimal.ZERO);
//			feeModelTmp.setTakenTradeDeposit(sellTakenTradeDeposit);
//			feeModelTmp.setCreditFee(BigDecimal.ZERO);
//			feeModelTmp.setCreditDeposit(sellCreditDeposit);
//			
//			/**
//			 * 同时更新成交单的 "已申请交收数量（批）DeliveryQuantity" 
//			 */
////				this.dao.updateDeliveryQuantityForBreach(user, orderID, order.getQuantity());
//
//			boolean result = false;
//			// 退卖家交易保证金
//			result = firmBanlanceManager.backFeeAndDeposit(orderID, 5, order.getSellFirmId(), feeModelTmp, "交易违约时退卖家交易");
//			if (!result) {
//				this.dao.rollBack();
//				return -1;
//			}
//			
//			// 收卖家交收保证金
//			result = firmBanlanceManager.getFeeAndDepositDeli(deliveryID, 5, order.getSellFirmId(), feeModelTmp, "交易违约时收卖家交收");
//			if (!result) {
//				this.dao.rollBack();
//				return -1;
//			}
//			
//			feeModelTmp = new FeeModel();
//			feeModelTmp.setTakenTradeFee(BigDecimal.ZERO);
//			feeModelTmp.setTakenTradeDeposit(buyTakenTradeDeposit);
//			feeModelTmp.setCreditFee(BigDecimal.ZERO);
//			feeModelTmp.setCreditDeposit(BigDecimal.ZERO);
//			// 退买家已收交易保证金
//			result = firmBanlanceManager.backFeeAndDeposit(orderID, 5, order.getBuyFirmId(), feeModelTmp, "交易违约退买家");
//			if (!result) {
//				this.dao.rollBack();
//				return -1;
//			}
//			// 收买家交收保证金
//			result = firmBanlanceManager.getFeeAndDepositDeli(deliveryID, 5, order.getBuyFirmId(), feeModelTmp, "交易违约时收买家交收");
//			if (!result) {
//				this.dao.rollBack();
//				return -1;
//			}
//		}else{
//			this.dao.rollBack();
//		}
		return returnCode;
	}
	
	@Override
	public BigDecimal getDayAmount() {
		return this.orderDAO_read.getDayAmount();
	}
	/**
	 * 
	 */
	@Override
	public List<DailyTons> getDailyTons(String startDate, String endDate) {
		this.log.debug("getDailyTons component Start");
		return this.orderDAO_read.getDailyTons(startDate, endDate);
	}
	private void rollBack() {
		this.dao.rollBack();
	}
	
	/**
	 * 
	 */
	public List<OrderSumByTradeTemplate> getOrderSumByTradeTmptId(String startDate, String endDate) {
		this.log.debug("getOrderSumByTradeTmptId component Start");
		return this.orderDAO_read.getOrderSumByTradeTmptId(startDate,endDate);
	}
	
	/**
	 * 买家--待支付订单
	 */
	@Override
	public List<FirmAllData> getNotPaidOrderList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug(OrderManagerImpl.class+" getNotPaidOrderList component Start");
		List<FirmAllData> list = this.orderDAO_read.getNotPaidOrderList(qc,pageInfo);
		this.log.debug(OrderManagerImpl.class+" getNotPaidOrderList component End");
		return list;
	}
	@Override
	public List<Order> getOrderListByFirmID(String firmID,String startDate, String endDate) {
		List<Order> orderList = this.orderDAO_read.getOrderByBuyFirmID(firmID,startDate,endDate);
		if (orderList != null && orderList.size()>0) {
			for (int i = 0; i < orderList.size(); i++) {
				//买家已付金额
				BigDecimal takenMoneys = new BigDecimal(0);
				for (int j = 0; j < orderList.size(); j++) {
					//订单已付金额(已付货款+买方交收已扣手续费)
					Long takenMoneyTemp = this.deliveryDAO_read.getTakenMoneyByOrderID(orderList.get(j).getOrderId());
					BigDecimal takenMoney = new BigDecimal(takenMoneyTemp);
					takenMoneys.add(takenMoney);
				}
				//已付金额
				orderList.get(i).setTakenMoney(takenMoneys);
				//未付金额
				if (orderList.get(i).getTotalMoney().subtract(takenMoneys).compareTo(new BigDecimal(0))<=0) {
					orderList.remove(i);
				}else {
					orderList.get(i).setNotPaidMoney(orderList.get(i).getTotalMoney().subtract(takenMoneys));
				}
			}
		}
		return orderList;
	}
	
	/**
	 * 交收单列表
	 * @param qc 条件
	 * @param pageInfo 分页对象
	 * @return
	 */
	@Override
	public List<OrderDto> selectOrderList(QueryConditions qc, PageInfo pageInfo) {
		this.log.debug("selectOrderList component Start");
		List<OrderDto> list = orderDAO_read.selectOrderList(qc, pageInfo);
		return list;
	}
	
	/**
	 * 
	 * @param orderID
	 * @param returnCode
	 * @param unnormalQuantity 违约交收量
	 * @param unnormalFirm
	 * @return
	 */
	private int setOrderStatus(String orderID,int returnCode,int unnormalQuantity,int unnormalFirm) {
		//交收单号生成规则   订单号+两位有序数字
		List<Delivery> deliveryList = this.dao.getDeliveryList(orderID);
		Order order = this.dao.getOrderByOrderID(orderID);
		if (deliveryList != null && deliveryList.size() > 0) {
			List<Delivery> deliveryPassedList = this.deliveryDAO.getDeliveryListByOrderID(orderID);//该订单下所有交收（履约+违约）
			int deliveryQuantity = this.deliveryDAO.getDeliveryQuantity(orderID);//所有交收单（履约+违约）数量
			//根据交收单不同的状态对订单状态进行更新
			if ((deliveryPassedList != null && deliveryPassedList.size() > 0) && (deliveryList.size() == deliveryPassedList.size() &&
					order.getQuantity() == deliveryQuantity)) {	
				int flagSell = 0;
				int flagBuy = 0;
				int flagBuyAndSell=0;
				for (int i = 0; i < deliveryPassedList.size(); i++) {
					//交收状态：已传上家
					if (deliveryPassedList.get(i).getDeliveryStatus() == 20) {
						//订单状态：已传上家
						returnCode = this.deliveryDAO.finishedOrder(15, orderID);
						break;
					}
					//交收状态： 签收单已上传
					if (deliveryPassedList.get(i).getDeliveryStatus() == 25) {
						//订单状态：签收单已上传
						returnCode = this.deliveryDAO.finishedOrder(20, orderID);
						break;
					}
					//交收状态：物流签收数量已确认
					if (deliveryPassedList.get(i).getDeliveryStatus() == 30) {
						//订单状态：物流签收数量已确认
						returnCode = this.deliveryDAO.finishedOrder(25, orderID);
						break;
					}
					//交收状态： 待风控审核 
					if (deliveryPassedList.get(i).getDeliveryStatus() == 35) {
						//订单状态： 待风控审核 
						returnCode = this.deliveryDAO.finishedOrder(30, orderID);
						break;
					}
					//交收状态：风控审核通过 
					if (deliveryPassedList.get(i).getDeliveryStatus() == 40) {
						//订单状态：风控签收数量已确认
						returnCode = this.deliveryDAO.finishedOrder(40, orderID);
						break;
					}
					//交收状态： 风控拒绝 
					if (deliveryPassedList.get(i).getDeliveryStatus() == 45) {
						//订单状态： 物流签收数量已确认
						returnCode = this.deliveryDAO.finishedOrder(30, orderID);
						break;
					}
					//交收状态： 溢短处理中
					if (deliveryPassedList.get(i).getDeliveryStatus() == 50) {
						//订单状态：溢短处理中
						returnCode = this.deliveryDAO.finishedOrder(35, orderID);
						break;
					}
					//交收状态： 溢短处理中
					if (deliveryPassedList.get(i).getDeliveryStatus() == 50) {
						//订单状态：溢短处理中
						returnCode = this.deliveryDAO.finishedOrder(35, orderID);
						break;
					}
					//交收状态：交易完成
					if (deliveryPassedList.get(i).getDeliveryStatus() == 55) {
						//订单状态：交易完成
						returnCode = this.deliveryDAO.finishedOrder(50, orderID);
						break;
					}
					//违约特殊情况 :买家违约
					if (deliveryPassedList.get(i).getDeliveryStatus() == 60 ) {
						flagBuy++;
					}
					//违约特殊情况 :卖家违约
					if (deliveryPassedList.get(i).getDeliveryStatus() == 65) {
						flagSell++;
					}
					//双方违约情况
					if (deliveryPassedList.get(i).getDeliveryStatus() == 60 || deliveryPassedList.get(i).getDeliveryStatus() == 65) {
						flagBuyAndSell++;
					}
					
				}
//				if (flagBuy == deliveryPassedList.size()) {
//					
//					//买家违约
//					if (unnormalFirm == 0)returnCode = this.deliveryDAO.finishedOrder(55, orderID);//订单状态：买家违约
//					//双方违约
//					if (unnormalFirm == 1)returnCode = this.deliveryDAO.finishedOrder(65, orderID);//订单状态：双方违约
//				
//				}
//				if (flagSell == deliveryPassedList.size()) {
//					//双方违约
//					if (unnormalFirm == 0)returnCode = this.deliveryDAO.finishedOrder(65, orderID);//订单状态：双方违约
//					//卖家违约
//					if (unnormalFirm == 1)returnCode = this.deliveryDAO.finishedOrder(60, orderID);//订单状态：卖家违约
//				}
//				if (flagBuyAndSell == deliveryPassedList.size()) {
//					//双方违约
//					returnCode = this.deliveryDAO.finishedOrder(65, orderID);
//				}
			}
		}else {
			if (unnormalQuantity <= order.getQuantity()) {
//				//买家违约
//				if (unnormalFirm == 0)returnCode = this.deliveryDAO.finishedOrder(55, orderID);//订单状态：买家违约
//				//卖家违约
//				if (unnormalFirm == 1)returnCode = this.deliveryDAO.finishedOrder(60, orderID);//订单状态：卖家违约
			}else {
//				returnCode = -24001;
			}
		}
		return returnCode;
	}
	@Override
	public List<Order> queryOrderListForPaymentStatus(QueryConditions qc,
			PageInfo pageInfo,String userID) {
		List<Order> list ;
		list = dao.queryOrderListForPaymentStatus(qc, pageInfo);
		List<MRole> roleList = this.systemMgrDAO_read.getRoleListByUserId(userID);
		String roleCodes="";
		if(roleList != null && roleList.size() > 0){
			for (int i = 0; i <  roleList.size(); i++) {
				if(i > 0) roleCodes += ",";
				roleCodes +=roleList.get(i).getRoleCode();
			}
		}
		//货款申请权限
		if(roleCodes.indexOf(BusinessEnumConstants.RoleType.SubmitPayRoleCode.getValue()) != -1){
			if(list != null && list.size() > 0 ){
				for (int i = 0; i < list.size(); i++) {
					list.get(i).setSubmitPayRole(true);
				}
			}
		}else {
			if(list != null && list.size() > 0 ){
				for (int i = 0; i < list.size(); i++) {
					list.get(i).setSubmitPayRole(false);
				}
			}
		}
		//货款审核通过权限
		if(roleCodes.indexOf(BusinessEnumConstants.RoleType.AuditPayRoleCode.getValue()) != -1){
			if(list != null && list.size() > 0 ){
				for (int i = 0; i < list.size(); i++) {
					list.get(i).setAuditPayRole(true);
				}
			}
		}else {
			if(list != null && list.size() > 0 ){
				for (int i = 0; i < list.size(); i++) {
					list.get(i).setAuditPayRole(false);
				}
			}
		}
		
		return list;
	}
	public static void main(String[] args) {
		String roleCodes = "0601,0602";
		System.err.println(roleCodes.indexOf("0601"));
		System.err.println(Integer.parseInt("-5262"));
	}
	@Override
	public Order findOrderByOrderId(String OrderId) {
		return dao.findOrderByOrderId(OrderId);
	}

	@Override
	public int updateApplyOrderForPaymentStatusByOrderId(Order order) {
		this.log.info(this.getClass().getName()+" Component updateApplyOrderForPaymentStatusByOrderId Start");
		// 获取优惠券的Component
		ICouponComponnetManager couponComponnetManager = (ICouponComponnetManager) FinanceSysData.getBean(Constants.BEAN_COUPON_MGR);
		// 页面数据：卖方是否使用优惠券  0:否 1:是
		Integer isUseSellCoupon = order.getIsUseSellCoupon();
		// 页面数据：收滞纳金 = 应收滞纳
		BigDecimal lateFee = order.getReceivableSellLateFee();
		this.log.debug("应收滞纳金 :"+lateFee);
		int resultCode = 0;
		Order dbOrder = dao.findOrderByOrderId(order.getOrderId());
		if(dbOrder.getTradeType() == 2){
			isUseSellCoupon = 0;
		}
		// 货款 = 单价 * 总数量
		BigDecimal amount = dbOrder.getPrice().multiply(dbOrder.getTotalQuantity().subtract(dbOrder.getCanceledTotalWeight()));
		this.log.debug("货款:"+amount);
		// 卖方优惠券余额
		BigDecimal sellCouponBalance = new BigDecimal(0);
		if (isUseSellCoupon == 1){
			// 取得卖方优惠券信息
			Coupon coupon = couponComponnetManager.selectCouponByFirmID(dbOrder.getSellFirmId());
			if (coupon != null){
				sellCouponBalance = coupon.getBalance();
			}
		}
		this.log.debug("卖方优惠券余额:"+sellCouponBalance);
		// 收手续费 = 应收续费  - 已收手续费
		BigDecimal subWeight = dbOrder.getTotalQuantity().subtract(dbOrder.getCanceledTotalWeight());
		
		//已收手续费 = 已收资金+已收优惠券-已收解约申请手续费
		BigDecimal takenTradeFee = dbOrder.getSellTakenTradeFee().add(dbOrder.getSellCouponTradeFee()).subtract(dbOrder.getCanceledTotalReceivedTradeFee());
		BigDecimal free = dbOrder.getSellTradeFee().multiply(subWeight).divide(dbOrder.getTotalQuantity()).subtract(takenTradeFee);
		// 收手续费 >= 卖方优惠券余额
		if (free.compareTo(sellCouponBalance) >= 0){
			free = free.subtract(sellCouponBalance);
		}else{
			free = new BigDecimal(0);
		}
		this.log.debug("收手续费 :"+free);
		if (amount.compareTo(free.add(lateFee)) <= 0){
			resultCode = -23017;
			return resultCode;
		}
		// 校验付款状态
		resultCode = this.checkPaidAmount(order.getOrderId(),1);
		if (resultCode >= 0){
			dao.updateApplyOrderForPaymentStatusByOrderId(order);
		}
		this.log.info(this.getClass().getName()+" Component updateApplyOrderForPaymentStatusByOrderId End");
		return resultCode;
	}
	@Override
	public int updatePassOrderForPaymentStatusByOrderId(Order order) {
		this.log.info(this.getClass().getName()+" Component updatePassOrderForPaymentStatusByOrderId Start");
		int resultCode = 0;
		// 获取优惠券的Component
		ICouponComponnetManager couponComponnetManager = (ICouponComponnetManager) FinanceSysData.getBean(Constants.BEAN_COUPON_MGR);
		// 获取凭证的Component
		IVoucherManager voucherManager = (IVoucherManager) FinanceSysData.getBean(Constants.BEAN_VOUCHER_MGR);
		String orderId = order.getOrderId();
		// check付款状态
		resultCode = this.checkPaidAmount(orderId,2);
		if (resultCode < 0){
			return resultCode;
		}
		try {
			String currentUserName = order.getCurrentUserName();
			Order dbOrder = dao.findOrderByOrderId(orderId);
			
			String dbOrderSellFirmId = dbOrder.getSellFirmId();
			// 货款 = 单价 * 总数量
			BigDecimal amount = dbOrder.getPrice().multiply(dbOrder.getTotalQuantity().subtract(dbOrder.getCanceledTotalWeight()));
			this.log.debug("货款:"+amount);
			// 卖方是否使用优惠券  0:否 1:是
			Integer isUseSellCoupon = dbOrder.getIsUseSellCoupon();
			// 卖方优惠券余额
			BigDecimal sellCouponBalance = new BigDecimal(0);
			if (isUseSellCoupon == 1){
				// 取得卖方优惠券信息
				Coupon coupon = couponComponnetManager.selectCouponByFirmID(dbOrder.getSellFirmId());
				if (coupon != null){
					sellCouponBalance = coupon.getBalance();
				}
			}
			this.log.debug("卖方优惠券余额:"+sellCouponBalance);
			// 卖方手续费优惠券金额
			BigDecimal sellCouponTradeFee = new BigDecimal(0);
			// 收手续费 = 应收续费  - 已收手续费
			BigDecimal subWeight = dbOrder.getTotalQuantity().subtract(dbOrder.getCanceledTotalWeight());
			//已收手续费 = 已收资金+已收优惠券-已收解约申请手续费
			BigDecimal takenTradeFee = dbOrder.getSellTakenTradeFee().add(dbOrder.getSellCouponTradeFee()).subtract(dbOrder.getCanceledTotalReceivedTradeFee());
			BigDecimal free = dbOrder.getSellTradeFee().multiply(subWeight).divide(dbOrder.getTotalQuantity()).subtract(takenTradeFee);
			// 收手续费 >= 卖方优惠券余额
			if (free.compareTo(sellCouponBalance) >= 0){
				free = free.subtract(sellCouponBalance);
				sellCouponTradeFee = sellCouponBalance;
			}else{
				sellCouponTradeFee = free;
				free = new BigDecimal(0);
			}
			this.log.debug("收手续费 :"+free);
			this.log.debug("卖方手续费优惠券金额 :"+sellCouponTradeFee);
			// 收滞纳金 = 应收滞纳
			BigDecimal lateFee = dbOrder.getReceivableSellLateFee();
			this.log.debug("收滞纳金 :"+lateFee);
			if (amount.compareTo(free.add(lateFee)) <= 0){
				resultCode = -23017;
				return resultCode;
			}
			// 获取当前成交单下配送运费资金表 （修正bugID 4841 原：排除 70,75，现在：不排除 70,75）
			List<DeliveryFreightFee> deliveryFrightFeeList = deliveryDAO.selectDeliveryFrightFeeOrderId(orderId);
			// 初始化所有交收单【应付卖家运费】的总和
			BigDecimal shouldPaySellFreightAllDelivery = new BigDecimal(0);
			// 初始化所有交收单【运费调整额】的总和
			BigDecimal overloadFreightAllDelivery = new BigDecimal(0);
			// 初始化所有交收单【实付卖家运费】的总和
			BigDecimal trueShouldPaySellFreightAllDelivery = new BigDecimal(0);
			if (deliveryFrightFeeList != null ){
				for (DeliveryFreightFee deliveryFrightFee : deliveryFrightFeeList){
					BigDecimal shouldPaySellFreight = deliveryFrightFee.getShouldPaySellPenalty() == null  ? new BigDecimal(0) : deliveryFrightFee.getShouldPaySellPenalty();
					BigDecimal overloadFreight = deliveryFrightFee.getOverloadFreight() == null ? new BigDecimal(0) : deliveryFrightFee.getOverloadFreight();
					shouldPaySellFreightAllDelivery = shouldPaySellFreightAllDelivery.add(shouldPaySellFreight);
					overloadFreightAllDelivery = overloadFreightAllDelivery.add(overloadFreight);
				}
			}
			trueShouldPaySellFreightAllDelivery = trueShouldPaySellFreightAllDelivery.add(shouldPaySellFreightAllDelivery).add(overloadFreightAllDelivery);
			
			this.log.info("应付卖家运费总额："+ shouldPaySellFreightAllDelivery);
			this.log.info("运费调整总额："+ overloadFreightAllDelivery);
			this.log.info("实付卖家运费总额："+ trueShouldPaySellFreightAllDelivery);
			/**
			 * 更新相关状态
			 */
			// 已付金额 = 货款 -  收手续费  - 收滞纳金
			//order.setPaidSellAmount(amount.subtract(free).subtract(lateFee));
			order.setPaidSellAmount(amount);// 已付卖方货款金额 = 货款
			order.setSellTakenTradeFee(free.add(dbOrder.getSellTakenTradeFee()));
			order.setReceivedSellLateFee(lateFee);
			// 1.更新订单的【付款状态】为10：已付款
			int count = dao.updatePassOrderForPaymentStatusByOrderId(order);
			// 2.更新订单的【卖方手续费优惠券金额】
			if (sellCouponTradeFee.compareTo(new BigDecimal(0)) > 0){
				dao.updateOrderOfSellCouponTradeFee(sellCouponTradeFee, currentUserName, orderId);
			}
			// 3.更新订单的下所有交收单的【已付货款(PayedMoney)】
			List<Delivery> deliveryList =  deliveryDAO.getAllDeliveryListByOrderID(orderId);
			if (deliveryList != null && deliveryList.size() > 0){
				for (Delivery delivery : deliveryList){
					// 已付卖方金额,成交数量（批）,交收单表的交收数量 2016.11.18 删除原因，zhulingfen 在测试 违约 发现bug 
					//BigDecimal payedMoney = DeliveryExpenseUtil.getMoney(amount.subtract(free).subtract(lateFee), dbOrder.getQuantity(), delivery.getDeliveryQuantity()); 
					BigDecimal payedMoney = DeliveryExpenseUtil.getMoney(amount, dbOrder.getQuantity(), delivery.getDeliveryQuantity());
					// 根据DeliveryID 更新 交收表的【已付货款(PayedMoney)】
					deliveryDAO.updateDeliveryOfPayedMoneyByDeliveryID(delivery.getDeliveryID(), currentUserName, payedMoney);
				}
			}else{
				this.log.info(this.getClass().getName()+"没有查询到交收信息列表,成交单ID："+orderId);
			}
			
			// 4.更新成交单下 所有 已付卖家运费 = 应付卖家运费 + 运费调整额(一般是负值)
			int updCount = 0;
			if (trueShouldPaySellFreightAllDelivery.compareTo(new BigDecimal(0)) > 0){
				updCount = deliveryDAO.updateDeliveryFrightFeeOfPaidSellFreightByOrderID(orderId, currentUserName);
			}
			// 5.更新卖方优惠券余额
			if (sellCouponTradeFee.compareTo(new BigDecimal(0)) > 0){
				int resultCouponCode =  couponComponnetManager.getFee(dbOrder.getSellFirmId(), sellCouponTradeFee, orderId, 1, 2, currentUserName);// 卖方ID，使用优惠券金额，订单ID,2抵用，操作人
				if (resultCouponCode < 0){
					this.log.debug("更新卖方优惠券余额失败，卖方交易商ID："+dbOrder.getSellFirmId());
					couponComponnetManager.rollback();
					deliveryDAO.rollBack();
					dao.rollBack();
					resultCode = -23018;
					return  resultCode;
				}else{
					this.log.debug("更新卖方优惠券余额成功，卖方交易商ID："+dbOrder.getSellFirmId());
				}
			}
			
			// 真实付款
			if (count == 1){
				try {
					Integer code = voucherManager.createNewOldVoucher(Constants.VOUCHERMODE_FU_HUO_KUAN, amount, orderId,dbOrderSellFirmId , "付卖家货款", currentUserName);
					if (code >= 0){
						int voucherResultCode = 0;
						if (free.compareTo(new BigDecimal(0)) > 0){
							voucherResultCode = voucherManager.createNewOldVoucher(Constants.VOUCHERMODE_SHOU_JIAOYI_SHOUXUFEI, free, orderId, dbOrderSellFirmId, "收取卖家交易手续费",currentUserName);
							if (voucherResultCode < 0){
								this.log.debug("收取卖家交易手续费失败!voucherResultCode"+ voucherResultCode);
								voucherManager.rollback();
							}else{
								this.log.debug("收取卖家交易手续费成功!"+ free);
							}
						}
						if (lateFee.compareTo(new BigDecimal(0)) > 0 && voucherResultCode >= 0){
							voucherResultCode = voucherManager.createNewOldVoucher(Constants.VOUCHERMODE_SHOU_ZHI_NA_JIN, lateFee, orderId, dbOrderSellFirmId, "收取卖家滞纳金", currentUserName);
							if (voucherResultCode < 0){
								this.log.debug("收取卖家滞纳金失败!voucherResultCode:"+ voucherResultCode);
								voucherManager.rollback();
							}else{
								this.log.debug("收取卖家滞纳金成功!"+ lateFee);
							}
						}
						// 付卖家运费
						if (updCount != 0 && trueShouldPaySellFreightAllDelivery.compareTo(new BigDecimal(0)) > 0 && voucherResultCode >= 0){
							// 付运费
							voucherResultCode = voucherManager.createNewOldVoucher(Constants.VOUCHERMODE_FU_YUNFEI, trueShouldPaySellFreightAllDelivery, orderId, dbOrderSellFirmId, "付卖家运费", currentUserName);
							if (voucherResultCode < 0){
								this.log.debug("付卖家运费失败!voucherResultCode:"+ voucherResultCode);
								voucherManager.rollback();
							}else{
								this.log.debug("付卖家运费成功!"+ trueShouldPaySellFreightAllDelivery);
							}
						}
					}
				} catch (Exception e) {
					this.log.error("付卖家相关费用失败:"+e.getMessage());
					resultCode = -23019;
					voucherManager.rollback();
				}
			}
		} catch (Exception e) {
			this.log.error("更新卖家相关费用失败:"+e.getMessage());
			resultCode = -23019;
			this.rollBack();
			deliveryDAO.rollBack();
			couponComponnetManager.rollback();
		}
		this.log.info(this.getClass().getName()+" Component updatePassOrderForPaymentStatusByOrderId End");
		return resultCode;
	}
	@Override
	public int updateRefuseOrderForPaymentStatusByOrderId(String orderId,
			String remarks, String currentUserName) {
		return dao.updateRefuseOrderForPaymentStatusByOrderId(orderId, remarks, currentUserName);
	}
	
	/**
	 * 交收违约
	 * @param
	 * orderID：订单ID
	 * userID：申请人
	 * unnormalQuantity：申请违约数量 (买方未付化交，是整体违约；买方已付化交，是申请部分违约)
	 * unnormalFirm:违约方：0：买家违约  1：卖家违约
	 * deliveryComment 备注：违约原因
	 * @throws ParseException 
	 */
	@Override
	public String insertViolationDelivery_BreachContractApply(String orderID,String userName,int unnormalQuantity,int unnormalFirm,
			String deliveryComment,String mode)throws RuntimeException, ParseException{
		deliveryManager = (IDeliveryManager) TradeSysData
				.getBean(Constants.BEAN_DELIVERY_MGR);
		Order orders = this.deliveryDAO.getOrderByID(orderID);
		int goodTypes = Common.getGoodsType(orders.getTradeType());
		int canDeliveryQuantity = orders.getQuantity()
				- orders.getDeliveryQuantity();
		if(unnormalQuantity > canDeliveryQuantity){
			return "24001";
		}
		
		
		
		
		int returnCode = 0;
		// 订单已经申请的数量更新
		returnCode = this.deliveryDAO.updateDeliveryQuantity(unnormalQuantity,
				orderID, userName);
		if(returnCode == -1)return "";
		
		
		int minQuantity = orders.getMinQuantity();
		
		/*订单总量*/
		int totalQuantity = orders.getQuantity()-orders.getDeliveryQuantity();
		int numQuantity = totalQuantity - minQuantity;
		if((unnormalQuantity > numQuantity)&&(unnormalQuantity != totalQuantity)){
			deliveryDAO.rollBack();
			return "-24028";
		}
		
		
		firmBanlanceManager = (IFirmBanlanceManager) FinanceSysData.getBean(Constants.BEAN_BALANCE_MGR);
		
		Order order = this.dao.getOrderByOrderID(orderID);
		Delivery delivery = new Delivery();
		delivery.setDeliveryQuantity(unnormalQuantity);
		this.log.debug("insertViolationDelivery_BreachContractApply DAO");
		String deliveryID = DeliveryExpenseUtil.setDeliveryID(orderID, dao);
		/**
		 * 买方违约：买方未付化交，是整体违约
		 */
		if (order.getTradeStatus() == 1 && unnormalFirm == 0) {
			int quantity = order.getQuantity();
			if(unnormalQuantity != quantity ){
				this.rollBack();
				return "-24021";
			}
			this.deliveryDAO.finishedOrder(55, orderID);//订单状态 "买家违约"
			order.setUnnormalFirm(unnormalFirm);
			delivery.setDeliveryQuantity(order.getQuantity());//违约数量 整体违约
			DeliveryExpenseUtil.setDeliveryExpenses(order, delivery, userName,deliveryDAO);
			
			//更新订单状态 
			
			delivery.setDeliveryID(deliveryID);
			delivery.setDeliveryComment(deliveryComment);
			delivery.setLeadsID(order.getLeadsID());
			
			//交易场信息
			TradeTemplate tradeTemplate = this.deliveryDAO.getTradeTemplateByID(order.getTradeTmptId());
			//货品类型
			DeliveryExpenseUtil.setViolationDeliveryExpenses(tradeTemplate, delivery);
			
			returnCode = this.dao.insertViolationDelivery(delivery,unnormalFirm);
			if (returnCode == -1) {
				this.rollBack();
			}
			returnCode = deliveryManager.updateOrderTradeStatus(orderID, mode,delivery.getDeliveryType());
			if (returnCode == -1) {
				this.rollBack();
				return "";
			}
			
			//释放买方保证金授信金额	BuyCreditDeposit	
			BigDecimal buyCreditDeposit = order.getBuyCreditDeposit();
			// 买家家使用授信的金额
			returnCode = this.deliveryDAO.updateBuyCreditDeposit(order.getOrderId(),buyCreditDeposit,userName);
			if (returnCode == -1) {
				this.rollBack();
				return "";
			}
			sApplyManagerImpl = (ISApplayManager) FinanceSysData
					.getBean(Constants.BEAN_SAPPLYMGR_MGR);
			/**
			 * 释放授信流水
			 */
			try {
				
				if (goodTypes == 0) { // 现货
					returnCode = sApplyManagerImpl
							.backMargin(order.getBuyFirmId(), buyCreditDeposit,
									deliveryID, 3);
				} else {// 预售
					returnCode = sApplyManagerImpl
							.backMarginForPreSale(order.getBuyFirmId(), buyCreditDeposit,
									deliveryID, 3);
				}
				if(returnCode < 0){
					this.rollBack();
					return "";
				}
			} catch (Exception e) {
				returnCode = -1;
				this.rollBack();
				return "";
			}
			
		}else if (order.getTradeStatus() == 1 && unnormalFirm == 1) {
			this.deliveryDAO.finishedOrder(60, orderID);//订单状态 "卖家违约"
			order.setUnnormalFirm(unnormalFirm);
			delivery.setDeliveryQuantity(order.getQuantity());//违约数量 整体违约
			DeliveryExpenseUtil.setDeliveryExpenses(order, delivery, userName,deliveryDAO);
			
			delivery.setDeliveryID(deliveryID);
			delivery.setDeliveryComment(deliveryComment);
			delivery.setLeadsID(order.getLeadsID());
			
			//交易场信息
			TradeTemplate tradeTemplate = this.deliveryDAO.getTradeTemplateByID(order.getTradeTmptId());
			//货品类型
			DeliveryExpenseUtil.setViolationDeliveryExpenses(tradeTemplate, delivery);
			
			returnCode = this.dao.insertViolationDelivery(delivery,unnormalFirm);
			if (returnCode == -1) {
				this.rollBack();
			}
			returnCode = deliveryManager.updateOrderTradeStatus(orderID, mode,delivery.getDeliveryType());
			if (returnCode == -1) {
				this.rollBack();
				return "";
			}
			sApplyManagerImpl = (ISApplayManager) FinanceSysData
					.getBean(Constants.BEAN_SAPPLYMGR_MGR);
			//释放买方保证金授信金额	BuyCreditDeposit	
			BigDecimal buyCreditDeposit = order.getBuyCreditDeposit();
			// 买家家使用授信的金额
			returnCode = this.deliveryDAO.updateBuyCreditDeposit(order.getOrderId(),buyCreditDeposit,userName);
			if (returnCode == -1) {
				this.rollBack();
				return "";
			}
			
			/**
			 * 释放授信流水
			 */
			try {
				if (goodTypes == 0) { // 现货
					returnCode = sApplyManagerImpl
							.backMargin(order.getBuyFirmId(), buyCreditDeposit,
									deliveryID, 3);
				} else {// 预售
					returnCode = sApplyManagerImpl
							.backMarginForPreSale(order.getBuyFirmId(), buyCreditDeposit,
									deliveryID, 3);
				}
				if(returnCode < 0){
					this.rollBack();
					return "";
				}
			} catch (Exception e) {
				returnCode = -1;
				this.rollBack();
				return "";
			}
			
		}else {
			int appliedQiamtity = this.dao.getAppliedQiamtity(orderID);
			int remainQiamtity  = order.getQuantity()-appliedQiamtity;//订单 未申请数量
			if (unnormalQuantity > remainQiamtity) {
				returnCode = -1;//交收违约 大于 可违约数量
			}
			order.setUnnormalFirm(unnormalFirm);
			delivery.setDeliveryQuantity(unnormalQuantity);
			DeliveryExpenseUtil.setDeliveryExpenses(order, delivery, userName,deliveryDAO);
			delivery.setDeliveryID(deliveryID);
			delivery.setDeliveryComment(deliveryComment);
			delivery.setLeadsID(order.getLeadsID());
			
			returnCode = this.setOrderStatus(orderID,returnCode,unnormalQuantity,unnormalFirm);
			if(returnCode < 0){
				this.rollBack();
				return "";
			}
			
			//交易场信息
			TradeTemplate tradeTemplate = this.deliveryDAO.getTradeTemplateByID(order.getTradeTmptId());
			//货品类型
			DeliveryExpenseUtil.setViolationDeliveryExpenses(tradeTemplate, delivery);
			delivery.setProcessStatus(1);
			returnCode = this.dao.insertViolationDelivery(delivery,unnormalFirm);
			if (returnCode == -1) {
				this.rollBack();
				return "";
			}
			returnCode = deliveryManager.updateOrderTradeStatus(orderID, mode,delivery.getDeliveryType());
			if (returnCode == -1) {
				this.rollBack();
				return "";
			}
			
		}
		this.log.debug("insertViolationDelivery_BreachContractApply DAO END");
		return deliveryID;
	}
	@Override
	public List<Order> getOrderByBuyTraderId(String traderId) {
		List<Order> orderList = this.orderDAO_read.getOrderByBuyTraderId(traderId);
		return orderList;
	}
	
	@Override
	public List<Delivery> getDeliveryListByOrderID(String orderID) {
		String deliveryStatus = "20,25";
		List<Delivery> list = this.orderDAO_read.getDeliveryListByOrderID(orderID,deliveryStatus);
		return list;
	}
//	@Override
//	public int instertOrderPayment(OrderPayment orderPayment) {
//		this.log.info(this.getClass().getName() + "Component instertOrderPayment Start");
//		int count = dao.instertOrderPayment(orderPayment);
//		this.log.info(this.getClass().getName() + "Component instertOrderPayment End");
//		return count;
//	}
//	@Override
//	public int updateOrderPayment(String orderId, String remarks) {
//		this.log.info(this.getClass().getName() + "Component updateOrderPayment Start");
//		int count = dao.updateOrderPayment(orderId, remarks);
//		this.log.info(this.getClass().getName() + "Component updateOrderPayment End");
//		return count;
//	}
//	@Override
//	public List<OrderPaymentDto> selectOrderPayment(QueryConditions qc, PageInfo pageInfo) {
//		this.log.info(this.getClass().getName() + "Component selectOrderPayment Start");
//		List<OrderPaymentDto> orderPaymentDtoList = dao.selectOrderPayment(qc, pageInfo);
//		this.log.info(this.getClass().getName() + "Component selectOrderPayment End");
//		return orderPaymentDtoList;
//	}
	
	/**
	 * 获取滞纳金
	 * @param orderID 成交单ID
	 * @param tradeType 1：买方 2:卖方
	 * @return 
	 */
	@Override
	public Double getOrderForLateFee(String orderID,Integer tradeType) {
		this.log.info("getOrderForLateFee component Start");
		ITraderManager traderManager = (ITraderManager) TradeSysData.getBean(Constants.BEAN_TRDER_MGR);
		Double lateFee = 0.00;
		try {
			Order orderDB = orderDAO_read.findOrderByOrderId(orderID);
			if (orderDB == null ){
				this.log.info("没有找到成交单信息，成交单ID："+orderID);
			}else{
				// 交易场ID
				Integer tradeTmptId = orderDB.getTradeTmptId();
				// 交货结束日期
				Date deliveryEndDate = orderDB.getDelievryDate();// sql中已经修改了
				// 上家到货时间
				Date sellArrivalTime = orderDB.getSellArrivalTime();
				
				// 取得交易场MAP 
				Map<Integer,TradeTemplate> map = TradeTemplateConstant.getTradeTemplateList();
				TradeTemplate tradeTemplate = map.get(tradeTmptId);
				// 卖方滞纳费类型 0：自然日 1：工作日
				Integer sellerLateFeeType = tradeTemplate.getSellerLateFeeType();
				// 卖方滞纳费 元/吨/天
				BigDecimal sellerLateFee = tradeTemplate.getSellerLateFee();
				// 买方滞纳费类型 0：自然日 1：工作日
				Integer buyerLateFeeType = tradeTemplate.getBuyerLateFeeType();
				// 买方滞纳费 元/吨/天
				BigDecimal buyerLateFee = tradeTemplate.getBuyerLateFee();
				// 总数量（吨）
				BigDecimal totalQuantity = orderDB.getTotalQuantity();
				// 相差天数
				int days = 0;
				// 买方
				if (tradeType == 1){
					// 买方滞纳费类型 0：自然日
					if (buyerLateFeeType == 0){
						if (sellArrivalTime != null){
							sellArrivalTime = DateUtil.getAddDay(sellArrivalTime, 1);
							days = DateUtil.getBetweenStartDateAndEndDateOfDays(sellArrivalTime, new Date());
						}
					}else{// 买方滞纳费类型 1：工作日
						if (sellArrivalTime != null){
							sellArrivalTime = DateUtil.getAddDay(sellArrivalTime, 1);
							days = traderManager.countTradeDate(sellArrivalTime, null);
						}
					}
					if(days > 1){
						days = 1;
					}
					// 滞纳金=天数 * 吨数 * 滞纳费
					lateFee = buyerLateFee.multiply(new BigDecimal(days)).multiply(totalQuantity).doubleValue();
				}
				// 卖方
				if(tradeType == 2){
					// 卖方滞纳费类型 0：自然日
					if (sellerLateFeeType == 0){
						if (sellArrivalTime != null){
							days = DateUtil.getBetweenStartDateAndEndDateOfDays(deliveryEndDate, sellArrivalTime);
						}
					}else{//卖方滞纳费类型 1：工作日
						if (sellArrivalTime != null){
							days = traderManager.countTradeDate(deliveryEndDate, sellArrivalTime);
						}
					}
					
//					if (days > 5){
//						days = 5;
//					}

					// 滞纳金=天数 * 吨数 * 滞纳费
					lateFee = sellerLateFee.multiply(new BigDecimal(days)).multiply(totalQuantity).doubleValue();
				}

			}
		} catch (Exception e) {
			this.log.error("更新滞纳金失败"+e.getMessage());
			lateFee = -1.0;
		}
		this.log.info("getOrderForLateFee component End");
		return lateFee;
	}
	@Override
	public int updateOrderForBuyLateFee(String orderID, String userId,
			BigDecimal receivableBuyLateFee, BigDecimal receivedBuyLateFee) {
		this.log.info("updateOrderForBuyLateFee component Start");
		int count = dao.updateOrderForBuyLateFee(orderID, userId, receivableBuyLateFee, receivedBuyLateFee);
		this.log.info("updateOrderForBuyLateFee component End");
		return count;
	}
	@Override
	public int updateOrderForSellLateFee(String orderID, String userId,
			BigDecimal receivableSellLateFee, BigDecimal receivedSellLateFee) {
		this.log.info("updateOrderForSellLateFee component Start");
		int count = dao.updateOrderForSellLateFee(orderID, userId, receivableSellLateFee, receivedSellLateFee);
		this.log.info("updateOrderForSellLateFee component End");
		return count;
	}
	
	@Override
	public int updateOrderExportStatus(String orderId) {
		this.log.info("updateOrderExportStatus component Start");
		int count = 0;
		List<OrderOprRecord> orderOprList = dao.getOrderOprRecords(orderId, 1);
		if (orderOprList == null || orderOprList.size() == 0) {
			count = dao.updateOrderExportStatus(orderId);
		}
		this.log.info("updateOrderExportStatus component End");
		return count;
	}
	
	@Override
	public List<Order> getOrderPaymentList(QueryConditions qc, PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+" getOrderPaymentList component Start");
		List<Order> list = orderDAO_read.getOrderPaymentList(qc, pageInfo);
		this.log.info(this.getClass().getName()+" getOrderPaymentList component End");
		return list;
	}
	
	@Override
	public List<ProductOrder> getFeeByProductList(QueryConditions qc,
			PageInfo pageInfo,String startDate,String endDate) {
		this.log.info(this.getClass().getName()+" getOrderPaymentList component Start");
		List<ProductOrder> list = orderDAO_read.getFeeByProductList(qc, pageInfo,startDate,endDate);
		this.log.info(this.getClass().getName()+" getOrderPaymentList component End");
		return list;
	}
	@Override
	public List<ProductOrder> getFeeByFirmList(QueryConditions qc,
			PageInfo pageInfo,String startDate,String endDate) {
		this.log.info(this.getClass().getName()+" getFeeByFirmList component Start");
		List<ProductOrder> list = orderDAO_read.getFeeByFirmList(qc, pageInfo,startDate,endDate);
		this.log.info(this.getClass().getName()+" getFeeByFirmList component End");
		return list;
	}
	
	@Override
	public List<ProductOrder> getFeeBySellFirmList(QueryConditions qc,
			PageInfo pageInfo,String startDate,String endDate) {
		this.log.info(this.getClass().getName()+" getFeeBySellFirmList component Start");
		List<ProductOrder> list = orderDAO_read.getFeeBySellFirmList(qc, pageInfo, startDate,endDate);
		this.log.info(this.getClass().getName()+" getFeeBySellFirmList component End");
		return list;
	}
	
	@Override
	public List<ProductOrder> getFeeByBuyFirmList(QueryConditions qc,
			PageInfo pageInfo,String startDate,String endDate) {
		this.log.info(this.getClass().getName()+" getFeeByBuyFirmList component Start");
		List<ProductOrder> list = orderDAO_read.getFeeByBuyFirmList(qc, pageInfo,startDate,endDate);
		this.log.info(this.getClass().getName()+" getFeeByBuyFirmList component End");
		return list;
	}
	@Override
	public int updateOrderOfIsGoodsControllerByOrderId(Integer isGoodsController, String userId, String orderId) {
		this.log.info(this.getClass().getName()+" updateOrderOfIsGoodsControllerByOrderId component Start");
		int count = this.dao.updateOrderOfIsGoodsControllerByOrderId(isGoodsController, userId, orderId);
		this.log.info(this.getClass().getName()+" updateOrderOfIsGoodsControllerByOrderId component End");
		return count;
	}
	
	/**
	 * 中石化 上传配送信息文件
	 */
	@Override
	public int uploadDistributionFile(JSONArray uploadFileModelArrayArray,
			String userName) {
		int returnCode = 0;
		for (int i = 0; i < uploadFileModelArrayArray.length(); i++) {
			UploadFileModel uploadFileModel = (UploadFileModel)JsonUtil.jsonToBean(uploadFileModelArrayArray.getJSONObject(i), UploadFileModel.class);
			Long uploadFileModelID = this.dao.getUploadFileModelID(uploadFileModel.getOrderString(),uploadFileModel.getFileID(),uploadFileModel.getFileType());
			if(uploadFileModelID == -1){
				returnCode = this.dao.addOrderSinopecFile(uploadFileModel,userName);
				if(returnCode == -1){
					this.rollBack();
					return returnCode;
				}
			}else {
				returnCode = this.dao.updateOrderSinopecFile(userName,uploadFileModelID);
				if(returnCode == -1){
					this.rollBack();
					return returnCode;
				}
			}
		}
		return returnCode;
	}
	
	@Override
	public List<UploadFileModel> getgetDistributionFile(String orderId,int fileType) {
		List<UploadFileModel> list = new ArrayList<UploadFileModel>();
		list = this.orderDAO_read.getgetDistributionFile(orderId,fileType);
		return list;
	}
	
	@Override
	public int deleteDistributionFile(long[] uploadFileModelIDArray) {
		int returnCode = 0;
		String uploadFileModelIDs ="";
		for (int i = 0; i < uploadFileModelIDArray.length; i++) {
			if(i>0)uploadFileModelIDs +=",";
			uploadFileModelIDs += uploadFileModelIDArray[i];
		}
		returnCode = this.dao.deleteDistributionFile(uploadFileModelIDs);
		return returnCode;
	}
	
	
	/**
	 * 后台申请违约
	 * @param breachDeliveryArray
	 * @param userName
	 * @param mode
	 * @return
	 */
	@Override
	public int addBreachDelivey(JSONArray breachDeliveryArrayTemp,String userName, String mode) {
		int returnCode = 0;
		for (int i = 0; i < breachDeliveryArrayTemp.length(); i++) {
			BreachContractApply breachContractApply = (BreachContractApply) JsonUtil.jsonToBean(breachDeliveryArrayTemp.getJSONObject(i), BreachContractApply.class);
			
			/*撤销原来的交收单*/
			if(breachContractApply.getHistoryDeliveryID() != null && !(breachContractApply.getHistoryDeliveryID().equals("0"))){
				returnCode = this.cancelDelivey(breachContractApply.getHistoryDeliveryID(),userName);
				if(returnCode == -1){
					this.rollBack();
					return returnCode;
				}
				
			}
			String deliveryID="";
			try {
				deliveryID = this.insertViolationDelivery_BreachContractApply(breachContractApply.getOrderID(), userName, 
						breachContractApply.getQuantity(), breachContractApply.getOrigin(), breachContractApply.getDeliveryComment(), mode);
						
				if(!deliveryID.contains("JS")){
					this.log.error("后台申请违约失败");
					this.rollBack();
					return Integer.parseInt(deliveryID);
				}
			} catch (Exception e) {
				this.log.error("后台申请违约失败"+e.getMessage());
				this.rollBack();
				return returnCode = -24010;
			}
			
			/*违约单号*/
			String applyID = this.getApplyID("WY",breachContractApply.getOrderID());
			if(applyID.equals("")){
				this.rollBack();
				return -10121;
			}
			breachContractApply.setId(applyID);
			breachContractApply.setDeliveryID(deliveryID);
			returnCode = this.dao.addBreachContractApply(breachContractApply,userName);
			if(returnCode == -1){
				this.rollBack();
				return -24010;
			}
		}
		return returnCode;
	}
	
	/**
	 * 撤销交收单
	 * @param historyDeliveryID
	 * @param userName
	 * @return
	 */
	private int cancelDelivey(String historyDeliveryID, String userName) {
		int returnCode;
		deliveryManager =  (IDeliveryManager) TradeSysData
				.getBean(Constants.BEAN_DELIVERY_MGR);
		returnCode = this.deliveryManager.disabledNormalDelivery(historyDeliveryID, userName);
		return returnCode;
	}
	/**
	 * 获取违约申请单号
	 * @param string
	 * @param orderID
	 * @return
	 */
	private String getApplyID(String orderType, String orderID) {
		String applyID = this.dao.getApplyID(orderType,orderID);
		return applyID;
	}
	@Override
	public int updateOrderOfIsDisplayOrder(Integer isDisplayOrder,
			String userName, String orderID) {
		this.log.info(this.getClass().getName()+" updateOrderOfIsDisplayOrder component Start");
		int count = dao.updateOrderOfIsDisplayOrder(isDisplayOrder, userName, orderID);
		this.log.info(this.getClass().getName()+" updateOrderOfIsDisplayOrder component End");
		return count;
	}
	
	/**
	 * 调用规则引擎 check付款的状态
	 * @param orderId
	 * @param paymentType 1：申请付款 2：审核通过
	 * @return
	 */
	private int checkPaidAmount(String orderId,Integer paymentType){
		this.log.debug("checkPaidAmount Start");
		Order dbOrder = dao.findOrderByOrderId(orderId);
		int resultCode = 0;
		try {
			if (dbOrder != null){
				Integer tradeStatus = dbOrder.getTradeStatus();
				BigDecimal paidAmount = dbOrder.getPaidAmount();
				Integer settlementMethod = dbOrder.getSettlementMethod();// 1自提 11自提或转货权 21中石化配送
				Integer paymentStatus = dbOrder.getPaymentStatus();// 0：待付款  5：待审核 10：已付款 15: 已拒绝
				BigDecimal paidSellAmount = dbOrder.getPaidSellAmount();// 已付卖方金额
				// 设定规则引擎的参数
				PaymentStatusPost paymentStatusPost = new PaymentStatusPost();
				PaymentStatus bean = new PaymentStatus();
				bean.setTradeStatus(tradeStatus);
				bean.setPaymentType(paymentType);
				bean.setPaymentStatus(paymentStatus);
				bean.setPaidAmount(paidAmount);
				bean.setSettlementMethod(settlementMethod);
				bean.setPaidSellAmount(paidSellAmount);
				bean.setViolationWeight(dbOrder.getViolationWeight());
				bean.setTotalQuantity(dbOrder.getTotalQuantity());
				// 交易场类型
				bean.setTradeType(dbOrder.getTradeType());
				bean.setIsGoodsController(dbOrder.getIsGoodsController());
				bean.setAllDeliveryWeight(dbOrder.getAllDeliveryWeight());
				bean.setNormalDeliveryWeight(dbOrder.getNormalDeliveryWeight());
				bean.setLogisticsMarkDeliveryWeight(dbOrder.getLogisticsMarkDeliveryWeight());
				// 调用规则引擎
				JSONObject rtn = paymentStatusPost.postPaymentStatusDrools(bean, this.getMode());
				String code = rtn.getString("CODE");
				if (!"00000".equals(code)) {
					this.log.error(this.getClass().getName() + "component 调用规则引擎[CheckPaymentStatus]失败,规则引擎返回CODE：" + code);
					return -10115;
				}
				JSONObject data = new JSONObject(rtn.getString("DATA"));
				resultCode = data.getInt("backendCode");
				int processPoint = data.getInt("processPoint");
				this.log.debug("规则引擎的处理过程点（processPoint）："+processPoint);
			}else{
				this.log.error("当前申请付款的成交单ID["+orderId+"]不存在！");
				resultCode = -23009;
			}
		} catch (Exception e) {
			this.log.error(" 调用规则引擎[CheckPaymentStatus]异常"+e.getMessage());
			resultCode = -10115;
		}
		this.log.debug("checkPaidAmount End");
		return resultCode;
	}
	@Override
	public List<OrderDto> getOrderWaitSignList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug(this.getClass().getName()+".getOrderWaitSignList Start");
		List<OrderDto> list = orderDAO_read.getOrderWaitSignList(qc, pageInfo);
		this.log.debug(this.getClass().getName()+".getOrderWaitSignList End");
		return list;
	}
	@Override
	public List<Order4Export> exportOrderList(QueryConditions qc, PageInfo pageInfo, boolean replace) {
		this.log.debug(this.getClass().getName()+".exportOrderList Start");
		List<Order4Export> list = orderDAO_read.exportOrderList(qc, pageInfo,replace);
		this.log.debug(this.getClass().getName()+".exportOrderList End");
		return list;
	}
	
	@Override
	public int getExportOrderCount(QueryConditions qc, PageInfo pageInfo) {
		this.log.debug(this.getClass().getName()+".exportOrderList Start");
		int totalCount = this.orderDAO_read.getExportOrderCount(qc,pageInfo);
		this.log.debug(this.getClass().getName()+".exportOrderList End");
		return totalCount;
	}
	@Override
	public List<CancelContract> getCancelList(QueryConditions qc, PageInfo pageInfo) {
		return this.orderDAO_read.getCancelList(qc, pageInfo);
	}
	@Override
	public CancelContract getCancelDetail(String KeyID) {
		return this.orderDAO_read.getCancelDetail(KeyID);
	}
	@Override
	public int uploadXSSF(String orderId, String XSSFNumber, String userID) {
		return this.dao.uploadXSSF(orderId, XSSFNumber, userID);
	}
	@Override
	public boolean ifXSSFAdmin(String userId) {
		return this.dao.ifXSSFAdmin(userId);
	}
	
	/**
	 * 通过检索条件查询一条或多条Order记录(线性-今日成交)
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	@Override
	public List<OrderLiner> getSimpleLinerOrderList(QueryConditions qc, PageInfo pageInfo) {
		return this.orderDAO_read.getSimpleLinerOrderList(qc, pageInfo);
	}
	@Override
	public int updateIsPaySellerMoneyByOrderId(String userName, String orderId) {
		this.log.info(this.getClass().getName()+" updateIsPaySellerMoneyByOrderId component Start");
		int count = this.dao.updateIsPaySellerMoneyByOrderId(userName, orderId);
		this.log.info(this.getClass().getName()+" updateIsPaySellerMoneyByOrderId component End");
		return count;
		
	}
	@Override
	public MailConfig getMailConfig(String mailKey) {
		return this.orderDAO_read.getMailConfig(mailKey);
	}
	@Override
	public int updateIsOutMoneyCus(String orderId, String modifyBy) {
		return this.dao.updateIsOutMoneyCus(orderId, modifyBy);
	}
	@Override
	public int updateIsOutMoneyRisk(String orderId, String modifyBy) {
		return this.dao.updateIsOutMoneyRisk(orderId, modifyBy);
	}
}
