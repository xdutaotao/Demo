package shcem.trade.component.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.json.JSONObject;

import com.sun.org.apache.xpath.internal.operations.Or;

import scem.activiti.ActivitiFactory;
import scem.activiti.model.ProcessInstance;
import scem.activiti.model.ProcessInstanceParams;
import scem.activiti.model.Task;
import scem.activiti.model.TaskParams;
import scem.activiti.model.VariableParams;
import scem.drools.DealStatus;
import shcem.base.component.impl.BaseManager;
import shcem.common.dao.CommonDAO;
import shcem.constant.BusinessEnumConstants;
import shcem.constant.Constants;
import shcem.finance.component.IVoucherManager;
import shcem.finance.util.FinanceSysData;
import shcem.logistics.dao.model.LogisticsTemplatePrice;
import shcem.systemMgr.dao.ISystemMgrDAO;
import shcem.systemMgr.dao.model.MUser;
import shcem.systemMgr.dao.model.UaacUser;
import shcem.trade.component.IDeliveryManager;
import shcem.trade.component.IDistributionMgr;
import shcem.trade.dao.IDeliveryDAO;
import shcem.trade.dao.IDistributionDao;
import shcem.trade.dao.OrderDAO;
import shcem.trade.dao.model.DelDistributionDetail;
import shcem.trade.dao.model.Delivery;
import shcem.trade.dao.model.DeliveryFreightFee;
import shcem.trade.dao.model.DeliveryOpeLog;
import shcem.trade.dao.model.Order;
import shcem.trade.util.DeliveryExpenseUtil;
import shcem.trade.util.TradeSysData;

public class DistributionMgrImpl extends BaseManager implements
		IDistributionMgr {

	private IDistributionDao distributionDao;
	
	private IDistributionDao distributionDao_read;

	public void setDistributionDao_read(IDistributionDao distributionDao_read) {
		this.distributionDao_read = distributionDao_read;
	}

	private OrderDAO orderDAO;

	private IDeliveryDAO deliveryDAO;

	private ISystemMgrDAO systemMgrDAO;

	private IDeliveryManager deliveryManager;

	private IVoucherManager voucherMgr;

	public void setDistributionDao(IDistributionDao distributionDao) {
		this.distributionDao = distributionDao;
	}

	public void setOrderDAO(OrderDAO orderDAO) {
		this.orderDAO = orderDAO;
	}

	public void setDeliveryDAO(IDeliveryDAO deliveryDAO) {
		this.deliveryDAO = deliveryDAO;
	}

	public void setSystemMgrDAO(ISystemMgrDAO systemMgrDAO) {
		this.systemMgrDAO = systemMgrDAO;
	}

	@Override
	public int addDistribution(Delivery delivery, String userID, String mode) {
		int returnCode = 0;

		Order order = this.orderDAO.getOrderByOrderID(delivery.getOrderID());
		/* 新增交收：数据校验 */
		returnCode = this.checkApplyDelivery(delivery);
		if (returnCode < 0)
			return returnCode;

		// 交收单号生成规则 订单号+两位有序数字
		String deliveryID = DeliveryExpenseUtil.setDeliveryID(
				order.getOrderId(), orderDAO);
		order.setUnnormalFirm(100);
		try {
			DeliveryExpenseUtil.setDeliveryExpenses(order, delivery, userID,
					deliveryDAO);
		} catch (ParseException e) {
			this.log.info(this.getClass().getName()+" 交收分摊订单费用出错");
			e.printStackTrace();
			return -1;
		}

		delivery.setDeliveryID(deliveryID);
		delivery.setDeliveryType(1);
		returnCode = this.deliveryDAO.addNormalDelivery(delivery, userID);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode = -24004;
		}

		/**
		 * 配送子表 T_DelDistributionDetail
		 */
		DelDistributionDetail detail = DeliveryExpenseUtil
				.getDelDistributionDetail(delivery, order, userID);
		try {
			returnCode = this.distributionDao.addDelDistributionDetail(detail);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (returnCode == -1) {
			this.rollBack();
			return returnCode = -24004;
		}

		/**
		 * 配送运费资金表 T_DeliveryFreightFee
		 */
		DeliveryFreightFee deliveryFreightFee = DeliveryExpenseUtil
				.getDeliveryFreightFee(delivery, order, userID);
		returnCode = this.distributionDao
				.addDeliveryFreightFee(deliveryFreightFee);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode = -24004;
		}

		// 订单已经申请的数量更新
		returnCode = this.deliveryDAO.updateDeliveryQuantity(
				delivery.getDeliveryQuantity(), delivery.getOrderID(), userID);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode = -24004;
		}

		returnCode = this.updateOrderTradeStatus(order.getOrderId(), mode,
				delivery.getDeliveryType());
		if (returnCode == -1) {
			this.rollBack();
			return returnCode = -24002;
		}

		/**
		 * 开启交收流程
		 */
		List<VariableParams> variables = new ArrayList<VariableParams>();

		VariableParams deliveryType = new VariableParams();
		// 是否前台客户提交
		deliveryType.setName("deliveryType");
		// 交收方式：1 配送
		deliveryType.setValue(1);

		// 下一节点操作人员 (物流审核人员)
		VariableParams uploadReceiptForm = new VariableParams();
		uploadReceiptForm.setName("uploadReceiptFormUser");
		String roleCodes = BusinessEnumConstants.RoleType.LogisticsAuditRoleCode
				.getValue();
		uploadReceiptForm.setValue(this.getUser(roleCodes));

		// // 并行节点（履约OR违约）0：履约 1：违约
		// VariableParams breachPromiseUsers = new VariableParams();
		// breachPromiseUsers.setName("breachPromiseUsers");
		// breachPromiseUsers.setValue(this.getUser(roleCodes));

		variables.add(deliveryType);
		variables.add(uploadReceiptForm);
		// variables.add(breachPromiseUsers);

		JSONObject rtnJso = startProcessInstance(deliveryID, "Deliverable",
				mode, userID, variables);
		if (!rtnJso.getString("CODE").equals("OK")) {
			this.rollBack();
			returnCode = -24005;
		} else {
			try {
				JSONObject JSONParams = new JSONObject(rtnJso.getString("DATA"));
				String processInstanceID = JSONParams.getString("id");
				returnCode = this.deliveryDAO.updateDeliveryProcessInstanceID(
						processInstanceID, deliveryID, userID);
				if (returnCode == -1) {
					this.rollBack();
					return returnCode = -1;
				}
				Integer[] userIds = this.getUserID(roleCodes);
				// 推送消息
				returnCode = this.pushMessage(mode, userIds, userID,
						"请物流审核人员审核交收申请", "app.deliveryDetail.logistic",
						deliveryID);
				if (returnCode == -1) {
					this.rollBack();
					return returnCode = -24006;
				}
			} catch (Exception e) {
				e.printStackTrace();
				this.rollBack();
				returnCode = -1;
			}
		}
		this.addDeliveryOpeLog(deliveryID, userID, "物流部门发起交收申请", "");

		return returnCode;
	}

	private int updateOrderTradeStatus(String orderID, String mode,
			int deliveryType) {
		int returnCode = 0;
		deliveryManager = (IDeliveryManager) TradeSysData
				.getBean(Constants.BEAN_DELIVERY_MGR);
		Order order = this.deliveryDAO.getOrderByID(orderID);
		int quantity = order.getQuantity();// 成交数量
		int deliveryQuantity = this.deliveryDAO.getDeliveryQuantity(order
				.getOrderId());// 已申请交收数量（批）
		int deliverySinopecQuantity = this.deliveryDAO.getDeliverySinopecQuantity(orderID);
		try {
			DealStatus dealStatus = this.deliveryManager
					.findOrderStatusFormDrools(order.getOrderId(), mode,
							quantity, deliveryQuantity, deliveryType,deliverySinopecQuantity);
			// 配送
			dealStatus.setDeliveryType(1);
			// 对订单状态进行更新
			if (dealStatus != null)
				returnCode = this.deliveryDAO.finishedOrder(
						dealStatus.getBackendCode(), order.getOrderId());
			if (dealStatus == null)
				returnCode = -1;
		} catch (Exception e) {
			this.rollBack();
			return returnCode = -1;
		}
		return returnCode;
	}

	@Override
	public int updateDistribution(DelDistributionDetail delDistributionDetail,
			String userID) {
		this.log.info(this.getClass() + "updateDistribution Start");
		int returnCode = 0;
		Delivery delivery = this.deliveryDAO
				.getDeliveryByID(delDistributionDetail.getDeliveryID());
		Order order = this.deliveryDAO
				.getOrderByDeliveryID(delDistributionDetail.getDeliveryID());
		
		delivery.setFreightFee(delDistributionDetail.getFreightFee());
	    delivery.setSmallFee(delDistributionDetail.getSmallFee());
	    
	    /* 运费 */
	    BigDecimal freightFee = new BigDecimal(delivery.getDeliveryQuantity())
		.multiply(order.getTradeUnitNumber())
		.multiply(delDistributionDetail.getFreightFee())
		.divide(new BigDecimal(1), 2, BigDecimal.ROUND_CEILING);
	    delDistributionDetail.setFreightFee(freightFee);
		
	    returnCode = this.distributionDao.updateDistribution(
				delDistributionDetail, userID);
		if (returnCode == -1)
			this.rollBack();
		
		/*配送运费资金表 T_DeliveryFreightFee*/
		DeliveryFreightFee deliveryFreightFee = DeliveryExpenseUtil.getDeliveryFreightFee(delivery, order, userID);
		returnCode = this.distributionDao.updateDeliveryFreightFee(deliveryFreightFee,userID);
		if (returnCode == -1){
			this.rollBack();
			return returnCode;
		}
			
		this.log.info(this.getClass() + "updateDistribution End");
		return returnCode;
	}

	@Override
	public List<LogisticsTemplatePrice> getLogisticsPrice(int categoryLeafID,
			int brandID, int sourcePlaceID, int logisticsLeafID) {
		List<LogisticsTemplatePrice> price = this.distributionDao_read.getLogisticsPrice(
				categoryLeafID, brandID, sourcePlaceID, logisticsLeafID);
		return price;
	}

	/**
	 * 取消中石化交收配送
	 */
	@Override
	public int cancelDistribution(String deliveryID, String userID) {
		this.log.info(this.getClass().getName()
				+ " cancelDistribution Component Start");
		int returnCode = 0;
		Order order = this.deliveryDAO.getOrderByDeliveryID(deliveryID);
		/* 更新交收状态：已取消,并且相关交收费用全部置为0 */
		returnCode = this.deliveryDAO.updateDeliveryStatus4Distribution(75, deliveryID,
				userID);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}
		
		DeliveryFreightFee deliveryFrightFee = this.deliveryDAO
				.selectDeliveryFrightFeeByDeliveryID(deliveryID);// 配送运费资金表详情
		BigDecimal buyPaidFreight = deliveryFrightFee.getBuyPaidFreight();
		
		/*应付卖家运费置为0 ShouldPaySellPenalty*/
		returnCode = this.distributionDao.updateShouldPaySellPenalty(deliveryID,userID,new BigDecimal(0));
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}
		
		returnCode = this.distributionDao.updateBuyPaidFreight(deliveryID,userID,new BigDecimal(0));
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}

		/* 退买家 已收运费 */
		voucherMgr = (IVoucherManager) FinanceSysData
				.getBean(Constants.BEAN_VOUCHER_MGR);

		if (buyPaidFreight.compareTo(new BigDecimal(0)) > 0) {
			returnCode = this.voucherMgr.createNewOldVoucher(
					Constants.VOUCHERMODE_TUI_YUNFEI,
					buyPaidFreight, deliveryID,
					order.getBuyFirmId(), "退买家运费", userID);
			if (returnCode < 0)
				this.rollBack();
		}
		this.log.info(this.getClass().getName()
				+ " cancelDistribution Component End");
		return returnCode;
	}

	/**
	 * 在取消交收单子的基础上发起交收申请(中石化)
	 */
	@Override
	public int applyDistributionByDelivery(Delivery delivery, String userID,String mode) {
		this.log.info(this.getClass().getName()
				+ " cancelDistribution applyDistributionByDelivery Start");
		int returnCode = 0;
		Order order = this.orderDAO.getOrderByOrderID(delivery.getOrderID());
		
		/*在取消交收单子的基础上发起交收申请(中石化)的数据校验*/
		returnCode = this.checkApplyDeliveryWitHistoryDelivery(delivery, order);
		if(returnCode < 0) return returnCode;

		
		
		String deliveryID = DeliveryExpenseUtil.setDeliveryID(order.getOrderId(), orderDAO);// 交收单号生成规则 订单号+两位有序数字
		/*新增中石化配送基础数据*/
		returnCode = this.addDistributionDatabase(order,delivery,userID,deliveryID);
		if(returnCode < 0) return returnCode;
		/*更新交收DeliveryQuantity*/
		returnCode = this.distributionDao.updateDeliveryQuantity(delivery.getHistoryDeliveryID(),delivery.getDeliveryQuantity());
		if(returnCode == -1){
			this.rollBack();
			return returnCode;
		}
		/*中石化配送重新开启流程*/
		List<VariableParams> variables = new ArrayList<VariableParams>();

		VariableParams deliveryType = new VariableParams();
		deliveryType.setName("deliveryType");
		// 交收方式：中石化拆单 
		deliveryType.setValue(11);

		/*中石化取消配送，重新发起流程(中石化拆单)下一节点操作人员 (中石化配送拆单审核人员)*/
		VariableParams riskControlAuditDistribution = new VariableParams();
		riskControlAuditDistribution.setName("riskVerifyDistributionUsers");
		String roleCodes = BusinessEnumConstants.RoleType.SinopecAuditRoleCode.getValue();
		riskControlAuditDistribution.setValue(this.getUser(roleCodes));

		variables.add(deliveryType);
		variables.add(riskControlAuditDistribution);

		JSONObject rtnJso = startProcessInstance(deliveryID, "Deliverable",
				mode, userID, variables);
		this.log.info(this.getClass().getName()+" 开启工作流返回json参数："+rtnJso.toString());
		if (!rtnJso.getString("CODE").equals("OK")) {
			this.rollBack();
			returnCode = -24005;
		} else {
			try {
				JSONObject JSONParams = new JSONObject(rtnJso.getString("DATA"));
				String processInstanceID = JSONParams.getString("id");
				returnCode = this.deliveryDAO.updateDeliveryProcessInstanceID(
						processInstanceID, deliveryID, userID);
				if (returnCode == -1) {
					this.rollBack();
					return returnCode = -1;
				}
				Integer[] userIds = this.getUserID(roleCodes);
				// 推送消息
				returnCode = this.pushMessage(mode, userIds, userID,
						"请风控审核人员审核交收申请", "app.deliveryDetail.riskControl",
						deliveryID);
				if (returnCode == -1) {
					this.rollBack();
					return returnCode = -24006;
				}
			} catch (Exception e) {
				e.printStackTrace();
				this.rollBack();
				returnCode = -1;
				return returnCode;
			}
		}
		this.addDeliveryOpeLog(deliveryID, userID, "物流部门重新发起交收申请(中石化拆单)", "");

		this.log.info(this.getClass().getName()
				+ " cancelDistribution applyDistributionByDelivery End");
		return returnCode;
	}

	/**
	 * 取消中石化交收配送，重新发起交收申请，风控审核通过(运费直接扣除)
	 */
	@Override
	public int reviewedDistributionApply(String deliveryID, String userID,
			String mode,String taskID) {
		this.log.info(this.getClass().getName()+" reviewedDistributionApply Component Start");
		int returnCode = 0;
		Order order = this.deliveryDAO.getOrderByDeliveryID(deliveryID);
		DeliveryFreightFee deliveryFreightFee = this.deliveryDAO.getDeliveryFreightFee(deliveryID);
		BigDecimal buyShouldPayFreight = deliveryFreightFee.getBuyShouldPayFreight();
		
		/*中石化拆单审核通过并且，更新交收状态:已付运费*/
		returnCode = this.distributionDao.updateUpdateLogisticalDetStatus(17, deliveryID, userID,5);
		if(returnCode == -1) return returnCode;

		/*更新配送运费资金表：买家已付运费BuyPaidFreight*/
		returnCode = this.distributionDao.updateDeliveryFreightFeeBuyPaidFreight(deliveryID,userID,buyShouldPayFreight);
		if(returnCode == -1){
			this.rollBack();
			return -30000;
		}
		
		/*扣除买家运费*/
		voucherMgr = (IVoucherManager) FinanceSysData.getBean(Constants.BEAN_VOUCHER_MGR);
		returnCode = this.voucherMgr.createNewOldVoucher(Constants.VOUCHERMODE_SHOU_YUNFEI,
				buyShouldPayFreight, deliveryID,order.getBuyFirmId() , "收买家运费", userID);
		if(returnCode < 0){
			this.log.info(this.getClass().getName()+" reviewedDistributionApply 取消中石化交收配送，重新发起交收申请，"
					+ "风控审核通过(运费直接扣除)失败：失败代码"+returnCode);
			this.rollBack();
			return -60003;
		}
		
		/**
		 * 拆单审核通过，进入下一个流程节点
		 */
		List<VariableParams> variables = new ArrayList<VariableParams>();
		// 认领任务
		JSONObject rtnJso = claimTask(taskID, userID, mode, userID);
		String resultCode = rtnJso.getString("CODE");
		// 完成任务
		if (resultCode.equals("OK")) {
			// 风控审核通过中石化拆单申请
			VariableParams riskDistributionApproved = new VariableParams();
			riskDistributionApproved.setName("riskDistributionApproved");
			riskDistributionApproved.setValue(1);
			variables.add(riskDistributionApproved);

			// 审核通过的同时，指定下一个任务节点的操作人员(风控普通操作员)
			VariableParams uploadReceiptForm = new VariableParams();
			uploadReceiptForm.setName("uploadReceiptFormUser");
			String roleCodes = BusinessEnumConstants.RoleType.LogisticsAuditRoleCode
					.getValue();
			uploadReceiptForm.setValue(this.getUser(roleCodes));
			variables.add(uploadReceiptForm);

			rtnJso = this.completeTask(variables, mode, userID, taskID);
			resultCode = rtnJso.getString("CODE");
			if (!resultCode.equals("OK")) {
				this.log.error(this.getClass().getName()+" completeTask 完成流程任务失败");
				this.rollBack();
				returnCode = -24008;
			} else {
				Integer[] userIds = this.getUserID(roleCodes);
				// 推送消息
				returnCode = this.pushMessage(mode, userIds, userID,
						"中石化交收配送申请拆单，风控审核通过，请物流审核人员审核",
						"app.deliveryDetail.logistic", deliveryID);
				if (returnCode == -1) {
					this.rollBack();
					return -24008;
				}
			}
		}else {
			this.log.error(this.getClass().getName()+" claimTask 认领流程任务失败");
			this.rollBack();
			returnCode = -24008;
			return returnCode;
		}
		
		this.log.info(this.getClass().getName()+" reviewedDistributionApply Component End");
		return returnCode;
	}

	/**
	 * 取消中石化交收配送，重新发起交收申请，风控审核拒绝
	 */
	@Override
	public int reviewedNotDistributionApply(String deliveryID, String userID,
			String mode, String taskID) {
		this.log.info(this.getClass().getName()+" reviewedNotDistributionApply Component Start");
		int returnCode = 0;
		
		/*风控审核拒绝中石化拆单申请，更新 '配送变更-审核状态' */
		returnCode = this.distributionDao.updateUpdateLogisticalDetStatus(1, deliveryID, userID,10);
		if(returnCode == -1) return returnCode;
		
		/**
		 * 拆单审核拒绝，返回原来流程节点
		 */
		List<VariableParams> variables = new ArrayList<VariableParams>();
		// 认领任务
		JSONObject rtnJso = claimTask(taskID, userID, mode, userID);
		String resultCode = rtnJso.getString("CODE");
		// 完成任务
		if (resultCode.equals("OK")) {
			// 风控审核通过中石化拆单申请
			VariableParams riskDistributionApproved = new VariableParams();
			riskDistributionApproved.setName("riskDistributionApproved");
			riskDistributionApproved.setValue(0);
			variables.add(riskDistributionApproved);

			// 审核拒绝的同时，指定下一个任务节点的操作人员(物流操作员)
			VariableParams deliveryModifyDistribution = new VariableParams();
			deliveryModifyDistribution.setName("deliveryModifyDistributionUsers");
			String roleCodes = BusinessEnumConstants.RoleType.LogisticsGeneralerRoleCode
					.getValue();
			deliveryModifyDistribution.setValue(this.getUser(roleCodes));
			variables.add(deliveryModifyDistribution);

			rtnJso = this.completeTask(variables, mode, userID, taskID);
			resultCode = rtnJso.getString("CODE");
			if (!resultCode.equals("OK")) {
				this.log.error(this.getClass().getName()+" completeTask 完成流程任务失败");
				this.rollBack();
				returnCode = -24008;
			} else {
				Integer[] userIds = this.getUserID(roleCodes);
				// 推送消息
				returnCode = this.pushMessage(mode, userIds, userID,
						"中石化交收配送申请拆单，风控审核拒绝，请物流修改配送拆单信息",
						"app.deliveryDetail.logistic", deliveryID);
				if (returnCode == -1) {
					this.rollBack();
					return -24008;
				}
			}
		}else {
			this.log.error(this.getClass().getName()+" claimTask 认领流程任务失败");
			this.rollBack();
			returnCode = -24008;
			return returnCode;
		}
		this.log.info(this.getClass().getName()+" reviewedNotDistributionApply Component End");
		return returnCode;
	}
	
	/**
	 * 取消中石化交收拆单，风控审核拒绝，物流修改拆单信息
	 */
	@Override
	public int updateDistributionApply(Delivery delivery, String userID,
			String mode, String taskID) {
		this.log.info(this.getClass().getName()+" updateDistributionApply Start");
		int returnCode = 0;
		Order order = this.deliveryDAO.getOrderByDeliveryID(delivery.getDeliveryID());
		
		/*随着拆单信息的修改，运费可能发生变化*/
		returnCode = this.updateDistributionDatabase(order,userID,delivery);
		if(returnCode < 0)return returnCode;
		
		/*物流修改拆单信息成功，制定到下一个流程节点*/
		List<VariableParams> variables = new ArrayList<VariableParams>();
		// 认领任务
		JSONObject rtnJso = claimTask(taskID, userID, mode, userID);
		String resultCode = rtnJso.getString("CODE");
		// 完成任务
		if (resultCode.equals("OK")) {
			// 物流修改拆单信息，指定下一个任务节点的操作人员(中石化配送拆单审核人员)
			VariableParams riskControlAuditDistribution = new VariableParams();
			riskControlAuditDistribution.setName("riskVerifyDistributionUsers");
			String roleCodes = BusinessEnumConstants.RoleType.SinopecAuditRoleCode
					.getValue();
			riskControlAuditDistribution.setValue(this.getUser(roleCodes));
			variables.add(riskControlAuditDistribution);

			rtnJso = this.completeTask(variables, mode, userID, taskID);
			resultCode = rtnJso.getString("CODE");
			if (!resultCode.equals("OK")) {
				this.log.error(this.getClass().getName()+" completeTask 完成流程任务失败");
				this.rollBack();
				returnCode = -24008;
			} else {
				Integer[] userIds = this.getUserID(roleCodes);
				// 推送消息
				returnCode = this.pushMessage(mode, userIds, userID,
						"修改拆单信息成功，请风控审核拆单物流信息",
						"app.deliveryDetail.logistic", delivery.getDeliveryID());
				if (returnCode == -1) {
					this.rollBack();
					return -24008;
				}
			}
		}else {
			this.log.error(this.getClass().getName()+" claimTask 认领流程任务失败");
			this.rollBack();
			returnCode = -24008;
			return returnCode;
		}
		
		
		this.log.info(this.getClass().getName()+" updateDistributionApply End");
		return returnCode;
	}
	
	@Override
	public Delivery getHisDelivery(String historyDeliveryID) {
		this.log.info(this.getClass().getName()+" getHisDelivery Start");
		Delivery delivery = this.distributionDao_read.getHisDelivery(historyDeliveryID);
		this.log.info(this.getClass().getName()+" getHisDelivery End");
		return delivery;
	}
	
	
	private void rollBack() {
		this.deliveryDAO.rollBack();
	}

	/**
	 * 下一节点 任务人员
	 * 
	 * @return
	 */
	private String getUser(String roleCode) {
		String userNames = "";
		List<MUser> userNameList = this.systemMgrDAO
				.getUserListByRoleCode(roleCode);
		if (userNameList != null && userNameList.size() > 0) {
			for (int i = 0; i < userNameList.size(); i++) {
				if (i > 0)
					userNames += ",";
				userNames += userNameList.get(i).getUserID();
			}
		}
		if (("").equals(userNames))
			this.log.debug("数据库中查无此角色:" + roleCode
					+ ",不能发起流程或者制定下一节点操作人员！请联系管理员");
		return userNames;
	}

	// 要推送消息的人员ID
	private Integer[] getUserID(String roleCode) {
		Integer[] userIDs = null;
		List<MUser> userNameList = this.systemMgrDAO
				.getUserListByRoleCode(roleCode);
		String userNames = "'";
		if (userNameList != null && userNameList.size() > 0) {
			for (int i = 0; i < userNameList.size(); i++) {
				if (i > 0)
					userNames += ",'";
				userNames += userNameList.get(i).getUserID() + "'";
			}
		}
		List<UaacUser> uaacUserList = this.systemMgrDAO
				.getUaacUserList(userNames);

		if (uaacUserList != null && uaacUserList.size() > 0) {
			userIDs = new Integer[uaacUserList.size()];
			for (int i = 0; i < uaacUserList.size(); i++) {
				userIDs[i] = uaacUserList.get(i).getId();
			}
		} else {
			userIDs = new Integer[0];
		}
		return userIDs;
	}

	/**
	 * 
	 * @param businessKey
	 *            业务主键（如交收id，付款id）
	 * @param definitionKey
	 *            流程主键
	 * @param mode
	 * @param userID
	 * @param variables
	 * @return
	 */
	private JSONObject startProcessInstance(String businessKey,
			String definitionKey, String mode, String userID,
			List<VariableParams> variables) {
		this.log.info(this.getClass().getName()+" startProcessInstance 开启流程 Start");
		ProcessInstance processInstance = new ProcessInstance();

		ProcessInstanceParams piParams = processInstance.getPiParams();
		piParams.setBusinessKey(businessKey);
		piParams.setProcessDefinitionKey(definitionKey);

		piParams.setVariables(variables);
		JSONObject rtnJso = null;
		try {
			String postData = ActivitiFactory.getActivitiRequestData(
					"Start_Process_Instance", userID,
					processInstance.getJsonObject());
			this.log.info(this.getClass().getName()+" 开启工作流请求postData参数："+postData);
			rtnJso = postActivitiApi(postData, mode);
		} catch (Exception e) {
			this.log.info(this.getClass().getName()+" startProcessInstance 开启流程失败："+e.getMessage());
			e.printStackTrace();
		}
		this.log.info(this.getClass().getName()+" startProcessInstance 开启流程 End");
		return rtnJso;
	}

	/**
	 * @param mode
	 * 
	 * @param userIds
	 *            要推送的人
	 * @param userID
	 *            推送人
	 * @param message
	 *            消息内容
	 * @param linkUrl
	 *            消息链接
	 * @param deliveryID
	 *            交收ID
	 * @return returnCode：200是success
	 */
	private int pushMessage(String mode, Integer[] userIds, String userID,
			String message, String linkUrl, String deliveryID) {
		this.log.debug("pushMessage Component Start");
		PostMethod filePost = null;

		if (Constants.MODE_TEST.equals(mode)) {
			filePost = new PostMethod(Constants.PUSH_MESSAGE_TEST);
		} else if (Constants.MODE_UAT.equals(mode)) {
			filePost = new PostMethod(Constants.PUSH_MESSAGE_UAT);
		} else if (Constants.MODE_DEPLOY.equals(mode)) {
			filePost = new PostMethod(Constants.PUSH_MESSAGE_DEPLOY);
		} else {
			filePost = new PostMethod(Constants.PUSH_MESSAGE_DEV);
		}

		this.log.debug("pushMessage mode : " + mode);

		JSONObject obj = new JSONObject();
		obj.accumulate("userIds", userIds);
		obj.accumulate("userid", userID);
		obj.accumulate("message", message);
		obj.accumulate("linkUrl", linkUrl);
		obj.accumulate("msgParams", deliveryID);
		filePost.setRequestBody(obj.toString());
		filePost.setRequestHeader("Content-Type",
				"application/json;charset=utf-8");
		HttpClient client = new HttpClient();
		client.getHttpConnectionManager().getParams()
				.setConnectionTimeout(5000);
		int returnCode;
		try {
			returnCode = client.executeMethod(filePost);
			this.log.error("pushMessage　returnCode:" + returnCode);

			if (returnCode != HttpStatus.SC_OK) {
				this.log.error("pushMessage error: 消息推送失败");
				returnCode = -1;
			} else {
				this.log.debug("pushMessage success");
			}
		} catch (HttpException e) {
			// 发生致命的异常，可能是协议不对或者返回的内容有问题
			this.log.error("pushMessage error:" + e.getMessage());
			returnCode = -1;
		} catch (IOException e) {
			// 发生网络异常
			this.log.error("pushMessage error:" + e.getMessage());
			returnCode = -1;
		} catch (Exception e) {
			this.log.error("pushMessage error:" + e.getMessage());
			returnCode = -1;
		} finally {
			filePost.releaseConnection();
		}

		this.log.debug("pushMessage Component Stop");
		return returnCode;
	}

	public void addDeliveryOpeLog(String deliveryID, String userID,
			String opeContent, String setOpeComment) {
		this.log.debug(this.getClass().getName() + "addDeliveryOpeLog Start");
		this.log.info(DeliveryManagerImpl.class
				+ "  addDeliveryOpeLog Component Start");
		DeliveryOpeLog deliveryOpeLog = new DeliveryOpeLog();

		deliveryOpeLog.setDeliveryID(deliveryID);
		deliveryOpeLog.setUserID(userID);
		deliveryOpeLog.setOpeContent(opeContent);
		deliveryOpeLog.setOpeComment(setOpeComment);
		this.addDeliveryOpeLog(deliveryOpeLog);
		this.log.debug(this.getClass().getName() + "addDeliveryOpeLog  End");
	}

	/**
	 * 某笔成交单可以申请交收的数量
	 * 
	 * @param OrderID
	 * @return
	 */
	private int getCanDeliveryQuantity(String OrderID) {
		Order order = this.deliveryDAO.getOrderByID(OrderID);
		int canDeliveryQuantity = order.getQuantity()
				- order.getDeliveryQuantity();
		return canDeliveryQuantity;
	}

	/**
	 * 交收业务日志
	 * 
	 * @return
	 */
	private void addDeliveryOpeLog(DeliveryOpeLog deliveryOpeLog) {
		this.log.info(DeliveryManagerImpl.class
				+ "  addDeliveryOpeLog Component Start");
		this.deliveryDAO.addDeliveryOpeLog(deliveryOpeLog);
	}

	private int checkApplyDelivery(Delivery delivery) {
		int returnCode = 0;
		Order order = this.orderDAO.getOrderByOrderID(delivery.getOrderID());

		int canDeliveryQuantity = this.getCanDeliveryQuantity(order
				.getOrderId());
		if (delivery.getDeliveryQuantity() > canDeliveryQuantity) {
			// 申请交收数量大于 订单可交收数量
			return returnCode = -24017;
		}
		// 最小交收数量（批）
		int minQuantity = this.deliveryDAO.getMinQuantity(order.getOrderId());
		if (delivery.getDeliveryQuantity() < minQuantity) {
			// 申请交收数量小于最小交收数量
			return returnCode = -24011;
		}

		/* 订单剩余总量 */
		int totalQuantity = order.getQuantity() - order.getDeliveryQuantity();
		int numQuantity = totalQuantity - minQuantity;
		if ((delivery.getDeliveryQuantity() > numQuantity)
				&& (delivery.getDeliveryQuantity() != totalQuantity))
			return -24027;
		return returnCode;
	}
	
	/**
	 * 在取消交收单子的基础上发起交收申请(中石化)的数据校验
	 */
	private int checkApplyDeliveryWitHistoryDelivery(Delivery delivery,Order order) {
		this.log.info(this.getClass().getName()+" checkApplyDeliveryWitHistoryDelivery Component Start");
		int returnCode = 0;
		Delivery historyDelivery = this.deliveryDAO.getDeliveryByID(delivery.getHistoryDeliveryID());
		int canDeliveryQuantity = historyDelivery.getDeliveryQuantity();
		if (delivery.getDeliveryQuantity() > canDeliveryQuantity) {
			// 申请交收数量大于 可交收数量
			return returnCode = -24017;
		}
		// 最小交收数量（批）
		int minQuantity = this.deliveryDAO.getMinQuantity(order.getOrderId());
		if (delivery.getDeliveryQuantity() < minQuantity) {
			// 申请交收数量小于最小交收数量
			return returnCode = -24011;
		}

		/* 原取消的交收单剩余总量 */
		int totalQuantity = historyDelivery.getDeliveryQuantity();
		int numQuantity = totalQuantity - minQuantity;
		if ((delivery.getDeliveryQuantity() > numQuantity)
				&& (delivery.getDeliveryQuantity() != totalQuantity))
			return -24027;
		this.log.info(this.getClass().getName()+" checkApplyDeliveryWitHistoryDelivery Component End");
		return returnCode;
	}
	/**
	 * 新增中石化配送基础数据
	 * @param order
	 * @param delivery
	 * @param userID
	 * @param deliveryDAO2
	 * @return
	 */
	private int addDistributionDatabase(Order order, Delivery delivery,
			String userID,String deliveryID) {
		this.log.info(this.getClass().getName()+" addDistributionDatabase addDistributionDatabase Start");
		int returnCode = 0;
		order.setUnnormalFirm(100);
		try {
			DeliveryExpenseUtil.setDeliveryExpenses(order, delivery, userID,
					deliveryDAO);
		} catch (ParseException e) {
			this.log.info(this.getClass().getName()+" 交收分摊订单费用出错");
			e.printStackTrace();
			return -1;
		}

		/*中石化拆单，重新生成交收单*/
		delivery.setDeliveryID(deliveryID);
		delivery.setDeliveryType(1);
		delivery.setUpdateLogisticalDetStatus(1);
		returnCode = this.deliveryDAO.addNormalDelivery(delivery, userID);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode = -24004;
		}

		/**
		 * 配送子表 T_DelDistributionDetail
		 */
		DelDistributionDetail detail = DeliveryExpenseUtil
				.getDelDistributionDetail(delivery, order, userID);
		try {
			returnCode = this.distributionDao.addDelDistributionDetail(detail);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (returnCode == -1) {
			this.rollBack();
			return returnCode = -24004;
		}

		/**
		 * 配送运费资金表 T_DeliveryFreightFee
		 */
		DeliveryFreightFee deliveryFreightFee = DeliveryExpenseUtil
				.getDeliveryFreightFee(delivery, order, userID);
		returnCode = this.distributionDao
				.addDeliveryFreightFee(deliveryFreightFee);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode = -24004;
		}
		this.log.info(this.getClass().getName()+" addDistributionDatabase Component End");
		return returnCode;
	}
	
	/**
	 * 取消中石化交收拆单，风控审核拒绝，物流修改拆单信息(运费资金)
	 * @param order
	 * @param userID
	 * @param deliveryID
	 * @return
	 */
	private int updateDistributionDatabase(Order order, String userID,
			Delivery delivery) {
		this.log.info(this.getClass().getName()+" updateDistributionDatabase Start");
		int returnCode = 0;

		Delivery deliveryTemp = this.deliveryDAO.getDeliveryByID(delivery.getDeliveryID());
		delivery.setDeliveryQuantity(deliveryTemp.getDeliveryQuantity());
		/* 配送子表 T_DelDistributionDetail*/
		DelDistributionDetail detail = DeliveryExpenseUtil
				.getDelDistributionDetail(delivery, order, userID);
		returnCode = this.distributionDao.updateDistribution(detail,delivery.getDeliveryID());
		if(returnCode == -1){
			this.log.error(this.getClass().getName()+"物流修改拆单信息,修改配送明细失败");
			return returnCode;
		}
		
		/*配送运费资金表 T_DeliveryFreightFee*/
		DeliveryFreightFee deliveryFreightFee = DeliveryExpenseUtil.getDeliveryFreightFee(delivery, order, userID);
		returnCode = this.distributionDao.updateDeliveryFreightFee(deliveryFreightFee,userID);
		if (returnCode == -1){
			this.log.error(this.getClass().getName()+"物流修改拆单信息,修改运费失败");
			this.rollBack();
			return returnCode;
		}
		
		/*拆单信息修改后，重新'待审核'*/
		returnCode = this.distributionDao.updateUpdateLogisticalDetStatus(1,delivery.getDeliveryID(), userID,1);
		
		this.log.info(this.getClass().getName()+" updateDistributionDatabase End");
		return returnCode;
	}
	/**
	 * 认领任务
	 * 
	 * @param taskID
	 * @param assignee
	 * @param variables
	 * @param variables
	 * @return
	 */
	private JSONObject claimTask(String taskID, String assignee, String mode,
			String userID) {
		Task task = new Task();
		TaskParams taskParams = task.getParams();
		task.setTaskId(taskID);// 流程ID
		taskParams.ClaimTask(assignee);// 认领人

		JSONObject rtnJso = null;
		try {
			/**
			 * 认领任务
			 */
			String postData = ActivitiFactory.getActivitiRequestData(
					"Action_Task", userID, task.getJsonObject());
			rtnJso = postActivitiApi(postData, mode);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return rtnJso;
	}

	/**
	 * 完成任务
	 * 
	 * @param variables
	 * @param mode
	 * @param userID
	 * @param taskID
	 * @return
	 */
	private JSONObject completeTask(List<VariableParams> variables,
			String mode, String userID, String taskID) {
		Task task = new Task();
		TaskParams taskParams = task.getParams();
		task.setTaskId(taskID);// 流程ID
		taskParams.CompleteTask();
		taskParams.setVariables(variables);

		JSONObject rtnJso = null;
		try {
			String postData = ActivitiFactory.getActivitiRequestData(
					"Action_Task", userID, task.getJsonObject());
			System.out.println("请求参数  :" + postData);
			rtnJso = postActivitiApi(postData, mode);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return rtnJso;
	}

}
