package shcem.trade.dao.impl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.jdbc.CannotGetJdbcConnectionException;

import shcem.base.dao.DaoHelper;
import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.service.model.UpAndDownRecord;
import shcem.constant.Constants;
import shcem.finance.dao.model.FinancialBills;
import shcem.systemMgr.dao.model.MUser;
import shcem.trade.ExportModel.Delivery4Export;
import shcem.trade.ExportModel.DeliveryInvoice4Export;
import shcem.trade.dao.IDeliveryDAO;
import shcem.trade.dao.model.BreachContractApply;
import shcem.trade.dao.model.DelDistributionDetail;
import shcem.trade.dao.model.Delivery;
import shcem.trade.dao.model.DeliveryDetail;
import shcem.trade.dao.model.DeliveryFreightFee;
import shcem.trade.dao.model.DeliveryInvoice;
import shcem.trade.dao.model.DeliveryOpeLog;
import shcem.trade.dao.model.ExportDelivery;
import shcem.trade.dao.model.ExportFirmfunds;
import shcem.trade.dao.model.Firmfunds;
import shcem.trade.dao.model.Order;
import shcem.trade.dao.model.OrderSinopec;
import shcem.trade.dao.model.ReceiptFile;
import shcem.trade.dao.model.TradeTemplate;
import shcem.trade.dao.model.TrasferGoodsDetail;
import shcem.trade.service.model.DeliveryDto;
import shcem.util.CommonRowMapper;

public class DeliveryDAOImpl extends BaseDAOImpl implements IDeliveryDAO {
	
	@Override
	public List<Delivery> getLogisticalDeliveryList(QueryConditions qc,
			PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_034");
		List<Delivery> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new Delivery()));
		return list;
	}
	@Override
	public List<Delivery> getDeliveryList(QueryConditions qc, PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_001");
		List<Delivery> list = null ;
		try {
			list= this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new Delivery()));
		} catch (Exception e) {
			this.log.debug(this.getClass().getName()+"getDeliveryList 失败");
			e.printStackTrace();
		}
		
		return list;
	}
	
	@Override
	public Delivery getDeliveryDetail(String deliveryID) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_002");
		Delivery delivery = null;
		Object[] param = {
				deliveryID
		};
		try {
			delivery = (Delivery) this.queryForObject(sql, param, new CommonRowMapper(new Delivery()));
		} catch (Exception e) {
			this.log.debug(this.getClass().getName()+"getDeliveryDetail.. 失败"+e.getMessage());
			delivery = null;
		}
		return delivery;
	}
	@Override
	public void addDeliveryOpeLog(DeliveryOpeLog deliveryOpeLog) {
		this.log.debug(this.getClass().getName()+" addDeliveryOpeLog Start");
		String sql = this.sqlProperty.getProperty("DeliveryDAO_003");
		Object[] params = {
				deliveryOpeLog.getDeliveryID(),deliveryOpeLog.getUserID(),deliveryOpeLog.getOpeContent(),
			deliveryOpeLog.getOpeComment()
		};
		this.updateBySQL(sql, params);
	}
	@Override
	public List<DeliveryOpeLog> getDeliveryOpeLogList(String deliveryID) {
		this.log.debug(this.getClass().getName()+" getDeliveryOpeLogList Start");
		String sql = this.sqlProperty.getProperty("DeliveryDAO_004");
		Object[] params = {
				deliveryID
		};
		return this.queryBySQL(sql, params, null, new CommonRowMapper(new DeliveryOpeLog()));
	}
	@Override
	public void handleDelivery(String deliveryID) {
//		String sql = this.sqlProperty.getProperty("DeliveryDAO_005");
//		Object[] params = {
//				deliveryID
//		};
//		this.updateBySQL(sql, params);
	}
	/**
	 * 付卖方货款
	 */
	@Override
	public void paySellerMoney(String deliveryID,BigDecimal payedMoney,MUser user) {
		this.log.debug(this.getClass().getName()+" paySellerMoney Start");
		String sql = this.sqlProperty.getProperty("DeliveryDAO_006");
		Object[] param ={
				payedMoney,user.getName(),deliveryID
		};
		this.updateBySQL(sql, param);
	}
	/**
	 * 收买方货款
	 */
	@Override
	public Firmfunds getFirmfundsByDeliveryID(String deliveryID) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_007");
		Object[] param ={
				deliveryID	
		};
		return (Firmfunds) this.queryForObject(sql, param, new CommonRowMapper(new Firmfunds()));
	}
	@Override
	public void takeBuyerMoney(String deliveryID, BigDecimal takenMoney, MUser user) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_009");
		Object[] param ={
				takenMoney,user.getName(),deliveryID
		};
		this.updateBySQL(sql, param);
	}
	/**
	 * 更新交易商资金账户
	 */
	@Override
	public void updateFirmfunds(Firmfunds firmfunds) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_008");
		Object[] param ={
				firmfunds.getBALANCE(),firmfunds.getFIRMID()	
		};
		this.updateBySQL(sql, param);
	}
	@Override
	public Order getOrderByDeliveryID(String deliveryID) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_010");
		Object[] param ={
				deliveryID	
		};
		return (Order) this.queryForObject(sql, param, new CommonRowMapper(new Order()));
	}
	@Override
	public void releaseCreditMoneyForSeller(Delivery delivery) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_011");
		Object[] param ={
				delivery.getSellCreditDeposit(),delivery.getREC_MODIFYBY(),delivery.getDeliveryID()
		};
		this.updateBySQL(sql, param);
	}
	/**
	 * 更新交收表 - 买方交收已扣保证金
	 */
	@Override
	public void updateTakenBSDeposit(Delivery delivery) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_012");
		Object[] param ={
				delivery.getTakenBSDeposit(),delivery.getREC_MODIFYBY(),delivery.getDeliveryID()	
		};
		this.updateBySQL(sql, param);
	}
	@Override
	public void updateSellPenalty(Delivery delivery) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_013");
		Object[] param ={
				delivery.getSellPenalty(),delivery.getREC_MODIFYBY(),delivery.getDeliveryID()	
		};
		this.updateBySQL(sql, param);
	}
	@Override
	public int adJustTakenQuantity(String deliveryComment, BigDecimal takenQuantity,
			String deliveryID, String userName,BigDecimal overloadFee) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_014");
		Object[] param ={
				deliveryComment,overloadFee,takenQuantity,userName,new Date(),deliveryID
		};
		return this.updateBySQL(sql, param);
		
	}
	@Override
	public Firmfunds getSellFirmfundsByDeliveryID(String deliveryID) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_016");
		Object[] param ={
				deliveryID	
		};
		return (Firmfunds) this.queryForObject(sql, param, new CommonRowMapper(new Firmfunds()));
	}
	
	@Override
	public Firmfunds getBuyFirmfundsByDeliveryID(String buyFirmId) {
		String sql ="SELECT * FROM F_FirmFunds ff where ff.FIRMID='"+buyFirmId+"'";
		Object[] param ={};
		return (Firmfunds) this.queryForObject(sql, param, new CommonRowMapper(new Firmfunds()));
	}
	
//	@Override
//	public void updatePenaltyMoneyForSeller(Delivery delivery) {
//		String sql = this.sqlProperty.getProperty("DeliveryDAO_017");
//		Object[] param ={
//				delivery.getTakenSellPenalty(),delivery.getTakenSSDeposit(),delivery.getREC_MODIFYBY(),delivery.getDeliveryID()	
//		};
//		this.updateBySQL(sql, param);
//	}
		
	@Override
	public void updatePenaltyMoneyForBuyer(Delivery delivery) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_018");
		Object[] param ={
				delivery.getTakenBuyPenalty(),delivery.getTakenBSDeposit(),delivery.getREC_MODIFYBY(),delivery.getDeliveryID()	
		};
		this.updateBySQL(sql, param);
		
	}
	@Override
	public int adJustOverLoadMoney(Delivery delivery) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_015");
		Object[] param ={
				delivery.getOverloadFee(),delivery.getREC_MODIFYBY(),delivery.getDeliveryID()
		};
		return this.updateBySQL(sql, param);
	}
	/**
	 * 
	 */
	public List<Delivery4Export> getExportDeliveryList(QueryConditions qc,PageInfo pageInfo,boolean replace) {
		this.log.debug("getExportDeliveryList DAO Start");
		String sql = sqlProperty.getProperty("DeliveryDAO_001");
		if(replace)sql = sql.replaceFirst("SELECT", "SELECT top "+Constants.EXPORT_MAX_COUNT+" ");
		this.log.debug("DeliveryDAO_001: " + sql);
		List<Delivery4Export> list =  queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new Delivery4Export()));
		return list;
	}
	
	/**
	 * 
	 */
	public List<DeliveryDetail> getDeliveryDetailList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getDeliveryDetailList DAO Start");
		String sql = sqlProperty.getProperty("ExportDeliveryDetailDAO_001");
		this.log.debug("ExportDeliveryDetailDAO_001_Sql: " + sql);
		return queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new DeliveryDetail()));
	}
	
	/**
	 * 
	 */
	public List<DelDistributionDetail> getDelDistributionDetailList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getDelDistributionDetailList DAO Start");
		String sql = sqlProperty.getProperty("ExportDelDistributionDetailDAO_001");
		this.log.debug("ExportDelDistributionDetailDAO_001_Sql: " + sql);
		return queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new DelDistributionDetail()));
	}
	@Override
	public void updateDeliveryTakenMoney(BigDecimal allmoney, String name,String deliveryID) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_019");
		Object[] param ={
				allmoney,name,deliveryID	
		};
		this.updateBySQL(sql, param);
	}
	@Override
	public void updatePayedMoney(BigDecimal allmoney, String name,String deliveryID) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_020");
		Object[] param ={
				allmoney,name,deliveryID	
		};
		this.updateBySQL(sql, param);
	}
	@Override
	public void updateSellTakenSSDepositAndTakenSellPenalty(Delivery delivery) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_021");
		Object[] param ={
				delivery.getSellTakenSSDeposit(),delivery.getTakenSellPenalty(),delivery.getREC_MODIFYBY(),delivery.getDeliveryID()	
		};
		this.updateBySQL(sql, param);
	}
	@Override
	public void updateTakenBSDepositAndTakenBuyPenalty(Delivery delivery) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_022");
		Object[] param ={
				delivery.getTakenBSDeposit(),delivery.getTakenBuyPenalty(),delivery.getREC_MODIFYBY(),delivery.getDeliveryID()	
		};
		this.updateBySQL(sql, param);
	}
	@Override
	public void updateBuyPenalty(Delivery delivery) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_023");
		Object[] param ={
				delivery.getBuyPenalty(),delivery.getREC_MODIFYBY(),delivery.getDeliveryID()	
		};
		this.updateBySQL(sql, param);
	}
	
	/**
	 * 
	 */
	public List<ExportFirmfunds> getExportFirmFundsList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getExportFirmFundsList DAO Start");
		String sql = sqlProperty.getProperty("ExportFirmFundsDAO_001");
		this.log.debug("ExportFirmFundsDAO_001_SQL: " + sql);
		return queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new ExportFirmfunds()));
	}
	@Override
	public Order getOrderByID(String orderID) {
		this.log.debug("getOrderByID DAO Start");
		String sql = sqlProperty.getProperty("OrderDAO_001");
		Object[] params = new Object[] { orderID };
		return (Order) queryForObject(sql, params, new CommonRowMapper(new Order()));
	}
	@Override
	public void updateSellCreditFeeAndSellTakenTradeFee(Order order) {
		String sql = this.sqlProperty.getProperty("OrderDAO_004");
		Object[] param ={
				order.getSellCreditFee(),order.getSellTakenTradeFee(),order.getREC_MODIFYBY(),order.getOrderId()
		};
		this.updateBySQL(sql, param);
	}
	@Override
	public void updateSellTakenSSDepositAndSellCreditDeposit(Delivery delivery) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_024");
		Object[] param ={
				delivery.getSellTakenSSDeposit(),delivery.getSellCreditDeposit(),delivery.getREC_MODIFYBY(),delivery.getDeliveryID()	
		};
		this.updateBySQL(sql, param);
	}
	@Override
	public List<Order> getOrderFile(String orderID) {
		this.log.info(this.getClass().getName()+" getOrderFile(已上传文件个数) ");
		String sql = sqlProperty.getProperty("DeliveryDAO_025");
		Object[] param = {orderID};
		return this.queryBySQL(sql, param, null, new CommonRowMapper(new Order()));
	}
	/**
	 * 履约处理完成 ，更新订单“已签收数量（批）SignQuantity”
	 * params:
	 * takenQuantity:交收实发数量
	 */
	@Override
	public void updateOrderSignQuantity(BigDecimal takenQuantity, String orderID,
			MUser user) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_026");
		Object[] params = {
				orderID,takenQuantity,user.getName(),new Date(),orderID
		};
		this.updateBySQL(sql, params);
	}
	
	@Override
	public void finishDelivery(int status, int violationStatus, String deliveryID){
		String sql = this.sqlProperty.getProperty("DeliveryDAO_027");
           Object[] params = {
				violationStatus,deliveryID
		};
	   this.updateBySQL(sql, params);
	}
	
	@Override
	public void finishProcessStatus(int status, String deliveryID) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_028");
		Object[] params = {
				status,deliveryID
		};
		this.updateBySQL(sql, params);
		
	}
	
	
	@Override
	public List<Delivery> getDeliveryListByOrderID(String orderId) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_029")+" and DeliveryStatus IN(20,25,30,35,40,45,50,55,60,65) and OrderID='"+orderId+"'";
		Object[] params = {
					orderId
				};
		List<Delivery> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new Delivery()));
		return list;
	}
	
	@Override
	public List<Delivery> getAllDeliveryListByOrderID(String orderId) {
		this.log.info(this.getClass().getName()+" getAllDeliveryListByOrderID Start");
		String sql = this.sqlProperty.getProperty("DeliveryDAO_029")+" and DeliveryStatus !=70 ";
		Object[] params = {
					orderId
				};
		List<Delivery> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new Delivery()));
		this.log.info(this.getClass().getName()+" getAllDeliveryListByOrderID End");
		return list;
	}
	
	@Override
	public List<Delivery> getPassedDeliveryList(String orderId,String statusConditions) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_029")+" and ProcessStatus in(0,1,2) AND DeliveryStatus IN "+statusConditions;
		Object[] params = {
					orderId
				};
		List<Delivery> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new Delivery()));
		return list;
	}
	
	@Override
	public int  finishedOrder(Integer tradeStatus,String orderId) {
		int returnCode = 0;
		String sql = this.sqlProperty.getProperty("DeliveryDAO_030");
		Object[] params = {
				tradeStatus,orderId,tradeStatus
			};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			returnCode = -1;
		}
		return this.updateBySQL(sql, params);
	}
	
	@Override
	public int updateDeliveryDetailStatus(String deliveryID,
			String rEC_MODIFYBY) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_031");
		Object[] params = {
				1,rEC_MODIFYBY,new Date(),deliveryID,1
		};
		return this.updateBySQL(sql, params);
	}
	/**
	 * 更新 交收 "物流状态"
	 */
	@Override
	public int updateDeliveryLogisticsStatus(Integer logisticsStatus, String deliveryID, String rEC_MODIFYBY) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_032");
		Object[] params = {
				logisticsStatus,rEC_MODIFYBY,new Date(),deliveryID,logisticsStatus
		};
		return this.updateBySQL(sql, params);
	}
	/**
	 * 
	 */
	@Override
	public int updDeliveryDetail(Delivery delivery,String userName) {
		this.log.debug("updDeliveryDetail DAO Start");
		String sql = sqlProperty.getProperty("DeliveryDetailDAO_001");
		Object[] params ={
				 	0,//默认为 0：正常，1：失效		DISABLED
				 	delivery.getStartDate(),//开始生效日期														
				 	delivery.getEndDate(),//结束生效日期																	
				 	delivery.getLogisticsCorp(),//运输公司名称																	
				 	delivery.getLogisticsCorpID(),//运输公司ID																	
				 	delivery.getDriverIDNumber(),//司机身份证号																	
				 	delivery.getDriverName(),//司机姓名																		
				 	delivery.getLicense(),//车牌号																		
				 	delivery.getContactTel(),//联系电话																		
				 	delivery.getContactName(),//提货人姓名																		
				 	delivery.getRemark(),//备注								    										
				 	userName,//最后修改人																		
				 	delivery.getSendStatus(),//发送状态
				 	delivery.getDeliveryID()//交收ID
		};
		this.log.debug("DeliveryDetailDAO_001_SQL: " + sql);
		for (int i = 0; i < params.length; i++) {
			this.log.debug("params[" + i + "]: " + params[i]);
		}
		int returnCode;
		try {
			returnCode = getJdbcTemplate().update(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error(e.getMessage());
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public int updTrasferGoodsDetail(Delivery delivery, String userName) {
		String sql = sqlProperty.getProperty("TrasferGoodsDetailDAO_001");
		Object[] params ={
				0,//默认为 0：正常，1：失效								
				delivery.getValidDate(),//有效日期																		
				delivery.getFeesItem(),//费用项目																		
				delivery.getRemark(),//备注
				delivery.getStoreHouseNum(),//仓库编号	
				userName,//最后修改人										
				delivery.getContactName(),//联系人姓名									
				delivery.getContactTel(),//联系人电话																		
				delivery.getDeliveryID()//交收ID									
		};
		
		/**
		 * update T_TrasferGoodsDetail set DISABLED=\u003f,ValidDate=\u003f,FeesItem=\u003f,Remark=\u003f,StoreHouseNum=\u003f,REC_MODIFYBY=\u003f,ContactName=\u003f,ContactTel=\u003f,REC_MODIFYTIME=getDate() where DeliveryID=\u003f
		 */
		this.log.debug("TrasferGoodsDetailDAO_001_SQL: " + sql);
		for (int i = 0; i < params.length; i++) {
			this.log.debug("params[" + i + "]: " + params[i]);
		}
		int returnCode;
		try {
			returnCode = getJdbcTemplate().update(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error(e.getMessage());
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public int updateDeliveryAttID(Integer deliveryAttID, String deliveryID, String userName, int deliveryStatus) {
		String sql = "update T_Delivery set deliveryAttID="+deliveryAttID+",REC_MODIFYBY = '"+userName+"'"
				+ ",REC_MODIFYTIME=GETDATE(),deliveryStatus="+deliveryStatus+" where DeliveryID='"+deliveryID+"'";
		int returnCode;
		Object [] param ={};
		try {
			returnCode = this.updateBySQL(sql, param);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	/**
	 * 
	 */
	public List<DeliveryInvoice> getDeliveryInvoiceList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getDeliveryInvoiceList DAO Start");
		String sql = sqlProperty.getProperty("DeliveryInvoiceDAO_001");
		this.log.debug("DeliveryInvoiceDAO_001_Sql: " + sql);
		return queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new DeliveryInvoice()));
	}
	
	
	@Override
	public List<DeliveryInvoice4Export> getDeliveryInvoice4ExportList(
			QueryConditions qc, PageInfo pageInfo,boolean replace) {
		this.log.debug("getDeliveryInvoice4ExportList DAO Start");
		String sql = sqlProperty.getProperty("DeliveryInvoiceDAO_001");
		if (replace)sql = sql.replaceFirst("select", "select top "+Constants.EXPORT_MAX_COUNT+"");
		this.log.debug("DeliveryInvoiceDAO_001_Sql: " + sql);
		return queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new DeliveryInvoice4Export()));
	}
	
	@Override
	public List<UpAndDownRecord> getRecordList(QueryConditions qc,PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_033");
		List<UpAndDownRecord> list = null;
		try {
			list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new UpAndDownRecord()));
		} catch (Exception e) {
			 e.printStackTrace();
		}
		return list;
	}
	
	@Override
	public List<UpAndDownRecord> getLogisticalRecordArray(QueryConditions qc,
			PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_035");
		List<UpAndDownRecord> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new UpAndDownRecord()));
		return list;
	}
	@Override
	public int updateDeliveryStatus(int deliveryStatus, String deliveryID, String userName) {
		this.log.debug(this.getClass().getName()+"updateDeliveryStatus Start");
		String sql = "update T_Delivery set DeliveryStatus ="+deliveryStatus+",REC_MODIFYBY='"+userName+"',REC_MODIFYTIME=GETDATE() where deliveryID='"+deliveryID+"'";
		Object [] param ={};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql,param);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" updateDeliveryStatus 失败");
			e.printStackTrace();
			returnCode = -1;
		}
		this.log.info(this.getClass().getName()+" updateDeliveryStatus End");
		return returnCode;
	}
	
	@Override
	public int updateDeliveryOrderFileID(int deliveryOrderFileID,
			int deliveryStatus, String deliveryID, String userName) {
		String sql = "update T_Delivery set deliveryOrderFileID="+deliveryOrderFileID+",DeliveryStatus ="+deliveryStatus+",REC_MODIFYBY='"+userName+"',REC_MODIFYTIME=GETDATE() where deliveryID='"+deliveryID+"'";
		Object [] param ={};
		int returnCode = 0;
		try {
			this.updateBySQL(sql,param);
		} catch (Exception e) {
			returnCode = -1;
		}
		return returnCode;
	}
	@Override
	public int updateNotPassedDeliveryStatus(int deliveryStatus, String deliveryID,String userName) {
		String sql = "update T_Delivery set DeliveryStatus ="+deliveryStatus+",REC_MODIFYBY='"+userName+"',REC_MODIFYTIME=GETDATE() where deliveryID='"+deliveryID+"'";
		Object [] param ={};
		int returnCode;
		try {
			returnCode =  this.updateBySQL(sql,param);
		} catch (Exception e) {
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public List<Delivery> getReviewPassedDeliverySignedQuantity(String orderID) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_029_1")+" and ProcessStatus in(0,1,2) AND DeliveryStatus IN (15,40,45,50,55,60,65)";
		Object[] params = {
				orderID
				};
		List<Delivery> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new Delivery()));
		return list;
	}
	@Override
	public int getDeliveryQuantity(String orderID) {
		String sql = "select SUM(DeliveryQuantity) from T_Delivery where  OrderID = '"+orderID+"'";
		int deliveryQuantity = this.queryForInt(sql);
		return deliveryQuantity;
	}
	
	@Override
	public int updateNotPassedDeliverySignedQuantityStatus(int deliveryStatus,
			String deliveryID) {
		String sql = "update T_Delivery set DeliveryStatus ="+deliveryStatus+" where deliveryID='"+deliveryID+"'";
		Object [] param ={};
		return this.updateBySQL(sql,param);
	}
	@Override
	public Long getTakenMoneyByOrderID(String orderId) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_036")+" where OrderID= '"+orderId+"'";
		return this.queryForLong(sql);
	}
	
	/**
	 * 已付商家违约金
	 */
	@Override
	public BigDecimal getFundFlowMoney(String firmID,String deliveryID, String vouchermode) {
		String sql = "SELECT SUM(AMOUNT) as paidSellerPenalty,ff.CONTRACTNO  FROM F_FundFlow  ff LEFT JOIN F_Voucher fv ON fv.VOUCHERNO = ff.VOUCHERNO LEFT JOIN F_VoucherModel fvm ON fvm.SUMMARYNO = fv.SUMMARYNO "
				+ "WHERE ff.CONTRACTNO ='"+deliveryID+"' and ff.FirmID ='"+firmID+"' and  fvm.CODE = '"+vouchermode+"'  GROUP BY ff.CONTRACTNO,ff.FIRMID";
		Object[] param ={};
		Delivery delivery = (Delivery) this.queryForObject(sql, param, new CommonRowMapper(new Delivery()));
		if (delivery != null ) {
			return delivery.getPaidSellerPenalty();
		}else {
			return new BigDecimal(0);
		}
	}
	/**
	 *  更新  已付卖方违约金
	 */
	@Override
	public int  updatePaidSellPenalty(String deliveryID, BigDecimal paidSellPenalty, String userName) {
		int returnCode = 0;
		String sql = "update  T_Delivery set PaidSellPenalty ="+paidSellPenalty+",REC_MODIFYBY='"+userName+"',REC_MODIFYTIME=GETDATE() where DeliveryID='"+deliveryID+"'";
		try {
			Object [] param ={};
			returnCode =  this.updateBySQL(sql,param);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode =-1;
		}
		return returnCode;
	}
	@Override
	public int updatePaidBuyPenalty(String deliveryID,BigDecimal paidBuyPenalty,String userName){
		int returnCode = 0;
		String sql = "update T_Delivery set PaidBuyPenalty ="+paidBuyPenalty+",REC_MODIFYBY='"+userName+"',REC_MODIFYTIME=GETDATE() where DeliveryID='"+deliveryID+"'";
		try {
			Object [] param ={};
			returnCode =  this.updateBySQL(sql,param);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode =-1;
		}
		return returnCode;
	}
	/**
	 * 后台申请交收
	 */
	@Override
	public int addNormalDelivery(Delivery delivery, String userName) {
		this.log.info(this.getClass().getName()+"addNormalDelivery Dao Start");
		int returnCode = 0;
		String sql = this.sqlProperty.getProperty("DeliveryDAO_039");
		Object[] params ={
				delivery.getDeliveryID(),//主键ID	DeliveryID			
				delivery.getOrderID(),//成交表ID	OrderID			
				delivery.getLeadsID(),//报盘ID	LeadsID			
				delivery.getDISABLED()==null?0:delivery.getDISABLED(),//默认为 0：正常，1：失效	DISABLED			
//				delivery.getStatus()==null?1:delivery.getStatus(),//状态	Status			
				delivery.getDeliveryFirmId(),//提报交收交易商ID	DeliveryFirmId			
				delivery.getDeliveryTraderId(),//提报交收交易员ID	DeliveryTraderId			
				delivery.getREC_CREATEBY(),//创建人	REC_CREATEBY			
				delivery.getREC_CREATETIME(),//创建时间	REC_CREATETIME			
				delivery.getREC_MODIFYBY(),//最后修改人	REC_MODIFYBY			
				delivery.getREC_MODIFYTIME(),//最后修改时间	REC_MODIFYTIME			
				delivery.getDeliveryQuantity(),//交收数量	DeliveryQuantity			
				delivery.getTakenQuantity(),//实收数量	TakenQuantity			
				delivery.getMoney(),//应收货款	Money			
				delivery.getTakenMoney(),//已收货款	TakenMoney			
				delivery.getPayedMoney(),//已付货款	PayedMoney			
				delivery.getOverloadFee(),//升贴水	OverloadFee			
				delivery.getPrice(),//成交价	Price			
				delivery.getSellSettleDeposit(),//卖方交收应收保证金	SellSettleDeposit			
				delivery.getSellTakenSSDeposit(),//卖方交收已收保证金	SellTakenSSDeposit			
				delivery.getSellCreditDeposit(),//卖方交收保证金授信金额	SellCreditDeposit			
				delivery.getTakenBSFee(),//买方交收已扣手续费	TakenBSFee			
				delivery.getTakenBSDeposit(),//买方交收已扣保证金	TakenBSDeposit			
				delivery.getSellPenalty(),//卖方交收应扣违约金	SellPenalty			
				delivery.getTakenSellPenalty(),//卖方交收已扣违约金	TakenSellPenalty			
				delivery.getBuyPenalty(),//买方交收应扣违约金	BuyPenalty			
				delivery.getTakenBuyPenalty(),//买方交收已扣违约金	TakenBuyPenalty		
				
//				delivery.getSellSettleFee(),//卖方交收应收手续费	SellSettleFee			
//				delivery.getBuySettleFee(),//买方交收应付手续费	BuySettleFee			
//				delivery.getBuySettleDeposit(),//买方交收应付保证金	BuySettleDeposit			
//				delivery.getTakenSSFee(),//卖方交收已扣手续费	TakenSSFee			
//				delivery.getSellCreditFee(),//卖方交收手续费授信金额	SellCreditFee			
//				delivery.getBuyCreditFee(),//买方手续费授信金额	BuyCreditFee			
//				delivery.getBuyCreditDeposit(),//买方保证金授信金额	BuyCreditDeposit	
				
				delivery.getDeliveryType(),//交收方式	DeliveryType			
				delivery.getDeliveryAttID(),//交收附件	DeliveryAttID			
				delivery.getDeliveryStatus(),//交收状态	DeliveryStatus			
				delivery.getProcessInstanceID(),//交收流程ID	ProcessInstanceID			
				delivery.getProcessStatus()==null?0:delivery.getProcessStatus(),//履约状态	ProcessStatus			
				delivery.getViolationStatus()==null?0:delivery.getViolationStatus(),//违约状态	ViolationStatus			
				delivery.getLogisticsStatus()==null?0:delivery.getLogisticsStatus(),//物流状态	LogisticsStatus			
				delivery.getDeliveryComment(),//备注	DeliveryComment			
				delivery.getPaidSellPenalty(),//已付卖方违约金	PaidSellPenalty			
				delivery.getPaidBuyPenalty(),//已付买方违约金	PaidBuyPenalty	
				delivery.getTailAdjustStatus()==null?0:delivery.getTailAdjustStatus(),//尾调状态(尾调状态)
				userName,
//				delivery.getDistributionFee(),//配送费
				delivery.getDeliveryWeight(),//交收重量
				delivery.getHistoryDeliveryID()==null?null:delivery.getHistoryDeliveryID(),///*原交收单号：使用中石化配送取消拆单的情况*/
				delivery.getUpdateLogisticalDetStatus()==null?null:delivery.getUpdateLogisticalDetStatus()//1：待审核 ，5：风控审核通过 ，10：风控审核拒绝（适用于中石化配送）

		};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+"交收申请失败："+e.getMessage());
			e.printStackTrace();
			returnCode =-1;
		}
		this.log.info(this.getClass().getName()+"addNormalDelivery Dao Start");
		return returnCode;
	}
	/**
	 * 自提信息
	 */
	@Override
	public int addDeliveryDetail(DeliveryDetail deliveryDetail) {
		this.log.info(this.getClass().getName()+" addDeliveryDetail Dao Start");
		int returnCode = 0;
		String sql = this.sqlProperty.getProperty("DeliveryDAO_040");
		Object[] params ={
				deliveryDetail.getDeliveryID(),//交收ID	     DeliveryID			
				deliveryDetail.getDISABLED(),//默认为 0：正常，1：失效  	DISABLED			
				deliveryDetail.getStartDate(),//开始生效日期	 StartDate			
				deliveryDetail.getEndDate(),//结束生效日期	 EndDate			
				deliveryDetail.getLogisticsCorp(),//运输公司名称	 LogisticsCorp			
//				deliveryDetail.getLogisticsCorpID(),//运输公司ID	 LogisticsCorpID			
				deliveryDetail.getDriverIDNumber(),//司机身份证号	 DriverIDNumber			
//				deliveryDetail.getDriverName(),//司机姓名	 DriverName			
				deliveryDetail.getLicense(),//车牌号	     License			
				deliveryDetail.getContactTel(),//联系电话	 ContactTel			
				deliveryDetail.getContactName(),//提货人姓名	 ContactName			
//				deliveryDetail.getNextApplyID(),//下家申请单	 NextApplyID			
				deliveryDetail.getRemark(),//备注	     Remark			
				deliveryDetail.getREC_CREATEBY(),//创建人	     REC_CREATEBY			
				deliveryDetail.getREC_CREATETIME(),//创建时间	 REC_CREATETIME			
				deliveryDetail.getREC_MODIFYBY(),//最后修改人	 REC_MODIFYBY			
				deliveryDetail.getREC_MODIFYTIME(),//最后修改时间	 REC_MODIFYTIME			
				deliveryDetail.getSendStatus(),//发送状态	 SendStatus										

				/**
				 * [S16071300000903, 0, Wed Aug 03 00:00:00 CST 2016, Wed Aug 17 00:00:00 CST 2016, 123, 
				 * null, 123, null, 123123, null, 123123, 168336, 123123, 
				 * system, Wed Aug 24 19:57:04 CST 2016, system, Wed Aug 24 19:57:04 CST 2016, 0]
				 */
		};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+"addDeliveryDetail失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		this.log.info(this.getClass().getName()+" addDeliveryDetail Dao End");
		return returnCode;
	}
	/**
	 * 转货权信息
	 */
	@Override
	public int addTrasferGoodsDetail(TrasferGoodsDetail trasferGoodsDetail) {
		this.log.info(this.getClass().getName()+" addTrasferGoodsDetail Dao Start");
		int returnCode = 0;
		String sql = this.sqlProperty.getProperty("DeliveryDAO_041");
		Object[] params ={
				trasferGoodsDetail.getDeliveryID(),//交收ID			DeliveryID
				trasferGoodsDetail.getDISABLED(),//默认为 0：正常，1：失效			DISABLED
				trasferGoodsDetail.getValidDate(),//有效日期			ValidDate
				trasferGoodsDetail.getFeesItem(),//费用项目			FeesItem
				trasferGoodsDetail.getRemark(),//备注			Remark
				trasferGoodsDetail.getREC_CREATEBY(),//创建人			REC_CREATEBY
				trasferGoodsDetail.getREC_CREATETIME(),//创建时间			REC_CREATETIME
				trasferGoodsDetail.getREC_MODIFYBY(),//最后修改人			REC_MODIFYBY
				trasferGoodsDetail.getREC_MODIFYTIME(),//最后修改时间			REC_MODIFYTIME
				trasferGoodsDetail.getContactName(),
				trasferGoodsDetail.getContactTel(),
				trasferGoodsDetail.getStoreHouseNum()
				
		};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+"addTrasferGoodsDetail失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		this.log.info(this.getClass().getName()+" addTrasferGoodsDetail Dao End");
		return returnCode;
	}
	
	@Override
	public int disabledDelivery(String deliveryID, String userName) {
		int returnCode = 0;
		String sql ="update T_Delivery set DeliveryQuantity =0,DeliveryStatus =70 ,REC_MODIFYTIME=GETDATE(),REC_MODIFYBY='"+userName+"' where  DeliveryID='"+deliveryID+"'";
		try {
			Object [] params= {};
			returnCode = this.updateBySQL(sql,params);
		} catch (Exception e) {
			this.log.error("disabledDelivery失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	@Override
	public int updateDeliveryQuantity(String orderId, int deliveryQuantity,String userName) {
		int returnCode = 0;
		String sql ="update T_Order set DeliveryQuantity =DeliveryQuantity+"+deliveryQuantity+",REC_MODIFYTIME=GETDATE(),REC_MODIFYBY='"+userName+"' where  OrderId='"+orderId+"'";
		try {
			Object [] params= {};
			returnCode = this.updateBySQL(sql,params);
		} catch (Exception e) {
			this.log.error("updateDeliveryQuantity失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	/**
	 * 风控部门 把客户违约交收单撤销
	 */
	@Override
	public int disabledUnNormalDelivery(String unNormalApplyID) {
		int returnCode = 0;
		String sql ="update T_BreachContractApply set Status = 1 where ID='"+unNormalApplyID+"'";
		try {
			Object [] params= {};
			returnCode = this.updateBySQL(sql,params);
		} catch (Exception e) {
			this.log.error("disabledUnNormalDelivery失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public BreachContractApply getBreachContractApply(Integer keyID) {
		this.log.debug(this.getClass().getName()+"getBreachContractApply Start");
		String sql ="select * from T_BreachContractApply where KeyID='"+keyID+"'";
		BreachContractApply breachContractApply;
		Object[] params ={};
		breachContractApply = (BreachContractApply) this.queryForObject(sql, params, new CommonRowMapper(new BreachContractApply()));
		this.log.debug("getBreachContractApply DAO :" + breachContractApply);
		return breachContractApply;
	}
	
	/**
	 * 某笔成交单可以违约的数量
	 */
	@Override
	public int getCanViolationQuantity(String orderID) {
		String sql = "select SUM(DeliveryQuantity) from T_Delivery where DeliveryStatus in(1,5,10,15) and OrderID = '"+orderID+"'";
		Order order = this.getOrderByID(orderID);
		
		int canViolationQuantity = this.queryForInt(sql);
		//可违约数量 canViolationQuantity+订单未申请交收数量
		canViolationQuantity = order.getQuantity()-order.getDeliveryQuantity()+canViolationQuantity;
		
		return canViolationQuantity;
	}
	/**
	 * 交收 尾调状态
	 */
	@Override
	public int updateDeliveryTailAdjustStatus(int tailAdjustStatus,
			String deliveryID) {
		int returnCode;
		String sql = "update  T_Delivery set TailAdjustStatus ="+tailAdjustStatus+" where DeliveryID='"+deliveryID+"'";
		Object [] param ={};
		try {
			returnCode = this.updateBySQL(sql, param);
		} catch (Exception e) {
			this.log.error("updateDeliveryTailAdjustStatus失败："+e.getMessage());
			e.printStackTrace();
			returnCode =-1;
		}
		
		return returnCode;
	}
	/**
	 * 卖方交收应扣违约金
	 */
	@Override
	public int updateSellPenalty(BigDecimal sellPenalty, String userName,
			String deliveryID) {
		String sql = "update  T_Delivery set SellPenalty ="+sellPenalty+",REC_MODIFYBY='"+userName+"',REC_MODIFYTIME=GETDATE() where DeliveryID='"+deliveryID+"'";
		Object [] param ={};
		return this.updateBySQL(sql, param);
	}
	/**
	 * 买方交收应扣违约金
	 */
	@Override
	public int updateBuyPenalty(BigDecimal buyPenalty, String userName,String deliveryID) {
		String sql = "update  T_Delivery set BuyPenalty ="+buyPenalty+",REC_MODIFYBY='"+userName+"',REC_MODIFYTIME=GETDATE() where DeliveryID='"+deliveryID+"'";
		Object [] param ={};
		return this.updateBySQL(sql, param);
	}
	
	@Override
	public int updateShouldPaySellPenalty(BigDecimal payMoney,
			String userName, String deliveryID) {
		String sql = "update  T_Delivery set ShouldPaySellPenalty ="+payMoney+",REC_MODIFYBY='"+userName+"',REC_MODIFYTIME=GETDATE() where DeliveryID='"+deliveryID+"'";
		Object [] param ={};
		return this.updateBySQL(sql, param);
	}
	
	@Override
	public int updateShouldPayBuyPenalty(BigDecimal payMoney, String userName,
			String deliveryID) {
		String sql = "update  T_Delivery set ShouldPayBuyPenalty ="+payMoney+",REC_MODIFYBY='"+userName+"',REC_MODIFYTIME=GETDATE() where DeliveryID='"+deliveryID+"'";
		Object [] param ={};
		return this.updateBySQL(sql, param);
	}
	
	@Override
	public int updateDeliveryProcessInstanceID(String processInstanceID,
			String deliveryID,String userName) {
		String sql = "update  T_Delivery set ProcessInstanceID ='"+processInstanceID+"',REC_MODIFYBY='"+userName+"',REC_MODIFYTIME=GETDATE() where DeliveryID='"+deliveryID+"'";
		int returnCode = 0;
		Object [] params ={};
		try {
			returnCode =  this.updateBySQL(sql,params);
		} catch (Exception e) {
			this.log.error("updateDeliveryProcessInstanceID失败："+e.getMessage());
			e.printStackTrace();
			returnCode =-1;
		}
		return returnCode;
	}
	
	
	
	@Override
	public DeliveryDetail getTDeliveryDetail(String deliveryID) {
		this.log.info(this.getClass().getName()+" getTDeliveryDetail Start");
		String sql = "select * from T_DeliveryDetail where DeliveryID='"+deliveryID+"'";
		Object [] param ={};
		return (DeliveryDetail) this.queryForObject(sql, param,new CommonRowMapper(new DeliveryDetail()));
	}
	@Override
	public TrasferGoodsDetail getTrasferGoodsDetail(String deliveryID) {
		this.log.info(this.getClass().getName()+ " getTrasferGoodsDetail Start");
		String sql = "select * from T_TrasferGoodsDetail where DeliveryID='"+deliveryID+"'";
		Object [] param ={};
		return (TrasferGoodsDetail) this.queryForObject(sql, param,new CommonRowMapper(new TrasferGoodsDetail()));
	}
	
	@Override
	public int updateDeliveryQuantity(int canDeliveryQuantity, String orderID,
			String userName) {
		this.log.info(this.getClass().getName()+" updateDeliveryQuantity　Dao Start");
		int returnCode;
		String sql = "update T_Order set DeliveryQuantity = isnull(DeliveryQuantity,0)+"+canDeliveryQuantity+",REC_MODIFYBY='"+userName+"',REC_MODIFYTIME=GETDATE() where OrderId ='"+orderID+"'";
		try {
			Object [] param = {};
			returnCode = this.updateBySQL(sql,param);
		} catch (Exception e) {
			this.log.error("updateDeliveryQuantity失败："+e.getMessage());
			e.printStackTrace();
			returnCode =-1;
		}
		this.log.info(this.getClass().getName()+" updateDeliveryQuantity　Dao End");
		return returnCode;
	}

	/**
	 * 根据交收单号获取自提或转让单明细
	 *
	 * @param deliveryID
	 * @return
	 */
	public DeliveryDto getDeliveryDtoDetail(String deliveryID,int deliveryType) {
		String sql="";
		if(deliveryType==0){
			sql = this.sqlProperty.getProperty("DeliveryDAO_043");
		}else{
			sql = this.sqlProperty.getProperty("DeliveryDAO_045");
		}

		Object[] params={deliveryID};
		return (DeliveryDto) this.queryForObject(sql,params,new CommonRowMapper(new DeliveryDto()));
	}

	/**
	 * 根据交收单号拿到明细
	 *
	 * @param deliveryID
	 * @return
	 */
	public Delivery getDeliveryInfo(String deliveryID) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_044");
		Object[] params={deliveryID};
		return (Delivery) this.queryForObject(sql,params,new CommonRowMapper(new Delivery()));
	}

	@Override
	public void rollBack() {
		try {
			getConnection().setAutoCommit(false);//事务设置为手动
			getConnection().rollback();
		} catch (CannotGetJdbcConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	@Override
	public TradeTemplate getTradeTemplateByID(Integer tradeTmptId) {
		String sql = "select * from T_TradeTemplate where TradeTmptId='"+tradeTmptId+"'";
		Object [] params = {};
		return (TradeTemplate) this.queryForObject(sql, params, new CommonRowMapper(new TradeTemplate()));
	}
	/**
	 * 查询 客户违约申请 列表(分页)
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	@Override
	public List<BreachContractApply> queryBreachContractApplyList(QueryConditions qc, PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_042");
		return this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new BreachContractApply()));
	}
	
	@Override
	public int updateTakenBuyPenalty(BigDecimal buyPenalty, String deliveryID,
			String userName) {
		int returnCode = 0;
		String sql ="update T_Delivery set TakenBuyPenalty ="+buyPenalty+",REC_MODIFYTIME=GETDATE(),REC_MODIFYBY='"+userName+"' where  DeliveryID='"+deliveryID+"'";
		try {
			Object [] params= {};
			returnCode = this.updateBySQL(sql,params);
		} catch (Exception e) {
			this.log.error("updateTakenBuyPenalty失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public int updateTakenSellPenalty(BigDecimal sellPenalty, String deliveryID,
			String userName) {
		int returnCode = 0;
		String sql ="update T_Delivery set TakenSellPenalty ="+sellPenalty+",REC_MODIFYTIME=GETDATE(),REC_MODIFYBY='"+userName+"' where  DeliveryID='"+deliveryID+"'";
		try {
			Object [] params= {};
			returnCode = this.updateBySQL(sql,params);
		} catch (Exception e) {
			this.log.error("updateTakenSellPenalty失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	/**
	 * 客户违约申请通过
	 */
	@Override
	public int updateBreachContractApply(
			String deliveryID, String userName,Integer keyID) {
		int returnCode = 0;
		String sql ="update T_BreachContractApply set Status=5, DeliveryID ='"+deliveryID+"',REC_MODIFYTIME=GETDATE(),REC_MODIFYBY='"+userName+"' where  KeyID='"+keyID+"'";
		try {
			Object [] params= {};
			returnCode = this.updateBySQL(sql,params);
		} catch (Exception e) {
			this.log.error("updateBreachContractApply失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public int upateDeliveryDetailBuyProxyFileID(String deliveryID,
			int buyProxyFileID, String userName) {
		this.log.debug(this.getClass().getName()+".upateDeliveryDetailBuyProxyFileID Start");
		int returnCode = 0;
		String sql ="update T_DeliveryDetail set buyProxyFileID ="+buyProxyFileID+",REC_MODIFYTIME=GETDATE(),REC_MODIFYBY='"+userName+"' where  DeliveryID='"+deliveryID+"'";
		try {
			Object [] params= {};
			returnCode = this.updateBySQL(sql,params);
		} catch (Exception e) {
			this.log.error("upateDeliveryDetailBuyProxyFileID失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		this.log.debug(this.getClass().getName()+".upateDeliveryDetailBuyProxyFileID End");
		return returnCode;
	}
	
	@Override
	public int upateTrasferGoodsDetailProxyFile(String deliveryID,
			int buyProxyFileID, int sellProxyFileID, String userName) {
		int returnCode = 0;
		String sql ="update T_TrasferGoodsDetail set buyProxyFileID ="+buyProxyFileID+",sellProxyFileID="+sellProxyFileID+",REC_MODIFYTIME=GETDATE(),REC_MODIFYBY='"+userName+"' where  DeliveryID='"+deliveryID+"'";
		try {
			Object [] params= {};
			returnCode = this.updateBySQL(sql,params);
		} catch (Exception e) {
			this.log.error("upateTrasferGoodsDetailProxyFile失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public int upateTrasferGoodsDetailProxyFileSell(String deliveryID,
			int sellProxyFileID, String userName) {
		this.log.debug(this.getClass().getName()+".upateTrasferGoodsDetailProxyFileSell Start");
		int returnCode = 0;
		String sql ="update T_TrasferGoodsDetail set sellProxyFileID="+sellProxyFileID+",REC_MODIFYTIME=GETDATE(),REC_MODIFYBY='"+userName+"' where  DeliveryID='"+deliveryID+"'";
		try {
			Object [] params= {};
			returnCode = this.updateBySQL(sql,params);
		} catch (Exception e) {
			this.log.error("upateTrasferGoodsDetailProxyFileSell失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		this.log.debug(this.getClass().getName()+".upateTrasferGoodsDetailProxyFileSell End");
		return returnCode;
	}
	@Override
	public int upateTrasferGoodsDetailProxyFileBuy(String deliveryID,
			int buyProxyFileID, String userName) {
		this.log.debug(this.getClass().getName()+".upateTrasferGoodsDetailProxyFileBuy Start");
		int returnCode = 0;
		String sql ="update T_TrasferGoodsDetail set buyProxyFileID ="+buyProxyFileID+",REC_MODIFYTIME=GETDATE(),REC_MODIFYBY='"+userName+"' where  DeliveryID='"+deliveryID+"'";
		try {
			Object [] params= {};
			returnCode = this.updateBySQL(sql,params);
		} catch (Exception e) {
			this.log.error("upateTrasferGoodsDetailProxyFileBuy失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		this.log.debug(this.getClass().getName()+".upateTrasferGoodsDetailProxyFileBuy Start");
		return returnCode;
	}
	@Override
	public List<String> findDeliveryStatusByOrderId(String orderId) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_046");
		Object [] params= {orderId};
		List<String> temp = new ArrayList<String>();
		List<Delivery> list = this.queryBySQL(sql, params, null,new CommonRowMapper(new Delivery()));
		for (Delivery delivery : list){
			temp.add(delivery.getDeliveryStatus().toString());
		}
		return temp;
	}
	
	@Override
	public int updateTakenQuantity(String deliveryID, BigDecimal takenQuantity,String userName) {
		int returnCode = 0;
		String sql ="update T_Delivery set TakenQuantity ="+takenQuantity+",REC_MODIFYTIME=GETDATE(),REC_MODIFYBY='"+userName+"' where  DeliveryID='"+deliveryID+"'";
		try {
			Object [] params= {};
			returnCode = this.updateBySQL(sql,params);
		} catch (Exception e) {
			this.log.error("updateTakenQuantity失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public int addReceipt(String orderID, String userName) {
		String sql = "insert into T_Receipt(OrderID,REC_CREATEBY,REC_CREATETIME,REC_MODIFYBY,REC_MODIFYTIME) VALUES(\u003f,\u003f,GETDATE(),\u003f,GETDATE())";
		Object [] params ={
				orderID,userName,userName
		};
		int fileID;
		try {
			fileID = this.queryForIntID(sql, params);
		} catch (Exception e) {
			this.log.error("addReceipt失败："+e.getMessage());
			e.printStackTrace();
			fileID = -1;
		}
		return fileID;
	}
	
	@Override
	public int deleteaddReceipt(String orderID) {
		List<ReceiptFile> list;
		String sqlList = "select ID as id,OrderID as orderID from T_Receipt where OrderID='"+orderID+"'";
		Object [] params ={};
		list = this.queryBySQL(sqlList, params, null, new CommonRowMapper(new ReceiptFile()));
		String ids = "";
		if(list != null && list.size() > 0){
			for (int i = 0; i < list.size(); i++) {
				if(i > 0)ids+=",";
				ids += list.get(i).getId();
			}
		}else {
			return 0;
		}
		String sql = "delete from T_Receipt_File where ReceiptID in("+ids+")";
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
			returnCode = this.updateBySQL("delete from T_Receipt where OrderID ='"+orderID+"'",params);
		} catch (Exception e) {
			this.log.error("deleteaddReceipt失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	@Override
	public int addReceiptFile(String orderID, int receiptFileID, int fileID,String userName) {
		String sql = "insert into T_Receipt_File(OrderID,ReceiptID,FileID,REC_CREATETIME) VALUES(\u003f,\u003f,\u003f,GETDATE())";
		Object [] params ={
				orderID,receiptFileID,fileID
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error("addReceiptFile失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	@Override
	public int updateOperNotes(String notes,String userId,String deliveryID) {
		this.log.debug("updateOperNotes DAO Start");
		String sql = sqlProperty.getProperty("DeliveryDAO_047");
		Object[] params ={notes,userId,userId,deliveryID};
		int code = 0;
		try {
			code = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error("updateOperNotes失败："+e.getMessage());
			e.printStackTrace();
			code = -1;
		}
		return code;
	}
	
	@Override
	public String findOperNotes(String deliveryID) {
		this.log.debug("findOperNotes DAO Start");
		String sql = sqlProperty.getProperty("DeliveryDAO_048");
		Object[] params ={deliveryID};
		String notes = (String) this.queryForObject(sql, params,String.class);
		return notes;
	}
	
	@Override
	public int getMinQuantity(String orderId) {
		this.log.info(this.getClass().getName()+"getMinQuantity Dao Start");
		String sql = "SELECT MinQuantity from T_Order  WHERE OrderId = '"+orderId+"'";
		int minQuantity = this.queryForInt(sql);
		this.log.info(this.getClass().getName()+"getMinQuantity Dao End");
		return minQuantity;
	}
	/**
	 * 待卖家确认溢短 交收单
	 */
	@Override
	public List<Delivery> getToBeIdentifiedListBySeller() {
		String sql = "select * from T_Delivery where DeliveryStatus = 40";
		Object [] params = {};
		List<Delivery> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new Delivery()));
		return list;
	}
	
	@Override
	public int updateDeliveryDocMarker(String deliveryID, String userName) {
		int returnCode = -1;
		String sql = "update T_Delivery set DocMarker='"+userName+"',REC_MODIFYTIME=GETDATE(),REC_MODIFYBY='"+userName+"' where DeliveryID='"+deliveryID+"'";
		Object [] params = {};
		try {
			returnCode =  this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error("更新制单人出错，交收单号："+deliveryID+"。错误信息："+e.getMessage());
			e.printStackTrace();
			return returnCode;
		}
		return returnCode;
	}

	/**
	 * 客户违约申请添加备注
	 *
	 * @param remrk
	 * @param userId
	 * @param deliveryID @return
	 */
	public int addReamrkBreach(String remrk, String userId, String deliveryID) {
		this.log.debug("addReamrkBreach DAO Start");
		String sql = sqlProperty.getProperty("DeliveryDAO_050");
		Object[] params ={remrk,userId,userId,deliveryID};
		int code = 0;
		try {
			code = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error("addReamrkBreach失败："+e.getMessage());
			e.printStackTrace();
			code = -1;
		}
		return code;
	}

	/**
	 * 客户违约申请获取备注
	 *
	 * @param deliveryID
	 */
	public String readRemarkBreach(String deliveryID) {
		this.log.debug("readRemarkBreach DAO Start");
		String sql = sqlProperty.getProperty("DeliveryDAO_051");
		Object[] params ={deliveryID};
		String notes = (String) this.queryForObject(sql, params,String.class);
		return notes;
	}
	
	/**
	 * 订单 买方交易已收保证金		BuyTakenTradeDeposit										
	 */
	@Override
	public int updateOrderBuyTakenTradeDeposit(String orderId,
			BigDecimal takenBSDeposit) {
		int retrunCode = 0;
		String sql = "update T_Order set BuyTakenTradeDeposit=BuyTakenTradeDeposit-"+takenBSDeposit+" where OrderId='"+orderId+"'";
		try {
			Object [] params = {};
			retrunCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error("updateOrderBuyTakenTradeDeposit失败："+e.getMessage());
			e.printStackTrace();
			retrunCode = -1;
		}
		return retrunCode;
	}
	
	@Override
	public int updateOrderSellTakenTradeDeposit(String orderId,
			BigDecimal sellTakenSSDeposit) {
		int retrunCode = 0;
		String sql = "update T_Order set SellTakenTradeDeposit=SellTakenTradeDeposit-"+sellTakenSSDeposit+" where OrderId='"+orderId+"'";
		try {
			Object [] params = {};
			retrunCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error("updateOrderSellTakenTradeDeposit失败："+e.getMessage());
			e.printStackTrace();
			retrunCode = -1;
		}
		return retrunCode;
	}
	
	/**
	 * 更新：卖方交易保证金授信
	 */
	@Override
	public int updateOrderSellCreditDeposit(String orderId,
			BigDecimal sellCreditDeposit) {
		int retrunCode = 0;
		String sql = "update T_Order set SellCreditDeposit=SellCreditDeposit-"+sellCreditDeposit+" where OrderId='"+orderId+"'";
		try {
			Object [] params = {};
			retrunCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error("updateOrderSellCreditDeposit失败："+e.getMessage());
			e.printStackTrace();
			retrunCode = -1;
		}
		return retrunCode;
	}
	@Override
	public int updateDeliveryOfPayedMoneyByDeliveryID(String deliveryID, String userID,
			BigDecimal payedMoney) {
		this.log.info(this.getClass().getName()+" Dao updateDeliveryOfPayedMoneyByDeliveryID Start");
		String sql = sqlProperty.getProperty("DeliveryDAO_052");
		Object [] params = {payedMoney,userID,deliveryID};
		int count = this.updateBySQL(sql, params);
		this.log.info(this.getClass().getName()+"Dao updateDeliveryOfPayedMoneyByDeliveryID End");
		return count;
	}
	@Override
	public int updateBuyTakenTradeDeposit(String orderId,
			BigDecimal takenBSDeposit,String userID) {
		String sql = "update T_Order set BuyTakenTradeDeposit=BuyTakenTradeDeposit-"+takenBSDeposit+",REC_MODIFYTIME=getDate(),REC_MODIFYBY='"+userID
			+"'  where OrderId='"+orderId+"'";
		int returnCode;
		Object [] params ={};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error("updateBuyTakenTradeDeposit失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	
	@Override
	public int updatePaidAmount(String orderId, BigDecimal takenMoney,
			String userName) {
		String sql = "update T_Order set PaidAmount=PaidAmount-"+takenMoney+",REC_MODIFYTIME=getDate(),REC_MODIFYBY='"+userName
				+"'  where OrderId='"+orderId+"'";
		int returnCode;
		Object [] params ={};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error("updatePaidAmount失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public int updateBuyTakenTradeFee(String orderId, BigDecimal takenBSFee,
			String userName) {
		String sql = "update T_Order set BuyTakenTradeFee=BuyTakenTradeFee-"+takenBSFee+",REC_MODIFYTIME=getDate(),REC_MODIFYBY='"+userName
				+"'  where OrderId='"+orderId+"'";
		int returnCode;
		Object [] params ={};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error("updateBuyTakenTradeFee失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public int updateSellTakenTradeFee(String orderId,
			BigDecimal violationPenalty, String userName) {
		String sql = "update T_Order set SellTakenTradeFee=SellTakenTradeFee-"+violationPenalty+",REC_MODIFYTIME=getDate(),REC_MODIFYBY='"+userName
				+"'  where OrderId='"+orderId+"'";
		int returnCode;
		Object [] params ={};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error("updateSellTakenTradeFee失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public int updatePaidSellAmount(String orderId, BigDecimal payedMoney,
			String userName) {
		String sql = "update T_Order set PaidSellAmount=PaidSellAmount-"+payedMoney+",REC_MODIFYTIME=getDate(),REC_MODIFYBY='"+userName
				+"'  where OrderId='"+orderId+"'";
		int returnCode;
		Object [] params ={};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error("updatePaidSellAmount失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	public int updateSellTakenTradeDeposit(String orderId, BigDecimal sellTakenSSDeposit, String userName) {
		String sql = "update T_Order set SellTakenTradeDeposit=SellTakenTradeDeposit-"+sellTakenSSDeposit+",REC_MODIFYTIME=getDate(),REC_MODIFYBY='"+userName
				+"'  where OrderId='"+orderId+"'";
		int returnCode;
		Object [] params ={};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error("updateSellTakenTradeDeposit失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public int updateBuyCreditDeposit(String orderId,
			BigDecimal buyCreditDeposit, String userName) {
		String sql = "update T_Order set BuyCreditDeposit=BuyCreditDeposit-"+buyCreditDeposit+",REC_MODIFYTIME=getDate(),REC_MODIFYBY='"+userName
				+"'  where OrderId='"+orderId+"'";
		int returnCode;
		Object [] params ={};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error("updateBuyCreditDeposit失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public Delivery getDeliveryByID(String deliveryID) {
		String sql = "select * from T_Delivery where DeliveryID ='"+deliveryID+"'";
		Object [] params ={};
		Delivery delivery = (Delivery) this.queryForObject(sql, params, new CommonRowMapper(new Delivery()));
		return delivery;
	}
	
	@Override
	public int addDelDistributionDetail(
			DelDistributionDetail delDistributionDetail, String userName) {
		String sql = this.sqlProperty.getProperty("DelDistributionDetail_001");
		Object [] params = {
//				delDistributionDetail.getDeliveryID(),//交收ID								DeliveryID										
//				delDistributionDetail.getDISABLED(),//	默认为 0：正常，1：失效								DISABLED										
//				delDistributionDetail.getLogisticsID(),//		物流ID								LogisticsID										
//				delDistributionDetail.getLogiisticsDetai(),//		物流详细								LogiisticsDetai	
//				delDistributionDetail.getAddressID(),//		配送地址ID								AddressID										
//				delDistributionDetail.getAddressDetail(),//		配送地址								AddressDetail										
//				delDistributionDetail.getContactTel(),//		联系电话								ContactTel										
//				delDistributionDetail.getContactName(),//		联系人姓名								ContactName										
//				delDistributionDetail.getRemark(),//		备注								Remark										
				userName,//	创建人								REC_CREATEBY	
				userName//	最后修改人								REC_MODIFYBY	
		};
		int returnCode;
		try {
			returnCode =  this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error("addDelDistributionDetail失败："+e.getMessage());
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public int updateDeliveryFrightFeeOfPaidSellFreightByOrderID(String orderId,String userId) {
		this.log.info(this.getClass().getName()+" updateDeliveryFrightFeeOfPaidSellFreightByOrderID dao Start");
		String sql = this.sqlProperty.getProperty("DeliveryFreightFeeDAO_001");
		Object[] params = {userId,userId,orderId};
		int code = this.updateBySQL(sql, params);
		this.log.info(this.getClass().getName()+" updateDeliveryFrightFeeOfPaidSellFreightByOrderID dao End");
		return code;
	}

	@Override
	public List<DeliveryFreightFee> selectDeliveryFrightFee(String orderId) {
		this.log.info(this.getClass().getName()+" selectDeliveryFrightFee dao Start");
		String sql = this.sqlProperty.getProperty("DeliveryFreightFeeDAO_002");
		Object[] params = {orderId};
		List<DeliveryFreightFee> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new DeliveryFreightFee()));
		this.log.info(this.getClass().getName()+" selectDeliveryFrightFee dao End");
		return list;
	}
	@Override
	public DeliveryFreightFee selectDeliveryFrightFeeByDeliveryID(String deliveryID) {
		this.log.info(this.getClass().getName()+" selectDeliveryFrightFeeByDeliveryID dao Start");
		String sql = this.sqlProperty.getProperty("DeliveryFreightFeeDAO_003");
		Object[] params = {deliveryID};
		DeliveryFreightFee deliveryFrightFee = (DeliveryFreightFee) this.queryForObject(sql, params, new CommonRowMapper(new DeliveryFreightFee()));
		this.log.info(this.getClass().getName()+" selectDeliveryFrightFeeByDeliveryID dao End");
		return deliveryFrightFee;
	}
	@Override
	public int updateDeliveryFrightFeeByDeliveryID(String deliveryID,
			BigDecimal buyShouldPayFreight, BigDecimal buyPaidFreight,
			String userId) {
		this.log.info(this.getClass().getName()+" updateDeliveryFrightFeeByDeliveryID dao Start");
		String sql = this.sqlProperty.getProperty("DeliveryFreightFeeDAO_004");
		Object[] params = {buyShouldPayFreight,buyPaidFreight,userId,deliveryID};
		int count = this.updateBySQL(sql, params);
		this.log.info(this.getClass().getName()+" updateDeliveryFrightFeeByDeliveryID dao End");
		return count;
	}	
	
	@Override
	public DelDistributionDetail getDelDistributionDetail(String deliveryID) {
		this.log.info(this.getClass().getName()+" getDeliveryFreightFee dao Start");
		String sql = "select * from T_DelDistributionDetail where DeliveryID='"+deliveryID+"'";
		Object [] param ={};
		DelDistributionDetail delDistributionDetail = (DelDistributionDetail) this.queryForObject(sql, param,new CommonRowMapper(new DelDistributionDetail()));
		this.log.info(this.getClass().getName()+" getDeliveryFreightFee dao End");
		return delDistributionDetail;
		
	}
	
	@Override
	public DeliveryFreightFee getDeliveryFreightFee(String deliveryID) {
		this.log.info(this.getClass().getName()+" getDeliveryFreightFee dao Start");
		String sql = "select t1.*,t1.ShouldPaySellPenalty as shouldPaySellFreight from T_DeliveryFreightFee t1 where t1.DeliveryID='"+deliveryID+"'";
		Object [] param ={};
		DeliveryFreightFee deliveryFreightFee = (DeliveryFreightFee) this.queryForObject(sql, param,new CommonRowMapper(new DeliveryFreightFee()));
		this.log.info(this.getClass().getName()+" getDeliveryFreightFee dao End");
		return deliveryFreightFee;
	}
	@Override
	public int disabledDeliveryFreightFeeByDeliveryID(String userId,String deliveryID) {
		this.log.info(this.getClass().getName()+" disabledDeliveryFreightFeeByDeliveryID dao Start");
		String sql = this.sqlProperty.getProperty("DeliveryFreightFeeDAO_005");
		Object[] params = {userId,deliveryID};
		int count = this.updateBySQL(sql, params);
		this.log.info(this.getClass().getName()+" disabledDeliveryFreightFeeByDeliveryID dao End");
		return count;
	}
	@Override
	public int updateDeliveryFreightFeeOfOverloadFreightByDeliveryID(
			BigDecimal overloadFreight, String userId, String deliveryID) {
		this.log.info(this.getClass().getName()+" updateDeliveryFreightFeeOfOverloadFreightByDeliveryID dao Start");
		String sql = this.sqlProperty.getProperty("DeliveryFreightFeeDAO_006");
		Object[] params = {overloadFreight,userId,deliveryID};
		int count = this.updateBySQL(sql, params);
		this.log.info(this.getClass().getName()+" updateDeliveryFreightFeeOfOverloadFreightByDeliveryID dao End");
		return count;
	}
	@Override
	public List<BreachContractApply> getBreachContractApplyListByID(String ID) {
		this.log.info(this.getClass().getName()+" getBreachContractApplyListByID dao Start");
		String sql = this.sqlProperty.getProperty("DeliveryDAO_054");
		Object[] params = {ID};
		List<BreachContractApply> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new BreachContractApply()));
		this.log.info(this.getClass().getName()+" getBreachContractApplyListByID dao End");
		return list;
	}

	@Override
	public BreachContractApply getBreachContractApplyByDeliveryID(
			String deliveryID) {
		this.log.info(this.getClass().getName()+" getBreachContractApplyByDeliveryID dao Start");
		String sql = this.sqlProperty.getProperty("DeliveryDAO_055");
		Object[] params = {deliveryID};
		BreachContractApply apply = (BreachContractApply) this.queryForObject(sql, params, new CommonRowMapper(new BreachContractApply()));
		this.log.info(this.getClass().getName()+" getBreachContractApplyByDeliveryID dao End");
		return apply;
	}
	@Override
	public int updateDeliveryOfIsGetSinopecNumber(String deliveryID,
			Integer isGetSinopecNumber, String userName) {
		this.log.info(this.getClass().getName()+" updateDeliveryOfIsGetSinopecNumber dao Start");
		String sql = this.sqlProperty.getProperty("DeliveryDAO_056");
		Object[] params = {isGetSinopecNumber,userName,deliveryID};
		int count = this.updateBySQL(sql, params);
		this.log.info(this.getClass().getName()+" updateDeliveryOfIsGetSinopecNumber dao End");
		return count;
	}
	
	@Override
	public int doReceive(String deliveryID, String userName) {
		this.log.info(this.getClass().getName()+" doReceive dao Start");
		String sql = this.sqlProperty.getProperty("DeliveryDAO_059");
		Object[] params = {userName,deliveryID};
		int count = this.updateBySQL(sql, params);
		this.log.info(this.getClass().getName()+" doReceive dao End");
		return count;
	}
	
	@Override
	public List<OrderSinopec> getDeliverySinopecFile(String deliveryID) {
		this.log.info(this.getClass().getName()+" getDeliverySinopecFile dao Start");
		String sql = "select * from T_OrderSinopec where DeliveryID ='"+deliveryID+"' and UploadType = 0";
		Object [] params = {};
		List<OrderSinopec> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new OrderSinopec()));
		this.log.info(this.getClass().getName()+" getDeliverySinopecFile dao End");
		return list;
	}
	@Override
	public List<Delivery> getDeliveryOfDelDistributionDetailList(
			QueryConditions qc, PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+" getDeliveryOfDelDistributionDetailList dao Start");
		String sql = this.sqlProperty.getProperty("ExportDelDistributionDetailDAO_002");
		List<Delivery> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new Delivery()));
		this.log.info(this.getClass().getName()+" getDeliveryOfDelDistributionDetailList dao End");
		return list;
	}
	
	@Override
	public int getDeliverySinopecQuantity(String orderID) {
		this.log.info(this.getClass().getName()+" getDeliverySinopecQuantity dao Start");
		String sql = "select  ISNULL(SUM(DeliveryQuantity), 0) from T_Delivery where OrderId='"+orderID+"' and DeliveryStatus = 75";
		int deliverySinopecQuantity = this.queryForInt(sql);
		this.log.info(this.getClass().getName()+" getDeliverySinopecQuantity dao End");
		return deliverySinopecQuantity;
	}
	
	/**
	 * 已经交收的数量(不包括撤销的交收单)
	 */
	@Override
	public int getTotalDeliveryQuantity(String orderId) {
		this.log.info(this.getClass().getName()+" getTotalDeliveryQuantity dao Start");
		String sql = "select ISNULL(SUM(DeliveryQuantity), 0) from T_Delivery where OrderId='"+orderId+"' and DeliveryStatus != 70 and DeliveryStatus != 75 ";
		int totalDeliveryQuantity = this.queryForInt(sql);
		this.log.info(this.getClass().getName()+" getTotalDeliveryQuantity dao End");
		return totalDeliveryQuantity;
	}
	
	/**
	 * 同一订单 卖方交收已收总额 					
	 */
	@Override
	public BigDecimal getTotalDeliveryExpense(String orderId, String deliveryExpenseName) {
		this.log.info(this.getClass().getName()+" getTotalDeliveryExpense dao Start");
		String sql = "select ISNULL(SUM("+deliveryExpenseName+"), 0) as totalDeliveryExpense from T_Delivery where OrderId='"+orderId+"' and "
				+ "DeliveryStatus in(1,5,10,15,17,20,25,30,35,40,45,50)  OR (OrderId='"+orderId+"' and DeliveryStatus IN(60,65) AND TailAdjustStatus != 10 )";
		Object [] params = {};
		Order order = (Order) this.queryForObject(sql, params, new CommonRowMapper(new Order()));
		this.log.info(this.getClass().getName()+" getTotalDeliveryExpense dao End");
		return new BigDecimal(order.getTotalDeliveryExpense());
	}
	
	@Override
	public BigDecimal getTotalDeliveryTakenBSFeeExpense(String orderId,
			String deliveryExpenseName) {
		this.log.info(this.getClass().getName()+" getTotalDeliveryTakenBSFeeExpense dao Start");
		String sql = "select ISNULL(SUM("+deliveryExpenseName+"), 0) as totalDeliveryExpense from T_Delivery where OrderId='"+orderId+"' and "
				+ "(DeliveryStatus in(1,5,10,15,17,20,25,30,35,40,45,50,55,65)  OR (DeliveryStatus IN(60) AND TailAdjustStatus != 10 ) OR ProcessStatus = 2)";
		Object [] params = {};
		Order order = (Order) this.queryForObject(sql, params, new CommonRowMapper(new Order()));
		this.log.info(this.getClass().getName()+" getTotalDeliveryTakenBSFeeExpense dao End");
		return new BigDecimal(order.getTotalDeliveryExpense());
	}
	
	@Override
	public BigDecimal getShouldTotalDeliveryExpense(String orderId,
			String deliveryExpenseName) {
		this.log.info(this.getClass().getName()+" getTotalDeliveryExpense dao Start");
		String sql = "select ISNULL(SUM("+deliveryExpenseName+"), 0) as totalDeliveryExpense from T_Delivery where OrderId='"+orderId+"' and "
				+ "DeliveryStatus != 70";
		Object [] params = {};
		Order order = (Order) this.queryForObject(sql, params, new CommonRowMapper(new Order()));
		this.log.info(this.getClass().getName()+" getTotalDeliveryExpense dao End");
		return new BigDecimal(order.getTotalDeliveryExpense());
	}
	
	/**
	 * 更新中石化交收状态：已取消,并且相关交收费用全部置为0 
	 */
	@Override
	public int updateDeliveryStatus4Distribution(int deliveryStatus,
			String deliveryID, String userID) {
		this.log.info(this.getClass().getName()+" updateDeliveryStatus4Distribution dao Start");
		String sql = "update T_Delivery set DeliveryStatus ="+deliveryStatus+",REC_MODIFYBY='"+userID+"',REC_MODIFYTIME=GETDATE() "
			+ ",SellSettleDeposit="+new BigDecimal(0)
			+ ",SellTakenSSDeposit="+new BigDecimal(0)
			+ ",SellCreditDeposit="+new BigDecimal(0)
			+ ",TakenBSFee="+new BigDecimal(0)
		+ ",TakenBSDeposit="+new BigDecimal(0)
		+ ",SellPenalty="+new BigDecimal(0)
		+ ",TakenSellPenalty="+new BigDecimal(0)
		+ ",BuyPenalty="+new BigDecimal(0)
		+ ",TakenBuyPenalty="+new BigDecimal(0)
		+ ",TakenMoney="+new BigDecimal(0)
		+ ",PayedMoney="+new BigDecimal(0)
		+ ",Money="+new BigDecimal(0)
				+ " where deliveryID='"+deliveryID+"'";
		Object [] param ={};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql,param);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" updateDeliveryStatus 失败");
			e.printStackTrace();
			returnCode = -1;
		}
		this.log.info(this.getClass().getName()+" updateDeliveryStatus4Distribution dao End");
		return returnCode;
	}
	@Override
	public List<DeliveryFreightFee> selectDeliveryFrightFeeOrderId(String orderId) {
		this.log.info(this.getClass().getName()+" selectDeliveryFrightFeeOrderId dao Start");
		String sql = this.sqlProperty.getProperty("DeliveryFreightFeeDAO_007");
		Object[] params = {orderId};
		List<DeliveryFreightFee> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new DeliveryFreightFee()));
		this.log.info(this.getClass().getName()+" selectDeliveryFrightFeeOrderId dao End");
		return list;
	}
	/**
	 * 导出交收列表（导出现货，预售，中石化用）
	 */
	@Override
	public List<Delivery4Export> exportNewDeliveryList(QueryConditions qc,
			PageInfo pageInfo, boolean replace) {
		this.log.info(this.getClass().getName()+" exportNewDeliveryList dao Start");
		String sql = this.sqlProperty.getProperty("ExportDeliveryDao_002");
		if (replace) sql = sql.replace("SELECT", "SELECT top "+Constants.EXPORT_MAX_COUNT+" ");
		List<Delivery4Export> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new Delivery4Export()));
		this.log.info(this.getClass().getName()+" exportNewDeliveryList dao End");
		return list;
	}
	
	/**
	 * 运费调整额    
	 */
	@Override
	public BigDecimal getSensedFreightFee(String deliveryID) {
		this.log.info(this.getClass().getName()+" getSensedFreightFee Start");
		String sql = "select OverloadFreight from T_DeliveryFreightFee where DeliveryID='"+deliveryID+"'";
		Object [] params = {
				
		};
		FinancialBills financialBills = (FinancialBills) this.queryForObject(sql, params, new CommonRowMapper(new FinancialBills()));
		this.log.info(this.getClass().getName()+" getSensedFreightFee End");
		return financialBills.getOverloadFreight();
	}
	
	@Override
	public int getExportDeliveryListCount(QueryConditions qc, PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+" getExportDeliveryListCount Start");
		String sql = this.sqlProperty.getProperty("DeliveryDAO_001");//
		int totalRecords = 0;
		totalRecords = getTotalCount(sql,qc);
		this.log.info(this.getClass().getName()+" getExportDeliveryListCount End");
		return totalRecords;
	}
	
	@Override
	public int exportNewDeliveryListListCount(QueryConditions qc,
			PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("ExportDeliveryDao_002");
		int totalRecords = 0;
		totalRecords = getTotalCount(sql,qc);
		this.log.info(this.getClass().getName()+" getExportDeliveryListCount End");
		return totalRecords;
	}
	
	@Override
	public int getDeliveryInvoice4ExportCount(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+" getDeliveryInvoice4ExportCount Start");
		String sql = this.sqlProperty.getProperty("DeliveryInvoiceDAO_001");
		int totalRecords = 0;
		totalRecords = getTotalCount(sql,qc);
		this.log.info(this.getClass().getName()+" getDeliveryInvoice4ExportCount End");
		return totalRecords;
	}
	
	@Override
	public int updateTakenBSFee(BigDecimal buyTradeFee, String deliveryID,String userName) {
		this.log.info(this.getClass().getName()+" updateTakenBSFee Start");
		String sql = this.sqlProperty.getProperty("DeliveryDAO_049");
		int returnCode = 0;
		Object[] param ={
				buyTradeFee,userName,deliveryID	
		};
		try {
			returnCode = this.updateBySQL(sql, param);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" updateTakenBSFee 出错："+e.getMessage());
			returnCode = -1;
		}
		this.log.info(this.getClass().getName()+" updateTakenBSFee Start");
		return returnCode;
	}
	
	@Override
	public Integer getDeliveryQuantitys(String orderId) {
		this.log.info(this.getClass().getName()+" getDeliveryQuantitys Start");
		String sql = this.sqlProperty.getProperty("DeliveryDAO_057");
		int deliveryQuantitys = 0;
		Object[] param ={
				orderId
		};
		try {
			deliveryQuantitys = this.queryForInt(sql,param);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" getDeliveryQuantitys 出错："+e.getMessage());
			deliveryQuantitys = 0;
		}
		this.log.info(this.getClass().getName()+" getDeliveryQuantitys Start");
		return deliveryQuantitys;
	}

	@Override
	public Delivery getDeliveryByDeliveryID(String deliveryID) {
		String sql = this.sqlProperty.getProperty("DeliveryDAO_058");
		Delivery delivery = null;
		Object[] param = {
				deliveryID
		};
		try {
			delivery = (Delivery) this.queryForObject(sql, param, new CommonRowMapper(new Delivery()));
		} catch (Exception e) {
			this.log.debug(this.getClass().getName()+"getDeliveryByDeliveryID.. 失败"+e.getMessage());
			delivery = null;
		}
		return delivery;
	}
	
}
