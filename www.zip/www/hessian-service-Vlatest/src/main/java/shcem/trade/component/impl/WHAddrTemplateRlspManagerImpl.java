package shcem.trade.component.impl;

import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.trade.component.IWHAddrTemplateRlspManager;
import shcem.trade.dao.IWHAddrTemplateRlspDao;
import shcem.trade.dao.model.WHAddrTemplateRlsp;
import shcem.trade.dao.model.WareHouse;
import shcem.trade.dao.model.WareHouseAddress;
import shcem.trade.dao.model.WareHouseGroup;

public class WHAddrTemplateRlspManagerImpl  extends BaseManager implements IWHAddrTemplateRlspManager {

	private IWHAddrTemplateRlspDao whAddrTemplateRlspDao;
	private IWHAddrTemplateRlspDao whAddrTemplateRlspDao_read;
	public void setWhAddrTemplateRlspDao(IWHAddrTemplateRlspDao whAddrTemplateRlspDao) {
		this.whAddrTemplateRlspDao = whAddrTemplateRlspDao;
	}

	public void setWhAddrTemplateRlspDao_read(IWHAddrTemplateRlspDao whAddrTemplateRlspDao_read) {
		this.whAddrTemplateRlspDao_read = whAddrTemplateRlspDao_read;
	}

	@Override
	public int addWHAddrTemplateRlsp(WHAddrTemplateRlsp wHAddrTemplateRlsp) {
		this.log.debug(this.getClass().getName()+"addWHAddrTemplateRlsp Start");
		
		int[] wareHouseIDArr = wHAddrTemplateRlsp.getWareHouseIDArr();
		int count = 0;
		for(int wareHouseID : wareHouseIDArr){
			wHAddrTemplateRlsp.setWareHouseID(wareHouseID);
			if (wareHouseID == -1){
				// 删除已经存在的数据
				count = whAddrTemplateRlspDao.disableWHAddrTemplateRlspForMore(wHAddrTemplateRlsp.getWareHouseAddressID(),wHAddrTemplateRlsp.getTradeTmptId(), 1, wHAddrTemplateRlsp.getREC_MODIFYBY());
				this.log.debug("disabled掉"+count+"条,WareHouseAddressID:"+wHAddrTemplateRlsp.getWareHouseAddressID()+",TradeTmptId:"+wHAddrTemplateRlsp.getTradeTmptId());
				// 根据仓库地址ID 查询 仓库货代表列表
				QueryConditions qc = new QueryConditions();
				qc.addCondition("wareHouse.WHAddressID", "=", wHAddrTemplateRlsp.getWareHouseAddressID(), "int");
				List<WareHouse> wareHouselist = whAddrTemplateRlspDao.selectWareHouseList(qc, null);
				int countTemp = 0;
				// 插入全部仓库名数据
				for (WareHouse wareHouse : wareHouselist){
					wHAddrTemplateRlsp.setWareHouseID(wareHouse.getId());
					int countT = whAddrTemplateRlspDao.addWHAddrTemplateRlsp(wHAddrTemplateRlsp);
					countTemp +=countT;
				}
				count = countTemp;
				this.log.debug("新增"+countTemp+"条,WareHouseAddressID:"+wHAddrTemplateRlsp.getWareHouseAddressID()+",TradeTmptId:"+wHAddrTemplateRlsp.getTradeTmptId());
			}else{
				// 删除已经存在的数据
				count = whAddrTemplateRlspDao.disableWHAddrTemplateRlspForOne(wHAddrTemplateRlsp.getWareHouseAddressID(), wareHouseID, wHAddrTemplateRlsp.getTradeTmptId(), 1, wHAddrTemplateRlsp.getREC_MODIFYBY());
				this.log.debug("disabled掉"+count+"条,WareHouseAddressID:"+wHAddrTemplateRlsp.getWareHouseAddressID()+",WareHouseID:"+wareHouseID+",TradeTmptId:"+wHAddrTemplateRlsp.getTradeTmptId());
				// 新增
				count = whAddrTemplateRlspDao.addWHAddrTemplateRlsp(wHAddrTemplateRlsp);
				this.log.debug("新增"+count+"条,WareHouseAddressID:"+wHAddrTemplateRlsp.getWareHouseAddressID()+",WareHouseID:"+wareHouseID+",TradeTmptId:"+wHAddrTemplateRlsp.getTradeTmptId());
			}
		}
		
		
		this.log.debug(this.getClass().getName()+"addWHAddrTemplateRlsp End");
		return count;
	}

	@Override
	public int updateWHAddrTemplateRlspById(WHAddrTemplateRlsp wHAddrTemplateRlsp) {
		this.log.debug(this.getClass().getName()+"updateWHAddrTemplateRlspById Start");
		int count = whAddrTemplateRlspDao.updateWHAddrTemplateRlspById(wHAddrTemplateRlsp);
		this.log.debug(this.getClass().getName()+"updateWHAddrTemplateRlspById End");
		return count;
	}

	@Override
	public List<WHAddrTemplateRlsp> selectWHAddrTemplateRlspList(QueryConditions qc, PageInfo pageInfo) {
		this.log.debug(this.getClass().getName()+"selectWHAddrTemplateRlspList Start");
		List<WHAddrTemplateRlsp> list = whAddrTemplateRlspDao_read.selectWHAddrTemplateRlspList(qc, pageInfo);
		this.log.debug(this.getClass().getName()+"selectWHAddrTemplateRlspList End");
		return list;
	}

	@Override
	public WHAddrTemplateRlsp selectWHAddrTemplateRlspById(Integer id) {
		this.log.debug(this.getClass().getName()+"selectWHAddrTemplateRlspById Start");
		WHAddrTemplateRlsp wHAddrTemplateRlsp = whAddrTemplateRlspDao_read.selectWHAddrTemplateRlspById(id);
		this.log.debug(this.getClass().getName()+"selectWHAddrTemplateRlspById End");
		return wHAddrTemplateRlsp;
	}

	@Override
	public List<WareHouseAddress> selectWareHouseAddressList(
			QueryConditions qc, PageInfo pageInfo) {
		this.log.debug(this.getClass().getName()+"selectWareHouseAddressList Start");
		List<WareHouseAddress> list = whAddrTemplateRlspDao_read.selectWareHouseAddressList(qc, pageInfo);
		this.log.debug(this.getClass().getName()+"selectWareHouseAddressList End");
		return list;
	}

	@Override
	public List<WareHouse> selectWareHouseList(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.debug(this.getClass().getName()+"selectWareHouseList Start");
		List<WareHouse> list = whAddrTemplateRlspDao_read.selectWareHouseList(qc, pageInfo);
		this.log.debug(this.getClass().getName()+"selectWareHouseList End");
		return list;
	}

	@Override
	public int deleteWHAddrTemplateRlspById(int[] idArr,String userName) {
		this.log.debug(this.getClass().getName()+"deleteWHAddrTemplateRlspById Start");
		this.log.debug("idArr:"+idArr);
		int count = 0;
		for (int id: idArr){
			int c = whAddrTemplateRlspDao.disableWHAddrTemplateRlspById(id, userName);
			count +=c; 
		}
		this.log.debug("删除掉："+count+"条");
		this.log.debug(this.getClass().getName()+"deleteWHAddrTemplateRlspById End");
		return count;
	}
	
	@Override
	public List<WareHouseGroup> getWareHouseGroupList(QueryConditions qc, PageInfo pageInfo) {
		this.log.debug(this.getClass().getName()+"getWareHouseGroupList Start");
		List<WareHouseGroup> list = whAddrTemplateRlspDao_read.getWareHouseGroupList(qc, pageInfo);
		this.log.debug(this.getClass().getName()+"getWareHouseGroupList End");
		return list;
	}
	
}
