package shcem.trade.component;

import java.util.List;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.trade.dao.ISpecialOprDAO;
import shcem.trade.dao.model.SpecialOpr;
import shcem.trade.dao.model.SpecialOprDetail;
import shcem.trade.service.model.SpecialOprDto;

public abstract interface ISpecialOprManager extends Manager {
	public abstract void setSpecialOprDAO(ISpecialOprDAO specialOprDAO);

	public abstract void addSpecialOpr(SpecialOpr specialOpr, String userID);

	public abstract List<SpecialOpr> getSpecialOprList(QueryConditions qc,
			PageInfo pageInfo, boolean replace);

	public abstract void updateSpecialOpr(int[] specialOprIDs, String userID);

	public abstract shcem.trade.dao.model.SpecialOpr getSpecialOprDetail(
			int specialOprID);
	/**
	 * 插入特殊流程记录
	 * @param specialOpr
	 * @return 主键
	 */
	public abstract int insertSpecialOpr(SpecialOpr specialOpr);
	
	/**
	 * 查询 尾调款待催 列表
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<SpecialOprDto> selectSpecialOprList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 插入 特殊流程执行项明细表
	 */
	void insertSpecialOprDetail(List<SpecialOprDetail> detailList,String specialOprID);
	
	/**
	 * 根据specialOprID 查询 特殊流程执行项明细列表
	 */
	List<SpecialOprDetail> selectSpecialOprDetailListBySpecialOprID(String specialOprID);
	
	/**
	 * 根据ID 更新  特殊流程执行项明细表的 状态
	 */
	int updateSpecialOprDetailOfStatusByID(String id,String username,Integer Status);
	
	/**
	 * 根据ID 更新  特殊流程执行项明细表的 删除状态
	 */
	void updateSpecialOprDetailOfDisabledByID(String id,String username,Integer disbaled);
	
	/**
	 * 根据ID 查询 特殊流程执行项明细信息
	 */
	SpecialOprDetail selectSpecialOprDetailByID(Integer id);
	
	/**
	 * 根据参数状态 统计 特殊流程执行项明细信息 的条数
	 * @param detail
	 */
	Integer countSpecialOprDetail(String specialOprID,Integer disbaled,Integer status);
	
	/**
	 * 根据 specialOprID 拒绝当前流程
	 */
	int refuseSpecialOprOfStatusByID(Integer id,String userName);

	public abstract int getSpecialOprCount(QueryConditions qc);

}
