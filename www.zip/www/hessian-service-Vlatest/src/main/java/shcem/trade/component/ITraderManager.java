/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: TraderManager
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.trade.component;

import java.util.Date;
import java.util.List;
import java.util.Map;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.trade.dao.TraderDAO;
import shcem.trade.dao.model.CSRemindRemark;
import shcem.trade.dao.model.EnquiryLiner;
import shcem.trade.dao.model.ExportEnquiry;
import shcem.trade.dao.model.ExportEnquiryCounter;
import shcem.trade.dao.model.FirmPrivilege;
import shcem.trade.dao.model.FirmSpecialFee;
import shcem.trade.dao.model.FirmSpecialMargin;
import shcem.trade.dao.model.FirmSpecialSettleFee;
import shcem.trade.dao.model.FirmSpecialSettleMargin;
import shcem.trade.dao.model.NotTradeDay;
import shcem.trade.dao.model.TTradeTime;
import shcem.trade.dao.model.TemplatePrivilege;
import shcem.trade.dao.model.TmptSectionRlsp;
import shcem.trade.dao.model.TradeTemplate;
import shcem.trade.dao.model.TradeTime;
import shcem.trade.dao.model.TraderPrivilege;
import shcem.trade.service.model.SpecialOprDto;

/**
 * TraderManager
 * 
 * @author chiyong
 * @version 1.0
 */
public abstract interface ITraderManager extends Manager {

	public abstract void setTraderDAO(TraderDAO paramTraderDAO);

	/**
	 * 取得TradeTimes列表
	 * 
	 * @param paramTradeTime
	 *            TradeTime
	 * @return TradeTimes列表
	 */
	public abstract List<Map<String, Object>> getTradeTimes(TradeTime paramTradeTime);

	/**
	 * 取得TradeTime
	 * 
	 * @param paramString
	 *            sectionId
	 * @return TradeTime
	 */
	public abstract TradeTime getTradeTime(String paramString);

	/**
	 * 取得sectionId列表
	 * 
	 * @param paramString
	 *            sectionId
	 * @return sectionId列表
	 */
	public abstract List<Map<String, Object>> getTradeTimeId(String paramString);

	/**
	 * 追加TradeTime表
	 * 
	 * @param paramTradeTime
	 *            TradeTime
	 */
	public abstract void insertTradeTime(TradeTime paramTradeTime);

	/**
	 * 更新TradeTime表
	 * 
	 * @param paramTradeTime
	 *            TradeTime
	 */
	public abstract void updateTradeTime(TradeTime paramTradeTime);

	/**
	 * 取得TradeTimeBreed列表
	 * 
	 * @param paramString
	 *            sectionId
	 * @return TradeTimeBreed列表
	 */
	public abstract List<Map<String, Object>> getTradeTimeBreed(String paramString);

	/**
	 * 取得TradeTimeRelBreed列表
	 * 
	 * @param paramString
	 *            sectionId
	 * @return TradeTimeRelBreed列表
	 */
	public abstract List<Map<String, Object>> getTradeTimeRelBreed(String paramString);

	/**
	 * 删除TradeTime表
	 * 
	 * @param paramTradeTime
	 *            sectionid
	 */
	public abstract void deleteTradeTimeById(String paramString);

	/**
	 * 取得系统时间
	 * 
	 * 
	 * @return 系统时间
	 */
	public abstract String getSysdate();

	/**
	 * 
	 */
	public abstract List<TradeTemplate> getTradeTemplateList(QueryConditions qc, PageInfo pageInfo);
	
	public abstract List<TradeTemplate> getTradeTemplateList(QueryConditions qc, PageInfo pageInfo,String userId);

	/**
	 * 
	 */
	public abstract TradeTemplate getTradeTemplateById(String strId);

	/**
	 * 
	 */
	public abstract int addTradeTemplate(TradeTemplate params);

	/**
	 * 
	 */
	public abstract int updTradeTemplate(TradeTemplate params);

	/**
	 * 
	 */
	public abstract List<TTradeTime> getTTradeTimeList(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 
	 */
	public abstract TTradeTime getTTradeTimeById(String strId);

	/**
	 * 
	 */
	public abstract int addTTradeTime(TTradeTime params);

	/**
	 * 
	 */
	public abstract int updTTradeTime(TTradeTime params);

	/**
	 * 
	 */
	public abstract int delTTradeTime(String sId);

	/**
	 * 
	 */
	public abstract List<TmptSectionRlsp> getTmptSectionRlspList(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 
	 */
	public abstract int addTmptSectionRlsp(TmptSectionRlsp params);

	/**
	 * 
	 */
	public abstract int updTmptSectionRlsp(TmptSectionRlsp params);

	/**
	 * 
	 */
	public abstract int delTmptSectionRlsp(String tId, String sId);

	/**
	 * 
	 */
	public abstract List<FirmSpecialFee> getFirmSpecialFeeList(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 
	 */
	public abstract FirmSpecialFee getFirmSpecialFeeById(String strId, String kbn);

	/**
	 * 
	 */
	public abstract String addFirmSpecialFee(FirmSpecialFee params);

	/**
	 * 
	 */
	public abstract int updFirmSpecialFee(FirmSpecialFee params, String kbn);

	/**
	 * 
	 */
	public abstract int delFirmSpecialFee(int[] firmSpecialFeeIDs, String kbn);

	/**
	 * 
	 */
	public abstract List<FirmSpecialMargin> getFirmSpecialMarginList(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 
	 */
	public abstract FirmSpecialMargin getFirmSpecialMarginById(String strId, String kbn);

	/**
	 * 
	 */
	public abstract String addFirmSpecialMargin(FirmSpecialMargin firmSpecialMargin);

	/**
	 * 
	 */
	public abstract int updFirmSpecialMargin(FirmSpecialMargin params, String kbn);

	/**
	 * 
	 */
	public abstract int delFirmSpecialMargin(int[] firmSpecialMarginIDs, String kbn);

	/**
	 * 
	 */
	public abstract List<FirmSpecialSettleFee> getFirmSpecialSettleFeeList(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 
	 */
	public abstract FirmSpecialSettleFee getFirmSpecialSettleFeeById(String strId, String kbn);

	/**
	 * 
	 */
	public abstract String addFirmSpecialSettleFee(FirmSpecialSettleFee params);

	/**
	 * 
	 */
	public abstract int updFirmSpecialSettleFee(FirmSpecialSettleFee params, String kbn);

	/**
	 * 
	 */
	public abstract int delFirmSpecialSettleFee(int[] firmSpecialSettleFeeIDs, String kbn);

	/**
	 * 
	 */
	public abstract List<FirmSpecialSettleMargin> getFirmSpecialSettleMarginList(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 
	 */
	public abstract FirmSpecialSettleMargin getFirmSpecialSettleMarginById(String strId, String kbn);

	/**
	 * 
	 */
	public abstract String addFirmSpecialSettleMargin(FirmSpecialSettleMargin params);

	/**
	 * 
	 */
	public abstract int updFirmSpecialSettleMargin(FirmSpecialSettleMargin params, String kbn);

	/**
	 * 
	 */
	public abstract int delFirmSpecialSettleMargin(int[] firmSpecialSettleMarginIDs, String kbn);

	/**
	 * 
	 */
	public List<TemplatePrivilege> getTemplatePrivilegeList(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 
	 */
	public TemplatePrivilege getTemplatePrivilegeById(String strId);

	/**
	 * 
	 */
	public abstract int addTemplatePrivilege(TemplatePrivilege params);

	/**
	 * 
	 */
	public abstract int updTemplatePrivilege(TemplatePrivilege params);

	/**
	 * 
	 */
	public abstract int delTemplatePrivilege(String strId);

	/**
	 * 
	 */
	public abstract List<FirmPrivilege> getFirmPrivilegeList(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 
	 */
	public abstract FirmPrivilege getFirmPrivilegeById(String strId);

	/**
	 * 
	 */
	public abstract int addFirmPrivilege(FirmPrivilege params);

	/**
	 * 
	 */
	public abstract int updFirmPrivilege(FirmPrivilege params);

	/**
	 * 
	 */
	public abstract int delFirmPrivilege(String strId);

	/**
	 * 
	 */
	public abstract List<TraderPrivilege> getTraderPrivilegeList(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 
	 */
	public abstract TraderPrivilege getTraderPrivilegeById(String strId);

	/**
	 * 
	 */
	public abstract int addTraderPrivilege(TraderPrivilege params);

	/**
	 * 
	 */
	public abstract int updTraderPrivilege(TraderPrivilege params);

	/**
	 * 
	 */
	public abstract int delTraderPrivilege(String strId);

	/**
	 * 获取非交易日
	 * 
	 * @param id
	 * @return
	 */
	public abstract NotTradeDay getNotTradeDay(Integer id);

	/**
	 * 更新非交易日
	 * 
	 * @param day
	 * @return
	 */
	public abstract int updateNotTradeDay(NotTradeDay dayModel);
	
	/**
	 * 询盘数据查询取得
	 */
	public abstract List<ExportEnquiry> getEnquiryList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 还盘数据查询
	 */
	
	public abstract List<ExportEnquiryCounter> getCounterList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 插入 客服待催备注 
	 */
	public abstract void insertCSRemindRemark(CSRemindRemark remark);
	
	/**
	 * 查询 客服待催列表
	 * @param relationId 关联单号
	 * @param remarkType 0:货款待催（关联单号为交易商编号) 1:尾调待催（关联单号为成交单号）
	 */
	public abstract List<CSRemindRemark> selectCSRemindRemarkList(String relationId,int remarkType);
	
	/**
	 * 判断传入日期是否为交易日，如果没传 视为当前日期
	 * @param date
	 * @return 0：交易日 1：非交易日 -1：判断失败
	 */
	public int isTradeDate(Date date);
	
	/**
	 * 统计开始日 到 结束日 交易日天数
	 * @param startDate 开始日(包含)
	 * @param endDate 结束日(不包含)
	 * @return
	 */
	public int countTradeDate(Date startDate,Date endDate);

	/**
	 * 询盘详情
	 * @param enquiryID
	 * @return
	 */
	public abstract ExportEnquiry getEnquiryByID(Long enquiryID);
	
	/**
	 * 询盘数据查询取得（线性）
	 */
	public abstract List<EnquiryLiner> getSimpleLinerEnquiryList(QueryConditions qc, PageInfo pageInfo);
}
