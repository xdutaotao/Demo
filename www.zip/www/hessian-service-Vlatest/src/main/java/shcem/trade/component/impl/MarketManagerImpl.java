/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: MarketManagerImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.trade.component.impl;

import java.util.List;
import java.util.Map;

import shcem.base.component.impl.BaseManager;
import shcem.trade.component.IMarketManager;
import shcem.trade.dao.MarketDAO;

/**
 * MarketManagerImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class MarketManagerImpl extends BaseManager implements IMarketManager {

	private MarketDAO dao;
	
	private MarketDAO marketDAO_read;
	
	public void setMarketDAO_read(MarketDAO marketDAO_read) {
		this.marketDAO_read = marketDAO_read;
	}

	public void setMarketDAO(MarketDAO dao) {
		this.dao = dao;
	}

	/**
	 * 取得Markets列表
	 * 
	 * @param paramString
	 *            id
	 * @return Markets列表
	 */
	public List<Map<String, Object>> getMarketById(String marketCode) {
		return this.marketDAO_read.getMarketById(marketCode);
	}

}
