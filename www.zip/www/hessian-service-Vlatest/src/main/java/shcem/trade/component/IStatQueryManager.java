/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IStatQueryManager
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.trade.component;

import shcem.base.component.Manager;
import shcem.trade.dao.StatQueryDAO;
import shcem.trade.dao.model.SystemStatus;

/**
 * StatQueryManager
 * 
 * @author chiyong
 * @version 1.0
 */
public abstract interface IStatQueryManager extends Manager{

	public abstract void setStatQueryDAO(StatQueryDAO paramStatQueryDAO);

	/**
	 * ȡ��SystemStatus
	 * 
	 * @return SystemStatus
	 */
	public abstract SystemStatus getSystemStatusObject();

}
