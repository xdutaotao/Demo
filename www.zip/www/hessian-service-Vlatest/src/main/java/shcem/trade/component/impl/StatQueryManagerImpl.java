/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: StatQueryManagerImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.trade.component.impl;

import shcem.base.component.impl.BaseManager;
import shcem.trade.component.IStatQueryManager;
import shcem.trade.dao.StatQueryDAO;
import shcem.trade.dao.model.SystemStatus;

/**
 * StatQueryManagerImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class StatQueryManagerImpl extends BaseManager implements IStatQueryManager {

	private StatQueryDAO dao;

	public void setStatQueryDAO(StatQueryDAO dao) {
		this.dao = dao;
	}

	/**
	 * 取得SystemStatus
	 * 
	 * @return SystemStatus
	 */
	public SystemStatus getSystemStatusObject() {
		return this.dao.getSystemStatusObject();
	}

}
