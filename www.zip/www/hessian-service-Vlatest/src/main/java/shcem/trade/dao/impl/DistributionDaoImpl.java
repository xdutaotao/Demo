package shcem.trade.dao.impl;

import java.math.BigDecimal;
import java.util.List;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.logistics.dao.model.LogisticsTemplatePrice;
import shcem.trade.dao.IDistributionDao;
import shcem.trade.dao.model.DelDistributionDetail;
import shcem.trade.dao.model.Delivery;
import shcem.trade.dao.model.DeliveryFreightFee;
import shcem.util.Common;
import shcem.util.CommonRowMapper;

public class DistributionDaoImpl extends BaseDAOImpl implements
		IDistributionDao {
	@Override
	public int addDelDistributionDetail(DelDistributionDetail detail) {
		String sql = this.sqlProperty.getProperty("DistributionDao_001");
		Object [] params = {
				detail.getDeliveryID(),//	交收ID								DeliveryID										
				detail.getDISABLED(),//	默认为 0：正常，1：失效								DISABLED										
				detail.getLogisticsLeafID(),//	物流区域LeafID								LogisticsLeafID										
				detail.getLogiisticsName(),//	物流区域名称								LogiisticsName										
				detail.getAddressDetail()!=null?detail.getAddressDetail():"",//	配送地址								AddressDetail										
				detail.getContactTel(),//	联系电话								ContactTel										
				detail.getContactName()==null?"":detail.getContactName(),//	联系人姓名								ContactName										
				detail.getContactMobile(),//	联系手机								ContactMobile										
				detail.getFreightFee(),//	运费								FreightFee										
				detail.getSmallFee(),//	小单费								SmallFee										
				detail.getRemark(),//	备注								Remark										
				detail.getREC_CREATEBY(),//	创建人								REC_CREATEBY										
				detail.getREC_MODIFYBY()//	最后修改人								REC_MODIFYBY										
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public int addDeliveryFreightFee(DeliveryFreightFee detail) {
		String sql = this.sqlProperty.getProperty("DistributionDao_002");
		Object [] params = {
				detail.getDISABLED(),//	默认为 0：正常，1：失效							
				detail.getREC_CREATEBY(),//	创建人
				detail.getREC_CREATEBY(),//	修改人
				detail.getOrderID(),//成交ID															
				detail.getDeliveryID(),//交收ID														
				detail.getBuyShouldPayFreight(),//买家应付运费																
				detail.getBuyPaidFreight(),//买家已付运费													
				detail.getShouldPaySellPenalty(),//	应付卖家运费																	
				detail.getPaidSellFreight()//已付卖家运费																
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public int updateDistribution(DelDistributionDetail delDistributionDetail,
			String userID) {
		this.log.info(this.getClass().getName()+" updateDistribution Start");
		String sql = this.sqlProperty.getProperty("DistributionDao_003");
		Object [] params = {
				delDistributionDetail.getLogisticsLeafID(),//物流区域LeafID
				delDistributionDetail.getLogiisticsName(),//区域三级名称（华北|浙江|杭州）
				delDistributionDetail.getAddressDetail(),//配送地址
				delDistributionDetail.getContactTel(),//联系电话
				delDistributionDetail.getContactName()==null?"":delDistributionDetail.getContactName(),//联系人姓名
				delDistributionDetail.getContactMobile(),//手机
				delDistributionDetail.getFreightFee(),//运费
				delDistributionDetail.getLogisticsRemark(),//备注
				userID,//修改人
				delDistributionDetail.getDeliveryID()//交收ID
		};
		int retrunCode;
		try {
			retrunCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" updateDistribution 失败："+e.getMessage());
			e.printStackTrace();
			retrunCode =-1;
		}
		this.log.info(this.getClass().getName()+" updateDistribution End");
		return retrunCode;
	}
	
	
	@Override
	public int updateDeliveryFreightFee(DeliveryFreightFee deliveryFreightFee,
			String userID) {
		this.log.info(this.getClass().getName()+" updateDeliveryFreightFee Start");
		String sql = this.sqlProperty.getProperty("DistributionDao_004");
		Object [] params = {
				deliveryFreightFee.getBuyShouldPayFreight(),//买家应付运费
				userID,
				deliveryFreightFee.getDeliveryID()
		};
		int retrunCode;
		try {
			retrunCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" updateDeliveryFreightFee 失败："+e.getMessage());
			e.printStackTrace();
			retrunCode =-1;
		}
		this.log.info(this.getClass().getName()+" updateDeliveryFreightFee End");
		return retrunCode;
	}
	
	
	@Override
	public Delivery getHisDelivery(String historyDeliveryID) {
		this.log.info(this.getClass().getName()+" getHisDelivery Start");
		String sql = this.sqlProperty.getProperty("DistributionDao_005");
		Object [] params = {
				historyDeliveryID
		};
		Delivery delivery = (Delivery) this.queryForObject(sql, params, new CommonRowMapper(new Delivery()));
		this.log.info(this.getClass().getName()+" getHisDelivery End");
		return delivery;
	}
	@Override
	public int updateDeliveryQuantity(String historyDeliveryID,
			Integer deliveryQuantity) {
		this.log.info(this.getClass().getName()+" updateDeliveryQuantity");
		String sql = "update T_Delivery set DeliveryQuantity=DeliveryQuantity-"+deliveryQuantity+" where DeliveryID='"+historyDeliveryID+"'";
		Object [] params = {};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.info(this.getClass().getName()+" updateDeliveryQuantity 失败："+e.getMessage());
			returnCode = -1;
		}
		return returnCode;
	}
	@Override
	public List<LogisticsTemplatePrice> getLogisticsPrice(int categoryLeafID,
			int brandID, int sourcePlaceID, int logisticsLeafID) {
		String sql = "SELECT * from T_LogisticsTemplatePrice WHERE TemplateID in (SELECT TemplateID from T_LogisticsTemplateCategory WHERE"
				+ " CategoryLeafID ="+categoryLeafID+" and  BrandID="+brandID+" and SourcePlaceID="+sourcePlaceID+") and EndAreaID = "+logisticsLeafID;
		Object [] params = {};
		List<LogisticsTemplatePrice> price = this.queryBySQL(sql, params, null, new CommonRowMapper(new LogisticsTemplatePrice()));
		return price;
	}
	
	@Override
	public int updateUpdateLogisticalDetStatus(int deliveryStatus,
			String deliveryID, String userID, int updateLogisticalDetStatus) {
		this.log.debug(this.getClass().getName()+"updateUpdateLogisticalDetStatus Start");
		String sql = "update T_Delivery set UpdateLogisticalDetStatus="+updateLogisticalDetStatus+", DeliveryStatus ="+deliveryStatus+",REC_MODIFYBY='"+userID+"',REC_MODIFYTIME=GETDATE() where deliveryID='"+deliveryID+"'";
		Object [] param ={};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql,param);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" updateUpdateLogisticalDetStatus 失败");
			e.printStackTrace();
			returnCode = -1;
		}
		this.log.info(this.getClass().getName()+" updateUpdateLogisticalDetStatus End");
		return returnCode;
	}
	
	@Override
	public int updateDeliveryFreightFeeBuyPaidFreight(String deliveryID,String userID,BigDecimal luggage) {
		this.log.info(this.getClass().getName()+" updateDeliveryFreightFeeBuyPaidFreight Dao Start");
		String sql = "update T_DeliveryFreightFee set REC_MODIFYBY='"+userID+"',REC_MODIFYTIME=GETDATE(),BuyPaidFreight = BuyShouldPayFreight "
				+ ",ShouldPaySellPenalty=BuyShouldPayFreight,BuyPaidTime=GETDATE(),BuyPaidBY ='"+userID+"' where DeliveryID = '"+deliveryID+"'";
		Object [] params = {};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" updateDeliveryFreightFeeBuyPaidFreight 失败："+e.getMessage());;
			returnCode = -1;
		}
		this.log.info(this.getClass().getName()+" updateDeliveryFreightFeeBuyPaidFreight Dao End");
		return returnCode;
	}
	
	@Override
	public int updateBuyPaidFreight(String deliveryID, String userID,
			BigDecimal buyPaidFreight) {
		this.log.info(this.getClass().getName()+" updateBuyPaidFreight Start");
		int returnCode;
		String sql = "update T_DeliveryFreightFee set REC_MODIFYBY='"+userID+"',REC_MODIFYTIME=GETDATE(),BuyPaidFreight ="+buyPaidFreight
				+ " where DeliveryID = '"+deliveryID+"'";
		Object [] params = {};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" updateBuyPaidFreight 失败："+e.getMessage());
			returnCode = -1;
			return returnCode;
		}
		this.log.info(this.getClass().getName()+" updateBuyPaidFreight End");
		return returnCode;
	}
	
	@Override
	public int updateShouldPaySellPenalty(String deliveryID, String userID,
			BigDecimal shouldPaySellPenalty) {
		this.log.info(this.getClass().getName()+" updateShouldPaySellPenalty Start");
		int returnCode;
		String sql = "update T_DeliveryFreightFee set REC_MODIFYBY='"+userID+"',REC_MODIFYTIME=GETDATE(),ShouldPaySellPenalty ="+shouldPaySellPenalty
				+ " where DeliveryID = '"+deliveryID+"'";
		Object [] params = {};
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" updateShouldPaySellPenalty 失败："+e.getMessage());
			returnCode = -1;
			return returnCode;
		}
		this.log.info(this.getClass().getName()+" updateShouldPaySellPenalty End");
		return returnCode;
	}
}
