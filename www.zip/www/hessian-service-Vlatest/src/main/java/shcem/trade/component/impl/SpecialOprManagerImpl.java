package shcem.trade.component.impl;

import java.util.ArrayList;
import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.constant.Constants;
import shcem.finance.component.IVoucherManager;
import shcem.finance.dao.model.VoucherModel;
import shcem.finance.util.FinanceSysData;
import shcem.systemMgr.dao.ISystemMgrDAO;
import shcem.systemMgr.dao.model.MUser;
import shcem.trade.component.ISpecialOprManager;
import shcem.trade.dao.ISpecialOprDAO;
import shcem.trade.dao.model.SpecialOpr;
import shcem.trade.dao.model.SpecialOprDetail;
import shcem.trade.service.model.SpecialOprDto;

public class SpecialOprManagerImpl extends BaseManager  implements ISpecialOprManager {
	private ISpecialOprDAO specialOprDAO;
	
	private ISpecialOprDAO specialOprDAO_read;
	
	public void setSpecialOprDAO_read(ISpecialOprDAO specialOprDAO_read) {
		this.specialOprDAO_read = specialOprDAO_read;
	}

	private ISystemMgrDAO systemMgrDAO; 
	
	public void setSpecialOprDAO(ISpecialOprDAO specialOprDAO) {
		this.specialOprDAO = specialOprDAO;
	}

	public void setSystemMgrDAO(ISystemMgrDAO systemMgrDAO){
		this.systemMgrDAO = systemMgrDAO;
	};

	@Override
	public void addSpecialOpr(SpecialOpr specialOpr,String userID) {
		MUser user = this.systemMgrDAO.getUserByLoginName(userID);
		specialOpr.setApplicantName(user.getName());
		this.specialOprDAO.addSpecialOpr(specialOpr);
	}
	@Override
	public List<SpecialOpr> getSpecialOprList(QueryConditions qc,
			PageInfo pageInfo, boolean replace) {
		this.log.info(this.getClass().getName()+" getSpecialOprList");
		return this.specialOprDAO_read.getSpecialOprList(qc,pageInfo,replace);
	}
	@Override
	public SpecialOpr getSpecialOprDetail(int specialOprID) {
		return this.specialOprDAO_read.getSpecialOprDetail(specialOprID);
	}
	@Override
	public void updateSpecialOpr(int[] specialOprIDs, String userID) {
		MUser user = this.systemMgrDAO.getUserByLoginName(userID);
		if (specialOprIDs != null) {
			String specialOprIDString = "";
			for (int i = 0; i < specialOprIDs.length; i++) {
				if(i>0)specialOprIDString+=",";
				specialOprIDString += specialOprIDs[i];
			}
			this.specialOprDAO.updateSpecialOpr(specialOprIDString,user);
		}
	}
	
	/**
	 * 插入特殊流程记录
	 * @param specialOpr
	 * @param userID
	 * @return 主键
	 */
	@Override
	public int insertSpecialOpr(SpecialOpr specialOpr) {
		return this.specialOprDAO.insertSpecialOpr(specialOpr);
	}
	
	@Override
	public List<SpecialOprDto> selectSpecialOprList(QueryConditions qc,
			PageInfo pageInfo) {
		return this.specialOprDAO_read.selectSpecialOprList(qc, pageInfo);
	}

	@Override
	public void insertSpecialOprDetail(List<SpecialOprDetail> detailList,String specialOprID) {
		//IVoucherOraManager mgrOra = (IVoucherOraManager) FinanceOraSysData.getBean(Constants.BEAN_VOUCHERORA_MGR);
		IVoucherManager mgr = (IVoucherManager) FinanceSysData.getBean(Constants.BEAN_VOUCHER_MGR);
		List<SpecialOprDetail> list = new ArrayList<SpecialOprDetail>();
		for (SpecialOprDetail detail : detailList){
			VoucherModel model = mgr.getVoucherModelByCode(String.valueOf(detail.getVoucherModelID()));
			if ("20100-".equals(model.getDEBITCODE())){
				detail.setPayType(1); // 收取
			}else{
				detail.setPayType(2);// 支付
			}
			list.add(detail);
		}
		this.specialOprDAO.insertSpecialOprDetail(list,specialOprID);
		
	}

	@Override
	public List<SpecialOprDetail> selectSpecialOprDetailListBySpecialOprID(
			String specialOprID) {
		return this.specialOprDAO_read.selectSpecialOprDetailListBySpecialOprID(specialOprID);
	}

	@Override
	public int updateSpecialOprDetailOfStatusByID(String id, String username,
			Integer Status) {
		return this.specialOprDAO.updateSpecialOprDetailOfStatusByID(id, username, Status);
		
	}

	@Override
	public void updateSpecialOprDetailOfDisabledByID(String id,
			String username, Integer disbaled) {
		this.specialOprDAO.updateSpecialOprDetailOfDisabledByID(id, username, disbaled);
	}

	@Override
	public SpecialOprDetail selectSpecialOprDetailByID(Integer id) {
		return this.specialOprDAO.selectSpecialOprDetailByID(id);
	}

	@Override
	public Integer countSpecialOprDetail(String specialOprID, Integer disbaled,
			Integer status) {
		return this.specialOprDAO.countSpecialOprDetail(specialOprID, disbaled, status);
	}

	@Override
	public int refuseSpecialOprOfStatusByID(Integer id,String userName) {
		this.log.info(this.getClass().getName() +"component refuseSpecialOprOfStatusByID Start");
		int count = this.specialOprDAO.updateSpecialOprOfStatusByID(id,3,userName);// 状态:3 已拒绝
		this.log.info(this.getClass().getName() +"component refuseSpecialOprOfStatusByID End");
		return count;
	}
	
	@Override
	public int getSpecialOprCount(QueryConditions qc) {
		this.log.info(this.getClass().getName() +"component getSpecialOprCount Start");
		int totalCount = this.specialOprDAO_read.getSpecialOprCount(qc);
		this.log.info(this.getClass().getName() +"component getSpecialOprCount End");
		return totalCount;
	}
}
