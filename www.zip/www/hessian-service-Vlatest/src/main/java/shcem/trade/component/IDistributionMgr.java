package shcem.trade.component;

import java.util.List;

import shcem.logistics.dao.model.LogisticsTemplatePrice;
import shcem.trade.dao.model.DelDistributionDetail;
import shcem.trade.dao.model.Delivery;

public interface IDistributionMgr {

	int addDistribution(Delivery delivery,
			String userID, String mode);

	int updateDistribution(DelDistributionDetail delDistributionDetail,
			String userID);

	List<LogisticsTemplatePrice> getLogisticsPrice(int categoryLeafID, int brandID,
			int sourcePlaceID, int logisticsLeafID);

	/**
	 * 取消中石化交收配送
	 * @param deliveryID
	 * @param userID 
	 * @return
	 */
	int cancelDistribution(String deliveryID, String userID);

	/**
	 * 在取消交收单子的基础上发起交收申请(中石化)
	 * @param delivery
	 * @param userID
	 * @param mode 
	 * @return
	 */
	int applyDistributionByDelivery(Delivery delivery, String userID, String mode);

	/**
	 * 取消中石化交收配送，重新发起交收申请，风控审核通过
	 * @param deliveryID
	 * @param userID
	 * @param mode
	 * @param taskID 
	 * @return
	 */
	int reviewedDistributionApply(String deliveryID, String userID, String mode, String taskID);

	/**
	 * 取消中石化交收配送，重新发起交收申请，风控审核拒绝
	 * @param deliveryID
	 * @param userID
	 * @param mode
	 * @param taskID
	 * @return
	 */
	int reviewedNotDistributionApply(String deliveryID, String userID,
			String mode, String taskID);

	/**
	 *  取消中石化交收拆单，风控审核拒绝，物流修改拆单信息
	 * @param delivery
	 * @param userID
	 * @param mode
	 * @param taskID
	 * @return
	 */
	int updateDistributionApply(Delivery delivery, String userID, String mode,
			String taskID);

	/**
	 * 原交收单信息
	 * @param historyDeliveryID
	 * @return
	 */
	Delivery getHisDelivery(String historyDeliveryID);
	
}
