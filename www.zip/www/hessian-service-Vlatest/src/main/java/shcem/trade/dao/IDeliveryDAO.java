package shcem.trade.dao;

import java.math.BigDecimal;
import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.service.model.UpAndDownRecord;
import shcem.systemMgr.dao.model.MUser;
import shcem.trade.ExportModel.Delivery4Export;
import shcem.trade.ExportModel.DeliveryInvoice4Export;
import shcem.trade.dao.model.BreachContractApply;
import shcem.trade.dao.model.DelDistributionDetail;
import shcem.trade.dao.model.Delivery;
import shcem.trade.dao.model.DeliveryDetail;
import shcem.trade.dao.model.DeliveryFreightFee;
import shcem.trade.dao.model.DeliveryInvoice;
import shcem.trade.dao.model.DeliveryOpeLog;
import shcem.trade.dao.model.ExportDelivery;
import shcem.trade.dao.model.ExportFirmfunds;
import shcem.trade.dao.model.Firmfunds;
import shcem.trade.dao.model.Order;
import shcem.trade.dao.model.OrderSinopec;
import shcem.trade.dao.model.TradeTemplate;
import shcem.trade.dao.model.TrasferGoodsDetail;
import shcem.trade.service.model.DeliveryDto;

public interface IDeliveryDAO extends DAO {

	List<Delivery> getDeliveryList(QueryConditions qc, PageInfo pageInfo);

	Delivery getDeliveryDetail(String deliveryID);

	void addDeliveryOpeLog(DeliveryOpeLog deliveryOpeLog);

	List<DeliveryOpeLog> getDeliveryOpeLogList(String deliveryID);

	void handleDelivery(String deliveryID);

	void paySellerMoney(String deliveryID, BigDecimal payedMoney, MUser user);
	/**
	 * 买家账户
	 * @param deliveryID
	 * @return
	 */
	Firmfunds getFirmfundsByDeliveryID(String deliveryID);

	/**更新交易商资金账户
	 * @param firmfunds
	 */
	void updateFirmfunds(Firmfunds firmfunds);

	void takeBuyerMoney(String deliveryID, BigDecimal takenMoney, MUser user);

	Order getOrderByDeliveryID(String deliveryID);

	/**
	 * 释放卖方授信金额
	 * @param delivery
	 */
	void releaseCreditMoneyForSeller(Delivery delivery);

	void updateTakenBSDeposit(Delivery delivery);

	void updateSellPenalty(Delivery delivery);

	void rollBack();

	int adJustTakenQuantity(String deliveryComment, BigDecimal takenQuantity,
			String deliveryID, String userName, BigDecimal overloadFee);

	int adJustOverLoadMoney(Delivery delivery);

	/**
	 * 卖家账户
	 * @param deliveryID
	 * @return
	 */
	Firmfunds getSellFirmfundsByDeliveryID(String deliveryID);

//	/**收卖方违约金 ，需要更新交收信息
//	 * @param delivery
//	 */
//	void updatePenaltyMoneyForSeller(Delivery delivery);

	/**收买方违约金 ，需要更新交收信息
	 * @param delivery
	 */
	void updatePenaltyMoneyForBuyer(Delivery delivery);
	/**
	 * @param replace 
	 * 
	 */
	public abstract List<Delivery4Export> getExportDeliveryList(QueryConditions qc,PageInfo pageInfo, boolean replace);
	
	/**
	 * 
	 */
	public abstract List<DeliveryDetail> getDeliveryDetailList(QueryConditions qc,PageInfo pageInfo);
	
	/**
	 * 
	 */
	public abstract List<DelDistributionDetail> getDelDistributionDetailList(QueryConditions qc,PageInfo pageInfo);

	/**更新已收付款
	 * @param delivery
	 */
	void updateDeliveryTakenMoney(BigDecimal allmoney, String name,String deliveryID);
	/**
	 * 更新已付货款
	 * @param delivery
	 */
	void updatePayedMoney(BigDecimal allmoney, String name,String deliveryID);
	/**
	 * 更新 卖方交收已收保证金  卖方交收已扣违约金
	 * @param delivery
	 */
	void updateSellTakenSSDepositAndTakenSellPenalty(Delivery delivery);
	/**
	 * 更新 买方交收已扣保证金  买方交收已扣违约金
	 * @param delivery
	 */
	void updateTakenBSDepositAndTakenBuyPenalty(Delivery delivery);

	/**更新买方应收违约金
	 * @param delivery
	 */
	void updateBuyPenalty(Delivery delivery);
	
	/**
	 * 
	 */
	public abstract List<ExportFirmfunds> getExportFirmFundsList(QueryConditions qc,PageInfo pageInfo);

	Order getOrderByID(String orderID);

	void updateSellCreditFeeAndSellTakenTradeFee(Order order);
	/**
	 * 更新交收单:
	 *  1)重新设置卖方交收已收保证金（SellTakenSSDeposit）
	 *  2)设置卖方交收保证金授信金额为（SellCreditDeposit）0 
	 */
	void updateSellTakenSSDepositAndSellCreditDeposit(Delivery delivery);

	List<Order> getOrderFile(String orderID);
	
	/**
	 *
	 */
	public abstract int updDeliveryDetail(Delivery delivery,String userName);
	public abstract int  updTrasferGoodsDetail(Delivery delivery,String userName);

	/**
	 * 履约处理完成 ，更新订单“已签收数量（批）SignQuantity”
	 * params:
	 * takenQuantity:交收实发数量
	 */
	void updateOrderSignQuantity(BigDecimal takenQuantity, String orderID, MUser user);

	/**
	 * 
	 * @param status  状态：1已申请，2：已处理, 3:违约
	 * @param violationStatus 0:违约处理中；1:违约处理完成
	 * @param deliveryID 
	 */
	void finishDelivery(int staTradeStatustus, int violationStatus, String deliveryID);
	/**
	 * 履约处理完成
	 * @param i
	 * @param deliveryID
	 */
	void finishProcessStatus(int status, String deliveryID);

	List<Delivery> getDeliveryListByOrderID(String orderId);
	
	List<Delivery> getPassedDeliveryList(String orderId,String statusConditions);

	int finishedOrder(Integer tradeStatus,String orderId);

	int updateDeliveryDetailStatus(String deliveryID, String rEC_MODIFYBY);

	int updateDeliveryLogisticsStatus(Integer logisticsStatus,String deliveryID, String rEC_MODIFYBY);
	
	/**
	 * 
	 */
	public abstract List<DeliveryInvoice> getDeliveryInvoiceList(QueryConditions qc,PageInfo pageInfo);

	List<UpAndDownRecord> getRecordList(QueryConditions qc, PageInfo pageInfo);

	List<Delivery> getLogisticalDeliveryList(QueryConditions qc,
			PageInfo pageInfo);

	List<UpAndDownRecord> getLogisticalRecordArray(QueryConditions qc,
			PageInfo pageInfo);

	int updateDeliveryStatus(int deliveryStatus, String deliveryID, String userName);
	int updateDeliveryOrderFileID(int deliveryOrderFileID,int deliveryStatus, String deliveryID, String userName);

	int updateNotPassedDeliveryStatus(int i, String deliveryID,String userName);

	List<Delivery> getReviewPassedDeliverySignedQuantity(String orderID);

	/**
	 * 所有交收（履约+违约）数量
	 * @param orderID
	 * @return
	 */
	int getDeliveryQuantity(String orderID);

	int updateNotPassedDeliverySignedQuantityStatus(int deliveryStatus, String deliveryID);

	Long getTakenMoneyByOrderID(String orderId);
	/**
	 * 获取某一个交收单/订单 资金流水
	 * @param deliveryID
	 * @param vouchermode
	 * @return
	 */
	BigDecimal getFundFlowMoney(String firmID,String deliveryID,String vouchermode);

	int updatePaidSellPenalty(String deliveryID, BigDecimal paidSellPenalty, String userName);

	int updatePaidBuyPenalty(String deliveryID,BigDecimal paidBuyPenalty,String userName);

	int addNormalDelivery(Delivery delivery, String userName);
	/**
	 * 交收自提信息
	 * @param deliveryDetail
	 * @return
	 */
	int addDeliveryDetail(DeliveryDetail deliveryDetail);

	int addTrasferGoodsDetail(TrasferGoodsDetail trasferGoodsDetail);

	int disabledDelivery(String deliveryID, String userName);

	int disabledUnNormalDelivery(String unNormalApplyID);

	BreachContractApply getBreachContractApply(Integer keyID);

	int getCanViolationQuantity(String orderID);

	/**
	 * 交收 尾调状态
	 * @param tailAdjustStatus
	 * @param deliveryID
	 * @return
	 */
	int updateDeliveryTailAdjustStatus(int tailAdjustStatus, String deliveryID);
	/**
	 * 卖家应扣违约金
	 * @param buyPenalty
	 * @param userName
	 * @param deliveryID
	 * @return
	 */
	int updateSellPenalty(BigDecimal sellPenalty, String userName, String deliveryID);
	/**
	 * 买家应扣违约金
	 * @param buyPenalty
	 * @param userName
	 */
	int updateBuyPenalty(BigDecimal buyPenalty, String userName,String deliveryID);

	/**
	 * 应付卖方违约金
	 * @param payMoney
	 * @param userName
	 * @param deliveryID
	 */
	int updateShouldPaySellPenalty(BigDecimal payMoney, String userName,
			String deliveryID);
	/**
	 * 应付买方违约金
	 * @param payMoney
	 * @param userName
	 * @param deliveryID
	 */
	int updateShouldPayBuyPenalty(BigDecimal payMoney, String userName,
			String deliveryID);

	/**
	 * 交收 赋值 交收流程ID
	 * @param processInstanceID 交收流程ID
	 * @param deliveryID
	 * @param userName 
	 */
	int updateDeliveryProcessInstanceID(String processInstanceID,
			String deliveryID, String userName);

	DeliveryDetail getTDeliveryDetail(String deliveryID);

	TrasferGoodsDetail getTrasferGoodsDetail(String deliveryID);

	int updateDeliveryAttID(Integer deliveryAttID, String deliveryID, String userName, int deliveryStatus);
	
	/**
	 * 查询 客户违约申请 列表(分页)
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	List<BreachContractApply> queryBreachContractApplyList(QueryConditions qc, PageInfo pageInfo);

	int updateDeliveryQuantity(int canDeliveryQuantity, String orderID,
			String userName);

	int updateDeliveryQuantity(String orderId, int deliveryQuantity,String userName);

	TradeTemplate getTradeTemplateByID(Integer tradeTmptId);

	int updateTakenBuyPenalty(BigDecimal buyPenalty, String deliveryID,
			String userName);

	int updateTakenSellPenalty(BigDecimal sellPenalty, String deliveryID,
			String userName);

	int updateBreachContractApply(String deliveryID,
			String userName,Integer keyID);

	/**
	 * 根据交收单号获取自提或转让单明细
	 * @param deliveryID
	 * @param deliveryType
	 * @return
	 */
	public DeliveryDto getDeliveryDtoDetail(String deliveryID, int deliveryType);

	/**
	 * 根据交收单号拿到明细
	 * @param deliveryID
	 * @return
	 */
	public Delivery getDeliveryInfo(String deliveryID);

	int upateDeliveryDetailBuyProxyFileID(String deliveryID,
			int buyProxyFileID, String userName);

	int upateTrasferGoodsDetailProxyFile(String deliveryID, int buyProxyFileID,
			int sellProxyFileID, String userName);
	
	/**
	 * 根据OrderID 查询交收单状态列表
	 * @param orderId
	 * @return
	 */
	List<String> findDeliveryStatusByOrderId(String orderId);

	int updateTakenQuantity(String deliveryID, BigDecimal takenQuantity,String userName);
	/**
	 * 
	 * @param orderID
	 * @param receiptFileID 
	 * @param fileID 
	 * @param userName
	 * @return
	 */
	int addReceiptFile(String orderID, int receiptFileID, int fileID,String userName);

	int addReceipt(String orderID, String userName);
	int deleteaddReceipt(String orderID);

	int upateTrasferGoodsDetailProxyFileSell(String deliveryID,
			int sellProxyFileID, String userName);

	int upateTrasferGoodsDetailProxyFileBuy(String deliveryID,
			int buyProxyFileID, String userName);
	/**
	 * 更新记录操作日志
	 * @return
	 */
	int updateOperNotes(String notes,String userId, String deliveryID);
	
	/**
	 * 查询记录操作日志
	 * @return
	 */
	String findOperNotes(String deliveryID);

	int getMinQuantity(String orderId);

	/**
	 * 待卖家确认交收单
	 * @return
	 */
	List<Delivery> getToBeIdentifiedListBySeller();

	int updateDeliveryDocMarker(String deliveryID, String userName);

	Firmfunds getBuyFirmfundsByDeliveryID(String buyFirmId);

	/**
	 * 客户违约申请添加备注
	 * @param
	 * @return
	 */
	 int addReamrkBreach(String remrk,String userId, String deliveryID);

	/**
	 *客户违约申请获取备注
	 */
	 String readRemarkBreach(String deliveryID);

	int updateOrderBuyTakenTradeDeposit(String orderId,
			BigDecimal takenBSDeposit);

	int updateOrderSellTakenTradeDeposit(String orderId,
			BigDecimal sellTakenSSDeposit);

	int updateOrderSellCreditDeposit(String orderId,
			BigDecimal sellCreditDeposit);
	
	/**
	 * 根据DeliveryID 更新 交收表的【已付货款(PayedMoney)】
	 */
	int updateDeliveryOfPayedMoneyByDeliveryID(String deliveryID,String userID,BigDecimal payedMoney);

	int updateBuyTakenTradeDeposit(String orderId, BigDecimal takenBSDeposit,String userID);

	int updatePaidAmount(String orderId, BigDecimal takenMoney, String userName);

	int updateBuyTakenTradeFee(String orderId, BigDecimal takenBSFee,
			String userName);

	int updateSellTakenTradeFee(String orderId, BigDecimal violationPenalty,
			String userName);

	int updatePaidSellAmount(String orderId, BigDecimal payedMoney,
			String userName);

	int updateSellTakenTradeDeposit(String orderId,
			BigDecimal sellTakenSSDeposit, String userName);

	int updateBuyCreditDeposit(String orderId, BigDecimal buyCreditDeposit,
			String userName);

	Delivery getDeliveryByID(String deliveryID);

	int addDelDistributionDetail(DelDistributionDetail delDistributionDetail, String userName);
	
	/**
	 * 根据 成交单ID 批量更新  配送运费资金表 【T_DeliveryFrightFee】的 已付卖家运费 =应付卖家运费
	 * @param orderId 成交单ID
	 * @param userId
	 * @return
	 */
	public abstract int updateDeliveryFrightFeeOfPaidSellFreightByOrderID(String orderId,String userId);
	
	/**
	 * 查询 配送运费资金表列表(收买家运费时用，排除 delivery.DeliveryStatus not in(70,75))
	 * @param orderId 订单ID
	 * @return
	 */
	public abstract List<DeliveryFreightFee> selectDeliveryFrightFee(String orderId);
	
	/**
	 * 查询 配送运费资金表列表(付货款 审核通过时用，不排除 (70,75))
	 * @param orderId 订单ID
	 * @return
	 */
	public abstract List<DeliveryFreightFee> selectDeliveryFrightFeeOrderId(String orderId);
	
	/**
	 * 根据 交收单ID查询 配送运费资金表列表
	 * @param DeliveryID  交收单ID
	 * @return
	 */
	public abstract DeliveryFreightFee selectDeliveryFrightFeeByDeliveryID(String deliveryID);

	DelDistributionDetail getDelDistributionDetail(String deliveryID);

	DeliveryFreightFee getDeliveryFreightFee(String deliveryID);
	
	/**
	 * 更新 【买家应付运费】和 买家已付运费
	 * @param deliveryID
	 * @param buyShouldPayFreight 买家应付运费
	 * @param buyPaidFreight  买家已付运费
	 * @param userId
	 * @return
	 */
	public abstract int updateDeliveryFrightFeeByDeliveryID(String deliveryID,BigDecimal buyShouldPayFreight,BigDecimal buyPaidFreight,String userId);
	
	/**
	 * 无效掉 配送运费资金数据(用在交收单的撤销动作)
	 * @param userId
	 * @param deliveryID
	 * @return
	 */
	int disabledDeliveryFreightFeeByDeliveryID(String userId,String deliveryID);
	
	/**
	 * 根据deliveryID更新【运费调整额】
	 * @param overloadFreight
	 * @param userId
	 * @param deliveryID
	 * @return
	 */
	int updateDeliveryFreightFeeOfOverloadFreightByDeliveryID(BigDecimal overloadFreight,String userId,String deliveryID);
	
	
	/**
	 * 根据申请ID获取申请列表
	 * @param ID 申请ID
	 * @return
	 */
	List<BreachContractApply> getBreachContractApplyListByID(String ID);
	
	BreachContractApply getBreachContractApplyByDeliveryID(String deliveryID);

	List<OrderSinopec> getDeliverySinopecFile(String deliveryID);
	
	/**
	 * 更新 交收表 是否取得中石化订单号
	 * @param deliveryID
	 * @param isGetSinopecNumber
	 * @param userName
	 * @return
	 */
	int updateDeliveryOfIsGetSinopecNumber(String deliveryID,Integer isGetSinopecNumber,String userName);
	
	/**
	 * 查询  交收配送明细表的列表
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	List<Delivery> getDeliveryOfDelDistributionDetailList(QueryConditions qc, PageInfo pageInfo);

	/**
	 * 中石化取消的交收量
	 * @return
	 */
	int getDeliverySinopecQuantity(String orderID);

	/**
	 * 已经交收的数量(不包括撤销的交收单)
	 * @param orderId
	 * @return
	 */
	int getTotalDeliveryQuantity(String orderId);

	/**
	 * 同一订单 交收相关费用总额 (已收/已付)										
	 * @param orderId
	 * @param deliveryExpenseName 
	 * @return
	 */
	BigDecimal getTotalDeliveryExpense(String orderId, String deliveryExpenseName);
	/**
	 * 同一订单，买家交收已收手续费之和(买家违约，退买家手续费，不退卖家手续费; 卖家违约，退卖家手续费，不退买家手续费)
	 * @param orderId
	 * @param string
	 * @return
	 */
	BigDecimal getTotalDeliveryTakenBSFeeExpense(String orderId, String deliveryExpenseName);

	/**
	 * 同一订单 交收相关费用总额 (应收)		
	 * @param orderId
	 * @param string
	 * @return
	 */
	BigDecimal getShouldTotalDeliveryExpense(String orderId, String deliveryExpenseName);

	/**
	 * 更新中石化交收状态：已取消,并且相关交收费用全部置为0 
	 * @param deliveryStatus
	 * @param deliveryID
	 * @param userID
	 * @return
	 */
	int updateDeliveryStatus4Distribution(int deliveryStatus, String deliveryID,
			String userID);

	/**
	 * 所有交收单
	 * @param orderId
	 * @return
	 */
	List<Delivery> getAllDeliveryListByOrderID(String orderId);
	
	/**
	 * 所有交收单
	 * @param replace 
	 * @param orderId
	 * @return
	 */
	List<Delivery4Export> exportNewDeliveryList(QueryConditions qc, PageInfo pageInfo, boolean replace);

	/**
	 * 运费调整额   
	 * @param deliveryID
	 * @return
	 */
	BigDecimal getSensedFreightFee(String deliveryID);

	List<DeliveryInvoice4Export> getDeliveryInvoice4ExportList(
			QueryConditions qc, PageInfo pageInfo, boolean replace);

	int getExportDeliveryListCount(QueryConditions qc, PageInfo pageInfo);

	int exportNewDeliveryListListCount(QueryConditions qc, PageInfo pageInfo);

	int getDeliveryInvoice4ExportCount(QueryConditions qc, PageInfo pageInfo);

	int updateTakenBSFee(BigDecimal buyTradeFee, String deliveryID,String userName);

	Integer getDeliveryQuantitys(String orderId);
	
	int doReceive(String deliveryID,String userName);
	
	Delivery getDeliveryByDeliveryID(String deliveryID);
}
