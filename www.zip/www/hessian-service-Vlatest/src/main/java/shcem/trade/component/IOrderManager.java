/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IOrderManager.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月12日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.trade.component;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.List;

import org.json.JSONArray;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.member.dao.model.FirmAllData;
import shcem.trade.ExportModel.Order4Export;
import shcem.trade.dao.OrderDAO;
import shcem.trade.dao.model.CancelContract;
import shcem.trade.dao.model.DailyTons;
import shcem.trade.dao.model.Delivery;
import shcem.trade.dao.model.MailConfig;
import shcem.trade.dao.model.Order;
import shcem.trade.dao.model.OrderLiner;
import shcem.trade.dao.model.OrderSumByTradeTemplate;
import shcem.trade.dao.model.ProductOrder;
import shcem.trade.dao.model.UploadFileModel;
import shcem.trade.service.model.OrderDto;

/**
 * @author wlpod
 *
 */
public interface IOrderManager extends Manager {
	public abstract void setOrderDAO(OrderDAO paramOrderDAO);

	/**
	 * 通过OrderId主键查询一条Order记录
	 * 
	 * @param orderID
	 * @return
	 */
	public abstract Order getOrderByID(String orderID);
	
	public abstract int uploadXSSF(String orderId, String XSSFNumber, String userID);
	
	public abstract boolean ifXSSFAdmin(String userId);

	/**
	 * 通过检索条件查询一条或多条Order记录
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<Order> getOrderList(QueryConditions qc, PageInfo pageInfo);
	
	public abstract List<Order> getOrderListByOrderIds(String orderIds);
	
	public abstract List<Order> getUnpayFeeSellerOrderList(QueryConditions qc, PageInfo pageInfo);

	/**更新订单 卖方交易手续费授信（SellCreditFee）    卖方交易已收手续费 SellTakenTradeFee 
	 * @param order
	 */
	public abstract void updateSellCreditFeeAndSellTakenTradeFee(Order order);

	public abstract Order getOrderByOrderID(String orderID);

	public abstract int insertViolationDelivery( String orderID, String userName, int unnormalQuantity, int unnormalFirm,String deliveryComment, String mode) throws RuntimeException, ParseException;
	
	public abstract BigDecimal getDayAmount();
	
	public abstract List<DailyTons> getDailyTons(String startDate, String endDate);
	
	/**
	 * 
	 */
	public abstract List<OrderSumByTradeTemplate> getOrderSumByTradeTmptId(String startDate, String endDate);
	/*
	 * 待支付交易商--订单
	 */
	public abstract List<FirmAllData> getNotPaidOrderList(QueryConditions qc,PageInfo pageInfo);

	/**
	 * 某个交易商的订单
	 * @param firmID
	 * @param endDate 
	 * @param startDate 
	 * @return
	 */
	public abstract List<Order> getOrderListByFirmID(String firmID, String startDate, String endDate);
	
	/**
	 * 查询买家交易员的订单
	 * @param traderId
	 * @return
	 */
	public abstract List<Order> getOrderByBuyTraderId(String traderId);
	
	/**
	 * 交收单列表
	 * @param qc 条件
	 * @param pageInfo 分页对象
	 * @return
	 */
	public abstract List<OrderDto> selectOrderList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 查询付款管理业务的订单列表
	 * @param orderID
	 * @return
	 */
	public abstract List<Order> queryOrderListForPaymentStatus(QueryConditions qc, PageInfo pageInfo,String userID);
	
	/**
	 * 根据OrderID查询付款管理业务的订单
	 * @param orderID
	 * @return
	 */
	public abstract Order findOrderByOrderId(String OrderId);
	
	/**
	 * 根据OrderID更新申请支付状态为5：待审核
	 * @param orderID
	 * @return
	 */
	public abstract int updateApplyOrderForPaymentStatusByOrderId(Order order);
	

	/**
	 * 根据OrderID更新审核通过支付状态为 10：已付款
	 * @return 
	 */
	public abstract int updatePassOrderForPaymentStatusByOrderId(Order order);
	
	/**
	 * 根据OrderID更新审核通过支付状态为 15：拒绝
	 */
	public abstract int updateRefuseOrderForPaymentStatusByOrderId(String orderId,String remarks,String currentUserName);
	String insertViolationDelivery_BreachContractApply(String orderID, String userName, int unnormalQuantity, int unnormalFirm,String deliveryComment, String mode) throws RuntimeException, ParseException;

	public abstract List<Delivery> getDeliveryListByOrderID(String orderID);
	
	/**
	 * 获取滞纳金
	 * @param orderID 成交单ID
	 * @param tradeType 1：买方 2:卖方
	 * @return
	 */
	public abstract Double getOrderForLateFee(String orderID,Integer tradeType);
	
	/**
	 * 更新买方滞纳金
	 * @param orderID
	 * @param userId 
	 * @param receivableBuyLateFee 应收买方滞纳金
	 * @param receivedBuyLateFee 已收买方滞纳金
	 * @return
	 */
	public abstract int updateOrderForBuyLateFee(String orderID,String userId,BigDecimal receivableBuyLateFee,BigDecimal receivedBuyLateFee);
	
	/**
	 * 更新卖方滞纳金
	 * @param orderID
	 * @param userId
	 * @param receivableSellLateFee 应收卖方滞纳金
	 * @param receivedSellLateFee 已收卖方滞纳金
	 * @return
	 */
	public abstract int updateOrderForSellLateFee(String orderID,String userId,BigDecimal receivableSellLateFee,BigDecimal receivedSellLateFee);
	
	/**
	 * 根据OrderID更新成交合同导出状态 0:未导出  1:已导出
	 * @param orderId 成交号
	 * @return 
	 */
	public abstract int updateOrderExportStatus(String orderId);
	
	/**
	 * 获取财务付款报表
	 */
	public abstract List<Order> getOrderPaymentList(QueryConditions qc, PageInfo pageInfo);
	/**
	 * 获取手续费报表（商品维度）
	 */
	public abstract List<ProductOrder> getFeeByProductList(QueryConditions qc,PageInfo pageInfo,String startDate,String endDate);
	
	/**
	 * 获取手续费报表（买方和卖方交易商维度）
	 */
	public abstract List<ProductOrder> getFeeByFirmList(QueryConditions qc,PageInfo pageInfo,String startDate,String endDate);
	
	/**
	 * 获取手续费报表（买方交易商维度）
	 */
	public abstract List<ProductOrder> getFeeBySellFirmList(QueryConditions qc,PageInfo pageInfo,String startDate,String endDate);
	
	/**
	 * 获取手续费报表（卖方交易商维度）
	 */
	public abstract List<ProductOrder> getFeeByBuyFirmList(QueryConditions qc,PageInfo pageInfo,String startDate,String endDate);
	
	/**
	 * 更新 成交单的 【化交是否取得货物控制权】
	 * @param isGoodsController
	 * @param userId
	 * @param orderId
	 * @return
	 */
	public abstract int updateOrderOfIsGoodsControllerByOrderId(Integer isGoodsController, String userId,String orderId);

	/**
	 * 中石化 上传配送信息文件
	 * @param uploadFileModelArrayArray
	 * @param userName
	 * @return
	 */
	public abstract int uploadDistributionFile(
			JSONArray uploadFileModelArrayArray, String userName);

	/**
	 * 获取 中石化配送附件
	 * @param orderId
	 * @param fileType 
	 * @return
	 */
	public abstract List<UploadFileModel> getgetDistributionFile(String orderId, int fileType);

	public abstract int deleteDistributionFile(long[] uploadFileModelIDArray);

	public abstract int addBreachDelivey(JSONArray breachDeliveryArray, String userName, String mode);
	
	
	/**
	 * 更新 前台是否显示成交单
	 * @param isDisplayOrder  0:不显示 1:显示 （默认是显示的，置标后就不显示了）
	 * @param userName
	 * @param orderID
	 * @return
	 */
	int updateOrderOfIsDisplayOrder(Integer isDisplayOrder,String userName,String orderID);
	
	/**
	 * 获取待签收订单列表
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	List<OrderDto> getOrderWaitSignList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 导出订单列表
	 * @param qc
	 * @param pageInfo
	 * @param replace 
	 * @return
	 */
	List<Order4Export> exportOrderList(QueryConditions qc, PageInfo pageInfo, boolean replace);

	public abstract List<CancelContract> getCancelList(QueryConditions qc, PageInfo pageInfo);
	public abstract CancelContract getCancelDetail(String ApplyID);
	
	public abstract int getExportOrderCount(QueryConditions qc,
			PageInfo pageInfo);
	
	/**
	 * 通过检索条件查询一条或多条Order记录(今日成交(全部))
	 * 
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<OrderLiner> getSimpleLinerOrderList(QueryConditions qc, PageInfo pageInfo);

	public abstract int updateIsPaySellerMoneyByOrderId(String userName, String orderId);
	
	public abstract MailConfig getMailConfig(String mailKey);
	
	public abstract int updateIsOutMoneyCus(String orderId, String modifyBy);
	
	public abstract int updateIsOutMoneyRisk(String orderId, String modifyBy);
}
