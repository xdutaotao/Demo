package shcem.trade.component;

import java.util.List;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.trade.dao.model.WHAddrTemplateRlsp;
import shcem.trade.dao.model.WareHouse;
import shcem.trade.dao.model.WareHouseAddress;
import shcem.trade.dao.model.WareHouseGroup;

public interface IWHAddrTemplateRlspManager extends Manager {

	/**
	 * 新增 仓库地址交易场
	 * @param wHAddrTemplateRlsp
	 * @return
	 */
	public int addWHAddrTemplateRlsp(WHAddrTemplateRlsp wHAddrTemplateRlsp);
	
	/**
	 * 更新 仓库地址交易场
	 * @param wHAddrTemplateRlsp
	 * @return
	 */
	public int updateWHAddrTemplateRlspById(WHAddrTemplateRlsp wHAddrTemplateRlsp);
	
	/**
	 * 查询 仓库地址交易场列表
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public List<WHAddrTemplateRlsp> selectWHAddrTemplateRlspList(QueryConditions qc,PageInfo pageInfo);
	
	/**
	 * 根据ID查询 仓库地址交易场信息
	 * @param id
	 * @return
	 */
	public WHAddrTemplateRlsp selectWHAddrTemplateRlspById(Integer id);
	
	/**
	 * 查询仓库地址表列表
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public List<WareHouseAddress> selectWareHouseAddressList(QueryConditions qc,PageInfo pageInfo);
	
	/**
	 * 查询仓库地址表列表
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public List<WareHouse> selectWareHouseList(QueryConditions qc,PageInfo pageInfo);
	
	/**
	 * 删除 仓库地址交易场关系表
	 * @param idList
	 * @return
	 */
	public int deleteWHAddrTemplateRlspById(int[] idArr,String userName);
	
	/**
	 * 查询仓库组列表
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public List<WareHouseGroup> getWareHouseGroupList(QueryConditions qc,PageInfo pageInfo);
	
}
