/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IMarketManager
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.trade.component;

import java.util.List;
import java.util.Map;

import shcem.base.component.Manager;
import shcem.trade.dao.MarketDAO;

/**
 * MarketManager
 * 
 * @author chiyong
 * @version 1.0
 */
public abstract interface IMarketManager extends Manager{

	public abstract void setMarketDAO(MarketDAO paramMarketDAO);

	/**
	 * ȡ��Markets�б�
	 * 
	 * @param paramString
	 *            id
	 * @return Markets�б�
	 */
	public abstract List<Map<String, Object>> getMarketById(String paramString);

}
