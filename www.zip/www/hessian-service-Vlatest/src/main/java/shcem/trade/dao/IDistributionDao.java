package shcem.trade.dao;

import java.math.BigDecimal;
import java.util.List;

import shcem.logistics.dao.model.LogisticsTemplatePrice;
import shcem.trade.dao.model.DelDistributionDetail;
import shcem.trade.dao.model.Delivery;
import shcem.trade.dao.model.DeliveryFreightFee;

public interface IDistributionDao {

	int addDelDistributionDetail(DelDistributionDetail detail);

	int addDeliveryFreightFee(DeliveryFreightFee deliveryFreightFee);

	int updateDistribution(DelDistributionDetail delDistributionDetail,
			String userID);

	List<LogisticsTemplatePrice> getLogisticsPrice(int categoryLeafID, int brandID,
			int sourcePlaceID, int logisticsLeafID);

	int updateDeliveryFreightFeeBuyPaidFreight(String deliveryID, String userID,BigDecimal luggage);

	int updateDeliveryFreightFee(DeliveryFreightFee deliveryFreightFee,
			String userID);

	Delivery getHisDelivery(String historyDeliveryID);

	/**
	 * 更新交收量
	 * @param string
	 * @param deliveryQuantity
	 * @return
	 */
	int updateDeliveryQuantity(String historyDeliveryID, Integer deliveryQuantity);

	int updateUpdateLogisticalDetStatus(int deliveryStatus, String deliveryID,
			String userID, int updateLogisticalDetStatus);

	public abstract int updateBuyPaidFreight(String deliveryID, String userID,
			BigDecimal buyPaidFreight);

	int updateShouldPaySellPenalty(String deliveryID, String userID,
			BigDecimal shouldPaySellPenalty);
}
