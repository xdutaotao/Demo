/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: LeadsManagerImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月12日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.trade.component.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.trade.component.ILeadsManager;
import shcem.trade.dao.LeadsDAO;
import shcem.trade.dao.OrderDAO;
import shcem.trade.dao.model.Leads;
import shcem.trade.dao.model.LeadsLiner;
import shcem.trade.dao.model.LeadsTemplatePrice;
import shcem.trade.service.model.LeadsForIMServiceModel;
import shcem.trade.dao.model.LockLead;
import shcem.trade.dao.model.Order;
import shcem.trade.service.model.LeadsListLinerQueryModel;

/**
 * @author wlpod
 *
 */
public class LeadsManagerImpl extends BaseManager implements ILeadsManager {

	private LeadsDAO dao;
	
	private LeadsDAO leadsDAO_read;
	
	private OrderDAO orderDAO_read;
	
	public void setOrderDAO_read(OrderDAO orderDAO_read) {
		this.orderDAO_read = orderDAO_read;
	}
	
	public void setLeadsDAO_read(LeadsDAO leadsDAO_read) {
		this.leadsDAO_read = leadsDAO_read;
	}

	@Override
	public void setLeadsDAO(LeadsDAO paramLeadsDAO) {
		this.dao = paramLeadsDAO;

	}

	/* (non-Javadoc)
	 * @see shcem.trade.component.ILeadsManager#getLeadsByID(java.lang.Integer)
	 */
	@Override
	public Leads getLeadsByID(Integer leadsID) {
		return this.leadsDAO_read.getLeadsByID(leadsID);
	}

	/* (non-Javadoc)
	 * @see shcem.trade.component.ILeadsManager#getLeadsList(shcem.base.query.QueryConditions, shcem.base.query.PageInfo)
	 */
	@Override
	public List<Leads> getLeadsList(QueryConditions qc, PageInfo pageInfo) {
		return this.leadsDAO_read.getLeadsList(qc, pageInfo);
	}
	
	/* (non-Javadoc)
	 * @see shcem.trade.component.ILeadsManager#getLeadsList(shcem.base.query.QueryConditions, shcem.base.query.PageInfo)
	 */
	@Override
	public List<LeadsForIMServiceModel> getLeadsListForIM(QueryConditions qc, PageInfo pageInfo) {
		return this.leadsDAO_read.getLeadsListForIM(qc, pageInfo);
	}

	@Override
	public List<LeadsLiner> getLeadsListLiner(LeadsListLinerQueryModel model, PageInfo pageInfo) {
		return this.leadsDAO_read.getLeadsListLiner(model, pageInfo);
	}
	
	@Override
	public List<LeadsTemplatePrice> getLeadsTemplatePriceList(Integer leadsID) {
		this.log.info(this.getClass().getName()+" getLeadsTemplatePriceList() component Start");
		List<LeadsTemplatePrice>  list = leadsDAO_read.getLeadsTemplatePriceList(leadsID);
		this.log.info(this.getClass().getName()+" getLeadsTemplatePriceList() component End");
		return list;
	}

	@Override
	public Map<String, BigDecimal> GetFirmDailyTradeInfoLiner(QueryConditions qcLeads, QueryConditions qcOrder,
			String firmId) {

		// 当日发布报价吨数
		BigDecimal todayBuyLeadsTon = BigDecimal.ZERO;
		BigDecimal todaySellLeadsTon = BigDecimal.ZERO;
		BigDecimal todayAllLeadsTon = BigDecimal.ZERO;

		// 当前有效报价吨数
		BigDecimal nowBuyLeadsTon = BigDecimal.ZERO;
		BigDecimal nowSellLeadsTon = BigDecimal.ZERO;
		BigDecimal nowAllLeadsTon = BigDecimal.ZERO;

		List<Leads> leadsList = leadsDAO_read.getLeadsList(qcLeads, null);

		for (Leads leads : leadsList) {
			int Direction = leads.getDirection();// 买卖方向，0：offer卖，1：BID买
			int LeadsStatus = leads.getLeadsStatus();// 报盘状态 0有效 1失效，10：成交，99：撤销

			// 此报盘总批数
			int allQuantity = leads.getQuantity() + leads.getLockQuantity() + leads.getDealtQuantity();

			// 此报盘总吨数
			BigDecimal AllTons = new BigDecimal(allQuantity).multiply(leads.getTradeUnitNumber());

			// 此报盘有效吨数
			BigDecimal validTons = new BigDecimal(leads.getQuantity() + leads.getLockQuantity())
					.multiply(leads.getTradeUnitNumber());

			// 买报盘
			if (Direction == 1) {
				todayBuyLeadsTon = todayBuyLeadsTon.add(AllTons);
				if (LeadsStatus == 0) {
					// 当前有效
					nowBuyLeadsTon = nowBuyLeadsTon.add(validTons);
				}
			} else {
				// 卖报盘
				todaySellLeadsTon = todaySellLeadsTon.add(AllTons);
				if (LeadsStatus == 0) {
					// 当前有效
					nowSellLeadsTon = nowSellLeadsTon.add(validTons);
				}
			}
		}

		// 当日成交吨数
		BigDecimal todayBuyOrderTon = BigDecimal.ZERO;
		BigDecimal todaySellOrderTon = BigDecimal.ZERO;
		BigDecimal todayAllOrderTon = BigDecimal.ZERO;

		// 当日成交金额
		BigDecimal todayBuyOrderMoney = BigDecimal.ZERO;
		BigDecimal todaySellOrderMoney = BigDecimal.ZERO;
		BigDecimal todayAllOrderMoney = BigDecimal.ZERO;

		List<Order> orderList = orderDAO_read.getOrderList(qcOrder, null);

		for (Order order : orderList) {
			int Direction;// 买卖方向，0：offer卖，1：BID买
			String buyFirmId = order.getBuyFirmId();
			if (firmId.equals(buyFirmId)) {
				Direction = 1;
			} else {
				Direction = 0;
			}

			// 此成交总吨数
			BigDecimal AllTons = new BigDecimal(order.getQuantity()).multiply(order.getTradeUnitNumber());
			// 此成交总金额
			BigDecimal orderMoney = order.getAmount();

			if (Direction == 1) {
				// 买成交
				todayBuyOrderTon = todayBuyOrderTon.add(AllTons);
				todayBuyOrderMoney = todayBuyOrderMoney.add(orderMoney);
			} else {
				// 卖成交
				todaySellOrderTon = todaySellOrderTon.add(AllTons);
				todaySellOrderMoney = todaySellOrderMoney.add(orderMoney);
			}
		}

		// 买卖总额加起来
		todayAllLeadsTon = todayBuyLeadsTon.add(todaySellLeadsTon);
		nowAllLeadsTon = nowBuyLeadsTon.add(nowSellLeadsTon);
		todayAllOrderTon = todayBuyOrderTon.add(todaySellOrderTon);
		todayAllOrderMoney = todayBuyOrderMoney.add(todaySellOrderMoney);

		Map<String, BigDecimal> resultMap = new HashMap<String, BigDecimal>();
		resultMap.put("todayBuyLeadsTon", todayBuyLeadsTon);
		resultMap.put("todaySellLeadsTon", todaySellLeadsTon);
		resultMap.put("todayAllLeadsTon", todayAllLeadsTon);

		resultMap.put("nowBuyLeadsTon", nowBuyLeadsTon);
		resultMap.put("nowSellLeadsTon", nowSellLeadsTon);
		resultMap.put("nowAllLeadsTon", nowAllLeadsTon);

		resultMap.put("todayBuyOrderTon", todayBuyOrderTon);
		resultMap.put("todaySellOrderTon", todaySellOrderTon);
		resultMap.put("todayAllOrderTon", todayAllOrderTon);

		resultMap.put("todayBuyOrderMoney", todayBuyOrderMoney);
		resultMap.put("todaySellOrderMoney", todaySellOrderMoney);
		resultMap.put("todayAllOrderMoney", todayAllOrderMoney);
		return resultMap;
	}
	
	/**
	 * 挂盘锁单
	 * @param enquiryid
	 * @throws Exception
	 */
	@Override
	public void lockLead(int enquiryid) throws Exception {
		
		this.log.info(this.getClass().getName()+" lockLead() component Start");
		
		// 检查并取得需要锁单的报盘明细
		LockLead lockLead = leadsDAO_read.checkLockLead(enquiryid);
		
		// 验证询盘状态
		if (lockLead == null || lockLead.getEnqexpid() == null) {
			throw new Exception("当前询盘已成交或已失效，请重新确认。");
		}
        
        // 验证询盘的有效时间与系统时间比较
        if ((new Date()).compareTo(lockLead.getEnqexpTime()) > 0) {
        	throw new Exception("当前询盘已过有效期，请重新确认。");
        }
        
		// 验证报盘状态
		if (lockLead.getLeadid() == null || lockLead.getLeadexpid() == null) {
			throw new Exception("当前报盘已成交或已失效，请重新确认。");
		}
     
		// 验证报盘的有效时间与系统时间比较
        if ((new Date()).compareTo(lockLead.getLeadexpTime()) > 0) {
        	throw new Exception("当前报盘已过有效期，请重新确认。");
        }

        // 非挂单中询盘 验证数量不可大于报盘可用数量
        if (lockLead.getEnqqnt() > lockLead.getLeadqnt()) {
        	throw new Exception("当前锁单数量超过报盘剩余数量，请重新确认。");
        }
		
		// 更新报盘
		dao.updateLead(lockLead);
		
		// 更新询盘状态
		dao.updateEnquiry(lockLead);
		
		// 更新询盘扩展表(报盘升贴水 元/吨)
		dao.updateEnquiryExpandLiner(lockLead);
		
		this.log.info(this.getClass().getName()+" lockLead() component End");
	}

}
