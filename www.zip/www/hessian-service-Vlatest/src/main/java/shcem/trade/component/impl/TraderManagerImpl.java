/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: TraderManagerImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.trade.component.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.common.dao.CommonDAO;
import shcem.common.service.model.ValueTxtView;
import shcem.constant.BusinessEnumConstants;
import shcem.systemMgr.dao.ISystemMgrDAO;
import shcem.systemMgr.dao.model.MRole;
import shcem.trade.component.ITraderManager;
import shcem.trade.dao.TraderDAO;
import shcem.trade.dao.model.CSRemindRemark;
import shcem.trade.dao.model.EnquiryLiner;
import shcem.trade.dao.model.ExportEnquiry;
import shcem.trade.dao.model.ExportEnquiryCounter;
import shcem.trade.dao.model.FirmPrivilege;
import shcem.trade.dao.model.FirmSpecialFee;
import shcem.trade.dao.model.FirmSpecialMargin;
import shcem.trade.dao.model.FirmSpecialSettleFee;
import shcem.trade.dao.model.FirmSpecialSettleMargin;
import shcem.trade.dao.model.NotTradeDay;
import shcem.trade.dao.model.TTradeTime;
import shcem.trade.dao.model.TemplatePrivilege;
import shcem.trade.dao.model.TmptSectionRlsp;
import shcem.trade.dao.model.TradeTemplate;
import shcem.trade.dao.model.TradeTime;
import shcem.trade.dao.model.TraderPrivilege;
import shcem.trade.service.model.SpecialOprDto;
import shcem.util.DateUtil;

/**
 * TraderManagerImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class TraderManagerImpl extends BaseManager implements ITraderManager {
	private TraderDAO dao;
	
	private TraderDAO traderDAO_read;
	
	private CommonDAO commonDao;
	
	private ISystemMgrDAO systemMgrDAO;
	
	private ISystemMgrDAO systemMgrDAO_read;
	
	
	
	public ISystemMgrDAO getSystemMgrDAO_read() {
		return systemMgrDAO_read;
	}



	public void setTraderDAO_read(TraderDAO traderDAO_read) {
		this.traderDAO_read = traderDAO_read;
	}



	public void setSystemMgrDAO_read(ISystemMgrDAO systemMgrDAO_read) {
		this.systemMgrDAO_read = systemMgrDAO_read;
	}

	private void rollBack() {
		this.dao.rollBack();
	}
	
	public void setCommonDao(CommonDAO commonDao) {
		this.commonDao = commonDao;
	}

	public void setTraderDAO(TraderDAO dao) {
		this.dao = dao;
	}

	public void setSystemMgrDAO(ISystemMgrDAO systemMgrDAO) {
		this.systemMgrDAO = systemMgrDAO;
	}
	/**
	 * 取得TradeTimes列表
	 * 
	 * @param paramTradeTime
	 *            TradeTime
	 * @return TradeTimes列表
	 */
	public List<Map<String, Object>> getTradeTimes(TradeTime tradeTime) {
		this.log.debug("getTradeTimes Component Start");
		return this.traderDAO_read.getTradeTimes(tradeTime);
	}

	/**
	 * 取得TradeTime
	 * 
	 * @param paramString
	 *            sectionId
	 * @return TradeTime
	 */
	public TradeTime getTradeTime(String ID) {
		return this.dao.getTradeTime(ID);
	}

	/**
	 * 取得sectionId列表
	 * 
	 * @param paramString
	 *            sectionId
	 * @return sectionId列表
	 */
	public List<Map<String, Object>> getTradeTimeId(String id) {
		return this.dao.getTradeTimeId(id);
	}

	/**
	 * 追加TradeTime表
	 * 
	 * @param paramTradeTime
	 *            TradeTime
	 */
	public void insertTradeTime(TradeTime tradeTime) {
		this.dao.insertTradeTime(tradeTime);
	}

	/**
	 * 更新TradeTime表
	 * 
	 * @param paramTradeTime
	 *            TradeTime
	 */
	public void updateTradeTime(TradeTime tradeTime) {
		this.dao.updateTradeTime(tradeTime);
	}

	/**
	 * 取得TradeTimeBreed列表
	 * 
	 * @param paramString
	 *            sectionId
	 * @return TradeTimeBreed列表
	 */
	public List<Map<String, Object>> getTradeTimeBreed(String ID) {
		return this.dao.getTradeTimeBreed(ID);
	}

	/**
	 * 取得TradeTimeRelBreed列表
	 * 
	 * @param paramString
	 *            sectionId
	 * @return TradeTimeRelBreed列表
	 */
	public List<Map<String, Object>> getTradeTimeRelBreed(String ID) {
		return this.dao.getTradeTimeRelBreed(ID);
	}

	/**
	 * 删除TradeTime表
	 * 
	 * @param paramTradeTime
	 *            sectionid
	 */
	public void deleteTradeTimeById(String sectionID) {
		this.dao.deleteTradeTimeById(sectionID);
	}

	/**
	 * 取得系统时间
	 * 
	 * @return 系统时间
	 */
	public String getSysdate() {
		return this.dao.getSysdate();
	}
	
	/**
	 * 
	 */
	public List<TradeTemplate> getTradeTemplateList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getTradeTemplateList component Start");
		return this.dao.getTradeTemplateList(qc,pageInfo);
	}
	
	/**
	 * 
	 */
	public List<TradeTemplate> getTradeTemplateList(QueryConditions qc,PageInfo pageInfo,String userId) {
		this.log.debug("getTradeTemplateList component Start");
		List<TradeTemplate> list = this.dao.getTradeTemplateList(qc,pageInfo);
		List<MRole> roleList = this.systemMgrDAO_read.getRoleListByUserId(userId);
		boolean logisticsWarehouseAdminRole = false;
		boolean riskRole = false;
		if (roleList != null && roleList.size() > 0){
			for (MRole mrole: roleList){
				// 物流仓库管理员
				if (BusinessEnumConstants.RoleType.LogisticsWarehouseAdminRoleCode.getValue().equals(mrole.getRoleCode())){
					logisticsWarehouseAdminRole = true;
					continue;
				}
				// 风控角色
				if (BusinessEnumConstants.RoleType.ControlGeneralerRoleCode.getValue().equals(mrole.getRoleCode()) ||
						BusinessEnumConstants.RoleType.ControlAuditRoleCode.getValue().equals(mrole.getRoleCode())	){
					riskRole = true;
					continue;
				}
			}
		}
		if (logisticsWarehouseAdminRole || riskRole){
			if (list != null &&  list.size() > 0){
				int size = list.size();
				for (int i = 0 ; i < size ; i++){
					list.get(i).setLogiWarehAdmin(logisticsWarehouseAdminRole);
					list.get(i).setRiskRole(riskRole);
				}
			}
		}
		this.log.debug("getTradeTemplateList component End");
		return list;
	}
	
	/**
	 * 
	 */
	public TradeTemplate getTradeTemplateById(String strId)  {
		this.log.debug("getTradeTemplateById component Start");
		return this.traderDAO_read.getTradeTemplateById(strId);
	}
	
	/**
	 * 
	 */
	public int addTradeTemplate(TradeTemplate params) {
		this.log.debug("addTradeTemplate component Start");
		return this.dao.addTradeTemplate(params);
	}

	/**
	 * 
	 */
	public int updTradeTemplate(TradeTemplate params) {
		this.log.debug("updTradeTemplate component Start");
		return this.dao.updTradeTemplate(params);
	}
	
	/**
	 * 
	 */
	public List<TTradeTime> getTTradeTimeList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getTTradeTimeList component Start");
		return this.traderDAO_read.getTTradeTimeList(qc,pageInfo);
	}
	
	/**
	 * 
	 */
	public TTradeTime getTTradeTimeById(String strId) {
		this.log.debug("getTTradeTimeById component Start");
		return this.traderDAO_read.getTTradeTimeById(strId);
	}
	
	/**
	 * 
	 */
	public int addTTradeTime(TTradeTime params) {
		this.log.debug("addTTradeTime component Start");
		return this.dao.addTTradeTime(params);
	}

	/**
	 * 
	 */
	public int updTTradeTime(TTradeTime params) {
		this.log.debug("updTTradeTime component Start");
		return this.dao.updTTradeTime(params);
	}

	/**
	 * 
	 */
	public int delTTradeTime(String sId) {
		this.log.debug("delTTradeTime component Start");
		int rtn = 0;
		int isHaveY = dao.isHaveTmptSectionRlspWithY(sId);
		if (isHaveY > 0) {
			rtn = -1;
		} else {
			int isHaveN = dao.isHaveTmptSectionRlspWithN(sId);
			if (isHaveN > 0) {
				rtn = rtn + this.dao.delTmptSectionRlspWithN(sId);
			}
			rtn = rtn + this.dao.delTTradeTime(sId);
		}
		return rtn;
	}
	
	
	/**
	 * 
	 */
	public List<TmptSectionRlsp> getTmptSectionRlspList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getTmptSectionRlspList component Start");
		return this.traderDAO_read.getTmptSectionRlspList(qc, pageInfo);
	}

	/**
	 * 
	 */
	public int addTmptSectionRlsp(TmptSectionRlsp params) {
		this.log.debug("addTmptSectionRlsp component Start");
		return this.dao.addTmptSectionRlsp(params);
	}

	/**
	 * 
	 */
	public int updTmptSectionRlsp(TmptSectionRlsp params) {
		this.log.debug("updTmptSectionRlsp component Start");
		return this.dao.updTmptSectionRlsp(params);
	}

	/**
	 * 
	 */
	public int delTmptSectionRlsp(String tId, String sId) {
		this.log.debug("delTmptSectionRlsp component Start");
		return this.dao.delTmptSectionRlsp(tId, sId);
	}
	
	/**
	 * 
	 */
	public List<FirmSpecialFee> getFirmSpecialFeeList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getFirmSpecialFeeList component Start");
		return this.traderDAO_read.getFirmSpecialFeeList(qc,pageInfo);
	}
	
	/**
	 * 
	 */
	public FirmSpecialFee getFirmSpecialFeeById(String strId, String kbn) {
		this.log.debug("getFirmSpecialFeeById component Start");
		FirmSpecialFee firmSpecialFee = this.traderDAO_read.getFirmSpecialFeeById(strId, kbn);
		
		//交易场 ??byID为什么取出所有关联的交易场？业务需要？启用，使用单一数据
		/*List<FirmSpecialFee> tradeTmptList = this.traderDAO_read.getTradeTmplListByFirm(firmSpecialFee.getFirmID());
		if (tradeTmptList != null && tradeTmptList.size() > 0) {
			int[] tradeTmptIdArray = new int[tradeTmptList.size()];
			for (int i = 0; i < tradeTmptList.size(); i++) {
				tradeTmptIdArray[i] = tradeTmptList.get(i).getTradeTmptId();
			}
			firmSpecialFee.setTradeTmptIdArray(tradeTmptIdArray);
		}*/
		if(firmSpecialFee.getTradeTmptId()!=null) {
			int[] tradeTmptIdArray = new int[1];
			tradeTmptIdArray[0] = firmSpecialFee.getTradeTmptId();
			firmSpecialFee.setTradeTmptIdArray(tradeTmptIdArray);
		}
		return firmSpecialFee;
	}
	
	/**
	 * 
	 */
	public String  addFirmSpecialFee(FirmSpecialFee firmSpecialFee) {
		String msg = "";
		List<FirmSpecialFee> list;
		this.log.debug("addFirmSpecialFee component Start");
		//新增特殊交易商交易手续费  交易商相关交易场
		int[] tradeTmptIdArray = firmSpecialFee.getTradeTmptIdArray();
		String tradeTmptIds="";
		for (int i = 0; i < tradeTmptIdArray.length; i++) {
			if(i > 0)tradeTmptIds +=",";
			tradeTmptIds += tradeTmptIdArray[i];
		}
		// 如果分类ID 是 -1（全部）时，先删除所有已经存在的数据
		boolean bool = false;
		Integer categoryId = firmSpecialFee.getCategoryId();
		if (categoryId != null && categoryId == -1){
			if (tradeTmptIdArray.length > 0){
				for(int tradeTmptId : tradeTmptIdArray){
					int count = dao.delFirmSpecialFeeByFirmID(firmSpecialFee.getFirmID(),tradeTmptId);
					if (count<=0){
						this.log.debug("没有删除数据，FirmID："+firmSpecialFee.getFirmID()+",tradeTmptId:"+tradeTmptId);
					}
				}
				bool = true;
			}
		}
		//1） 同一品类下 ,同一交易商 同一交易场 同一牌号只能新增一次 
		if (firmSpecialFee.getBrandId() != null) {
			list = this.dao.getFirmSpecialFeeListByBrand(tradeTmptIds,firmSpecialFee.getFirmID(),firmSpecialFee.getCategoryId(),firmSpecialFee.getBrandId());
			String TradeTmptName = "";
			if (list != null && list.size() > 0) {
				for (int i = 0; i <list.size(); i++) {
					ValueTxtView TradeTmpt = this.dao.getTradeTmptById(list.get(i).getTradeTmptId());
					if(i>0)TradeTmptName += ",";
					TradeTmptName += TradeTmpt.getText();
				}
				msg = "该牌号已经在：【"+TradeTmptName+"】 设置过特殊交易商交易手续费";
				return msg;
			}
			
		}
		//2） 同一品类下 ,同一交易商 同一交易场只能新增一次 (牌号没有选择)
		if (firmSpecialFee.getBrandId() == null && firmSpecialFee.getCategoryId()!= null) {
			list = this.dao.getFirmSpecialFeeListByCategory(tradeTmptIds,firmSpecialFee.getFirmID(),firmSpecialFee.getCategoryId());
			String TradeTmptName = "";
			if (list != null && list.size() > 0) {
				for (int i = 0; i < list.size(); i++) {
					ValueTxtView TradeTmpt = this.dao.getTradeTmptById(list.get(i).getTradeTmptId());
					if(i>0)TradeTmptName += ",";
					TradeTmptName += TradeTmpt.getText();
				}
				msg = "该分类已经在：【"+TradeTmptName+"】 设置过特殊交易商交易手续费";
				return msg;
			}
		}
		if (tradeTmptIdArray.length > 0) {
			for (int i = 0; i < tradeTmptIdArray.length; i++) {
				msg = "00000";
				firmSpecialFee.setTradeTmptId(tradeTmptIdArray[i]);
				if(bool){
					int resultCode = this.dao.addAllCategoryIDToFirmSpecialFee(firmSpecialFee);
					if (resultCode == -1){
						msg = "保存全部分类失败!FirmID:"+firmSpecialFee.getFirmID()+",TradeTmptId:"+firmSpecialFee.getTradeTmptId();
						this.dao.rollBack();
					}
				}else{
					this.dao.addFirmSpecialFee(firmSpecialFee);
				}
			}
		}
		return msg;
	}

	/**
	 * 
	 */
	public int updFirmSpecialFee(FirmSpecialFee params, String kbn) {
		this.log.debug("updFirmSpecialFee component Start");
		return this.dao.updFirmSpecialFee(params, kbn);
	}

	/**
	 * 
	 */
	public int delFirmSpecialFee(int[] firmSpecialFeeIDs, String kbn) {
		this.log.debug("delFirmSpecialFee component Start");
		String ids="";
		for (int i = 0; i < firmSpecialFeeIDs.length; i++) {
			if(i>0)ids +=",";
			ids += firmSpecialFeeIDs[i];
		}
		return this.dao.delFirmSpecialFee(ids, kbn);
	}
	
	/**
	 * 
	 */
	public List<FirmSpecialMargin> getFirmSpecialMarginList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getFirmSpecialMarginList component Start");
		return this.traderDAO_read.getFirmSpecialMarginList(qc,pageInfo);
	}
	
	/**
	 * 
	 */
	public FirmSpecialMargin getFirmSpecialMarginById(String strId, String kbn) {
		this.log.debug("getFirmSpecialMarginById component Start");
		FirmSpecialMargin firmSpecialMargin = this.traderDAO_read.getFirmSpecialMarginById(strId, kbn);;
		//交易场
		List<FirmSpecialMargin> tradeTmptList = this.traderDAO_read.getFirmSpecialMarginTradeTmplListByFirm(firmSpecialMargin.getFirmID());
		//交易场 ??byID为什么取出所有关联的交易场？业务需要？启用，使用单一数据
		/*if (tradeTmptList != null && tradeTmptList.size() > 0) {
			int[] tradeTmptIdArray = new int[tradeTmptList.size()];
			for (int i = 0; i < tradeTmptList.size(); i++) {
				tradeTmptIdArray[i] = tradeTmptList.get(i).getTradeTmptId();
			}
			firmSpecialMargin.setTradeTmptIdArray(tradeTmptIdArray);
		}*/
		if(firmSpecialMargin.getTradeTmptId()!=null) {
			int[] tradeTmptIdArray = new int[1];
			tradeTmptIdArray[0] = firmSpecialMargin.getTradeTmptId();
			firmSpecialMargin.setTradeTmptIdArray(tradeTmptIdArray);
		}
		return firmSpecialMargin;
	}
	
	/**
	 * 
	 */
	public String addFirmSpecialMargin(FirmSpecialMargin firmSpecialMargin) {
		this.log.debug("addFirmSpecialMargin component Start");
		String msg="";
		int[] tradeTmptIdArray = firmSpecialMargin.getTradeTmptIdArray();
		String tradeTmptIds="";
		for (int i = 0; i < tradeTmptIdArray.length; i++) {
			if(i > 0)tradeTmptIds +=",";
			tradeTmptIds += tradeTmptIdArray[i];
		}
		List<FirmSpecialMargin> list;
		//1） 同一品类下 ,同一交易商 同一交易场 同一牌号只能新增一次 
		if (firmSpecialMargin.getBrandId() != null) {
			list = this.dao.getfirmSpecialMarginListByBrand(tradeTmptIds,firmSpecialMargin.getFirmID(),firmSpecialMargin.getCategoryId(),
					firmSpecialMargin.getBrandId());
			String TradeTmptName = "";
			if (list != null && list.size() > 0) {
				for (int i = 0; i <list.size(); i++) {
					ValueTxtView TradeTmpt = this.dao.getTradeTmptById(list.get(i).getTradeTmptId());
					if(i>0)TradeTmptName += ",";
					TradeTmptName += TradeTmpt.getText();
				}
				msg = "该牌号已经在：【"+TradeTmptName+"】 设置过特殊交易商交易保证金";
				return msg;
			}
		}
		// 如果分类ID 是 -1（全部）时，先删除所有已经存在的数据
		boolean bool = false;
		Integer categoryId = firmSpecialMargin.getCategoryId();
		if (categoryId != null && categoryId == -1){
			if (tradeTmptIdArray.length > 0){
				for(int tradeTmptId : tradeTmptIdArray){
					int count = dao.delFirmSpecialMarginByFirmID(firmSpecialMargin.getFirmID(),tradeTmptId);
					if (count<=0){
						this.log.debug("没有删除数据，FirmID："+firmSpecialMargin.getFirmID()+",tradeTmptId:"+tradeTmptId);
					}
				}
				bool = true;
			}
		}
		//2） 同一品类下 ,同一交易商 同一交易场只能新增一次 (牌号没有选择)
		if (firmSpecialMargin.getBrandId() == null && firmSpecialMargin.getCategoryId()!= null) {
			list = this.dao.getFirmSpecialMarginListByCategory(tradeTmptIds,firmSpecialMargin.getFirmID(),firmSpecialMargin.getCategoryId());
			String TradeTmptName = "";
			if (list != null && list.size() > 0) {
				for (int i = 0; i < tradeTmptIdArray.length; i++) {
					ValueTxtView TradeTmpt = this.dao.getTradeTmptById(list.get(i).getTradeTmptId());
					if(i>0)TradeTmptName += ",";
					TradeTmptName += TradeTmpt.getText();
				}
				msg = "该分类已经在：【"+TradeTmptName+"】 设置过特殊交易商交易保证金";
				return msg;
			}
		}
		
		//新增特殊交易商交易手续费  交易商相关交易场
		if (tradeTmptIdArray != null && tradeTmptIdArray.length > 0) {
			for (int i = 0; i < tradeTmptIdArray.length; i++) {
				firmSpecialMargin.setTradeTmptId(tradeTmptIdArray[i]);
				msg = "00000";
				if(bool){
					int resultCode = this.dao.addAllCategoryIDToFirmSpecialMargin(firmSpecialMargin);
					if (resultCode == -1){
						msg = "保存全部分类失败!FirmID:"+firmSpecialMargin.getFirmID()+",TradeTmptId:"+firmSpecialMargin.getTradeTmptId();
						this.dao.rollBack();
					}
				}else{
					this.dao.addFirmSpecialMargin(firmSpecialMargin);
				}
			}
		}
		return msg;
	}

	/**
	 * 
	 */
	public int updFirmSpecialMargin(FirmSpecialMargin params, String kbn) {
		this.log.debug("updFirmSpecialMargin component Start");
		return this.dao.updFirmSpecialMargin(params, kbn);
	}

	/**
	 * 
	 */
	public int delFirmSpecialMargin(int[] firmSpecialMarginIDs, String kbn) {
		this.log.debug("delFirmSpecialMargin component Start");
		String ids="";
		for (int i = 0; i < firmSpecialMarginIDs.length; i++) {
			if(i>0)ids +=",";
			ids += firmSpecialMarginIDs[i];
		}
		return this.dao.delFirmSpecialMargin(ids, kbn);
	}
	
	/**
	 * 
	 */
	public List<FirmSpecialSettleFee> getFirmSpecialSettleFeeList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getFirmSpecialSettleFeeList component Start");
		return this.traderDAO_read.getFirmSpecialSettleFeeList(qc,pageInfo);
	}
	
	/**
	 * 
	 */
	public FirmSpecialSettleFee getFirmSpecialSettleFeeById(String strId, String kbn) {
		this.log.debug("getFirmSpecialSettleFeeById component Start");
		FirmSpecialSettleFee firmSpecialSettleFee = this.traderDAO_read.getFirmSpecialSettleFeeById(strId, kbn);
		//交易场
		List<FirmSpecialSettleFee> tradeTmptList = this.traderDAO_read.getFirmSpecialSettleFeeTradeTmplListByFirm(firmSpecialSettleFee.getFirmID());
		if (tradeTmptList != null && tradeTmptList.size() > 0) {
			int[] tradeTmptIdArray = new int[tradeTmptList.size()];
			for (int i = 0; i < tradeTmptList.size(); i++) {
				tradeTmptIdArray[i] = tradeTmptList.get(i).getTradeTmptId();
			}
			firmSpecialSettleFee.setTradeTmptIdArray(tradeTmptIdArray);
		}
		
		return firmSpecialSettleFee;
	}
	
	/**
	 * 
	 */
	public String addFirmSpecialSettleFee(FirmSpecialSettleFee firmSpecialSettleFee) {
		this.log.debug("addFirmSpecialSettleFee component Start");
		String msg="";
		List<FirmSpecialSettleFee> list;
		
		
		//新增特殊交易商交易手续费  交易商相关交易场
		int[] tradeTmptIdArray = firmSpecialSettleFee.getTradeTmptIdArray();
		String tradeTmptIds="";
		for (int i = 0; i < tradeTmptIdArray.length; i++) {
			if(i > 0)tradeTmptIds +=",";
			tradeTmptIds += tradeTmptIdArray[i];
		}
		//1） 同一品类下 ,同一交易商 同一交易场 同一牌号只能新增一次 
		if (firmSpecialSettleFee.getBrandId() != null) {
			list = this.dao.getFirmSpecialSettleFeeListByBrand(tradeTmptIds,firmSpecialSettleFee.getFirmID(),
					firmSpecialSettleFee.getCategoryId(),firmSpecialSettleFee.getBrandId());
			String TradeTmptName = "";
			if (list != null && list.size() > 0) {
				for (int i = 0; i <list.size(); i++) {
					ValueTxtView TradeTmpt = this.dao.getTradeTmptById(list.get(i).getTradeTmptId());
					if(i>0)TradeTmptName += ",";
					TradeTmptName += TradeTmpt.getText();
				}
				msg = "该牌号已经在：【"+TradeTmptName+"】 设置过特殊交易商交收手续费";
				return msg;
			}
		}
		//2） 同一品类下 ,同一交易商 同一交易场只能新增一次 (牌号没有选择)
		if (firmSpecialSettleFee.getBrandId() == null && firmSpecialSettleFee.getCategoryId()!= null) {
			list = this.dao.getFirmSpecialSettleFeeListByCategory(tradeTmptIds,firmSpecialSettleFee.getFirmID(),
					firmSpecialSettleFee.getCategoryId());
			String TradeTmptName = "";
			if (list != null && list.size() > 0) {
				for (int i = 0; i < tradeTmptIdArray.length; i++) {
					ValueTxtView TradeTmpt = this.dao.getTradeTmptById(list.get(i).getTradeTmptId());
					if(i>0)TradeTmptName += ",";
					TradeTmptName += TradeTmpt.getText();
				}
				msg = "该分类已经在：【"+TradeTmptName+"】 设置过特殊交易商交收手续费";
				return msg;
			}
		}
		if (tradeTmptIdArray.length > 0) {
			for (int i = 0; i < tradeTmptIdArray.length; i++) {
				firmSpecialSettleFee.setTradeTmptId(tradeTmptIdArray[i]);
				this.dao.addFirmSpecialSettleFee(firmSpecialSettleFee);
				msg = "00000";
			}
		}

		return msg;
	}

	/**
	 * 
	 */
	public int updFirmSpecialSettleFee(FirmSpecialSettleFee params, String kbn) {
		this.log.debug("updFirmSpecialSettleFee component Start");
		return this.dao.updFirmSpecialSettleFee(params, kbn);
	}

	/**
	 * 
	 */
	public int delFirmSpecialSettleFee(int[] firmSpecialSettleFeeIDs, String kbn) {
		this.log.debug("delFirmSpecialSettleFee component Start");
		String ids="";
		for (int i = 0; i < firmSpecialSettleFeeIDs.length; i++) {
			if(i>0)ids +=",";
			ids += firmSpecialSettleFeeIDs[i];
		}
		return this.dao.delFirmSpecialSettleFee(ids, kbn);
	}
	
	/**
	 * 
	 */
	public List<FirmSpecialSettleMargin> getFirmSpecialSettleMarginList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getFirmSpecialSettleMarginList component Start");
		return this.traderDAO_read.getFirmSpecialSettleMarginList(qc,pageInfo);
	}
	
	/**
	 * 
	 */
	public FirmSpecialSettleMargin getFirmSpecialSettleMarginById(String strId, String kbn) {
		this.log.debug("getFirmSpecialSettleMarginById component Start");
		FirmSpecialSettleMargin firmSpecialSettleMargin = this.traderDAO_read.getFirmSpecialSettleMarginById(strId, kbn);
		//交易场
		List<FirmSpecialSettleMargin> tradeTmptList = this.traderDAO_read.getFirmSpecialSettleMarginTradeTmplListByFirm(firmSpecialSettleMargin.getFirmID());
		if (tradeTmptList != null && tradeTmptList.size() > 0) {
			int[] tradeTmptIdArray = new int[tradeTmptList.size()];
			for (int i = 0; i < tradeTmptList.size(); i++) {
				tradeTmptIdArray[i] = tradeTmptList.get(i).getTradeTmptId();
			}
			firmSpecialSettleMargin.setTradeTmptIdArray(tradeTmptIdArray);
		}
		
		return firmSpecialSettleMargin;
	}
	
	/**
	 * 
	 */
	public String  addFirmSpecialSettleMargin(FirmSpecialSettleMargin firmSpecialSettleMargin) {
		this.log.debug("addFirmSpecialSettleMargin component Start");
		
		String msg="";
		List<FirmSpecialSettleMargin> list;
		
		
		//新增特殊交易商交易手续费  交易商相关交易场
		int[] tradeTmptIdArray = firmSpecialSettleMargin.getTradeTmptIdArray();
		String tradeTmptIds="";
		for (int i = 0; i < tradeTmptIdArray.length; i++) {
			if(i > 0)tradeTmptIds +=",";
			tradeTmptIds += tradeTmptIdArray[i];
		}
		//1） 同一品类下 ,同一交易商 同一交易场 同一牌号只能新增一次 
		if (firmSpecialSettleMargin.getBrandId() != null) {
			list = this.dao.getFirmSpecialSettleMarginListByBrand(tradeTmptIds,firmSpecialSettleMargin.getFirmID(),
					firmSpecialSettleMargin.getCategoryId(),firmSpecialSettleMargin.getBrandId());
			String TradeTmptName = "";
			if (list != null && list.size() > 0) {
				for (int i = 0; i <list.size(); i++) {
					ValueTxtView TradeTmpt = this.dao.getTradeTmptById(list.get(i).getTradeTmptId());
					if(i>0)TradeTmptName += ",";
					TradeTmptName += TradeTmpt.getText();
				}
				msg = "该牌号已经在：【"+TradeTmptName+"】 设置过特殊交易商交收保证金";
				return msg;
			}
		}
		//2） 同一品类下 ,同一交易商 同一交易场只能新增一次 (牌号没有选择)
		if (firmSpecialSettleMargin.getBrandId() == null && firmSpecialSettleMargin.getCategoryId()!= null) {
			list = this.dao.getFirmSpecialSettleMarginListByCategory(tradeTmptIds,firmSpecialSettleMargin.getFirmID(),
					firmSpecialSettleMargin.getCategoryId());
			String TradeTmptName = "";
			if (list != null && list.size() > 0) {
				for (int i = 0; i < tradeTmptIdArray.length; i++) {
					ValueTxtView TradeTmpt = this.dao.getTradeTmptById(list.get(i).getTradeTmptId());
					if(i>0)TradeTmptName += ",";
					TradeTmptName += TradeTmpt.getText();
				}
				msg = "该分类已经在：【"+TradeTmptName+"】 设置过特殊交易商交收保证金";
				return msg;
			}
		}
		if (tradeTmptIdArray.length > 0) {
			for (int i = 0; i < tradeTmptIdArray.length; i++) {
				firmSpecialSettleMargin.setTradeTmptId(tradeTmptIdArray[i]);
				this.dao.addFirmSpecialSettleMargin(firmSpecialSettleMargin);
				msg = "00000";
			}
		}
		return msg;
	}

	/**
	 * 
	 */
	public int updFirmSpecialSettleMargin(FirmSpecialSettleMargin params, String kbn) {
		this.log.debug("updFirmSpecialSettleMargin component Start");
		return this.dao.updFirmSpecialSettleMargin(params, kbn);
	}

	/**
	 * 
	 */
	public int delFirmSpecialSettleMargin(int[] firmSpecialSettleMarginIDs, String kbn) {
		this.log.debug("delFirmSpecialSettleMargin component Start");
		String ids="";
		for (int i = 0; i < firmSpecialSettleMarginIDs.length; i++) {
			if(i>0)ids +=",";
			ids += firmSpecialSettleMarginIDs[i];
		}
		return this.dao.delFirmSpecialSettleMargin(ids, kbn);
	}
	
	/**
	 * 
	 */
	public List<TemplatePrivilege> getTemplatePrivilegeList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getTemplatePrivilegeList component Start");
		return this.traderDAO_read.getTemplatePrivilegeList(qc,pageInfo);
	}
	
	/**
	 * 
	 */
	public TemplatePrivilege getTemplatePrivilegeById(String strId) {
		this.log.debug("getTemplatePrivilegeById component Start");
		return this.traderDAO_read.getTemplatePrivilegeById(strId);
	}
	
	/**
	 * 
	 */
	public int addTemplatePrivilege(TemplatePrivilege params) {
		int resultCode = 0;
		this.log.info(this.getClass().getName()+ " addTemplatePrivilege component Start");
		try {
			if (params != null){
				// 校验添加 数据的分类权限
				QueryConditions qcTemp = new QueryConditions();
				qcTemp.addCondition("temp.TradeTmptId", "=", params.getTradeTmptId());
				qcTemp.addCondition("temp.CategoryId", "=", params.getCategoryId());
				qcTemp.addCondition("(temp.BrandId = " + 0 + " or temp.BrandId is null) and '1'=", " ", 1);
				List<TemplatePrivilege> listTemp = this.dao.getTemplatePrivilegeList(qcTemp, null);
				if (listTemp == null || listTemp.size() == 0){
					// 批量插入牌号ID
					int[] brandIdArrayInt = params.getBrandIdArrayInt();
					if (brandIdArrayInt.length >= 1){
						for (int brandId : brandIdArrayInt){
							params.setBrandId(brandId);
							// 校验添加的数据 在数据库中是否存在
							QueryConditions qc = new QueryConditions();
							qc.addCondition("temp.TradeTmptId", "=", params.getTradeTmptId());
							qc.addCondition("temp.CategoryId", "=", params.getCategoryId());
							qc.addCondition("temp.BrandId", "=", params.getBrandId());
							List<TemplatePrivilege> list = this.dao.getTemplatePrivilegeList(qc, null);
							if (list == null || list.size() == 0){
								this.dao.addTemplatePrivilege(params);
							}else{
								resultCode = -2;
								this.log.error("该数据已经存在,请核对后再添加,牌号："+params.getBrandId());
								this.rollBack();
								return resultCode;
							}
						}
					}else{
						// 校验添加的数据 在数据库中是否存在
						QueryConditions qc = new QueryConditions();
						qc.addCondition("temp.TradeTmptId", "=", params.getTradeTmptId());
						qc.addCondition("temp.CategoryId", "=", params.getCategoryId());
						List<TemplatePrivilege> list = this.dao.getTemplatePrivilegeList(qc, null);
						if (list == null || list.size() == 0){
							this.dao.addTemplatePrivilege(params);
						}else{
							this.dao.delTemplatePrivilegeByTradeTmptId(params.getTradeTmptId(), params.getCategoryId());
							this.dao.addTemplatePrivilege(params);
						}
					}
					
				}else{
					resultCode = -2;
					this.log.error("该数据已经存在,请核对后再添加,分类ID："+params.getCategoryId());
				}
			}
		} catch (Exception e) {
			resultCode = -1;
			this.log.error("添加交易场交易权限失败！"+e.getMessage());
			this.rollBack();
		}
		
		this.log.info(this.getClass().getName()+ " addTemplatePrivilege component End");
		return resultCode;
	}

	/**
	 * 
	 */
	public int updTemplatePrivilege(TemplatePrivilege params) {
		int resultcode = 0;
		this.log.info("updTemplatePrivilege component Start");
		try {
			// 校验添加 数据的分类权限
			QueryConditions qcTemp = new QueryConditions();
			qcTemp.addCondition("temp.TradeTmptId", "=", params.getTradeTmptId());
			qcTemp.addCondition("temp.CategoryId", "=", params.getCategoryId());
			qcTemp.addCondition("(temp.BrandId = " + 0 + " or temp.BrandId is null) and '1'=", " ", 1);
			List<TemplatePrivilege> listTemp = this.dao.getTemplatePrivilegeList(qcTemp, null);
			if (listTemp == null || listTemp.size() == 0){
				resultcode = this.dao.updTemplatePrivilege(params);
			}else{
				if (params.getBrandId() != null && params.getBrandId() != 0){
					// 校验添加 数据的分类权限
					QueryConditions qcTemp1 = new QueryConditions();
					qcTemp1.addCondition("temp.TradeTmptId", "=", params.getTradeTmptId());
					qcTemp1.addCondition("temp.CategoryId", "=", params.getCategoryId());
					qcTemp1.addCondition("temp.BrandId", "=", params.getBrandId());
					List<TemplatePrivilege> listTemp1 = this.dao.getTemplatePrivilegeList(qcTemp1, null);
					if (listTemp1 == null || listTemp1.size() == 0){
						resultcode = this.dao.updTemplatePrivilege(params);
					}else{
						resultcode = -2;
						this.log.info("当前分类下的牌号权限已经设定，请更改后再次设定。");
					}
				}else{
					
					resultcode = this.dao.updTemplatePrivilege(params);
				}
			}
		} catch (Exception e) {
			this.log.error("更新交易场交易权限表失败"+e.getMessage());
			resultcode = -1;
			this.rollBack();
		}
		this.log.info("updTemplatePrivilege component End");
		return resultcode;
	}

	/**
	 * 
	 */
	public int delTemplatePrivilege(String strId) {
		this.log.debug("delTemplatePrivilege component Start");
		return this.dao.delTemplatePrivilege(strId);
	}
	
	/**
	 * 
	 */
	public List<FirmPrivilege> getFirmPrivilegeList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getFirmPrivilegeList component Start");
		return this.traderDAO_read.getFirmPrivilegeList(qc,pageInfo);
	}
	
	/**
	 * 
	 */
	public FirmPrivilege getFirmPrivilegeById(String strId) {
		this.log.debug("getFirmPrivilegeById component Start");
		return this.traderDAO_read.getFirmPrivilegeById(strId);
	}
	
	/**
	 * 
	 */
	public int addFirmPrivilege(FirmPrivilege params) {
		int resultCode = 0;
		this.log.info(this.getClass().getName()+ " addFirmPrivilege component Start");
		try {
			if (params != null){
				// 校验添加 数据的分类权限
				QueryConditions qcTemp = new QueryConditions();
				qcTemp.addCondition("temp.FirmID", "=", params.getFirmID());
				qcTemp.addCondition("temp.TradeTmptId", "=", params.getTradeTmptId());
				qcTemp.addCondition("temp.CategoryId", "=", params.getCategoryId());
				qcTemp.addCondition("(temp.BrandId = " + 0 + " or temp.BrandId is null) and '1'=", " ", 1);
				List<FirmPrivilege> listTemp = this.dao.getFirmPrivilegeList(qcTemp, null);
				if (listTemp == null || listTemp.size() == 0){
					// 批量插入牌号ID
					int[] brandIdArrayInt = params.getBrandIdArrayInt();
					if (brandIdArrayInt.length >= 1){
						for (int brandId : brandIdArrayInt){
							params.setBrandId(brandId);
							// 校验添加的数据 在数据库中是否存在
							QueryConditions qc = new QueryConditions();
							qc.addCondition("temp.FirmID", "=", params.getFirmID());
							qc.addCondition("temp.TradeTmptId", "=", params.getTradeTmptId());
							qc.addCondition("temp.CategoryId", "=", params.getCategoryId());
							qc.addCondition("temp.BrandId", "=", params.getBrandId());
							List<FirmPrivilege> list = this.dao.getFirmPrivilegeList(qc, null);
							if (list == null || list.size() == 0){
								this.dao.addFirmPrivilege(params);
							}else{
								resultCode = -2;
								this.log.error("该数据已经存在,请核对后再添加,牌号："+params.getBrandId());
								this.rollBack();
								return resultCode;
							}
						}
					}else{
						QueryConditions qc = new QueryConditions();
						qc.addCondition("temp.FirmID", "=", params.getFirmID());
						qc.addCondition("temp.TradeTmptId", "=", params.getTradeTmptId());
						qc.addCondition("temp.CategoryId", "=", params.getCategoryId());
						List<FirmPrivilege> list = this.dao.getFirmPrivilegeList(qc, null);
						if (list == null || list.size() == 0){
							this.dao.addFirmPrivilege(params);
						}else{
							this.dao.delFirmPrivilegeByFirmID(params.getFirmID(),params.getTradeTmptId(),params.getCategoryId());
							this.dao.addFirmPrivilege(params);
						}
					}
					
				}else{
					resultCode = -2;
					this.log.error("该数据已经存在,请核对后再添加,分类ID："+params.getCategoryId());
				}
			}
		} catch (Exception e) {
			resultCode =-1;
			this.log.error("新增交易商交易权限失败"+e.getMessage());
			this.rollBack();
		}

		this.log.info(this.getClass().getName()+ " addFirmPrivilege component End");
		return resultCode;
	}

	/**
	 * 
	 */
	public int updFirmPrivilege(FirmPrivilege params) {
		int resultcode = 0;
		this.log.info(this.getClass().getName()+" updFirmPrivilege component Start");
		try {
			// 校验添加 数据的分类权限
			QueryConditions qcTemp = new QueryConditions();
			qcTemp.addCondition("temp.FirmID", "=", params.getFirmID());
			qcTemp.addCondition("temp.TradeTmptId", "=", params.getTradeTmptId());
			qcTemp.addCondition("temp.CategoryId", "=", params.getCategoryId());
			qcTemp.addCondition("(temp.BrandId = " + 0 + " or temp.BrandId is null) and '1'=", " ", 1);
			List<FirmPrivilege> listTemp = this.dao.getFirmPrivilegeList(qcTemp, null);
			if (listTemp == null || listTemp.size() == 0){
				resultcode = this.dao.updFirmPrivilege(params);
			}else{
				
				if (params.getBrandId() != null && params.getBrandId() != 0){
					// 校验添加 数据的分类权限
					QueryConditions qcTemp1 = new QueryConditions();
					qcTemp1.addCondition("temp.FirmID", "=", params.getFirmID());
					qcTemp1.addCondition("temp.TradeTmptId", "=", params.getTradeTmptId());
					qcTemp1.addCondition("temp.CategoryId", "=", params.getCategoryId());
					qcTemp1.addCondition("temp.BrandId", "=", params.getBrandId());
					List<FirmPrivilege> listTemp1 = this.dao.getFirmPrivilegeList(qcTemp1, null);
					if (listTemp1 == null || listTemp1.size() == 0){
						resultcode = this.dao.updFirmPrivilege(params);
					}else{
						resultcode = -2;
						this.log.info("当前分类下的牌号权限已经设定，请更改后再次设定。");
					}
				}else{
					resultcode = this.dao.updFirmPrivilege(params);
				}
			}
		} catch (Exception e) {
			this.log.error("交易商交易场权限表(特殊设定)失败"+e.getMessage());
			resultcode = -1;
			this.rollBack();
		}
		
		this.log.info(this.getClass().getName()+" updFirmPrivilege component End");
		return resultcode;
	}

	/**
	 * 
	 */
	public int delFirmPrivilege(String strId) {
		this.log.debug("delFirmPrivilege component Start");
		return this.dao.delFirmPrivilege(strId);
	}
	
	/**
	 * 
	 */
	public List<TraderPrivilege> getTraderPrivilegeList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getTraderPrivilegeList component Start");
		return this.traderDAO_read.getTraderPrivilegeList(qc,pageInfo);
	}
	
	/**
	 * 
	 */
	public TraderPrivilege getTraderPrivilegeById(String strId) {
		this.log.debug("getTraderPrivilegeById component Start");
		return this.traderDAO_read.getTraderPrivilegeById(strId);
	}
	
	/**
	 * 
	 */
	public int addTraderPrivilege(TraderPrivilege params) {
		this.log.debug("addTraderPrivilege component Start");
		return this.dao.addTraderPrivilege(params);
	}

	/**
	 * 
	 */
	public int updTraderPrivilege(TraderPrivilege params) {
		this.log.debug("updTraderPrivilege component Start");
		return this.dao.updTraderPrivilege(params);
	}

	/**
	 * 
	 */
	public int delTraderPrivilege(String strId) {
		this.log.debug("delTraderPrivilege component Start");
		return this.dao.delTraderPrivilege(strId);
	}

	@Override
	public NotTradeDay getNotTradeDay(Integer id) {
		this.log.debug("getNotTradeDay component Start");
		return this.traderDAO_read.getNotTradeDay(id);
	}

	@Override
	public int updateNotTradeDay(NotTradeDay day) {
		this.log.debug("updateNotTradeDay component Start");
		return this.dao.updateNotTradeDay(day);
	}
	
	/**
	 * 
	 */
	public List<ExportEnquiry> getEnquiryList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getEnquiryList component Start");
		return this.traderDAO_read.getEnquiryList(qc, pageInfo);
	}
	
	public List<ExportEnquiryCounter> getCounterList(QueryConditions qc, PageInfo pageInfo){
		this.log.debug("getCounterList component Start");
		return this.dao.getCounterList(qc, pageInfo);
	}

	@Override
	public ExportEnquiry getEnquiryByID(Long enquiryID) {
		this.log.info(this.getClass().getName()+"  getEnquiryByID Component Start");
		ExportEnquiry exportEnquiry = this.traderDAO_read.getEnquiryByID(enquiryID);
		this.log.info(this.getClass().getName()+"  getEnquiryByID Component End");
		return exportEnquiry;
	}
	
	@Override
	public void insertCSRemindRemark(CSRemindRemark remark) {
		this.log.debug("insertCSRemindRemark component Start");
		this.dao.insertCSRemindRemark(remark);
		
	}

	@Override
	public List<CSRemindRemark> selectCSRemindRemarkList(String relationId,
			int remarkType) {
		this.log.debug("selectCSRemindRemarkList component Start");
		return this.traderDAO_read.selectCSRemindRemarkList(relationId, remarkType);
	}
	
	/**
	 * 判断传入日期是否为当前日期
	 * @param date
	 * @return 0：交易日 1：非交易日 -1：判断失败
	 */
	@Override
	public int isTradeDate(Date date) {
		this.log.info("isTradeDate component Start");
		int code = this.judgeDate(date);
		this.log.info("isTradeDate component End");
		return code;
	}

	@Override
	public int countTradeDate(Date startDate, Date endDate) {
		int count = 0;
		this.log.info("countTradeDate component Start");
		if (startDate == null){
			startDate = new Date();
		}
		if (endDate == null){
			endDate = new Date();
		}
		count = countBetweenStartDateAndEndDate(startDate,endDate);
		this.log.info("countTradeDate component End");
		return count;
	}
	
	private int countBetweenStartDateAndEndDate(Date startDate, Date endDate){
		int count = 0;
		String startDateStr = DateUtil.convert(startDate, "yyyy-MM-dd");
		String endDateStr = DateUtil.convert(endDate, "yyyy-MM-dd");
		if (!startDateStr.equals(endDateStr) && startDate.getTime() < endDate.getTime()){
			int resultCode = this.judgeDate(startDate);
			if (resultCode == 0){
				count = countBetweenStartDateAndEndDate(DateUtil.getAddDay(startDate, 1),endDate)+1;
				return count;
			}else{
				count = countBetweenStartDateAndEndDate(DateUtil.getAddDay(startDate, 1),endDate)+0;
				return count;
			}
		}
		else{
			return count;
		}
	}
	
	
	/**
	 * 判断传入日期是否为当前日期
	 * @param date
	 * @return 0：交易日 1：非交易日 -1：判断失败
	 */
	private int judgeDate(Date date){
		int code = 0;
		Date judgeDate = null;// 需要判断的日期
		if (date == null){
			judgeDate = new Date();
		}else{
			judgeDate = date;
		}
		try {
			String judgeDateStr = DateUtil.convert(judgeDate,"yyyy-MM-dd");
			
			// 取得非交易日信息
			NotTradeDay notTradeDay =  this.traderDAO_read.getNotTradeDay(3);
			if (notTradeDay == null ){
				code = -1;
			}else{
				String weekStr = notTradeDay.getWeek(); // 普通的非交易日(1-7代表周日到周六）
				String dayStr = notTradeDay.getDay(); // 所有的非交易日
				
				if (dayStr != null && !"".equals(dayStr)){
					String[] dayArr = dayStr.split(",");
					for (int i = 0; i < dayArr.length; i++ ){
						// 判断日期 是 非交易日
						if (judgeDateStr.equals(dayArr[i]) ){
							code = 1;// 非交易日
							return code;
						}
					}
					
					if (weekStr != null && !"".endsWith(weekStr)){
						String[] weekArr = weekStr.split(",");
						
						for (int j = 0; j < weekArr.length; j++){
							 // 取得 【判断日期】是星期几
							 Calendar calendar = Calendar.getInstance();
							 calendar.setTime(judgeDate);
							 String w = calendar.get(Calendar.DAY_OF_WEEK)+"";
							 if (w.equals(weekArr[j])){
								 code = 1;// 非交易日
								 return code;
							 }
						}
					}
				}
				
				if (weekStr != null && !"".endsWith(weekStr)){
					String[] weekArr = weekStr.split(",");
					
					for (int j = 0; j < weekArr.length; j++){
						 // 取得 【判断日期】是星期几
						 Calendar calendar = Calendar.getInstance();
						 calendar.setTime(judgeDate);
						 String w = calendar.get(Calendar.DAY_OF_WEEK)+"";
						 if (w.equals(weekArr[j])){
							 code = 1;// 非交易日
							 return code;
						 }
					}
				}
			}
		} catch (Exception e) {
			this.log.error("判断日期失败！"+e.getMessage());
			code = -1;
		}
		return code;
	}
	
	/**
	 * 询盘查询（线性-今日挂单中的询盘）
	 */
	public List<EnquiryLiner> getSimpleLinerEnquiryList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getSimpleLinerEnquiryList component Start");
		return this.traderDAO_read.getSimpleLinerEnquiryList(qc, pageInfo);
	}
}
