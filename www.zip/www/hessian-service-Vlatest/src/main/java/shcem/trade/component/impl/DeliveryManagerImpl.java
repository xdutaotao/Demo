package shcem.trade.component.impl;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.json.JSONArray;
import org.json.JSONObject;

import scem.activiti.ActivitiFactory;
import scem.activiti.model.ProcessInstance;
import scem.activiti.model.ProcessInstanceParams;
import scem.activiti.model.Task;
import scem.activiti.model.TaskParams;
import scem.activiti.model.VariableParams;
import scem.drools.DealStatus;
import scem.drools.DealStatusPost;
import scem.drools.DeliveryExpense;
import scem.drools.DeliveryOutParams;
import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.component.ICommonMgr;
import shcem.common.dao.model.ChargesModel;
import shcem.common.service.model.UpAndDownRecord;
import shcem.common.service.model.ValueTxtView;
import shcem.common.util.CommoSys;
import shcem.constant.BusinessEnumConstants;
import shcem.constant.Constants;
import shcem.finance.component.ISApplayManager;
import shcem.finance.component.IVoucherManager;
import shcem.finance.dao.SApplyDAO;
import shcem.finance.util.FinanceSysData;
import shcem.logistics.dao.ILogisticsRateDao;
import shcem.member.service.model.userMobileModel;
import shcem.systemMgr.dao.ISystemMgrDAO;
import shcem.systemMgr.dao.model.MUser;
import shcem.systemMgr.dao.model.UaacUser;
import shcem.trade.ExportModel.Delivery4Export;
import shcem.trade.ExportModel.DeliveryInvoice4Export;
import shcem.trade.component.IDeliveryManager;
import shcem.trade.component.IOrderManager;
import shcem.trade.dao.IDeliveryDAO;
import shcem.trade.dao.OrderDAO;
import shcem.trade.dao.model.BreachContractApply;
import shcem.trade.dao.model.DelDistributionDetail;
import shcem.trade.dao.model.Delivery;
import shcem.trade.dao.model.DeliveryDetail;
import shcem.trade.dao.model.DeliveryFreightFee;
import shcem.trade.dao.model.DeliveryInvoice;
import shcem.trade.dao.model.DeliveryOpeLog;
import shcem.trade.dao.model.ExportDelivery;
import shcem.trade.dao.model.ExportFirmfunds;
import shcem.trade.dao.model.Firmfunds;
import shcem.trade.dao.model.Order;
import shcem.trade.dao.model.OrderSinopec;
import shcem.trade.dao.model.ProcessTask;
import shcem.trade.dao.model.TrasferGoodsDetail;
import shcem.trade.service.model.DeliveryDto;
import shcem.trade.util.BigDecimalUtil;
import shcem.trade.util.DeliveryExpenseUtil;
import shcem.trade.util.TradeSysData;
import shcem.util.Base64Util;
import shcem.util.Common;
import shcem.util.DataUtil;
import shcem.util.JsonUtil;
import shcem.util.PdfUtil;
import shcem.util.PropertyUtil;

public class DeliveryManagerImpl extends BaseManager implements
		IDeliveryManager {
	private IDeliveryDAO deliveryDAO;
	
	private IDeliveryDAO deliveryDAO_read;
	
	
	
	public void setDeliveryDAO_read(IDeliveryDAO deliveryDAO_read) {
		this.deliveryDAO_read = deliveryDAO_read;
	}

	private ISystemMgrDAO systemMgrDAO;
	private SApplyDAO SApplyDAO;
	private ISApplayManager sApplyManagerImpl;

	private ILogisticsRateDao logisticsRateDao;
	
	private ILogisticsRateDao logisticsRateDao_read;

	public void setLogisticsRateDao_read(ILogisticsRateDao logisticsRateDao_read) {
		this.logisticsRateDao_read = logisticsRateDao_read;
	}

	private OrderDAO orderDAO;
	
	private OrderDAO orderDAO_read;
	
	

	public void setOrderDAO_read(OrderDAO orderDAO_read) {
		this.orderDAO_read = orderDAO_read;
	}

	private IVoucherManager voucherMgr = (IVoucherManager) FinanceSysData
			.getBean(Constants.BEAN_VOUCHER_MGR);
	private IOrderManager orderMgr = null;

	private ICommonMgr commonMgr;

	public void setSystemMgrDAO(ISystemMgrDAO systemMgrDAO) {
		this.systemMgrDAO = systemMgrDAO;
	}

	public void setDeliveryDAO(IDeliveryDAO iDeliveryDAO) {
		this.deliveryDAO = iDeliveryDAO;
	}

	public void setOrderDAO(OrderDAO orderDAO) {
		this.orderDAO = orderDAO;
	}

	public void setLogisticsRateDao(ILogisticsRateDao logisticsRateDao) {
		this.logisticsRateDao = logisticsRateDao;
	}

	@Override
	public List<Delivery> getLogisticalDeliveryList(QueryConditions qc,
			PageInfo pageInfo) {
		List<Delivery> list = this.deliveryDAO_read.getLogisticalDeliveryList(qc,
				pageInfo);
		return list;
	}

	@Override
	public List<Delivery> getDeliveryList(QueryConditions qc, PageInfo pageInfo) {
		this.log.info(DeliveryManagerImpl.class
				+ "  Component  getDeliveryList Start");
		List<Delivery> list = this.deliveryDAO_read.getDeliveryList(qc, pageInfo);
		if (list != null && list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				// 前台客户申请的交收没有制单人
				if (list.get(i).getDeliveryStatus() < 5)
					list.get(i).setDocumentMaker("");
				;
			}
		}
		this.log.info(DeliveryManagerImpl.class
				+ "  Component  getDeliveryList End");
		return list;
	}

	/**
	 * 交易详情
	 */
	@Override
	public Delivery getDeliveryDetail(String deliveryID, String userID,
			String mode) throws RuntimeException {
		this.log.info(DeliveryManagerImpl.class
				+ "  getDeliveryDetail Component Start");
		Delivery delivery = this.deliveryDAO_read.getDeliveryDetail(deliveryID);
		if (delivery == null)
			return null;
		// 自提
		if (delivery.getDeliveryType() == 0) {
			DeliveryDetail DeliveryDetail = this.deliveryDAO_read
					.getTDeliveryDetail(deliveryID);
			if (DeliveryDetail != null) {
				this.setDeliveryDetail(delivery, DeliveryDetail);
			}

		}

		/* 配送详情(物流信息、运费) */
		if (delivery.getDeliveryType() == 1) {
			// 物流信息
			DelDistributionDetail delDistributionDetail = this.deliveryDAO_read
					.getDelDistributionDetail(deliveryID);
			if (delDistributionDetail != null) {
				this.setDelDistributionDetail(delivery, delDistributionDetail);
			}
			// 运费
			DeliveryFreightFee deliveryFreightFee = this.deliveryDAO_read.getDeliveryFreightFee(deliveryID);
			if (delDistributionDetail != null) {
				this.setDeliveryFreightFee(delivery, deliveryFreightFee);
			}
			// 交收配送明细表
			DelDistributionDetail delDistributionDetailModel = this.deliveryDAO_read.getDelDistributionDetail(deliveryID);
			if(delDistributionDetailModel != null){
				delivery.setFreightFee(delDistributionDetailModel.getFreightFee());//运费
				delivery.setSmallFee(delDistributionDetailModel.getSmallFee());//小单费
			}
			
		}
		// 转货权
		if (delivery.getDeliveryType() == 2) {
			TrasferGoodsDetail trasferGoodsDetail = this.deliveryDAO_read
					.getTrasferGoodsDetail(deliveryID);
			if (trasferGoodsDetail != null) {
				this.setTrasferGoodsDetail(delivery, trasferGoodsDetail);
			}
		}
		// 已上传文件个数
		int receiptFileNum = 0;
		List<Order> orderList = this.deliveryDAO_read.getOrderFile(delivery
				.getOrderID());
		if (orderList != null) {
			receiptFileNum = orderList.size();
		}
		delivery.setReceiptFileNum(receiptFileNum);

		// 交易手续费
		Order order = this.deliveryDAO_read.getOrderByDeliveryID(deliveryID);
		commonMgr = (ICommonMgr) CommoSys.getBean(Constants.BEAN_COMMON_MGR);

		String sellFirmId = order.getSellFirmId();
		String buyFirmId = order.getSellFirmId();
		String tmplID = order.getTradeTmptId() + "";
		Integer cateID = order.getCategoryLeafID();
		Integer brandID = order.getBrandID();
		// 交易方向 0卖 1买
		Integer tradeRole = 0;
		BigDecimal price = order.getPrice();
		// 交易数量
		BigDecimal quantity = new BigDecimal(1);
		BigDecimal tradeUnitNumber = order.getTradeUnitNumber();

		// 卖家
		ChargesModel cm_seller = new ChargesModel();
		cm_seller = commonMgr.getChargesByFirmID(sellFirmId, tmplID, cateID,
				brandID, tradeRole, price, quantity, tradeUnitNumber);
		delivery.setSellFee(cm_seller.getFee());
		// 买家
		ChargesModel cm_buyer = new ChargesModel();
		tradeRole = 1;
		cm_buyer = commonMgr.getChargesByFirmID(buyFirmId, tmplID, cateID,
				brandID, tradeRole, price, quantity, tradeUnitNumber);
		delivery.setBuyFee(cm_buyer.getFee());

		// 买家申请单
		delivery.setNextApplyID(delivery.getDeliveryAttID());

		this.log.info(DeliveryManagerImpl.class
				+ "  getDeliveryDetail Component End");
		return delivery;
	}

	private void setDeliveryFreightFee(Delivery delivery,
			DeliveryFreightFee deliveryFreightFee) {
		/* 买家应付运费 */
		delivery.setBuyShouldPayFreight(deliveryFreightFee
				.getBuyShouldPayFreight());

		/* 买家已付运费 */
		delivery.setBuyPaidFreight(deliveryFreightFee.getBuyPaidFreight());

		/* 买家已付运费时间 */
		delivery.setBuyPaidTime(deliveryFreightFee.getBuyPaidTime());

		/* 买家已付操作人 */
		delivery.setBuyPaidBY(deliveryFreightFee.getBuyPaidBY());

		/* 应付卖家运费 */
		delivery.setShouldPaySellFreight(deliveryFreightFee
				.getShouldPaySellFreight());

		/* 已付卖家运费 */
		delivery.setPaidSellFreight(deliveryFreightFee.getPaidSellFreight());

		/* 已付卖家运费时间 */
		delivery.setPaidSellFreightTime(deliveryFreightFee
				.getPaidSellFreightTime());

		/* 已付卖家运费操作人 */
		delivery.setPaidSellFreightBY(deliveryFreightFee.getPaidSellFreightBY());

	}

	/**
	 * 配送信息
	 * 
	 * @param delivery
	 * @param deliveryFreightFee
	 */
	private void setDelDistributionDetail(Delivery delivery,
			DelDistributionDetail delDistributionDetail) {
		/* 物流区域LeafID */
		delivery.setLogisticsLeafID(delDistributionDetail.getLogisticsLeafID());

		/* 物流区域名称 */
		delivery.setLogiisticsName(delDistributionDetail.getLogiisticsName());

		/* 配送地址 */
		delivery.setAddressDetail(delDistributionDetail.getAddressDetail());

		/* 运费 */
		delivery.setFreightFee(delDistributionDetail.getFreightFee());

		/* 小单费 */
		delivery.setSmallFee(delDistributionDetail.getSmallFee());

		/* 联系人手机 */
		delivery.setContactMobile(delDistributionDetail.getContactMobile());

		/* 联系人电话 */
		delivery.setContactTel(delDistributionDetail.getContactTel());

		/* 联系人 */
		delivery.setContactName(delDistributionDetail.getContactName());

		/* 配送备注信息 */
		delivery.setLogisticsRemark(delDistributionDetail.getRemark());

		/* 配送省ID-省区ID-市区ID */
		// 省区
		ValueTxtView valueTxtView = this.logisticsRateDao_read
				.getParentAreaByJuniorID(delDistributionDetail
						.getLogisticsLeafID());
		try {
			delivery.setSecondAreaID(valueTxtView.getTagID());
		} catch (Exception e) {
			this.log.error(this.getClass().getName()
					+ " setDelDistributionDetail 没有对应的配送二级区域：" + e.getMessage());
			e.printStackTrace();
		}

		if (valueTxtView != null) {
			// 省份
			ValueTxtView valueTxtViewProvice = this.logisticsRateDao_read
					.getParentAreaByJuniorID(valueTxtView.getTagID());
			try {
				delivery.setFirstAreaID(valueTxtViewProvice.getTagID());
			} catch (Exception e) {
				this.log.error(this.getClass().getName()
						+ " setDelDistributionDetail 没有对应的配送一级区域："
						+ e.getMessage());
				e.printStackTrace();
			}
		}
	}

	/**
	 * 处理完成（履约/违约） returnCode： 1:成功 0:卖家账户余额不足 -1 :老专场不存在这样的model -2
	 * :快捷创建凭证失败！(老) -3 :凭证审核失败！请确认摘要与科目是否正确。(老) -4 :凭证审核失败！造成201余额为负值。(老) -5
	 * :凭证审核失败！(老) -6 :快捷创建凭证失败！(新) -7 :凭证审核失败！请确认摘要与科目是否正确。(新) -8
	 * :凭证审核失败！造成201余额为负值。(新) -9 :凭证审核失败！(新) -10:买方 已收<应收 -11:卖方 已付<应付
	 */
	@Override
	public int handleDelivery(String deliveryID, String userID) {
		this.log.info(DeliveryManagerImpl.class
				+ "  handleDelivery Component Start");
		MUser user = this.getUserByLoginName(userID);
		// 处理完成两种情况：履约和违约
		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryID);
		delivery.setREC_MODIFYBY(user.getName());
		int processStatus = delivery.getProcessStatus();
		Order order = this.deliveryDAO.getOrderByDeliveryID(deliveryID);
		BigDecimal allmoney = new BigDecimal(0);

		int row;
		int returnCode = 1;
		/**
		 * 处理完成：履约情况 1） 买方：已收>=应收，卖方：已付>=应付 2） 退买方：已收-应收的差额，收卖方已付-应付的差额。 3）
		 * 若此时卖方系统中的资金不足以支付差额，则事务做同步失败处理。
		 */
		if (processStatus == 0) {
			// 履约处理完成 ，更新订单“已签收数量（批）SignQuantity”
			updateOrderSignQuantity(delivery.getTakenQuantity(),
					order.getOrderId(), user);

			// 处理完成时 "卖方保证金" 同时退回
			returnCode = releaseCreditMoneyForSeller(deliveryID, userID);
			if (returnCode != 1)
				return returnCode;

			// 应收货款
			allmoney = delivery.getMoney().add(delivery.getOverloadFee());
			// 已收货款
			BigDecimal payedMoney = delivery.getPayedMoney();
			// 已付货款
			BigDecimal takenMoney = delivery.getTakenMoney();

			// 处理状态 已经处理
			// 买方
			if (payedMoney.compareTo(allmoney) > 0
					&& takenMoney.compareTo(allmoney) > 0) {
				// 退买家多收货款
				row = this.voucherMgr.createNewOldVoucher(
						Constants.VOUCHERMODE_FU_HUO_KUAN,
						takenMoney.subtract(allmoney), order.getOrderId(),
						order.getBuyFirmId(), "处理完成-退买家货款", user.getName());
				if (row >= 0) {
					// 更新已收货款
					this.deliveryDAO.updateDeliveryTakenMoney(allmoney,
							user.getName(), deliveryID);
					returnCode = 1;
				} else {
					this.rollBack();
					returnCode = row;
				}
			} else if (payedMoney.compareTo(allmoney) == 0
					&& takenMoney.compareTo(allmoney) == 0) {
				returnCode = 1;
			} else {
				returnCode = -10;
			}
			// 卖方
			if (delivery.getTakenMoney().compareTo(allmoney) > 0
					&& delivery.getPayedMoney().compareTo(allmoney) > 0) {
				// 已付>应付 补足差额 首先判断卖家账户余额
				Firmfunds firmfunds = this.deliveryDAO
						.getSellFirmfundsByDeliveryID(deliveryID);
				if (delivery.getPayedMoney().subtract(delivery.getMoney())
						.compareTo(firmfunds.getBALANCE()) < 0) {
					// 收卖家货款，补足差额
					row = this.voucherMgr.createNewOldVoucher(
							Constants.VOUCHERMODE_SHOU_HUO_KUAN,
							payedMoney.subtract(allmoney), order.getOrderId(),
							order.getSellFirmId(), "处理完成-收卖家货款补足差额",
							user.getName());
					if (row >= 0) {
						// 更新已付货款
						this.deliveryDAO.updatePayedMoney(allmoney,
								user.getName(), deliveryID);
						returnCode = 1;
					} else {
						this.rollBack();
						returnCode = row;
					}
				} else {
					// 卖家账户余额不足
					returnCode = 0;
				}
			} else if (payedMoney.compareTo(allmoney) == 0
					&& takenMoney.compareTo(allmoney) == 0) {
				returnCode = 1;
			} else {
				returnCode = -10;
			}
			if (returnCode >= 0) {
				// 更新状态 交收履约处理完成
				this.deliveryDAO.finishProcessStatus(2, deliveryID);
			}
		}
		/**
		 * 处理完成：违约情况 退保证金给双方，再收取不大于原先保证金的违约金
		 */
		else if(processStatus == 1){
			// 卖方
			// 违约处理完成
			delivery.setViolationStatus(1);
			// 卖方交收已收保证金
			if (delivery.getSellTakenSSDeposit().compareTo(new BigDecimal(0)) > 0) {
				row = this.voucherMgr.createNewOldVoucher(
						Constants.VOUCHERMODE_TUI_BAOZHENGJIN,
						delivery.getSellTakenSSDeposit(), order.getOrderId(),
						order.getSellFirmId(), "违约处理-退保证金给卖方", user.getName());
				if (row >= 0) {
					// 收卖方违约金
					/**
					 * 卖方交收应扣违约金:SellPenalty
					 * 
					 * 卖方交收已扣违约金:TakenSellPenalty
					 */
					row = this.voucherMgr.createNewOldVoucher(
							Constants.VOUCHERMODE_SHOU_WEIYUEJIN,
							delivery.getSellPenalty(), order.getOrderId(),
							order.getSellFirmId(), "违约处理-收卖方违约金",
							user.getName());
					if (row >= 0) {
						// 卖方交收已收保证金
						delivery.setSellTakenSSDeposit(new BigDecimal(0));
						// 卖方交收已扣违约金
						delivery.setTakenSellPenalty(delivery.getSellPenalty());
						// 更新 卖方交收已收保证金 卖方交收已扣违约金
						this.deliveryDAO
								.updateSellTakenSSDepositAndTakenSellPenalty(delivery);
					} else {
						this.rollBack();
						returnCode = row;
					}
				} else {
					this.rollBack();
					returnCode = row;
				}
			}
			// 买方交收已扣保证金
			if (delivery.getTakenBSDeposit().compareTo(new BigDecimal(0)) > 0) {
				row = this.voucherMgr.createNewOldVoucher(
						Constants.VOUCHERMODE_TUI_BAOZHENGJIN,
						delivery.getTakenBSDeposit(), order.getOrderId(),
						order.getBuyFirmId(), "违约处理-退保证金给买方", user.getName());
				if (row >= 0) {
					// 收买方违约金
					/**
					 * 买方交收应扣违约金:BuyPenalty
					 * 
					 * 买方交收已扣违约金:TakenBuyPenalty
					 */
					row = this.voucherMgr
							.createNewOldVoucher(
									Constants.VOUCHERMODE_SHOU_WEIYUEJIN,
									delivery.getBuyPenalty(),
									order.getOrderId(), order.getBuyFirmId(),
									"违约处理-收买方违约金", user.getName());
					if (row >= 0) {
						// 买方交收已扣保证金
						delivery.setTakenBSDeposit(new BigDecimal(0));
						// 买方交收已扣违约金
						delivery.setTakenBuyPenalty(delivery.getBuyPenalty());
						// 更新 买方交收已扣保证金 买方交收已扣违约金
						this.deliveryDAO
								.updateTakenBSDepositAndTakenBuyPenalty(delivery);
					} else {
						this.rollBack();
						returnCode = row;
					}
				} else {
					this.rollBack();
					returnCode = row;
				}
			}
			if (returnCode >= 0) {
				// 更新状态 违约处理完成
				this.deliveryDAO.finishDelivery(3, 1, deliveryID);
			}
		}
		this.log.info(DeliveryManagerImpl.class
				+ "  handleDelivery Component End");
		return returnCode;
	}

	@Override
	public List<DeliveryOpeLog> getDeliveryOpeLogList(String deliveryID) {
		this.log.info(DeliveryManagerImpl.class
				+ "  getDeliveryOpeLogList Component Start");
		return this.deliveryDAO_read.getDeliveryOpeLogList(deliveryID);
	}

	/**
	 * 交收业务日志
	 * 
	 * @return
	 */
	private void addDeliveryOpeLog(DeliveryOpeLog deliveryOpeLog) {
		this.log.info(DeliveryManagerImpl.class
				+ "  addDeliveryOpeLog Component Start");
		this.deliveryDAO.addDeliveryOpeLog(deliveryOpeLog);
	}

	public void addDeliveryOpeLog(String deliveryID, String userID,
			String opeContent, String setOpeComment) {
		this.log.debug(this.getClass().getName() + "addDeliveryOpeLog Start");
		this.log.info(DeliveryManagerImpl.class
				+ "  addDeliveryOpeLog Component Start");
		DeliveryOpeLog deliveryOpeLog = new DeliveryOpeLog();

		deliveryOpeLog.setDeliveryID(deliveryID);
		deliveryOpeLog.setUserID(userID);
		deliveryOpeLog.setOpeContent(opeContent);
		deliveryOpeLog.setOpeComment(setOpeComment);
		this.addDeliveryOpeLog(deliveryOpeLog);
		this.log.debug(this.getClass().getName() + "addDeliveryOpeLog  End");
	}

	/**
	 * 付卖方货款 returnCode 1:付卖方货款成功 0:所付卖方货款大于余下应付货款 -1 :老专场不存在这样的model -2
	 * :快捷创建凭证失败！(老) -3 :凭证审核失败！请确认摘要与科目是否正确。(老) -4 :凭证审核失败！造成201余额为负值。(老) -5
	 * :凭证审核失败！(老) -6 :快捷创建凭证失败！(新) -7 :凭证审核失败！请确认摘要与科目是否正确。(新) -8
	 * :凭证审核失败！造成201余额为负值。(新) -9 :凭证审核失败！(新)
	 */
	@Override
	public int paySellerMoney(String deliveryID, BigDecimal money,
			String userID, boolean isCheck, String orderID)
			throws RuntimeException {
		this.log.info(DeliveryManagerImpl.class
				+ "  paySellerMoney Component Start");
		MUser user = this.systemMgrDAO.getUserByLoginName(userID);
		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryID);
		int row = 0;
		int returnCode = 1;
		// 差额
		BigDecimal discrepancy = delivery.getMoney()
				.add(delivery.getOverloadFee())
				.subtract(delivery.getPayedMoney());
		// 成交单 补足授信资金 是否一次性收费补足！
		if (isCheck) {
			returnCode = this.takeSettleFeeForOrderSeller(orderID, userID);
		}
		// 应付卖方总金额
		if (discrepancy.compareTo(money) >= 0) {
			// 生成凭证流水
			Order order = this.deliveryDAO.getOrderByDeliveryID(deliveryID);
			String oprFlag = "";
			String oprString = "";
			if (money.compareTo(new BigDecimal(0)) >= 0) {
				oprFlag = Constants.VOUCHERMODE_FU_HUO_KUAN;
				oprString = "付交易商货款";
			} else {
				oprFlag = Constants.VOUCHERMODE_SHOU_HUO_KUAN;
				oprString = "收交易商货款";
			}
			row = this.voucherMgr.createNewOldVoucher(oprFlag, money.abs(),
					deliveryID, order.getSellFirmId(), oprString,
					user.getName());
			/**
			 * 付卖方货款，入金操作，不关心资金来源，后续会计人员做资金流水处理
			 * 
			 * 已付货款 :PayedMoney
			 */
			this.deliveryDAO.paySellerMoney(deliveryID, delivery
					.getPayedMoney().add(money), user);
			if (row >= 0) {
				returnCode = 1;
			} else {
				this.rollBack();
				returnCode = row;
			}
		} else {
			returnCode = 0;
		}
		this.log.info(DeliveryManagerImpl.class
				+ "  paySellerMoney Component End");
		return returnCode;
	}

	/**
	 * 收买方货款 returnCode: 1:收买方货款成功 0:买方交易商账户余额不足 2:应扣买方交易商货款大于应收货款 -1
	 * :老专场不存在这样的model -2 :快捷创建凭证失败！(老) -3 :凭证审核失败！请确认摘要与科目是否正确。(老) -4
	 * :凭证审核失败！造成201余额为负值。(老) -5 :凭证审核失败！(老) -6 :快捷创建凭证失败！(新) -7
	 * :凭证审核失败！请确认摘要与科目是否正确。(新) -8 :凭证审核失败！造成201余额为负值。(新) -9 :凭证审核失败！(新)
	 */
	@Override
	public int takeBuyerMoney(String deliveryID, BigDecimal money, String userID)
			throws RuntimeException {
		this.log.info(DeliveryManagerImpl.class
				+ "  takeBuyerMoney Component Start");

		MUser user = this.systemMgrDAO.getUserByLoginName(userID);

		Firmfunds firmfunds = this.deliveryDAO
				.getFirmfundsByDeliveryID(deliveryID);
		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryID);

		// 差额
		BigDecimal discrepancy = delivery.getMoney()
				.add(delivery.getOverloadFee())
				.subtract(delivery.getTakenMoney());

		int row = 0;
		int returnCode = -10;
		// 校验扣款金额是否大于应扣金额
		if (discrepancy.compareTo(money) >= 0) {
			// 校验交易商买家账户余额是否充足
			if (firmfunds.getBALANCE().compareTo(money) >= 0) {
				Order order = this.deliveryDAO.getOrderByDeliveryID(deliveryID);
				String oprFlag = "";
				String oprString = "";
				if (money.compareTo(new BigDecimal(0)) >= 0) {
					oprFlag = Constants.VOUCHERMODE_SHOU_HUO_KUAN;
					oprString = "收交易商货款";
				} else {
					oprFlag = Constants.VOUCHERMODE_FU_HUO_KUAN;
					oprString = "退交易商货款";
				}
				row = this.voucherMgr.createNewOldVoucher(oprFlag, money.abs(),
						deliveryID, order.getBuyFirmId(), oprString,
						user.getName());

				// 已付货款
				if (row >= 0) {
					// 更新已收货款
					this.deliveryDAO.updateDeliveryTakenMoney(delivery
							.getTakenMoney().add(money), user.getName(),
							deliveryID);
					returnCode = 1;
				} else {
					this.rollBack();
					returnCode = row;
				}
			} else {
				// 买方交易商账户余额不足
				returnCode = 0;
			}
		} else {
			// 应扣买方交易商货款大于应收货款
			returnCode = 2;
		}
		this.log.info(DeliveryManagerImpl.class
				+ "  takeBuyerMoney Component End");
		return returnCode;
	}

	@Override
	public MUser getUserByLoginName(String userID) {
		this.log.info(DeliveryManagerImpl.class
				+ "  getUserByLoginName Component Start");
		return this.systemMgrDAO.getUserByLoginName(userID);
	}

	@Override
	public Order getOrderByDeliveryID(String deliveryID) {
		this.log.info(DeliveryManagerImpl.class
				+ "  getOrderByDeliveryID Component Start");
		return this.deliveryDAO.getOrderByDeliveryID(deliveryID);
	}

	/**
	 * 释放卖方保证金 扣卖方账户补足差额(交收单)
	 */
	@Override
	public int releaseCreditMoneyForSeller(String deliveryID, String userID)
			throws RuntimeException {
		this.log.info(DeliveryManagerImpl.class
				+ " Component  releaseCreditMoneyForSeller Start");
		MUser user = this.systemMgrDAO.getUserByLoginName(userID);
		Order order = this.deliveryDAO.getOrderByDeliveryID(deliveryID);
		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryID);
		delivery.setREC_MODIFYBY(user.getName());
		int row;
		int returnCode = 1;
		// 要释放的保证金
		BigDecimal releaseSellCreditDeposit = delivery.getSellCreditDeposit();
		if (delivery.getSellCreditDeposit().compareTo(new BigDecimal(0)) > 0) {
			try {
				sApplyManagerImpl = (ISApplayManager) FinanceSysData
						.getBean(Constants.BEAN_SAPPLYMGR_MGR);
				/**
				 * 更新交收授信金额
				 */
				delivery.setSellCreditDeposit(new BigDecimal(0));
				this.deliveryDAO
						.updateSellTakenSSDepositAndSellCreditDeposit(delivery);

				/**
				 * 授信流水
				 */
				sApplyManagerImpl.backSettleMargin(order.getSellFirmId(),
						releaseSellCreditDeposit, deliveryID, 5);
				returnCode = 1;

			} catch (Exception e) {
				this.rollBack();
				returnCode = -10;
			}
		} else {
			returnCode = 1;
		}
		// 释放实体资金（卖方交收保证金） 退保证金给卖家
		if (delivery.getSellTakenSSDeposit().compareTo(new BigDecimal(0)) > 0) {
			row = this.voucherMgr.createNewOldVoucher(
					Constants.VOUCHERMODE_TUI_JIAOSHOU_BAOZHENGJING,
					delivery.getSellTakenSSDeposit(), deliveryID,
					order.getSellFirmId(), "退卖方交收保证金", user.getName());
			if (row >= 0) {
				/**
				 * 更新交收单: 1)重新设置卖方交收已收保证金（SellTakenSSDeposit）为 0
				 */
				delivery.setSellTakenSSDeposit(new BigDecimal(0));
				delivery.setSellCreditDeposit(new BigDecimal(0));
				this.deliveryDAO
						.updateSellTakenSSDepositAndSellCreditDeposit(delivery);
				returnCode = 1;
			} else {
				this.rollBack();
				returnCode = row;
			}
		}
		this.log.info(DeliveryManagerImpl.class
				+ "  releaseCreditMoneyForSeller Component End");
		return returnCode;
	}

	/**
	 * 释放卖方保证金 扣卖方账户补足差额(订单)
	 */
	@Override
	public int releaseCreditMoneyForSellerByOrderID(String orderId,
			String userID) throws RuntimeException {
		this.log.info(this.getClass().getName()
				+ " Component  releaseCreditMoneyForSellerByOrderID Start");
		boolean flag = false;
		Order orderDB = null;
		MUser user = this.systemMgrDAO.getUserByLoginName(userID);
		try {
			orderDB = this.orderDAO.getOrderByOrderID(orderId);
			if (orderDB == null) {
				this.log.error(this.getClass().getName()
						+ " Component  查询订单信息为NULL，orderID：" + orderId);
				return -1;
			}
			// 订单状态非已付款时
			if (10 != orderDB.getPaymentStatus()) {
				return -2;
			}
		} catch (Exception e) {
			this.log.error(" Component  查询订单信息失败，orderID：" + orderId);
			this.log.error(e.getMessage());
			return -1;
		}
		// 授信类型，0：现货 1：预售
		Integer goodsType = Common.getGoodsType(orderDB.getTradeType());
		
		// 卖方交易已收保证金
		BigDecimal sellTakenTradeDeposit = orderDB.getSellTakenTradeDeposit();
		// 卖方交易保证金授信
		BigDecimal sellCreditDeposit = orderDB.getSellCreditDeposit();
		// 卖方交易商ID
		String sellFirmId = orderDB.getSellFirmId();

		// 要释放的保证金
		if (sellCreditDeposit.compareTo(new BigDecimal(0)) > 0) {
			try {
				sApplyManagerImpl = (ISApplayManager) FinanceSysData
						.getBean(Constants.BEAN_SAPPLYMGR_MGR);
				/**
				 * 更新订单授信金额（SellCreditDeposit）为0
				 */
				// sellCreditDeposit = new BigDecimal(0);
				int count = this.orderDAO.updateOrderSellerDepositByOrderId(
						orderId, userID, sellTakenTradeDeposit, new BigDecimal(
								0));
				flag = true;
				if (count == 1) {
					if (goodsType == 1) {
						// 预售
						sApplyManagerImpl.backMarginForPreSale(sellFirmId,
								sellCreditDeposit, orderId, 4);
					} else {
						// 现货
						sApplyManagerImpl.backMargin(sellFirmId,
								sellCreditDeposit, orderId, 4);
					}
				} else {
					this.log.info(this.getClass().getName() + "根据OrderID："
							+ orderId + " 未更新成功成交单信息。");
				}
			} catch (Exception e) {
				this.log.error(" Component  释放的授信保证金失败，orderID：" + orderId);
				this.log.error(e.getMessage());
				this.rollBack();
				return -1;
			}
		}
		// 释放实体资金（卖方交收保证金） 退保证金给卖家
		if (sellTakenTradeDeposit.compareTo(new BigDecimal(0)) > 0) {
			try {
				/**
				 * 更新成交单:重新设置卖方交收已收保证金（SellTakenSSDeposit）为 0
				 */
				if (flag) {
					sellCreditDeposit = new BigDecimal(0);
				}
				// sellTakenTradeDeposit = new BigDecimal(0);
				int count = this.orderDAO.updateOrderSellerDepositByOrderId(
						orderId, userID, new BigDecimal(0), sellCreditDeposit);
				if (count == 1) {

					int code = this.voucherMgr.createNewOldVoucher(
							Constants.VOUCHERMODE_TUI_JIAOSHOU_BAOZHENGJING,
							sellTakenTradeDeposit, orderId, sellFirmId,
							"退卖方成交单保证金", user.getName());
					if (code < 0) {
						this.log.error("Component  退卖方成交单保证金异常，CODE：" + code);
					}
				} else {
					this.log.info(this.getClass().getName() + "根据OrderID："
							+ orderId + " 未更新成功成交单信息。");
				}
			} catch (Exception e) {
				this.rollBack();
				this.log.error("Component  释放的授信保证金失败，orderID：" + orderId);
				this.log.error(e.getMessage());
				return -1;
			}

		}
		this.log.info(this.getClass().getName()
				+ "  releaseCreditMoneyForSellerByOrderID Component End");
		return 1;
	}

	/**
	 * 退款（保证金）给买方 returnCode: 1:收货款 -1 :老专场不存在这样的model -2 :快捷创建凭证失败！(老) -3
	 * :凭证审核失败！请确认摘要与科目是否正确。(老) -4 :凭证审核失败！造成201余额为负值。(老) -5 :凭证审核失败！(老) -6
	 * :快捷创建凭证失败！(新) -7 :凭证审核失败！请确认摘要与科目是否正确。(新) -8 :凭证审核失败！造成201余额为负值。(新) -9
	 * :凭证审核失败！(新) -10:买方余额不足 -11:退保证金给买方失败
	 */
	@Override
	public int refundForBuyFirm(String deliveryID, String userID,
			BigDecimal money) throws RuntimeException {
		this.log.info(DeliveryManagerImpl.class
				+ "  refundForBuyFirm Component Start");
		MUser user = this.systemMgrDAO.getUserByLoginName(userID);
		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryID);
		int row;
		int returnCode = -1;
		if (delivery.getTakenBSDeposit().compareTo(money) >= 0) {
			// 交收记录 交收已扣保证金 更新
			delivery.setTakenBSDeposit(delivery.getTakenBSDeposit().subtract(
					money));
			delivery.setREC_MODIFYBY(user.getName());
			this.deliveryDAO.updateTakenBSDeposit(delivery);
			Order order = this.deliveryDAO.getOrderByDeliveryID(deliveryID);
			row = this.voucherMgr
					.createNewOldVoucher(
							Constants.VOUCHERMODE_TUI_JIAOSHOU_BAOZHENGJING,
							money, deliveryID, order.getBuyFirmId(), "退保证金给买方",
							user.getName());
			if (row >= 0) {
				// 收买方货款
				row = this.voucherMgr.createNewOldVoucher(
						Constants.VOUCHERMODE_SHOU_HUO_KUAN, money, deliveryID,
						order.getBuyFirmId(), "收买方货款", user.getName());
				// 已付货款
				this.deliveryDAO.takeBuyerMoney(deliveryID, delivery
						.getTakenMoney().add(money), user);
				if (row >= 0) {
					returnCode = 1;
				} else {
					this.rollBack();
					returnCode = row;
				}
			} else {
				/**
				 * 退保证金给买方失败
				 */
				this.rollBack();
				returnCode = -11;
			}

		} else {
			// 买方保证金不足
			returnCode = -10;
		}
		this.log.info(DeliveryManagerImpl.class
				+ "  refundForBuyFirm Component End");
		return returnCode;
	}

	/**
	 * 收卖方违约金：记录设定值，风控审核通过再扣除 卖方交收已收保证金（SellTakenSSDeposit）
	 */
	@Override
	public int takePenaltyMoneyForSeller(String deliveryID, BigDecimal money,
			String userName) throws RuntimeException {
		this.log.info(DeliveryManagerImpl.class
				+ "  takePenaltyMoneyForSeller Component Start");
		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryID);
		delivery.setREC_MODIFYBY(userName);
		int returnCode = 0;
		returnCode = this.deliveryDAO.updateSellPenalty(money, userName,
				deliveryID);

		// // 卖方交收应扣违约金(TakenSellPenalty) 不能大于 卖方交收已收保证金（SellTakenSSDeposit）
		// if (money.compareTo(delivery.getSellTakenSSDeposit()) <= 0) {
		// delivery.setSellPenalty(money);
		// // 更新卖方交收应扣违约金(TakenSellPenalty)
		// this.deliveryDAO.updateSellPenalty(delivery);
		// returnCode = 1;
		// } else {
		// // 卖方交收应扣违约金(TakenSellPenalty) 不能大于 卖方交收已收保证金（SellTakenSSDeposit）
		// returnCode = 0;
		// }
		this.log.info(DeliveryManagerImpl.class
				+ "  takePenaltyMoneyForSeller Component End");
		return returnCode;
	}

	/**
	 * 收买方违约金 ：记录设定值，风控审核通过再扣除 买方交收已扣保证金（TakenBSDeposit）
	 */
	@Override
	public int takePenaltyMoneyForBuyer(String deliveryID, String userName,
			BigDecimal money) {
		this.log.info(DeliveryManagerImpl.class
				+ "  takePenaltyMoneyForBuyer Component Start");

		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryID);
		delivery.setREC_MODIFYBY(userName);
		int returnCode = -10;
		returnCode = this.deliveryDAO.updateBuyPenalty(money, userName,
				deliveryID);
		// // 买方交收应扣违约金（BuyPenalty） 不能大于 买方交收已扣保证金（TakenBSDeposit）
		// if (money.compareTo(delivery.getTakenBSDeposit()) <= 0) {
		// delivery.setBuyPenalty(money);
		// // 更新买方交收应扣违约金(BuyPenalty)
		// this.deliveryDAO.updateBuyPenalty(delivery);
		// returnCode = 1;
		// } else {
		// returnCode = -1;
		// }
		// this.log.info(DeliveryManagerImpl.class
		// + "  takePenaltyMoneyForBuyer Component End");

		return returnCode;
	}

	/**
	 * 物流部门 调整实发货数量，调整溢短金额(升贴水)
	 */
	@Override
	public int adJustTakenQuantity(String deliveryID, String userName,
			BigDecimal takenQuantity, String deliveryComment, String taskID,
			String mode, String userID, int deliveryOrderFileID)
			throws RuntimeException {
		this.log.info(DeliveryManagerImpl.class
				+ "  adJustTakenQuantity Component Start");

		int returnCode = 0;
		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryID);
		Order order = this.deliveryDAO.getOrderByDeliveryID(deliveryID);

		// 申请交收数量
		BigDecimal deliveryQuantity = order.getTradeUnitNumber().multiply(
				new BigDecimal(delivery.getDeliveryQuantity()));
		deliveryQuantity = BigDecimalUtil.getBigDecimalNum(deliveryQuantity, 6);
		// 实际签收数量
		takenQuantity = BigDecimalUtil.getBigDecimalNum(takenQuantity, 6);

		// 溢短金额
		BigDecimal overloadFee = takenQuantity.subtract(deliveryQuantity)
				.multiply(order.getPrice());

		overloadFee = BigDecimalUtil.getBigDecimalNum(overloadFee, 2);

		this.deliveryDAO.adJustTakenQuantity(deliveryComment, takenQuantity,
				deliveryID, userName, overloadFee);

		// 订单状态 没有溢短 交收直接处理完成
		if (deliveryQuantity.compareTo(takenQuantity) <= 0) {

			// 卖家保证金/授信，该退就退，该释放就释放
			returnCode = this.refundment(order, delivery, userName,
					Common.getGoodsType(order.getTradeType()));
			if (returnCode < 0) {
				this.rollBack();
				return returnCode;
			}

			returnCode = this.deliveryDAO.updateDeliveryOrderFileID(
					deliveryOrderFileID, 55, deliveryID, userName);
			// this.deliveryDAO.updateDeliveryStatus(55, deliveryID, userName);
			if (returnCode == -1)
				return returnCode;

			returnCode = this.updateOrderTradeStatus(order.getOrderId(), mode,
					delivery.getDeliveryType());
			if (returnCode == -1)
				return returnCode;
			// String statusConditions = "(50,55,60,65)";
			// boolean flag = this.compareDeliveryStatus(order.getOrderId(),
			// statusConditions);
			// if (flag) {
			// this.deliveryDAO.finishedOrder(Integer.valueOf(50),
			// order.getOrderId());
			// }
			List<VariableParams> variables = new ArrayList<VariableParams>();

			// 不存在溢短 ，流程直接结束
			VariableParams shortOverflow = new VariableParams();
			shortOverflow.setName("shortOverflow");
			shortOverflow.setValue(0);
			variables.add(shortOverflow);

			JSONObject rtnJso = this.completeTask(variables, mode, userID,
					taskID);
			String resultCode = rtnJso.getString("CODE");
			if (!resultCode.equals("OK")) {
				this.rollBack();
				returnCode = -1;
			}
		}

		// 产生溢短
		if (deliveryQuantity.compareTo(takenQuantity) > 0) {
			returnCode = this.deliveryDAO.updateDeliveryOrderFileID(
					deliveryOrderFileID, 35, deliveryID, userName);
			if (returnCode == -1)
				return returnCode;

			returnCode = this.updateOrderTradeStatus(order.getOrderId(), mode,
					delivery.getDeliveryType());
			if (returnCode == -1)
				return returnCode;

			// String statusConditions = "(35,40,50,55,60,65)";
			// boolean flag = compareDeliveryStatus(order.getOrderId(),
			// statusConditions);
			// if (flag) {
			// this.deliveryDAO.finishedOrder(Integer.valueOf(30),
			// order.getOrderId());
			// }
			/**
			 * 调整溢短进入下一流程节点
			 */

			List<VariableParams> variables = new ArrayList<VariableParams>();

			// 认领任务
			JSONObject rtnJso = claimTask(taskID, userID, mode, userID);
			String resultCode = rtnJso.getString("CODE");
			if (resultCode.equals("OK")) {
				// 是否溢短
				VariableParams shortOverflow = new VariableParams();
				shortOverflow.setName("shortOverflow");
				shortOverflow.setValue(1);
				variables.add(shortOverflow);

				// 调整溢短的同时，指定下一个任务节点的操作人员(风控审核人员)
				VariableParams riskDeptVerify = new VariableParams();
				riskDeptVerify.setName("riskDeptVerify");
				String roleCodes = BusinessEnumConstants.RoleType.ControlAuditRoleCode
						.getValue();
				riskDeptVerify.setValue(this.getUser(roleCodes));
				variables.add(riskDeptVerify);

				rtnJso = this.completeTask(variables, mode, userID, taskID);
				resultCode = rtnJso.getString("CODE");
				if (!resultCode.equals("OK")) {
					this.rollBack();
					returnCode = -1;
				} else {
					// 推送消息
					Integer[] userIds = this.getUserID(roleCodes);
					returnCode = this.pushMessage(mode, userIds, userID,
							"请物流操作人员查看审核商城客户提交的交收申请",
							"app.deliveryDetail.riskControl", deliveryID);
					if (returnCode == -1) {
						this.rollBack();
						return returnCode;
					}
				}
			}
		}
		this.log.info(DeliveryManagerImpl.class
				+ "  adJustTakenQuantity Component End");
		return returnCode;
	}

	/**
	 * 风控部门 调整溢短金额
	 */
	@Override
	public int adJustOverLoadMoney(String deliveryID, String userName,
			BigDecimal money, String mode, String userID) {
		this.log.info(DeliveryManagerImpl.class
				+ "  adJustOverLoadMoney Component Start");

		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryID);
		delivery.setREC_MODIFYBY(userName);
		delivery.setOverloadFee(money);
		int returnCode;
		returnCode = this.deliveryDAO.adJustOverLoadMoney(delivery);

		List<VariableParams> variables = new ArrayList<VariableParams>();
		this.log.info(DeliveryManagerImpl.class
				+ "  adJustOverLoadMoney Component End");

		return returnCode;
	}

	@Override
	public int takeSettleFeeForOrderSeller(String orderID, String userID) {
		this.log.info(DeliveryManagerImpl.class
				+ "  takeSettleFeeForOrderSeller Component Start");

		MUser user = this.systemMgrDAO.getUserByLoginName(userID);
		Order order = this.deliveryDAO.getOrderByID(orderID);
		order.setREC_MODIFYBY(user.getName());
		int row;
		int returnCode = -10;

		/**
		 * 从卖家收手续费 抵扣 卖方交易手续费授信（SellCreditFee）
		 */
		if (order.getSellCreditFee().compareTo(new BigDecimal(0)) > 0) {
			row = this.voucherMgr.createNewOldVoucher(
					Constants.VOUCHERMODE_SHOU_JIAOYI_SHOUXUFEI,
					order.getSellCreditFee(), order.getOrderId(),
					order.getSellFirmId(), "收卖方交易手续费-冲抵卖方交易手续费授信",
					user.getName());
			if (row >= 0) {
				try {
					sApplyManagerImpl = (ISApplayManager) FinanceSysData
							.getBean(Constants.BEAN_SAPPLYMGR_MGR);
					// 授信类型，0：现货 1：预售
					Integer goodsType = Common.getGoodsType(order.getTradeType());
					if (1 == goodsType) {
						/**
						 * 预售授信流水
						 */
						sApplyManagerImpl.backFeeForPreSale(
								order.getSellFirmId(),
								order.getSellCreditFee(), orderID, 2);
					} else {
						/**
						 * 授信流水
						 */
						sApplyManagerImpl.backFee(order.getSellFirmId(),
								order.getSellCreditFee(), orderID, 1);
					}

					// 更新订单 卖方交易手续费授信（SellCreditFee）
					order.setSellCreditFee(new BigDecimal(0));
					// 更新 卖方交易已收手续费 SellTakenTradeFee
					order.setSellTakenTradeFee(order.getSellTakenTradeFee()
							.add(order.getSellCreditFee()));
					// 更新订单
					this.deliveryDAO
							.updateSellCreditFeeAndSellTakenTradeFee(order);

					returnCode = 1;
				} catch (Exception e) {
					e.printStackTrace();
					returnCode = 0;
				}

			} else {
				this.rollBack();
				returnCode = row;
			}
		} else {
			returnCode = 0;
		}
		this.log.info(DeliveryManagerImpl.class
				+ "  takeSettleFeeForOrderSeller Component End");

		return returnCode;
	}

	@Override
	public void updateFirmfundsForBuyFirm(String deliveryID, BigDecimal money) {
		// TODO Auto-generated method stub

	}

	private void rollBack() {
		this.deliveryDAO.rollBack();
	}

	/**
	 * 
	 */
	public List<Delivery4Export> getExportDeliveryList(QueryConditions qc,
			PageInfo pageInfo, boolean replace) {
		this.log.debug("getExportDeliveryList component Start");

		List<Delivery4Export> rtnList = deliveryDAO_read.getExportDeliveryList(qc,
				pageInfo,replace);
		List<DeliveryDetail> ddList = deliveryDAO_read.getDeliveryDetailList(null,
				null);
		List<DelDistributionDetail> dddList = deliveryDAO_read
				.getDelDistributionDetailList(null, null);
		HashMap<String, DeliveryDetail> ddMap = new HashMap<String, DeliveryDetail>();
		HashMap<String, DelDistributionDetail> dddMap = new HashMap<String, DelDistributionDetail>();
		for (DeliveryDetail dd : ddList) {
			ddMap.put(dd.getDeliveryID(), dd);
		}
		for (DelDistributionDetail ddd : dddList) {
			dddMap.put(ddd.getDeliveryID(), ddd);
		}
		for (Delivery4Export ed : rtnList) {
			if (null == ed.getOverloadFee()) {
				ed.setOverloadFee(new BigDecimal(0));
			}
			if (null == ed.getPayedMoney()) {
				ed.setPayedMoney(new BigDecimal(0));
			}
			if (ddMap.size() > 0) {
				ed.setDeliveryDetail((DeliveryDetail) ddMap.get(ed
						.getDeliveryID()));
			}
			if (dddMap.size() > 0) {
				ed.setDelDistributionDetail((DelDistributionDetail) dddMap
						.get(ed.getDeliveryID()));
				;
			}
		}
		return rtnList;
	}

	@Override
	public Order getOrderFile(String orderID) {
		this.log.info(DeliveryManagerImpl.class
				+ "  getOrderFile Component Start");
		Order order = new Order();
		List<Order> list = this.deliveryDAO_read.getOrderFile(orderID);
		if (list != null && list.size() > 0) {
			int[] fileArray = new int[list.size()];
			for (int i = 0; i < fileArray.length; i++) {
				fileArray[i] = list.get(i).getFileID();
			}
			order.setFileArray(fileArray);
		}
		this.log.info(DeliveryManagerImpl.class
				+ "  getOrderFile Component End");
		return order;
	}

	/**
	 * 
	 */
	public List<ExportFirmfunds> getExportFirmFundsList(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.debug("getExportFirmFundsList component Start");

		List<ExportFirmfunds> rtnList = deliveryDAO_read.getExportFirmFundsList(qc,
				pageInfo);

		for (ExportFirmfunds eff : rtnList) {
			if (eff.getBALANCE().compareTo(eff.getNeedMoney()) >= 0) {
				eff.setNeedFunds(new BigDecimal(0));
			} else {
				eff.setNeedFunds(eff.getNeedMoney().subtract(eff.getBALANCE()));
			}
		}
		return rtnList;
	}

	public SApplyDAO getSApplyDAO() {
		return SApplyDAO;
	}

	public void setSApplyDAO(SApplyDAO sApplyDAO) {
		this.SApplyDAO = sApplyDAO;
	}

	/**
	 * 履约处理完成 ，更新订单“已签收数量（批）SignQuantity” params: takenQuantity:交收实发数量
	 */
	private void updateOrderSignQuantity(BigDecimal takenQuantity,
			String orderID, MUser user) {
		this.deliveryDAO.updateOrderSignQuantity(takenQuantity, orderID, user);
	}

	/**
	 * 
	 */
	public int updDeliveryDetail(Delivery delivery, String userName,
			String userID, String mode, String taskID) {
		this.log.debug("updDeliveryDetail component Start");
		Order order = this.deliveryDAO.getOrderByDeliveryID(delivery
				.getDeliveryID());
		int returnCode;
		// returnCode = this.deliveryDAO.updateDeliveryDocMarker(
		// delivery.getDeliveryID(), userName);
		returnCode = this.updateOrderTradeStatus(order.getOrderId(), mode,
				delivery.getDeliveryType());
		if (returnCode == -1) {
			this.rollBack();
			return returnCode = -24002;
		}
		if (returnCode >= 0) {
			// 买家申请单
			delivery.setDeliveryAttID(delivery.getNextApplyID());
			returnCode = this.deliveryDAO.updateDeliveryAttID(
					delivery.getDeliveryAttID(), delivery.getDeliveryID(),
					userName, 5);
			if (returnCode == -1)
				this.rollBack();
			List<VariableParams> variables = new ArrayList<VariableParams>();
			// 认领任务
			JSONObject rtnJso = claimTask(taskID, userID, mode, userID);
			String resultCode = rtnJso.getString("CODE");
			if (resultCode.equals("OK")) {
				// 完成任务
				VariableParams confirmDeliveryUser = new VariableParams();
				confirmDeliveryUser.setName("confirmDeliveryUser");
				confirmDeliveryUser
						.setValue(this
								.getUser(BusinessEnumConstants.RoleType.LogisticsAuditRoleCode
										.getValue()));
				variables.add(confirmDeliveryUser);

				// 修改之后，指定下一个节点
				VariableParams deliveryDeptVerify = new VariableParams();
				deliveryDeptVerify.setName("deliveryDeptVerify");
				deliveryDeptVerify
						.setValue(this
								.getUser(BusinessEnumConstants.RoleType.LogisticsAuditRoleCode
										.getValue()));
				variables.add(deliveryDeptVerify);

				rtnJso = this.completeTask(variables, mode, userID, taskID);
				resultCode = rtnJso.getString("CODE");
				if (!resultCode.equals("OK")) {
					this.rollBack();
					returnCode = -1;
				}
			}
		} else {
			this.rollBack();
			returnCode = -1;
		}
		return returnCode;
	}

	@Override
	public int updateDelLogisticsInfo(Delivery delivery, String userName) {
		this.log.debug("updateDelLogisticsInfo component Start");
		int returnCode = 0;
		int deliveryType = delivery.getDeliveryType();// 交收方式
		if (returnCode == -1)
			return returnCode;
		if (deliveryType == 0) {
			returnCode = this.deliveryDAO.updDeliveryDetail(delivery, userName);
		} else {
			returnCode = this.deliveryDAO.updTrasferGoodsDetail(delivery,
					userName);
		}
		return returnCode;
	}

	@Override
	public int updateDeliveryDetailStatus(String deliveryID, String userID)
			throws RuntimeException {
		this.log.info(DeliveryManagerImpl.class
				+ "  updateDeliveryDetailStatus Component Start");
		MUser user = this.systemMgrDAO.getUserByLoginName(userID);
		// 更新交收自提信息状态
		return this.deliveryDAO.updateDeliveryDetailStatus(deliveryID,
				user.getName());
	}

	/**
	 * 成交单处理完成
	 * 
	 * @param equal
	 * @param quantity
	 * @param deliveryQuantity
	 * @param deliveryID
	 */
	@Override
	public int finishedOrder(int tradeStatus, String orderID, boolean equal,
			int deliveryQuantity, int quantity) {
		this.log.info(DeliveryManagerImpl.class
				+ "  finishedOrder Component Start");
		int recturnCode = 0;
		// 查看 此交收单 关联的 “成交单” 是否还有未处理完成的 交收单 如果没有，把成交单置为处理完成
		List<Delivery> deliveryList = this.deliveryDAO
				.getDeliveryListByOrderID(orderID);
		int flag = 0;
		if (deliveryList != null && deliveryList.size() > 0) {
			for (int i = 0; i < deliveryList.size(); i++) {
				if (deliveryList.get(i).getStatus() == 2
						|| deliveryList.get(i).getViolationStatus() == 1) {
					flag++;
				}
				// 违约情况
				if (deliveryList.get(i).getProcessStatus() == 1) {
					deliveryQuantity += deliveryList.get(i)
							.getDeliveryQuantity();
				}
			}
			equal = quantity == deliveryQuantity ? true : false;
			if (flag == deliveryList.size() && equal) {
				recturnCode = this.deliveryDAO.finishedOrder(tradeStatus,
						orderID);
			}
		}
		this.log.info(DeliveryManagerImpl.class
				+ "  finishedOrder Component End");

		return recturnCode;
	}

	@Override
	public int updateDeliveryLogisticsStatus(String deliveryID, String userID,
			String mode) {
		this.log.info(DeliveryManagerImpl.class
				+ "  updateDeliveryLogisticsStatus Component Start");

		int returnCode = 0;
		MUser user = this.systemMgrDAO.getUserByLoginName(userID);
		Delivery delivery = this.getDeliveryDetail(deliveryID, userID, mode);
		// 更新交收表 "物流状态"
		returnCode = deliveryDAO.updateDeliveryLogisticsStatus(1, deliveryID,
				user.getName());
		if (returnCode == 0)
			return returnCode;

		List<Delivery> deliveryList = this.deliveryDAO
				.getDeliveryListByOrderID(delivery.getOrderID());
		Order order = this.getOrderByDeliveryID(deliveryID);
		// 订单 "已申请交收数量（批）DeliveryQuantity" "成交数量（批）Quantity"
		boolean equal = false;
		int deliveryQuantity = order.getDeliveryQuantity();
		int flag = 0;
		if (deliveryList != null && deliveryList.size() > 0) {
			for (int i = 0; i < deliveryList.size(); i++) {
				if (deliveryList.get(i).getLogisticsStatus() == 1
						|| deliveryList.get(i).getLogisticsStatus() == 2
						|| deliveryList.get(i).getLogisticsStatus() == 3
						|| deliveryList.get(i).getProcessStatus() == 1) {
					flag++;
				}
				// 违约情况
				if (deliveryList.get(i).getProcessStatus() == 1) {
					deliveryQuantity += deliveryList.get(i)
							.getDeliveryQuantity();
				}
			}
			equal = order.getQuantity() == deliveryQuantity ? true : false;
			if (flag == deliveryList.size() && equal) {
				returnCode = this.deliveryDAO.finishedOrder(10,
						delivery.getOrderID());
			}
		}
		this.log.info(DeliveryManagerImpl.class
				+ "  updateDeliveryLogisticsStatus Component End");

		return returnCode;
	}

	/**
	 * 未付交易商手续费
	 */
	@Override
	public BigDecimal getNotPaidSellerPenalty(String deliveryID, String firmID,
			int penaltyType) {
		this.log.debug(this.getClass().getName()
				+ " getNotPaidSellerPenalty Component Start");
		Delivery delivery = this.deliveryDAO_read.getDeliveryDetail(deliveryID);
		// 待付商家违约金
		BigDecimal notPaidSellerPenalty;
		if (penaltyType == 0) {// 付卖家违约金
			// 买方已扣违约金
			BigDecimal buyPenalty = delivery.getBuyPenalty();
			// 已付卖方违约金
			BigDecimal paidSellerPenalty = delivery.getPaidSellerPenalty() == null ? new BigDecimal(
					0) : delivery.getPaidSellerPenalty();
			// 待支付卖方方违约金
			notPaidSellerPenalty = buyPenalty.subtract(paidSellerPenalty);

		} else {// 付买方违约金
				// 卖方已扣违约金
			BigDecimal sellPenalty = delivery.getSellPenalty();
			// 已付买方违约金
			BigDecimal paidBuyPenalty = delivery.getPaidBuyPenalty() == null ? new BigDecimal(
					0) : delivery.getPaidBuyPenalty();
			// 待支付买方违约金
			notPaidSellerPenalty = sellPenalty.subtract(paidBuyPenalty);
		}
		return notPaidSellerPenalty;
	}

	/**
	 * 付卖家违约金(买家交收违约)
	 */
	@Override
	public int paySellerPenalty(String deliveryID, String userName,
			BigDecimal payMoney) {
		this.log.debug(DeliveryManagerImpl.class.getName()
				+ " paySellerPenalty Component Start");
		int returnCode = -10;
		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryID);
		BigDecimal buyPenalty = delivery.getBuyPenalty();// 买家交收应扣违约金

		if (payMoney.compareTo(buyPenalty) > 0)
			return returnCode - 1;// 付卖家违约金大于 "买家交收应扣违约金"
		returnCode = this.deliveryDAO.updateShouldPaySellPenalty(payMoney,
				userName, deliveryID);

		// 待支付违约金
		// BigDecimal notPaidSellerPenalty = this.getNotPaidSellerPenalty(
		// deliveryID, delivery.getSellFirmId(), 0);
		// if (payMoney.compareTo(notPaidSellerPenalty) > 0) {
		// returnCode = -10;
		// } else {
		// // 更新“已付卖方违约金”
		// BigDecimal paidSellPenalty = delivery.getPaidSellerPenalty() == null
		// ? new BigDecimal(
		// 0) : delivery.getPaidSellerPenalty();
		// paidSellPenalty = paidSellPenalty.add(payMoney);
		// returnCode = this.deliveryDAO.updatePaidSellPenalty(
		// paidSellPenalty, deliveryID);
		// if (returnCode > 0) {
		// returnCode = this.voucherMgr.createNewOldVoucher(
		// Constants.VOUCHERMODE_TUI_WEIYUEJIN, payMoney,
		// deliveryID, delivery.getSellFirmId(), "买方交收违约，付卖方违约金",
		// userName);
		// if (returnCode < 0) {
		// this.rollBack();
		// returnCode = -10;
		// }
		// } else {
		// this.rollBack();
		// returnCode = -10;
		// }
		// }
		return returnCode;
	}

	/**
	 * 付买家违约金(卖家交收违约)
	 * 
	 * @param deliveryID
	 * @param userName
	 * @param payMoney
	 * @return
	 */
	@Override
	public int payBuyerPenalty(String deliveryID, String userName,
			BigDecimal payMoney) {
		int returnCode = -10;
		this.log.debug(DeliveryManagerImpl.class.getName()
				+ " payBuyerPenalty Component Start");
		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryID);
		BigDecimal sellPenalty = delivery.getSellPenalty();// 卖方交收应扣违约金

		if (payMoney.compareTo(sellPenalty) > 0)
			return returnCode - 1;// 付买家违约金大于 "卖方交收应扣违约金"
		returnCode = this.deliveryDAO.updateShouldPayBuyPenalty(payMoney,
				userName, deliveryID);
		// // 待支付违约金
		// BigDecimal notPaidSellerPenalty = this.getNotPaidSellerPenalty(
		// deliveryID, delivery.getBuyFirmId(), 1);
		// if (payMoney.compareTo(notPaidSellerPenalty) > 0) {
		// returnCode = -10;
		// } else {
		// // 更新“已付买方违约金”
		// BigDecimal paidBuyPenalty = delivery.getPaidBuyPenalty() == null ?
		// new BigDecimal(
		// 0) : delivery.getPaidBuyPenalty();
		// paidBuyPenalty = paidBuyPenalty.add(payMoney);
		// returnCode = this.deliveryDAO.updatePaidBuyPenalty(paidBuyPenalty,
		// deliveryID);
		// if (returnCode > 0) {
		// returnCode = this.voucherMgr.createNewOldVoucher(
		// Constants.VOUCHERMODE_TUI_WEIYUEJIN, payMoney,
		// deliveryID, delivery.getBuyFirmId(), "卖方交收违约，付买方违约金",
		// userName);
		// if (returnCode < 0) {
		// this.rollBack();
		// returnCode = -10;
		// }
		// } else {
		// this.rollBack();
		// returnCode = -10;
		// }
		// }
		return returnCode;
	}

	@Override
	public String[] getLogisticalRecordArray(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.info(DeliveryManagerImpl.class.getName()
				+ "  getLogisticalRecordArray Component Start");

		List<UpAndDownRecord> recordList = this.deliveryDAO
				.getLogisticalRecordArray(qc, pageInfo);

		String[] array = null;
		if (recordList != null && recordList.size() > 0) {
			array = new String[recordList.size()];
			for (int i = 0; i < recordList.size(); i++) {
				array[i] = recordList.get(i).getRecordID();
			}
		}
		this.log.info(DeliveryManagerImpl.class
				+ "  getLogisticalRecordArray Component End");

		return array;
	}

	@Override
	public String[] getRecordArray(QueryConditions qc, PageInfo pageInfo) {
		this.log.info(DeliveryManagerImpl.class
				+ "  getRecordArray Component Start");

		List<UpAndDownRecord> recordList = this.deliveryDAO.getRecordList(qc,
				pageInfo);

		String[] array = null;
		if (recordList != null && recordList.size() > 0) {
			array = new String[recordList.size()];
			for (int i = 0; i < recordList.size(); i++) {
				array[i] = recordList.get(i).getRecordID();
			}
		}
		this.log.info(DeliveryManagerImpl.class
				+ "  getRecordArray Component End");

		return array;
	}

	@Override
	public List<DeliveryInvoice4Export> getDeliveryInvoice4ExportList(
			QueryConditions qc, PageInfo pageInfo, boolean replace) {
		this.log.debug("getDeliveryInvoiceList component Start");

		List<DeliveryInvoice4Export> rtnList = deliveryDAO_read.getDeliveryInvoice4ExportList(qc,
				pageInfo,replace);
		StringBuilder sb = null;
		for (DeliveryInvoice4Export di : rtnList) {
			if (di.getTakenQuantity().compareTo(new BigDecimal(0)) != 0) {
				di.setDPrice(di.getTakenMoney().divide(di.getTakenQuantity(),
						2, BigDecimal.ROUND_HALF_EVEN));
			} else {
				di.setDPrice(new BigDecimal(0));
			}
			sb = new StringBuilder();
			if (null != di.getFPVShortName()) {
				sb.append(di.getFPVShortName());
			}
			if (null != di.getFCTShortName()) {
				sb.append(di.getFCTShortName());
			}
			if (null != di.getFDTShortName()) {
				sb.append(di.getFDTShortName());
			}
			if (null != di.getFAddress()) {
				sb.append(di.getFAddress());
			}
			di.setDetailedAddress(sb.toString());
			sb = new StringBuilder();
			if (null != di.getVPVShortName()) {
				sb.append(di.getVPVShortName());
			}
			if (null != di.getVCTShortName()) {
				sb.append(di.getVCTShortName());
			}
			if (null != di.getVDTShortName()) {
				sb.append(di.getVDTShortName());
			}
			if (null != di.getVAddress()) {
				sb.append(di.getVAddress());
			}
			di.setInvoiceAddress(sb.toString());
			sb = new StringBuilder();
			if (null != di.getVBankName()) {
				sb.append(di.getVBankName());
			}
			// if (null != di.getVatBkBranch()) {
			// sb.append(di.getVatBkBranch());
			// }
			di.setVBankFullName(sb.toString());
			if (null != di.getFContactTelNo()) {
				di.setFContactTelNo(Base64Util.getFromBase64(di
						.getFContactTelNo()));
			}
			if (null != di.getFContactMobile()) {
				di.setFContactMobile(Base64Util.getFromBase64(di
						.getFContactMobile()));
			}
			if (null != di.getVatBkAccount()) {
				di.setVatBkAccount(Base64Util.getFromBase64(di
						.getVatBkAccount()));
			}
			if (null != di.getVContactTelNo()) {
				di.setVContactTelNo(Base64Util.getFromBase64(di
						.getVContactTelNo()));
			}
		}
		return rtnList;
	}
	/**
	 * 
	 */
	public List<DeliveryInvoice> getDeliveryInvoiceList(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.debug("getDeliveryInvoiceList component Start");

		List<DeliveryInvoice> rtnList = deliveryDAO_read.getDeliveryInvoiceList(qc,
				pageInfo);
		StringBuilder sb = null;
		for (DeliveryInvoice di : rtnList) {
			if (di.getTakenQuantity().compareTo(new BigDecimal(0)) != 0) {
				di.setDPrice(di.getTakenMoney().divide(di.getTakenQuantity(),
						2, BigDecimal.ROUND_HALF_EVEN));
			} else {
				di.setDPrice(new BigDecimal(0));
			}
			sb = new StringBuilder();
			if (null != di.getFPVShortName()) {
				sb.append(di.getFPVShortName());
			}
			if (null != di.getFCTShortName()) {
				sb.append(di.getFCTShortName());
			}
			if (null != di.getFDTShortName()) {
				sb.append(di.getFDTShortName());
			}
			if (null != di.getFAddress()) {
				sb.append(di.getFAddress());
			}
			di.setDetailedAddress(sb.toString());
			sb = new StringBuilder();
			if (null != di.getVPVShortName()) {
				sb.append(di.getVPVShortName());
			}
			if (null != di.getVCTShortName()) {
				sb.append(di.getVCTShortName());
			}
			if (null != di.getVDTShortName()) {
				sb.append(di.getVDTShortName());
			}
			if (null != di.getVAddress()) {
				sb.append(di.getVAddress());
			}
			di.setInvoiceAddress(sb.toString());
			sb = new StringBuilder();
			if (null != di.getVBankName()) {
				sb.append(di.getVBankName());
			}
			// if (null != di.getVatBkBranch()) {
			// sb.append(di.getVatBkBranch());
			// }
			di.setVBankFullName(sb.toString());
			if (null != di.getFContactTelNo()) {
				di.setFContactTelNo(Base64Util.getFromBase64(di
						.getFContactTelNo()));
			}
			if (null != di.getFContactMobile()) {
				di.setFContactMobile(Base64Util.getFromBase64(di
						.getFContactMobile()));
			}
			if (null != di.getVatBkAccount()) {
				di.setVatBkAccount(Base64Util.getFromBase64(di
						.getVatBkAccount()));
			}
			if (null != di.getVContactTelNo()) {
				di.setVContactTelNo(Base64Util.getFromBase64(di
						.getVContactTelNo()));
			}
		}
		return rtnList;
	}

	@Override
	public int startProcessByCustomer(String[] deliveryIDArray, String userID,
			String userName, String mode) {
		int returnCode = 0;
		if (deliveryIDArray != null && deliveryIDArray.length > 0) {
			for (int i = 0; i < deliveryIDArray.length; i++) {
				String deliveryID = deliveryIDArray[i];
				/**
				 * 开启交收流程
				 */
				List<VariableParams> variables = new ArrayList<VariableParams>();

				VariableParams isCustomerApply = new VariableParams();
				// 是否前台客户提交
				isCustomerApply.setName("isCustomerApply");
				// 交收申请来源：0：后台物流 1：前台客户
				isCustomerApply.setValue(1);

				// 下一节点操作人员 (物流普通操作人员)
				VariableParams confirmDeliveryUser = new VariableParams();
				confirmDeliveryUser.setName("confirmDeliveryUser");
				String roleCodes = BusinessEnumConstants.RoleType.LogisticsGeneralerRoleCode
						.getValue();
				confirmDeliveryUser.setValue(this.getUser(roleCodes));

				variables.add(isCustomerApply);
				variables.add(confirmDeliveryUser);

				JSONObject rtnJso = startProcessInstance(deliveryID,
						"Deliverable", mode, userID, variables);
				if (!rtnJso.getString("CODE").equals("OK")) {
					this.log.debug(this.getClass().getName()
							+ "startProcessByCustomer 调用工作流程失败,交收单号："
							+ deliveryID + ",返回参数 rtnJso:" + rtnJso);
					this.rollBack();
					returnCode = -1;
				} else {
					try {
						JSONObject JSONParams = new JSONObject(
								rtnJso.getString("DATA"));
						String processInstanceID = JSONParams.getString("id");
						returnCode = this.deliveryDAO
								.updateDeliveryProcessInstanceID(
										processInstanceID, deliveryID, userName);
						if (returnCode == -1) {
							this.rollBack();
							return returnCode = -1;
						}
						Integer[] userIds = this.getUserID(roleCodes);
						// 推送消息
						returnCode = this.pushMessage(mode, userIds, userID,
								"请物流操作人员查看审核商城客户提交的交收申请",
								"app.deliveryDetail.logistic", deliveryID);
						if (returnCode == -1) {
							this.log.debug(this.getClass().getName()
									+ "pushMessage 推送消息失败 交收单号：" + deliveryID);
							this.rollBack();
							return returnCode = -24006;
						}
					} catch (Exception e) {
						e.printStackTrace();
						this.rollBack();
						returnCode = -1;
					}
				}
				this.addDeliveryOpeLog(deliveryID, userName, "商城客户发起交收申请", "");
			}
		}
		return returnCode;
	}

	@Override
	public int submitDelivery(Delivery delivery, String userName,
			String userID, String mode) {//
		int returnCode = 0;
		// 交收更新为 "物流部门 待审核 5"
		returnCode = this.deliveryDAO.updateDeliveryStatus(5,
				delivery.getDeliveryID(), userName);
		Order order = this.deliveryDAO.getOrderByDeliveryID(delivery
				.getDeliveryID());
		if (!(returnCode >= 0)) {
			this.rollBack();
			return returnCode;
		}
		int deliveryType = delivery.getDeliveryType();// 交收方式
		// 物流信息
		if (deliveryType == 0) {
			returnCode = this.deliveryDAO.updDeliveryDetail(delivery, userName);
			if (returnCode == -1) {
				this.rollBack();
				return returnCode;
			}
		} else {
			returnCode = this.deliveryDAO.updTrasferGoodsDetail(delivery,
					userName);
			if (returnCode == -1) {
				this.rollBack();
				return returnCode;
			}
		}
		return returnCode;
	}

	/**
	 * 交收申请（后台提交 状态直接为"待审核 5"）
	 * 
	 * @throws ParseException
	 */
	@Override
	public int addNormalDelivery(Delivery delivery, String userName,
			String mode, String userID) throws ParseException {
		this.log.info(this.getClass().getName()
				+ "addNormalDelivery Component Start");
		int returnCode = 0;
		Order order = this.orderDAO.getOrderByOrderID(delivery.getOrderID());
		int canDeliveryQuantity = this.getCanDeliveryQuantity(order
				.getOrderId());
		if (delivery.getDeliveryQuantity() > canDeliveryQuantity) {
			// 申请交收数量大于 订单可交收数量
			return returnCode = -24017;
		}
		// 最小交收数量（批）
		int minQuantity = this.deliveryDAO.getMinQuantity(order.getOrderId());
		if (delivery.getDeliveryQuantity() < minQuantity) {
			// 申请交收数量小于最小交收数量
			return returnCode = -24011;
		}

		/* 订单剩余总量 */
		int totalQuantity = order.getQuantity() - order.getDeliveryQuantity();
		int numQuantity = totalQuantity - minQuantity;
		if ((delivery.getDeliveryQuantity() > numQuantity)
				&& (delivery.getDeliveryQuantity() != totalQuantity))
			return -24027;

		// 交收单号生成规则 订单号+两位有序数字
		String deliveryID = DeliveryExpenseUtil.setDeliveryID(
				order.getOrderId(), orderDAO);
		order.setUnnormalFirm(100);
		DeliveryExpenseUtil.setDeliveryExpenses(order, delivery, userName,
				deliveryDAO);
		delivery.setDeliveryID(deliveryID);

		returnCode = this.deliveryDAO.addNormalDelivery(delivery, userName);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode = -24004;
		}
		// 订单已经申请的数量更新
		returnCode = this.deliveryDAO
				.updateDeliveryQuantity(delivery.getDeliveryQuantity(),
						delivery.getOrderID(), userName);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode = -24004;
		}

		// 交收方式0: 自提；1:配送,2:转货
		int deliveryType = delivery.getDeliveryType();
		if (deliveryType == 0) {
			// 交收自提明细
			DeliveryDetail deliveryDetail = DeliveryExpenseUtil
					.getDeliveryDetail(delivery, userName);
			if (returnCode > 0)
				returnCode = this.deliveryDAO.addDeliveryDetail(deliveryDetail);
			if (returnCode == -1) {
				this.rollBack();
				return returnCode = -24004;
			}
		}

		// if(deliveryType == 1){
		// /*配送地址*/
		// int addRessID = this.commonDao.addAddress(delivery);
		// if(addRessID >= 0){
		// delivery.setDistributionAddressID(addRessID);
		// }else {
		// this.rollBack();
		// return returnCode = -24004;
		// }
		// /*配送地址：Address表的地址(省）+地址(市）+地址(区）+详细地址*/
		// String distributionAddress =
		// this.commonDao.getAddRessString(addRessID);
		// delivery.setDistributionAddress(distributionAddress);
		// //配送申请
		// DelDistributionDetail delDistributionDetail =
		// DeliveryExpenseUtil.getDelDistributionDetail(delivery,userName);
		// if(returnCode > 0)
		// returnCode =
		// this.deliveryDAO.addDelDistributionDetail(delDistributionDetail,userName);
		// if (returnCode == -1) {
		// this.rollBack();
		// return returnCode = -24004;
		// }
		// }

		if (deliveryType == 2) {
			// 货权转移
			TrasferGoodsDetail trasferGoodsDetail = DeliveryExpenseUtil
					.getTrasferGoodsDetail(delivery, userName);
			if (returnCode > 0)
				returnCode = this.deliveryDAO
						.addTrasferGoodsDetail(trasferGoodsDetail);
			if (returnCode == -1) {
				this.rollBack();
				return returnCode = -24004;
			}
		}
		returnCode = this.updateOrderTradeStatus(order.getOrderId(), mode,
				delivery.getDeliveryType());
		if (returnCode == -1) {
			this.rollBack();
			return returnCode = -24002;
		}

		/**
		 * 开启交收流程
		 */
		List<VariableParams> variables = new ArrayList<VariableParams>();

		VariableParams isCustomerApply = new VariableParams();
		// 是否前台客户提交
		isCustomerApply.setName("isCustomerApply");
		// 交收申请来源：0：后台物流 1：前台客户
		isCustomerApply.setValue(0);

		VariableParams deliveryTypeParams = new VariableParams();
		// 是否前台客户提交
		deliveryTypeParams.setName("deliveryType");
		// 交收方式
		deliveryTypeParams.setValue(deliveryType);

		// 下一节点操作人员 (物流审核人员)
		VariableParams deliveryDeptVerify = new VariableParams();
		deliveryDeptVerify.setName("deliveryDeptVerify");
		String roleCodes = BusinessEnumConstants.RoleType.LogisticsAuditRoleCode
				.getValue();
		deliveryDeptVerify.setValue(this.getUser(roleCodes));

		// // 并行节点（履约OR违约）0：履约 1：违约
		// VariableParams breachPromiseUsers = new VariableParams();
		// breachPromiseUsers.setName("breachPromiseUsers");
		// breachPromiseUsers.setValue(this.getUser(roleCodes));

		variables.add(isCustomerApply);
		variables.add(deliveryDeptVerify);
		variables.add(deliveryTypeParams);
		// variables.add(breachPromiseUsers);

		JSONObject rtnJso = startProcessInstance(deliveryID, "Deliverable",
				mode, userID, variables);
		if (!rtnJso.getString("CODE").equals("OK")) {
			this.rollBack();
			returnCode = -24005;
		} else {
			try {
				JSONObject JSONParams = new JSONObject(rtnJso.getString("DATA"));
				String processInstanceID = JSONParams.getString("id");
				returnCode = this.deliveryDAO.updateDeliveryProcessInstanceID(
						processInstanceID, deliveryID, userName);
				if (returnCode == -1) {
					this.rollBack();
					return returnCode = -1;
				}
				Integer[] userIds = this.getUserID(roleCodes);
				// 推送消息
				returnCode = this.pushMessage(mode, userIds, userID,
						"请物流审核人员审核交收申请", "app.deliveryDetail.logistic",
						deliveryID);
				if (returnCode == -1) {
					this.rollBack();
					return returnCode = -24006;
				}
			} catch (Exception e) {
				e.printStackTrace();
				this.rollBack();
				returnCode = -1;
			}
		}
		this.addDeliveryOpeLog(deliveryID, userName, "物流部门发起交收申请", "");
		this.log.info(this.getClass().getName()
				+ "addNormalDelivery Component End");
		return returnCode;
	}

	/**
	 * 物流部门 交收申请 审核通过
	 */
	@Override
	public int reviewPassedDelivery(String deliveryID, String userName,
			String mode, String userID, String taskID) {
		this.log.info(this.getClass().getName()+" reviewPassedDelivery Start");
		int returnCode = 0;
		returnCode = this.deliveryDAO.updateDeliveryStatus(10, deliveryID,
				userName);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}

		/**
		 * 订单状态
		 */
		Delivery delivery = this.getDeliveryDetail(deliveryID, userID, mode);
		/** 2016.12.14 开始为了避免上传失败 造成事务死锁，把以下代码移到service层(因为service层没有事务) */
//		// 自提审核通过，直接生成委托书
//		if (delivery.getDeliveryType() == 0) {
//			DeliveryDto deliveryDto = new DeliveryDto();
//			deliveryDto.setDeliveryID(deliveryID);
//			deliveryDto.setFullName(delivery.getGoodName());
//			Map<String, Object> mapFile = this.createImage(mode, 0, deliveryDto);
//			List<Map<String, Object>> fileList = new ArrayList<Map<String, Object>>();
//			fileList.add(mapFile);
//			returnCode = this.upateDeliveryDetailORTrasferGoodsDetail(fileList,delivery, userName, 0);
//			if (returnCode == -1) {
//				this.rollBack();
//				return returnCode = -24007;
//			}
//		}
		/** 2016.12.14 结束*/
		Order order = this.deliveryDAO.getOrderByID(delivery.getOrderID());

		returnCode = this.updateOrderTradeStatus(order.getOrderId(), mode,
				delivery.getDeliveryType());
		if (returnCode == -1) {
			this.rollBack();
			return returnCode = -24002;
		}

		// String statusConditions = "(10,20,25,30,35,40,45,50,55,60,65)";
		// boolean flag = this.compareDeliveryStatus(order.getOrderId(),
		// statusConditions);
		//
		// if (flag) {
		// // 更新订单状态
		// this.deliveryDAO.finishedOrder(10, order.getOrderId());
		// }

		List<VariableParams> variables = new ArrayList<VariableParams>();
		// 认领任务
		JSONObject rtnJso = claimTask(taskID, userID, mode, userID);
		String resultCode = rtnJso.getString("CODE");
		if (resultCode.equals("OK")) {
			// 完成任务
			VariableParams deliveryApproved = new VariableParams();
			deliveryApproved.setName("deliveryApproved");
			deliveryApproved.setValue(1);
			variables.add(deliveryApproved);

			// 审核通过的同时，指定下一个任务节点的操作人员(物流操作人员)
			VariableParams uploadReceiptFormUser = new VariableParams();
			uploadReceiptFormUser.setName("uploadReceiptFormUser");
			String roleCodes = BusinessEnumConstants.RoleType.LogisticsGeneralerRoleCode
					.getValue();
			String userCodes = this.getUser(roleCodes);
			this.log.info(this.getClass().getName()+" reviewPassedDelivery(物流部门审核通过交收申请),下一点任务人员(物流制单操作员)ID是: "+userCodes);
			uploadReceiptFormUser.setValue(this.getUser(roleCodes));
			variables.add(uploadReceiptFormUser);

			// //履约、违约
			// VariableParams isBreachPromise = new VariableParams();
			// isBreachPromise.setName("isBreachPromise");
			// isBreachPromise.setValue(0);
			// variables.add(isBreachPromise);

			// 并行节点（履约OR违约）0：履约 1：违约
			// VariableParams breachPromiseUsers = new VariableParams();
			// breachPromiseUsers.setName("breachPromiseUsers");
			// breachPromiseUsers.setValue(this.getUser(roleCodes));
			// variables.add(breachPromiseUsers);

			rtnJso = this.completeTask(variables, mode, userID, taskID); 
			resultCode = rtnJso.getString("CODE");
			if (!resultCode.equals("OK")) {
				this.rollBack();
				returnCode = -24008;
			} else {
				Integer[] userIds = this.getUserID(roleCodes);
				// 推送消息
				returnCode = this.pushMessage(mode, userIds, userID,
						"物流审核通过，请物流操作人员传买家委托书给卖家",
						"app.deliveryDetail.logistic", deliveryID);
				if (returnCode == -1) {
					this.rollBack();
					return returnCode = -24006;
				}
			}
		}
		this.log.info(this.getClass().getName()+" reviewPassedDelivery End");
		return returnCode;
	}

	/**
	 * 交收申请 审核拒绝
	 */
	@Override
	public int reviewNotPassedDelivery(String deliveryID, String userName,
			String taskID, String mode, String userID) {
		int returnCode = 0;
		// 审核拒绝 物流部门重新修改交收申请信息
		returnCode = this.deliveryDAO.updateNotPassedDeliveryStatus(15,
				deliveryID, userName);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}

		List<VariableParams> variables = new ArrayList<VariableParams>();
		// 认领任务
		JSONObject rtnJso = claimTask(taskID, userID, mode, userID);

		// 完成任务
		VariableParams deliveryApproved = new VariableParams();
		deliveryApproved.setName("deliveryApproved");
		// 审核拒绝
		deliveryApproved.setValue(0);
		variables.add(deliveryApproved);

		// 审核拒绝的同时，指定下一个任务节点的操作人员(物流普通操作员)
		VariableParams confirmDeliveryUser = new VariableParams();
		confirmDeliveryUser.setName("confirmDeliveryUser");
		String roleCodes = BusinessEnumConstants.RoleType.LogisticsGeneralerRoleCode
				.getValue();
		confirmDeliveryUser.setValue(this.getUser(roleCodes));
		variables.add(confirmDeliveryUser);

		// // 并行节点（履约OR违约）0：履约 1：违约
		// VariableParams breachPromiseUsers = new VariableParams();
		// breachPromiseUsers.setName("breachPromiseUsers");
		// breachPromiseUsers.setValue(this.getUser(roleCodes));
		// variables.add(breachPromiseUsers);

		rtnJso = this.completeTask(variables, mode, userID, taskID);
		String resultCode = rtnJso.getString("CODE");
		if (!resultCode.equals("OK")) {
			this.rollBack();
			returnCode = -1;
		} else {
			Integer[] userIds = this.getUserID(roleCodes);
			// 推送消息
			returnCode = this.pushMessage(mode, userIds, userID,
					"物流审核拒绝，请物流操作人员在必要情况下修改物流信息",
					"app.deliveryDetail.logistic", deliveryID);
			if (returnCode == -1)
				this.rollBack();
		}
		return returnCode;
	}

	/**
	 * 传上家委托书
	 */
	@Override
	public int uploadReceiptForm(String deliveryID, String userName,
			String mode, String userID, String taskID) {
		int returnCode = 0;
		// 传上家委托书
		returnCode = this.deliveryDAO.updateDeliveryStatus(20, deliveryID,
				userName);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}
		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryID);

		returnCode = this.updateOrderTradeStatus(delivery.getOrderID(), mode,
				delivery.getDeliveryType());
		if (returnCode == -1) {
			this.rollBack();
			return returnCode = -24009;
		}
		// 获取任务
		JSONObject rtnJso = this.getPerformanceAgreementTaskList(deliveryID,
				userName, userID, mode);
		if (rtnJso != null) {
			JSONObject JSONParams = new JSONObject(rtnJso.getString("DATA"));
			if (JSONParams != null) {
				JSONArray taskArray = JSONParams.getJSONArray("data");
				if (taskArray != null && taskArray.length() > 0) {
					String taskIDTemp = "";
					String ss = taskArray.get(0).toString();
					JSONObject taskObject = new JSONObject(ss);
					if (!taskObject.isNull("id")) {
						taskIDTemp = taskObject.getString("id");
						List<VariableParams> variables = new ArrayList<VariableParams>();
						// 认领
						this.claimTask(taskIDTemp, userID, mode, userID);
						// // 完成任务 履约
						// VariableParams isBreachPromise = new
						// VariableParams();
						// isBreachPromise.setName("isBreachPromise");
						// isBreachPromise.setValue(0);
						// variables.add(isBreachPromise);
						rtnJso = this.completeTask(variables, mode, userID,
								taskIDTemp);
						String resultCode = rtnJso.getString("CODE");
						if (!resultCode.equals("OK")) {
							this.rollBack();
							return returnCode = -1;
						}
					}
				}
			}
		}

		List<VariableParams> variables = new ArrayList<VariableParams>();

		// 认领任务
		JSONObject rtnJsos = claimTask(taskID, userID, mode, userID);

		// 指定下一个任务节点的操作人员(物流调整实价发货数量：物流普通操作员)
		VariableParams amountAdjustment = new VariableParams();
		amountAdjustment.setName("amountAdjustment");
		String roleCodes = BusinessEnumConstants.RoleType.LogisticsGeneralerRoleCode
				.getValue();
		amountAdjustment.setValue(this.getUser(roleCodes));
		variables.add(amountAdjustment);

		rtnJso = this.completeTask(variables, mode, userID, taskID);
		String resultCode = rtnJsos.getString("CODE");
		if (!resultCode.equals("OK")) {
			this.rollBack();
			returnCode = -1;
		}
		// else {
		// Integer[] userIds = this.getUserID(roleCodes);
		// //推送消息
		// returnCode = this.pushMessage(userIds, userID,
		// "已经上传卖家委托书，请物流操作人员在必要情况下调整实际发货数量", "app.deliveryDetail.logistic",
		// deliveryID);
		// if (returnCode == -1){
		// this.rollBack();
		// return returnCode;
		// }
		// }
		return returnCode;
	}

	@Override
	public int uploadReceiptFormByBuyer(String orderID,
			JSONArray deliveryArray, JSONArray fileIDArray, String userName) {
		int returnCode = 0;
		Order order = this.deliveryDAO.getOrderByID(orderID);
		int quantity = order.getQuantity();
		int deliveryQuantity = order.getDeliveryQuantity();
		if (quantity > deliveryQuantity) {
			return returnCode = -24003;
		}
		if (deliveryArray != null && deliveryArray.length() > 0) {
			for (int i = 0; i < deliveryArray.length(); i++) {
				JSONObject JSONParams = deliveryArray.getJSONObject(i);
				String deliveryID = JSONParams.getString("deliveryID");
				BigDecimal takenQuantity = new BigDecimal(
						JSONParams.getString("takenQuantity"));

				// Delivery delivery =
				// this.deliveryDAO.getDeliveryDetail(deliveryID);
				// BigDecimal deliveryQuantityBigDecimal = new
				// BigDecimal(delivery.getDeliveryQuantity()).multiply(order.getTradeUnitNumber());
				// if(takenQuantity.compareTo(deliveryQuantityBigDecimal) > 0){
				// return returnCode = -24019;
				// }
				returnCode = this.deliveryDAO.updateTakenQuantity(deliveryID,
						takenQuantity, userName);
				if (returnCode == -1)
					return returnCode;
				returnCode = this.deliveryDAO.updateDeliveryStatus(25,
						deliveryID, userName);
				if (returnCode == -1) {
					this.rollBack();
					return returnCode;
				}
			}
			if (fileIDArray != null && fileIDArray.length() > 0) {
				returnCode = this.deliveryDAO.deleteaddReceipt(orderID);
				for (int i = 0; i < fileIDArray.length(); i++) {

					if (returnCode == -1) {
						this.rollBack();
						return returnCode;
					}
					int fileID = Integer.parseInt(fileIDArray.getString(i));// 签收文件ID
					// 签收相关表
					int receiptFileID = this.deliveryDAO.addReceipt(orderID,
							userName);
					if (receiptFileID == -1) {
						this.rollBack();
						return returnCode = -1;
					}
					returnCode = this.deliveryDAO.addReceiptFile(orderID,
							receiptFileID, fileID, userName);
					if (fileID == -1) {
						this.rollBack();
						return returnCode = -1;
					}
				}
			}
		}

		// 订单状态更新:签收单已上传
		returnCode = this.deliveryDAO.finishedOrder(20, orderID);
		if (returnCode == -1)
			this.rollBack();
		return returnCode;
	}

	/**
	 * 签收存在溢短，需风控介入审核 风控审核签收数量--通过
	 */
	@Override
	public int reviewPassedDeliverySignedQuantity(String deliveryID,
			String userName, String mode, String userID, String taskID) {
		int returnCode = 0;
		// 审核通过 交收状态置为 "40 风控通过，待卖家确认"
		returnCode = this.deliveryDAO.updateDeliveryStatus(40, deliveryID,
				userName);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}

		// 审核通过 订单状态变为"风控签收数量已确认"
		Delivery delivery = this.getDeliveryDetail(deliveryID, userID, mode);

		Order order = this.deliveryDAO.getOrderByID(delivery.getOrderID());
		returnCode = this.updateOrderTradeStatus(order.getOrderId(), mode,
				delivery.getDeliveryType());
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}

		// String statusConditions = "(40,50,55,60,65)";
		// boolean flag = this.compareDeliveryStatus(order.getOrderId(),
		// statusConditions);
		// if (flag) {
		// // 更新订单状态 所有交收单签收数量（履约/违约）风控审核通过后，订单状态为"40 风控签收数量已确认 "
		// this.deliveryDAO.finishedOrder(40, order.getOrderId());
		// }

		List<VariableParams> variables = new ArrayList<VariableParams>();
		// 认领任务
		JSONObject rtnJso = claimTask(taskID, userID, mode, userID);
		String resultCode = rtnJso.getString("CODE");
		// 完成任务
		if (resultCode.equals("OK")) {
			// 风控审核通过物流部门 签收数量
			VariableParams riskMgntApproved = new VariableParams();
			riskMgntApproved.setName("riskMgntApproved");
			riskMgntApproved.setValue(1);
			variables.add(riskMgntApproved);

			// 审核通过的同时，指定下一个任务节点的操作人员(风控普通操作员)
			VariableParams overFlowAdjustment = new VariableParams();
			overFlowAdjustment.setName("overFlowAdjustment");
			String roleCodes = BusinessEnumConstants.RoleType.ControlGeneralerRoleCode
					.getValue();
			overFlowAdjustment.setValue(this.getUser(roleCodes));
			variables.add(overFlowAdjustment);

			rtnJso = this.completeTask(variables, mode, userID, taskID);
			resultCode = rtnJso.getString("CODE");
			if (!resultCode.equals("OK")) {
				this.rollBack();
				returnCode = -1;
			} else {
				Integer[] userIds = this.getUserID(roleCodes);
				// 推送消息
				returnCode = this.pushMessage(mode, userIds, userID,
						"签收存在溢短，风控审核通过签收数量，请风控操作人员在必要情况下调整溢短金额",
						"app.deliveryDetail.riskControl", deliveryID);
				if (returnCode == -1) {
					this.rollBack();
					return returnCode;
				}
			}
		}
		return returnCode;
	}

	@Override
	public int confirmSignedQuantityBySeller(String deliveryID, String userName) {
		int returnCode = 0;
		// 风控审核签收数量--通过物流部门的签收数量,卖家确认
		returnCode = this.deliveryDAO.updateDeliveryStatus(50, deliveryID,
				userName);
		if (returnCode == -1)
			this.rollBack();
		return returnCode;
	}

	/**
	 * 签收存在溢短，需风控介入审核 风控审核签收数量--拒绝
	 */
	@Override
	public int reviewNotPassedDeliverySignedQuantity(String deliveryID,
			String userName, String taskID, String mode, String userID) {
		int returnCode = 0;
		Delivery delivery = this.deliveryDAO.getDeliveryByID(deliveryID);
		returnCode = this.deliveryDAO.updateDeliveryStatus(45, deliveryID,
				userName);
		if (!(returnCode >= 0)) {
			this.rollBack();
			return returnCode;
		}

		Order order = this.deliveryDAO.getOrderByDeliveryID(deliveryID);
		returnCode = this.updateOrderTradeStatus(order.getOrderId(), mode,
				delivery.getDeliveryType());
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}
		// 订单状态 35 风控拒绝
		// String statusConditions = "(35,40,50,55,60,65)";
		// boolean flag = this.compareDeliveryStatus(order.getOrderId(),
		// statusConditions);
		// if (flag) {
		// this.deliveryDAO.finishedOrder(35, order.getOrderId());
		// }

		List<VariableParams> variables = new ArrayList<VariableParams>();
		// 认领任务
		JSONObject rtnJso = claimTask(taskID, userID, mode, userID);
		String resultCode = rtnJso.getString("CODE");
		// 完成任务
		if (resultCode.equals("OK")) {
			// 风控审核拒绝物流部门 签收数量
			VariableParams riskMgntApproved = new VariableParams();
			riskMgntApproved.setName("riskMgntApproved");
			riskMgntApproved.setValue(0);
			variables.add(riskMgntApproved);

			// 审核拒绝的同时，指定下一个任务节点的操作人员(物流调整实价发货数量：物流普通操作员)
			VariableParams amountAdjustment = new VariableParams();
			amountAdjustment.setName("amountAdjustment");
			String roleCodes = BusinessEnumConstants.RoleType.LogisticsGeneralerRoleCode
					.getValue();
			amountAdjustment.setValue(this.getUser(roleCodes));
			variables.add(amountAdjustment);

			rtnJso = this.completeTask(variables, mode, userID, taskID);
			resultCode = rtnJso.getString("CODE");
			if (!resultCode.equals("OK")) {
				this.rollBack();
				returnCode = -1;
			} else {
				Integer[] userIds = this.getUserID(roleCodes);
				// 推送消息
				returnCode = this.pushMessage(mode, userIds, userID,
						"签收存在溢短，风控拒绝通过签收数量，请物流操作人员重新调整实际发货数量",
						"app.deliveryDetail.logistic", deliveryID);
				if (returnCode == -1) {
					this.rollBack();
					return returnCode;
				}
			}
		}
		return returnCode;
	}

	/**
	 * 物流部门 把交收单撤销失效
	 */
	@Override
	public int disabledNormalDelivery(String deliveryID, String userName) {
		// 交收数量DeliveryQuantity 置为0，DISABLED 失效 0：正常，1：失效
		int returnCode = 0;
		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryID);
		int deliveryQuantity = delivery.getDeliveryQuantity();
		returnCode = this.deliveryDAO.disabledDelivery(deliveryID, userName);
		Order order = this.deliveryDAO.getOrderByDeliveryID(deliveryID);
		if (returnCode >= 0) {
			returnCode = this.deliveryDAO.updateDeliveryQuantity(
					order.getOrderId(), -deliveryQuantity, userName);
			if (returnCode >= 0) {
				// 订单状态更新为"10 交收处理中"
				returnCode = this.deliveryDAO.finishedOrder(10,
						order.getOrderId());
				if (returnCode == -1) {
					this.rollBack();
				}
				// 需求变更，在撤销时不退运费.
				// 获取 配送运费资金表详情
				// DeliveryFreightFee deliveryFrightFee =
				// deliveryDAO.selectDeliveryFrightFeeByDeliveryID(deliveryID);
				// if (deliveryFrightFee != null){
				// if (deliveryFrightFee.getPaidSellFreight().compareTo(new
				// BigDecimal(0)) > 0){
				//
				// int count =
				// deliveryDAO.disabledDeliveryFreightFeeByDeliveryID(userName,
				// deliveryID);
				// if (count > 0){
				// Integer code =
				// this.voucherMgr.createNewOldVoucher(Constants.VOUCHERMODE_TUI_YUNFEI,
				// deliveryFrightFee.getPaidSellFreight(),
				// deliveryID,delivery.getBuyFirmId() , "退买家运费", userName);
				// if (code < 0){
				// this.rollBack();
				// }
				// }
				// }
				// }
			} else {
				this.rollBack();
				returnCode = -1;
			}
		} else {
			this.rollBack();
			returnCode = -1;
		}

		return returnCode;
	}

	/**
	 * 风控部门 把客户违约交收单撤销
	 */
	@Override
	public int disabledUnNormalDelivery(String unNormalApplyID) {
		int returnCode = 0;
		returnCode = this.deliveryDAO.disabledUnNormalDelivery(unNormalApplyID);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}
		return returnCode;
	}

	/**
	 * 客户申请违约 后台确认通过(调整实际能够违约的数量)
	 * 
	 * @throws ParseException
	 * @throws RuntimeException
	 */
	@Override
	public int confirmUnNormalDelivery(JSONArray breachContractApplyArray,
			String userName, String mode) throws RuntimeException,
			ParseException {

		this.log.debug("confirmUnNormalDelivery Start");
		int returnCode = 0;

		orderMgr = (IOrderManager) TradeSysData
				.getBean(Constants.BEAN_ORDERMGR_MGR);

		returnCode = DeliveryExpenseUtil.addViolationDelivery(
				breachContractApplyArray, userName, mode, orderDAO,
				deliveryDAO, log, orderMgr, this);

		return returnCode;
	}

	/**
	 * 风控部门 调整溢短金额"申请审核"
	 */
	@Override
	public int submitOverLordMoney(String deliveryID, String userName,
			String mode, String userID, String taskID) {
		this.log.info(this.getClass().getName()
				+ " component submitOverLordMoney Start");
		int returnCode = 0;
		returnCode = updateDeliveryTailAdjustStatus(5, deliveryID);

		List<VariableParams> variables = new ArrayList<VariableParams>();
		// 认领任务 "申请任务"
		JSONObject rtnJso = claimTask(taskID, userID, mode, userID);
		String resultCode = rtnJso.getString("CODE");
		if (resultCode.equals("OK")) {
			// 指定下一个任务节点的操作人员 去"提交审核"(风控审核人员)
			VariableParams tailAdjustVerify = new VariableParams();
			tailAdjustVerify.setName("tailAdjustVerify");
			String roleCodes = BusinessEnumConstants.RoleType.ControlAuditRoleCode
					.getValue();
			tailAdjustVerify.setValue(this.getUser(roleCodes));
			variables.add(tailAdjustVerify);

			rtnJso = this.completeTask(variables, mode, userID, taskID);
			resultCode = rtnJso.getString("CODE");
			if (!resultCode.equals("OK")) {
				this.rollBack();
				returnCode = -1;
			} else {
				Integer[] userIds = this.getUserID(roleCodes);
				// 推送消息
				returnCode = this.pushMessage(mode, userIds, userID,
						"金额调整提请审核，请风控审核人员在审核溢短金额",
						"app.deliveryDetail.riskControl", deliveryID);
				if (returnCode == -1)
					this.rollBack();
			}
		}
		return returnCode;
	}

	/**
	 * 风控审核 通过溢短金额 直接扣款 交收完成
	 */
	@Override
	public int reviewPassedOverLordMoney(String deliveryID, String userName,
			String mode, String userID, String taskID) {
		int returnCode;
		Order order = this.deliveryDAO.getOrderByDeliveryID(deliveryID);
		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryID);
		// 尾调状态
		returnCode = this.updateDeliveryTailAdjustStatus(10, deliveryID);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}
		// 交收状态 "交易完成"
		returnCode = this.deliveryDAO.updateDeliveryStatus(55, deliveryID,
				userName);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}

		returnCode = this.updateOrderTradeStatus(order.getOrderId(), mode,
				delivery.getDeliveryType());
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}
		// // 订单状态
		// String statusConditions = "(55,60,65)";
		// boolean flag = this.compareDeliveryStatus(order.getOrderId(),
		// statusConditions);
		// if (flag) {
		// this.deliveryDAO.finishedOrder(50, order.getOrderId());
		// }

		// 审核通过，处理溢短金额
		returnCode = this.adjustOverShortExpense(delivery.getOverloadFee(),
				deliveryID, userName);
		if (returnCode < 0) {
			this.rollBack();
			return returnCode;
		}
		returnCode = this.refundment(order, delivery, userName,
				Common.getGoodsType(order.getTradeType()));
		if (returnCode < 0) {
			this.rollBack();
			return returnCode;
		}
		// 处理【运费调整额】
		returnCode = this.backOverloadFreightToBuyer(delivery.getDeliveryID(),
				userName);
		if (returnCode < 0) {
			this.rollBack();
			if(returnCode == -1){
				return -60004;// 退买家运费调整额失败
			}else if(returnCode == -2){
				return -60005;// 收卖家运费调整额失败
			}else{
				return -60006;// 收卖家,退买家运费调整额异常
			}
		}
		if (returnCode >= 0) {
			List<VariableParams> variables = new ArrayList<VariableParams>();
			// 认领任务
			JSONObject rtnJso = claimTask(taskID, userID, mode, userID);
			String resultCode = rtnJso.getString("CODE");
			if (resultCode.equals("OK")) {

				// 审核通过 完成流程
				VariableParams tailAdjustApproved = new VariableParams();
				tailAdjustApproved.setName("tailAdjustApproved");
				tailAdjustApproved.setValue(1);
				variables.add(tailAdjustApproved);

				rtnJso = this.completeTask(variables, mode, userID, taskID);
				resultCode = rtnJso.getString("CODE");
				if (!resultCode.equals("OK")) {
					this.rollBack();
					returnCode = -1;
				}
			}
		} else {
			this.rollBack();
		}
		return returnCode;
	}

	// 退给买家运费调整额
	private int backOverloadFreightToBuyer(String deliveryId, String userId) {
		int resultCode = 0;
		try {
			// 不是违约 就是溢短
			Delivery deliveryTemp = deliveryDAO.getDeliveryByID(deliveryId);
			if (deliveryTemp != null) {
				Integer deliveryStatus = deliveryTemp.getDeliveryStatus();
				if (deliveryStatus != null
						&& (deliveryStatus == 60 || deliveryStatus == 65)) {
					BreachContractApply breachContractApply = deliveryDAO
							.getBreachContractApplyByDeliveryID(deliveryId);
					if (breachContractApply != null) {
						String historyDeliveryID = breachContractApply
								.getHistoryDeliveryID();
						deliveryId = historyDeliveryID;
					}
				}
			}

			DeliveryFreightFee deliveryFreightFee = this.deliveryDAO.getDeliveryFreightFee(deliveryId);
			if (deliveryFreightFee != null) {
				Delivery delivery = deliveryDAO.getDeliveryDetail(deliveryId);
				if (deliveryFreightFee.getOverloadFreight() != null && deliveryFreightFee.getOverloadFreight().compareTo(new BigDecimal(0)) < 0) {
					
					BigDecimal overloadFreight = deliveryFreightFee.getOverloadFreight().negate();
					// 收卖家运费调整额
					int code1 = this.voucherMgr.createNewOldVoucher(
							Constants.VOUCHERMODE_SHOU_YUNFEI, overloadFreight,
							deliveryId, delivery.getSellFirmId(), "收卖家运费调整额",
							userId);
					
					if (code1 < 0){
						// 收卖家运费失败
						resultCode = -2;
						this.log.businesslog("风控审核 收卖家运费调整额: " + deliveryId
								+ " 失败", Constants.OPE_MODE_TRADE,
								Constants.OPE_FAIL);
					}else{
						this.log.businesslog("风控审核 收卖家运费调整额: " + deliveryId
								+ " 成功", Constants.OPE_MODE_TRADE,
								Constants.OPE_SUCCESS);
						// 退给买家运费调整额
						int code2 = this.voucherMgr.createNewOldVoucher(
								Constants.VOUCHERMODE_TUI_YUNFEI, overloadFreight,
								deliveryId, delivery.getBuyFirmId(), "退买家运费调整额",
								userId);
						if (code2 < 0) {
							this.log.businesslog("风控审核 退买家运费调整额: " + deliveryId
									+ " 失败", Constants.OPE_MODE_TRADE,
									Constants.OPE_FAIL);
							// 退买家运费失败
							resultCode = -1;
						} else {
							this.log.businesslog("风控审核 通过运费调整额: " + deliveryId
									+ " 成功", Constants.OPE_MODE_TRADE,
									Constants.OPE_SUCCESS);
						}
					}
				}
			}

		} catch (Exception e) {
			this.log.error("收/退 运费调整额失败" + e.getMessage());
			resultCode = -3;
		}
		return resultCode;

	}

	/**
	 * 风控审核 拒绝溢短金额
	 */
	@Override
	public int reviewNotPassedOverLordMoney(String deliveryID, String userName,
			String mode, String userID, String taskID) {
		int returnCode;
		// 尾调状态 审核拒绝
		returnCode = this.updateDeliveryTailAdjustStatus(15, deliveryID);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}
		List<VariableParams> variables = new ArrayList<VariableParams>();
		// 认领任务
		JSONObject rtnJso = claimTask(taskID, userID, mode, userID);
		String resultCode = rtnJso.getString("CODE");
		if (resultCode.equals("OK")) {
			// 审核拒绝 完成流程
			VariableParams tailAdjustApproved = new VariableParams();
			tailAdjustApproved.setName("tailAdjustApproved");
			tailAdjustApproved.setValue(0);
			variables.add(tailAdjustApproved);

			// 指定下一节点操作人员(风控普通操作员)
			VariableParams overFlowAdjustment = new VariableParams();
			overFlowAdjustment.setName("overFlowAdjustment");
			String roleCodes = BusinessEnumConstants.RoleType.ControlGeneralerRoleCode
					.getValue();
			overFlowAdjustment.setValue(this.getUser(roleCodes));
			variables.add(overFlowAdjustment);

			rtnJso = this.completeTask(variables, mode, userID, taskID);
			resultCode = rtnJso.getString("CODE");
			if (!resultCode.equals("OK")) {
				this.rollBack();
				returnCode = -1;
			} else {
				Integer[] userIds = this.getUserID(roleCodes);
				// 推送消息
				returnCode = this.pushMessage(mode, userIds, userID,
						"风控审核 拒绝溢短金额，请风控操作人员在必要情况下重新调整溢短金额",
						"app.deliveryDetail.riskControl", deliveryID);
				if (returnCode == -1)
					this.rollBack();
			}
		} else {
			this.rollBack();
			returnCode = -1;
		}
		return returnCode;
	}

	/**
	 * 风控部门 审核通过 收违约金/付违约金
	 * 
	 * @param deliveryID
	 * @param userName
	 * @return
	 */
	@Override
	public int passedDeleveryPenalty(String deliveryID, String userName,
			String taskId, String mode, String userID) {
		this.log.info(this.getClass().getName()
				+ " component passedDeleveryPenalty Start");
		int returnCode = 0;
		Order order = this.deliveryDAO.getOrderByDeliveryID(deliveryID);
		returnCode = adjustViolationPenalty(deliveryID, userName,
				Common.getGoodsType(order.getTradeType()));

		if (returnCode < 0) {
			this.rollBack();
			return returnCode;
		}
		// 收/退 卖家、买家运费调整额
		returnCode = this.backOverloadFreightToBuyer(deliveryID, userName);
		if (returnCode < 0) {
			this.rollBack();
			if(returnCode == -1){
				return -60004;// 退买家运费调整额失败
			}else if(returnCode == -2){
				return -60005;// 收卖家运费调整额失败
			}else{
				return -60006;// 收卖家,退买家运费调整额异常
			}
		}

		if (returnCode >= 0) {
			// 更新尾调状态
			returnCode = this.updateDeliveryTailAdjustStatus(10, deliveryID);
			if (returnCode == -1)
				return returnCode;
			List<VariableParams> variables = new ArrayList<VariableParams>();
			// 认领任务
			JSONObject rtnJso = claimTask(taskId, userID, mode, userID);
			String resultCode = rtnJso.getString("CODE");
			if (resultCode.equals("OK")) {
				// 是否通过
				VariableParams tailAdjustApproved = new VariableParams();
				tailAdjustApproved.setName("tailAdjustApproved");
				tailAdjustApproved.setValue(1);
				variables.add(tailAdjustApproved);

				rtnJso = this.completeTask(variables, mode, userID, taskId);
				resultCode = rtnJso.getString("CODE");
				if (!resultCode.equals("OK")) {
					this.rollBack();
					returnCode = -1;
				}
			}
		}
		this.log.info(this.getClass().getName()
				+ " component passedDeleveryPenalty Start");
		return returnCode;
	}

	@Override
	public int refusedDeleveryPenalty(String deliveryID, String userName,
			String taskId, String mode, String userID) {
		int returnCode = 0;
		returnCode = this.updateDeliveryTailAdjustStatus(15, deliveryID);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode = -1;
		}
		if (returnCode >= 0) {
			// 更新尾调状态
			List<VariableParams> variables = new ArrayList<VariableParams>();
			// 认领任务
			JSONObject rtnJso = claimTask(taskId, userID, mode, userID);
			String resultCode = rtnJso.getString("CODE");
			if (resultCode.equals("OK")) {
				// 是否通过
				VariableParams tailAdjustApproved = new VariableParams();
				tailAdjustApproved.setName("tailAdjustApproved");
				tailAdjustApproved.setValue(0);
				variables.add(tailAdjustApproved);

				// 指定下一个节点(风控普通操作员)
				VariableParams tailAdjustModifyUsers = new VariableParams();
				tailAdjustModifyUsers.setName("tailAdjustModifyUsers");
				String roleCodes = BusinessEnumConstants.RoleType.ControlGeneralerRoleCode
						.getValue();
				tailAdjustModifyUsers.setValue(this.getUser(roleCodes));
				variables.add(tailAdjustModifyUsers);

				rtnJso = this.completeTask(variables, mode, userID, taskId);
				resultCode = rtnJso.getString("CODE");
				if (!resultCode.equals("OK")) {
					this.rollBack();
					returnCode = -1;
				} else {
					Integer[] userIds = this.getUserID(roleCodes);
					// 推送消息
					returnCode = this.pushMessage(mode, userIds, userID,
							"风控审核拒接尾调，请风控操作人员在必要情况下重新调整后申请",
							"app.deliveryDetail.riskControl", deliveryID);
					if (returnCode == -1)
						this.rollBack();
				}
			}
		}
		this.log.info(this.getClass().getName()
				+ " component passedDeleveryPenalty Start");
		return returnCode;
	}

	@Override
	public int updateOrderTradeStatus(String orderID, String mode,
			Integer deliveryType) {
		this.log.info(this.getClass().getName()
				+ " updateOrderTradeStatus Component Start");
		int returnCode = 0;
		Order order = this.deliveryDAO.getOrderByID(orderID);
		int quantity = order.getQuantity();// 成交数量
		int deliveryQuantity = this.deliveryDAO.getDeliveryQuantity(order
				.getOrderId());// 已申请交收数量（批）
		int deliverySinopecQuantity = this.deliveryDAO
				.getDeliverySinopecQuantity(orderID);
		try {
			DealStatus dealStatus = findOrderStatusFormDrools(
					order.getOrderId(), mode, quantity, deliveryQuantity,
					deliveryType, deliverySinopecQuantity);
			// 对订单状态进行更新
			if (dealStatus != null)
				returnCode = this.deliveryDAO.finishedOrder(
						dealStatus.getBackendCode(), order.getOrderId());
			if (dealStatus == null)
				returnCode = -1;
		} catch (Exception e) {
			this.log.error(" updateOrderTradeStatus失败：" + e.toString());
			this.rollBack();
			return returnCode = -1;
		}
		this.log.info(this.getClass().getName()
				+ " updateOrderTradeStatus Component End");
		return returnCode;
	}

	public static void main(String[] args) throws IOException {

		Date currentDate = new Date();
		Date deliveryDate = new Date();

		Calendar calendar = new GregorianCalendar();
		calendar.setTime(deliveryDate);
		calendar.add(calendar.DATE, 1);// 把日期往后增加一天.整数往后推,负数往前移动
		deliveryDate = calendar.getTime(); // 这个时间就是日期往后推一天的结果
		System.err.println(currentDate);
		System.err.println(deliveryDate);
		System.err.println(currentDate.getTime() == deliveryDate.getTime());

		// 设置规则引擎的参数
		DeliveryExpense requestbean = new DeliveryExpense();
		requestbean.setIsLastDelivery(false);
		requestbean.setDeliveryQuantity(2);
		requestbean.setOrderID("CJ1612050001");
		String mode = "local";
		requestbean.setMode(mode);

		try {
			// 调用规则引擎
			DealStatusPost post = new DealStatusPost();
			JSONObject rtn = post.postDeliveryExpenseDrools(requestbean, mode);
			
			JSONObject data = new JSONObject(rtn.getString("DATA"));
			String outParams = data.getString("deliveryOutParams");
			
			System.err.println(outParams);
			outParams = outParams.replace(" ", "");
			JSONObject JSONObject = new JSONObject(outParams.trim());
			DeliveryOutParams deliveryOutParams = (DeliveryOutParams) JsonUtil.jsonToBean(JSONObject,DeliveryOutParams.class);
//			System.err.println(data.get("sellTakenSSDeposit"));
//			System.err.println(deliveryOutParams==null?"没有返回值":deliveryOutParams.toString());
			System.err.println(deliveryOutParams);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}

	}

	/**
	 * 获取成交的状态
	 * 
	 * @param orderID
	 *            订单ID
	 * @param mode
	 * @param orderQuantity
	 * @param delieveryQuantity
	 * @param deliverySinopecQuantity
	 * @return
	 */
	@Override
	public DealStatus findOrderStatusFormDrools(String orderID, String mode,
			Integer orderQuantity, Integer delieveryQuantity, int deliveryType,
			int deliverySinopecQuantity) {
		this.log.info(this.getClass().getName()
				+ " component findOrderStatusFormDrools Start");
		List<String> deliveryStatusList = null;
		try {
			// 根据OrderID取得交收状态列表
			deliveryStatusList = deliveryDAO_read
					.findDeliveryStatusByOrderId(orderID);

			if (deliveryStatusList == null || deliveryStatusList.size() == 0) {
				this.log.info(this.getClass().getName()
						+ " component 根据orderID:" + orderID + ",未查询出交收状态列表数据！");
				return null;
			}
		} catch (Exception e) {
			this.log.error(this.getClass().getName() + " component 根据orderID:"
					+ orderID + ",查询交收状态列表失败！");
			this.log.error(e.getMessage());
			return null;
		}

		if (orderQuantity == null || delieveryQuantity == null) {
			try {
				Order order = orderDAO_read.getOrderByID(orderID);
				if (order == null) {
					this.log.error(this.getClass().getName()
							+ " component 根据orderID:" + orderID + ",未查询出订单信息！");
					return null;
				}
				orderQuantity = order.getQuantity(); // 成交数量（批）
				delieveryQuantity = order.getDeliveryQuantity(); // 已申请交收数量（批）
			} catch (Exception e) {
				this.log.error(this.getClass().getName()
						+ " component 根据orderID:" + orderID + ",查询订单信息失败！");
				this.log.error(e.getMessage());
				return null;
			}
		}
		// 设置规则引擎的参数
		DealStatus requestbean = new DealStatus();
		requestbean.setLsDeliveryStatus(deliveryStatusList);
		requestbean.setOrderQuantity(orderQuantity);
		requestbean.setDelieveryQuantity(delieveryQuantity);
		requestbean.setDeliveryType(deliveryType);
		requestbean.setDeliverySinopecQuantity(deliverySinopecQuantity);
		if (mode == null || "".equals(mode)) {
			mode = this.getMode();
		}

		// 设定返回参数
		DealStatus resultbean = new DealStatus();
		try {
			// 调用规则引擎
			DealStatusPost post = new DealStatusPost();
			JSONObject rtn = post.postDealStatusDrools(requestbean, mode);
			String code = rtn.getString("CODE");
			if (!"00000".equals(code)) {
				this.log.error(this.getClass().getName()
						+ "component 调用规则引擎失败,规则引擎返回CODE：" + code);
				return null;
			}
			JSONObject data = new JSONObject(rtn.getString("DATA"));
			resultbean.setProcessPoint(data.getInt("processPoint"));
			resultbean.setBackendCode(data.getInt("backendCode"));
			resultbean.setBackendStatus(data.getString("backendStatus"));
			JSONArray lsDeliveryStatus = data.getJSONArray("lsDeliveryStatus");

			List<String> deliveryStatusResultList = new ArrayList<String>();
			int lsDeliveryStatusLength = lsDeliveryStatus.length();
			if (lsDeliveryStatusLength > 0) {
				for (int i = 0; i < lsDeliveryStatusLength; i++) {
					deliveryStatusResultList.add((String) lsDeliveryStatus
							.get(i));
				}
			}
			resultbean.setLsDeliveryStatus(deliveryStatusResultList);
			resultbean.setBuyerStatus(data.getString("buyerStatus"));
			resultbean.setSellerStatus(data.getString("sellerStatus"));
		} catch (Exception e) {
			this.log.error(this.getClass().getName() + "component 调用规则引擎异常!");
			this.log.error(e.getMessage());
			return null;
		}

		this.log.info(this.getClass().getName()
				+ " component findOrderStatusFormDrools End");
		return resultbean;
	}

	/**
	 * 某笔成交单可以申请交收的数量
	 * 
	 * @param OrderID
	 * @return
	 */
	private int getCanDeliveryQuantity(String OrderID) {
		this.log.info(this.getClass().getName()
				+ "getCanDeliveryQuantity Component Start");
		Order order = this.deliveryDAO.getOrderByID(OrderID);
		int canDeliveryQuantity = order.getQuantity()
				- order.getDeliveryQuantity();
		this.log.info(this.getClass().getName()
				+ "getCanDeliveryQuantity Component End");
		return canDeliveryQuantity;
	}

	/**
	 * 存在溢短情况 :审核通过，处理溢短金额
	 * 
	 * @param overloadFeeSet
	 *            :风控调整的溢短金额
	 * @param deliveryID
	 * @return
	 */
	private int adjustOverShortExpense(BigDecimal overloadFee,
			String deliveryID, String userName) {
		int returnCode = 0;
		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryID);
		Order order = this.deliveryDAO.getOrderByDeliveryID(deliveryID);

		// 卖方交易已收手续费
	    BigDecimal sellTakenTradeFee = BigDecimalUtil.getBigDecimalNum(
	    		order.getSellTradeFee().subtract(order.getSellCouponTradeFee()),2);
	    // 订单总数量
	    BigDecimal totalQuantity = order.getTradeUnitNumber().multiply(
	        new BigDecimal(order.getQuantity()));
	    // 交收申请数量
	    BigDecimal applyQuantity = order.getTradeUnitNumber().multiply(
	        new BigDecimal(delivery.getDeliveryQuantity()));
	    // 签收数量
	    BigDecimal takenQuantity = delivery.getTakenQuantity();
	    // 溢短数量
	    BigDecimal overShortQuantity = BigDecimalUtil.getBigDecimalNum(
	        applyQuantity.subtract(takenQuantity), 6);

	    // 溢短部分 手续费
	    BigDecimal overShortCharge = overShortQuantity.multiply(
	        sellTakenTradeFee).divide(totalQuantity, 2,
	        BigDecimal.ROUND_HALF_UP);

		overloadFee = overloadFee.abs();
		// 化交付卖家货款 PaymentStatus 0：待付款 5：待审核 10：已付款 15: 已拒绝
		int paymentStatus = order.getPaymentStatus();
		if (paymentStatus == 10) {
			returnCode = this.deliveryDAO.updatePaidSellAmount(
					order.getOrderId(), overloadFee, userName);// 更新订单“已付卖方金额”
			if (returnCode == -1) {
				this.rollBack();
				return returnCode;
			}

			returnCode = this.deliveryDAO.updateSellTakenTradeFee(
					order.getOrderId(), overShortCharge, userName);// 更新订单“卖方交易已收手续费”
			if (returnCode == -1) {
				this.rollBack();
				return returnCode;
			}

			/**
			 * 收卖家货款
			 */
			returnCode = this.voucherMgr
					.createNewOldVoucher(Constants.VOUCHERMODE_SHOU_HUO_KUAN,
							overloadFee.subtract(overShortCharge), deliveryID,
							order.getSellFirmId(), "下家签收数量少于申请交收数量-收上家溢短部分货款",
							userName);
			if (returnCode < 0) {
				this.rollBack();
				return returnCode;
			}
		}

		returnCode = this.deliveryDAO.updatePaidAmount(order.getOrderId(),
				overloadFee, userName);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}
		/**
		 * 退买家货款
		 */
		returnCode = this.voucherMgr.createNewOldVoucher(
				Constants.VOUCHERMODE_FU_HUO_KUAN, overloadFee, deliveryID,
				order.getBuyFirmId(), "下家签收数量少于申请交收数量-退下家溢短部分货款", userName);

		// /**
		// * 退卖家溢短部分 手续费
		// */
		// if (returnCode >= 0)
		// returnCode = this.voucherMgr.createNewOldVoucher(
		// Constants.VOUCHERMODE_TUI_JIAOYI_SHOUXUFEI,
		// overShortCharge, deliveryID, order.getBuyFirmId(),
		// "下家签收数量少于申请交收数量-退下家溢短部分手续费", userName);

		return returnCode;

	}

	/**
	 * 风控部门审核通过 :收违约金/付违约金
	 * 
	 * a 买家违约 1收买家违约金 2 付卖家违约金 3退买家违约部分数量 手续费
	 * 
	 * b 卖家违约 1收卖家违约金2 付买家违约金 3退违约部分货款给买家
	 * 
	 * @param deliveryID
	 * @param userName
	 * @param goodTypes
	 * @return
	 */
	private int adjustViolationPenalty(String deliveryID, String userName,
			Integer goodTypes) {
		int returnCode = 0;
		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryID);
		Order order = this.deliveryDAO.getOrderByDeliveryID(deliveryID);

		int deliveryStatus = delivery.getDeliveryStatus();// 违约方 60 买家违约 65 卖家违约

		// 卖方交收应扣保证金
		BigDecimal sellSettleDeposit = delivery.getSellSettleDeposit();
		// 卖方交收已扣保证金
		BigDecimal sellTakenSSDeposit = delivery.getSellTakenSSDeposit();
		// 买方交收已扣保证金
		BigDecimal takenBSDeposit = delivery.getTakenBSDeposit();
		// 卖方交收应扣违约金
		BigDecimal sellPenalty = delivery.getSellPenalty();

		// 买方交收已扣违约金
		BigDecimal takenBuyPenalty = delivery.getTakenBuyPenalty();

		// 买方交收应扣违约金
		BigDecimal buyPenalty = delivery.getBuyPenalty();
		// 应付卖方违约金 ShouldPaySellPenalty
		BigDecimal shouldPaySellPenalty = delivery.getShouldPaySellPenalty();
		// 应付买方违约金 ShouldPayBuyPenalty
		BigDecimal shouldPayBuyPenalty = delivery.getShouldPayBuyPenalty();

		if (deliveryStatus == 60) {// 买家违约
			// 更新已付卖方违约金
			returnCode = this.deliveryDAO.updatePaidSellPenalty(deliveryID,
					shouldPaySellPenalty, userName);
			if (returnCode == -1)
				return returnCode;
			// 更新买方交收已扣违约金 TakenBuyPenalty
			returnCode = this.deliveryDAO.updateTakenBuyPenalty(buyPenalty,
					deliveryID, userName);
			if (returnCode == -1) {
				this.rollBack();
				return returnCode;
			}

			/**
			 * ################## 卖方保证金（含流水）Start######################
			 */
			// 卖家使用授信的金额 ：卖方交收应收保证金-卖方交收已收保证金
			BigDecimal sellCreditDeposit = sellSettleDeposit
					.subtract(sellTakenSSDeposit);

			// 更新订单 卖方交收保证金授信金额 SellCreditDeposit
			returnCode = this.deliveryDAO.updateOrderSellCreditDeposit(
					order.getOrderId(), sellCreditDeposit);
			if (returnCode == -1) {
				this.rollBack();
				return returnCode;
			}

			// 订单 卖方交易已收保证金:SellTakenTradeDeposit
			returnCode = this.deliveryDAO.updateSellTakenTradeDeposit(
					order.getOrderId(), sellTakenSSDeposit, userName);
			if (returnCode == -1) {
				this.rollBack();
				return returnCode;
			}
			// 退保证金给卖家
			if (returnCode >= 0)
				returnCode = this.voucherMgr.createNewOldVoucher(
						Constants.VOUCHERMODE_TUI_JIAOSHOU_BAOZHENGJING,
						sellTakenSSDeposit, deliveryID,
						delivery.getSellFirmId(), "退保证金给卖家", userName);
			Firmfunds firmfundsell = this.deliveryDAO
					.getBuyFirmfundsByDeliveryID(delivery.getSellFirmId());
			BigDecimal bALANCESell = firmfundsell.getBALANCE();
			if (sellPenalty.compareTo(bALANCESell) > 0) {
				this.rollBack();
				return -23007;
			}

			sApplyManagerImpl = (ISApplayManager) FinanceSysData
					.getBean(Constants.BEAN_SAPPLYMGR_MGR);
			/**
			 * 释放授信流水
			 */
			try {
				if (goodTypes == 0) { // 现货
					returnCode = sApplyManagerImpl.backMargin(
							order.getSellFirmId(), sellCreditDeposit,
							deliveryID, 3);
				} else {// 预售
					returnCode = sApplyManagerImpl.backMarginForPreSale(
							order.getSellFirmId(), sellCreditDeposit,
							deliveryID, 3);
				}

			} catch (Exception e) {
				returnCode = -1;
				this.rollBack();
				return returnCode;
			}

			/**
			 * ################## 卖方保证金（含流水）End######################
			 */

			// 买家未付化交 是整体违约
			BigDecimal paidAmount = order.getPaidAmount();
			if (paidAmount.compareTo(new BigDecimal(0)) <= 0) {// 货款都未收到
				// 买家未付货款，买家违约，退还买家交收保证金
				returnCode = this.deliveryDAO.updateBuyTakenTradeDeposit(
						order.getOrderId(), takenBSDeposit, userName);// 更新订单“买方交收已收保证金”
				if (returnCode == -1) {
					this.rollBack();
					return returnCode;
				}
				// 退保证金给买家
				returnCode = this.voucherMgr.createNewOldVoucher(
						Constants.VOUCHERMODE_TUI_JIAOSHOU_BAOZHENGJING,
						takenBSDeposit, deliveryID, delivery.getBuyFirmId(),
						"退保证金给买家", userName);

				Firmfunds firmfunds = this.deliveryDAO
						.getBuyFirmfundsByDeliveryID(delivery.getBuyFirmId());
				BigDecimal bALANCE = firmfunds.getBALANCE();
				if (shouldPaySellPenalty.compareTo(bALANCE) > 0) {
					this.rollBack();
					return -23002;
				}

				// 收买家违约金
				if (returnCode >= 0)
					returnCode = this.voucherMgr.createNewOldVoucher(
							Constants.VOUCHERMODE_SHOU_WEIYUEJIN, buyPenalty,
							deliveryID, delivery.getBuyFirmId(), "买家违约，收买家违约金",
							userName);

				// 付卖家违约金
				if (returnCode >= 0)
					returnCode = this.voucherMgr.createNewOldVoucher(
							Constants.VOUCHERMODE_TUI_WEIYUEJIN,
							delivery.getShouldPaySellPenalty(), deliveryID,
							delivery.getSellFirmId(), "买家违约,付卖家违约金", userName);

				returnCode = this.deliveryDAO.updatePaidSellPenalty(deliveryID,
						delivery.getShouldPaySellPenalty(), userName);

			} else {// 买家已付化交 如果化交付款给卖家 需要卖家退货款给化交
				returnCode = this.deliveryDAO.updatePaidAmount(
						order.getOrderId(), delivery.getTakenMoney(), userName);// 更新订单“成交买家已付金额”
				if (returnCode == -1) {
					this.rollBack();
					return returnCode;
				}
				returnCode = this.deliveryDAO.updateBuyTakenTradeFee(
						order.getOrderId(), delivery.getTakenBSFee(), userName);// 更新订单“买方交易已收手续费”
				if (returnCode == -1) {
					this.rollBack();
					return returnCode;
				}

				BigDecimal payedMoney = delivery.getPayedMoney();// 如果化交付款给卖家
																	// 需要卖家退货款给化交

				// 0：待付款 5：待审核 10：已付款 15: 已拒绝
				int paymentStatus = order.getPaymentStatus();

				if (paymentStatus == 10) {
					returnCode = this.deliveryDAO.updatePaidSellAmount(
							order.getOrderId(), payedMoney, userName);// 更新订单“已付卖方金额”
					if (returnCode == -1) {
						this.rollBack();
						return returnCode;
					}

					returnCode = this.voucherMgr.createNewOldVoucher(
							Constants.VOUCHERMODE_SHOU_HUO_KUAN, payedMoney,
							deliveryID, delivery.getSellFirmId(),
							"买家违约，卖家退货款给化交(收交易商货款)", userName);
				}

				// 收买家违约金
				if (returnCode >= 0)
					returnCode = this.voucherMgr.createNewOldVoucher(
							Constants.VOUCHERMODE_SHOU_WEIYUEJIN, buyPenalty,
							deliveryID, delivery.getBuyFirmId(), "买家违约，收买家违约金",
							userName);

				// 付卖家违约金
				if (returnCode >= 0)
					returnCode = this.voucherMgr.createNewOldVoucher(
							Constants.VOUCHERMODE_TUI_WEIYUEJIN,
							shouldPaySellPenalty, deliveryID,
							delivery.getSellFirmId(), "买家违约,付卖家违约金", userName);

				// 化交退货款给买家（含手续费）
				if (returnCode >= 0)
					returnCode = this.voucherMgr.createNewOldVoucher(
							Constants.VOUCHERMODE_FU_HUO_KUAN,
							delivery.getTakenMoney().add(
									delivery.getTakenBSFee()), deliveryID,
							delivery.getBuyFirmId(), "买家违约，化交退货款给买家（含手续费）",
							userName);
				;
			}
		} else if (deliveryStatus == 65) {
			boolean isPayMoney = false;//买家是否付化交
			Firmfunds firmfunds_buy =  this.deliveryDAO
					.getBuyFirmfundsByDeliveryID(delivery.getBuyFirmId());
			BigDecimal buyTradeFee = order.getBuyTradeFee();
			BigDecimal shouldPayBuyPenaltyTemp = shouldPayBuyPenalty.add(firmfunds_buy.getBALANCE());
		
			if(buyTradeFee.compareTo(shouldPayBuyPenaltyTemp) > 0){
				return -23022;
			}
			
			// 更新已付买方违约金
			returnCode = this.deliveryDAO.updatePaidBuyPenalty(deliveryID,
					shouldPayBuyPenalty, userName);
			if (returnCode == -1)
				return returnCode;
			// 更新卖方交收已扣违约金 TakenSellPenalty
			returnCode = this.deliveryDAO.updateTakenSellPenalty(sellPenalty,//
					deliveryID, userName);
			if (returnCode == -1)
				return returnCode;

			// 更新订单 卖方交易已收保证金 SellTakenTradeDeposit
			returnCode = this.deliveryDAO.updateOrderSellTakenTradeDeposit(
					order.getOrderId(), sellTakenSSDeposit);
			if (returnCode == -1) {
				this.rollBack();
				return returnCode;
			}

			// 卖家使用授信的金额
			BigDecimal sellCreditDeposit = sellSettleDeposit
					.subtract(sellTakenSSDeposit);

			// 更新订单 卖方交收保证金授信金额 SellCreditDeposit
			returnCode = this.deliveryDAO.updateOrderSellCreditDeposit(
					order.getOrderId(), sellCreditDeposit);
			if (returnCode == -1) {
				this.rollBack();
				return returnCode;
			}

			// 订单 卖方交易已收保证金:SellTakenTradeDeposit
//			 returnCode = this.deliveryDAO.updateSellTakenTradeDeposit(
//			 order.getOrderId(), sellTakenSSDeposit, userName);
//			 if (returnCode == -1) {
//				 this.rollBack();
//				 return returnCode;
//			 }
			// 退保证金给卖家
			if (returnCode >= 0)
				returnCode = this.voucherMgr.createNewOldVoucher(
						Constants.VOUCHERMODE_TUI_JIAOSHOU_BAOZHENGJING,
						sellTakenSSDeposit, deliveryID,
						delivery.getSellFirmId(), "退保证金给卖家", userName);
			Firmfunds firmfunds = this.deliveryDAO
					.getBuyFirmfundsByDeliveryID(delivery.getSellFirmId());
			BigDecimal bALANCE = firmfunds.getBALANCE();
			if (sellPenalty.compareTo(bALANCE) > 0) {
				this.rollBack();
				return -23007;
			}

			sApplyManagerImpl = (ISApplayManager) FinanceSysData
					.getBean(Constants.BEAN_SAPPLYMGR_MGR);
			/**
			 * 释放授信流水
			 */
			try {
				if (goodTypes == 0) { // 现货
					returnCode = sApplyManagerImpl.backMargin(
							order.getSellFirmId(), sellCreditDeposit,
							deliveryID, 3);
				} else {// 预售
					returnCode = sApplyManagerImpl.backMarginForPreSale(
							order.getSellFirmId(), sellCreditDeposit,
							deliveryID, 3);
				}
			} catch (Exception e) {
				returnCode = -1;
				this.rollBack();
				return returnCode;
			}

			// 化交已付卖家，需要卖家退货款给化交(手续费需要退给卖家，轧差：不扣手续费部分)
			BigDecimal payedMoney = delivery.getPayedMoney();// 已付上家货款

			// 0：待付款 5：待审核 10：已付款 15: 已拒绝
			int paymentStatus = order.getPaymentStatus();
			BigDecimal paidAmount = order.getPaidAmount();
			if (paymentStatus == 10) {
				// 买家已付化交，需要化交退款给买家
				returnCode = this.deliveryDAO.updatePaidAmount(
						order.getOrderId(), delivery.getTakenMoney(), userName);// 更新订单“成交买家已付金额”
				if (returnCode == -1) {
					this.rollBack();
					return returnCode;
				}
				
				returnCode = this.deliveryDAO.updatePaidSellAmount(
						order.getOrderId(), payedMoney, userName);// 更新订单“已付卖方金额”
				if (returnCode == -1) {
					this.rollBack();
					return returnCode;
				}

				BigDecimal violationPenalty = this.getViolationPenalty(
						delivery, order);
				returnCode = this.deliveryDAO.updateSellTakenTradeFee(//
						order.getOrderId(), violationPenalty, userName);// 更新订单“卖方交易已收手续费”

				if (returnCode == -1) {
					this.rollBack();
					return returnCode;
				}

				// 卖家违约，卖家手续费是在货款里退的（卖家退货款时候，少扣卖家手续费，就相当于退了卖家手续费）
				// 卖家退货款给化交
				returnCode = this.voucherMgr.createNewOldVoucher(
						Constants.VOUCHERMODE_SHOU_HUO_KUAN,
						payedMoney.subtract(violationPenalty), deliveryID,
						delivery.getSellFirmId(), "卖家违约，卖家退货款给化交(收交易商货款)",
						userName);
				// 退货款给买家
				if (returnCode >= 0)
					returnCode = this.voucherMgr.createNewOldVoucher(
							Constants.VOUCHERMODE_FU_HUO_KUAN,
							delivery.getTakenMoney(), deliveryID,
							delivery.getBuyFirmId(), "卖家违约，退货款给买家", userName);
				
				isPayMoney = true;
				
			} else if (paymentStatus != 10
					&& paidAmount.compareTo(new BigDecimal(0)) <= 0) {// 买家未付货款，卖家违约，退买家交收保证金
				// 买家未付货款，卖家违约，退买家交收保证金
				returnCode = this.deliveryDAO.updateBuyTakenTradeDeposit(
						order.getOrderId(), takenBSDeposit, userName);// 更新订单“买方交收已收保证金”
				if (returnCode == -1) {
					this.rollBack();
					return returnCode;
				}
				// 退保证金给买家
				returnCode = this.voucherMgr.createNewOldVoucher(
						Constants.VOUCHERMODE_TUI_JIAOSHOU_BAOZHENGJING,
						takenBSDeposit, deliveryID, delivery.getBuyFirmId(),
						"退保证金给买家", userName);
			} else {// 买家已付货款，化交没有付给卖家，卖家违约，退货款给买家（含买家保证金）
				returnCode = this.deliveryDAO.updatePaidAmount(
						order.getOrderId(), delivery.getTakenMoney(), userName);// 更新订单“成交买家已付金额”
				if (returnCode == -1) {
					this.rollBack();
					return returnCode;
				}
				// 退货款给买家
				if (returnCode >= 0)
					returnCode = this.voucherMgr.createNewOldVoucher(
							Constants.VOUCHERMODE_FU_HUO_KUAN,
							delivery.getTakenMoney(), deliveryID,
							delivery.getBuyFirmId(), "卖家违约，退货款给买家", userName);
				
				isPayMoney = true;
				
			}
			if (returnCode >= 0)
				// 收违约金
				returnCode = this.voucherMgr.createNewOldVoucher(
						Constants.VOUCHERMODE_SHOU_WEIYUEJIN, sellPenalty,
						deliveryID, delivery.getSellFirmId(), "卖家违约，收卖家违约金",
						userName);

			if (returnCode >= 0){
				
				returnCode = this.voucherMgr.createNewOldVoucher(
						Constants.VOUCHERMODE_TUI_WEIYUEJIN,
						shouldPayBuyPenalty, deliveryID,
						delivery.getBuyFirmId(), "卖家违约，付买家违约金", userName);
				if(returnCode < 0){
					this.log.error(this.getClass().getName()+"adjustViolationPenalty  卖家违约，付买家违约金失败");
					return -1;
				}
				Integer deliveryQuantitys = this.deliveryDAO.getDeliveryQuantitys(order.getOrderId());
				int orderQuantity = order.getQuantity();
				this.log.info(this.getClass().getName()+" 买家未付货款，卖家违约,交收数量："+deliveryQuantitys+" 订单数量："+orderQuantity);
				if(orderQuantity == deliveryQuantitys && !isPayMoney){//卖家违约
					this.log.info(this.getClass().getName()+" 买家未付货款，卖家违约,买家得到卖家违约金 :【"+shouldPayBuyPenalty+"】 开始收买家手续费");
					voucherMgr = (IVoucherManager) FinanceSysData
							.getBean(Constants.BEAN_VOUCHER_MGR);
					
					/**
					 * 买家未付化交，卖家违约，要收取买家手续费 add by zhangnan 2017-03-03 下午
					 */
					//应收买家手续费
					buyTradeFee = order.getBuyTradeFee();
					returnCode =this.deliveryDAO.updateTakenBSFee(buyTradeFee,deliveryID,userName);
					if(returnCode < 0)
						return -1;
					returnCode = this.voucherMgr.createNewOldVoucher(
							Constants.VOUCHERMODE_SHOU_JIAOSHOU_SHOUXUFEI, buyTradeFee,
							deliveryID, order.getBuyFirmId(), "买家未付化交，卖家违约，买家得到卖方支付违约金，收取买家手续费",
							userName);
					this.log.info(this.getClass().getName()+" 买家未付货款，卖家违约,收买家手续费：【"+buyTradeFee+"】元 后,返回参数："+returnCode);
					if(returnCode < 0){
						this.log.error(this.getClass().getName()+"adjustViolationPenalty  买家未付化交，卖家违约，买家得到卖方支付违约金，收取买家手续费失败,错误代码："+returnCode);
						return -1;
					}
				}
			}
		} else {
			returnCode = -1;
		}
		if (returnCode < 0)
			this.rollBack();

		return returnCode;
	}

	private BigDecimal getViolationPenalty(Delivery delivery, Order order) {
		// 订单总数量
		Integer totalQuantity = order.getQuantity();
		// 违约数量
		Integer deliveryQuantity = delivery.getDeliveryQuantity();
		BigDecimal violationPenalty = new BigDecimal(0);
		if(order.getPaymentStatus() == 10){
			// 违约部分手续费 卖方交易已收手续费:SellTakenTradeFee
			violationPenalty = new BigDecimal(deliveryQuantity)
					.multiply(order.getSellTradeFee().subtract(order.getSellCouponTradeFee())).divide(
							new BigDecimal(totalQuantity), 2,
							BigDecimal.ROUND_HALF_UP);
		}
		return violationPenalty;
	}

	/**
	 * 交收 尾调状态
	 * 
	 * @param tailAdjustStatus
	 *            尾调状态
	 * @param deliveryID
	 *            交收id
	 * @return
	 */
	private int updateDeliveryTailAdjustStatus(int tailAdjustStatus,
			String deliveryID) {
		int returnCode;
		returnCode = this.deliveryDAO.updateDeliveryTailAdjustStatus(
				tailAdjustStatus, deliveryID);
		return returnCode;
	}

	public static final String ADD_URL = "http://192.168.60.204:8075/api/pub";

	public static void appadd() {
		try {
			URL url = new URL(ADD_URL);
			HttpURLConnection connection = (HttpURLConnection) url
					.openConnection();
			connection.setDoOutput(true);
			connection.setDoInput(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type",
					"application/json;charset=utf-8");
			connection.setUseCaches(false);
			connection.setInstanceFollowRedirects(true);
			connection.setRequestProperty("connection", "Keep-Alive");
			connection.connect();
			// POST请求
			DataOutputStream out = new DataOutputStream(
					connection.getOutputStream());
			JSONObject obj = new JSONObject();
			int[] userIds = new int[] { 22 };
			obj.accumulate("userIds", userIds);
			obj.accumulate("userid", 11);
			obj.accumulate("message", "孙飞快来解决竞拍问题！速度！速度！速度！");
			obj.accumulate("linkUrl", "app.welcome");
			obj.accumulate("msgParams", "test1111231");

			out.writeBytes("data=" + obj.toString());
			System.out.println("data=" + obj.toString());
			out.flush();
			out.close();
			// 读取响应
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					connection.getInputStream()));
			String lines;
			StringBuffer sb = new StringBuffer("");
			while ((lines = reader.readLine()) != null) {
				lines = new String(lines.getBytes(), "utf-8");
				sb.append(lines);
			}
			System.out.println(sb);
			reader.close();
			connection.disconnect();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * 
	 * @param businessKey
	 *            业务主键（如交收id，付款id）
	 * @param definitionKey
	 *            流程主键
	 * @param mode
	 * @param userID
	 * @param variables
	 * @return
	 */
	private JSONObject startProcessInstance(String businessKey,
			String definitionKey, String mode, String userID,
			List<VariableParams> variables) {
		ProcessInstance processInstance = new ProcessInstance();

		ProcessInstanceParams piParams = processInstance.getPiParams();
		piParams.setBusinessKey(businessKey);
		piParams.setProcessDefinitionKey(definitionKey);

		piParams.setVariables(variables);
		JSONObject rtnJso = null;
		try {
			String postData = ActivitiFactory.getActivitiRequestData(
					"Start_Process_Instance", userID,
					processInstance.getJsonObject());
			rtnJso = postActivitiApi(postData, mode);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rtnJso;

	}

	/**
	 * 认领任务
	 * 
	 * @param taskID
	 * @param assignee
	 * @param variables
	 * @param variables
	 * @return
	 */
	private JSONObject claimTask(String taskID, String assignee, String mode,
			String userID) {
		Task task = new Task();
		TaskParams taskParams = task.getParams();
		task.setTaskId(taskID);// 流程ID
		taskParams.ClaimTask(assignee);// 认领人

		JSONObject rtnJso = null;
		try {
			/**
			 * 认领任务
			 */
			String postData = ActivitiFactory.getActivitiRequestData(
					"Action_Task", userID, task.getJsonObject());
			rtnJso = postActivitiApi(postData, mode);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return rtnJso;
	}

	/**
	 * 完成任务
	 * 
	 * @param variables
	 * @param mode
	 * @param userID
	 * @param taskID
	 * @return
	 */
	private JSONObject completeTask(List<VariableParams> variables,
			String mode, String userID, String taskID) {
		this.log.info(this.getClass().getName()+" completeTask(完成节点任务) Start");
		Task task = new Task();
		TaskParams taskParams = task.getParams();
		task.setTaskId(taskID);// 流程ID
		taskParams.CompleteTask();
		taskParams.setVariables(variables);

		JSONObject rtnJso = null;
		try {
			String postData = ActivitiFactory.getActivitiRequestData(
					"Action_Task", userID, task.getJsonObject());
			System.out.println("请求参数  :" + postData);
			rtnJso = postActivitiApi(postData, mode);
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" completeTask(完成节点任务)失败： "+e.getMessage());
			e.printStackTrace();
			rtnJso = null;
		}
		this.log.info(this.getClass().getName()+" completeTask(完成节点任务) End");
		return rtnJso;
	}

	// /**
	// * //下一节点操作人员
	// * @param taskName 节点名称
	// * @param list
	// * @return
	// */
	// private List<VariableParams> getVariableParams(String
	// taskName,List<VariableParams> list) {
	// VariableParams variableParams=new VariableParams();
	// variableParams.setName(taskName);
	// variableParams.setValue(this.getUser(BusinessEnumConstants.RoleType.LogisticsAuditRoleCode.getValue());
	// list.add(variableParams);
	// return list;
	// }
	/**
	 * 下一节点 任务人员
	 * 
	 * @return
	 */
	private String getUser(String roleCode) {
		this.log.info(this.getClass().getName()+" getUser(获取某个节点任务人员) Start");
		String userNames = "";
		List<MUser> userNameList = this.systemMgrDAO
				.getUserListByRoleCode(roleCode);
		if (userNameList != null && userNameList.size() > 0) {
			for (int i = 0; i < userNameList.size(); i++) {
				if (i > 0)
					userNames += ",";
				userNames += userNameList.get(i).getUserID();
			}
		}
		if (("").equals(userNames))
			this.log.debug("数据库中查无此角色:" + roleCode
					+ ",不能发起流程或者制定下一节点操作人员！请联系管理员");
		this.log.info(this.getClass().getName()+" getUser(获取某个节点任务人员) End");
		return userNames;
	}

	// 要推送消息的人员ID
	private Integer[] getUserID(String roleCode) {
		Integer[] userIDs = null;
		List<MUser> userNameList = this.systemMgrDAO
				.getUserListByRoleCode(roleCode);
		String userNames = "'";
		if (userNameList != null && userNameList.size() > 0) {
			for (int i = 0; i < userNameList.size(); i++) {
				if (i > 0)
					userNames += ",'";
				userNames += userNameList.get(i).getUserID() + "'";
			}
		}
		List<UaacUser> uaacUserList = this.systemMgrDAO
				.getUaacUserList(userNames);

		if (uaacUserList != null && uaacUserList.size() > 0) {
			userIDs = new Integer[uaacUserList.size()];
			for (int i = 0; i < uaacUserList.size(); i++) {
				userIDs[i] = uaacUserList.get(i).getId();
			}
		} else {
			userIDs = new Integer[0];
		}
		return userIDs;
	}

	/**
	 * 获取任务
	 * 
	 * @param userID
	 * @param processInstanceID
	 * @param mode
	 * @param taskName
	 *            节点名称
	 * @return
	 */
	@Override
	public ProcessTask getCandidateUserTaskList(String deliveryID,
			String userName, String userID, String mode) {
		Delivery delivery = this.deliveryDAO_read.getDeliveryDetail(deliveryID);
		ProcessTask processTask = new ProcessTask();
		Task task = new Task();
		TaskParams taskParams = task.getParams();
		taskParams.setCandidateUser(userID);
		taskParams.setProcessInstanceId(delivery.getProcessInstanceID());
		taskParams.setName(this.getTaskName(delivery.getDeliveryStatus(),
				delivery.getTailAdjustStatus(),
				delivery.getUpdateLogisticalDetStatus()));
		JSONObject rtnJso = null;
		try {
			String postData = ActivitiFactory.getActivitiRequestData(
					"Query_Tasks", userID, task.getJsonObject());
			rtnJso = postActivitiApi(postData, mode);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (rtnJso != null) {
			JSONObject JSONParams = new JSONObject(rtnJso.getString("DATA"));
			if (JSONParams != null) {
				JSONArray taskArray = JSONParams.getJSONArray("data");
				if (taskArray != null && taskArray.length() > 0) {
					String taskID = "";
					String ss = taskArray.get(0).toString();
					JSONObject taskObject = new JSONObject(ss);
					if (!taskObject.isNull("id")) {
						taskID = taskObject.getString("id");
						processTask.setTaskID(taskID);
						processTask.setTaskName(this.getTaskName(
								delivery.getDeliveryStatus(),
								delivery.getTailAdjustStatus(),
								delivery.getUpdateLogisticalDetStatus()));
					}
				}
			}
		}

		return processTask;
	}

	/**
	 * 收买家/卖家违约金 提请审核
	 */
	@Override
	public int subDeleveryPenalty(String deliveryID, String userName,
			String userID, String mode) {
		int returnCode = 0;
		Order order = this.deliveryDAO.getOrderByDeliveryID(deliveryID);
		boolean paymentStatus = !(order.getPaymentStatus() == 10 && order
				.getPaidSellAmount().compareTo(new BigDecimal(0)) > 0);
		boolean tradeStatus = order.getTradeStatus() == 55
				|| order.getTradeStatus() == 60 || order.getTradeStatus() == 65;
		// 付款判断 ，为了暂时解决先收违约金，再付货款时，多付卖家违约部分的货款
		if (!tradeStatus) {
			if (paymentStatus) {
				return -24035;// （请付卖家货款后，再提请风控部门审核违约）
			}
		}

		returnCode = this.updateDeliveryTailAdjustStatus(5, deliveryID);

		/**
		 * 开启尾调流程
		 */
		List<VariableParams> variables = new ArrayList<VariableParams>();

		// 下一节点操作人员（风控审核人员）
		VariableParams tailAdjustVerify = new VariableParams();
		tailAdjustVerify.setName("tailAdjustVerify");
		String roleCodes = BusinessEnumConstants.RoleType.ControlAuditRoleCode
				.getValue();
		tailAdjustVerify.setValue(this.getUser(roleCodes));
		variables.add(tailAdjustVerify);

		JSONObject rtnJso = startProcessInstance(deliveryID, "TailAdjust",
				mode, userID, variables);
		if (!rtnJso.getString("CODE").equals("OK")) {
			this.rollBack();
			returnCode = -1;
		} else {
			try {
				JSONObject JSONParams = new JSONObject(rtnJso.getString("DATA"));
				String processInstanceID = JSONParams.getString("id");
				returnCode = this.deliveryDAO.updateDeliveryProcessInstanceID(
						processInstanceID, deliveryID, userName);
				if (returnCode == -1) {
					this.rollBack();
				}
			} catch (Exception e) {
				e.printStackTrace();
				this.rollBack();
				returnCode = -1;
			}

		}

		return 0;
	}

	/**
	 * 获取履约/违约流程任务
	 * 
	 * @param deliveryID
	 * @param userName
	 * @param userID
	 * @param mode
	 * @return
	 */
	private JSONObject getPerformanceAgreementTaskList(String deliveryID,
			String userName, String userID, String mode) {
		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryID);
		Task task = new Task();
		TaskParams taskParams = task.getParams();
		taskParams.setCandidateUser(userID);
		taskParams.setProcessInstanceId(delivery.getProcessInstanceID());
		taskParams.setName("isPerformanceAgreement");
		JSONObject rtnJso = null;
		try {
			String postData = ActivitiFactory.getActivitiRequestData(
					"Query_Tasks", userID, task.getJsonObject());
			rtnJso = postActivitiApi(postData, mode);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return rtnJso;
	}

	/**
	 * 转货权信息
	 * 
	 * @param delivery
	 * @param trasferGoodsDetail
	 */
	private void setTrasferGoodsDetail(Delivery delivery,
			TrasferGoodsDetail trasferGoodsDetail) {
		this.log.info(this.getClass().getName()+ " setTrasferGoodsDetail Start");
		delivery.setValidDate(trasferGoodsDetail.getValidDate());
		delivery.setFeesItem(trasferGoodsDetail.getFeesItem());
		delivery.setRemark(trasferGoodsDetail.getRemark());
		delivery.setStoreHouseNum(trasferGoodsDetail.getStoreHouseNum());
		delivery.setContactName(trasferGoodsDetail.getContactName());
		delivery.setContactTel(trasferGoodsDetail.getContactTel());
		/** 下家委托书 */
		delivery.setBuyProxyFileID(trasferGoodsDetail.getBuyProxyFileID());
		/** 上家委托书 */
		delivery.setSellProxyFileID(trasferGoodsDetail.getSellProxyFileID());
		this.log.info(this.getClass().getName()+ " setTrasferGoodsDetail End");
	}

	/**
	 * 自提信息
	 * 
	 * @param delivery
	 * @param deliveryDetail
	 */
	private void setDeliveryDetail(Delivery delivery,
			DeliveryDetail deliveryDetail) {
		delivery.setStartDate(deliveryDetail.getStartDate());
		delivery.setEndDate(deliveryDetail.getEndDate());
		delivery.setLogisticsCorp(deliveryDetail.getLogisticsCorp());
		delivery.setDriverIDNumber(deliveryDetail.getDriverIDNumber());
		delivery.setLicense(deliveryDetail.getLicense());
		delivery.setContactName(deliveryDetail.getContactName());
		delivery.setContactTel(deliveryDetail.getContactTel());
		delivery.setSendStatus(deliveryDetail.getSendStatus());
		/** 下家委托书 */
		delivery.setBuyProxyFileID(deliveryDetail.getBuyProxyFileID());
	}

	/**
	 * 交收不同状态对应流程节点名称
	 * 
	 * @param tradeStatus
	 * @param tailAdjustStatus
	 *            付款状态（履约）
	 * @return
	 */
	private String getTaskName(int deliveryStatus, int tailAdjustStatus,
			int updateLogisticalDetStatus) {
		String taskName = "";
		if ((updateLogisticalDetStatus != 1 && updateLogisticalDetStatus != 5 && updateLogisticalDetStatus != 10)
				&& deliveryStatus == 1) {// 买家已申请
			taskName = "deliveryInfoConfirm";
		} else if (updateLogisticalDetStatus == 1 && deliveryStatus == 1) {// 中石化拆单申请
			taskName = "riskControlAuditDistribution";
		} else if (updateLogisticalDetStatus == 10 && deliveryStatus == 1) {// 中石化拆单申请，风控审核拒绝
			taskName = "deliveryModifyDistribution";
		} else if (deliveryStatus == 5) {// 待审核
			taskName = "deliveryInfoVerify";
		} else if (deliveryStatus == 10 || deliveryStatus == 17) {// 审核通过||买家已付运费
			taskName = "uploadReceiptForm";
		} else if (deliveryStatus == 15) {// 审核拒绝
			taskName = "modifyDeliveryInfo";
		} else if (deliveryStatus == 20) {// 已传卖家
			taskName = "deliveryInfoVerify";
		} else if (deliveryStatus == 25) {// 签收单已上传
			taskName = "adjustRealAmount";
		} else if (deliveryStatus == 35) {// 待风控审核
			taskName = "adjustRealAmountVerify";
		} else if (deliveryStatus == 40) {// 风控通过，待卖家确认
			taskName = "adjustOverflowShort";
		} else if (deliveryStatus == 45) {// 风控拒绝
			taskName = "adjustRealAmount";
		} else if (deliveryStatus == 50) {// 溢短处理中
			// 1：未处理 ，5：待审核 ，10：审核通过 ，15：审核拒绝
			if (tailAdjustStatus == 1) {
				taskName = "adjustOverflowShort";
			} else if (tailAdjustStatus == 5) {
				taskName = "tailAdjustVerify";
			} else if (tailAdjustStatus == 15) {
				taskName = "adjustOverflowShort";
			} else {
				taskName = "noTask";
			}

		} else if (deliveryStatus == 60 || deliveryStatus == 65) {
			// 1：未处理 ，5：待审核 ，10：审核通过 ，15：审核拒绝
			if (tailAdjustStatus == 5) {
				taskName = "tailAdjustReview";
			} else if (tailAdjustStatus == 15) {
				taskName = "tailAdjustModify";
			} else {
				taskName = "noTask";
			}
		} else {
			taskName = "noTask";
		}
		return taskName;
	}

	@Override
	public List<BreachContractApply> queryBreachContractApplyList(
			QueryConditions qc, PageInfo pageInfo) {
		this.log.info(DeliveryManagerImpl.class
				+ "  queryBreachContractApplyList Component Start");
		return deliveryDAO_read.queryBreachContractApplyList(qc, pageInfo);
	}

	/**
	 * 根据交收单号获取自提或转让单明细
	 *
	 * @param deliveryID
	 * @param deliveryType
	 * @return
	 */
	public DeliveryDto getDeliveryDtoDetail(String deliveryID, int deliveryType) {
		this.log.debug(this.getClass().getName()+".getDeliveryDtoDetail Start");
		DeliveryDto dto = deliveryDAO.getDeliveryDtoDetail(deliveryID, deliveryType);
		this.log.debug(this.getClass().getName()+".getDeliveryDtoDetail End");
		return dto;
	}

	/**
	 * 根据交收单号拿到明细
	 *
	 * @param deliveryID
	 * @return
	 */
	public Delivery getDeliveryInfo(String deliveryID) {
		this.log.debug(this.getClass().getName()+".getDeliveryInfo Start");
		Delivery delivery = deliveryDAO.getDeliveryInfo(deliveryID);
		this.log.debug(this.getClass().getName()+".getDeliveryInfo End");
		return delivery;
	}

	@Override
	public int creatProxyFile(DeliveryDto deliveryDto, String mode,
			String userName) {
		this.log.debug(this.getClass().getName()+"creatProxyFile Start");
		// 委托书类型 ：0化交给上家 1化交给下家
		int returnCode;
		int proxyType = deliveryDto.getProxyType();
		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryDto
				.getDeliveryID());
		deliveryDto.setFullName(delivery.getGoodName());
		Map<String, Object> fileMap = this.createImage(mode, proxyType,
				deliveryDto);
		if (fileMap == null) {
			return returnCode = -1;
		}
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		list.add(fileMap);
		returnCode = upateDeliveryDetailORTrasferGoodsDetail(list, delivery,
				userName, proxyType);
		if (returnCode == -1)
			this.rollBack();
		this.log.debug(this.getClass().getName()+"creatProxyFile End");
		return returnCode;
	}

	/**
	 * 生成自提，货权转移image
	 *
	 * @param deliveryID
	 * @param type
	 *            委托书类型 ：0化交给上家 1化交给下家
	 * @return
	 */
	private Map<String, Object> createImage(String mode, int type,
			DeliveryDto deliveryDtoOfPage) {
		this.log.debug(this.getClass().getName()+".createImage Start");
		String deliveryID = deliveryDtoOfPage.getDeliveryID();
		Delivery delivery = getDeliveryInfo(deliveryID);
		DeliveryDto deliveryDto = getDeliveryDtoDetail(deliveryID,delivery.getDeliveryType());
		String sourcePlaceName = "" ;
		String storeHouseFN = "";
		if (deliveryDto.getSourcePlaceName() != null && !deliveryDto.getSourcePlaceName().equals("")){
			sourcePlaceName = "--"+deliveryDto.getSourcePlaceName();
		}
		if (deliveryDto.getStoreHouseFN() != null &&  !deliveryDto.getStoreHouseFN().equals("")){
			storeHouseFN = "--"+ deliveryDto.getStoreHouseFN();
		}
		Calendar now = Calendar.getInstance();
		now.setTime(new Date());
		String temPath = "";
		String newPath = "";
		String imgPath = "";
		PropertyUtil propUtil = new PropertyUtil();
		Properties pdfProperty = propUtil.getProperties(Constants.PDF_PROPERTY);
		String basePath = pdfProperty.getProperty(mode + "_pdf_temp_path");
		Map<String, Object> rmap = null;
		if (type == 0) {
			this.log.debug("委托书类型,化交给上家 开始");
			// 交收方式 0: 自提；1:配送,2:转货权
			if (delivery.getDeliveryType() == 0) {
				this.log.debug("处理自提开始");
				temPath = basePath + "/delegated.pdf";
				newPath = basePath + "/delegated" + System.currentTimeMillis()
						+ ".pdf";
				imgPath = basePath + "/de" + System.currentTimeMillis()
						+ ".jpg";
				String detail = deliveryDto.getDetail() != null ? deliveryDto
						.getDetail() : "";
				String remark = deliveryDto.getRemark() != null ? deliveryDto
						.getRemark() : "";
				String tempRemark = "";
				if (detail.length() > 0 && remark.length() > 0) {
					tempRemark = detail + "，" + remark;
				} else {
					tempRemark = detail + remark;
				}
				tempRemark += storeHouseFN;
				int size = 20;
				int size1 = 27;
				int length = tempRemark.length();
				String tempRemark1 = tempRemark;
				String tempRemark2 = "";
				String tempRemark3 = "";
				String tempRemark4 = "";
				
				int substringIndex = truncate(tempRemark,size,5,0,7);
				if (length > substringIndex && substringIndex !=0) {
					tempRemark1 = tempRemark.substring(0, substringIndex);
					tempRemark2 = tempRemark.substring(substringIndex);
					substringIndex = truncate(tempRemark2,size1,5,0,9);
					if (tempRemark2.length() > substringIndex && substringIndex != 0){
						tempRemark3 = tempRemark2.substring(substringIndex);
						tempRemark2 = tempRemark2.substring(0,substringIndex);
						substringIndex = truncate(tempRemark3,size1,5,0,9);
						if (tempRemark3.length() > substringIndex && substringIndex != 0 ){
							tempRemark4 = tempRemark3.substring(substringIndex);
							tempRemark3 = tempRemark3.substring(0, substringIndex);
						}
					}
				}
				Calendar start = Calendar.getInstance();
				Calendar end = Calendar.getInstance();
				if (deliveryDto.getStartDate() != null) {
					start.setTime(deliveryDto.getStartDate());
				}
				if (deliveryDto.getEndDate() != null) {
					end.setTime(deliveryDto.getEndDate());
				}
				DecimalFormat df = new DecimalFormat("###.######");
				BigDecimal tradeUnitNumber = deliveryDto.getTradeUnitNumber() == null ? new BigDecimal(
						0) : deliveryDto.getTradeUnitNumber();
				Integer deliveryQuantity = deliveryDto.getDeliveryQuantity() == null ? 0
						: deliveryDto.getDeliveryQuantity();
				String[] datas = {
						deliveryID,
						deliveryDto.getFullName(),
						// deliveryDto.getOrderId(),
						deliveryID,
						deliveryDto.getCategoryName() + "-" + deliveryDto.getBrandName()+sourcePlaceName,
						// deliveryDto.getDeliveryQuantity().toString(),
						df.format(tradeUnitNumber.multiply(new BigDecimal(
								deliveryQuantity))) + "(吨)",// 交易单位（吨/批）*
															// 交收数量(批)
						deliveryDto.getLicense(),
						deliveryDto.getLogisticsCorp(),
						// detail,
						// remark,
						tempRemark1, tempRemark2, tempRemark3, tempRemark4,
						String.valueOf(start.get(Calendar.YEAR)),
						String.valueOf(start.get(Calendar.MONTH) + 1),
						String.valueOf(start.get(Calendar.DAY_OF_MONTH)),
						String.valueOf(end.get(Calendar.YEAR)),
						String.valueOf(end.get(Calendar.MONTH) + 1),
						String.valueOf(end.get(Calendar.DAY_OF_MONTH)),
						String.valueOf(now.get(Calendar.YEAR)),
						String.valueOf(now.get(Calendar.MONTH) + 1),
						String.valueOf(now.get(Calendar.DAY_OF_MONTH)) };

				rmap = PdfUtil.convertPdf(temPath, newPath, imgPath, datas,mode);
				this.log.debug("处理自提结束");
			} else {
				this.log.debug("配送或转货权开始");
				temPath = basePath + "/sell.pdf";
				newPath = basePath + "/sell" + System.currentTimeMillis()
						+ ".pdf";
				imgPath = basePath + "/sell" + System.currentTimeMillis()
						+ ".jpg";
				String remarks = deliveryDtoOfPage.getRemarks() != null ? deliveryDtoOfPage.getRemarks()+storeHouseFN : "";
				
				int size = 22;
				int size1 = 26;
				String remarks1 = remarks;
				String remarks2 = "";
				String remarks3 = "";
				String remarks4 = "";
				int length = remarks.length();
				int substringIndex = truncate(remarks,size,4,0,2);
				if (length > substringIndex && substringIndex !=0) {
					remarks1 = remarks.substring(0, substringIndex);
					remarks2 = remarks.substring(substringIndex);
					substringIndex = truncate(remarks2,size1,5,0,2);
					if (remarks2.length() > substringIndex && substringIndex != 0){
						remarks3 = remarks2.substring(substringIndex);
						remarks2 = remarks2.substring(0,substringIndex);
						substringIndex = truncate(remarks3,size1,5,0,2);
						if (remarks3.length() > substringIndex && substringIndex != 0 ){
							remarks4 = remarks3.substring(substringIndex);
							remarks3 = remarks3.substring(0, substringIndex);
						}
					}
				}
				String[] selldatas = {
						deliveryID,
						deliveryDto.getSellName(),
						deliveryID,
						deliveryDto.getCategoryName() + "-" + deliveryDto.getBrandName()+sourcePlaceName,
						String.valueOf(deliveryDtoOfPage.getQuantity()) + "(吨)",
						remarks1, remarks2,remarks3,remarks4,
						String.valueOf(now.get(Calendar.YEAR)),
						String.valueOf(now.get(Calendar.MONTH) + 1),
						String.valueOf(now.get(Calendar.DAY_OF_MONTH)) };
				rmap = PdfUtil.convertPdf(temPath, newPath, imgPath, selldatas,
						mode);
				this.log.debug("配送或转货权结束");
			}
			this.log.debug("委托书类型,化交给上家 结束");
		} else {
			this.log.debug("委托书类型,化交给下家 开始");
			temPath = basePath + "/buy.pdf";
			newPath = basePath + "/buy" + System.currentTimeMillis() + ".pdf";
			imgPath = basePath + "/buy" + System.currentTimeMillis() + ".jpg";
			String remarks = deliveryDtoOfPage.getRemarks() == null ? "": deliveryDtoOfPage.getRemarks()+storeHouseFN;
			int size = 23;
			int size1 = 28;
			int substringIndex = truncate(remarks,size,4,0,2);
			String remarks1 = remarks;
			String remarks2 =""	;
			if (remarks.length() > substringIndex && substringIndex != 0){
				remarks1 = remarks.substring(0, substringIndex);
				remarks2 = remarks.substring(substringIndex);
			}
			String feesItem = deliveryDtoOfPage.getFeesItem() == null ? "" : deliveryDtoOfPage.getFeesItem();
			String feesItem1 = feesItem;
			String feesItem2 = "";
			String feesItem3 = "";
			substringIndex = truncate(feesItem,size,4,0,2);
			if (feesItem.length() > substringIndex && substringIndex != 0) {
				feesItem1 = feesItem.substring(0, substringIndex);
				feesItem2 = feesItem.substring(substringIndex);
				substringIndex = truncate(feesItem2,size1,5,0,2);
				if (feesItem2.length() > substringIndex && substringIndex != 0){
					feesItem3 = feesItem2.substring(substringIndex);
					feesItem2 = feesItem2.substring(0,substringIndex);
				}
			}
			String contactNameTel = "";
			boolean bool = false;
			if (deliveryDto.getContactName() != null) {
				contactNameTel = deliveryDto.getContactName();
				bool = true;
			}
			if (deliveryDto.getContactTel() != null) {
				if (bool) {
					contactNameTel = contactNameTel + "、"
							+ deliveryDto.getContactTel();
				} else {
					contactNameTel = deliveryDto.getContactTel();
				}
			}

			String[] buydatas = {
					deliveryID,
					"上海化工品交易市场经营管理有限公司",
					deliveryDto.getBuyName(),
					contactNameTel,
					deliveryDtoOfPage.getStoreHouseNum(),
					deliveryDto.getCategoryName() + "-" + deliveryDto.getBrandName()+sourcePlaceName,
					String.valueOf(deliveryDtoOfPage.getQuantity()) + "(吨)",// 吨
					DataUtil.DateToString(deliveryDtoOfPage.getTradeDate()),
					remarks1, remarks2, 
					feesItem1, feesItem2, feesItem3 };
			rmap = PdfUtil
					.convertPdf(temPath, newPath, imgPath, buydatas, mode);
			this.log.debug("委托书类型,化交给下家 结束");
		}
		if (rmap == null) {
			this.log.businesslog("pdf模板不存在", mode, Constants.OPE_FAIL);
		}
		this.log.debug(this.getClass().getName()+".createImage End");
		return rmap;
	}
	
	/**
	 * 返回 要截取字符串的位置
	 * @param truncateStr 字符串
	 * @param lineLength 一行的长度
	 * @param halfFineTuningNum 全部半角时调整数
	 * @param fullFineTuningNum 全部全角时调整数
	 * @param halfFullNum 全角半角混合的调整数
	 * @return
	 */
	private int truncate(String truncateStr,int lineLength,int halfFineTuningNum,int fullFineTuningNum,int halfFullNum){
		int index = 0;
		int substringIndex = 0;
		String[] tempRemarkArr = truncateStr.split("");
		boolean fullFlag = false;
		boolean halfFlag = false;
		int fullFlagIndex = 0;
		int halfFlagIndex = 0;
		for (int i = 1; i < tempRemarkArr.length; i++) {
			String str = tempRemarkArr[i];
			if (str.getBytes().length == str.length()
					&& !"".equals(str)) {// 半角
				index++;
				halfFlagIndex++;
				if (halfFlagIndex >= lineLength * 2){
					halfFlag = true;
				}
			} else {// 全角
				index = index + 2;
				fullFlagIndex +=2 ;
				if (fullFlagIndex >= lineLength * 2){
					fullFlag = true;
				}
			}
			if (halfFlag){
				substringIndex = i - halfFineTuningNum;
				break;
			}
			if (fullFlag){
				substringIndex = i - fullFineTuningNum;
				break;
			}
			if (index >= lineLength * 2){
				substringIndex = i - halfFullNum;
				break;
			}
		}
		return substringIndex;
	}
	
	/**
	 * 
	 * @param fileList
	 * @param delivery
	 * @param userName
	 * @param proxyType
	 *            委托书类型
	 * @return
	 */
	private int upateDeliveryDetailORTrasferGoodsDetail(
			List<Map<String, Object>> fileList, Delivery delivery,
			String userName, int proxyType) {
		this.log.debug("upateDeliveryDetailORTrasferGoodsDetail Start");
		int returnCode = -1;
		if (fileList != null && fileList.size() > 0) {
			// 自提
			if (delivery.getDeliveryType() == 0) {
				this.log.debug(" 更新自提委托书 开始");
				Map<String, Object> fileMap = fileList.get(0);
				int buyProxyFileID = 0;
				try {
					buyProxyFileID = Integer.parseInt(fileMap.get("id")
							.toString());
				} catch (Exception e) {
					this.rollBack();
					return returnCode = -1;
				}
				returnCode = this.deliveryDAO
						.upateDeliveryDetailBuyProxyFileID(
								delivery.getDeliveryID(), buyProxyFileID,
								userName);
				if (returnCode == -1) {
					this.rollBack();
					return returnCode = -1;
				}
				this.log.debug(" 更新自提委托书 结束");
			}
			// 转货权
			if (delivery.getDeliveryType() == 2) {
				this.log.debug(" 更新转货权委托书 开始");
				Map<String, Object> fileMap = fileList.get(0);
				// 化交传委托书给上家
				if (proxyType == 0) {
					this.log.debug(" 化交传委托书给上家 开始");
					try {
						int sellProxyFileID = Integer.parseInt(fileMap
								.get("id").toString());
						returnCode = this.deliveryDAO
								.upateTrasferGoodsDetailProxyFileSell(
										delivery.getDeliveryID(),
										sellProxyFileID, userName);
						if (returnCode == -1) {
							this.rollBack();
							return returnCode;
						}
					} catch (Exception e) {
						this.rollBack();
						return returnCode = -1;
					}
					this.log.debug(" 化交传委托书给上家 结束");
				}// 化交传委托书给下家
				else {
					this.log.debug(" 化交传委托书给下家 开始");
					try {
						int buyProxyFileID = Integer.parseInt(fileMap.get("id")
								.toString());
						returnCode = this.deliveryDAO
								.upateTrasferGoodsDetailProxyFileBuy(
										delivery.getDeliveryID(),
										buyProxyFileID, userName);
						if (returnCode == -1) {
							this.rollBack();
							return returnCode;
						}
					} catch (Exception e) {
						this.rollBack();
						return returnCode = -1;
					}
					this.log.debug(" 化交传委托书给下家 结束");
				}
				this.log.debug(" 更新转货权委托书 结束");
			}
		}
		this.log.debug("upateDeliveryDetailORTrasferGoodsDetail End");
		return returnCode;
	}

	@Override
	public List<String> findDeliveryStatusByOrderId(String orderId) {
		return deliveryDAO.findDeliveryStatusByOrderId(orderId);
	}

	@Override
	public int pushMessage(String orderID, String userID, String mode) {
		String roleCodes = BusinessEnumConstants.RoleType.ControlAuditRoleCode
				.getValue();
		Integer[] userIds = this.getUserID(roleCodes);
		int returnCode = 0;
		returnCode = this
				.pushMessage(mode, userIds, userID, " 有客户申请违约，请风控审核人员查看",
						"app.deliveryDetail.riskControl", orderID);
		return returnCode;
	}

	/**
	 * @param mode
	 * 
	 * @param userIds
	 *            要推送的人
	 * @param userID
	 *            推送人
	 * @param message
	 *            消息内容
	 * @param linkUrl
	 *            消息链接
	 * @param deliveryID
	 *            交收ID
	 * @return returnCode：200是success
	 */
	private int pushMessage(String mode, Integer[] userIds, String userID,
			String message, String linkUrl, String deliveryID) {
		this.log.debug("pushMessage Component Start");
		PostMethod filePost = null;

		if (Constants.MODE_TEST.equals(mode)) {
			filePost = new PostMethod(Constants.PUSH_MESSAGE_TEST);
		} else if (Constants.MODE_UAT.equals(mode)) {
			filePost = new PostMethod(Constants.PUSH_MESSAGE_UAT);
		} else if (Constants.MODE_DEPLOY.equals(mode)) {
			filePost = new PostMethod(Constants.PUSH_MESSAGE_DEPLOY);
		} else {
			filePost = new PostMethod(Constants.PUSH_MESSAGE_DEV);
		}

		this.log.debug("pushMessage mode : " + mode);

		JSONObject obj = new JSONObject();
		obj.accumulate("userIds", userIds);
		obj.accumulate("userid", userID);
		obj.accumulate("message", message);
		obj.accumulate("linkUrl", linkUrl);
		obj.accumulate("msgParams", deliveryID);
		filePost.setRequestBody(obj.toString());
		filePost.setRequestHeader("Content-Type",
				"application/json;charset=utf-8");
		HttpClient client = new HttpClient();
		client.getHttpConnectionManager().getParams()
				.setConnectionTimeout(5000);
		int returnCode;
		try {
			returnCode = client.executeMethod(filePost);
			this.log.error("pushMessage　returnCode:" + returnCode);

			if (returnCode != HttpStatus.SC_OK) {
				this.log.error("pushMessage error: 消息推送失败");
				returnCode = -1;
			} else {
				this.log.debug("pushMessage success");
			}
		} catch (HttpException e) {
			// 发生致命的异常，可能是协议不对或者返回的内容有问题
			this.log.error("pushMessage error:" + e.getMessage());
			returnCode = -1;
		} catch (IOException e) {
			// 发生网络异常
			this.log.error("pushMessage error:" + e.getMessage());
			returnCode = -1;
		} catch (Exception e) {
			this.log.error("pushMessage error:" + e.getMessage());
			returnCode = -1;
		} finally {
			filePost.releaseConnection();
		}

		this.log.debug("pushMessage Component Stop");
		return returnCode;
	}

	/**
	 * 风控部门审核通过后，如果卖家24小时之内没有确认，后台自动触发确认
	 */
	@Override
	public int sellConfirmDelivery(String deliveryID, String userName,
			String mode, String userID) {
		int returnCode = -2;
		Delivery delivery = this.deliveryDAO.getDeliveryDetail(deliveryID);
		returnCode = this.deliveryDAO.updateDeliveryStatus(50, deliveryID,
				userName);
		if (returnCode == -1)
			return returnCode;

		// 订单状态
		returnCode = this.updateOrderTradeStatus(delivery.getOrderID(), mode,
				delivery.getDeliveryType());
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}
		// 推送消息给风控操作人员
		String roleCodes = BusinessEnumConstants.RoleType.ControlGeneralerRoleCode
				.getValue();
		Integer[] userIds = this.getUserID(roleCodes);
		returnCode = this.pushMessage(mode, userIds, userID,
				"卖家已经确认溢短，请风控操作人员查看", "app.deliveryDetail.riskControl",
				deliveryID);
		if (returnCode == -1) {
			this.log.debug("推送消息失败,交收单号：" + deliveryID);
			this.rollBack();
			return returnCode;
		}
		return returnCode;
	}

	@Override
	public int sellConfirmDeliveryPolled(String userName, String mode,
			String userID) {
		int returnCode = -2;
		Date currentDate = new Date();
		List<Delivery> toBeIdentifiedListBySeller = this.deliveryDAO
				.getToBeIdentifiedListBySeller();
		if (toBeIdentifiedListBySeller != null
				&& toBeIdentifiedListBySeller.size() > 0) {
			for (Delivery delivery : toBeIdentifiedListBySeller) {
				Date deliveryDate = delivery.getREC_MODIFYTIME();
				Calendar calendar = new GregorianCalendar();
				calendar.setTime(deliveryDate);
				calendar.add(calendar.DATE, 1);// 把日期往后增加一天.整数往后推,负数往前移动
				deliveryDate = calendar.getTime(); // 这个时间就是日期往后推一天的结果

				if (currentDate.getTime() >= deliveryDate.getTime()) {
					this.log.debug("前台卖家确认溢短超过24小时没有人为确定，系统自动触发开始："
							+ new Date());
					returnCode = this.deliveryDAO.updateDeliveryStatus(50,
							delivery.getDeliveryID(), userName);
					if (returnCode == -1)
						return returnCode;

					// 推送消息给风控操作人员
					String roleCodes = BusinessEnumConstants.RoleType.ControlGeneralerRoleCode
							.getValue();
					Integer[] userIds = this.getUserID(roleCodes);
					if (returnCode >= 1)
						returnCode = this.pushMessage(mode, userIds, userID,
								"卖家已经确认溢短，请风控操作人员查看",
								"app.deliveryDetail.riskControl",
								delivery.getDeliveryID());
					if (returnCode == -1) {
						this.log.debug("推送消息失败,交收单号："
								+ delivery.getDeliveryID());
						this.rollBack();
						return returnCode;
					}
				}

				// 订单状态
				returnCode = this.updateOrderTradeStatus(delivery.getOrderID(),
						mode, delivery.getDeliveryType());
				if (returnCode == -1) {
					this.rollBack();
					return returnCode;
				}

			}
		}

		return 0;
	}

	@Override
	public int updateOperNotes(String notes, String userId, String deliveryID) {
		return deliveryDAO.updateOperNotes(notes, userId, deliveryID);
	}

	@Override
	public String findOperNotes(String deliveryID) {
		return deliveryDAO_read.findOperNotes(deliveryID);
	}

	/**
	 * 客户违约申请添加备注
	 *
	 * @param
	 * @return
	 */
	public int addReamrkBreach(String remark, String userId, String deliveryID) {
		return deliveryDAO.addReamrkBreach(remark, userId, deliveryID);
	}

	/**
	 * 客户违约申请获取备注
	 *
	 * @param
	 */
	public String readRemarkBreach(String deliveryID) {
		return deliveryDAO_read.readRemarkBreach(deliveryID);
	}

	@Override
	public int updateDeliveryOfPayedMoneyByDeliveryID(String deliveryID,
			String userID, BigDecimal payedMoney) {
		this.log.info(this.getClass().getName()
				+ "component updateDeliveryOfPayedMoneyByDeliveryID Start");
		int count = deliveryDAO.updateDeliveryOfPayedMoneyByDeliveryID(
				deliveryID, userID, payedMoney);
		this.log.info(this.getClass().getName()
				+ "component updateDeliveryOfPayedMoneyByDeliveryID End");
		return count;
	}

	/**
	 * 签收没有溢短 //卖家保证金/授信，该退就退，该释放就释放
	 * 
	 * @param order
	 * @param delivery
	 * @param integer
	 * @return
	 */
	private int refundment(Order order, Delivery delivery, String userName,
			Integer goodsType) {
		int returnCode;
		// 卖方交收应扣保证金
		BigDecimal sellSettleDeposit = delivery.getSellSettleDeposit();
		// 卖方交收已扣保证金
		BigDecimal sellTakenSSDeposit = delivery.getSellTakenSSDeposit();
		/**
		 * ################## 卖方保证金（含流水）Start######################
		 */
		// 卖家使用授信的金额
		BigDecimal sellCreditDeposit = sellSettleDeposit
				.subtract(sellTakenSSDeposit);

		// 更新订单 卖方交收保证金授信金额 SellCreditDeposit
		returnCode = this.deliveryDAO.updateOrderSellCreditDeposit(
				order.getOrderId(), sellCreditDeposit);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}

		// 订单 卖方交易已收保证金:SellTakenTradeDeposit
		returnCode = this.deliveryDAO.updateSellTakenTradeDeposit(
				order.getOrderId(), sellTakenSSDeposit, userName);
		if (returnCode == -1) {
			this.rollBack();
			return returnCode;
		}
		// 退保证金给卖家
		if (returnCode >= 0)
			returnCode = this.voucherMgr.createNewOldVoucher(
					Constants.VOUCHERMODE_TUI_JIAOSHOU_BAOZHENGJING,
					sellTakenSSDeposit, delivery.getDeliveryID(),
					delivery.getSellFirmId(), "退保证金给卖家", userName);

		sApplyManagerImpl = (ISApplayManager) FinanceSysData
				.getBean(Constants.BEAN_SAPPLYMGR_MGR);
		/**
		 * 释放授信流水
		 */
		try {

			if (goodsType == 0) { // 现货
				returnCode = sApplyManagerImpl.backMargin(
						order.getSellFirmId(), sellCreditDeposit,
						delivery.getDeliveryID(), 3);
			} else {// 预售
				returnCode = sApplyManagerImpl.backMarginForPreSale(
						order.getSellFirmId(), sellCreditDeposit,
						delivery.getDeliveryID(), 3);
			}

		} catch (Exception e) {
			returnCode = -1;
			this.rollBack();
			return returnCode;
		}

		/**
		 * ################## 卖方保证金（含流水）End######################
		 */

		return returnCode;
	}

	@Override
	public Delivery getDeliveryByID(String deliveryID) {
		Delivery delivery = this.deliveryDAO.getDeliveryByID(deliveryID);
		return delivery;
	}

	/**
	 * 变更 配送运费资金表 的 【运费调整额】
	 */
	@Override
	public int updateDeliveryFreightFeeOfOverloadFreight(String deliveryID,
			BigDecimal backFreightFree, String userId) {
		int resultCode = 0;
		this.log.info(this.getClass().getName()
				+ " updateDeliveryFreightFeeOfOverloadFreight component Start");

		if (backFreightFree == null
				|| backFreightFree.compareTo(new BigDecimal(0)) <= 0) {
			resultCode = -1;// 要退的运费不能 小于或等于0
		} else {
			
			
			// 取负值
			BigDecimal backFreightFreeTemp = backFreightFree.negate();
			DeliveryFreightFee deliveryFreightFee = deliveryDAO
					.selectDeliveryFrightFeeByDeliveryID(deliveryID);
			if (deliveryFreightFee != null) {
				if (deliveryFreightFee.getBuyPaidFreight().compareTo(
						backFreightFree) < 0) {
					resultCode = -3; // 要退买家的运费不能大于买家已付运费
				} else {
					// 更新 配送运费资金表 的 【运费调整额】
					deliveryDAO
							.updateDeliveryFreightFeeOfOverloadFreightByDeliveryID(
									backFreightFreeTemp, userId, deliveryID);
				}
			} else {
				resultCode = -2;// 买家未付运费不能退款
			}
		}
		this.log.info(this.getClass().getName()
				+ " updateDeliveryFreightFeeOfOverloadFreight component End");
		return resultCode;
	}

	@Override
	public int subtractBuyFirmFreight(String orderId, String userID) {
		this.log.info(this.getClass().getName()
				+ " subtractBuyFirmFreight() component Start");
		int resultCode = 0;
		try {
			// 获取订单信息
			Order order = orderDAO.getOrderByID(orderId);
			// 获取订单下所有交收单的配送资金列表
			List<DeliveryFreightFee> list = deliveryDAO
					.selectDeliveryFrightFee(orderId);
			if (list != null && list.size() > 0) {
				BigDecimal allFree = new BigDecimal(0);
				for (DeliveryFreightFee free : list) {
					allFree = allFree.add(free.getBuyPaidFreight());// 累加 买家已付运费
				}
				if (allFree.compareTo(new BigDecimal(0)) > 0) {
					// 收买家运费
					int code = this.voucherMgr.createNewOldVoucher(
							Constants.VOUCHERMODE_SHOU_YUNFEI, allFree,
							orderId, order.getBuyFirmId(), "收买家运费", userID);
					if (code < 0) {
						resultCode = -3;// 收买家运费失败
					}
				} else {
					resultCode = -2;// 买家未付运费,不能扣除
				}
			} else {
				resultCode = -1;// 根据成交ID未查询出配送运费资金列表
			}
		} catch (Exception e) {
			this.log.error("收买家运费异常" + e.getMessage());
			resultCode = -4;//
		}
		this.log.info(this.getClass().getName()
				+ " subtractBuyFirmFreight() component End");
		return resultCode;
	}

	@Override
	public List<BreachContractApply> getBreachContractApplyListByID(String ID) {
		this.log.info(this.getClass().getName()
				+ " getBreachContractApplyListByID() component Start");
		List<BreachContractApply> list = deliveryDAO_read
				.getBreachContractApplyListByID(ID);
		this.log.info(this.getClass().getName()
				+ " getBreachContractApplyListByID() component End");
		return list;
	}

	@Override
	public List<OrderSinopec> getDeliverySinopecFile(String deliveryID) {
		this.log.info(this.getClass().getName()
				+ " getDeliverySinopecFile() component Start");
		List<OrderSinopec> list = this.deliveryDAO_read
				.getDeliverySinopecFile(deliveryID);
		this.log.info(this.getClass().getName()
				+ " getDeliverySinopecFile() component End");
		return list;
	}

	@Override
	public int updateDeliveryOfIsGetSinopecNumber(String deliveryID,
			Integer isGetSinopecNumber, String userName) {
		this.log.info(this.getClass().getName()
				+ " updateDeliveryOfIsGetSinopecNumber() component Start");
		int count = deliveryDAO.updateDeliveryOfIsGetSinopecNumber(deliveryID,
				isGetSinopecNumber, userName);
		this.addDeliveryOpeLog(deliveryID, userName, "已取得石化订单号", "");// 添加操作日志
		this.log.info(this.getClass().getName()
				+ " updateDeliveryOfIsGetSinopecNumber() component End");
		return count;
	}
	
	@Override
	public int doReceive(String deliveryID, String userName) {
		this.log.info(this.getClass().getName()	+ " doReceive() component Start");
		int count = deliveryDAO.doReceive(deliveryID, userName);
		this.addDeliveryOpeLog(deliveryID, userName, "物流部门已确认收货", "");// 添加操作日志
		this.log.info(this.getClass().getName() + " doReceive() component End");
		return count;
	}

	@Override
	public List<Delivery> getDeliveryOfDelDistributionDetailList(
			QueryConditions qc, PageInfo pageInfo) {
		this.log.info(this.getClass().getName()
				+ " getDeliveryOfDelDistributionDetailList() component Start");
		List<Delivery> list = deliveryDAO
				.getDeliveryOfDelDistributionDetailList(qc, pageInfo);
		this.log.info(this.getClass().getName()
				+ " getDeliveryOfDelDistributionDetailList() component End");
		return list;
	}

	@Override
	public List<Delivery4Export> exportNewDeliveryList(QueryConditions qc,
			PageInfo pageInfo,boolean replace) {
		this.log.info(this.getClass().getName()+ " exportNewDeliveryList() component Start");
		List<Delivery4Export> list = deliveryDAO_read.exportNewDeliveryList(qc, pageInfo,replace);
		this.log.info(this.getClass().getName()+ " exportNewDeliveryList() component End");
		return list;
	}

	@Override
	public int getExportDeliveryListCount(QueryConditions qc, PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+" getExportDeliveryListCount Start");
		int count = 0;
		count = this.deliveryDAO_read.getExportDeliveryListCount(qc,pageInfo);
		this.log.info(this.getClass().getName()+" getExportDeliveryListCount End");
		return count;
	}
	
	@Override
	public int exportNewDeliveryListListCount(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+" exportNewDeliveryListListCount Start");
		int count = 0;
		count = this.deliveryDAO_read.exportNewDeliveryListListCount(qc,pageInfo);
		this.log.info(this.getClass().getName()+" exportNewDeliveryListListCount End");
		return count;
	}

	@Override
	public List<userMobileModel> getUserMobileList(String userCode) {
		this.log.info(this.getClass().getName()+" getUserMobileList Start");
		List<userMobileModel> list = this.systemMgrDAO.getUserMobileList(userCode);
		this.log.info(this.getClass().getName()+" getUserMobileList End");
		return list;
	}
	
	
	@Override
	public int getDeliveryInvoice4ExportCount(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+" getDeliveryInvoice4ExportCount Start");
		int totalCount = this.deliveryDAO_read.getDeliveryInvoice4ExportCount(qc,pageInfo);
		this.log.info(this.getClass().getName()+" getDeliveryInvoice4ExportCount End");
		return totalCount;
	}
	
	@Override
	public Delivery getDeliveryByDeliveryID(String deliveryID) {
		this.log.info(this.getClass().getName() + " getDeliveryByDeliveryID Start");
		Delivery delivery = this.deliveryDAO_read.getDeliveryByDeliveryID(deliveryID);
		this.log.info(this.getClass().getName() + " getDeliveryByDeliveryID End ");
		return delivery;
	}
}
