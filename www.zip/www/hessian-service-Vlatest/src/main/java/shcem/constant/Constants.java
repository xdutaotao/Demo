/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: Constants
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.constant;

import java.math.BigDecimal;

import scala.annotation.meta.getter;
import shcem.util.Common;

/**
 * 常量
 * 
 * @author chiyong
 * @version 1.0
 */
public class Constants {

	/**
	 * 基础定义
	 */
	// sql configure
	public final static String SQL_PROPERTY = "/sql.properties";
	public final static String RMI_PROPERTY = "/rmi.properties";
	public final static String MAIL_PROPERTY = "/mail.properties";

	public final static String JPUSH_PROPERTY = "/jpush.properties";
	public final static String PDF_PROPERTY = "/pdf.properties";
	public final static String MIDDLE_WARE_PROPERTY = "/middleWare.properties";
	public final static String REDIS_PROPERTY = "/redis.properties";
	public final static String WEIXIN_PROPERTY = "/weixin.properties";
	public static final String WEIXIN4J = "weixin4j_";
	
	// Log Level
	public final static String LOG_DEBUG = "DEBUG";
	public final static String LOG_ERROR = "ERROR";
	public final static String LOG_INFO = "INFO";
	public final static String LOG_WARN = "WARN";

	// Header type
	public final static String HEADER_CLIENT_IP = "Clientip";
	public final static String HEADER_REQ_TIME = "Reqtime";
	public final static String HEADER_MEM_ID = "Memberid";
	public final static String HEADER_MEM_NAME = "Membername";
	public final static String HEADER_APP_NAME = "Appname";
	public final static String HEADER_MODE = "mode";
	public final static String HEADER_REQUESTID = "RequestId";	

	// Operation mode
	public final static String OPE_MODE_TRADE = "trade";
	public final static String OPE_MODE_MEMBER = "member";
	public final static String OPE_MODE_AUTH = "auth";
	public final static String OPE_MODE_FINANCE = "finance";
	public final static String OPE_MODE_DELIVERY = "delivery";
	public final static String OPE_MODE_PRODUCT = "product";
	public final static String OPE_MODE_CONTRACT = "contract";
	public final static String OPE_MODE_RISK = "risk";
	public final static String OPE_MODE_INFORM = "inform";
	public final static String OPE_MODE_SYSTEMMGR = "systemMgr";
	public final static String OPE_MODE_LOGISTICS = "logistics";
	public final static String OPE_MODE_MARKET = "market";

	// Operation status
	public final static int OPE_SUCCESS = 1;
	public final static int OPE_FAIL = 0;

	public final static String LOG_ENV_JSON = "ENV";
	public final static String LOG_SYSTEM_DIFF_JSON = "SYS";
	public final static String LOG_DATA_JSON = "DATA";
	public final static String LOG_DATA_COLUMN_TIME = "LOGTIME";
	public final static String LOG_DATA_COLUMN_LEVEL = "LEVEL";
	public final static String LOG_DATA_COLUMN_TYPE = "TYPE";
	public final static String LOG_DATA_COLUMN_MESSAGE = "MSG";
	public final static String LOG_DATA_COLUMN_USERID = "USERID";
	public final static String LOG_DATA_COLUMN_APPNAME = "APPNAME";
	public final static String LOG_DATA_COLUMN_IPADDRESS = "IPADS";
	public final static String LOG_DATA_COLUMN_STATUS = "STATUS";
	
	// 模式区分
	public final static String ENV_LOCAL = "LOC";
	public final static String ENV_DEVELOP = "DEV";
	public final static String ENV_TEST = "TST";
	public final static String ENV_UAT = "UAT";
	public final static String ENV_DEPLOY = "DEP";

	// 系统区分
	// Java服务
	public final static String SYSTEM_DIFF_JAVSV = "JAVSV";
	
	/**
	 * 用户自定义
	 */
	// 启用集合竞价CODE
	public final static String GATHERBID_USE_CODE = "1";
	// 不启用集合竞价CODE
	public final static String GATHERBID_NOT_USE_CODE = "0";
	// 启用集合竞价
	public final static String GATHERBID_USE = "启用";
	// 不启用集合竞价
	public final static String GATHERBID_NOT_USE = "不启用";

	/**
	 * BEAN NAME
	 */
	// Log MANAGER
	public final static String BEAN_LOG_MGR = "logManager";
	// TRADE MANAGER
	public final static String BEAN_TRADE_MGR = "traderManager";
	// MARKET MANAGER
	public final static String BEAN_MARKET_MGR = "marketManager";
	// STATQUERY MANAGER
	public final static String BEAN_STAT_QUERY_MGR = "statQueryManager";
	// FIRM MANAGER
	public final static String BEAN_FIRM_MGR = "firmManager";
	// Product MANAGER
	public final static String BEAN_PDCLASSIFY_MGR = "pdClassifyManager";
	// Bank Manager MANAGER
	public final static String BEAN_BANKMGR_MGR = "bankMgrManager";
	// Inform Manager MANAGER
	public final static String BEAN_INFOMGR_MGR = "infoMgrManager";
	// Inform Quo MANAGER
	public final static String BEAN_INFOQUO_MGR = "infoQuoManager";
	// Inform Ctg MANAGER
	public final static String BEAN_INFOCTG_MGR = "infoCtgManager";
	// InformOra Manager MANAGER
	public final static String BEAN_INFOORAMGR_MGR = "infoOraManager";
	// Trader MANAGER
	public final static String BEAN_TRDER_MGR = "traderManager";
	// User MANAGER
	public final static String BEAN_USER_MGR = "userManager";
	// User MANAGER
	public final static String BEAN_COMMON_MGR = "commonManager";
	// voucher MANAGER
	public final static String BEAN_VOUCHER_MGR = "voucherManager";
	// voucherOra MANAGER
	public final static String BEAN_VOUCHERORA_MGR = "voucherOraManager";
	// balance MANAGER
	public final static String BEAN_BALANCE_MGR = "firmBanlanceManager";
	// balanceOra MANAGER
	public final static String BEAN_BALANCEORA_MGR = "firmBanlanceOraManager";
	// 资金流水
	public final static String BEAN_FUNDFLOW_MGR = "fundFlowManagerImpl";
	// 后台管理（系统用户、角色等）
	public final static String BEAN_SYSTEMMGR_MGR = "systemMgrManager";
	// 交手相关
	public final static String BEAN_DELIVERY_MGR = "deliveryManager";
	// message
	public final static String BEAN_MESSAGE_MGR = "messageManager";

	// Leads MANAGER
	public final static String BEAN_LEADSMGR_MGR = "leadsManager";
	// order MANAGER
	public final static String BEAN_ORDERMGR_MGR = "orderManager";
	// sapply MANAGER
	public final static String BEAN_SAPPLYMGR_MGR = "sapplyManager";

	// 极光推送服务
	public final static String BEAN_PUSH_MGR = "pushManager";
	// app推荐消息服务
	public final static String BEAN_PUSH_MSG_FOR_APP_MGR = "pushMsgForAppManager";
	// 微信消息服务
	public final static String BEAN_WEIXIN_API_MGR = "weiXinApiManager";

	// 化交kpi消息服务
	public final static String BEAN_KPI_API_MGR = "kpiApiManager";
	
	// 特殊流程记录
	public final static String BEAN_SPECIALOPR_MGR = "specialOprManagerImpl";

	// 优惠券
	public final static String BEAN_COUPON_MGR = "couponComponnetManager";
	
	//发票业务
	public final static String BEAN_INVOICE_MGR = "invoiceComponnetManager";
	
	//物流配送相关
	public final static String BEAN_LOGIST_MGR = "logisticsRateMgrImpl";
	
	//配送交收相关
	public final static String BEAN_DISTRIBUTION_MGR = "distributionMgr";
	
	//仓库地址交易场关系
	public final static String BEAN_WHADDRTEMPLATERLSP_MGR = "WHAddrTemplateRlspManager";
	
	//优惠券相关
	public final static String BEAN_NEWMARKET_MGR = "newMarkeTManager";
	
	//竞猜活动有关相关
	public final static String BEAN_QUIZ_ACTIVITIES_MGR = "quizActivitiesManager";

	//产品关注关相关
	public final static String BEAN_ATTENTION__MGR = "attentionManager";
	
	//保价相关
	public final static String BEAN_INSURANCE_POLICY__MGR = "insurancePolicyComponent";

	/**
	 * 产品Tag
	 */
	// PE
	public final static Integer I_INFOTAG_PE = 1;
	// PP
	public final static Integer I_INFOTAG_PP = 2;
	// PVC
	public final static Integer I_INFOTAG_PVC = 3;
	
	
	//导出最大条数
	public final static int EXPORT_MAX_COUNT = 1000;

	/**
	 * voucherModel
	 */
	// 入金-存款
	public final static String VOUCHERMODE_RUJIN_CUNKUAN = "1";
	// 出金-存款
	public final static String VOUCHERMODE_CHUJIN_CUNKUAN = "2";
	// 入金-银商
	public final static String VOUCHERMODE_RUJIN_YINSHANG = "3";
	// 出金-银商
	public final static String VOUCHERMODE_CHUJIN_YINSHANG = "4";
	// 付交易商货款
	public final static String VOUCHERMODE_FU_HUO_KUAN = "5";
	// 收交易商货款
	public final static String VOUCHERMODE_SHOU_HUO_KUAN = "6";
	// 退保证金
	public final static String VOUCHERMODE_TUI_BAOZHENGJIN = "7";
	// 收保证金
	public final static String VOUCHERMODE_SHOU_BAOZHENGJIN = "8";
	// 退违约金
	public final static String VOUCHERMODE_TUI_WEIYUEJIN = "9";
	// 收违约金
	public final static String VOUCHERMODE_SHOU_WEIYUEJIN = "10";
	// 退运费
	public final static String VOUCHERMODE_TUI_YUNFEI = "11";
	// 收运费
	public final static String VOUCHERMODE_SHOU_YUNFEI = "12";
	// 退交易手续费
	public final static String VOUCHERMODE_TUI_JIAOYI_SHOUXUFEI = "13";
	// 收交易手续费
	public final static String VOUCHERMODE_SHOU_JIAOYI_SHOUXUFEI = "14";
	// 退交收手续费
	public final static String VOUCHERMODE_TUI_JIAOSHOU_SHOUXUFEI = "15";
	// 收交收手续费
	public final static String VOUCHERMODE_SHOU_JIAOSHOU_SHOUXUFEI = "16";
	// 退出入库费
	public final static String VOUCHERMODE_TUI_CHURUKU_FEI = "17";
	// 收出入库费
	public final static String VOUCHERMODE_SHOU_CHURUKU_FEI = "18";
	// 退仓储费
	public final static String VOUCHERMODE_TUI_CANGCHU_FEI = "19";
	// 收仓储费
	public final static String VOUCHERMODE_SHOU_CANGCHU_FEI = "20";

	// 收交收保证金
	public final static String VOUCHERMODE_SHOU_JIAOSHOU_BAOZHENGJING = "21";
	// 退交收保证金
	public final static String VOUCHERMODE_TUI_JIAOSHOU_BAOZHENGJING = "22";

	// 收滞纳金
	public final static String VOUCHERMODE_SHOU_ZHI_NA_JIN = "23";
	
	// 付运费
	public final static String VOUCHERMODE_FU_YUNFEI = "24";
	
	// 充值手续费
	public final static String VOUCHERMODE_COUPON_FEE = "27";
	
	// 保价赔付
	public final static String VOUCHERMODE_INSURED_PAYMENT = "28";
	
	// 收解约相关费用
	public final static String VOUCHERMODE_SHOU_JIEYUE = "29";
	
	// 付解约相关费用
	public final static String VOUCHERMODE_FU_JIEYUE = "30";
	
	//开票类型    1:货款 5：手续费
	public final static String FEEPAYMENT="1";
    
	public final static String COUNTERFEE="5";
	
	public final static String INVOICEFE_ENABLE="1";
	
	public final static String INVOICEFE_DISABLE ="0";
	
	// 上传下载URL
	public final static String UPLOAD_LOCAL_URL = "http://fms.dev.shcem.com/mapi/file/uploadfileformDonet";
	public final static String UPLOAD_DEV_URL = "http://fms.dev.shcem.com/mapi/file/uploadfileformDonet";
	public final static String UPLOAD_TEST_URL = "http://fms.test.shcem.com/mapi/file/uploadfileformDonet";
	public final static String UPLOAD_UAT_URL = "http://fms.uat.shcem.com/mapi/file/uploadfileformDonet";
	public final static String UPLOAD_DEPLOY_URL = "http://fms.inner.shcem.com/mapi/file/uploadfileformDonet";

	// 消息推送UEL_LOCAL
	public final static String PUSH_MESSAGE_LOCAL = "http://192.168.60.204:8075/api/pub";
	// 消息推送UEL_dev
	public final static String PUSH_MESSAGE_DEV = "http://192.168.60.204:8075/api/pub";
	// 消息推送UEL_test
	public final static String PUSH_MESSAGE_TEST = "http://192.168.68.101:8075/api/pub";
	// 消息推送UEL_UAT
	public final static String PUSH_MESSAGE_UAT = "http://192.168.68.21:8075/api/pub";
	// 消息推送UEL_DEPLOY
	public final static String PUSH_MESSAGE_DEPLOY = "http://192.168.18.21:8075/api/pub";

	public final static String MODE_LOCAL = "local";
	public final static String MODE_DEV = "dev";
	public final static String MODE_TEST = "test";
	public final static String MODE_UAT = "uat";
	public final static String MODE_DEPLOY = "deploy";

	// RMI OPEN Flag
	public final static String OPENFLG_CLOSE = "0";
	public final static String OPENFLG_OPEN = "1";

	public final static String KAFKA_PROPERITES_CFILE = "/mq/kafka_consumer.properties";
	public final static String KAFKA_PROPERITES_PFILE = "/mq/kafka_producer.properties";

	public final static String DROOLS_PROPERITES_FILE = "/droolsapi.properties";
	public final static String ACTIVITI_PROPERITES_FILE = "/activitiapi.properties";
	// Jpush params key
	public final static String JPUSH_APP_KEY_STR = "_appKey";
	public final static String JPUSH_MASTER_SECRET_STR = "_masterSecret";

	// redis params key
	public final static String REDIS_HJ_IP_STR = "_redis_hj_ip";
	public final static String REDIS_HJ_PORT_STR = "_redis_hj_port";

	// Jpush params value
	public final static String JPUSH_APP_KEY = Common.getJPushAppKey();
	public final static String JPUSH_MASTER_SECRET = Common.getJPushMasterSecret();

	// redis config
	public final static String REDIS_HJ_IP = Common.getRedisHJIp();
	public final static int REDIS_HJ_PORT = Common.getRedisHJPort();
	public final static int REDIS_HJ_TIMEOUT = 5000;

	// 加密的key值
	public final static String DES_KEY = "shcem3436egewTqWyreEWT2ee";
	public final static String DES_KEY2 = "shcem3436egewkdaleEWT2ee";
	
	// BaseException errorCode
	public final static int EXCEPTION_ERROR_CODE_1001 = 1001;

	// KPI用
	public final static String KPI_WAITBUYER_PAY = "WaitBuyerPay";
	public final static String KPI_WAITBUYER_PAY_Name = "待买方付款";
	public final static String KPI_BUYERPAYED = "BuyerPayed";
	public final static String KPI_BUYERPAYED_Name = "买方已付化交";
	public final static String KPI_DELIVERING = "Delivering";
	public final static String KPI_DELIVERING_NAME = "交收处理中";
	public final static String KPI_BID_TOSELLER = "BidToSeller";
	public final static String KPI_BID_TOSELLER_NAME = "已传上家";
	public final static String KPI_RECEIVER_UPED = "ReceiverUploaded";
	public final static String KPI_RECEIVER_UPED_NAME = "签收单已上传";
	public final static String KPI_DELIVERYCONFIMED = "DeliveryConfirmed";
	public final static String KPI_DELIVERYCONFIMED_NAME = "物流签收数量已确认";
	public final static String KPI_WAITRISK_CONFIRM = "WaitRiskConfirm";
	public final static String KPI_WAITRISK_CONFIRM_NAME = "待风控审核";
	public final static String KPI_RISK_DENIED = "RiskDenied";
	public final static String KPI_RISK_DENIED_NAME = "风控拒绝";
	public final static String KPI_WAITSELLER_CONFIRM = "WaitSellerConfirm";
	public final static String KPI_WAITSELLER_CONFIRM_NAME = "风控通过，待卖家确认";
	public final static String KPI_MOREORLESS = "MoreOrLess";
	public final static String KPI_MOREORLESS_NAME = "溢短处理中";
	public final static String KPI_FINISHED = "Finished";
	public final static String KPI_FINISHED_NAME = "交易完成";
	public final static String KPI_BUYER_BREAK = "BuyerBreak";
	public final static String KPI_BUYER_BREAK_NAME = "买家违约";
	public final static String KPI_SELLER_BREAK = "SellerBreak";
	public final static String KPI_SELLER_BREAK_NAME = "卖家违约";
	
	public final static String KPI_DEAL = "deal";
	public final static String KPI_DEAL_NAME = "成交";
	public final static String KPI_REQUEST = "request";
	public final static String KPI_REQUEST_NAME = "询盘";
	public final static String KPI_LOGIN = "login";
	public final static String KPI_LOGIN_NAME = "登陆";
	
	public final static String KPI_SELLER_TRADER = "SellerTrader";
	public final static String KPI_SELLER_TRADER_NAME = "卖方交易商";
	public final static String KPI_BUYER_TRADER = "BuyerTrader";
	public final static String KPI_BUYER_TRADER_NAME = "买方交易商";
	public final static String KPI_BOTH_TRADER = "BothTrader";
	public final static String KPI_BOTH_TRADER_NAME = "买卖方交易商";
	public final static String KPI_User = "User";
	public final static String KPI_User_NAME = "用户";
	
	// 农业银行专用
	public final static String ABC_FUNCTIONID_MARKET_SIGNUP = "0000";
	public final static String ABC_FUNCTIONID_MARKET_SIGNOFF = "0001";
	public final static String ABC_FUNCTIONID_MARKET_ORDERPAY = "0026";
	public final static String ABC_MARKET_SIGN_MERCHANTID = "[[MerchantID]]";
	public final static String ABC_MARKET_SIGN_MERCHANTID_DESC = "交易市场编号：";
	public final static String ABC_MARKET_SIGN_MERCHANTNAME = "[[MerchantName]]";
	public final static String ABC_MARKET_SIGN_MERCHANTNAME_DESC = "交易市场名称：";
	public final static String ABC_MARKET_SIGN_TRXNO = "[[MerchantTrxNo]]";
	public final static String ABC_MARKET_SIGN_TRXNO_DESC = "交易流水号：";
	public final static String ABC_MARKET_SIGN_FUNCTIONID = "[[FunctionID]]";
	public final static String ABC_MARKET_SIGN_FUNCTIONID_DESC = "交易名称：";
	public final static String ABC_MARKET_SIGN_CUSTNAME = "[[CustName]]";
	public final static String ABC_MARKET_SIGN_CUSTNAME_DESC = "客户名称：";
	public final static String ABC_MARKET_SIGN_SIGNTIME = "[[_time]]";
	public final static String ABC_MARKET_SIGN_SIGNTIME_DESC = "签约时间：";
	public final static String ABC_MARKET_SIGN_SIGNOFFTIME = "[[_time]]";
	public final static String ABC_MARKET_SIGN_SIGNOFFTIME_DESC = "解约时间：";
	public final static String ABC_MARKET_SIGN_TRXTIME = "[[_time]]";
	public final static String ABC_MARKET_SIGN_TRXTIME_DESC = "交易时间：";
	public final static String ABC_MARKET_SIGN_PAYAMOUNT = "[[PayAmount]]";
	public final static String ABC_MARKET_SIGN_PAYAMOUNT_DESC = "支付金额：";
	public final static String ABC_MARKET_SIGN_ORDERNO = "[[OrderNo]]";
	public final static String ABC_MARKET_SIGN_ORDERNO_DESC = "订单号：";
	
	//paymentLog返回code
	public final static Integer PAYMENT_STATUS_FAILED = -1;
	public final static Integer PAYMENT_STATUS_SUCCESS = 1;
	
	//paymentDetailLog返回code
	public final static Integer PAYMENT_DETAIL_STATUS_FAILED = -1;
	public final static Integer PAYMENT_DETAIL_STATUS_NOTYET = 0;
	public final static Integer PAYMENT_DETAIL_STATUS_SUCCESS = 1;
	public final static Integer PAYMENT_DETAIL_STATUS_WAITING = 2;
	
	// 奖金幅度范围正负 25
	public final static Integer FOLAT_VALUE = 25;
	
	public final static String CLOSE_TIME = "15:50:00";
	
	/**
	 * 期限市场撤销询盘和挂盘的区分
	 * 0|前台撤询盘 ; 1|后台释放询盘; 2|Job撤询盘
	 */
	public final static int BACK_FRONT = 0;
	
	public final static int BACK_END = 1;
	
	public final static int BACK_JOB = 2;

	/**
	 * 奖金设置
	 * @param moneyTerm 中奖等级
	 * @return
	 */
	public static BigDecimal getQuizMoney(int moneyTerm) {
		if (moneyTerm ==1) {
			return new BigDecimal(200);
		}else if (moneyTerm ==2) {
			return new BigDecimal(100);
		}else if (moneyTerm ==3) {
			return new BigDecimal(50);
		}else {
			return new BigDecimal(0);
		}
	}
}
