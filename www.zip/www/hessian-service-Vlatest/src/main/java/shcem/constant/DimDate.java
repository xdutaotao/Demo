package shcem.constant;

import java.util.HashMap;
import java.util.Map;

/**
 * 日期维表
 * @author 老鱼
 * */
public class DimDate {
	public static Map<String, Object[]> workDayMap = new HashMap<String, Object[]>() {
		{
			//日期， 是否工作日，该月第几个工作日
			put("20161201", new Object[]{1,1});
			put("20161202", new Object[]{1,2});
			put("20161203", new Object[]{0,2});
			put("20161204", new Object[]{0,2});
			put("20161205", new Object[]{1,3});
			put("20161206", new Object[]{1,4});
			put("20161207", new Object[]{1,5});
			put("20161208", new Object[]{1,6});
			put("20161209", new Object[]{1,7});
			put("20161210", new Object[]{0,7});
			put("20161211", new Object[]{0,7});
			put("20161212", new Object[]{1,8});
			put("20161213", new Object[]{1,9});
			put("20161214", new Object[]{1,10});
			put("20161215", new Object[]{1,11});
			put("20161216", new Object[]{1,12});
			put("20161217", new Object[]{0,12});
			put("20161218", new Object[]{0,12});
			put("20161219", new Object[]{1,13});
			put("20161220", new Object[]{1,14});
			put("20161221", new Object[]{1,15});
			put("20161222", new Object[]{1,16});
			put("20161223", new Object[]{1,17});
			put("20161224", new Object[]{0,17});
			put("20161225", new Object[]{0,17});
			put("20161226", new Object[]{1,18});
			put("20161227", new Object[]{1,19});
			put("20161228", new Object[]{1,20});
			put("20161229", new Object[]{1,21});
			put("20161230", new Object[]{1,22});
			put("20161231", new Object[]{0,22});
			put("20170101", new Object[]{0,0});
			put("20170102", new Object[]{0,0});
			put("20170103", new Object[]{1,1});
			put("20170104", new Object[]{1,2});
			put("20170105", new Object[]{1,3});
			put("20170106", new Object[]{1,4});
			put("20170107", new Object[]{0,4});
			put("20170108", new Object[]{0,4});
			put("20170109", new Object[]{1,5});
			put("20170110", new Object[]{1,6});
			put("20170111", new Object[]{1,7});
			put("20170112", new Object[]{1,8});
			put("20170113", new Object[]{1,9});
			put("20170114", new Object[]{0,9});
			put("20170115", new Object[]{0,9});
			put("20170116", new Object[]{1,10});
			put("20170117", new Object[]{1,11});
			put("20170118", new Object[]{1,12});
			put("20170119", new Object[]{1,13});
			put("20170120", new Object[]{1,14});
			put("20170121", new Object[]{0,14});
			put("20170122", new Object[]{1,15});
			put("20170123", new Object[]{1,16});
			put("20170124", new Object[]{1,17});
			put("20170125", new Object[]{1,18});
			put("20170126", new Object[]{1,19});
			put("20170127", new Object[]{0,19});
			put("20170128", new Object[]{0,19});
			put("20170129", new Object[]{0,19});
			put("20170130", new Object[]{0,19});
			put("20170131", new Object[]{0,19});
			
			put("20170201", new Object[]{0,0});
			put("20170202", new Object[]{0,0});
			put("20170203", new Object[]{1,1});
			put("20170204", new Object[]{1,2});
			put("20170205", new Object[]{0,2});
			put("20170206", new Object[]{1,3});
			put("20170207", new Object[]{1,4});
			put("20170208", new Object[]{1,5});
			put("20170209", new Object[]{1,6});
			put("20170210", new Object[]{1,7});
			put("20170211", new Object[]{0,7});
			put("20170212", new Object[]{0,7});
			put("20170213", new Object[]{1,8});
			put("20170214", new Object[]{1,9});
			put("20170215", new Object[]{1,10});
			put("20170216", new Object[]{1,11});
			put("20170217", new Object[]{1,12});
			put("20170218", new Object[]{0,12});
			put("20170219", new Object[]{0,12});
			put("20170220", new Object[]{1,13});
			put("20170221", new Object[]{1,14});
			put("20170222", new Object[]{1,15});
			put("20170223", new Object[]{1,16});
			put("20170224", new Object[]{1,17});
			put("20170225", new Object[]{0,17});
			put("20170226", new Object[]{0,17});
			put("20170227", new Object[]{1,18});
			put("20170228", new Object[]{1,19});
			
			put("20170301", new Object[]{1,1});
			put("20170302", new Object[]{1,2});
			put("20170303", new Object[]{1,3});
			put("20170304", new Object[]{0,3});
			put("20170305", new Object[]{0,3});
			put("20170306", new Object[]{1,4});
			put("20170307", new Object[]{1,5});
			put("20170308", new Object[]{1,6});
			put("20170309", new Object[]{1,7});
			put("20170310", new Object[]{1,8});
			put("20170311", new Object[]{0,8});
			put("20170312", new Object[]{0,8});
			put("20170313", new Object[]{1,9});
			put("20170314", new Object[]{1,10});
			put("20170315", new Object[]{1,11});
			put("20170316", new Object[]{1,12});
			put("20170317", new Object[]{1,13});
			put("20170318", new Object[]{0,13});
			put("20170319", new Object[]{0,13});
			put("20170320", new Object[]{1,14});
			put("20170321", new Object[]{1,15});
			put("20170322", new Object[]{1,16});
			put("20170323", new Object[]{1,17});
			put("20170324", new Object[]{1,18});
			put("20170325", new Object[]{0,18});
			put("20170326", new Object[]{0,18});
			put("20170327", new Object[]{1,19});
			put("20170328", new Object[]{1,20});
			put("20170329", new Object[]{1,21});
			put("20170330", new Object[]{1,22});
			put("20170331", new Object[]{1,23});
		}
	};
}
