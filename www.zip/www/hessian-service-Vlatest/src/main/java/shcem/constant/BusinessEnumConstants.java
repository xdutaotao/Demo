package shcem.constant;

/**
 * 业务枚举常量
 * 
 * @author wangshuai
 *
 */
public class BusinessEnumConstants {

	public enum RoleType {
		SYSADMIN("超级管理员","0000"),
		// 客服
		CSRoleCode("客服", "0101"),
		// 物流普通操作员
		LogisticsGeneralerRoleCode("物流制单操作员", "0201"),
		// 物流审核人员
		LogisticsAuditRoleCode("物流审核人员", "0202"),
//		// 物流Leader
//		LogisticsLeaderRoleCode("物流Leader", "0203"),
//		// 物流制单人员
//		LogisticsMakeCardRoleCode("物流制单人员", "0204"),
		// 风控普通操作员
		ControlGeneralerRoleCode("风控普通操作员", "0301"),
		// 风控审核人员
		ControlAuditRoleCode("风控审核人员", "0302"),
//		// 风控Leader
//		ControlLeaderRoleCode("风控Leader", "0303"),
//		// 风控制单人员
//		ControlMakeCardRoleCode("风控制单人员", "0304"),
		// 尾调普通操作员
//		AdjustGeneralerRoleCode("尾调普通操作员", "0401"),
		// 尾调审核人员
//		AdjustAuditRoleCode("尾调审核人员", "0402"),
		
		//前台客户
		BackEndClient("前台客户", "0501"),
		
		//付货款人员
		//货款申请人员
		SubmitPayRoleCode("付货款申请人员","0601"),
		//付货款审核人员
		AuditPayRoleCode("付货款审核人员","0602"),
		
		//中石化配送拆单审核角色
		SinopecAuditRoleCode("配送变更审核人员","0701"),
		
		// 物流仓库管理员
		LogisticsWarehouseAdminRoleCode("物流仓库管理员","0801");
		// 成员变量
		private String name;
		private String value;

		// 构造方法
		private RoleType(String name, String value) {
			this.name = name;
			this.value = value;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getValue() {
			return value;
		}

		public void setValue(String value) {
			this.value = value;
		}

	}

}
