package shcem.constant;

/**
 * 成交状态
 * @author sunf
 *
 */
public enum TradeStatus {
	/*
	 * 123
	 */
	TradedUnpaid("待买方付款","1"),
	WaitDelivery("买方已付化交","5"),
	DeliveryIn("交收处理中","10"),
	FreightPaid("买家已付运费","12"),
	WaitSign("已传上家","15"),
	SignIn("签收单已上传","20"),
	Signed("物流签收数量已确认","25"),
	WaitApprove("待风控审核","30"),
	Unapprove("风控拒绝","35"),
	Approved("风控通过，待卖家确认","40"),
	OvershortIn("溢短处理中","45"),
	SellerDefault("交易完成","50"),
	BuyerBreach("买家违约","55"),
	SellerBreach("卖家违约","60"),
	AllBreach("双方违约","65");
	
	private String desc; 
	private String value;
	
	
	/**
	 * @param desc
	 * @param value
	 */
	private TradeStatus(String desc, String value) {
		this.desc = desc;
		this.value = value;
	}
	
	public String getDesc() {
		return desc;
	}


	public void setDesc(String desc) {
		this.desc = desc;
	}


	public String getValue() {
		return value;
	}


	public void setValue(String value) {
		this.value = value;
	}
	
	
}
