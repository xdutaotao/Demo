package shcem.constant;

import java.util.ArrayList;
import java.util.List;

/**
 * 交收状态枚举
 * 
 * @author sunf
 *
 */
public enum DeliveryStatus {
	Apply("买家已申请", "1"), 
	WaitApplyApprove("待审核", "5"), 
	ApplyPass("审核通过", "10"), 
	ApplyRefuse("审核拒绝", "15"),
	PaidFreightByBuyer("买家已付运费","17"),
	WaitSign("已传上家","20"),
	SignIn("签收单已上传","25"),
	TakenQuantity("物流签收数量已确认","30"),
	WaitControlApprove("待风控审核","35"),
	ControlPass("风控审核通过","40"),
	ControlRefuse("风控拒绝","45"),
	Shorting("溢短处理中","50"),
	Finish("交易完成","55"),
	BuyViolate("买家违约","60"),
	SellViolate("卖家违约","65"),
	Repeal("已撤销","70"),
	Cancelled("已取消","75"); // 中石化配送交收单变更状态

	
	private String desc;
	private String value;
	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	private DeliveryStatus(String _desc, String _value) {
		this.desc = _desc;
		this.value = _value;
	}
	
	 
	
	public static void main(String [] args){
		List<String> list=new ArrayList<String>();
		
		for(DeliveryStatus status :DeliveryStatus.values()){
			list.add(status.desc);
		}
		System.out.println(list.toString());
	}
}
