package shcem.constant;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import shcem.base.query.QueryConditions;
import shcem.trade.component.ITraderManager;
import shcem.trade.dao.model.Delivery;
import shcem.trade.dao.model.Order;
import shcem.trade.dao.model.TradeTemplate;
import shcem.trade.util.TradeSysData;

public class TradeTemplateConstant {

	private static Map<Integer,TradeTemplate> map = null;
	private TradeTemplateConstant(){}
	public static Map<Integer,TradeTemplate> getTradeTemplateList() {
		if (map == null){
			map = new HashMap<Integer, TradeTemplate>();
			ITraderManager traderManager = (ITraderManager) TradeSysData.getBean(Constants.BEAN_TRADE_MGR);
			QueryConditions qc = new QueryConditions();
			qc.addCondition("t.DISABLED", "=", "0");
			List<TradeTemplate> tradeTemplateList = traderManager.getTradeTemplateList(qc, null);
			 for(TradeTemplate tradeTemplate : tradeTemplateList){
				 map.put(tradeTemplate.getTradeTmptId(), tradeTemplate);
			 }
			 return map;
		}
		return map;
	}
	/**
	 * 重新加载
	 */
	public static void reload() {
		map = null;
	}
	
	public static void main(String args[]) throws ParseException{
		  SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd");
		  Date date = new Date();// 定义Date 
		  Calendar calendar = Calendar.getInstance();
		  calendar.setTime(date);
		  calendar.add(Calendar.DATE, 2);
		  date = calendar.getTime();
		  System.err.println(date);
		  System.err.println(sdf.parse(sdf.format(date)));
		  
//		  System.out.println(sdf.parse(sdf.format(date2)));
	}
	
	 public static Date getDate(Date date){
		  Calendar calendar = Calendar.getInstance();
		  calendar.setTime(date);
		  calendar.add(Calendar.DATE, 1);
		  Date date1 = new Date(calendar.getTimeInMillis());
		  return date1;
	 }
	/**
	 * 
	 * @param tradeTemplateId 交易场ID
	 * @param dateType 0当时 1隔日
	 * @param price 成交价
	 * @param totalQuantity 违约批数
	 * @param breakPromiseType 1：收买家违约金 2：付卖家违约金 3 收卖家违约金 4付买家违约金
	 * @return
	 * @throws ParseException 
	 */
	public static BigDecimal getBreakPromiseFee(Order order,int totalQuantity,Integer breakPromiseType) throws ParseException{
		Integer tradeTemplateId = order.getTradeTmptId();//交易场ID
		if (map == null){
			TradeTemplateConstant.getTradeTemplateList();
		}
		TradeTemplate tradeTemplate = map.get(tradeTemplateId);//交易场
		//买方违约日
		int buyerBreakPromise = tradeTemplate.getBuyerBreakPromise();
		//卖方违约日
		int sellerBreakPromise = tradeTemplate.getSellerBreakPromise();
		
		BigDecimal price = order.getPrice();
		BigDecimal totalQuantitys = new BigDecimal(totalQuantity).multiply(order.getTradeUnitNumber());
		
		Date currentDate = new Date();
		//货品类型，0：现货 1：预售
		String dateType = null; 
		int tradeType = order.getTradeType();
		if(tradeType != 1){
			if(breakPromiseType == 1 || breakPromiseType == 3){//收买家违约金
				SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd");
				
				Date tradeDate = sdf.parse(sdf.format(order.getTradeDate()));
				//现货，买家违约，收卖家违约金，往后推两天
				currentDate =sdf.parse(sdf.format(currentDate));
				if(tradeDate.getTime() >= currentDate.getTime()){//当时
					dateType = "0";
				}else {//隔天
					dateType = "1";
				}
			}
		}else {
			if(breakPromiseType == 1){//收买家违约金
				SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd");
				if(order.getSellArrivalTime() == null){
					dateType = "0";
				}else {
					Date SellArrivalTime = sdf.parse(sdf.format(order.getSellArrivalTime()));
					Calendar calendar = Calendar.getInstance();
					calendar.setTime(SellArrivalTime);
					calendar.add(Calendar.DATE, buyerBreakPromise);
					SellArrivalTime = calendar.getTime();
					currentDate =sdf.parse(sdf.format(currentDate));
					if(SellArrivalTime.getTime() >= currentDate.getTime()){//当时
						dateType = "0";
					}else {//隔日
						dateType = "1";
					}
				}
			}else if(breakPromiseType == 3){//收卖家违约金
				SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd");
				
				Date delievryDate = sdf.parse(sdf.format(order.getDeliveryEndDate()));
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(delievryDate);
				calendar.add(Calendar.DATE, sellerBreakPromise);
				delievryDate = calendar.getTime();
				currentDate =sdf.parse(sdf.format(currentDate));
				if(delievryDate.getTime() >= currentDate.getTime()){//当时
					dateType = "0";
				}else {//隔天
					dateType = "1";
				}
			}
		}
		
		BigDecimal amount = null;
		// 违约金T+0类型 
		Integer breakProFeeT0Type = null;
		BigDecimal breakProFeeT0 = null;	
		// 收违约金T+0类型
		Integer recBreakProFeeT0Type = null;
		BigDecimal recBreakProFeeT0 = null;
		// 违约金T+N类型 
		Integer breakProFeeTNType = null;
		BigDecimal breakProFeeTN = null;	
		// 收违约金T+0类型
		Integer recBreakProFeeTNType = null;
		BigDecimal recBreakProFeeTN = null;
		// 1：收买家违约金
		if (1 == breakPromiseType){
			if ("0".equals(dateType)){
				recBreakProFeeT0Type = tradeTemplate.getBuyerRecBreakProFeeT0Type();
				recBreakProFeeT0 = tradeTemplate.getBuyerRecBreakProFeeT0();
				if (recBreakProFeeT0Type == 1){//绝对值
					amount = totalQuantitys.multiply(recBreakProFeeT0);
				}else{//百分比
					amount = price.multiply(totalQuantitys).multiply(recBreakProFeeT0).divide(new BigDecimal(100),2,BigDecimal.ROUND_CEILING);
				}
			}else{
//				recBreakProFeeTNType = tradeTemplate.getBuyerRecBreakProFeeTNType();
//				recBreakProFeeTN = tradeTemplate.getBuyerRecBreakProFeeTN();
//				if (recBreakProFeeTNType == 1){
//					amount = totalQuantitys.multiply(recBreakProFeeTN);
//				}else{
//					amount = price.multiply(totalQuantitys).multiply(recBreakProFeeTN).divide(new BigDecimal(100),2,BigDecimal.ROUND_CEILING);
//				}
				// 修正 bugId:4249
				// 卖家交易保证金算法 默认为 1：绝对值，2：百分比
				recBreakProFeeTNType = order.getSellDepositAlgr();
				// 卖家交易保证金数值
				recBreakProFeeTN = order.getSellDepositRate();
				if (recBreakProFeeTNType == 1){
					amount = totalQuantitys.multiply(recBreakProFeeTN);
				}else{
					//amount = price.multiply(totalQuantitys).multiply(recBreakProFeeTN).divide(new BigDecimal(100),2,BigDecimal.ROUND_CEILING);
					// 前台存 保证金的比例时，已经除了100，所以这里不用在处理
					amount = price.multiply(totalQuantitys).multiply(recBreakProFeeTN);
				}
			}
		}
		
		// 2：付卖家违约金
		if (2 == breakPromiseType){
			if ("0".equals(dateType)){
				breakProFeeT0Type = tradeTemplate.getSellerBreakProFeeT0Type();
				breakProFeeT0 = tradeTemplate.getSellerBreakProFeeT0();
				if (breakProFeeT0Type == 1){//绝对值
					amount = totalQuantitys.multiply(breakProFeeT0);
				}else{//百分比
					amount = price.multiply(totalQuantitys).multiply(breakProFeeT0).divide(new BigDecimal(100),2,BigDecimal.ROUND_CEILING);
				}
			}else{
				breakProFeeTNType = tradeTemplate.getSellerBreakProFeeTNType();
				breakProFeeTN = tradeTemplate.getSellerBreakProFeeTN();
				if (breakProFeeTNType == 1){
					amount = totalQuantitys.multiply(breakProFeeTN);
				}else{
					amount = price.multiply(totalQuantitys).multiply(breakProFeeTN).divide(new BigDecimal(100),2,BigDecimal.ROUND_CEILING);
				}
			}
		}
		
		// 3 收卖家违约金
		if (3 == breakPromiseType){
			if ("0".equals(dateType)){
				recBreakProFeeT0Type = tradeTemplate.getSellerRecBreakProFeeT0Type();
				recBreakProFeeT0 = tradeTemplate.getSellerRecBreakProFeeT0();
				if (recBreakProFeeT0Type == 1){//绝对值
					amount = totalQuantitys.multiply(recBreakProFeeT0);
				}else{//百分比
					amount = price.multiply(totalQuantitys).multiply(recBreakProFeeT0).divide(new BigDecimal(100),2,BigDecimal.ROUND_CEILING);
				}
			}else{
//				recBreakProFeeTNType = tradeTemplate.getSellerRecBreakProFeeTNType();
//				recBreakProFeeTN = tradeTemplate.getSellerRecBreakProFeeTN();
//				if (recBreakProFeeTNType == 1){
//					amount = totalQuantitys.multiply(recBreakProFeeTN);
//				}else{
//					amount = price.multiply(totalQuantitys).multiply(recBreakProFeeTN).divide(new BigDecimal(100),2,BigDecimal.ROUND_CEILING);
//				}
				// 修正 bugId:4249
				// 卖家交易保证金算法 默认为 1：绝对值，2：百分比
				recBreakProFeeTNType = order.getSellDepositAlgr();
				// 卖家交易保证金数值
				recBreakProFeeTN = order.getSellDepositRate();
				if (recBreakProFeeTNType == 1){
					amount = totalQuantitys.multiply(recBreakProFeeTN);
				}else{
					// 前台存 保证金的比例时，已经除了100，所以这里不用在处理
					amount = price.multiply(totalQuantitys).multiply(recBreakProFeeTN);
				}
			}
		}
		
		// 4:付买家违约金
		if (4 == breakPromiseType){
			if ("0".equals(dateType)){
				breakProFeeT0Type = tradeTemplate.getBuyerBreakProFeeTypeT0();
				breakProFeeT0 = tradeTemplate.getBuyerBreakProFeeT0();
				if (breakProFeeT0Type == 1){//绝对值
					amount = totalQuantitys.multiply(breakProFeeT0);
				}else{//百分比
					amount = price.multiply(totalQuantitys).multiply(breakProFeeT0).divide(new BigDecimal(100),2,BigDecimal.ROUND_CEILING);
				}
			}else{
				breakProFeeTNType = tradeTemplate.getBuyerBreakProFeeTNType();
				breakProFeeTN = tradeTemplate.getBuyerBreakProFeeTN();
				if (breakProFeeTNType == 1){
					amount = totalQuantitys.multiply(breakProFeeTN);
				}else{
					amount = price.multiply(totalQuantitys).multiply(breakProFeeTN).divide(new BigDecimal(100),2,BigDecimal.ROUND_CEILING);
				}
			}
		}
		return amount;
	}
	/**
	 * 计算违约金的共通方法
	 * @param price
	 * @param quantity
	 * @param bsFlag
	 * @param dateType
	 * @param tradeTemplate
	 * @return
	 */
	private BigDecimal computePenalty(BigDecimal price,BigDecimal quantity,Integer bsFlag,String dateType,TradeTemplate tradeTemplate){
		BigDecimal amount = new BigDecimal(0);
		Integer feeAlgr = null;
		BigDecimal rate = new BigDecimal(0);
		if(bsFlag == 1){ //买方
			
		}else if(bsFlag == 0){//卖方
			
		}
		if (feeAlgr == 1){ //绝对值算法
			amount = quantity.multiply(rate);
		}else{ //百分比算法
			amount = price.multiply(quantity).multiply(rate).divide(new BigDecimal(100),2,BigDecimal.ROUND_CEILING);
		}
		return amount;
	}
}
