/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: ValueTxtView.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月30日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.service.model;

import shcem.base.dao.model.BaseObject;

/**
 * @author wlpod
 *
 */
public class ValueTxtView extends BaseObject implements java.io.Serializable,Cloneable  {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String value ="";
	private String text ="";
	private String name="";
	private Integer tagID=0;
	
	public ValueTxtView(String value, String text) {
		super();
		this.value = value;
		this.text = text;
		this.name = null;
		this.tagID = null;
		this.sUMMARYNO = null;
	}
	public ValueTxtView() {
		// TODO Auto-generated constructor stub
	}
	private String sUMMARYNO ="";
	
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
	public Integer getTagID() {
		return tagID;
	}
	public void setTagID(Integer tagID) {
		this.tagID = tagID;
	}
	public String getSUMMARYNO() {
		return sUMMARYNO;
	}
	public void setSUMMARYNO(String sUMMARYNO) {
		this.sUMMARYNO = sUMMARYNO;
	}
	
}
