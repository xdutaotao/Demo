package shcem.common.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.component.ICommonMgr;
import shcem.common.dao.model.CDictionary;
import shcem.constant.Constants;

public class DictionaryConstant {

	private static Map<String, List<CDictionary>> map = null;

	private DictionaryConstant() {
	}

	public static List<CDictionary> getDicListByENName(String paramENName) {
		if (map == null) {
			map = new HashMap<String, List<CDictionary>>();
			ICommonMgr commonMgr = (ICommonMgr) CommoSys.getBean(Constants.BEAN_COMMON_MGR);
			QueryConditions qc = new QueryConditions();
			qc.addCondition("DISABLED", "=", "0");
			PageInfo pageInfo = new PageInfo();
			pageInfo.setPageSize(0);
			pageInfo.setPageNo(0);
			pageInfo.addOrderField("ENName", false);
			pageInfo.addOrderField("DictID", false);
			List<CDictionary> dictionaryList = commonMgr.getDictionaryList(qc, pageInfo);

			for (CDictionary tempModel : dictionaryList) {
				String ENName = tempModel.getENName();
				if (!map.containsKey(ENName)) {
					map.put(ENName, new ArrayList<CDictionary>());
				}
			}

			for (CDictionary tempModel : dictionaryList) {
				String ENName = tempModel.getENName();
				map.get(ENName).add(tempModel);
			}
		}
		if(map.containsKey(paramENName)){
			return map.get(paramENName);
		}else{
			return new ArrayList<CDictionary>();
		}
	}

	/**
	 * 重新加载
	 */
	public static void reload() {
		map = null;
	}
}
