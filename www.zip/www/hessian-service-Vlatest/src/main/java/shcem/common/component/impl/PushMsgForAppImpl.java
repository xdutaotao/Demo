/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: PushMsgForAppServiceImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年8月9日 　喻剑平  Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.component.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;

import cn.jpush.api.common.resp.APIConnectionException;

import com.foxinmy.weixin4j.model.WeixinAccount;
import com.foxinmy.weixin4j.mp.api.TmplApi;
import com.foxinmy.weixin4j.mp.message.TemplateMessage;
import com.foxinmy.weixin4j.mp.model.TemplateMessageInfo;
import com.foxinmy.weixin4j.mp.token.WeixinTokenCreator;
import com.foxinmy.weixin4j.token.TokenManager;
import com.foxinmy.weixin4j.util.Weixin4jConfigUtil;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.common.component.IJPushMgr;
import shcem.common.component.IPushMsgForApp;
import shcem.common.dao.ICMessageDAO;
import shcem.common.dao.model.MessageHistory;
import shcem.common.dao.model.MessageSendRelation;
import shcem.common.util.Weixin4jSettings;
import shcem.member.dao.UserWeiXinDAO;
import shcem.member.dao.model.UserWeiXin;
import shcem.util.CollectionUtil;
import shcem.util.CommonUtils;

public class PushMsgForAppImpl extends BaseManager implements IPushMsgForApp {

	/**创建和修改者*/
	private final String recUpdater = "admin";
	
	private ICMessageDAO cMessageDAO;
	private ICMessageDAO cMessageDAO_read;
	private UserWeiXinDAO userWeiXinDAO;
	
	public void setcMessageDAO(ICMessageDAO cMessageDAO) {
		this.cMessageDAO = cMessageDAO;
	}

	public void setcMessageDAO_read(ICMessageDAO cMessageDAO_read) {
		this.cMessageDAO_read = cMessageDAO_read;
	}

	public void setUserWeiXinDAO(UserWeiXinDAO userWeiXinDAO) {
		this.userWeiXinDAO = userWeiXinDAO;
	}

	/**
	 * app推送消息(广播)
	 * 
	 * 事务在component层，pushMsg不需要事务管理
	 * @param params
	 * @return
	 */
	@Override
	public String pushMsgWithBroadcast() {
		
		IJPushMgr mgr = new JPushMgrImpl();
		HashMap<String, String> extras = new HashMap<String, String>();
		Collection<String> aliases = new ArrayList<String>();
		extras.put("MsgCode", "msgCode1"); //消息类型
//		try {
//			mgr.sendPush("hi, this is testing! ", extras, aliases);
//		} catch (APIConnectionException e) {
//			e.printStackTrace();
//		}
		return null;
	}
	
	/**
	 * app推送消息
	 * 
	 * 事务在component层，pushMsg不需要事务管理
	 * @param params
	 * @return
	 */
	@Override
	public String pushMsg() {
		List<MessageSendRelation> sendRelations = new ArrayList<MessageSendRelation>();
		
		//获取需要推送的对象
		List<MessageHistory> msgPushes = cMessageDAO.getPushes();
		
		//发送消息
		for(MessageHistory msgPush: msgPushes) {
			IJPushMgr mgr = new JPushMgrImpl();
			HashMap<String, String> extras = new HashMap<String, String>();
			Collection<String> aliases = new ArrayList<String>();
			aliases.add(msgPush.getReceiveNumber()); //手机号
			extras.put("MsgCode", msgPush.getMsgCode()); //消息类型
			//极光推送
			try {
				mgr.sendPush(msgPush.getMessageContent(), extras, aliases);
			} catch (APIConnectionException e) {
				if (e.getMessage().contains("Read timed out")) {
					break;  //Read timed out一次30秒
				} else {
					continue;
				}
			} catch (Exception e) {
				continue;
			}
			
			//更新已经发送过消息的记录（isSend=1）
			cMessageDAO.updatePushesMsgHistory(msgPush.getMessageID());
			
			// app消息发送记录数据组装
			MessageSendRelation sendRelation = new MessageSendRelation();
			sendRelation.setMessageID(msgPush.getMessageID());
			sendRelation.setMsgSendType(1); //APP
			sendRelation.setReceiveNumber(msgPush.getReceiveNumber()); //手机号
			sendRelation.setMsgStatus(1);  //已发送
			sendRelation.setResultStatus(0);  //默认未读
			sendRelation.setRecCreateby(recUpdater); //定时任务写入
			sendRelation.setRecModifyby(recUpdater); //定时任务写入
			
			sendRelations.add(sendRelation);
		}
		
		//记录发送消息日志
		if (CollectionUtil.isValidCollect(sendRelations)) {
			cMessageDAO.insertBatchMessageSendRelation(sendRelations);
		}
		return null;
	}

	/**
	 * 通过手机号，获取用户已发送消息列表
	 * 
	 * @param params
	 * @return
	 */
	@Override
	public List<MessageHistory> getMessageHistoryList(String params) {
		 
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		
		List<Condition> conditionList = new ArrayList<Condition>();
	
		conditionList.add(new Condition("mh.ReceiveNumber", "=", "", "String", "ReceiveNumber"));
		conditionList.add(new Condition("mh.IsSend", "=", "", "int", "IsSend"));
		
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		if (queryModel != null) {
			// messageId检索条件追加
			if (queryModel.has("MessageID")) {
				String messageID = queryModel.getString("MessageID");
				if (!StringUtils.isBlank(messageID)) {
					qc.addCondition("mh.MessageID", "=", messageID);
				}
			}
			
			// msgCode检索条件追加
			if (queryModel.has("MsgCode")) {
				String msgCode = queryModel.getString("MsgCode");
				if (!StringUtils.isBlank(msgCode)) {
					qc.addCondition("mh.MsgCode", "=", msgCode);
				}
			}
						
			// MsgStatus检索条件追加
			if (queryModel.has("MsgStatus")) {
				String msgStatus = queryModel.getString("MsgStatus");
				if (!StringUtils.isBlank(msgStatus)) {
					qc.addCondition("mh.MsgStatus", "=", msgStatus);
				}
			}
		}
		
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		
		return cMessageDAO.getMessageHistoryList(qc, pageInfo);
	 }

	/**
	 * 标识信息为已读
	 * 
	 * @param params "messageID"
	 * @return
	 */
	@Override
	public void setMessageRead(int messageId) {
		cMessageDAO.updateMessageRead(messageId);
	}
	
	/**
	 * 标识信息为已读(通过手机号)
	 * 
	 * @param params "mobile"
	 * @return
	 */
	@Override
	public void setMessageReadByMobile(String mobile) {
		cMessageDAO.updateMessageReadByMobile(mobile);
	}
	
	/**
	 * 查询未读消息数量
	 * */
	@Override
	public int getUnReadMsgNum(String mobile) {
		return cMessageDAO_read.getUnReadMsgNum(mobile);
	}
}
