/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: ValueTxtView.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月30日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.dao.model;

import shcem.base.dao.model.BaseObject;

/**
 * @author wlpod
 *
 */
public class CDictionary extends BaseObject implements java.io.Serializable, Cloneable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer DictID;
	private String CNName;
	private String ENName;
	private String ValueName;
	private String ValueID;
	private Integer Disabled;

	public Integer getDictID() {
		return DictID;
	}

	public void setDictID(Integer dictID) {
		DictID = dictID;
	}

	public String getCNName() {
		return CNName;
	}

	public void setCNName(String cNName) {
		CNName = cNName;
	}

	public String getENName() {
		return ENName;
	}

	public void setENName(String eNName) {
		ENName = eNName;
	}

	public String getValueName() {
		return ValueName;
	}

	public void setValueName(String valueName) {
		ValueName = valueName;
	}

	public String getValueID() {
		return ValueID;
	}

	public void setValueID(String valueID) {
		ValueID = valueID;
	}

	public Integer getDisabled() {
		return Disabled;
	}

	public void setDisabled(Integer disabled) {
		Disabled = disabled;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
