/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: CateBrandPlaceView.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2017年7月10日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;

import shcem.base.dao.model.BaseObject;

/**
 * @author wlpod
 *
 */
public class CateBrandPlaceView extends BaseObject implements Serializable,
		Cloneable {
	private Integer categoryId;
	private String categoryName;
	private Integer brandId;
	private String brandName;
	private Integer sourcePlaceId;
	private String sourcePlaceName;
	private BigDecimal tradeUnitNumber;

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.dao.model.BaseObject#toString()
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.dao.model.BaseObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.dao.model.BaseObject#hashCode()
	 */
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @return the categoryId
	 */
	public Integer getCategoryId() {
		return categoryId;
	}

	/**
	 * @param categoryId
	 *            the categoryId to set
	 */
	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	/**
	 * @return the categoryName
	 */
	public String getCategoryName() {
		return categoryName;
	}

	/**
	 * @param categoryName
	 *            the categoryName to set
	 */
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	/**
	 * @return the brandId
	 */
	public Integer getBrandId() {
		return brandId;
	}

	/**
	 * @param brandId
	 *            the brandId to set
	 */
	public void setBrandId(Integer brandId) {
		this.brandId = brandId;
	}

	/**
	 * @return the brandName
	 */
	public String getBrandName() {
		return brandName;
	}

	/**
	 * @param brandName
	 *            the brandName to set
	 */
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	/**
	 * @return the sourcePlaceId
	 */
	public Integer getSourcePlaceId() {
		return sourcePlaceId;
	}

	/**
	 * @param sourcePlaceId
	 *            the sourcePlaceId to set
	 */
	public void setSourcePlaceId(Integer sourcePlaceId) {
		this.sourcePlaceId = sourcePlaceId;
	}

	/**
	 * @return the sourcePlaceName
	 */
	public String getSourcePlaceName() {
		return sourcePlaceName;
	}

	/**
	 * @param sourcePlaceName
	 *            the sourcePlaceName to set
	 */
	public void setSourcePlaceName(String sourcePlaceName) {
		this.sourcePlaceName = sourcePlaceName;
	}

	public BigDecimal getTradeUnitNumber() {
		return tradeUnitNumber;
	}

	public void setTradeUnitNumber(BigDecimal tradeUnitNumber) {
		this.tradeUnitNumber = tradeUnitNumber;
	}

	

}
