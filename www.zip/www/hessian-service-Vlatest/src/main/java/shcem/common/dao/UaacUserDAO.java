/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: UaacUserDao.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年8月12日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.dao;

import java.util.List;

import shcem.base.dao.DAO;
import shcem.common.dao.model.UaacUser;

/**
 * @author sunf
 *
 */
public  interface UaacUserDAO extends DAO {
	public List<UaacUser> getAllUaacUser();
}
