/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: PushMsgForAppServiceImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年8月9日 　喻剑平  Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.service.impl;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.service.impl.BaseServiceImpl;
import shcem.common.component.IPushMsgForApp;
import shcem.common.dao.model.MessageHistory;
import shcem.common.service.IPushMsgForAppService;
import shcem.common.util.CommoSys;
import shcem.constant.Constants;
import shcem.constant.ResultCode;
import shcem.util.HessianUtil;
import shcem.util.JsonUtil;

public class PushMsgForAppServiceImpl extends BaseServiceImpl implements IPushMsgForAppService {

	private IPushMsgForApp mgr = (IPushMsgForApp) CommoSys.getBean(Constants.BEAN_PUSH_MSG_FOR_APP_MGR);
	
	/**
	 * app推送消息(广播)
	 * 
	 * {"json":{"ServiceName":"shcem.common.service.IPushMsgForAppService","MethodName":"pushMsgWithBroadcast"}}
	 * 开发环境要加token，, "authkeyid" : "t_dal"}}
	 * @param params
	 * @return
	 */
	@Override
	public String pushMsgWithBroadcast() {
		this.log.info("pushMsgWithBroadcast Service Start");
		try {
			mgr.pushMsgWithBroadcast();
			this.log.info("pushMsgWithBroadcast Service End");
			setResultData(ResultCode.CODE00000.getValue(), null);
		} catch (Exception e) {
			this.log.error("推送消息出错：" + e.getMessage());
			setResultData(ResultCode.CODE10112.getValue(), null, e.getMessage());
		}
		
		return rtnData.toString();
	}
	
	/**
	 * app推送消息
	 * 
	 * {"json":{"ServiceName":"shcem.common.service.IPushMsgForAppService","MethodName":"pushMsg", "Params": "{\"authkeyid\":\"t_dal\"}"}}
	 * 开发环境要加token，, "authkeyid":"t_dal"}}
	 * @param params
	 * @return
	 */
	@Override
	public String pushMsg() {
		this.log.info("pushMsg Service Start");
		try {
			if (Constants.MODE_DEPLOY.equals(HessianUtil.getMode()) ||
					Constants.MODE_UAT.equals(HessianUtil.getMode())) {
				//uat和deploy才做极光推送，dev和test不通外网。
				mgr.pushMsg();
			}
			this.log.info("pushMsg Service End");
			setResultData(ResultCode.CODE00000.getValue(), null);
		} catch (Exception e) {
			this.log.error("推送消息出错：" + e.getMessage());
			setResultData(ResultCode.CODE10112.getValue(), null, e.getMessage());
		}
		
		return rtnData.toString();
	}
	
	/**
	 * 通过手机号，获取用户已发送消息列表
	 * 
	 * {"json":{"ServiceName":"shcem.common.service.IPushMsgForAppService","MethodName":"getMessageHistoryList", "Params": "{\"pageNo\":1,\"pageSize\":10, \"queryModel\":{\"ReceiveNumber\":\"18221729325\", \"IsSend\":1}}"}}
	 * 按某字段排序："Params":"{\"orderFields\":[{\"orderBy\":\"mh.REC_MODIFYTIME\",\"orderDesc\":true}],\"pageNo\":1,  orderFields是需要排序的字段，前台传
	 * @param params json条件
	 * @return
	 */
	@Override
	public String getMessageHistoryList(String params) {
		this.log.info("getMessageHistoryList Service Start");
		List<MessageHistory> mhList = mgr.getMessageHistoryList(params);
		this.log.info("getMessageHistoryList Service End");
		
		try {
			JSONArray retData = JsonUtil.coverModelToJSONArray(mhList);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("result", retData);
			jsonObj.put("total", mhList.size());
			setResultData(ResultCode.CODE00000.getValue(), jsonObj);
		} catch (Exception e) {
			this.log.error("获取消息列表出错：" + e.getMessage());
			setResultData(ResultCode.CODE10101.getValue(), null, e.getMessage());
		}
		
		//把未读消息置成已读
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		mgr.setMessageReadByMobile(queryModel.getString("ReceiveNumber"));
		return rtnData.toString();
	}

	/**
	 * 标识信息为已读
	 * {"json":{"ServiceName":"shcem.common.service.IPushMsgForAppService","MethodName":"setMessageRead", "Params": "{\"messageID\":99}" }}
	 * @param params "messageID"
	 * 
	 * @return
	 */
	@Override
	public String setMessageRead(String params) {
		this.log.info("setMessageRead Service Start");
		JSONObject JOParams = new JSONObject(params);
		try {
			mgr.setMessageRead(JOParams.getInt("messageID"));
			this.log.info("setMessageRead Service End");
			setResultData(ResultCode.CODE00000.getValue(), null);
		} catch (Exception e) {
			this.log.error("更新消息出错：" + e.getMessage());
			setResultData(ResultCode.CODE10112.getValue(), null, e.getMessage());
		}
		
		return rtnData.toString();
	}
	
	/**
	 * 查询未读消息数量
	 * 
	 * {"json":{"ServiceName":"shcem.common.service.IPushMsgForAppService","MethodName":"getUnReadMsgNum", "Params": "{\"ReceiveNumber\":\"18221729325\"}" }}
	 * 
	 * {"DATA":"{\"result\":15}","INFO":"Service执行成功。","CODE":"00000"}
	 * */
	@Override
	public String getUnReadMsgNum(String params) {
		this.log.info("getUnReadMsgNum Service Start");
		JSONObject JOParams = new JSONObject(params);
		try {
			int num = mgr.getUnReadMsgNum(JOParams.getString("ReceiveNumber"));
			this.log.info("getUnReadMsgNum Service End");
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("result", num);
			setResultData(ResultCode.CODE00000.getValue(), jsonObj);
		} catch (Exception e) {
			this.log.error("查询未读消息数量出错：" + e.getMessage());
			setResultData(ResultCode.CODE10112.getValue(), null, e.getMessage());
		}
		
		return rtnData.toString();
	}
}
