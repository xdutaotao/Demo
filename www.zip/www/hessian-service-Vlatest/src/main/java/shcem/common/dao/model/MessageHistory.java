/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：前台消息模块
 * File Name: MsgPushesModel.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年8月9日 　喻剑平  Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.dao.model;

import java.io.Serializable;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * @author jampion
 *
 */
public class MessageHistory extends BaseObject implements Serializable{
	private static final long serialVersionUID = -1278966116234002354L;
	
	/**
	 * 消息ID
	 */
	private int messageID;
	
	/**
	 * 短信类型
	 */
	private String msgCode;
	
	/**
	 * 短信内容
	 */
	private String messageContent;
	
	/**
	 * 接收号码
	 */
	private String receiveNumber;
	
	/**
	 * 发送状态
	 */
	private int msgStatus;
	
	/**
	 * 服务商
	 */
	private int serviceProvider;
	
	/**
	 * 返回结果
	 */
	private String resultMsg; 
	
	/**
	 * 是否发送（null：未发送。  1：已发送）
	 */
	private int isSend;
	
	/**
	 * 返回状态 0 未读 1 已读
	 * */
	private int ResultStatus;
	
	/**创建人*/
	private String recCreateby;
	
	/**创建时间*/
	private Date recCreatetime;
	
	/**最后修改人*/
	private String recModifyby;
	
	/**最后修改时间*/
	private Date recModifytime;

	public int getMessageID() {
		return messageID;
	}
	public void setMessageID(int messageID) {
		this.messageID = messageID;
	}
	public String getMsgCode() {
		return msgCode;
	}
	public void setMsgCode(String msgCode) {
		this.msgCode = msgCode;
	}
	public String getMessageContent() {
		return messageContent;
	}
	public void setMessageContent(String messageContent) {
		this.messageContent = messageContent;
	}
	public String getReceiveNumber() {
		return receiveNumber;
	}
	public void setReceiveNumber(String receiveNumber) {
		this.receiveNumber = receiveNumber;
	}
	public int getMsgStatus() {
		return msgStatus;
	}
	public void setMsgStatus(int msgStatus) {
		this.msgStatus = msgStatus;
	}
	public int getServiceProvider() {
		return serviceProvider;
	}
	public void setServiceProvider(int serviceProvider) {
		this.serviceProvider = serviceProvider;
	}
	public String getResultMsg() {
		return resultMsg;
	}
	public void setResultMsg(String resultMsg) {
		this.resultMsg = resultMsg;
	}
	public int getIsSend() {
		return isSend;
	}
	public void setIsSend(int isSend) {
		this.isSend = isSend;
	}
	public int getResultStatus() {
		return ResultStatus;
	}
	public void setResultStatus(int resultStatus) {
		ResultStatus = resultStatus;
	}
	public String getRecCreateby() {
		return recCreateby;
	}
	public void setRecCreateby(String recCreateby) {
		this.recCreateby = recCreateby;
	}
	public Date getRecCreatetime() {
		return recCreatetime;
	}
	public void setRecCreatetime(Date recCreatetime) {
		this.recCreatetime = recCreatetime;
	}
	public String getRecModifyby() {
		return recModifyby;
	}
	public void setRecModifyby(String recModifyby) {
		this.recModifyby = recModifyby;
	}

	
	public Date getRecModifytime() {
		return recModifytime;
	}
	public void setRecModifytime(Date recModifytime) {
		this.recModifytime = recModifytime;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}
