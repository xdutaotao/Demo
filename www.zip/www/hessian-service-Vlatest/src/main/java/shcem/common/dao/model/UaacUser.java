package shcem.common.dao.model;

import java.io.Serializable;

import shcem.base.dao.model.BaseObject;

/**
 * UAAC 用户
 * @author sunf
 *
 */
public class UaacUser  extends BaseObject implements Serializable{
	private String loginName;
	private String email;
	
	
	
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}
