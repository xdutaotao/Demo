package shcem.common.component.impl;

import java.util.Collection;
import java.util.Map;

import cn.jpush.api.JPushClient;
import cn.jpush.api.common.resp.APIConnectionException;
import cn.jpush.api.common.resp.APIRequestException;
import cn.jpush.api.push.PushResult;
import cn.jpush.api.push.model.Options;
import cn.jpush.api.push.model.Platform;
import cn.jpush.api.push.model.PushPayload;
import cn.jpush.api.push.model.PushPayload.Builder;
import cn.jpush.api.push.model.audience.Audience;
import cn.jpush.api.push.model.notification.AndroidNotification;
import cn.jpush.api.push.model.notification.IosNotification;
import cn.jpush.api.push.model.notification.Notification;
import cn.jpush.api.push.model.notification.WinphoneNotification;
import shcem.common.component.IJPushMgr;
import shcem.common.dao.model.JPushModel;
import shcem.constant.Constants;
import shcem.log.service.ILogService;
import shcem.log.service.impl.LogServiceImpl;
import shcem.util.CollectionUtil;
import shcem.util.Common;
import shcem.util.HessianUtil;

public class JPushMgrImpl implements IJPushMgr {

	protected final ILogService log = new LogServiceImpl("Componentlog");
	
	/**
	 * 推送消息
	 * 
	 * @param message 推送的消息
	 * @param extras 扩展参数
	 * @param alias 用户别名
	 * */
	@Override
	public String sendPush(JPushModel jpush) {
		this.log.debug("sendPush Start");
		JPushClient jpushClient = new JPushClient(Constants.JPUSH_MASTER_SECRET, Constants.JPUSH_APP_KEY);
		
	    // 创建PushPayload对象.
	    PushPayload payload = buildPushObject(jpush);
	
	    try {
	    	// 推送
	        PushResult result = jpushClient.sendPush(payload);
	        log.info("Got result - " + result);
	
	    } catch (APIConnectionException e) {
	    	/*Error Message: Read timed out. 
	    	Read response from JPush Server timed out. 
	    	If this is a Push action, you may not want to retry. 
	    	It may be due to slowly response from JPush server, or unstable connection. 
	    	If the problem persists, please let us know at support@jpush.cn.*/
	    	//if (e.getMessage())
	        // Connection error, should retry later
	    	log.error("Connection error, should retry later");
	    	log.error("Error Message: " + e.getMessage());
	    } catch (APIRequestException e) {
	        // Should review the error, and fix the request
	    	log.error("Should review the error, and fix the request");
	    	log.info("HTTP Status: " + e.getStatus());
	    	log.info("Error Code: " + e.getErrorCode());
	    	log.info("Error Message: " + e.getErrorMessage());
	    }
		this.log.debug("sendPush End");
		return null;
	}
	
	/**
	 * 推送消息(全体广播)
	 * 
	 * @param message 推送的消息
	 * */
	@Override
	public String sendPush(String message) {
		this.log.debug("sendPush Start");
		JPushClient jpushClient = new JPushClient(Constants.JPUSH_MASTER_SECRET, Constants.JPUSH_APP_KEY);
		
		JPushModel jpush = new JPushModel();
		jpush.setMessage(message);
	    // 创建PushPayload对象.
	    PushPayload payload = buildPushObject(jpush);
	
	    try {
	    	// 推送
	        PushResult result = jpushClient.sendPush(payload);
	        log.info("Got result - " + result);
	
	    } catch (APIConnectionException e) {
	        // Connection error, should retry later
	    	log.error("Connection error, should retry later");
	       	log.error("Error Message: " + e.getMessage());
	    } catch (APIRequestException e) {
	        // Should review the error, and fix the request
	    	log.error("Should review the error, and fix the request");
	    	log.info("HTTP Status: " + e.getStatus());
	    	log.info("Error Code: " + e.getErrorCode());
	    	log.info("Error Message: " + e.getErrorMessage());
	    }
		this.log.debug("sendPush End");
		return null;
	}
	
	/**
	 * 推送消息
	 * 
	 * @param message 推送的消息
	 * @param alias 用户别名
	 * */
	@Override
	public String sendPush(String message, Collection<String> aliases) {
		this.log.debug("sendPush Start");
		JPushClient jpushClient = new JPushClient(Constants.JPUSH_MASTER_SECRET, Constants.JPUSH_APP_KEY);
		
		JPushModel jpush = new JPushModel();
		jpush.setMessage(message);
		jpush.setAliases(aliases);
	    // 创建PushPayload对象.
	    PushPayload payload = buildPushObject(jpush);
	
	    try {
	    	// 推送
	        PushResult result = jpushClient.sendPush(payload);
	        log.info("Got result - " + result);
	
	    } catch (APIConnectionException e) {
	        // Connection error, should retry later
	    	log.error("Connection error, should retry later");
	       	log.error("Error Message: " + e.getMessage());
	    } catch (APIRequestException e) {
	        // Should review the error, and fix the request
	    	log.error("Should review the error, and fix the request");
	    	log.info("HTTP Status: " + e.getStatus());
	    	log.info("Error Code: " + e.getErrorCode());
	    	log.info("Error Message: " + e.getErrorMessage());
	    }
		this.log.debug("sendPush End");
		return null;
	}
	
	@Override
	public String sendPush(String message, Map<String, String> extras,
			Collection<String> aliases) throws APIConnectionException {
		this.log.debug("sendPush Start");
		JPushClient jpushClient = new JPushClient(Constants.JPUSH_MASTER_SECRET, Constants.JPUSH_APP_KEY);
		
		JPushModel jpush = new JPushModel();
		jpush.setMessage(message); //通知消息
		jpush.setExtras(extras);  //扩展参数
		jpush.setAliases(aliases); //别名（手机号）
	    // 创建PushPayload对象.
	    PushPayload payload = buildPushObject(jpush);
	
	    try {
	    	// 推送
	        PushResult result = jpushClient.sendPush(payload);
	        log.info("Got result - " + result);
	
	    } catch (APIConnectionException e) {
	        // Connection error, should retry later
	    	log.error("Connection error, should retry later");
	    	log.error("Error Message: " + e.getMessage());
	    	throw e;
	    } catch (APIRequestException e) {
	        // Should review the error, and fix the request
	    	log.error("Should review the error, and fix the request");
	    	log.info("HTTP Status: " + e.getStatus());
	    	log.info("Error Code: " + e.getErrorCode());
	    	log.info("Error Message: " + e.getErrorMessage());
	    }
		this.log.debug("sendPush End");
		return null;
	}
	 
	/**
	 * 构建推送对象
	 * 
	 * @param jpush 推送消息model
	 * 
	 * @return 推送的对象
	 * */
	 public PushPayload buildPushObject(JPushModel jpush) {
		 Builder pushPayload = PushPayload.newBuilder();
		 
		 pushPayload
			.setPlatform(Platform.all())  //平台
			.setAudience(Audience.all())  //推送对象
			.setNotification(
					Notification
							.newBuilder().setAlert(jpush.getMessage())  //消息
							.addPlatformNotification(
									IosNotification.newBuilder().addExtras(jpush.getExtras())
											.incrBadge(1).build())    //ios角标+1， Android和winphone不支持角标， 键值对
							.addPlatformNotification(
									AndroidNotification.newBuilder().addExtras(jpush.getExtras()).build())   // 键值对
							.addPlatformNotification(  
									WinphoneNotification.newBuilder().addExtras(jpush.getExtras()).build())    // 键值对
											.build()); 
		 
		 //别名
		 if (CollectionUtil.isValidCollect(jpush.getAliases())) {
			 pushPayload.setAudience(Audience.alias(jpush.getAliases())); 
		 }
		 if (Constants.MODE_DEPLOY.equals(HessianUtil.getMode())) {
			 pushPayload.setOptions(Options.newBuilder().setApnsProduction(true).build());  //生产模式
		 } else {
			 pushPayload.setOptions(Options.newBuilder().setApnsProduction(false).build());  //开发模式
		 }
         return pushPayload.build();
    }
}
