/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: CommonDAO.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月30日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.dao;

import java.math.BigDecimal;
import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.dao.model.CDictionary;
import shcem.common.dao.model.CateBrandPlaceView;
import shcem.common.dao.model.ChargesModel;
import shcem.common.dao.model.CrmBrand;
import shcem.common.dao.model.CrmCategorySpecial;
import shcem.common.service.model.ValueTxtView;
import shcem.member.dao.model.Firm;
import shcem.trade.dao.model.Delivery;

/**
 * @author wlpod
 *
 */
public abstract interface CommonDAO extends DAO {
	public abstract List<ValueTxtView> getCantonListByLv(int lv);

	public abstract List<ValueTxtView> getCantonListByPid(int parentId);

	public abstract List<ValueTxtView> getCompanyTypeList();

	public abstract List<ValueTxtView> getBankList(String bankName);

	public abstract List<ValueTxtView> getUserList();

	public abstract List<ValueTxtView> getFirmList(QueryConditions qc, int firmSource);

	public abstract List<ValueTxtView> getSummaryModelList();

	public abstract ChargesModel getChargesByFirmID(String firmID, String tmplID, Integer cateID, Integer brandID,
			int tradeRole, BigDecimal price, BigDecimal quantity, BigDecimal tradeUnitNumber);

	public abstract List<ValueTxtView> getInfoTagList(Integer tagTypeDiff);

	public abstract ChargesModel getSettleChargesByFirmID(String firmID, String tmplID, Integer cateID, Integer brandID,
			int tradeRole, BigDecimal price, BigDecimal quantity, BigDecimal tradeUnitNumber);

	public abstract  boolean ChkAuthByFirmID(String firmID, String tmplID, Integer cateID, Integer brandID, int tradeRole, Integer sourcePlaceID);
	
	public abstract  boolean ChkAuthByTraderID(String traderID, String tmplID, Integer cateID, Integer brandID, int tradeRole, Integer sourcePlaceID);
	
	public abstract List<ValueTxtView> getTradeTmplList();

	public abstract List<ValueTxtView> getTradeTmplListByFirm(String firmID);

	public abstract List<ValueTxtView> getUnBindUserList();

	public abstract List<ValueTxtView> getSummaryList();
	
	public abstract List<ValueTxtView> getAssignBankList();

	public abstract List<ValueTxtView> getCategoryList(String categoryName);

	public abstract List<ValueTxtView> getCategoryBrandList(int categoryID);

	public abstract List<ValueTxtView> getFirmWithTradeTemplate(
			QueryConditions qc);

	public abstract List<ValueTxtView> getZoneNumbeList(String zoneNum);
	
	/**
	 * 根据【交易场交易权限表(基础设定)】的交易场ID 获取分类列表
	 * @param tradeTmptId
	 * @param like categoryName
	 * @return
	 */
	public abstract List<CrmCategorySpecial> getCategorySpecialListByTradeTmptId(Integer tradeTmptId,String categoryName);
	
	/**
	 * 获取分类列表
	 * @param type 分类类型 0:分枝 1:叶子
	 * @return
	 */
	public abstract List<CrmCategorySpecial> getCategoryListByType(Integer type);
	
	/**
	 * 获取分类下的商品牌号
	 * @param categoryLeafID
	 * @param tradeTmptId
	 * @param like barandName
	 * @return
	 */
	public abstract List<CrmBrand> getCrmBrandListByCategoryLeafIDOfTradeTmptId(Integer categoryLeafID,Integer tradeTmptId,String barandName);

	public abstract int addAddress(Delivery delivery);

	/**
	 * 省市县+地址
	 * @param addRessID
	 * @return
	 */
	public abstract String getAddRessString(int addRessID);

	public abstract Firm getFirmByTraderID(
			String traderID);
	/**
	 * 
	 * @param categoryId
	 * @param brandId
	 * @return
	 */
	public int countFirmPrivilegeCategoryIDAndBrandId(String tradeTmptId,String firmId,Integer categoryId,Integer brandId);

	/**
	 * 仓库地址信息
	 * @param wHGruopID
	 * @param tradeTmptId 
	 * @return
	 */
	public abstract List<ValueTxtView> getWHGruopAddress(Integer wHGruopID, Integer tradeTmptId);

	public abstract List<ValueTxtView> getWHAddrTemplateRlspList(
			Integer tradeTmptId);
	/**
	 * 获取期货合约列表
	 * @return
	 */
	public abstract List<ValueTxtView> getFutureContractList();
	
	/**
	 * 获取交易场所属分配牌号权限
	 * @param tempId
	 * @return
	 */
	public List<CateBrandPlaceView> getCateBrandSourcePlaceByTradeTmptId(QueryConditions qc,PageInfo pageInfo) ;
	
	/**
	 * 获取系统枚举定义表
	 * @param tempId
	 * @return
	 */
	public List<CDictionary> getDictionaryList(QueryConditions qc,PageInfo pageInfo) ;
	
	/**
	 * 获取线性专场交易保证金
	 * @param firmID
	 * @param tmplID
	 * @param cateID
	 * @param brandID
	 * @param tradeRole
	 * @param price
	 * @param quantity
	 * @param tradeUnitNumber
	 * @param linerTypeDicId
	 * @param deliveryDateDicId
	 * @return
	 */
	public ChargesModel getChargesForLLDPEByFirmID(final String firmID, final String tmplID, final Integer cateID,
			final Integer brandID, final int tradeRole, final BigDecimal price, final BigDecimal quantity,
			final BigDecimal tradeUnitNumber, final int linerTypeDicId, final int deliveryDateDicId) ;

	public abstract List<CateBrandPlaceView> getCateBrandByTradeTmptId(QueryConditions qc, PageInfo pageInfo);

}
