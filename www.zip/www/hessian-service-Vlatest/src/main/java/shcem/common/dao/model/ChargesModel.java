/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: ChargesModel.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月6日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.dao.model;

import java.math.BigDecimal;

/**
 * @author wlpod
 *
 */
public class ChargesModel {
	/**
	 * 交易手续费
	 */
	private BigDecimal fee;
	/**
	 * 交易手续费算法
	 * 1：绝对值,2:百分比
	 */
	private BigDecimal feeAlgr;
	/**
	 * 交易手续费率
	 */
	private BigDecimal feeRate;
	/**
	 * 交收手续费
	 */
	private BigDecimal settleFee;
	/**
	 * 交收手续费算法
	 * 1：绝对值,2:百分比
	 */
	private BigDecimal settleFeeAlgr;
	/**
	 * 交收手续费率
	 */
	private BigDecimal settleFeeRate;
	/**
	 * 保证金
	 */
	private BigDecimal margin;
	/**
	 * 保证金算法
	 * 1：绝对值,2:百分比
	 */
	private BigDecimal marginAlgr;
	/**
	 * 保证金费率
	 */
	private BigDecimal marginRate;
	/**
	 * 交收保证金
	 */
	private BigDecimal settleMargin;
	/**
	 * 交收保证金算法
	 * 1：绝对值,2:百分比
	 */
	private BigDecimal settleMarginAlgr;	
	/**
	 * 交收保证金费率
	 */
	private BigDecimal settleMarginRate;
	/**
	 * 支付货款
	 */
	private BigDecimal payout;	
	/**
	 * 支付货款算法
	 * 1：绝对值,2:百分比
	 */
	private BigDecimal payoutAlgr;
	/**
	 * 支付货款费率
	 */
	private BigDecimal payoutRate;
	/**
	 * 追加保证金
	 */
	private BigDecimal addMargin;
	/**
	 * 追加保证金算法
	 * 1：绝对值,2:百分比
	 */
	private BigDecimal addMarginAlgr;
	/**
	 * 追加保证金费率
	 */
	private BigDecimal addMarginRate;
	/**
	 * @return the feeAlgr
	 */
	public BigDecimal getFeeAlgr() {
		return feeAlgr;
	}

	/**
	 * @param feeAlgr the feeAlgr to set
	 */
	public void setFeeAlgr(BigDecimal feeAlgr) {
		this.feeAlgr = feeAlgr;
	}

	/**
	 * @return the feeRate
	 */
	public BigDecimal getFeeRate() {
		return feeRate;
	}

	/**
	 * @param feeRate the feeRate to set
	 */
	public void setFeeRate(BigDecimal feeRate) {
		this.feeRate = feeRate;
	}

	/**
	 * @return the settleFeeAlgr
	 */
	public BigDecimal getSettleFeeAlgr() {
		return settleFeeAlgr;
	}

	/**
	 * @param settleFeeAlgr the settleFeeAlgr to set
	 */
	public void setSettleFeeAlgr(BigDecimal settleFeeAlgr) {
		this.settleFeeAlgr = settleFeeAlgr;
	}

	/**
	 * @return the settleFeeRate
	 */
	public BigDecimal getSettleFeeRate() {
		return settleFeeRate;
	}

	/**
	 * @param settleFeeRate the settleFeeRate to set
	 */
	public void setSettleFeeRate(BigDecimal settleFeeRate) {
		this.settleFeeRate = settleFeeRate;
	}

	/**
	 * @return the marginAlgr
	 */
	public BigDecimal getMarginAlgr() {
		return marginAlgr;
	}

	/**
	 * @param marginAlgr the marginAlgr to set
	 */
	public void setMarginAlgr(BigDecimal marginAlgr) {
		this.marginAlgr = marginAlgr;
	}

	/**
	 * @return the marginRate
	 */
	public BigDecimal getMarginRate() {
		return marginRate;
	}

	/**
	 * @param marginRate the marginRate to set
	 */
	public void setMarginRate(BigDecimal marginRate) {
		this.marginRate = marginRate;
	}

	/**
	 * @return the settleMarginAlgr
	 */
	public BigDecimal getSettleMarginAlgr() {
		return settleMarginAlgr;
	}

	/**
	 * @param settleMarginAlgr the settleMarginAlgr to set
	 */
	public void setSettleMarginAlgr(BigDecimal settleMarginAlgr) {
		this.settleMarginAlgr = settleMarginAlgr;
	}

	/**
	 * @return the settleMarginRate
	 */
	public BigDecimal getSettleMarginRate() {
		return settleMarginRate;
	}

	/**
	 * @param settleMarginRate the settleMarginRate to set
	 */
	public void setSettleMarginRate(BigDecimal settleMarginRate) {
		this.settleMarginRate = settleMarginRate;
	}

	/**
	 * @return the payoutAlgr
	 */
	public BigDecimal getPayoutAlgr() {
		return payoutAlgr;
	}

	/**
	 * @param payoutAlgr the payoutAlgr to set
	 */
	public void setPayoutAlgr(BigDecimal payoutAlgr) {
		this.payoutAlgr = payoutAlgr;
	}

	/**
	 * @return the payoutRate
	 */
	public BigDecimal getPayoutRate() {
		return payoutRate;
	}

	/**
	 * @param payoutRate the payoutRate to set
	 */
	public void setPayoutRate(BigDecimal payoutRate) {
		this.payoutRate = payoutRate;
	}

	/**
	 * @return the fee
	 */
	public BigDecimal getFee() {
		return fee;
	}

	/**
	 * @param fee
	 *            the fee to set
	 */
	public void setFee(BigDecimal fee) {
		this.fee = fee;
	}

	/**
	 * @return the settleFee
	 */
	public BigDecimal getSettleFee() {
		return settleFee;
	}

	/**
	 * @param settleFee
	 *            the settleFee to set
	 */
	public void setSettleFee(BigDecimal settleFee) {
		this.settleFee = settleFee;
	}

	/**
	 * @return the margin
	 */
	public BigDecimal getMargin() {
		return margin;
	}

	/**
	 * @param margin
	 *            the margin to set
	 */
	public void setMargin(BigDecimal margin) {
		this.margin = margin;
	}

	/**
	 * @return the settleMargin
	 */
	public BigDecimal getSettleMargin() {
		return settleMargin;
	}

	/**
	 * @param settleMargin
	 *            the settleMargin to set
	 */
	public void setSettleMargin(BigDecimal settleMargin) {
		this.settleMargin = settleMargin;
	}

	/**
	 * @return the payout
	 */
	public BigDecimal getPayout() {
		return payout;
	}

	/**
	 * @param payout
	 *            the payout to set
	 */
	public void setPayout(BigDecimal payout) {
		this.payout = payout;
	}

	/**
	 * @return the addMargin
	 */
	public BigDecimal getAddMargin() {
		return addMargin;
	}

	/**
	 * @param addMargin the addMargin to set
	 */
	public void setAddMargin(BigDecimal addMargin) {
		this.addMargin = addMargin;
	}

	/**
	 * @return the addMarginAlgr
	 */
	public BigDecimal getAddMarginAlgr() {
		return addMarginAlgr;
	}

	/**
	 * @param addMarginAlgr the addMarginAlgr to set
	 */
	public void setAddMarginAlgr(BigDecimal addMarginAlgr) {
		this.addMarginAlgr = addMarginAlgr;
	}

	/**
	 * @return the addMarginRate
	 */
	public BigDecimal getAddMarginRate() {
		return addMarginRate;
	}

	/**
	 * @param addMarginRate the addMarginRate to set
	 */
	public void setAddMarginRate(BigDecimal addMarginRate) {
		this.addMarginRate = addMarginRate;
	}
}
