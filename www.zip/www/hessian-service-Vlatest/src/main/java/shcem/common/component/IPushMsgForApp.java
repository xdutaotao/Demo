/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IPushMsgForAppService.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年8月9日 　喻剑平   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.component;

import java.util.List;

import shcem.common.dao.model.MessageHistory;

/**
 * @author jampion
 *
 */
public interface IPushMsgForApp {

	/**
	 * app推送消息(广播)
	 * 
	 * 事务在component层，pushMsg不需要事务管理
	 * @param params
	 * @return
	 */
	public String pushMsgWithBroadcast();
	
	/**
	 * app推送消息
	 * 
	 * @param params
	 * @return
	 */
	public String pushMsg();

	/**
	 * 通过手机号，获取用户已发送消息列表
	 * 
	 * @param params
	 * @return
	 */
	public List<MessageHistory> getMessageHistoryList(String params);

	/**
	 * 标识信息为已读
	 * 
	 * @param params "messageID"
	 * @return
	 */
	public void setMessageRead(int messageId);

	
	/**
	 * 查询未读消息数量
	 * */
	public int getUnReadMsgNum(String mobile);


	/**
	 * 标识信息为已读(通过手机号)
	 * 
	 * @param params "mobile"
	 * @return
	 */
	public void setMessageReadByMobile(String mobile);
}
