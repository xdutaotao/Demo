/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：前台消息模块
 * File Name: ICMessageDAO.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年8月9日 　喻剑平   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.dao;

import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.dao.model.MessageHistory;
import shcem.common.dao.model.MessageSendRelation;

/**
 * @author jampion
 *
 */
public interface ICMessageDAO extends DAO {
	
	/**
	 * 获取需要推送的对象
	 * */
	public List<MessageHistory> getPushes();

	/**
	 * 记录微信APP消息发送情况表
	 * */
	public int insertMessageSendRelation(MessageSendRelation sendRelation);
	
	/**
	 * 记录微信APP消息发送情况表（批量）
	 * */
	public void insertBatchMessageSendRelation(List<MessageSendRelation> sendRelations);
	
	/**
	 * 查询消息列表
	 * */
	public List<MessageHistory> getMessageHistoryList(QueryConditions qc, PageInfo pageInfo);
	
	/**
	 * 更新已经发送过消息的记录（app用）（isSend=1）
	 * */
	public void updatePushesMsgHistory();
	
	/**
	 * 标识消息为已读（MessageSendRelation。ResultStatus = 1）
	 * */
	public void updateMessageRead(int messageId);
	
	/**
	 * 查询未读消息数量
	 * */
	public int getUnReadMsgNum(String mobile);

	/**
	 * 标识信息为已读(通过手机号)
	 * 
	 * @param params "mobile"
	 * @return
	 */
	public void updateMessageReadByMobile(String mobile);

	/**
	 *  更新已经发送过消息的记录（app用）（isSend=1）
	 * */
	public void updatePushesMsgHistory(int messageId);
}
