/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: CommonDAOImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月30日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.dao.impl;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCallback;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.dao.CommonDAO;
import shcem.common.dao.model.CDictionary;
import shcem.common.dao.model.CateBrandPlaceView;
import shcem.common.dao.model.ChargesModel;
import shcem.common.dao.model.CrmBrand;
import shcem.common.dao.model.CrmCategorySpecial;
import shcem.common.service.model.ValueTxtView;
import shcem.member.dao.model.Firm;
import shcem.member.dao.model.FirmAllData;
import shcem.trade.dao.model.Delivery;
import shcem.util.CommonRowMapper;

/**
 * @author wlpod
 *
 */
public class CommonDAOImpl extends BaseDAOImpl implements CommonDAO {

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.common.dao.CommonDAO#getCantonListByLv(int)
	 */
	@Override
	public List<ValueTxtView> getCantonListByLv(int lv) {
		this.log.debug("getCantonListByLv DAO Start");
		String sql = sqlProperty.getProperty("CommonDAO_001");
		Object[] params = new Object[] { lv };
		return queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView()));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.common.dao.CommonDAO#getCantonListByPid(int)
	 */
	@Override
	public List<ValueTxtView> getCantonListByPid(int parentId) {
		this.log.debug("getCantonListByPid DAO Start");
		String sql = sqlProperty.getProperty("CommonDAO_002");
		Object[] params = new Object[] { parentId };
		return queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView()));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.common.dao.CommonDAO#getCompanyTypeList()
	 */
	@Override
	public List<ValueTxtView> getCompanyTypeList() {
		this.log.debug("getCompanyTypeList DAO Start");
		String sql = sqlProperty.getProperty("CommonDAO_003");
		Object[] params = new Object[] {};
		return queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView()));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.common.dao.CommonDAO#getBankList()
	 */
	@Override
	public List<ValueTxtView> getBankList(String bankName) {
		this.log.debug("getBankList DAO Start");
		String sql = sqlProperty.getProperty("CommonDAO_004")+" where t.BankName like '%"+bankName+"%'";
		Object[] params = new Object[] {};
		return queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView()));
	}

	@Override
	public List<ValueTxtView> getUserList() {
		this.log.debug("getUserList DAO Start");
		String sql = sqlProperty.getProperty("CommonDAO_005");
		Object[] params = new Object[] {};
		List<ValueTxtView> list = queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView()));
		return list;
	}

	@Override
	public List<ValueTxtView> getFirmList(QueryConditions qc,int firmSource) {
		this.log.debug("getTraderList DAO Start");
		String sql = sqlProperty.getProperty("CommonDAO_006")+" AND cfa.AppType = "+firmSource;
		Object[] params = new Object[] {};
		List<ValueTxtView> list = queryBySQL(sql, qc, null, new CommonRowMapper(new ValueTxtView()));
		return list;
	}

	@Override
	public ChargesModel getChargesByFirmID(final String firmID, final String tmplID, final Integer cateID,
			final Integer brandID, final int tradeRole, final BigDecimal price, final BigDecimal quantity,
			final BigDecimal tradeUnitNumber) {
		String procedure = sqlProperty.getProperty("CommonDAO_009");
		ChargesModel retM = new ChargesModel();
		try {
			retM = (ChargesModel) this.getJdbcTemplate().execute(procedure, new CallableStatementCallback() {
				public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {
					ChargesModel chargesModel = new ChargesModel();
					cs.setString(2, firmID); // 输出参数类型
					cs.setString(1, tmplID);
					cs.setLong(3, cateID);
					cs.setLong(4, brandID);
					cs.setInt(5, tradeRole);
					cs.setBigDecimal(6, price);
					cs.setBigDecimal(7, quantity);
					cs.setBigDecimal(8, tradeUnitNumber);
					ResultSet rs = cs.executeQuery();
					while (rs.next()) {
						/**
						 * 如不存在相应设定，则对应费用为Null
						 */
						chargesModel.setMargin(rs.getBigDecimal("MarginAmount"));
						chargesModel.setMarginAlgr(rs.getBigDecimal("v_Margin_A"));
						chargesModel.setMarginRate(rs.getBigDecimal("v_Margin"));
						chargesModel.setFee(rs.getBigDecimal("FeeAmount"));
						chargesModel.setFeeAlgr(rs.getBigDecimal("v_Fee_A"));
						chargesModel.setFeeRate(rs.getBigDecimal("v_Fee"));
					}
					return chargesModel;
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
		return retM;
	}

	@Override
	public List<ValueTxtView> getSummaryModelList() {
		this.log.debug("getSummaryModelList DAO Start");
		String sql = sqlProperty.getProperty("CommonDAO_007");
		Object[] params = new Object[] {};
		List<ValueTxtView> list = queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView()));
		return list;
	}
	
	@Override
	public List<ValueTxtView> getSummaryList() {
		this.log.debug("getSummaryModelList DAO Start");
		String sql = sqlProperty.getProperty("CommonDAO_016");
		Object[] params = new Object[] {};
		List<ValueTxtView> list = queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView()));
		return list;
	}

	@Override
	public List<ValueTxtView> getInfoTagList(Integer tagTypeDiff) {
		this.log.debug("getInfoTagList DAO Start");
		String sql = sqlProperty.getProperty("CommonDAO_008");
		Object[] params = new Object[] {tagTypeDiff};
		List<ValueTxtView> list = queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView()));
		return list;
	}
	

	@Override
	public ChargesModel getSettleChargesByFirmID(final String firmID, final String tmplID, final Integer cateID,
			final Integer brandID, final int tradeRole, final BigDecimal price, final BigDecimal quantity,
			final BigDecimal tradeUnitNumber) {
		String procedure = sqlProperty.getProperty("CommonDAO_010");
		ChargesModel retM = new ChargesModel();
		try {
			retM = (ChargesModel) this.getJdbcTemplate().execute(procedure, new CallableStatementCallback() {
				public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {
					ChargesModel chargesModel = new ChargesModel();
					cs.setString(2, firmID); // 输出参数类型
					cs.setString(1, tmplID);
					cs.setLong(3, cateID);
					cs.setLong(4, brandID);
					cs.setInt(5, tradeRole);
					cs.setBigDecimal(6, price);
					cs.setBigDecimal(7, quantity);
					cs.setBigDecimal(8, tradeUnitNumber);
					ResultSet rs = cs.executeQuery();
					while (rs.next()) {
						/**
						 * 如不存在相应设定，则对应费用为Null
						 */
						chargesModel.setSettleMargin(rs.getBigDecimal("MarginAmount"));
						chargesModel.setSettleMarginAlgr(rs.getBigDecimal("v_Margin_A"));
						chargesModel.setSettleMarginRate(rs.getBigDecimal("v_Margin"));
						chargesModel.setSettleFee(rs.getBigDecimal("FeeAmount"));
						chargesModel.setSettleFeeAlgr(rs.getBigDecimal("v_Fee_A"));
						chargesModel.setSettleFeeRate(rs.getBigDecimal("v_Fee"));
						chargesModel.setPayout(rs.getBigDecimal("PayAmount"));
						chargesModel.setPayoutAlgr(rs.getBigDecimal("v_Pay_A"));
						chargesModel.setPayoutRate(rs.getBigDecimal("v_Pay"));
					}
					return chargesModel;
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
		return retM;
	}

	@Override
	public boolean ChkAuthByFirmID(final String firmID, final String tmplID, final Integer cateID,
			final Integer brandID, final int tradeRole,final Integer sourcePlaceID) {
		String procedure = sqlProperty.getProperty("CommonDAO_011");
		String retCode = "-1";
		try {
			retCode = (String) this.getJdbcTemplate().execute(procedure, new CallableStatementCallback() {
				public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {
					ChargesModel chargesModel = new ChargesModel();
					cs.registerOutParameter(1, Types.INTEGER); // 输出参数类型
					cs.setString(2, tmplID);
					cs.setString(3, firmID);
					cs.setLong(4, cateID);
					cs.setLong(5, brandID);
					cs.setLong(6, sourcePlaceID);
					cs.setInt(7, tradeRole);
					cs.execute();
					return cs.getString(1);
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
		if ("0".equals(retCode))
			return true;
		return false;
	}

	public boolean ChkAuthByTraderID(final String traderID, final String tmplID, final Integer cateID,
			final Integer brandID, final int tradeRole,final Integer sourcePlaceID) {
		String procedure = sqlProperty.getProperty("CommonDAO_012");
		String retCode = "-1";
		try {
			retCode = (String)  this.getJdbcTemplate().execute(procedure, new CallableStatementCallback() {
				public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {
					ChargesModel chargesModel = new ChargesModel();
					cs.registerOutParameter(1, Types.INTEGER); // 输出参数类型
					cs.setString(2, tmplID);
					cs.setString(3, traderID);
					cs.setLong(4, cateID);
					cs.setLong(5, brandID);
					cs.setLong(6, sourcePlaceID);
					cs.setInt(7, tradeRole);
					cs.execute();
					return cs.getString(1);
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
		if ("0".equals(retCode))
			return true;
		return false;
	}

	@Override
	public List<ValueTxtView> getTradeTmplList() {
		this.log.debug("getTradeTmplList DAO Start");
		String sql = sqlProperty.getProperty("CommonDAO_013");
		Object[] params = new Object[] { };
		return queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView()));
	}
	@Override
	public List<ValueTxtView> getTradeTmplListByFirm(String firmID) {
		String sql = sqlProperty.getProperty("CommonDAO_014");
		Object[] params = new Object[] { firmID };
		return queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView()));
	}
	
	@Override
	public List<ValueTxtView> getUnBindUserList() {
		String sql = sqlProperty.getProperty("CommonDAO_015");
		Object[] params = new Object[] {};
		List<ValueTxtView> list = queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView()));
		return list;
	}
	
	public List<ValueTxtView> getAssignBankList() {
		String sql = sqlProperty.getProperty("CommonDAO_017");
		Object[] params = new Object[] {};
		List<ValueTxtView> list = queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView()));
		return list;
	}
	
	@Override
	public List<ValueTxtView> getCategoryList(String categoryName) {
		String sql = sqlProperty.getProperty("CommonDAO_018");
		sql = sql+" and vm_c.CategoryName like '%"+categoryName+"%'";
		Object[] params = new Object[] {};
		List<ValueTxtView> list = queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView()));
		return list;
	}
	
	@Override
	public List<ValueTxtView> getCategoryBrandList(int categoryID) {
		String sql = sqlProperty.getProperty("CommonDAO_019");
		Object[] params = new Object[] {categoryID};
		List<ValueTxtView> list = queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView()));
		return list;
	}
	
	@Override
	public List<ValueTxtView> getFirmWithTradeTemplate(QueryConditions qc) {
		this.log.debug("getFirmWithTradeTemplate DAO Start");
		String sql = sqlProperty.getProperty("CommonDAO_020");
		Object[] params = new Object[] {};
		List<ValueTxtView> list = queryBySQL(sql, qc, null, new CommonRowMapper(new ValueTxtView()));
		return list;
	}
	
	@Override
	public List<ValueTxtView> getZoneNumbeList(String zoneNum) {
		this.log.debug("getZoneNumbeList DAO Start");
		String sql = "select ZoneNum as value  from  D_ZoneNumber where ZoneNum ='"+zoneNum+"'";
		Object[] params = new Object[] {};
		List<ValueTxtView> list = queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView()));
		return list;
	}
	
	/**
	 * 地址
	 */
	@Override
	public int addAddress(Delivery delivery) {
		String sql = this.sqlProperty.getProperty("DelDistributionDetail_002");
		/**
		 * (AddPV,AddCT,Address,DISABLED,ContactName,ContactTelNo,CreateTime,UpdateTime)
		 */
		Object [] params ={
				delivery.getAddPV(),
				delivery.getAddCT(),
				delivery.getAddRess(),
				delivery.getCategoryName(),
				delivery.getContactTel()
		};
		int addRessID;
		try {
			addRessID = this.queryForIntID(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			addRessID =-1;
		}
		return addRessID;
	}
	
	@Override
	public String getAddRessString(int addRessID) {
		String sql = "SELECT CAST(ISNULL(vwc1.FullName, '') AS VARCHAR)+''+CAST(ISNULL(vwc2.FullName,'')  AS VARCHAR)+''"
				+ "+CAST(ISNULL(vwc3.FullName,'') AS VARCHAR)+''+CAST(ISNULL(ca.Address,'') AS VARCHAR) AS distributionAddress "
				+ "from C_Address ca LEFT JOIN VW_Canton vwc1  on ca.AddPV = vwc1.ID LEFT JOIN VW_Canton vwc2  on ca.AddCT = vwc2.ID"
				+ " LEFT JOIN VW_Canton vwc3  on ca.AddDT = vwc3.ID where ca.ID ="+addRessID;
		Object [] params = {};
		Delivery delivery = (Delivery) this.queryForObject(sql, params, new CommonRowMapper(new Delivery()));
		String distributionAddress;
		if(delivery.getDistributionAddress() == null){
			distributionAddress = "";
		}else {
			distributionAddress = delivery.getDistributionAddress();
		}
		return distributionAddress;
	}
	
	@Override
	public Firm getFirmByTraderID(String traderID) {
		String sql = "SELECT t1.* FROM C_Firm  t1  INNER JOIN C_Trader t2 ON t2.FirmID = t1.FirmID WHERE t2.TraderID ='"+traderID+"'";
		Object [] params = {
				
		};
		Firm firm = (Firm) this.queryForObject(sql, params, new CommonRowMapper(new Firm()));
		return firm;
	}

	@Override
	public List<CrmCategorySpecial> getCategorySpecialListByTradeTmptId(Integer tradeTmptId,String categoryName) {
		this.log.info(this.getClass().getName()+" getCategorySpecialListByTradeTmptId DAO Start");
		String sql = sqlProperty.getProperty("CommonDAO_021");
		if (categoryName != null && !"".equals(categoryName)){
			sql+= " and categorySpecial.CategoryName like '%"+categoryName+"%'";
		}
		Object[] params = {tradeTmptId};
		List<CrmCategorySpecial> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new CrmCategorySpecial()));
		this.log.info(this.getClass().getName()+" getCategorySpecialListByTradeTmptId DAO End");
		return list;
	}

	@Override
	public List<CrmBrand> getCrmBrandListByCategoryLeafIDOfTradeTmptId(Integer categoryLeafID,Integer tradeTmptId,String barandName) {
		this.log.info(this.getClass().getName()+" getCrmBrandListByCategoryLeafIDOfTradeTmptId DAO Start");
		String sql = sqlProperty.getProperty("CommonDAO_022");
		if (barandName != null && !"".equals(barandName)){
			sql+= " and brand.BrandName like '%"+barandName+"%'";
		}
		
		Object[] params = {categoryLeafID,tradeTmptId};
		List<CrmBrand> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new CrmBrand()));
		this.log.info(this.getClass().getName()+" getCrmBrandListByCategoryLeafIDOfTradeTmptId DAO End");
		return list;
	}

	@Override
	public List<CrmCategorySpecial> getCategoryListByType(Integer type) {
		this.log.info(this.getClass().getName()+" getCategoryListByType DAO Start");
		String sql = sqlProperty.getProperty("CommonDAO_023");
		Object[] params = {type};
		List<CrmCategorySpecial> list = this.queryBySQL(sql, params, null);
		this.log.info(this.getClass().getName()+" getCategoryListByType DAO End");
		return list;
	}

	@Override
	public int countFirmPrivilegeCategoryIDAndBrandId(String tradeTmptId,String firmId,Integer categoryId,
			Integer brandId) {
		this.log.info(this.getClass().getName()+" countFirmPrivilegeCategoryIDAndBrandId DAO Start");
		String sql = sqlProperty.getProperty("FirmPrivilegeDAO_008");
		Object[] params = {tradeTmptId,firmId,categoryId,brandId};
		int count = this.queryForInt(sql, params);
		this.log.info(this.getClass().getName()+" countFirmPrivilegeCategoryIDAndBrandId DAO End");
		return count;
	}
	
	/**
	 * 仓库地址信息
	 */
	@Override
	public List<ValueTxtView> getWHGruopAddress(Integer wHGruopID, Integer tradeTmptId) {
		this.log.info(this.getClass().getName()+" getWHGruopAddress Start");
		String sql = this.sqlProperty.getProperty("CommonDAO_024");
		Object [] params = {
				wHGruopID,
			tradeTmptId
		};
		List<ValueTxtView> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView()));
		this.log.info(this.getClass().getName()+" getWHGruopAddress End");
		return list;
	}
	
	@Override
	public List<ValueTxtView> getWHAddrTemplateRlspList(Integer tradeTmptId) {
		this.log.info(this.getClass().getName()+" getWHGruopAddress Start");
		String sql = "select WareHouseAddressID as value  from T_WHAddrTemplateRlsp where TradeTmptId = "+tradeTmptId+" and DISABLED=0";
		Object [] params = {};
		List<ValueTxtView> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView()));
		this.log.info(this.getClass().getName()+" getWHGruopAddress End");
		return list;
	}

	@Override
	public List<ValueTxtView> getFutureContractList() {
		this.log.info(this.getClass().getName()+"getFutureContractList DAO Start");
		String sql = sqlProperty.getProperty("CommonDAO_025");
		Object[] params = new Object[] {};
		List<ValueTxtView> list = queryBySQL(sql, params, null, new CommonRowMapper(new ValueTxtView("","")));
		this.log.info(this.getClass().getName()+" getFutureContractList End");
		return list;
	}
	
	public List<CateBrandPlaceView> getCateBrandSourcePlaceByTradeTmptId(QueryConditions qc,PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+"getCateBrandSourcePlaceByTempId DAO Start");
		String sql = sqlProperty.getProperty("CommonDAO_026");
		String groupByStr = " group by t.CategoryId,c.CategoryName,t.BrandId,b.BrandName,t.SourcePlaceId,s.Name,t.TradeUnitNumber ";
		List<CateBrandPlaceView> list = queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new CateBrandPlaceView()),groupByStr);
		this.log.info(this.getClass().getName()+" getCateBrandSourcePlaceByTradeTmptId End");
		return list;
	}
	
	public List<CateBrandPlaceView> getCateBrandByTradeTmptId(QueryConditions qc,PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+"getCateBrandByTradeTmptId DAO Start");
		String sql = sqlProperty.getProperty("CommonDAO_029");
		String groupByStr = " group by t.CategoryId,c.CategoryName,t.BrandId,b.BrandName ";
		List<CateBrandPlaceView> list = queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new CateBrandPlaceView()),groupByStr);
		this.log.info(this.getClass().getName()+" getCateBrandByTradeTmptId End");
		return list;
	}
	
	public List<CDictionary> getDictionaryList(QueryConditions qc,PageInfo pageInfo) {
		this.log.info(this.getClass().getName()+"getDictionaryList DAO Start");
		String sql = sqlProperty.getProperty("CommonDAO_027");
		List<CDictionary> list = queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new CDictionary()));
		this.log.info(this.getClass().getName()+" getDictionaryList End");
		return list;
	}
	public ChargesModel getChargesForLLDPEByFirmID(final String firmID, final String tmplID, final Integer cateID,
			final Integer brandID, final int tradeRole, final BigDecimal price, final BigDecimal quantity,
			final BigDecimal tradeUnitNumber, final int linerTypeDicId, final int deliveryDateDicId) {
		String procedure = sqlProperty.getProperty("CommonDAO_028");
		ChargesModel retM = new ChargesModel();
		try {
			retM = (ChargesModel) this.getJdbcTemplate().execute(procedure, new CallableStatementCallback() {
				public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {
					ChargesModel chargesModel = new ChargesModel();
					cs.setString(1, firmID); 
//					cs.setString(1, tmplID);
					cs.setLong(2, cateID);
					cs.setLong(3, brandID);
					cs.setInt(4, tradeRole);
					cs.setBigDecimal(5, price);
					cs.setBigDecimal(6, quantity);
					cs.setBigDecimal(7, tradeUnitNumber);
					cs.setInt(8, linerTypeDicId);
					cs.setInt(9, deliveryDateDicId);
					ResultSet rs = cs.executeQuery();
					while (rs.next()) {
						/**
						 * 如不存在相应设定，则对应费用为Null
						 */
						chargesModel.setMargin(rs.getBigDecimal("MarginAmount"));
						chargesModel.setMarginAlgr(rs.getBigDecimal("v_Margin_A"));
						chargesModel.setMarginRate(rs.getBigDecimal("v_Margin"));
						chargesModel.setFee(rs.getBigDecimal("FeeAmount"));
						chargesModel.setFeeAlgr(rs.getBigDecimal("v_Fee_A"));
						chargesModel.setFeeRate(rs.getBigDecimal("v_Fee"));
						chargesModel.setAddMargin(rs.getBigDecimal("AddMarginAmount"));
						chargesModel.setAddMarginAlgr(rs.getBigDecimal("v_AddMargin_A"));
						chargesModel.setAddMarginRate(rs.getBigDecimal("v_AddMargin"));
					}
					return chargesModel;
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
		return retM;
	}
}
