/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: JPushService.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年8月9日 　喻剑平   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.component;

import java.util.Collection;
import java.util.Map;

import cn.jpush.api.common.resp.APIConnectionException;
import shcem.common.dao.model.JPushModel;

/**
 * @author jampion
 *
 */
public interface IJPushMgr {

	/**
	 * 推送消息
	 * 
	 * @param jpush 消息推送model
	 * */
	public String sendPush(JPushModel jpush);
		
	/**
	 * 推送消息(全体广播)
	 * 
	 * @param message 推送的消息
	 * */
	public String sendPush(String message);
	
	/**
	 * 发送推送
	 * 
	 * @param message 推送的消息
	 * @param alias 用户别名
	 * @return
	 */
	public String sendPush(String message, Collection<String> aliases);
	
	/**
	 * 发送推送
	 * 
	 * @param message 推送的消息
	 * @param extras 扩展参数键值对
	 * @param alias 用户别名
	 * @return
	 * @throws APIConnectionException 
	 */
	public String sendPush(String message, Map<String, String> extras, Collection<String> aliases) throws APIConnectionException;

}
