/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: ICommonMgrService.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月31日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.service;

/**
 * @author wlpod
 *
 */
public interface ICommonMgrService {
	public String getAllProvList(String params);

	public String getAllCityList(String params);

	public String getCityListByPid(String params);

	public String getAllCountryList(String params);

	public String getCountryListByPid(String params);

	public String getCompanyTypeList(String params);

	public String getBankList(String params);

	public String getUserList(String params);

	public String getFirmList(String params);

	// 获取摘要信息
	public String getSummaryModelList(String params);

	public String getChargesByFirmID(String params);

	public String getSettleChargesByFirmID(String params);

	public String chkAuthByFirmID(String params);

	public String chkAuthByTraderID(String params);

	// 获取咨询tag信息
	public String getInfoTagList(String params);

	public String getLogonUserCount(String params);

	public String getTradeTmplList();

	/**
	 * 在交易商的基础上查询交易场
	 * 
	 * @param params
	 * @return
	 */
	public String getTradeTmplListByFirm(String params);

	/**
	 * 没有绑定任何交易商的用户
	 * 
	 * @param params
	 */
	public String getUnBindUserList(String params);

	public String getSummaryList(String params);

	public String getAssignBankList();
	
	/**
	 * 获取商品分类列表
	 */
	public String getCategoryList(String params);
	/**
	 * 获取商品牌号列表
	 */
	public String getCategoryBrandList(String params);
	/**
	 * 绑定过交易场的交易商
	 */
	public String getFirmWithTradeTemplate(String params);

	public String test(String params);
	
	public String createActivitiUser();
	/**
	 * 验证城市区号
	 * @param params
	 * @return
	 */
	public String checkZoneNumbe(String params);
	
	public String testConnection();
	
	
	/**
	 * 根据【交易场交易权限表(基础设定)】的交易场ID 获取分类列表
	 * @return
	 */
	public String getCategorySpecialListByTradeTmptId(String params);
	
	/**
	 * 获取分类下的商品牌号
	 * @return
	 */
	public String getCrmBrandListByCategoryLeafIDAndTradeTmptId(String params);
	
	/**
	 * 获取所有交收状态
	 * @return
	 */
	public String getAllDeliveryStatus();
	
	/**
	 * 获取所有成交状态
	 * @return
	 */
	public String getAllTradeStatus();
	
	/**
	 * 仓库组地址信息
	 * @param params
	 * @return
	 */
	public String getWHGruopAddress(String params);
	/**
	 * 获取期货合约列表
	 * @param params
	 * @return
	 */
	public String getFutureContractList(String params);
	
	/**
	 * 获取线性专场的分类牌号
	 * @param params
	 * @return
	 */
	public String getCategoryBrandListForLiner(String params);
	
	/**
	 * 获取线性专场产地+交易单位列表
	 * @param params
	 * @return
	 */
	public String getSourcePlaceListForLiner(String params);
	/**
	 * 获取系统枚举定义表
	 * @param params
	 * @return
	 */
	public String getDictionaryByENName(String params);
	
	/**
	 * 重新读取枚举定义表
	 * @param params
	 * @return
	 */
	public String reloadDictionary(String params);
	
	/**
	 * 获取线性专场交易保证金
	 * @param params
	 * @return
	 */
	public String getChargesForLLDPEByFirmID(String params);
	
	/**
	 * 获取字典表 options list
	 * 
	 * @param params
	 * @return
	 */
	public String getDicOptList(String params);
}
