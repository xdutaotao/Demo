/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：前台消息模块
 * File Name: JPushModel.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年8月15日 　喻剑平  Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.dao.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Map;

import shcem.base.dao.model.BaseObject;

/**
 * @author jampion
 *
 */
public class JPushModel extends BaseObject implements Serializable{
	private static final long serialVersionUID = -1278966116234002354L;
	
	/**
	 * 推送平台："all"，"android"，"ios"，"winphone"
	 */
	private String deviceType;
	
	/**
	 * 推送对象
	 */
	private Collection<String> aliases;
	
	/**
	 * 通知内容
	 */
	private String message;
	
	/**
	 * 附加字段
	 */
	private Map<String, String> extras;
	
	
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public Collection<String> getAliases() {
		return aliases;
	}
	public void setAliases(Collection<String> aliases) {
		this.aliases = aliases;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Map<String, String> getExtras() {
		return extras;
	}
	public void setExtras(Map<String, String> extras) {
		this.extras = extras;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}
