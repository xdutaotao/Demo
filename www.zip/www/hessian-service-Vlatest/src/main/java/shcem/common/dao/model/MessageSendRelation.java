/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：前台消息模块
 * File Name: MessageSendRelation.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年8月9日 　喻剑平  Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.dao.model;

import java.io.Serializable;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * @author jampion
 *
 */
public class MessageSendRelation extends BaseObject implements Serializable{
	
	private static final long serialVersionUID = 5523083689405307168L;

	private long ID;
	
	/**消息ID 关联 C_MessageHistory.MessageID*/
	private int MessageID;
	
	/**发送类型*/
	private int msgSendType;
	
	/**接收对象*/
	private String receiveNumber;
	
	/**发送状态*/
	private int msgStatus;
	
	/**返回状态*/
	private int resultStatus;
	
	/**创建人*/
	private String recCreateby;
	
	/**创建时间*/
	private Date recCreatetime;
	
	/**最后修改人*/
	private String recModifyby;
	
	/**最后修改时间*/
	private Date recModifytime;
	
	
	public long getID() {
		return ID;
	}
	public void setID(long iD) {
		ID = iD;
	}
	public int getMessageID() {
		return MessageID;
	}
	public void setMessageID(int messageID) {
		MessageID = messageID;
	}
	public int getMsgSendType() {
		return msgSendType;
	}
	public void setMsgSendType(int msgSendType) {
		this.msgSendType = msgSendType;
	}
	public String getReceiveNumber() {
		return receiveNumber;
	}
	public void setReceiveNumber(String receiveNumber) {
		this.receiveNumber = receiveNumber;
	}
	public int getMsgStatus() {
		return msgStatus;
	}
	public void setMsgStatus(int msgStatus) {
		this.msgStatus = msgStatus;
	}
	public int getResultStatus() {
		return resultStatus;
	}
	public void setResultStatus(int resultStatus) {
		this.resultStatus = resultStatus;
	}
	public String getRecCreateby() {
		return recCreateby;
	}
	public void setRecCreateby(String recCreateby) {
		this.recCreateby = recCreateby;
	}
	public Date getRecCreatetime() {
		return recCreatetime;
	}
	public void setRecCreatetime(Date recCreatetime) {
		this.recCreatetime = recCreatetime;
	}
	public String getRecModifyby() {
		return recModifyby;
	}
	public void setRecModifyby(String recModifyby) {
		this.recModifyby = recModifyby;
	}
	public Date getRecModifytime() {
		return recModifytime;
	}
	public void setRecModifytime(Date recModifytime) {
		this.recModifytime = recModifytime;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}
