/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: CommonMgrServiceImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月31日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import scem.activiti.ActivitiFactory;
import scem.activiti.model.User;
import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.common.component.ICommonMgr;
import shcem.common.dao.model.CDictionary;
import shcem.common.dao.model.CateBrandPlaceView;
import shcem.common.dao.model.ChargesModel;
import shcem.common.dao.model.CrmBrand;
import shcem.common.dao.model.CrmCategorySpecial;
import shcem.common.dao.model.UaacUser;
import shcem.common.service.ICommonMgrService;
import shcem.common.service.model.ValueTxtView;
import shcem.common.util.CommoSys;
import shcem.common.util.DictionaryConstant;
import shcem.common.util.RedisClient;
import shcem.constant.Constants;
import shcem.constant.DeliveryStatus;
import shcem.constant.ResultCode;
import shcem.constant.TradeStatus;
import shcem.util.Common;
import shcem.util.JsonUtil;

/**
 * @author wlpod
 *
 */
public class CommonMgrServiceImpl extends BaseServiceImpl implements ICommonMgrService {

	private ICommonMgr mgr = (ICommonMgr) CommoSys.getBean(Constants.BEAN_COMMON_MGR);

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.common.service.ICommonMgrService#getAllProvList()
	 */
	@Override
	public String getAllProvList(String params) {
		this.log.info(this.getClass().getName() + " getAllProvList() Start");
		List<ValueTxtView> list = null;
		boolean bolRst = false;
		try {
			list = mgr.getAllProvList();
			bolRst = true;
		} catch (Exception err) {
			this.log.error("查询省份列表出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("省份列表数据转换失败：" + e.getMessage());
				setResultData("00000", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getAllProvList() End");
		return rtnData.toString();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.common.service.ICommonMgrService#getAllCityList()
	 */
	@Override
	public String getAllCityList(String params) {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.common.service.ICommonMgrService#getCityListByPid(int)
	 */
	@Override
	public String getCityListByPid(String params) {
		this.log.info(this.getClass().getName() + " getAllProvList() Start");
		JSONObject JOParams = new JSONObject(params);
		int provID = JOParams.getInt("provID");
		List<ValueTxtView> list = null;
		boolean bolRst = false;
		try {
			list = mgr.getCityListByPid(provID);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("查询城市列表出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("城市列表数据转换失败：" + e.getMessage());
				setResultData("00000", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getAllProvList() End");
		return rtnData.toString();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.common.service.ICommonMgrService#getAllCountryList()
	 */
	@Override
	public String getAllCountryList(String params) {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.common.service.ICommonMgrService#getCountryListByPid(int)
	 */
	@Override
	public String getCountryListByPid(String params) {
		this.log.info(this.getClass().getName() + " getCountryListByPid() Start");
		JSONObject JOParams = new JSONObject(params);
		int cityId = JOParams.getInt("cityId");
		List<ValueTxtView> list = null;
		boolean bolRst = false;
		try {
			list = mgr.getCountryListByPid(cityId);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("查询县区列表出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("县区列表数据转换失败：" + e.getMessage());
				setResultData("00000", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getCountryListByPid() End");
		return rtnData.toString();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.common.service.ICommonMgrService#getCompanyTypeList()
	 */
	@Override
	public String getCompanyTypeList(String params) {
		this.log.info(this.getClass().getName() + " getCompanyTypeList() Start");
		List<ValueTxtView> list = null;
		boolean bolRst = false;
		try {
			list = mgr.getCompanyTypeList();
			bolRst = true;
		} catch (Exception err) {
			this.log.error("公司类型列表出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("公司类型数据转换失败：" + e.getMessage());
				setResultData("00000", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getBankList() End");
		return rtnData.toString();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.common.service.ICommonMgrService#getBankList()
	 */
	@Override
	public String getBankList(String params) {
		this.log.info(this.getClass().getName() + " getBankList() Start");
		List<ValueTxtView> list = null;
		JSONObject JSONParams = new JSONObject(params);
		boolean bolRst = false;
		String bankName = JSONParams.optString("bankName","");
		try {
			list = mgr.getBankList(bankName);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("查询银行列表出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("银行列表数据转换失败：" + e.getMessage());
				setResultData("00000", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getBankList() End");
		return rtnData.toString();
	}

	public String getUserList(String params) {
		this.log.info(this.getClass().getName() + " getUserList() Start");
		List<ValueTxtView> list = null;
		boolean bolRst = false;
		try {
			list = mgr.getUserList();
			bolRst = true;
		} catch (Exception err) {
			this.log.error("查询用户列表出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("用户数据转换失败：" + e.getMessage());
				setResultData("00000", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getUserList() End");
		return rtnData.toString();
	}

	@Override
	public String getFirmList(String params) {
		this.log.info(this.getClass().getName() + " getFirmList() Start");
		List<ValueTxtView> list = null;
		JSONObject JSONParams = new JSONObject(params);
		QueryConditions qc = null;
		boolean flag = false;
		
		int firmSource = 1;
		if (!JSONParams.isNull("queryModel")) {
			List<Condition> conditionsList = new ArrayList<Condition>();
//			conditionsList.add(new Condition("cf.FirmName", "like", "", "string", "firmName"));
//			conditionsList.add(new Condition(" OR++OR cf.FirmID", "like", "", "string", "firmName"));

			JSONObject queryModel = JSONParams.optJSONObject("queryModel");

			flag = queryModel.getString("firmName").replaceAll(" ", "").equals("");
			firmSource = queryModel.optInt("firmSource")==0?1:queryModel.optInt("firmSource");//如若该参数没有传递，默认为是化交平台调用
			qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionsList, "");
			if(queryModel != null){
				String firmName = queryModel.optString("firmName");
				if (firmName != null && !"".equals(firmName)) {
					qc.addCondition("(cf.FirmName like '%" + firmName + "%' or cf.FirmID like '%" + firmName
							+ "%') and '1'=", " ", 1);
				}
			}
		}

		boolean bolRst = false;
		try {
			if (flag) {
				list = null;
			} else {
				list = mgr.getFirmList(qc,firmSource);
			}

			bolRst = true;
		} catch (Exception err) {
			this.log.error("交易商列表出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			if (list != null) {
				try {
					retData = JsonUtil.coverModelToJSONArray(list);
					jsonObj.put("result", retData);
					setResultData("00000", jsonObj);
				} catch (Exception e) {
					this.log.error("交易商数据转换失败：" + e.getMessage());
					setResultData("10101", null, e.getMessage());
				}
			} else {
				setResultData("00000", null);
			}
		}

		this.log.info(this.getClass().getName() + " getFirmList() End");
		return rtnData.toString();
	}

	@Override
	public String getSummaryModelList(String params) {
		this.log.info(this.getClass().getName() + " getSummaryModelList() Start");
		List<ValueTxtView> list = null;
		boolean bolRst = false;
		try {
			list = mgr.getSummaryModelList();
			bolRst = true;
		} catch (Exception err) {
			this.log.error("科目列表出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("科目类型转换失败：" + e.getMessage());
				setResultData("00000", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getSummaryModelList() End");
		return rtnData.toString();
	}

	@Override
	public String getSummaryList(String params) {
		this.log.info(this.getClass().getName() + " getSummaryList() Start");
		List<ValueTxtView> list = null;
		boolean bolRst = false;
		try {
			list = mgr.getSummaryList();
			bolRst = true;
		} catch (Exception err) {
			this.log.error("科目列表出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("科目类型转换失败：" + e.getMessage());
				setResultData("00000", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getSummaryList() End");
		return rtnData.toString();
	}

	@Override
	public String getChargesByFirmID(String params) {
		this.log.info(this.getClass().getName() + " getChargesByFirmID() Start");
		JSONObject JOParams = new JSONObject(params);
		String firmID = JOParams.getString("firmID");
		String tmplID = JOParams.getString("tmplID");
		Integer cateID = JOParams.getInt("cateID");
		Integer brandID = JOParams.getInt("brandID");
		Integer tradeRole = JOParams.getInt("tradeRole");
		BigDecimal price = new BigDecimal(JOParams.getString("price"));
		BigDecimal quantity = new BigDecimal(JOParams.getString("quantity"));
		BigDecimal tradeUnitNumber = new BigDecimal(JOParams.getString("tradeUnitNumber"));
		ChargesModel cm = new ChargesModel();
		cm = mgr.getChargesByFirmID(firmID, tmplID, cateID, brandID, tradeRole, price, quantity, tradeUnitNumber);
		setResultData("00000", cm);
		this.log.info(this.getClass().getName() + " getChargesByFirmID() End");
		return rtnData.toString();
	}

	@Override
	public String getInfoTagList(String params) {
		this.log.info(this.getClass().getName() + " getInfoTagList() Start");
		JSONObject JOParams = new JSONObject(params);
		Integer tagTypeDiff = JOParams.getInt("tagTypeDiff");
		List<ValueTxtView> list = null;
		boolean bolRst = false;
		try {
			list = mgr.getInfoTagList(tagTypeDiff);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("获取咨询产品分类出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("咨询产品分类转换失败：" + e.getMessage());
				setResultData("00000", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getInfoTagList() End");
		return rtnData.toString();
	}

	/**
	 * 交易商相关费用
	 */
	@Override
	public String getSettleChargesByFirmID(String params) {
		this.log.info(this.getClass().getName() + " getSettleChargesByFirmID() Start");
		JSONObject JOParams = new JSONObject(params);
		String firmID = JOParams.getString("firmID");
		String tmplID = JOParams.getString("tmplID");
		Integer cateID = JOParams.getInt("cateID");
		Integer brandID = JOParams.getInt("brandID");
		Integer tradeRole = JOParams.getInt("tradeRole");
		BigDecimal price = new BigDecimal(JOParams.getString("price"));
		BigDecimal quantity = new BigDecimal(JOParams.getString("quantity"));
		BigDecimal tradeUnitNumber = new BigDecimal(JOParams.getString("tradeUnitNumber"));
		Integer sourcePlaceID = JOParams.optInt("sourcePlaceID");
		boolean ret = false;
		ret = mgr.chkAuthByFirmID(firmID, tmplID, cateID, brandID, tradeRole,sourcePlaceID);
		ChargesModel cm = new ChargesModel();
		if (!ret) {
			cm = mgr.getSettleChargesByFirmID(firmID, tmplID, cateID, brandID, tradeRole, price, quantity,
					tradeUnitNumber);
			setResultData("00000", cm);
		} else {
			setResultData("24000", null);
		}
		this.log.info(this.getClass().getName() + " getSettleChargesByFirmID() End");
		return rtnData.toString();
	}

	@Override
	public String chkAuthByFirmID(String params) {
		this.log.info(this.getClass().getName() + " ChkAuthByFirmID() Start");
		JSONObject JOParams = new JSONObject(params);
		String firmID = JOParams.getString("firmID");
		String tmplID = JOParams.getString("tmplID");
		Integer cateID = JOParams.getInt("cateID");
		Integer brandID = JOParams.getInt("brandID");
		Integer tradeRole = JOParams.getInt("tradeRole");
		/*产地ID*/
		Integer sourcePlaceID = JOParams.optInt("sourcePlaceID");
		boolean ret = false;
		ret = mgr.chkAuthByFirmID(firmID, tmplID, cateID, brandID, tradeRole,sourcePlaceID);
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("auth", ret);
		if (!ret) {
			setResultData("10114", jsonObj);
		} else {
			setResultData("00000", jsonObj);
		}

		this.log.info(this.getClass().getName() + " ChkAuthByFirmID() End");
		return rtnData.toString();
	}

	/**
	 * 
	 */
	@Override
	public String chkAuthByTraderID(String params) {
		this.log.info(this.getClass().getName() + " ChkAuthByTraderID() Start");
		JSONObject JOParams = new JSONObject(params);
		/*交易员ID*/
		String traderID = JOParams.getString("traderID");
		/*交易场ID*/
		String tmplID = JOParams.getString("tmplID");
		/*交易品类ID*/
		Integer cateID = JOParams.getInt("cateID");
		/*交易牌号ID*/
		Integer brandID = JOParams.getInt("brandID");
		/*交易买卖方向：0卖  1买*/
		Integer tradeRole = JOParams.getInt("tradeRole");
		/*产地ID*/
		Integer sourcePlaceID = JOParams.optInt("sourcePlaceID");
		boolean ret = false;
		ret = mgr.chkAuthByTraderID(traderID, tmplID, cateID, brandID, tradeRole,sourcePlaceID);
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("auth", ret);
		if (!ret) {
			setResultData("10114", jsonObj);
		} else {
			setResultData("00000", jsonObj);
		}
		this.log.info(this.getClass().getName() + " ChkAuthByTraderID() End");
		return rtnData.toString();
	}

	/**
	 * 取得当前登录用户数
	 */
	@Override
	public String getLogonUserCount(String params) {

		this.log.info(this.getClass().getName() + " getLogonUserCount() Start");

		JSONObject JOParams = new JSONObject(params);
		String ipaddress = JOParams.getString("ipaddress");
		String port = JOParams.getString("port");

		RedisClient rdsClient = new RedisClient(ipaddress, port);
		int userCount = rdsClient.getUserCount();

		setResultData("00000", Integer.toString(userCount));

		this.log.info(this.getClass().getName() + " getLogonUserCount() End");
		return rtnData.toString();
	}

	@Override
	public String getTradeTmplList() {
		this.log.info(this.getClass().getName() + " getTradeTmplList() Start");
		List<ValueTxtView> list = null;
		boolean bolRst = false;
		try {
			list = mgr.getTradeTmplList();
			bolRst = true;
		} catch (Exception err) {
			this.log.error("查询交易场列表出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("查询交易场列表出错：" + e.getMessage());
				setResultData("10101", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getTradeTmplList() End");
		return rtnData.toString();
	}

	@Override
	public String getTradeTmplListByFirm(String param) {
		this.log.info(this.getClass().getName() + " getTradeTmplListByFirm() Start");
		this.log.debug("JSONParams=" + param);
		JSONObject JSONParams = new JSONObject(param);
		String firmID = JSONParams.getString("firmID");
		List<ValueTxtView> list = null;
		boolean bolRst = false;
		try {
			list = this.mgr.getTradeTmplListByFirm(firmID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询交易场列表出错：" + e.getMessage());
			setResultData("10101", null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("查询交易场列表出错：" + e.getMessage());
				setResultData("10101", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getTradeTmplListByFirm() End");
		return rtnData.toString();
	}

	@Override
	public String getUnBindUserList(String params) {
		this.log.info(this.getClass().getName() + " getUnBindUserList() Start");
		List<ValueTxtView> list = null;
		boolean bolRst = false;
		try {
			list = mgr.getUnBindUserList();
			bolRst = true;
		} catch (Exception err) {
			this.log.error("查询用户列表出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("用户数据转换失败：" + e.getMessage());
				setResultData("10101", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getUnBindUserList() End");
		return rtnData.toString();
	}

	@Override
	public String getAssignBankList() {
		this.log.info(this.getClass().getName() + " getAssignBankList() Start");
		List<ValueTxtView> list = null;
		boolean bolRst = false;
		try {
			list = mgr.getAssignBankList();
			bolRst = true;
		} catch (Exception err) {
			this.log.error("获取签约银行列表出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10101", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getAssignBankList() End");
		return rtnData.toString();
	}

	/**
	 * 获取商品分类列表
	 */
	@Override
	public String getCategoryList(String params) {
		this.log.info(this.getClass().getName() + " getCategoryList() Start");
		JSONObject JSONParams = new JSONObject(params);
		// 商品分类名称
		String categoryName = JSONParams.getString("categoryName");
		List<ValueTxtView> list = null;
		boolean bolRst = false;
		try {
			list = mgr.getCategoryList(categoryName);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("获取商品分类列表出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("获取商品分类列表出错：" + e.getMessage());
				setResultData("10101", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getCategoryList() End");
		return rtnData.toString();
	}

	/**
	 * 获取商品牌号列表
	 */
	@Override
	public String getCategoryBrandList(String params) {
		this.log.info(this.getClass().getName() + " getCategoryBrandList() Start");
		JSONObject JSONParams = new JSONObject(params);
		// 商品分类名称
		int categoryID = JSONParams.getInt("categoryID");
		List<ValueTxtView> list = null;
		boolean bolRst = false;
		try {
			list = mgr.getCategoryBrandList(categoryID);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("获取商品牌号列表出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("获取商品牌号列表出错：" + e.getMessage());
				setResultData("10101", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getCategoryBrandList() End");
		return rtnData.toString();
	}

	@Override
	public String getFirmWithTradeTemplate(String params) {
		this.log.info(this.getClass().getName() + " getFirmWithTradeTemplate() Start");
		List<ValueTxtView> list = null;
		JSONObject JSONParams = new JSONObject(params);
		QueryConditions qc = null;
		boolean flag = false;
		if (!JSONParams.isNull("queryModel")) {
			List<Condition> conditionsList = new ArrayList<Condition>();
//			conditionsList.add(new Condition("cf.FirmName", "like", "", "string", "firmName"));
//			conditionsList.add(new Condition(" OR++OR cf.FirmID", "like", "", "string", "firmName"));

			JSONObject queryModel = JSONParams.optJSONObject("queryModel");

			flag = queryModel.getString("firmName").replaceAll(" ", "").equals("");
			qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionsList, "");
			
			if(queryModel != null){
				String firmName = queryModel.optString("firmName");
				if (firmName != null && !"".equals(firmName)) {
					qc.addCondition("(cf.FirmName like '%" + firmName + "%' or cf.FirmID like '%" + firmName
							+ "%') and '1'=", " ", 1);
				}
			}
		}

		boolean bolRst = false;
		try {
			if (flag) {
				list = null;
			} else {
				list = mgr.getFirmWithTradeTemplate(qc);
			}

			bolRst = true;
		} catch (Exception err) {
			this.log.error("交易商列表出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			if (list != null) {
				try {
					retData = JsonUtil.coverModelToJSONArray(list);
					jsonObj.put("result", retData);
					setResultData("00000", jsonObj);
				} catch (Exception e) {
					this.log.error("交易商数据转换失败：" + e.getMessage());
					setResultData("10101", null, e.getMessage());
				}
			} else {
				setResultData("00000", null);
			}
		}

		this.log.info(this.getClass().getName() + " getFirmWithTradeTemplate() End");
		return rtnData.toString();
	}

	@Override
	public String test(String params) {
		this.log.info(this.getClass().getName() + " test() Start");

		// 生成 Activiti API的post数据
		JSONObject jso = new JSONObject();
		JSONObject jsoPms = new JSONObject();

		jsoPms.put("firstName", "chiupdate");
		jsoPms.put("lastName", "yong");

		jso.put("userId", "adsf");
		jso.put("params", jsoPms);

		String postData = null;
		try {
			postData = ActivitiFactory.getActivitiRequestData("Get_Single_User", "kermit", jso);
		} catch (Exception e) {
			setResultData("", null, e.getMessage());
		}

		JSONObject rtnJso = null;
		if (postData != null) {
			// 调用Activiti API
			rtnJso = postActivitiApi(postData);
		}

		return rtnJso.toString();
	}

	/**
	 * 创建用户
	 * 
	 * @param params
	 * @return
	 */
	public String createActivitiUser() {
		this.log.info(this.getClass().getName() + " createActivitiUser() start");

		String userId = "kermit";
		JSONObject rtnJso = new JSONObject();
		try {
			this.log.info(" createActivitiUser() getUserList from UAAC");
			List<UaacUser> _userList = this.mgr.getAllUaacUser();
			this.log.info(" createActivitiUser() getListNumber:" + _userList.size());
			for (UaacUser user : _userList) {
				
				// 璁惧畾User灞炴�
				User acitiviiUser = new User();
				acitiviiUser.getParams().setId(user.getLoginName());
				acitiviiUser.getParams().setFirstName(user.getLoginName());
				acitiviiUser.getParams().setEmail(user.getEmail());
				acitiviiUser.getParams().setPassword(user.getLoginName());
				acitiviiUser.setUserId(user.getLoginName());
				JSONObject jso = acitiviiUser.getJsonObject();
				
				String postData = ActivitiFactory.getActivitiRequestData("Get_Single_User", userId, jso);
				if (postData != null) {
					JSONObject retJson = postActivitiApi(postData);
					String retCode = retJson.get("CODE").toString();
					if (retCode.equals("Fail")) {


						postData = ActivitiFactory.getActivitiRequestData("Create_User", userId, jso);

						if (postData != null) {
							rtnJso = postActivitiApi(postData);
						}
					}
				}
			}

		} catch (Exception e) {
			setResultData(ResultCode.CODE10116.getValue(), null, e.getMessage());
			this.log.error(this.getClass().getName() + " createActivitiUser() error:" + e.getMessage());
			return rtnData.toString();
		}

		this.log.info(this.getClass().getName() + " createActivitiUser() End");
		return rtnJso.toString();
	}
	@Override
	public String checkZoneNumbe(String params) {
		this.log.info(this.getClass().getName() + " checkZoneNumbe() Start");
		JSONObject JOParams = new JSONObject(params);
		String zoneNumbe = JOParams.getString("zoneNumbe");
		boolean ret = false;
		ret = mgr.checkZoneNumbe(zoneNumbe);
		if (!ret) {
			setResultData("10117", null);
		} else {
			setResultData("00000", null);
		}
		this.log.info(this.getClass().getName() + " checkZoneNumbe() End");
		return rtnData.toString();
	}
	
	@Override
	public String testConnection() {

		setResultData("00000", null);

		return rtnData.toString();
	}

	@Override
	public String getCrmBrandListByCategoryLeafIDAndTradeTmptId(String params) {
		this.log.info(this.getClass().getName() + " getCrmBrandListByCategoryLeafID() Start");
		this.log.info(params);
		JSONObject JSONParams = new JSONObject(params);
		List<CrmBrand> list = null;
		boolean bolRst = false;
		Integer categoryLeafID = JSONParams.optInt("categoryLeafID");
		Integer tradeTmptId = JSONParams.optInt("tradeTmptId");
		if (tradeTmptId == null || categoryLeafID == null){
			setResultData("10101", null, "交易场ID或分类ID没有传值");
			return rtnData.toString();
		}
		String barandName = JSONParams.optString("barandName");
		try {
			list = mgr.getCrmBrandListByCategoryLeafIDOfTradeTmptId(categoryLeafID, tradeTmptId, barandName);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("获取商品牌号列表出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("获取商品牌号列表出错：" + e.getMessage());
				setResultData("10101", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getCrmBrandListByCategoryLeafID() End");
		return rtnData.toString();
	}

	@Override
	public String getCategorySpecialListByTradeTmptId(String params) {
		this.log.info(this.getClass().getName() + " getCategorySpecialListByTradeTmptId() Start");
		this.log.info(params);
		JSONObject JSONParams = new JSONObject(params);
		
		Integer tradeTmptId = JSONParams.optInt("tradeTmptId");
		if (tradeTmptId == null){
			setResultData("10101", null, "交易场ID没有传值！");
			return rtnData.toString();
		}
		String categoryName = JSONParams.optString("categoryName");
		List<CrmCategorySpecial> list = null;
		boolean bolRst = false;
		try {
			list = mgr.getCategorySpecialListByTradeTmptId(tradeTmptId,categoryName);
			bolRst = true;
		} catch (Exception err) {
			this.log.error("获取交易场下分类列表出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("获取交易场下分类列表出错：" + e.getMessage());
				setResultData("10101", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getCategorySpecialListByTradeTmptId() End");
		return rtnData.toString();
	}

	@Override
	public String getAllDeliveryStatus() {
		this.log.info(this.getClass().getName() + " getAllDeliveryStatus() Start");
		JSONArray retData;
		JSONObject jsonObj = new JSONObject();
		List<ValueTxtView> list = null;
		
		try {
			list=new ArrayList<ValueTxtView>();
			for(DeliveryStatus s:DeliveryStatus.values()){
				ValueTxtView text=new ValueTxtView(); 
				text.setName(s.getDesc());
				text.setValue(s.getValue());
				list.add(text); 
			}
			retData = JsonUtil.coverModelToJSONArray(list);
			jsonObj.put("result", retData);
			jsonObj.put("total", list.size());
			setResultData("00000", jsonObj);
		} catch (Exception err) {
			this.log.error("获取交收单状态出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
		 
		this.log.info(this.getClass().getName() + " getAllDeliveryStatus() End");
		return rtnData.toString();
	}

	@Override
	public String getAllTradeStatus() {
		this.log.info(this.getClass().getName() + " getAllTradeStatus() Start");
		JSONArray retData;
		JSONObject jsonObj = new JSONObject();
		List<ValueTxtView> list = null;
		
		try {
			list=new ArrayList<ValueTxtView>();
			for(TradeStatus s:TradeStatus.values()){ 
				ValueTxtView text=new ValueTxtView(); 
				text.setName(s.getDesc());
				text.setValue(s.getValue());
				list.add(text); 
			}
			retData = JsonUtil.coverModelToJSONArray(list);
			jsonObj.put("result", retData);
			jsonObj.put("total", list.size());
			setResultData("00000", jsonObj); 
		} catch (Exception err) {
			this.log.error("获取成交单状态出错" + err.getMessage());
			setResultData("", null, err.getMessage());
		}
	 
		this.log.info(this.getClass().getName() + " getAllTradeStatus() End");
		return rtnData.toString();
	}

	/**
	 * 仓库组地址信息(锅：20161220 和交易场无关的地址要剔除掉！)
	 */
	@Override
	public String getWHGruopAddress(String params) {
		this.log.info(this.getClass().getName()+" getWHGruopAddress Start");
		JSONObject JSONParams = new JSONObject(params);
		Integer WHGruopID = JSONParams.optInt("WHGruopID");
		Integer tradeTmptId = JSONParams.optInt("tradeTmptId");
		List<ValueTxtView> list = new ArrayList<ValueTxtView>();
		boolean bolRst = false;
		try {
			list = this.mgr.getWHGruopAddress(WHGruopID,tradeTmptId);
			bolRst = true;
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" getWHGruopAddress");
			setResultData("10101",null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("仓库地址信息转换出错：" + e.getMessage());
				setResultData("30000", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName()+" getWHGruopAddress End");
		return rtnData.toString();
	}
	
	public String getFutureContractList(String params){
		this.log.info(this.getClass().getName()+" getFutureContractList Start");
		JSONObject JSONParams = new JSONObject(params);		
		List<ValueTxtView> list = new ArrayList<ValueTxtView>();
		boolean bolRst = false;
		try {
			list = this.mgr.getFutureContractList();
			bolRst = true;
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" getFutureContractList");
			setResultData("10101",null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("获取期货合约列表转换出错：" + e.getMessage());
				setResultData("30000", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName()+" getFutureContractList End");
		return rtnData.toString();
	}
	
	public String getCategoryBrandListForLiner(String params){
		this.log.info(this.getClass().getName()+" getCategoryBrandListForLiner Start");
		JSONObject JSONParams = new JSONObject(params);		
		
		JSONObject queryModel =JSONParams.optJSONObject("queryModel");
		List<Condition> conditionsList = new ArrayList<Condition>();
		conditionsList.add(new Condition("t.TradeTmptId", "=", "", "string","tradeTmptId"));
		conditionsList.add(new Condition("t.SourcePlaceId", "=", "", "string","sourcePlaceId"));
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionsList, "");
		qc.addCondition("t.PRIVILEGECODE_B", "=", 0);
		qc.addCondition("t.PRIVILEGECODE_S", "=", 0);
		
		PageInfo pageInfo = new PageInfo(); 
		pageInfo.setPageSize(0);
		pageInfo.addOrderField("t.CategoryId",false);
		pageInfo.addOrderField("t.BrandId",false);
	
		
		List<CateBrandPlaceView> list = new ArrayList<CateBrandPlaceView>();
		boolean bolRst = false;
	
		try {
			list = this.mgr.getCateBrandByTradeTmptId(qc,pageInfo);
			bolRst = true;
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" getCategoryBrandListForLiner");
			setResultData("10101",null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("获取线性专场的分类牌号：" + e.getMessage());
				setResultData("30000", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName()+" getCategoryBrandListForLiner End");
		return rtnData.toString();
	}
	
	public String getSourcePlaceListForLiner(String params){
		this.log.info(this.getClass().getName()+" getSourcePlaceListForLiner Start");
		JSONObject JSONParams = new JSONObject(params);		
		
		JSONObject queryModel =JSONParams.optJSONObject("queryModel");
		List<Condition> conditionsList = new ArrayList<Condition>();
		conditionsList.add(new Condition("t.TradeTmptId", "=", "", "string","tradeTmptId"));
		conditionsList.add(new Condition("t.BrandId", "=", "", "string","brandId"));
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionsList, "");
		qc.addCondition("t.PRIVILEGECODE_B", "=", 0);
		qc.addCondition("t.PRIVILEGECODE_S", "=", 0);
		
		PageInfo pageInfo = new PageInfo(); 
		pageInfo.setPageSize(0);
		pageInfo.addOrderField("t.CategoryId",false);
		pageInfo.addOrderField("t.BrandId",false);
		pageInfo.addOrderField("t.SourcePlaceId",false);

		List<CateBrandPlaceView> list = new ArrayList<CateBrandPlaceView>();
		boolean bolRst = false;
	
		try {
			list = this.mgr.getCateBrandSourcePlaceByTradeTmptId(qc,pageInfo);
			bolRst = true;
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" getSourcePlaceListForLiner");
			setResultData("10101",null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("获取线性专场产地+交易单位列表：" + e.getMessage());
				setResultData("30000", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName()+" getSourcePlaceListForLiner End");
		return rtnData.toString();
	}

	@Override
	public String getDictionaryByENName(String params) {
		this.log.info(this.getClass().getName() + " getDictionaryByENName Start");
		JSONObject JSONParams = new JSONObject(params);

		String ENName = JSONParams.optString("ENName");
		if (Common.isEmpty(ENName)) {
			setResultData("10103", null);
			return rtnData.toString();
		}

		List<CDictionary> list = new ArrayList<CDictionary>();
		boolean bolRst = false;

		try {
			list = DictionaryConstant.getDicListByENName(ENName);
			bolRst = true;
		} catch (Exception e) {
			this.log.error(this.getClass().getName() + " getDictionaryByENName");
			setResultData("10112", null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("获取系统枚举定义表：" + e.getMessage());
				setResultData("10112", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getDictionaryByENName End");
		return rtnData.toString();
	}

	@Override
	public String reloadDictionary(String params) {
		this.log.info(this.getClass().getName() + " reloadDictionary Start");

		try {
			DictionaryConstant.reload();
		} catch (Exception e) {
			this.log.error(this.getClass().getName() + " reloadDictionary");
			setResultData("10112", null, e.getMessage());
		}
		setResultData("00000", null);
		this.log.info(this.getClass().getName() + " reloadDictionary End");

		return rtnData.toString();
	}

	@Override
	public String getChargesForLLDPEByFirmID(String params) {
		this.log.info(this.getClass().getName() + " getChargesForLLDPEByFirmID() Start");
		JSONObject JOParams = new JSONObject(params);
		String firmID = JOParams.getString("firmID");
//		String tmplID = JOParams.getString("tmplID");
		String tmplID = "";
		Integer cateID = JOParams.getInt("cateID");
		Integer brandID = JOParams.getInt("brandID");
		Integer tradeRole = JOParams.getInt("tradeRole");
		BigDecimal price = new BigDecimal(JOParams.getString("price"));
		BigDecimal quantity = new BigDecimal(JOParams.getString("quantity"));
		BigDecimal tradeUnitNumber = new BigDecimal(JOParams.getString("tradeUnitNumber"));
		Integer linerTypeDicId = JOParams.getInt("linerTypeDicId");
		Integer deliveryDateDicId = JOParams.getInt("deliveryDateDicId");
		ChargesModel cm = new ChargesModel();
		cm = mgr.getChargesForLLDPEByFirmID(firmID, tmplID, cateID, brandID, tradeRole, price, quantity, tradeUnitNumber,linerTypeDicId,deliveryDateDicId);
		setResultData("00000", cm);
		this.log.info(this.getClass().getName() + " getChargesForLLDPEByFirmID() End");
		return rtnData.toString();
	}
	
	public String getDicOptList(String params) {
		this.log.info(this.getClass().getName()+" getDicOptList Start");
		JSONObject JSONParams = new JSONObject(params);
		String dicEnName = JSONParams.getString("enName");
		List<ValueTxtView> list = new ArrayList<ValueTxtView>();
		boolean bolRst = false;
		try {
			list = this.mgr.getDictionaryValueTextByName(dicEnName);
			bolRst = true;
		} catch (Exception e) {
			this.log.error(this.getClass().getName()+" getDicOptList");
			setResultData("10101",null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData);
				jsonObj.put("total", list.size());
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("获取字典表列表转换出错：" + e.getMessage());
				setResultData("30000", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName()+" getDicOptList End");
		return rtnData.toString();
	}
}
