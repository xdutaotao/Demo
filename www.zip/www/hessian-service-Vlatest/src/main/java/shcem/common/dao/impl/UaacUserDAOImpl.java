/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: UaacUserDaoImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年8月12日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.dao.impl;

import java.util.List;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.common.dao.UaacUserDAO;
import shcem.common.dao.model.UaacUser;
import shcem.util.CommonRowMapper;

/**
 * @author sunf
 *
 */
public class UaacUserDAOImpl  extends BaseDAOImpl implements UaacUserDAO {

	@Override
	public List<UaacUser> getAllUaacUser() {
		this.log.debug("getAllUaacUser DAO Start");
		String sql = sqlProperty.getProperty("UaacUserDAO_001");
		
		Object[] params = new Object[] {};
		List<UaacUser> userList = queryBySQL(sql, params, null, new CommonRowMapper(new UaacUser()));
		this.log.debug("getAllUaacUser DAO End");
		return userList;
	 
	}

}
