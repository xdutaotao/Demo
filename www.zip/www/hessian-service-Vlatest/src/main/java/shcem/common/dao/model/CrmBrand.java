/**
 * @author ws
 * 2016-10-21 13:18:21
 */
package shcem.common.dao.model;

import java.io.Serializable;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

public class CrmBrand extends BaseObject implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2564316169429200863L;

	private Integer id;

	private Integer disabled;

	private String rEC_CREATEBY;

	private Date rEC_CREATETIME;

	private String rEC_MODIFYBY;

	private Date rEC_MODIFYTIME;

	private Integer categoryLeafID;
	
	private String categoryLeafName;

	private String brandName;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY == null ? null : rEC_CREATEBY.trim();
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY == null ? null : rEC_MODIFYBY.trim();
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	public Integer getCategoryLeafID() {
		return categoryLeafID;
	}

	public void setCategoryLeafID(Integer categoryLeafID) {
		this.categoryLeafID = categoryLeafID;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName == null ? null : brandName.trim();
	}

	public String getCategoryLeafName() {
		return categoryLeafName;
	}

	public void setCategoryLeafName(String categoryLeafName) {
		this.categoryLeafName = categoryLeafName;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}