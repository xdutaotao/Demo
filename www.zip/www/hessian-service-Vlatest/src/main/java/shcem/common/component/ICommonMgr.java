/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: CommonMgr.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月30日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.component;

import java.math.BigDecimal;
import java.util.List;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.dao.CommonDAO;
import shcem.common.dao.model.CDictionary;
import shcem.common.dao.model.CateBrandPlaceView;
import shcem.common.dao.model.ChargesModel;
import shcem.common.dao.model.CrmBrand;
import shcem.common.dao.model.CrmCategorySpecial;
import shcem.common.dao.model.UaacUser;
import shcem.common.service.model.ValueTxtView;

/**
 * @author wlpod
 *
 */
public abstract interface ICommonMgr extends Manager {

	public abstract void setCommonDAO(CommonDAO paramCommonDAO);

	public abstract List<ValueTxtView> getAllProvList();

	public abstract List<ValueTxtView> getProvListByPid(int areaId);

	public abstract List<ValueTxtView> getAllCityList();

	public abstract List<ValueTxtView> getCityListByPid(int provId);

	public abstract List<ValueTxtView> getAllCountryList();

	public abstract List<ValueTxtView> getCountryListByPid(int cityId);

	public abstract List<ValueTxtView> getCompanyTypeList();

	public abstract List<ValueTxtView> getBankList(String bankName);

	public abstract List<ValueTxtView> getUserList();

	/**
	 * 
	 * @param qc
	 * @param firmSource 商户来源  1-HJOnline 2-CbiHX
	 * @return
	 */
	public abstract List<ValueTxtView> getFirmList(QueryConditions qc, int firmSource);

	public abstract List<ValueTxtView> getSummaryModelList();

	public abstract List<ValueTxtView> getInfoTagList(Integer tagTypeDiff);

	public abstract ChargesModel getChargesByFirmID(String firmID, String tmplID, Integer cateID, Integer brandID, int tradeRole,
			BigDecimal price, BigDecimal quantity, BigDecimal tradeUnitNumber);

	public abstract  ChargesModel getSettleChargesByFirmID(String firmID, String tmplID, Integer cateID, Integer brandID, int tradeRole,
			BigDecimal price, BigDecimal quantity, BigDecimal tradeUnitNumber);

	public abstract  boolean chkAuthByFirmID(String firmID, String tmplID, Integer cateID, Integer brandID, int tradeRole,Integer sourcePlaceID);
	
	public abstract  boolean chkAuthByTraderID(String traderID, String tmplID, Integer cateID, Integer brandID, int tradeRole,Integer sourcePlaceID);
	
	public abstract List<ValueTxtView> getTradeTmplList();

	public abstract List<ValueTxtView> getTradeTmplListByFirm(String firmID);

	public abstract List<ValueTxtView> getUnBindUserList();

	public abstract List<ValueTxtView> getSummaryList();
	
	public abstract List<ValueTxtView> getAssignBankList();

	public abstract List<ValueTxtView> getCategoryList(String categoryName);

	public abstract List<ValueTxtView> getCategoryBrandList(int categoryID);

	public abstract List<ValueTxtView> getFirmWithTradeTemplate(
			QueryConditions qc);
	
	public List<UaacUser> getAllUaacUser();

	public abstract boolean checkZoneNumbe(String zoneNumbe);
	
	/**
	 * 获取分类列表
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<CrmCategorySpecial> getCategorySpecialList();
	
	/**
	 * 根据【交易场交易权限表(基础设定)】的交易场ID 获取分类列表
	 * @param tradeTmptId
	 * @return
	 */
	public abstract List<CrmCategorySpecial> getCategorySpecialListByTradeTmptId(Integer tradeTmptId,String categoryName);
	
	/**
	 * 获取分类下的商品牌号
	 * @param categoryLeafID
	 * @param tradeTmptId
	 * @param like barandName
	 * @return
	 */
	public abstract List<CrmBrand> getCrmBrandListByCategoryLeafIDOfTradeTmptId(Integer categoryLeafID,Integer tradeTmptId,String barandName);

	/**
	 * 仓库地址信息
	 * @param wHGruopID
	 * @param tradeTmptId 
	 * @return
	 */
	public abstract List<ValueTxtView> getWHGruopAddress(Integer wHGruopID, Integer tradeTmptId);
	/**
	 * 获取期货合约列表
	 * @return
	 */
	public abstract List<ValueTxtView> getFutureContractList();
	
	/**
	 * 获取交易场所属分配牌号权限
	 * @param tempId
	 * @return
	 */
	public List<CateBrandPlaceView> getCateBrandSourcePlaceByTradeTmptId(QueryConditions qc,PageInfo pageInfo) ;
	
	/**
	 * 获取系统枚举定义表
	 * @param tempId
	 * @return
	 */
	public List<CDictionary> getDictionaryList(QueryConditions qc,PageInfo pageInfo) ;
	
	/**
	 * 获取线性专场交易保证金
	 * @param firmID
	 * @param tmplID
	 * @param cateID
	 * @param brandID
	 * @param tradeRole
	 * @param price
	 * @param quantity
	 * @param tradeUnitNumber
	 * @param linerTypeDicId
	 * @param deliveryDateDicId
	 * @return
	 */
	public abstract ChargesModel getChargesForLLDPEByFirmID(final String firmID, final String tmplID, final Integer cateID,
			final Integer brandID, final int tradeRole, final BigDecimal price, final BigDecimal quantity,
			final BigDecimal tradeUnitNumber, final int linerTypeDicId, final int deliveryDateDicId) ;
	/**
	 * 获取字典的 option list
	 * @param dicName
	 * @return
	 */
	public List<ValueTxtView> getDictionaryValueTextByName(String dicName);

	public List<CateBrandPlaceView> getCateBrandByTradeTmptId(QueryConditions qc, PageInfo pageInfo);

}
