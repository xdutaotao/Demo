package shcem.common.dao.impl;

import java.util.List;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.dao.ICMessageDAO;
import shcem.common.dao.model.MessageSendRelation;
import shcem.common.dao.model.MessageHistory;
import shcem.util.CommonRowMapper;

public class CMessageDAOImpl extends BaseDAOImpl implements ICMessageDAO {

	/**
	 * 获取需要推送的对象
	 * */
	@SuppressWarnings("unchecked")
	@Override
	public List<MessageHistory> getPushes() {
		this.log.debug("getPushes DAO Start");
		String sql = sqlProperty.getProperty("CMessageDAO_001").concat(sqlProperty.getProperty("CMessageDAO_005")) ;
		
		Object[] params = new Object[] {};
		List<MessageHistory> mhList = queryBySQL(sql, params, null, new CommonRowMapper(new MessageHistory()));
		this.log.debug("getPushes DAO End");
		return mhList;
	}
	
	/**
	 * 记录微信APP消息发送情况表（单条）
	 * */
	public int insertMessageSendRelation(MessageSendRelation sendRelation) {
		this.log.debug("insertMessageSendRelation DAO Start");
		String sql = sqlProperty.getProperty("CMessageDAO_002");
		Object[] params = {sendRelation.getMessageID(), sendRelation.getMsgSendType(), sendRelation.getReceiveNumber(),
				sendRelation.getMsgStatus(), sendRelation.getResultStatus(), sendRelation.getRecCreateby(), sendRelation.getRecModifyby()};
		int lines = updateBySQL(sql, params);
		this.log.debug("insertMessageSendRelation DAO End");
		return lines;
	}
	
	/**
	 * 查询消息列表
	 * */
	@SuppressWarnings("unchecked")
	public List<MessageHistory> getMessageHistoryList(QueryConditions qc, PageInfo pageInfo) {
		this.log.debug("getMessageHistoryList DAO Start");
		String sql = sqlProperty.getProperty("CMessageDAO_004");
		List<MessageHistory> mhList =  queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new MessageHistory()));
		this.log.debug("getMessageHistoryList DAO End");
		return mhList;
	}
	
	/**
	 * 查询未读消息数量
	 * */
	@SuppressWarnings("unchecked")
	public int getUnReadMsgNum(String mobile) {
		this.log.debug("getUnReadMsgNum DAO Start");
		Object[] params = { mobile };
		String sql = sqlProperty.getProperty("CMessageDAO_008");
		int num =  queryForInt(sql, params);
		this.log.debug("getUnReadMsgNum DAO End");
		return num;
	}
	
	/**
	 * 记录微信APP消息发送情况表（批量）
	 * */
	public void insertBatchMessageSendRelation(List<MessageSendRelation> sendRelations) {
		this.log.debug("insertBatchMessageSendRelation DAO Start");
		String sql = sqlProperty.getProperty("CMessageDAO_003");
		StringBuffer sqlB = new StringBuffer();
		sqlB.append(sql);

		for (int i=0, size = sendRelations.size(); i<size; i++) {
			sqlB.append("(");
			sqlB.append(sendRelations.get(i).getMessageID());
			sqlB.append(", ");
			sqlB.append(sendRelations.get(i).getMsgSendType());
			sqlB.append(", ");
			sqlB.append("'");
			sqlB.append(sendRelations.get(i).getReceiveNumber());
			sqlB.append("'");
			sqlB.append(", ");
			sqlB.append(sendRelations.get(i).getMsgStatus());
			sqlB.append(", ");
			sqlB.append(sendRelations.get(i).getResultStatus());
			sqlB.append(", ");
			sqlB.append("'");
			sqlB.append(sendRelations.get(i).getRecCreateby());
			sqlB.append("'");
			sqlB.append(", ");
			sqlB.append("getDate()");
			sqlB.append(", ");
			sqlB.append("'");
			sqlB.append(sendRelations.get(i).getRecModifyby());
			sqlB.append("'");
			sqlB.append(", ");
			sqlB.append("getDate()");
			if (i == size-1) {
				sqlB.append(")");
			} else {
				sqlB.append("), ");
			}
		}
		
		updateBySQL(sqlB.toString());
		this.log.debug("insertBatchMessageSendRelation DAO End");
	}

	/**
	 *  更新已经发送过消息的记录（app用）（isSend=1）
	 * */
	@Override
	public void updatePushesMsgHistory() {
		this.log.debug("updatePushesMsgHistory DAO Start");
		String sql = sqlProperty.getProperty("CMessageDAO_006").concat(sqlProperty.getProperty("CMessageDAO_005")) ;
		updateBySQL(sql);
		this.log.debug("updatePushesMsgHistory DAO End");
	}
	
	/**
	 *  更新已经发送过消息的记录（app用）（isSend=1）
	 * */
	@Override
	public void updatePushesMsgHistory(int messageId) {
		this.log.debug("updatePushesMsgHistory(messageId) DAO Start");
		String sql = sqlProperty.getProperty("CMessageDAO_010");
		Object[] params = new Object[] {messageId};
		updateBySQL(sql, params);
		this.log.debug("updatePushesMsgHistory(messageId) DAO End");
	}

	@Override
	public void updateMessageRead(int messageId) {
		this.log.debug("updateMessageRead DAO Start");
		String sql = sqlProperty.getProperty("CMessageDAO_007");
		Object[] params = new Object[] {messageId};
		updateBySQL(sql, params);
		this.log.debug("updateMessageRead DAO End");
	}
	
	@Override
	public void updateMessageReadByMobile(String mobile) {
		this.log.debug("updateMessageReadByMobile DAO Start");
		String sql = sqlProperty.getProperty("CMessageDAO_009");
		Object[] params = new Object[] {mobile};
		updateBySQL(sql, params);
		this.log.debug("updateMessageReadByMobile DAO End");
	}
}
