package shcem.common.service.model;

import com.sun.org.apache.regexp.internal.recompile;

import shcem.base.dao.model.BaseObject;

/**
 * 上一条、下一条记录 list
 * @author zhangnan
 *
 */
public class UpAndDownRecord extends BaseObject implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String recordID;
	/**
	 * 上一条记录
	 */
	private String prevRecordID;
	/**
	 * 下一条记录
	 */
	private String nextRecordID;
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getRecordID() {
		return recordID;
	}

	public void setRecordID(String recordID) {
		this.recordID = recordID;
	}

	public String getPrevRecordID() {
		return prevRecordID;
	}

	public void setPrevRecordID(String prevRecordID) {
		this.prevRecordID = prevRecordID;
	}

	public String getNextRecordID() {
		return nextRecordID;
	}

	public void setNextRecordID(String nextRecordID) {
		this.nextRecordID = nextRecordID;
	}

}
