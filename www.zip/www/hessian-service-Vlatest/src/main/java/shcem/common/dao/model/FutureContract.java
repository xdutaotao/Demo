/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: FutureContract.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2017年7月10日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.dao.model;

import shcem.base.dao.model.BaseObject;

/**
 * @author wlpod
 *
 */
public class FutureContract extends BaseObject implements Cloneable {

	/* (non-Javadoc)
	 * @see shcem.base.dao.model.BaseObject#toString()
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see shcem.base.dao.model.BaseObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see shcem.base.dao.model.BaseObject#hashCode()
	 */
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
