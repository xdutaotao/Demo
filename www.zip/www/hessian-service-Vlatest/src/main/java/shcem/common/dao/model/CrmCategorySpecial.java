/**
 * @author ws
 * 2016-10-21 12:46:21
 */
package shcem.common.dao.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import shcem.base.dao.model.BaseObject;

public class CrmCategorySpecial extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 395321086639060179L;

	private Integer id;

	private Integer disabled;

	private String rEC_CREATEBY;

	private Date rEC_CREATETIME;

	private String rEC_MODIFYBY;

	private Date rEC_MODIFYTIME;

	private Integer parentID;

	private String categoryName;

	private Integer relCategoryID;

	private String path;

	private Integer type;

	private Integer sort;
	
	private List<CrmCategorySpecial> crmCategorySpecialList;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getDisabled() {
		return disabled;
	}

	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY == null ? null : rEC_CREATEBY.trim();
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY == null ? null : rEC_MODIFYBY.trim();
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	public Integer getParentID() {
		return parentID;
	}

	public void setParentID(Integer parentID) {
		this.parentID = parentID;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName == null ? null : categoryName.trim();
	}

	public Integer getRelCategoryID() {
		return relCategoryID;
	}

	public void setRelCategoryID(Integer relCategoryID) {
		this.relCategoryID = relCategoryID;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path == null ? null : path.trim();
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public List<CrmCategorySpecial> getCrmCategorySpecialList() {
		return crmCategorySpecialList;
	}

	public void setCrmCategorySpecialList(
			List<CrmCategorySpecial> crmCategorySpecialList) {
		this.crmCategorySpecialList = crmCategorySpecialList;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}