package shcem.common.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisShardInfo;
import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

public class RedisClient {

	/**
	 * JedisPool连一台Redis，ShardedJedisPool连Redis集群，
	 * 通过一致性哈希算法决定把数据存到哪台上，是一种客户端负载均衡。
	 * 因此JedisPool用于删除和更新，ShardedJedisPool用于检索和添加
	 */
	private Jedis jedis;// 非切片额客户端连接
	private ShardedJedis shardedJedis;// 切片额客户端连接
	private ShardedJedisPool shardedJedisPool;// 切片连接池

	private final int dbIndex = 2;
	private final String[] redisName = new String[] { "master", "slave" };

	private String[] ip;
	private int ipCount = 1;
	private int port;

	public RedisClient(String ip, String port) {
		this.ip = ip.split(",");
		try {
			this.port = Integer.parseInt(port);
		} catch (NumberFormatException e) {
			// default port
			this.port = 6379;
		}

		if (this.ip.length == 2) {
			this.ipCount = 2;
		}

		initialShardedPool();
		shardedJedis = shardedJedisPool.getResource();
	}

	/**
	 * 初始化切片池
	 */
	private void initialShardedPool() {
		// 池基本配置
		JedisPoolConfig config = new JedisPoolConfig();
		// 连接耗尽时是否阻塞, false报异常,ture阻塞直到超时, 默认true
		config.setBlockWhenExhausted(true);
		// 最大连接数
		config.setMaxTotal(50);
		// 最大空闲连接数
		config.setMaxIdle(8);
		// 获取连接时的最大等待毫秒数(如果设置为阻塞时BlockWhenExhausted),如果超时就抛异常, 小于零:阻塞不确定的时间,
		// 默认-1
		config.setMaxWaitMillis(-1);
		// 最小空闲连接数, 默认0
		config.setMinIdle(0);
		// 在获取连接的时候检查有效性, 默认false
		config.setTestOnBorrow(false);
		// slave链接
		List<JedisShardInfo> shards = new ArrayList<JedisShardInfo>();
		for (int i = 0; i < this.ipCount; i++) {
			shards.add(new JedisShardInfo(this.ip[i], this.port, redisName[i]));
		}

		// 构造池
		shardedJedisPool = new ShardedJedisPool(config, shards);
	}

	public int getUserCount() {

		int lnCount;
		int count = 0;
		
		Collection<Jedis> c = shardedJedis.getAllShards();
		Iterator<Jedis> iterator = c.iterator();
		while (iterator.hasNext()) {
			jedis = iterator.next();
			jedis.select(dbIndex);
			lnCount = jedis.keys("shcem.com&online*").size();
			count = count + lnCount;
		}

		shardedJedisPool.close();

		return count;
	}

	public static void main(String[] args) {

		RedisClient rs = new RedisClient("192.168.60.107", "6379");

		System.out.println(rs.getUserCount());
	}
}
