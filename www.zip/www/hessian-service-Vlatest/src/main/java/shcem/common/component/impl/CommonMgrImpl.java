/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: CommonMgrImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年5月30日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.component.impl;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.component.ICommonMgr;
import shcem.common.dao.CommonDAO;
import shcem.common.dao.UaacUserDAO;
import shcem.common.dao.model.CDictionary;
import shcem.common.dao.model.CateBrandPlaceView;
import shcem.common.dao.model.ChargesModel;
import shcem.common.dao.model.CrmBrand;
import shcem.common.dao.model.CrmCategorySpecial;
import shcem.common.dao.model.UaacUser;
import shcem.common.service.model.ValueTxtView;
import shcem.common.util.DictionaryConstant;
import shcem.member.dao.model.Firm;
import shcem.member.dao.model.FirmAllData;

/**
 * @author wlpod
 *
 */
public class CommonMgrImpl extends BaseManager implements ICommonMgr {
	private CommonDAO commonDao;
	
	private CommonDAO commonDao_read;
	
	public void setCommonDao_read(CommonDAO commonDao_read) {
		this.commonDao_read = commonDao_read;
	}

	private UaacUserDAO uaacUserDAO;
	private UaacUserDAO uaacUserDAO_read;
	public UaacUserDAO getUaacUserDAO() {
		return uaacUserDAO;
	}

	public void setUaacUserDAO_read(UaacUserDAO uaacUserDAO_read) {
		this.uaacUserDAO_read = uaacUserDAO_read;
	}

	public void setUaacUserDAO(UaacUserDAO uaacUserDAO) {
		this.uaacUserDAO = uaacUserDAO;
	}

	public CommonDAO getCommonDao() {
		return commonDao;
	}

	public void setCommonDao(CommonDAO commonDao) {
		this.commonDao = commonDao;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * shcem.common.service.CommonMgr#setCommonDAO(shcem.common.dao.CommonDAO)
	 */
	@Override
	public void setCommonDAO(CommonDAO paramCommonDAO) {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.common.service.CommonMgr#getAllProvList()
	 */
	@Override
	public List<ValueTxtView> getAllProvList() {

		return this.commonDao_read.getCantonListByLv(2);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.common.service.CommonMgr#getProvListByPid(int)
	 */
	@Override
	public List<ValueTxtView> getProvListByPid(int areaId) {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.common.service.CommonMgr#getAllCityList()
	 */
	@Override
	public List<ValueTxtView> getAllCityList() {
		return this.commonDao.getCantonListByLv(3);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.common.service.CommonMgr#getCityListByPid(int)
	 */
	@Override
	public List<ValueTxtView> getCityListByPid(int provId) {
		return this.commonDao_read.getCantonListByPid(provId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.common.service.CommonMgr#getAllCountryList()
	 */
	@Override
	public List<ValueTxtView> getAllCountryList() {
		return this.commonDao.getCantonListByLv(4);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.common.service.CommonMgr#getCountryListByPid(int)
	 */
	@Override
	public List<ValueTxtView> getCountryListByPid(int cityId) {
		return this.commonDao_read.getCantonListByPid(cityId);
	}

	@Override
	public List<ValueTxtView> getCompanyTypeList() {
		return this.commonDao_read.getCompanyTypeList();
	}

	@Override
	public List<ValueTxtView> getBankList(String bankName) {
		return this.commonDao_read.getBankList(bankName);
	}

	@Override
	public List<ValueTxtView> getUserList() {
		return this.commonDao_read.getUserList();
	}

	@Override
	public List<ValueTxtView> getFirmList(QueryConditions qc,int firmSource){
		return this.commonDao_read.getFirmList(qc,firmSource);
	}

	@Override
	public List<ValueTxtView> getSummaryModelList() {
		return this.commonDao_read.getSummaryModelList();
	}

	/**
	 * 根据交易商ID获取交易手续费，交易保证金
	 */
	@Override
	public ChargesModel getChargesByFirmID(String firmID, String tmplID, Integer cateID, Integer brandID, int tradeRole,
			BigDecimal price, BigDecimal quantity, BigDecimal tradeUnitNumber) {
		this.log.info(this.getClass().getName()+" getChargesByFirmID(根据交易商ID获取交易手续费，交易保证金)");
		return this.commonDao_read.getChargesByFirmID(firmID, tmplID, cateID, brandID, tradeRole, price, quantity,
				tradeUnitNumber);
	}

	/**
	 * 根据交易商ID获取交收手续费，交收保证金，所需支付货款
	 * 
	 * @param firmID
	 * @param tmplID
	 * @param cateID
	 * @param brandID
	 * @param tradeRole
	 * @param price
	 * @param quantity
	 * @param tradeUnitNumber
	 * @return
	 */
	@Override
	public ChargesModel getSettleChargesByFirmID(String firmID, String tmplID, Integer cateID, Integer brandID,
			int tradeRole, BigDecimal price, BigDecimal quantity, BigDecimal tradeUnitNumber) {
		return this.commonDao_read.getSettleChargesByFirmID(firmID, tmplID, cateID, brandID, tradeRole, price, quantity,
				tradeUnitNumber);
	}

	@Override
	public List<ValueTxtView> getInfoTagList(Integer tagTypeDiff) {
		return this.commonDao_read.getInfoTagList(tagTypeDiff);
	}

	@Override
	public boolean chkAuthByFirmID(String firmID, String tmplID, Integer cateID, Integer brandID, int tradeRole,Integer sourcePlaceID) {
		return this.commonDao_read.ChkAuthByFirmID(firmID, tmplID, cateID, brandID, tradeRole,sourcePlaceID);
	}

	@Override
	public boolean chkAuthByTraderID(String traderID, String tmplID, Integer cateID, Integer brandID, int tradeRole,Integer sourcePlaceID) {
		//交易员交易场权限
		boolean tradeAuth = this.commonDao_read.ChkAuthByTraderID(traderID, tmplID, cateID, brandID, tradeRole,sourcePlaceID);
		
		//交易员关联的交易商具有的(交易员交易商 一对一)
		Firm firm = this.commonDao_read.getFirmByTraderID(traderID);
		if(firm != null){
			if (tradeAuth) {
				tradeAuth = this.commonDao_read.ChkAuthByFirmID(firm.getFirmid(), tmplID, cateID, brandID, tradeRole,sourcePlaceID);// 校验分类和牌号是否有权限
			}else {
				return tradeAuth;
			}
		}else {
			tradeAuth = false;
		}
		return tradeAuth;
	}

	@Override
	public List<ValueTxtView> getTradeTmplList() {
		return this.commonDao_read.getTradeTmplList();
	}
	@Override
	public List<ValueTxtView> getTradeTmplListByFirm(String firmID) {
		return this.commonDao_read.getTradeTmplListByFirm(firmID);
	}

	@Override
	public List<ValueTxtView> getUnBindUserList() {
		return this.commonDao_read.getUnBindUserList();
	}
	
	@Override
	public List<ValueTxtView> getSummaryList() {
		return this.commonDao_read.getSummaryList();
	}

	@Override
	public List<ValueTxtView> getAssignBankList() {
		return this.commonDao_read.getAssignBankList();
	}
	
	@Override
	public List<ValueTxtView> getCategoryList(String categoryName) {
		return this.commonDao_read.getCategoryList(categoryName);
	}
	
	@Override
	public List<ValueTxtView> getCategoryBrandList(int categoryID) {
		return this.commonDao_read.getCategoryBrandList(categoryID);
	}
	@Override
	public List<ValueTxtView> getFirmWithTradeTemplate(QueryConditions qc) {
		return this.commonDao_read.getFirmWithTradeTemplate(qc);
	}

	@Override
	public List<UaacUser> getAllUaacUser() {
		this.log.info(" getAllUaacUser() Start");
		return this.uaacUserDAO_read.getAllUaacUser();
	}
	@Override
	public boolean checkZoneNumbe(String zoneNumbe) {
		boolean flag = false;
		List<ValueTxtView> list = this.commonDao_read.getZoneNumbeList(zoneNumbe);
		if(list != null && list.size() > 0){
			flag = true;
		}else {
			flag = false;
		}
		return flag;
	}

	@Override
	public List<CrmCategorySpecial> getCategorySpecialList() {
		this.log.info(this.getClass().getName()+ " getCategorySpecialList() component Start");
		List<CrmCategorySpecial> listMain = commonDao.getCategoryListByType(0);//分类类型 0:分枝 1:叶子
		List<CrmCategorySpecial> listBranch = commonDao.getCategoryListByType(1);//分类类型 0:分枝 1:叶子
		if(listMain != null && listBranch != null){
			for (CrmCategorySpecial categorySpecial : listMain){
				List<CrmCategorySpecial> childrenList = new ArrayList<CrmCategorySpecial>();
				for (CrmCategorySpecial categorySpecial1 : listBranch){
					if (categorySpecial.getId().equals(categorySpecial1.getParentID())){
						childrenList.add(categorySpecial1);
					}
				}
				categorySpecial.setCrmCategorySpecialList(childrenList);
			}
		}
		this.log.info(this.getClass().getName()+ " getCategorySpecialList() component End");
		return listMain;
	}

	@Override
	public List<CrmBrand>getCrmBrandListByCategoryLeafIDOfTradeTmptId(Integer categoryLeafID,Integer tradeTmptId,String barandName) {
		this.log.info(this.getClass().getName()+ " getCrmBrandListByCategoryLeafIDOfTradeTmptId() component Start");
		List<CrmBrand> list = commonDao_read.getCrmBrandListByCategoryLeafIDOfTradeTmptId(categoryLeafID, tradeTmptId, barandName);
		this.log.info(this.getClass().getName()+ " getCrmBrandListByCategoryLeafIDOfTradeTmptId() component End");
		return list;
	}

	@Override
	public List<CrmCategorySpecial> getCategorySpecialListByTradeTmptId(Integer tradeTmptId,String categoryName) {
		this.log.info(this.getClass().getName()+ " getCategorySpecialListByTradeTmptId() component Start");
		List<CrmCategorySpecial> list = commonDao_read.getCategorySpecialListByTradeTmptId(tradeTmptId,categoryName);
		this.log.info(this.getClass().getName()+ " getCategorySpecialListByTradeTmptId() component End");
		return list;
	}
	
	/**
	 * 仓库地址信息
	 */
	@Override
	public List<ValueTxtView> getWHGruopAddress(Integer wHGruopID,Integer tradeTmptId) {
		this.log.info(this.getClass().getName()+" getWHGruopAddress Start");
		List<ValueTxtView> list = this.commonDao_read.getWHGruopAddress(wHGruopID,tradeTmptId);
		/**
		 * 锅：20161220 和交易场无关的地址要剔除掉！  T_WHAddrTemplateRlsp
		 */
		
		this.log.info(this.getClass().getName()+" getWHGruopAddress End");
		return list;
	}

	@Override
	public List<ValueTxtView> getFutureContractList() {
		return this.commonDao_read.getFutureContractList();
	}

	@Override
	public List<CateBrandPlaceView> getCateBrandSourcePlaceByTradeTmptId(
			QueryConditions qc,PageInfo pageInfo) {
		return this.commonDao_read.getCateBrandSourcePlaceByTradeTmptId(qc,pageInfo);
	}
	
	@Override
	public List<CateBrandPlaceView> getCateBrandByTradeTmptId(
			QueryConditions qc,PageInfo pageInfo) {
		return this.commonDao_read.getCateBrandByTradeTmptId(qc,pageInfo);
	}
	
	@Override
	public List<CDictionary> getDictionaryList(QueryConditions qc, PageInfo pageInfo) {
		return this.commonDao_read.getDictionaryList(qc, pageInfo);
	}

	@Override
	public ChargesModel getChargesForLLDPEByFirmID(String firmID,
			String tmplID, Integer cateID, Integer brandID, int tradeRole,
			BigDecimal price, BigDecimal quantity, BigDecimal tradeUnitNumber,
			int linerTypeDicId, int deliveryDateDicId) {
		this.log.info(this.getClass().getName()+" getChargesByFirmID(根据交易商ID获取线性交易手续费，交易保证金)");
		return this.commonDao_read.getChargesForLLDPEByFirmID(firmID, tmplID, cateID, brandID, tradeRole, price, quantity,
				tradeUnitNumber, linerTypeDicId, deliveryDateDicId);
	}
	
	public List<ValueTxtView> getDictionaryValueTextByName(String dicName){
		List<CDictionary> dicList = DictionaryConstant.getDicListByENName(dicName);
		List<ValueTxtView> retList = new ArrayList<ValueTxtView>();
		for(CDictionary dic : dicList) {
			retList.add(new ValueTxtView(dic.getDictID().toString(),dic.getValueName()));
		}
		return retList;
	}
}
