/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IPushMsgForAppService.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年8月9日 　喻剑平   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.common.service;

/**
 * @author jampion
 *
 */
public interface IPushMsgForAppService {

	/**
	 * app推送消息（广播）
	 * 
	 * @param params
	 * @return
	 */
	public String pushMsgWithBroadcast();
	
	/**
	 * app推送消息
	 * 
	 * @param params
	 * @return
	 */
	public String pushMsg();

	/**
	 * 通过手机号，获取用户已发送消息列表
	 * 
	 * @param params
	 * @return
	 */
	public String getMessageHistoryList(String params);
	
	/**
	 * 标识信息为已读
	 * 
	 * @param params
	 * @return
	 */
	public String setMessageRead(String params);

	/**
	 * 查询未读消息数量
	 * */
	public String getUnReadMsgNum(String params);
}
