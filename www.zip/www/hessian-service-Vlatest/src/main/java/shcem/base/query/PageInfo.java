/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: PageInfo
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.base.query;

import java.util.ArrayList;
import java.util.List;

/**
 * PageInfo
 * @author chiyong
 * @version 1.0
 */
public class PageInfo {
	private int pageSize;//每页展示条数
	private int pageNo;//第几页
	private int totalPages;
	private int totalRecords;
	private List<OrderField> orderFields = new ArrayList<OrderField>();

	public PageInfo() {
	}

	public PageInfo(int pageNo, int pageSize, String field, boolean isOrderDesc) {
		this.pageNo = pageNo;
		this.pageSize = pageSize;
		addOrderField(field, isOrderDesc);
	}

	public void addOrderField(String field, boolean isOrderDesc) {
		this.orderFields.add(new OrderField(field, isOrderDesc));
	}

	public List<OrderField> getOrderFields() {
		return this.orderFields;
	}

	public void setOrderFields(List<OrderField> orderFields) {
		this.orderFields = orderFields;
	}

	public int getPageNo() {
		return this.pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getPageSize() {
		return this.pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getTotalPages() {
		return this.totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public int getTotalRecords() {
		return this.totalRecords;
	}

	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}
}
