/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: Header
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.base.service.model;

import java.io.Serializable;

import shcem.constant.Constants;
import shcem.hessian.HessianHeaderContext;

/**
 * Header
 * 
 * @author chiyong
 * @version 1.0
 */
public class Header implements Serializable {

	private static final long serialVersionUID = 1L;

	// 服务A对象的keyCode
	private String ClientIP;
	private String ReqTime;
	private String MemberID;
	private String MemberName;
	private String AppName;
	private String Mode;
	private String RequestId;

	public Header(HessianHeaderContext context) {
		this.ClientIP = context.getHeader(Constants.HEADER_CLIENT_IP) == null ? "" : context
				.getHeader(Constants.HEADER_CLIENT_IP);
		this.ReqTime = context.getHeader(Constants.HEADER_REQ_TIME) == null ? "" : context
				.getHeader(Constants.HEADER_REQ_TIME);
		this.MemberID = context.getHeader(Constants.HEADER_MEM_ID) == null ? "" : context
				.getHeader(Constants.HEADER_MEM_ID);
		this.MemberName = context.getHeader(Constants.HEADER_MEM_NAME) == null ? "" : context
				.getHeader(Constants.HEADER_MEM_NAME);
		this.AppName = context.getHeader(Constants.HEADER_APP_NAME) == null ? "" : context
				.getHeader(Constants.HEADER_APP_NAME);
		this.RequestId = context.getHeader(Constants.HEADER_REQUESTID) == null ? "" : context
				.getHeader(Constants.HEADER_REQUESTID);

		String mode = Constants.MODE_LOCAL;
		String sysMode = System.getProperty(Constants.HEADER_MODE);

		if (sysMode != null && !sysMode.isEmpty()) {
			if (Constants.MODE_LOCAL.equals(sysMode) || Constants.MODE_DEV.equals(sysMode)
					|| Constants.MODE_TEST.equals(sysMode) || Constants.MODE_UAT.equals(sysMode)
					|| Constants.MODE_DEPLOY.equals(sysMode)) {
				mode = sysMode;
			}
		}

		this.Mode = mode;

		System.out.println("Header-----:" + this.ClientIP + ":" + this.ReqTime + ":" + this.MemberID + ":"
				+ this.MemberName + ":" + this.AppName + ":" + this.RequestId + ":" + this.Mode);
	}

	public String getClientIP() {
		return ClientIP;
	}

	public void setClientIP(String clientIP) {
		ClientIP = clientIP;
	}

	public String getReqTime() {
		return ReqTime;
	}

	public void setReqTime(String reqTime) {
		ReqTime = reqTime;
	}

	public String getMemberID() {
		return MemberID;
	}

	public void setMemberID(String memberID) {
		MemberID = memberID;
	}

	public String getMemberName() {
		return MemberName;
	}

	public void setMemberName(String memberName) {
		MemberName = memberName;
	}

	public String getAppName() {
		return AppName;
	}

	public void setAppName(String appName) {
		AppName = appName;
	}

	public String getMode() {
		return Mode;
	}

	public void setMode(String mode) {
		Mode = mode;
	}

	public String getRequestId() {
		return RequestId;
	}

	public void setRequestId(String requestId) {
		RequestId = requestId;
	}

}
