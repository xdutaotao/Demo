/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: BaseDAOImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.base.dao.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Properties;

import shcem.base.dao.DAO;
import shcem.base.dao.DaoHelper;
import shcem.constant.Constants;
import shcem.log.service.ILogService;
import shcem.log.service.impl.LogServiceImpl;
import shcem.util.PropertyUtil;

/**
 * BaseDAOImpl
 * @author chiyong
 * @version 1.0
 */
public class BaseDAOImpl extends DaoHelper implements DAO {
	
	protected final ILogService log = new LogServiceImpl("DAOlog");
	
	protected Properties sqlProperty;
	
	public BaseDAOImpl() {
		PropertyUtil propUtil = new PropertyUtil();
		sqlProperty = propUtil.getProperties(Constants.SQL_PROPERTY);
	}

	public void saveObject(Object o) {
	}

	public Object getObject(Class clazz, Serializable id) {
		return null;
	}

	public List getObjects(Class clazz) {
		return null;
	}

	public void removeObject(Class clazz, Serializable id) {
	}

	protected String convertStringNull2Blank(String v) {
		return v == null ? "" : v;
	}

	protected Short convertShortNull2Zero(Short v) {
		return v == null ? new Short((short) 0) : v;
	}

	protected Double convertDoubleNull2Zero(Double v) {
		return v == null ? new Double(0.0D) : v;
	}

	protected Long convertLongNull2Zero(Long v) {
		return v == null ? new Long(0L) : v;
	}

	public int deleteVoucher(Long vOUCHERNO) {
		// TODO Auto-generated method stub
		return 0;
	}
}
