/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: BaseObject
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.base.dao.model;

import java.io.Serializable;
import java.util.Date;

import shcem.util.Clone;

/**
 * BaseObject
 * @author chiyong
 * @version 1.0
 */
public abstract class BaseObject extends Clone implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public abstract String toString();

	public abstract boolean equals(Object paramObject);

	public abstract int hashCode();
	
	String recCreateby;
	Date recCreatetime;
	String recModifyby;
	Date recModifytime;

	public String getRecCreateby() {
		return recCreateby;
	}

	public void setRecCreateby(String recCreateby) {
		this.recCreateby = recCreateby;
	}

	public Date getRecCreatetime() {
		return recCreatetime;
	}

	public void setRecCreatetime(Date recCreatetime) {
		this.recCreatetime = recCreatetime;
	}

	public String getRecModifyby() {
		return recModifyby;
	}

	public void setRecModifyby(String recModifyby) {
		this.recModifyby = recModifyby;
	}

	public Date getRecModifytime() {
		return recModifytime;
	}

	public void setRecModifytime(Date recModifytime) {
		this.recModifytime = recModifytime;
	}
	


}