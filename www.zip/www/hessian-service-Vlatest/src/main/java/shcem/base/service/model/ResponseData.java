/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: ResponseData
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.base.service.model;

import java.io.Serializable;
import java.util.Hashtable;

import org.json.JSONObject;

/**
 * ResponseData
 * 
 * @author chiyong
 * @version 1.0
 */
public class ResponseData implements Serializable {

	private static final long serialVersionUID = 1L;

	// keyCode
	private String CODE;
	private String INFO;
	private String DATA;

	public String toString() {
		Hashtable<String, String> tb = new Hashtable<String, String>();

		tb.put("CODE", this.CODE == null ? "" : this.CODE);
		tb.put("INFO", this.INFO == null ? "" : this.INFO);
		tb.put("DATA", this.DATA == null ? "" : this.DATA);

		return new JSONObject(tb).toString();
	}

	public String getCODE() {
		return CODE;
	}

	public void setCODE(String cODE) {
		CODE = cODE;
	}

	public String getINFO() {
		return INFO;
	}

	public void setINFO(String iNFO) {
		INFO = iNFO;
	}

	public String getDATA() {
		return DATA;
	}

	public void setDATA(String dATA) {
		DATA = dATA;
	}

}
