/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: Condition
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.base.query;

/**
 * Condition
 * 
 * @author chiyong
 * @version 1.0
 */
public class Condition {
	public static final String STRING = "string";
	public static final String LONG = "long";
	public static final String DATE = "date";
	public static final String DATETIME = "datetime";
	private String field;
	private String operator;
	private Object value;
	private String dataType;
	private String aliasName;//别名 模型中的定义，空时则用field

	/**
	 * @return the aliasName
	 */
	public String getAliasName() {
		return aliasName;
	}

	/**
	 * @param aliasName the aliasName to set
	 */
	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	public Condition(String field, String operator, Object value) {
		this(field, operator, value, "string");
	}

	public Condition(String field, String operator, Object value, String dataType) {
		this.field = field;
		this.operator = operator;
		this.value = value;
		this.dataType = dataType;
		this.aliasName = field;
	}

	public Condition(String field, String operator, Object value, String dataType,String aliasName) {
		this.field = field;
		this.operator = operator;
		this.value = value;
		this.dataType = dataType;
		this.aliasName = aliasName;
	}
	
	public String getField() {
		return this.field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String getOperator() {
		return this.operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public Object getValue() {
		return this.value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	public String getDataType() {
		return this.dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getSqlClause() {
		if ((getField() == null) || (getField().length() == 0) || (this.operator == null)
				|| (this.operator.length() == 0) || (this.value == null))
			return "";
		String clause = null;
		if ("is".equals(this.operator))
			clause = getField() + " is " + getValue();
		else if ("in".equals(this.operator))
			clause = getField() + " in " + getValue();
		else if ("like".equals(this.operator)){
			if(!this.dataType.equals("String"))
			//clause = getField() + " like " + " '%' || ? || '%' "; //for oracle
			clause = getField() + " like " + " '%' +convert(varchar,?)+ '%' "; //for mssql
			else {
				clause = getField() + " like " + " '%'+?+'%' "; //for mssql
			}
		}
			
		else if ("or".equals(this.operator))
			clause = (String) getValue();
		else
			clause = getField() + " " + getOperator() + " ?";
		return clause;
	}

	public Integer getSqlDataType() {
		if ((getField() == null) || (getField().length() == 0) || (this.operator == null)
				|| (this.operator.length() == 0) || (this.value == null))
			return null;
		if ("is".equals(this.operator))
			return null;
		if ("in".equals(this.operator))
			return null;
		if ("or".equals(this.operator))
			return null;
		if ("string".equals(this.dataType))
			return new Integer(12);
		if ("long".equals(this.dataType))
			return new Integer(-5);
		if ("date".equals(this.dataType))
			return new Integer(91);
		if ("datetime".equals(this.dataType)) {
			return new Integer(91);
		}
		return null;
	}

	public Object getSqlValue() {
		if ((getField() == null) || (getField().length() == 0) || (this.operator == null)
				|| (this.operator.length() == 0) || (this.value == null))
			return null;
		if ("is".equals(this.operator))
			return null;
		if ("in".equals(this.operator))
			return null;
		if ("or".equals(this.operator))
			return null;
		return this.value;
	}
}
