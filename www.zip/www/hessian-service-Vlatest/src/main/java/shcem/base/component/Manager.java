/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: Manager
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.base.component;

import java.io.Serializable;
import java.util.List;

import shcem.base.dao.DAO;

/**
 * Manager
 * @author chiyong
 * @version 1.0
 */
public abstract interface Manager
{
  public abstract void setDAO(DAO paramDAO);

  public abstract List getObjects(Class paramClass);

  public abstract Object getObject(Class paramClass, Serializable paramSerializable);

  public abstract void saveObject(Object paramObject);

  public abstract void removeObject(Class paramClass, Serializable paramSerializable);
}
