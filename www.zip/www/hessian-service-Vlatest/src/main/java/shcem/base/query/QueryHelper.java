/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: QueryHelper
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.base.query;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.web.util.WebUtils;

import shcem.base.exception.BaseException;

/**
 * QueryHelper
 * 
 * @author chiyong
 * @version 1.0
 */
public class QueryHelper {

	private static final transient Log logger = LogFactory.getLog(QueryHelper.class);

	public static QueryConditions getQueryConditionsFromRequest(HttpServletRequest request) {
		logger.debug("enter getQueryConditionsFromReq...");

		QueryConditions qc = null;
		Map<String, Object> keys = WebUtils.getParametersStartingWith(request, "_");
		Map keysForAttribute = getAttributeStartingWith(request, "_");
		keys.putAll(keysForAttribute);
		qc = getQueryConditionsForMap(keys);

		return qc;
	}

	public static QueryConditions createQueryConditionsFromRequest(HttpServletRequest request) {
		QueryConditions qc = getQueryConditionsFromRequest(request);
		if (qc == null) {
			qc = new QueryConditions();
		}
		return qc;
	}

	public static PageInfo getPageInfoFromRequest(HttpServletRequest request) {
		logger.debug("enter getPageInfoFromRequest...");

		PageInfo pageInfo = null;

		String pageSizeForString = request.getParameter("pageSize");
		if (pageSizeForString == null) {
			pageSizeForString = (String) request.getAttribute("pageSize");
		}
		int pageSize = Utils.parseInt(pageSizeForString);

		String pageNoForString = request.getParameter("pageNo");
		if (pageNoForString == null) {
			pageNoForString = (String) request.getAttribute("pageNo");
		}
		int pageNo = Utils.parseInt(pageNoForString, 1);
		if (pageSize > 0) {
			pageInfo = new PageInfo();

			pageInfo.setPageSize(pageSize);
			pageInfo.setPageNo(pageNo);

			String[] orderFields = request.getParameterValues("orderField");
			if (orderFields == null) {
				orderFields = (String[]) request.getAttribute("orderField");
				logger.debug("orderFields:" + orderFields);
			}
			String[] orderTypes = request.getParameterValues("orderDesc");
			if (orderTypes == null) {
				orderTypes = (String[]) request.getAttribute("orderDesc");
			}
			if ((orderFields != null) && (orderTypes != null)) {
				for (int i = 0; i < orderFields.length; i++) {
					logger.debug("orderField " + i + "=" + orderFields[i]);
					logger.debug("orderDesc " + i + "=" + orderTypes[i]);
					String orderField = orderFields[i];
					boolean orderDesc = Utils.parseBoolean(orderTypes[i]);
					pageInfo.addOrderField(orderField, orderDesc);
				}
			} else {
				String orderField = request.getParameter("orderField");
				String orderType = request.getParameter("orderDesc");
				logger.debug("orderField =" + orderField);
				logger.debug("orderDesc =" + orderType);
				if ((orderField != null) && (orderField.length() > 0)) {
					boolean orderDesc = Utils.parseBoolean(orderType);
					pageInfo.addOrderField(orderField, orderDesc);
				} else {
					return null;
				}
			}
			logger.debug("pageInfo: pageNo = " + pageInfo.getPageNo() + ", pageSize = " + pageInfo.getPageSize());
		}
		return pageInfo;
	}

	public static PageInfo getPageInfoFromJsonReq(JSONObject reqJson) {
		logger.debug("enter getPageInfoFromRequest...");

		PageInfo pageInfo = null;

		int pageSizeForString = 0;
		if (!reqJson.isNull("pageSize")) {
			try {
				pageSizeForString = reqJson.getInt("pageSize");
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		int pageSize = pageSizeForString;

		int pageNoForString = 0;
		if (!reqJson.isNull("pageNo")) {
			pageNoForString = reqJson.getInt("pageNo");
		}
		int pageNo = pageNoForString;
//		if (pageSize > 0) {
			pageInfo = new PageInfo();

			pageInfo.setPageSize(pageSize);
			pageInfo.setPageNo(pageNo);

			JSONArray orderFields = null;
			if (!reqJson.isNull("orderFields")) {
				orderFields = reqJson.getJSONArray("orderFields");
			}

			if (orderFields != null && orderFields.length() > 0) {
				for (int i = 0; i < orderFields.length(); i++) {
					JSONObject jo = (JSONObject) orderFields.get(i);
					if (jo.isNull("orderBy")) {
						continue;
					}
					if (jo.isNull("orderDesc")) {
						continue;
					}
					String orderField = jo.getString("orderBy");
					boolean orderDesc = jo.getBoolean("orderDesc");
					pageInfo.addOrderField(orderField, orderDesc);
				}
				logger.debug("pageInfo: pageNo = " + pageInfo.getPageNo() + ", pageSize = " + pageInfo.getPageSize());
			}
//		}
		return pageInfo;
	}

	public static String getTargetView(HttpServletRequest request, String defaultTarget) {
		String target = request.getParameter("targetView");
		if ((target == null) || (target.length() == 0))
			target = defaultTarget;
		return target;
	}

	public static Map<String, String> getAttributeStartingWith(ServletRequest request, String prefix) {
		Enumeration paramNames = request.getAttributeNames();
		Map<String, String> params = new TreeMap<String, String>();
		if (prefix == null) {
			prefix = "";
		}
		while ((paramNames != null) && (paramNames.hasMoreElements())) {
			String paramName = (String) paramNames.nextElement();

			if (("".equals(prefix)) || (paramName.startsWith(prefix))) {
				String unprefixed = paramName.substring(prefix.length());
				String value = (String) request.getAttribute(paramName);
				if (value != null) {
					params.put(unprefixed, value);
				}
			}
		}

		return params;
	}

	/**
	 * 
	 * @param jO
	 *            传入的查询条件json对象
	 * @param includeQc
	 *            此方法接收的查询字段及类型 操作。
	 * @param prefix
	 *            查询是否有统一前缀 如：sid 默认为“”
	 * @return
	 * @author wlpod
	 */
	public static QueryConditions getQueryConditionsFromJson(JSONObject jO, List<Condition> includeQc, String prefix) {
		QueryConditions qc = new QueryConditions();
		if (prefix == null) {
			prefix = "";
		}
		if (jO == null)
			return qc;
		for (int i = 0; i < includeQc.size(); i++) {
			Condition iQ = (Condition) includeQc.get(i);
			String paramName = iQ.getField();
			if (iQ.getAliasName() != null) {
				paramName = iQ.getAliasName();
			}
			String prefixedParam = prefix + paramName;
			if (!jO.isNull(prefixedParam)) {
				if (("".equals(prefix)) || (paramName.startsWith(prefix))) {
					if (!"".equals(jO.get(prefixedParam))) {
						qc.addCondition(iQ.getField(), iQ.getOperator(), jO.get(prefixedParam), iQ.getDataType());
					}
				}
			}
		}
		return qc;
	}

	public static QueryConditions getQueryConditionsForMap(Map keys) {
		QueryConditions qc = null;
		if ((keys != null) && (keys.size() > 0)) {
			logger.debug("parameter size:" + keys.size());

			Pattern pOperatorDatatype = Pattern.compile("(.+?)\\[(.+)]\\[(.+)]");

			Pattern pOperator = Pattern.compile("(.+?)\\[(.+)]");

			for (Iterator it = keys.keySet().iterator(); it.hasNext();) {
				String key = (String) it.next();
				Object value = keys.get(key);
				logger.debug("parameter:" + key);
				Matcher m = pOperatorDatatype.matcher(key);
				String type;
				String param;
				String op;
				if (m.matches()) {
					param = m.group(1);
					op = m.group(2);
					type = m.group(3);
				} else {
					m = pOperator.matcher(key);
					if (m.matches()) {
						param = m.group(1);
						op = m.group(2);
						type = null;
					} else {
						param = null;
						op = null;
						type = null;
					}
				}

				if ((param != null) && (value != null) && (((String) value).length() > 0)) {
					if (qc == null) {
						qc = new QueryConditions();
					}
					if (type != null) {
						try {
							value = Utils.convert(value, type);
						} catch (BaseException be) {
							logger.error("Utils.convert() failed!");
						}
					}
					logger.debug("parameter:" + param);
					logger.debug("operator:" + op);
					logger.debug("datatype:" + type);
					logger.debug("value:" + value);
					qc.addCondition(param, op, value);
				}
			}
		}
		return qc;
	}

	public static QueryConditions getQueryConditionsFromRequestAttribute(HttpServletRequest request, String prefix) {
		Map<String, String> map = getAttributeStartingWith(request, prefix);
		QueryConditions qc = getQueryConditionsForMap(map);
		return qc;
	}

	public static Map<String, Object> getMapFromRequest(HttpServletRequest request) {
		logger.debug("enter getQueryConditionsFromReq...");

		Map<String, Object> keys = WebUtils.getParametersStartingWith(request, "_");
		Map<String, String> keysForAttribute = getAttributeStartingWith(request, "_");
		keys.putAll(keysForAttribute);

		return keys;
	}
}
