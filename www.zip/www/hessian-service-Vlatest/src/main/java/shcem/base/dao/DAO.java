/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: DAO
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.base.dao;

import java.io.Serializable;
import java.util.List;

/**
 * DAO
 * @author chiyong
 * @version 1.0
 */
public abstract interface DAO {
	
	public abstract List getObjects(Class paramClass);

	public abstract Object getObject(Class paramClass, Serializable paramSerializable);

	public abstract void saveObject(Object paramObject);

	public abstract void removeObject(Class paramClass, Serializable paramSerializable);
}
