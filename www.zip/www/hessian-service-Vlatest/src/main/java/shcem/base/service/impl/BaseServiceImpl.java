/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: BaseServiceImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.base.service.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import netty.NettyClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import shcem.base.service.model.Header;
import shcem.base.service.model.ResponseData;
import shcem.constant.Constants;
import shcem.constant.ResultCode;
import shcem.constant.ResultInfo;
import shcem.finance.dao.model.FBanks;
import shcem.hessian.HessianHeaderContext;
import shcem.log.component.LogManager;
import shcem.log.service.ILogService;
import shcem.log.service.impl.LogServiceImpl;
import shcem.log.util.LogSysData;
import shcem.util.JsonUtil;
import shcem.util.PropertyUtil;

/**
 * BaseServiceImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class BaseServiceImpl {

	protected ResponseData rtnData = new ResponseData();

	protected final ILogService log = new LogServiceImpl("Servicelog");

	private LogManager logMgr = (LogManager) LogSysData.getBean(Constants.BEAN_LOG_MGR);
	private String logdif = "";
	private Header header = null;

	/**
	 * 设定ResultData
	 * 
	 * @param code
	 *            code字符： 00000， 10001
	 * @param data
	 *            返回数据对象
	 * @param args
	 *            可变追加信息
	 */
	protected void setResultData(String code, Object data, String... args) {

		ResultCode rstCd = Enum.valueOf(ResultCode.class, "CODE" + code);
		ResultInfo rstInfo = Enum.valueOf(ResultInfo.class, "CODE" + code);
		StringBuffer sbInfo = new StringBuffer(args.length + 1);

		sbInfo.append(rstInfo.getValue());
		for (int i = 0; i < args.length; i++) {
			sbInfo.append(args[i]);
		}

		this.rtnData.setCODE(rstCd.getValue());
		this.rtnData.setINFO(sbInfo.toString());

		if (data == null) {
			this.rtnData.setDATA(null);
		} else if (data instanceof JSONObject || data instanceof JSONArray) {
			this.rtnData.setDATA(data.toString());
		} else if (data instanceof List) {
			JSONArray retData;
			try {
				retData = JsonUtil.coverModelToJSONArray((List) data);
				this.rtnData.setDATA(retData.toString());
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				this.rtnData.setCODE(ResultCode.CODE10103.getValue());
				this.rtnData.setINFO(ResultInfo.CODE10103.getValue());
			}
		} else if (data instanceof String) {
			this.rtnData.setDATA((String) data);
		} else if (data instanceof Map) {
			JSONObject retData;
			try {
				retData = new JSONObject((Map) data);
				this.rtnData.setDATA(retData.toString());
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				this.rtnData.setCODE(ResultCode.CODE10103.getValue());
				this.rtnData.setINFO(ResultInfo.CODE10103.getValue());
			}
		} else if (data instanceof Object) {
			JSONObject retData;
			try {
				retData = JsonUtil.coverModelToJSONObject(data);
				this.rtnData.setDATA(retData.toString());
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				this.rtnData.setCODE(ResultCode.CODE10103.getValue());
				this.rtnData.setINFO(ResultInfo.CODE10103.getValue());
			}
		}
	}

	/**
	 * 校验Bean
	 * 
	 * @param ob
	 * @return ��һ��error��Ϣ 校验对象
	 * @return 第一个error信息
	 */
	protected String validateBean(Object ob) {
		/**
		 * @Null 验证对象是否为空
		 * @NotNull 验证对象是否为非空
		 * @AssertTrue 验证 Boolean 对象是否为 true
		 * @AssertFalse 验证 Boolean 对象是否为 false
		 * @Min 验证 Number 和 String 对象是否大等于指定的值
		 * @Max 验证 Number 和 String 对象是否小等于指定的值
		 * @DecimalMin 验证 Number 和 String 对象是否大等于指定的值，小数存在精度
		 * @DecimalMax 验证 Number 和 String 对象是否小等于指定的值，小数存在精度
		 * @Size 验证对象（Array,Collection,Map,String）长度是否在给定的范围之内
		 * @Digits 验证 Number 和 String 的构成是否合法
		 * @Past 验证 Date 和 Calendar 对象是否在当前时间之前
		 * @Future 验证 Date 和 Calendar 对象是否在当前时间之后
		 * @Pattern 验证 String 对象是否符合正则表达式的规则
		 */
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		String strRst = null;

		Set<ConstraintViolation<Object>> constraintViolations = validator.validate(ob);

		for (ConstraintViolation<Object> constraintViolation : constraintViolations) {
			strRst = constraintViolation.getMessage();
			// 检索到第一条错误信息则直接返回
			break;
		}

		return strRst;
	}

	public static void main(String[] args) {
		FBanks fb = new FBanks();
		fb.setBankID("我是我");
		fb.setBankName("name");
		fb.setBeginTime("begintie");
		fb.setControl(new Integer(10));
		fb.setEndTime("endtime");
		fb.setMaxAuditMoney(new BigDecimal(11.23).setScale(2, BigDecimal.ROUND_HALF_UP));
		fb.setMaxPerSglTransMoney(new BigDecimal(12.34).setScale(2, BigDecimal.ROUND_HALF_UP));
		fb.setMaxPerTransCount(new Integer(13));
		fb.setMaxPerTransMoney(new BigDecimal(14.56).setScale(2, BigDecimal.ROUND_HALF_UP));
		fb.setValidFlag(new Integer(2));

		BaseServiceImpl v = new BaseServiceImpl();
		System.err.println(v.validateBean(fb));

	}

	public String getFirmList(String params) {
		// TODO Auto-generated method stub
		return null;
	}

	protected String getUserId() {
		HessianHeaderContext context = HessianHeaderContext.getContext();
		String userid = context.getHeader(Constants.HEADER_MEM_ID) == null ? "" : context.getHeader(Constants.HEADER_MEM_ID);
		this.log.debug("Got Userid From Hessian Header:" + userid);
		return userid;
	}

	protected String getUserName() {
		// 使用 getUserId()，为了避免改代码中的 getUserName 方法
//		HessianHeaderContext context = HessianHeaderContext.getContext();
//		return context.getHeader(Constants.HEADER_MEM_NAME) == null ? "" : context.getHeader(Constants.HEADER_MEM_NAME);
		return getUserId();
	}

	protected String getMode() {
		String mode = Constants.MODE_LOCAL;
		String sysMode = System.getProperty(Constants.HEADER_MODE);

		if (sysMode != null && !sysMode.isEmpty()) {
			if (Constants.MODE_LOCAL.equals(sysMode)
					|| Constants.MODE_DEV.equals(sysMode)
					|| Constants.MODE_TEST.equals(sysMode)
					|| Constants.MODE_UAT.equals(sysMode)
					|| Constants.MODE_DEPLOY.equals(sysMode)) {
				mode = sysMode;
			}
		}

		return mode;
	}
	
	protected String getRequestId() {
		HessianHeaderContext context = HessianHeaderContext.getContext();
		return context.getHeader(Constants.HEADER_REQUESTID) == null ? "" : context.getHeader(Constants.HEADER_REQUESTID);
	}

	private void setHeader() {
		HessianHeaderContext context = HessianHeaderContext.getContext();
		this.header = new Header(context);
	}

	/**
	 * 调用Activiti的API
	 * 
	 * @param postData
	 * @return
	 */
	protected JSONObject postActivitiApi(String postData) {

		PropertyUtil propUtil = new PropertyUtil();
		Properties clientProperty = propUtil.getProperties(Constants.ACTIVITI_PROPERITES_FILE);

		// 取得中央代理服务器的信息
		String ipaddress = clientProperty.getProperty(getMode() + "_activitiapi_IP");
		String strPort = clientProperty.getProperty("activitiapi_port");
		
		int port;
		try {
			port = Integer.parseInt(strPort);
		} catch (NumberFormatException e1) {
			// default port;
			port = 5420;
		}

		/**
		 * 取得数据 Start
		 */
		NettyClient ntc = new NettyClient(ipaddress, port, postData,"/activitiapi","");
		String response = null;
		try {
			Map<String, String> m = ntc.httpPost();
			response = m.get("response");
		} catch (Exception e) {
			return setReturnData("10116", e.getMessage());
		}
		/**
		 * 取得数据 End
		 */

		// 数据转换成JSON对象
		JSONObject jsoSource;
		try {
			jsoSource = new JSONObject(response);
		} catch (JSONException e) {
			return setReturnData("10116", e.getMessage());
		}

		return jsoSource;
	}

	/**
	 * 
	 * 
	 * @param endpoint
	 * @param differ
	 * @return
	 */
	private JSONObject setReturnData(String code, String... msg) {

		JSONObject result = new JSONObject();

		ResultCode rstCd = Enum.valueOf(ResultCode.class, "CODE" + code);
		ResultInfo rstInfo = Enum.valueOf(ResultInfo.class, "CODE" + code);

		StringBuffer sbInfo = new StringBuffer(msg.length + 1);

		sbInfo.append(rstInfo.getValue());
		for (int i = 0; i < msg.length; i++) {
			sbInfo.append(msg[i]);
		}

		result.put("CODE", rstCd.getValue());
		result.put("INFO", sbInfo.toString());
		result.put("DATA", "none");

		HessianHeaderContext.close();

		return result;
	}
}