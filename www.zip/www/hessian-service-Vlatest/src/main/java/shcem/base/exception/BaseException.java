/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: BaseException
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.base.exception;

/**
 * BaseException
 * @author chiyong
 * @version 1.0
 */
public class BaseException extends Exception {
	private static final long serialVersionUID = 1L;
	private int errorCode;
	private Object[] params;

	public BaseException(int errorCode, Object[] params) {
		this.errorCode = errorCode;
		this.params = params;
	}

	public int getErrorCode() {
		return this.errorCode;
	}

	public Object[] getParams() {
		return this.params;
	}
}
