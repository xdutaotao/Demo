/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: BaseServiceObject
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.base.service.model;

import java.io.Serializable;

import org.json.JSONObject;

/**
 * model
 * 
 * @author chiyong
 * @version 1.0
 */
public abstract class BaseServiceObject implements Serializable {

	private static final long serialVersionUID = 8079884919320419004L;

	public abstract String toString();

	public abstract JSONObject toJSONObject();

	public abstract boolean equals(Object o);

	public abstract int hashCode();
}
