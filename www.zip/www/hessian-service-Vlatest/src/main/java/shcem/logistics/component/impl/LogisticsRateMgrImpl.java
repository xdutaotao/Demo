package shcem.logistics.component.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.service.model.ValueTxtView;
import shcem.logistics.component.ILogisticsRateMgr;
import shcem.logistics.dao.ILogisticsRateDao;
import shcem.logistics.dao.model.CheckMessage;
import shcem.logistics.dao.model.LogisticsArea;
import shcem.logistics.dao.model.LogisticsRate;
import shcem.logistics.dao.model.LogisticsTemplatePrice;
import shcem.util.ImportHttpExecl;

public class LogisticsRateMgrImpl extends BaseManager implements
		ILogisticsRateMgr {
	
	private ILogisticsRateDao logisticsRateDao;
	
	private ILogisticsRateDao logisticsRateDao_read;
	
	
	public void setLogisticsRateDao_read(ILogisticsRateDao logisticsRateDao_read) {
		this.logisticsRateDao_read = logisticsRateDao_read;
	}


	public void setLogisticsRateDao(ILogisticsRateDao logisticsRateDao) {
		this.logisticsRateDao = logisticsRateDao;
	}
	

	@Override
	public List<LogisticsRate> getLogisticsRateCategoryList(
			QueryConditions qc, PageInfo pageInfo) {
		List<LogisticsRate> list = this.logisticsRateDao_read.getLogisticsRateCategoryList(qc,pageInfo);
		return list;
	}
	
	@Override
	public int addLogisticsRate(LogisticsRate logisticsRate, String userName) {
		this.log.info(this.getClass().getName()+" addLogisticsRate Start");
		int returnCode;
		
		/*新增：物流配送费率  T_LogisticsRate*/
		/***
		 * 验证  "产品分类"+"产品牌号" 不能重复
		 */
		int templateID = this.disRepeat(logisticsRate.getTemplateName()); 
		//该  "产品分类"+"产品牌号"  没有新增过
		if(templateID == -1){
			templateID = this.logisticsRateDao.addLogisticsRate(logisticsRate,userName);
			if(templateID == -1)return -1;
		}else {
			templateID = this.logisticsRateDao.getLogisticsTemplate(logisticsRate.getTemplateBigName(),logisticsRate.getTemplateName());
			if(templateID == -1)return -4;
		}
		/*新增：物流配送费率产品分类  T_LogisticsRateCategory*/
		int LogisticsRateCategoryCount = this.logisticsRateDao.getLogisticsRateCategoryCount(logisticsRate.getCategoryLeafID(),
				logisticsRate.getBrandID(),logisticsRate.getSourcePlaceID());
		if(LogisticsRateCategoryCount == 0){
			returnCode = this.logisticsRateDao.addLogisticsRateCategory(templateID,logisticsRate,userName);
			if(returnCode == -1){
				this.logisticsRateDao.rollBack();
				return returnCode;
			}
		}else {
			this.logisticsRateDao.rollBack();
			return -3;
		}
		this.log.info(this.getClass().getName()+" addLogisticsRate End");
		return returnCode;
	}
	
	/**
	 * 验证  "产品分类"+"产品牌号" 不能重复
	 */
	@Override
	public int disRepeat(String rateDetailName) {
		this.log.info(this.getClass().getName()+" disRepeat Start");
		LogisticsRate logisticsRate = this.logisticsRateDao_read.getLogisticsRate(rateDetailName);
		if(logisticsRate != null){
			return logisticsRate.getId();
		}else {
			return -1;
		}
	}
	
	@Override
	public List<ValueTxtView> getBrandList(String brandName) {
		List<ValueTxtView> list = this.logisticsRateDao_read.getBrandList(brandName);
		return list;
	}
	
	@Override
	public List<ValueTxtView> getSourcePlaceListByBrandID(int brandID) {
		List<ValueTxtView> list = this.logisticsRateDao_read.getSourcePlaceListByBrandID(brandID);
		return list;
	}
	
	@Override
	public int updateLogisticsRate(LogisticsRate logisticsRate, String userName) {
		int returnCode =0;
		return returnCode;
	}
	
	@Override
	public int deleteLogisticsRateCategory(int[] logisticsRateCategoryIDArray) {
		int returnCode;
		String logisticsRateCategoryIDs ="";
		if(logisticsRateCategoryIDArray != null && logisticsRateCategoryIDArray.length > 0){
			for (int i = 0; i < logisticsRateCategoryIDArray.length; i++) {
				if(i > 0)logisticsRateCategoryIDs +=",";
				logisticsRateCategoryIDs += logisticsRateCategoryIDArray[i];
			}
		}
		returnCode = this.logisticsRateDao.deleteLogisticsRateCategory(logisticsRateCategoryIDs);
		return returnCode;
	}
	
	/**
	 * 导入 费率细分
	 */
	@Override
	public int importLogisticsRate(List<LogisticsRate> list, String userName) {
		int returnCode = 0;
		for (int i = 0; i <list.size(); i++) {
			returnCode = this.addImportLogisticsRate(list.get(i),userName);
			if(returnCode < 0)break;
		}
		return returnCode;
	}
	
	/**
	 * 导入 配送区域
	 */
	@Override
	public int importLogisticsArea(List<LogisticsArea> list, String userName) {
		int returnCode = 0;
		for (int i = 0; i <list.size(); i++) {
			returnCode = this.addimportLogisticsArea(list.get(i),userName);
			if(returnCode < 0)break;
		}
		return returnCode;
	}
	
	
	
	@Override
	public List<LogisticsArea> getLogisticsAreaList(QueryConditions qc,
			PageInfo pageInfo) {
		List<LogisticsArea> list = this.logisticsRateDao_read.getLogisticsAreaList(qc,pageInfo); 
		return list;
	}

	
	
	
	@Override
	public CheckMessage checkLogisticsPriceTemplate(String filePath) {
		this.log.debug("readLogisticsAreaToList() Start");
		CheckMessage checkMessage = new CheckMessage();
		checkMessage.setImportBoolean(false);
		int successCount = 0;
		String message ="";
		List<LogisticsTemplatePrice> rtnLst = new ArrayList<LogisticsTemplatePrice>();
		LogisticsTemplatePrice detail = null;
		ImportHttpExecl ihe = new ImportHttpExecl();
		int sheetNo=0;

		// 读取Excel2007
        List<List<String>> list = ihe.read(filePath,sheetNo,true);
 
        String err = ihe.getErrorInfo();
        if (null != err && !err.isEmpty()) {
        	// Excel2007失败，再次尝试读取Excel2003
        	ihe = new ImportHttpExecl();
        	list = ihe.read(filePath,sheetNo,false);
        }
        err = null;
        err = ihe.getErrorInfo();
        if (null != err && !err.isEmpty()) {
        	this.log.error(err);
        	checkMessage.setMessage("物流配送运费'模板实体类设定失败");
			return checkMessage;
        }
        for (int i = 2; i < list.size(); i++) {
        	detail = new LogisticsTemplatePrice();
        	List<String> cellList = new ArrayList<String>();
            cellList = list.get(i);  
            try {
				if (cellList != null && cellList.size() > 0) {
					detail.setLogistics(true);
					
					/*流水号*/
					String excelTemplateNum = cellList.get(0);
					
					/*费率大类*/
					String templateBigName = cellList.get(1);
					if(!this.judgeIsNull(templateBigName)){
						message += "流水号【"+excelTemplateNum+"】记录，费率大类为空  ^^ ";
						detail.setLogistics(false);
					}
					
					List<LogisticsRate>  logisticsRateList = this.logisticsRateDao_read.getLogisticsRateByTemplateBigName(templateBigName);
					if(logisticsRateList == null){
						message += "流水号【"+excelTemplateNum+"】记录,库中不存在该费率大类 【"+templateBigName+"】 ^^ ";
						detail.setLogistics(false);
					}
					detail.setTemplateBigName(templateBigName);
					
					
					/*产品(费率细分)*/
					String templateName = cellList.get(2);
					if(!this.judgeIsNull(templateName)){
						message += "流水号【"+excelTemplateNum+"】记录，费率细分为空 ^^ ";
						detail.setLogistics(false);
					}
					LogisticsRate logisticsRate = this.logisticsRateDao_read.getLogisticsRate(templateName);
					if(logisticsRate == null){
						message += "流水号【"+excelTemplateNum+"】记录，库中不存在该费率细分 【"+templateName+"】  ^^ ";
						detail.setLogistics(false);
					}
					
					/*组合校验：费率大类+产品(费率细分)*/
					logisticsRate = this.logisticsRateDao_read.getlogisticsRateBytemplateBigNameAndtemplateName(templateBigName,templateName);
					if(logisticsRate == null){
						message += "流水号【"+excelTemplateNum+"】记录，库中不存在该费率大类+产品(费率细分) 为 【  "+templateBigName+"-"+templateName+"】 的组合  ^^ ";
						detail.setLogistics(false);
					}
					detail.setTemplateName(templateName);
					
					
					/*目的地区域代码*/
					String endAreaNo = cellList.get(3);
					if(!this.judgeIsNull(endAreaNo)){
						message += "流水号【"+endAreaNo+"】记录，区域代码为空 ^^ ";
						detail.setLogistics(false);
					}
					LogisticsArea logisticsArea = this.logisticsRateDao_read.getLogisticsAreaByAreaNo(endAreaNo);
					if(logisticsArea == null){
						message += "流水号【"+excelTemplateNum+"】记录，库中不存在该区域，区域代码为 【  "+endAreaNo+"】 ^^ ";
						detail.setLogistics(false);
					}
					detail.setEndAreaNo(endAreaNo);
					
					
					/*区域名称*/
					String endAreaName = cellList.get(4);
					if(!this.judgeIsNull(endAreaName)){
						message += "流水号【"+excelTemplateNum+"】记录，区域名称为空 ^^ ";
						detail.setLogistics(false);
					}
					/*组合校验：区域代码+区域名称*/
					logisticsArea = this.logisticsRateDao_read.getLogisticsAreaByAreaNoAndName(endAreaNo,endAreaName);
					if(logisticsArea == null){
						message += "流水号【"+excelTemplateNum+"】记录，库中不存在该区域代码+区域名称 为 【  "+endAreaNo+"-"+endAreaName+"】 的组合  ^^ ";
						detail.setLogistics(false);
					}
					detail.setEndAreaName(endAreaName);
					
					/*运费(元/吨)*/
					String price = cellList.get(5);
					if(!this.judgeIsNull(price)){
						message += "流水号【"+excelTemplateNum+"】记录，价格为空 ^^ ";
						detail.setLogistics(false);
					};
					detail.setPrice(new BigDecimal(price));
					rtnLst.add(detail);
					if(detail.isLogistics())
						successCount++;
				}else {
					checkMessage.setMessage("逗逼，模板中没有数据！");
					checkMessage.setImportBoolean(false);
					return checkMessage;
				}
			} catch (Exception e) {
				this.log.error("'物流配送运费'模板实体类设定失败");
				e.printStackTrace();
				checkMessage.setMessage("'物流配送运费'模板实体类设定失败");
				checkMessage.setImportBoolean(false);
				return checkMessage;
			}
            
		}
		this.log.debug("readLogisticsAreaToList() End");
		String messageTemp = "共"+successCount+"条可成功导入 ^^ "+message;
		checkMessage.setMessage(messageTemp);
		if(successCount > 0)checkMessage.setImportBoolean(true);
		return checkMessage;
	}
	
	@Override
	public List<LogisticsTemplatePrice> readLogisticsTemplatePriceToList(
			String filePath) {
		this.log.debug("readLogisticsTemplatePriceToList() Start");
		List<LogisticsTemplatePrice> rtnLst = new ArrayList<LogisticsTemplatePrice>();
		LogisticsTemplatePrice detail = null;
		ImportHttpExecl ihe = new ImportHttpExecl();
		int sheetNo=0;

		// 读取Excel2007
        List<List<String>> list = ihe.read(filePath,sheetNo,true);
 
        String err = ihe.getErrorInfo();
        if (null != err && !err.isEmpty()) {
        	// Excel2007失败，再次尝试读取Excel2003
        	ihe = new ImportHttpExecl();
        	list = ihe.read(filePath,sheetNo,false);
        }
        err = null;
        err = ihe.getErrorInfo();
        if (null != err && !err.isEmpty()) {
        	this.log.error(err);
			return null;
        }
        for (int i = 2; i < list.size(); i++) {
        	detail = new LogisticsTemplatePrice();
        	List<String> cellList = new ArrayList<String>();
            cellList = list.get(i);  
            try {
				if (cellList != null && cellList.size() > 0) {
					detail.setLogistics(true);
					
					
					/*费率大类*/
					String templateBigName = cellList.get(1);
					if(!this.judgeIsNull(templateBigName)){
						detail.setLogistics(false);
					}
					
					List<LogisticsRate>  logisticsRateList = this.logisticsRateDao.getLogisticsRateByTemplateBigName(templateBigName);
					if(logisticsRateList == null){
						detail.setLogistics(false);
					}
					detail.setTemplateBigName(templateBigName);
					
					
					/*产品(费率细分)*/
					String templateName = cellList.get(2);
					if(!this.judgeIsNull(templateName)){
						detail.setLogistics(false);
					}
					LogisticsRate logisticsRate = this.logisticsRateDao.getLogisticsRate(templateName);
					if(logisticsRate == null){
						detail.setLogistics(false);
					}
					
					/*组合校验：费率大类+产品(费率细分)*/
					logisticsRate = this.logisticsRateDao.getlogisticsRateBytemplateBigNameAndtemplateName(templateBigName,templateName);
					if(logisticsRate == null){
						detail.setLogistics(false);
					}
					detail.setTemplateName(templateName);
					
					
					/*目的地区域代码*/
					String endAreaNo = cellList.get(3);
					if(!this.judgeIsNull(endAreaNo)){
						detail.setLogistics(false);
					}
					LogisticsArea logisticsArea = this.logisticsRateDao.getLogisticsAreaByAreaNo(endAreaNo);
					if(logisticsArea == null){
						detail.setLogistics(false);
					}
					detail.setEndAreaNo(endAreaNo);
					
					
					/*区域名称*/
					String endAreaName = cellList.get(4);
					if(!this.judgeIsNull(endAreaName)){
						detail.setLogistics(false);
					}
					/*组合校验：区域代码+区域名称*/
					logisticsArea = this.logisticsRateDao.getLogisticsAreaByAreaNoAndName(endAreaNo,endAreaName);
					if(logisticsArea == null){
						detail.setLogistics(false);
					}
					detail.setEndAreaName(endAreaName);
					
					/*运费(元/吨)*/
					String price = cellList.get(5);
					if(!this.judgeIsNull(price)){
						detail.setLogistics(false);
					};
					detail.setPrice(new BigDecimal(price));
					
					
					
//					/*费率大类*/
//					String templateBigName = cellList.get(1);
//					if(!this.judgeIsNull(templateBigName)){
//						detail.setLogistics(false);
//					}
//					
//					List<LogisticsRate>  logisticsRateList = this.logisticsRateDao.getLogisticsRateByTemplateBigName(templateBigName);
//					if(logisticsRateList == null){
//						detail.setLogistics(false);
//					}
//					detail.setTemplateBigName(templateBigName);
//					
//					
//					/*产品(费率细分)*/
//					String templateName = cellList.get(2);
//					if(!this.judgeIsNull(templateName)){
//						detail.setLogistics(false);
//					}
//					LogisticsRate logisticsRate = this.logisticsRateDao.getLogisticsRate(templateName);
//					if(logisticsRate == null){
//						detail.setLogistics(false);
//					}
//					detail.setTemplateName(templateName);
//					
//					
//					/*目的地区域代码*/
//					String endAreaNo = cellList.get(3);
//					if(!this.judgeIsNull(endAreaNo)){
//						detail.setLogistics(false);
//					}
//					LogisticsArea logisticsArea = this.logisticsRateDao.getLogisticsAreaByAreaNo(endAreaNo);
//					if(logisticsArea == null){
//						detail.setLogistics(false);
//					}
//					detail.setEndAreaNo(endAreaNo);
//					
//					/*区域名称*/
//					String endAreaName = cellList.get(4);
//					if(!this.judgeIsNull(endAreaName)){
//						detail.setLogistics(false);
//					}
//					detail.setEndAreaName(endAreaName);
					
//					/*运费(元/吨)*/
//					String price = cellList.get(5);
//					if(!this.judgeIsNull(price));
//					detail.setPrice(new BigDecimal(price));
					
					
					
					if(detail.isLogistics()){
						rtnLst.add(detail);
					}
				}else {
					return rtnLst;
				}
			} catch (Exception e) {
				this.log.error("'物流配送运费'模板实体类设定失败");
				e.printStackTrace();
				return null;
			}
            
		}
		this.log.debug("readLogisticsTemplatePriceToList() End");
		return rtnLst;
	}
	
	@Override
	public int importLogisticsTemplatePrice(List<LogisticsTemplatePrice> list,
			String userName) {
		int returnCode = 0;
		for (int i = 0; i <list.size(); i++) {
			returnCode = this.addLogisticsTemplatePrice(list.get(i),userName);
			if(returnCode < 0)break;
		}
		return returnCode;
	}
	
	@Override
	public List<ValueTxtView> getProvinceList(String leadsID) {
		List<ValueTxtView> list = this.logisticsRateDao_read.getProvinceList(leadsID);
		return list;
	}

	@Override
	public List<ValueTxtView> getProvinceAreaList(int proviceID, String queryType,int leadsID) {
		List<ValueTxtView> list = this.logisticsRateDao_read.getProvinceAreaList(proviceID,queryType,leadsID);
		return list;
	}
	
	@Override
	public List<ValueTxtView> getCityList(int proviceAreaID, String queryType, int leadsID) {
		List<ValueTxtView> list = this.logisticsRateDao_read.getCityList(proviceAreaID,queryType,leadsID);
		return list;
	}
	
	@Override
	public List<LogisticsTemplatePrice> getLogisticsTemplatePriceList(
			QueryConditions qc, PageInfo pageInfo) {
		List<LogisticsTemplatePrice> list = this.logisticsRateDao_read.getLogisticsTemplatePriceList(qc,pageInfo);
		return list;
	}
	
	@Override
	public int deleteLogisticsTemplatePrice(long[] logisticsTemplatePriceIDs) {
		String logisticsTemplatePriceID ="";
		int returnCode = 0;
		if(logisticsTemplatePriceIDs != null && logisticsTemplatePriceIDs.length > 0){
			for (int i = 0; i < logisticsTemplatePriceIDs.length; i++) {
				if(i>0) logisticsTemplatePriceID +=",";
				logisticsTemplatePriceID += logisticsTemplatePriceIDs[i];
			}
			returnCode = this.logisticsRateDao.deleteLogisticsTemplatePrice(logisticsTemplatePriceID);
			if(returnCode == -1){
				this.logisticsRateDao.rollBack();
			}
		}
		return returnCode;
	}
	
	@Override
	public ValueTxtView getParentAreaByJuniorID(int juniorID) {
		ValueTxtView valueTxtView = this.logisticsRateDao_read.getParentAreaByJuniorID(juniorID);
		return valueTxtView;
	}
	private int addLogisticsTemplatePrice(LogisticsTemplatePrice logisticsTemplatePrice, String userName) {
		this.log.debug(this.getClass()+" addLogisticsTemplatePrice Start");
		int returnCode = 0;
		if(logisticsTemplatePrice.isLogistics()){
			/*运费模板ID	TemplateID*/
			int templateID = this.logisticsRateDao.getLogisticsTemplate(logisticsTemplatePrice.getTemplateBigName(),
					logisticsTemplatePrice.getTemplateName());
			if(templateID == -1){
				return templateID;
			}else {
				logisticsTemplatePrice.setTemplateID(templateID);
			}
			
			
			/*目的地ID*/
			int endAreaID = this.logisticsRateDao.getLogisticsAreaIDByAreaNo(logisticsTemplatePrice.getEndAreaNo()); 
			if(endAreaID == -1){
				return endAreaID;
			}else {
				/*目的地ID*/
				logisticsTemplatePrice.setEndAreaID(endAreaID);
				/*目的地名称*/
				String endAreaName = this.logisticsRateDao.getEndAreaName(endAreaID);
				if(endAreaName.equals("-1")){
					return -1;
				}else {
					logisticsTemplatePrice.setEndAreaName(endAreaName);
				}
				
				/*重复校验*/
				int logisticsTemplatePriceID = this.logisticsRateDao.getlogisticsTemplatePriceIDByTemplateIDAndendArEaID(
						templateID,endAreaID);
				
				if(logisticsTemplatePriceID == -1){
					/*新增*/
					returnCode = this.logisticsRateDao.addLogisticsTemplatePrice(logisticsTemplatePrice,userName);
					if(returnCode == -1){
						this.logisticsRateDao.rollBack();
						return returnCode;
					}
				}else {
					/*更新操作*/
					returnCode = this.logisticsRateDao.updateLogisticsTemplatePrice(logisticsTemplatePrice,userName,logisticsTemplatePriceID);
					if(returnCode == -1){
						this.logisticsRateDao.rollBack();
						return returnCode;
					}
				}
			}
			this.log.debug(this.getClass()+" addLogisticsTemplatePrice End");
		}
		return returnCode;
	}


	private int addimportLogisticsArea(LogisticsArea logisticsAreaTemp,
			String userName) {
		int returnCode;
		LogisticsArea logisticsArea = new LogisticsArea();
		logisticsArea.setAreaNo(logisticsAreaTemp.getAreaNo());
		/*物流公司ID 默认为中石化：1*/
		logisticsArea.setLogisticsID(1);
		logisticsArea.setSort(0);//排序
		
		/*省级*/
		int provinceID = this.disProvinceRepeat(logisticsAreaTemp.getProvinceName());
		
		logisticsArea.setParentID(0);//上级id
		logisticsArea.setAreaLevel(1);//区域级别（1：省 以此类推）
		logisticsArea.setIsLeaf(0);//是否叶子节点
		logisticsArea.setName(logisticsAreaTemp.getProvinceName());//区域名称
		if(provinceID == -1){
			provinceID = this.logisticsRateDao.addLogisticsArea(logisticsArea,userName);
			if(provinceID == -1) return provinceID;
			
			/*全路径Path*/ 
			String path = "|"+provinceID+"|";
			returnCode = this.logisticsRateDao.updateLogisticsAreaPath(path,userName,provinceID);
			if(returnCode == -1){
				this.logisticsRateDao.rollBack();
				return returnCode;
			}
		}else {
			String path = "|"+provinceID+"|";
			returnCode = this.logisticsRateDao.updateLogisticsArea(logisticsArea,provinceID,userName,path);
			if(returnCode == -1){
				this.logisticsRateDao.rollBack();
				return returnCode;
			}
		}
		
		/*省区(二级区域)*/
		logisticsArea.setParentID(provinceID);
		logisticsArea.setAreaLevel(2);
		logisticsArea.setIsLeaf(0);//是否叶子节点
		logisticsArea.setName(logisticsAreaTemp.getProvinceArea());//区域名称
		//是否已经存在
		int parentID_provinceAreaID = this.logisticsRateDao.getLogisticsAreaID(provinceID,2,logisticsAreaTemp.getProvinceArea());
		if(parentID_provinceAreaID == -1){
			parentID_provinceAreaID = this.logisticsRateDao.addLogisticsArea(logisticsArea,userName);
			if(parentID_provinceAreaID == -1){
				this.logisticsRateDao.rollBack();
				return parentID_provinceAreaID;
			}
			
			String path_provinceArea = "|"+provinceID+"|"+parentID_provinceAreaID+"|";
			returnCode = this.logisticsRateDao.updateLogisticsAreaPath(path_provinceArea,userName,parentID_provinceAreaID);
			if(returnCode == -1){
				this.logisticsRateDao.rollBack();
				return returnCode;
			}
		}else {
			String path_provinceArea = "|"+provinceID+"|"+parentID_provinceAreaID+"|";
			returnCode = this.logisticsRateDao.updateLogisticsArea(logisticsArea,parentID_provinceAreaID,userName,path_provinceArea);
			if(returnCode == -1){
				this.logisticsRateDao.rollBack();
				return returnCode;
			}
		}
		
		
		
		/*区域(三级区域)*/
		logisticsArea.setParentID(parentID_provinceAreaID);
		logisticsArea.setAreaLevel(3);
		logisticsArea.setIsLeaf(1);//是否叶子节点
		logisticsArea.setName(logisticsAreaTemp.getName());
//		LogisticsArea logisticsAreaTemps = this.logisticsRateDao.getLogisticsAreaByAreaNo(logisticsAreaTemp.getAreaNo());
		int areaID = this.logisticsRateDao.getLeafLogisticsAreaIDByAreaNo(parentID_provinceAreaID,3,logisticsAreaTemp.getAreaNo());
		if(areaID == -1){
			logisticsArea.setAreaNo(logisticsAreaTemp.getAreaNo());
			areaID = this.logisticsRateDao.addLogisticsArea(logisticsArea,userName);
			if(areaID == -1){
				this.logisticsRateDao.rollBack();
				return areaID;
			}
			
			String path_area =  "|"+provinceID+"|"+parentID_provinceAreaID+"|"+areaID+"|";
			returnCode = this.logisticsRateDao.updateLogisticsAreaPath(path_area,userName,areaID);
			if(returnCode == -1){
				this.logisticsRateDao.rollBack();
				return returnCode;
			}
		}else {
			logisticsArea.setAreaNo(logisticsAreaTemp.getAreaNo());
			String path_area =  "|"+provinceID+"|"+parentID_provinceAreaID+"|"+areaID+"|";
			returnCode = this.logisticsRateDao.updateLogisticsArea(logisticsArea,areaID,userName,path_area);
			if(returnCode == -1){
				this.logisticsRateDao.rollBack();
				return returnCode;
			}
		}
		return returnCode;
	}


	/**
	 * 区域：省份是否已经存在
	 * @param provinceName
	 * @return
	 */
	private int disProvinceRepeat(String provinceName) {
		LogisticsArea logisticsArea = this.logisticsRateDao.getLogisticsAreaByProvinceName(provinceName);
		if(logisticsArea != null){
			return logisticsArea.getId();
		}else {
			return -1;
		}
	}

	
	private int addImportLogisticsRate(LogisticsRate logisticsRate, String userName) {
		int returnCode;
		/*费率大类*/
		String templateBigName = logisticsRate.getTemplateBigName();
		
		/*费率细分*/
		String templateName = logisticsRate.getTemplateName();
		
		/*产地名称*/
		String sourcePlaceName = logisticsRate.getSourcePlaceName();
		
		/*分类名*/
		String categoryLeafName = logisticsRate.getCategoryLeafName();
		
		/*牌号*/
		String brandName = logisticsRate.getBrandName();
		
		/*分类ID,叶子节点*/
		int categoryLeafID = this.logisticsRateDao.getCategoryLeafID(categoryLeafName);
		if(categoryLeafID == -1){
			return -1;//库中不存在模板中的三级分类
		}
		logisticsRate.setCategoryLeafID(categoryLeafID);
		
		int brandID = this.logisticsRateDao.getBrandID(categoryLeafID,brandName);
		if(brandID == -1){
			System.err.println("陈苏华，这个分类下: 【"+categoryLeafName+"】的牌号：【"+brandName+"】不存在");
			this.log.error("陈苏华，这个分类下: 【"+categoryLeafName+"】的牌号：【"+brandName+"】不存在,或者该分类下存在多个同样的牌号");
			return -2;//库中不存在模板中的牌号
		}
		logisticsRate.setBrandID(brandID);
		
		int sourcePlaceID = this.logisticsRateDao.getSourcePlaceID(sourcePlaceName);
		if(sourcePlaceID == -1){
			return -3;//库中不存在模板中的产地
		}
		logisticsRate.setSourcePlaceID(sourcePlaceID);
		
		/*费率细分不能重复*/
		int templateID = this.disRepeat(templateName);
		if(templateID == -1){
			templateID = this.logisticsRateDao.addLogisticsRate(logisticsRate,userName);
			if(templateID == -1)return -1;
		}
		/*新增：物流配送费率产品分类  T_LogisticsRateCategory*/
		int LogisticsRateCategoryCount = this.logisticsRateDao.getLogisticsRateCategoryCount(logisticsRate.getCategoryLeafID(),
				logisticsRate.getBrandID(),logisticsRate.getSourcePlaceID());
		if(LogisticsRateCategoryCount == 0){
			returnCode = this.logisticsRateDao.addLogisticsRateCategory(templateID,logisticsRate,userName);
			if(returnCode == -1){
				this.logisticsRateDao.rollBack();
				return returnCode;
			}
		}else {
			//覆盖原来的记录
			returnCode = this.logisticsRateDao.updateLogisticsRateCategory(templateID,logisticsRate.getCategoryLeafID(),
					logisticsRate.getBrandID(),logisticsRate.getSourcePlaceID(),userName);
		}
		return returnCode;
	}
	
	
	
	/**
	 * 字符串去空
	 * @param categoryLeafName
	 * @return
	 */
	private boolean judgeIsNull(String categoryLeafName) {
		if(categoryLeafName == null ){
			return false;
		}else {
			categoryLeafName = categoryLeafName.trim(); 
			if(categoryLeafName.equals("")){
				return false;
			}else {
				return true;
			}
		}
	}
	
}
