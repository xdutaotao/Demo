package shcem.logistics.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * 物流配送区域
 * @author zhangnan
 *
 */
public class LogisticsArea extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**/
	private Integer id;
	
	/*物流公司ID*/
	private Integer logisticsID;
	
	/*区域代码*/
	private String areaNo;
	
	/*区域名称*/
	private String name;
	
	/*上级ID*/
	private Integer parentID;
	
	/*级别:区域级别（1：省 以此类推）*/
	private Integer areaLevel;
	
	/*排序*/
	private Integer sort;
	
	/*是否叶子节点 IsLeaf 默认0*/
	private Integer isLeaf;
	
	/*全路径ID*/
	private String path;
	
	/*区域表ID*/
	private Integer cantonID;
	
	/*默认为 0：显示，1：不显示*/
	private Integer dISABLED;
	
	/*创建人*/
	private String rEC_CREATEBY;

	/*创建时间*/
	private Date  rEC_CREATETIME;
	
	/*最后修改人*/
	private String rEC_MODIFYBY;
	
	/*最后时间*/
	private Date  rEC_MODIFYTIME;
	
	/*省份*/
	private String provinceName;
	
	/*省份ID*/
	private Integer provinceID;
	
	/*省区，如：江苏省A*/
	private String provinceArea;
	
	/*省区ID*/
	private Integer provinceAreaID;
	
	/*运费:单价（元/吨）*/
	private BigDecimal price;
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getLogisticsID() {
		return logisticsID;
	}

	public void setLogisticsID(Integer logisticsID) {
		this.logisticsID = logisticsID;
	}

	public String getAreaNo() {
		return areaNo;
	}

	public void setAreaNo(String areaNo) {
		this.areaNo = areaNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getParentID() {
		return parentID;
	}

	public void setParentID(Integer parentID) {
		this.parentID = parentID;
	}

	public Integer getAreaLevel() {
		return areaLevel;
	}

	public void setAreaLevel(Integer areaLevel) {
		this.areaLevel = areaLevel;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public Integer getIsLeaf() {
		return isLeaf;
	}

	public void setIsLeaf(Integer isLeaf) {
		this.isLeaf = isLeaf;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public Integer getCantonID() {
		return cantonID;
	}

	public void setCantonID(Integer cantonID) {
		this.cantonID = cantonID;
	}

	public Integer getDISABLED() {
		return dISABLED;
	}

	public void setDISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getProvinceName() {
		return provinceName;
	}

	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}

	public String getProvinceArea() {
		return provinceArea;
	}

	public void setProvinceArea(String provinceArea) {
		this.provinceArea = provinceArea;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Integer getProvinceID() {
		return provinceID;
	}

	public void setProvinceID(Integer provinceID) {
		this.provinceID = provinceID;
	}

	public Integer getProvinceAreaID() {
		return provinceAreaID;
	}

	public void setProvinceAreaID(Integer provinceAreaID) {
		this.provinceAreaID = provinceAreaID;
	}

}
