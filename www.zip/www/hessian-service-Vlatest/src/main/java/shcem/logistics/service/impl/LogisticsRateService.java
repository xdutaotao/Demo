package shcem.logistics.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.common.service.model.ValueTxtView;
import shcem.constant.Constants;
import shcem.constant.ResultCode;
import shcem.finance.util.JSONArrayUtil;
import shcem.logistics.component.ILogisticsRateMgr;
import shcem.logistics.dao.model.CheckMessage;
import shcem.logistics.dao.model.LogisticsArea;
import shcem.logistics.dao.model.LogisticsRate;
import shcem.logistics.dao.model.LogisticsTemplatePrice;
import shcem.logistics.service.ILogisticsRateService;
import shcem.trade.util.TradeSysData;
import shcem.util.ImportHttpExecl;
import shcem.util.JsonUtil;
/**
 * 交收配送:物流运费相关
 * @author zhangnan
 *
 */
public class LogisticsRateService extends BaseServiceImpl implements
		ILogisticsRateService {
	private ILogisticsRateMgr logisticsRateMgr = (ILogisticsRateMgr) TradeSysData
			.getBean(Constants.BEAN_LOGIST_MGR);

	/**
	 * 
	 */
	@Override
	public String getLogisticsRateCategoryList(String params) {
		this.log.info(this.getClass().getName()
				+ " getLogisticsRateCategoryList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<LogisticsRate> list = new ArrayList<LogisticsRate>();
		boolean bolRst = false;
		List<Condition> conditionList = new ArrayList<Condition>();
		
		conditionList.add(new Condition("temp.TemplateBigName", "like", "","String", "templateBigName"));//费率大类
		conditionList.add(new Condition("temp.TemplateName", "like", "","String", "templateName"));//费率细分
		conditionList.add(new Condition("temp.goodName", "like", "","String", "goodName"));//品类-牌号
		conditionList.add(new Condition("temp.sourcePlaceName", "like", "","String", "sourcePlaceName"));//产地

		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel,
				conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			list = this.logisticsRateMgr.getLogisticsRateCategoryList(qc,
					pageInfo);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("费率细分列表 数据查询失败："+e.getMessage());
			setResultData("10105",null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData==null?new int[0]:retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("费率细分列表 数据转换失败：" + e.getMessage());
				setResultData("10101", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName()
				+ " getLogisticsRateCategoryList() Start");
		return rtnData.toString();
	}

	/**
	 * 新增 费率细分
	 */
	@Override
	public String addLogisticsRate(String params) {
		this.log.info(this.getClass().getName() + " addLogisticsRate() Start");
		this.log.debug("addLogisticsRate Service Start debug");
		JSONObject JOParams = new JSONObject(params);

		LogisticsRate logisticsRate = (LogisticsRate) JsonUtil.jsonToBean(
				JOParams, LogisticsRate.class);
		this.log.debug(params);
		String userName = this.getUserId() == null ? "system" : (this
				.getUserId().equals("")) ? "system" : this.getUserId();
		int returnCode;
		try {
			returnCode = this.logisticsRateMgr.addLogisticsRate(logisticsRate,
					userName);
			if (returnCode >= 0) {
				this.log.businesslog("新增 费率细分 成功",
						Constants.OPE_MODE_LOGISTICS, Constants.OPE_SUCCESS);
				setResultData("00000", null);
			} else if (returnCode == -2) {
				this.log.businesslog("新增 费率细分 失败",
						Constants.OPE_MODE_LOGISTICS, Constants.OPE_FAIL);
				setResultData("50001", null);
			} else if(returnCode == -3) {
				this.log.businesslog("新增 费率细分 失败",
						Constants.OPE_MODE_LOGISTICS, Constants.OPE_FAIL);
				setResultData("50004", null);
			}else if(returnCode == -4) {
				this.log.businesslog("新增 费率细分 失败",
						Constants.OPE_MODE_LOGISTICS, Constants.OPE_FAIL);
				setResultData("50006", null);
			}else {
				this.log.businesslog("新增 费率细分 失败",
						Constants.OPE_MODE_LOGISTICS, Constants.OPE_FAIL);
				setResultData("50000", null);
			}
		} catch (Exception e) {
			this.log.error("新增 费率细分 失败:" + e.getMessage());
			setResultData("50000", null);
		}
		this.log.info(this.getClass().getName() + " addLogisticsRate() End");
		return rtnData.toString();
	}

	@Override
	public String disRepeat(String params) {
		this.log.info(this.getClass().getName() + " disRepeat() Start");
		this.log.debug("addLogisticsRate Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		/* 费率大类 */
		String rateName = JOParams.getString("rateName");
		/* 费率细分 */
		String rateDetailName = JOParams.getString("rateDetailName");
		int returnCode;
		try {
			returnCode = this.logisticsRateMgr.disRepeat(
					rateDetailName);
			if (returnCode == 2) {
				setResultData("00000", null);
			} else {
				setResultData("50001", null);
			}
		} catch (Exception e) {
			this.log.error("产品分类+产品牌号重复校验出错：" + e.getMessage());
			setResultData("10101", null);
		}
		this.log.info(this.getClass().getName() + " disRepeat() End");
		return rtnData.toString();
	}

	/**
	 * 牌号列表(支持模糊查询)
	 */
	@Override
	public String getBrandList(String params) {
		this.log.info(this.getClass().getName() + " getBrandList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<ValueTxtView> list = new ArrayList<ValueTxtView>();
		boolean bolRst = false;
		String brandName = JOParams.optString("brandName");
		try {
			list = this.logisticsRateMgr.getBrandList(brandName);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("牌号列表 查询失败：" + e.getMessage());
			setResultData("10101", null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData==null?new int[0]:retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("牌号列表 数据转换失败：" + e.getMessage());
				setResultData("10101", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getBrandList() End");
		return rtnData.toString();
	}

	/**
	 * 某个牌号关联的产地
	 */
	@Override
	public String getSourcePlaceListByBrandID(String params) {
		this.log.info(this.getClass().getName() + " getSourcePlaceListByBrandID() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<ValueTxtView> list = new ArrayList<ValueTxtView>();
		boolean bolRst = false;
		int brandID = JOParams.getInt("brandID");
		try {
			list = this.logisticsRateMgr.getSourcePlaceListByBrandID(brandID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("产地列表 查询失败：" + e.getMessage());
			setResultData("10101", null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData==null?new int[0]:retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("产地列表  数据转换失败：" + e.getMessage());
				setResultData("10101", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getSourcePlaceListByBrandID() End");
		return rtnData.toString();
	}
	
	@Override
	public String updateLogisticsRate(String params) {
		this.log.info(this.getClass().getName() + " updateLogisticsRate() Start");
		this.log.debug("addLogisticsRate Service Start debug");
		JSONObject JOParams = new JSONObject(params);

		LogisticsRate logisticsRate = (LogisticsRate) JsonUtil.jsonToBean(
				JOParams, LogisticsRate.class);
		this.log.debug(params);
		String userName = this.getUserId() == null ? "system" : (this
				.getUserId().equals("")) ? "system" : this.getUserId();
		int returnCode;
		try {
			returnCode = this.logisticsRateMgr.updateLogisticsRate(logisticsRate,
					userName);
			if (returnCode >= 0) {
				this.log.businesslog("更新 费率细分 成功",
						Constants.OPE_MODE_LOGISTICS, Constants.OPE_SUCCESS);
				setResultData("00000", null);
			} else if (returnCode == -2) {
				this.log.businesslog("新增 费率细分 失败",
						Constants.OPE_MODE_LOGISTICS, Constants.OPE_FAIL);
				setResultData("50001", null);
			} else {
				this.log.businesslog("新增 费率细分 失败",
						Constants.OPE_MODE_LOGISTICS, Constants.OPE_FAIL);
				setResultData("50000", null);
			}
		} catch (Exception e) {
			this.log.error("新增 费率细分 失败:" + e.getMessage());
			setResultData("50000", null);
		}
		this.log.info(this.getClass().getName() + " updateLogisticsRate() End");
		return rtnData.toString();
	}
	
	@Override
	public String deleteLogisticsRateCategory(String params) {
		this.log.info(this.getClass().getName() + " deleteLogisticsRateCategory() Start");
		this.log.debug("addLogisticsRate Service Start debug");
		JSONObject JOParams = new JSONObject(params);
		
		JSONArray logisticsTemplateCategoryIDArrayTemp = JOParams.getJSONArray("logisticsTemplateCategoryIDArray");
		int[] logisticsTemplateCategoryIDArray = JSONArrayUtil.getJsonToIntArray(logisticsTemplateCategoryIDArrayTemp);
		int returnCode;
		try {
			returnCode = this.logisticsRateMgr.deleteLogisticsRateCategory(logisticsTemplateCategoryIDArray);
			if(returnCode >= 0){
				setResultData("00000", null);
			}else {
				setResultData("10107", null);
			}
		} catch (Exception e) {
			this.log.error("删除 费率细分 失败"+e.getMessage());
			setResultData("10107",null);
		}
		this.log.info(this.getClass().getName() + " deleteLogisticsRateCategory() End");
		return rtnData.toString();
	}
	

	
	
	@Override
	public String checkLogisticsTemplatePrice_File(String params) {
		this.log.info(this.getClass().getName() + " checkLogisticsTemplatePrice_File() Start");
		JSONObject JOParams = new JSONObject(params);
		boolean bolRst = false;
		String url = JOParams.getString("url");
		CheckMessage checkMessage = new CheckMessage();
		checkMessage.setUrl(url);
		try {
			checkMessage  = this.logisticsRateMgr.checkLogisticsPriceTemplate(url);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("校验配送区域运费Excel失败:"+e.getMessage());
			setResultData("50005", null);
		}
		if (bolRst) {
			JSONObject retData;			
			try {
				retData = JsonUtil.coverModelToJSONObject(checkMessage);
				setResultData("00000", retData==null?new int[0]:retData);
			} catch (Exception e) {
				this.log.error("校验数据转换失败：" + e.getMessage());
				setResultData("50005", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " checkLogisticsTemplatePrice_File() End");
		return rtnData.toString();
	}

	@Override
	public String importLogisticsRate(String params) {
		this.log.info(this.getClass().getName() + " importLogisticsRate() Start");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		 
		String url = JOParams.getString("url");
		JSONArray retData=null;
		JSONObject jsonObj=new JSONObject();
		String userName = this.getUserId() == null?"system":(this.getUserId().equals(""))?"system":this.getUserId();
		int returnCode;
		try {
			List<LogisticsRate> list = readLogisticsRateToList(url);
			if(list.size() == 0){
				setResultData("50002",null);
			}else if (list == null) {
				setResultData("50003",null);
			}else{
				returnCode = this.logisticsRateMgr.importLogisticsRate(list,userName);
				if(returnCode >= 0){
					this.log.businesslog("牌号-费率 导入成功",Constants.OPE_MODE_LOGISTICS,Constants.OPE_SUCCESS);
					retData = JsonUtil.coverModelToJSONArray(list);
					jsonObj.put("total", list.size());
					jsonObj.put("result", retData==null?new int[0]:retData);
					setResultData(ResultCode.CODE00000.getValue(), jsonObj);
				}else {
					setResultData("40015",null);
				}
			}
		} catch (Exception e) {
			this.log.error("牌号-费率 导入失败：" + e.getMessage());
			setResultData("40015",null);
		}
		this.log.info(this.getClass().getName() + " importLogisticsRate() End");
		return rtnData.toString();
	}

	@Override
	public String importLogisticsTemplatePrice(String params) {
		this.log.info(this.getClass().getName() + " importLogisticsTemplatePrice() Start");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		String url = JOParams.getString("url");
		JSONArray retData=null;
		JSONObject jsonObj=new JSONObject();
		String userName = this.getUserId() == null?"system":(this.getUserId().equals(""))?"system":this.getUserId();
		int returnCode;
		try {
			List<LogisticsTemplatePrice> list = this.logisticsRateMgr.readLogisticsTemplatePriceToList(url);
			if(list.size() == 0){
				setResultData("50002",null);
			}else if (list == null) {
				setResultData("50003",null);
			}else{
				returnCode = this.logisticsRateMgr.importLogisticsTemplatePrice(list,userName);
				if(returnCode >= 0){
					this.log.businesslog("物流配送运费 导入成功",Constants.OPE_MODE_LOGISTICS,Constants.OPE_SUCCESS);
					retData = JsonUtil.coverModelToJSONArray(list);
					jsonObj.put("total", list.size());
					jsonObj.put("result", retData==null?new int[0]:retData);
					setResultData(ResultCode.CODE00000.getValue(), jsonObj);
				}else {
					this.log.businesslog("物流配送运费 导入失败",Constants.OPE_MODE_LOGISTICS,Constants.OPE_FAIL);
					setResultData("40015",null);
				}
			}
		} catch (Exception e) {
			this.log.error("物流配送运费 导入失败：" + e.getMessage());
			setResultData("40015",null);
		}
		this.log.info(this.getClass().getName() + " importLogisticsTemplatePrice() End");
		return rtnData.toString();
	}
	
	
	/**
	 * 导入 物流配送区域
	 */
	@Override
	public String importLogisticsArea(String params) {
		this.log.info(this.getClass().getName() + " importLogisticsArea() Start");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		 
		String url = JOParams.getString("url");
		JSONArray retData=null;
		JSONObject jsonObj=new JSONObject();
		String userName = this.getUserId() == null?"system":(this.getUserId().equals(""))?"system":this.getUserId();
		int returnCode;
		try {
			List<LogisticsArea> list = readLogisticsAreaToList(url);
			if(list.size() == 0){
				setResultData("50002",null);
			}else if (list == null) {
				setResultData("50003",null);
			}else{
				returnCode = this.logisticsRateMgr.importLogisticsArea(list,userName);
				if(returnCode >= 0){
					this.log.businesslog("物流配送区域 导入成功",Constants.OPE_MODE_LOGISTICS,Constants.OPE_SUCCESS);
					retData = JsonUtil.coverModelToJSONArray(list);
					jsonObj.put("total", list.size());
					jsonObj.put("result", retData==null?new int[0]:retData);
					setResultData(ResultCode.CODE00000.getValue(), jsonObj);
				}else {
					setResultData("40015",null);
				}
			}
		} catch (Exception e) {
			this.log.error("物流配送区域 导入失败：" + e.getMessage());
			setResultData("40015",null);
		}
		this.log.info(this.getClass().getName() + " importLogisticsArea() End");
		return rtnData.toString();
	}
	
	@Override
	public String getLogisticsAreaList(String params) {
		this.log.info(this.getClass().getName()
				+ " getLogisticsAreaList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<LogisticsArea> list = new ArrayList<LogisticsArea>();
		boolean bolRst = false;
		List<Condition> conditionList = new ArrayList<Condition>();
		
		conditionList.add(new Condition("temp.Path", "like", "","String", "path"));
		conditionList.add(new Condition("temp.AreaNo", "like", "","String", "areaNo"));

		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel,
				conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			list = this.logisticsRateMgr.getLogisticsAreaList(qc,pageInfo);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("物流配送区域列表 数据查询失败："+e.getMessage());
			setResultData("10105",null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData==null?new int[0]:retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("物流配送区域列表 数据转换失败：" + e.getMessage());
				setResultData("10101", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName()
				+ " getLogisticsAreaList() End");
		return rtnData.toString();
	}
	
	@Override
	public String getLogisticsAreaPriceList(String params) {
		this.log.info(this.getClass().getName() + " getLogisticsAreaPriceList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<LogisticsTemplatePrice> list = new ArrayList<LogisticsTemplatePrice>();
		boolean bolRst = false;
		
		List<Condition> conditionList = new ArrayList<Condition>();
		
		conditionList.add(new Condition("temp.Path", "like", "","String", "Path"));
		conditionList.add(new Condition("temp.sourcePlaceName", "like", "","String", "sourcePlaceName"));
		conditionList.add(new Condition("temp.goodName", "like", "","String", "goodName"));

		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel,
				conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			list = this.logisticsRateMgr.getLogisticsTemplatePriceList(qc,pageInfo);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("运费列表 数据查询失败："+e.getMessage());
			setResultData("10105",null);
		}
		
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData==null?new int[0]:retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("运费列表 数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getLogisticsAreaPriceList() Start");
		return rtnData.toString();
	}
	
	
	@Override
	public String getProvinceList(String params) {
		this.log.info(this.getClass().getName() + " getProvinceList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<ValueTxtView> list = new ArrayList<ValueTxtView>();
		String leadsID = "-1";
		leadsID = JOParams.optString("leadsID").equals("")?"-1":JOParams.optString("leadsID");
		boolean bolRst = false;
		try {
			list = this.logisticsRateMgr.getProvinceList(leadsID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("省份列表 查询失败：" + e.getMessage());
			setResultData("10101", null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData==null?new int[0]:retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("省份列表 数据转换失败：" + e.getMessage());
				setResultData("10101", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getProvinceList() End");
		return rtnData.toString();
	}

	@Override
	public String getProvinceAreaList(String params) {
		this.log.info(this.getClass().getName() + " getProvinceAreaList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<ValueTxtView> list = new ArrayList<ValueTxtView>();
		boolean bolRst = false;
		int proviceID = JOParams.getInt("proviceID");
		
		String queryType = "query";
		queryType = JOParams.optString("queryType").equals("")?"query":JOParams.optString("queryType");
		int leadsID =  JOParams.optInt("leadsID");
		
		try {
			list = this.logisticsRateMgr.getProvinceAreaList(proviceID,queryType,leadsID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("省区列表 查询失败：" + e.getMessage());
			setResultData("10101", null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData==null?new int[0]:retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("省区列表 数据转换失败：" + e.getMessage());
				setResultData("10101", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getProvinceAreaList() End");
		return rtnData.toString();
	}

	@Override
	public String getCityList(String params) {
		this.log.info(this.getClass().getName() + " getBrandList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<ValueTxtView> list = new ArrayList<ValueTxtView>();
		boolean bolRst = false;
		
		String queryType = "query";
		queryType = JOParams.optString("queryType").equals("")?"query":JOParams.optString("queryType");
		int leadsID =  JOParams.optInt("leadsID");
		
		int proviceAreaID  = JOParams.getInt("proviceAreaID");
		try {
			list = this.logisticsRateMgr.getCityList(proviceAreaID,queryType,leadsID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("区域名称列表 查询失败：" + e.getMessage());
			setResultData("10101", null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("result", retData==null?new int[0]:retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("区域名称列表 数据转换失败：" + e.getMessage());
				setResultData("10101", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getBrandList() End");
		return rtnData.toString();
	}
	
	@Override
	public String deleteLogisticsTemplatePrice(String params) {
		this.log.info(this.getClass().getName() + " deleteLogisticsTemplatePrice() Start");
		JSONObject JOParams = new JSONObject(params);
		// 提交的凭证号数组
		JSONArray logisticsTemplatePriceIDArrayTemp = JOParams.getJSONArray("logisticsTemplatePriceIDArray");
		long[] logisticsTemplatePriceIDs = JSONArrayUtil.getJsonToLongArray(logisticsTemplatePriceIDArrayTemp);
		int returnCode;
		try {
			returnCode = this.logisticsRateMgr.deleteLogisticsTemplatePrice(logisticsTemplatePriceIDs);
			if(returnCode >= 0){
				this.log.businesslog("物流配送运费 删除成功",Constants.OPE_MODE_LOGISTICS,Constants.OPE_SUCCESS);
				setResultData("00000",null);
			}else {
				this.log.businesslog("物流配送运费 删除失败",Constants.OPE_MODE_LOGISTICS,Constants.OPE_FAIL);
				setResultData("10107",null);
			}
		} catch (Exception e) {
			this.log.error("物流配送运费 删除失败："+e.getMessage());
			setResultData("10107",null);
		}
		return rtnData.toString();
	}

	/**
	 * 读取导入"物流配送区域" excel数据
	 * @param url
	 * @return
	 */
	private List<LogisticsArea> readLogisticsAreaToList(String filePath) {
		this.log.debug("readLogisticsAreaToList() Start");
		List<LogisticsArea> rtnLst = new ArrayList<LogisticsArea>();
		LogisticsArea detail = null;
		ImportHttpExecl ihe = new ImportHttpExecl();
		int sheetNo=0;

		// 读取Excel2007
        List<List<String>> list = ihe.read(filePath,sheetNo,true);

        String err = ihe.getErrorInfo();
        if (null != err && !err.isEmpty()) {
        	// Excel2007失败，再次尝试读取Excel2003
        	ihe = new ImportHttpExecl();
        	list = ihe.read(filePath,sheetNo,false);
        }
        err = null;
        err = ihe.getErrorInfo();
        if (null != err && !err.isEmpty()) {
        	this.log.error(err);
			setResultData(ResultCode.CODE10103.getValue(), null, err);
			return null;
        }
        for (int i = 2; i < list.size(); i++) {
        	detail = new LogisticsArea();
        	List<String> cellList = new ArrayList<String>();
            cellList = list.get(i);  
            java.util.Date date = null;
            boolean isNull = false;
            try {
				if (cellList != null && cellList.size() > 0) {
					
					/*省份*/
					String provinceName = cellList.get(0);
					if(!this.judgeIsNull(provinceName)) return null;
					detail.setProvinceName(provinceName);
					
					
					/*省区(二级区域)*/
					String provinceArea = cellList.get(1);
					if(!this.judgeIsNull(provinceArea)) return null;
					detail.setProvinceArea(provinceArea);
					
					
					/*区域代码*/
					String areaNo = cellList.get(2);
					if(!this.judgeIsNull(areaNo)) return null;
					detail.setAreaNo(areaNo);
					
					
					/*区域名称*/
					String logisticsAreaName = cellList.get(3);
					if(!this.judgeIsNull(logisticsAreaName)) return null;
					detail.setName(logisticsAreaName);
					
					rtnLst.add(detail);
				}else {
					return rtnLst;
				}
			} catch (Exception e) {
				this.log.error("'物流配送区域'模板实体类设定失败");
				e.printStackTrace();
				return null;
			}
		}
        
        return rtnLst;
	}
	/**
	 * 读取导入"牌号-费率" excel数据
	 * @param url
	 * @return
	 */
	private List<LogisticsRate> readLogisticsRateToList(String filePath) {
		this.log.debug("readLogisticsRateToList() Start");
		List<LogisticsRate> rtnLst = new ArrayList<LogisticsRate>();
		LogisticsRate detail = null;
		ImportHttpExecl ihe = new ImportHttpExecl();
		int sheetNo=0;

		// 读取Excel2007
        List<List<String>> list = ihe.read(filePath,sheetNo,true);

        String err = ihe.getErrorInfo();
        if (null != err && !err.isEmpty()) {
        	// Excel2007失败，再次尝试读取Excel2003
        	ihe = new ImportHttpExecl();
        	list = ihe.read(filePath,sheetNo,false);
        }
        err = null;
        err = ihe.getErrorInfo();
        if (null != err && !err.isEmpty()) {
        	this.log.error(err);
			setResultData(ResultCode.CODE10103.getValue(), null, err);
			return null;
        }
        
        if (list == null || list.isEmpty()) {
        	this.log.error("'牌号-费率'模板读取失败");
			setResultData(ResultCode.CODE10104.getValue(), null, "'牌号-费率'模板读取失败");
        	return null;
        }
        for (int i = 1; i < list.size(); i++) {
        	detail = new LogisticsRate();
        	List<String> cellList = new ArrayList<String>();
            cellList = list.get(i);  
            java.util.Date date = null;
            boolean isNull = false;
            try {
				if(cellList != null && cellList.size() > 0){
					
					/*分类*/
					String CategoryLeafName = cellList.get(2);
					if(!this.judgeIsNull(CategoryLeafName)) return null;
					detail.setCategoryLeafName(CategoryLeafName);
					
					/*牌号*/
					String brandName = cellList.get(3);
					if(!this.judgeIsNull(brandName)) return null;
					if(brandName.endsWith(".0"))
						brandName = brandName.replace(".0", "");
					detail.setBrandName(brandName.toString());
					
					/*产地*/
					String sourcePlaceName = cellList.get(4);
					if(!this.judgeIsNull(sourcePlaceName)) return null;
					detail.setSourcePlaceName(sourcePlaceName);
					
					/*费率大类*/
					String templateBigName = cellList.get(5);
					if(!this.judgeIsNull(templateBigName)) return null;
					detail.setTemplateBigName(templateBigName);
					
					/*费率细分*/
					String templateName = cellList.get(6);
					if(!this.judgeIsNull(templateName)) return null;
					detail.setTemplateName(templateName);
					
					rtnLst.add(detail);
				}else {
					return rtnLst;
//					setResultData("", "逗逼，模板数据为空");
				}
			} catch (Exception e) {
				this.log.error("'牌号-费率'模板实体类设定失败");
				e.printStackTrace();
				return null;
			}
		}
        this.log.debug("readLogisticsRateToList() End");
		return rtnLst;
	}

	
	/**
	 * 字符串去空
	 * @param categoryLeafName
	 * @return
	 */
	private boolean judgeIsNull(String categoryLeafName) {
		if(categoryLeafName == null ){
			return false;
		}else {
			categoryLeafName = categoryLeafName.trim(); 
			if(categoryLeafName.equals("")){
				return false;
			}else {
				return true;
			}
		}
	}

	@Override
	public String getParentAreaByJuniorID(String params) {
		this.log.info(this.getClass().getName() + " getParentAreaByJuniorID() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<ValueTxtView> list = new ArrayList<ValueTxtView>();
		boolean bolRst = false;
		//次级区域ID
		int juniorID = JOParams.getInt("juniorID");
		ValueTxtView valueTxtView = new ValueTxtView();
		try {
			valueTxtView = this.logisticsRateMgr.getParentAreaByJuniorID(juniorID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("上级区域 查询失败：" + e.getMessage());
			setResultData("10101", null);
		}
		if (bolRst) {
			JSONObject retData;
			try {
				retData = JsonUtil.coverModelToJSONObject(valueTxtView);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error("上级区域转换失败：" + e.getMessage());
				setResultData("10105", null);
			}
		}
		this.log.info(this.getClass().getName() + " getParentAreaByJuniorID() End");
		return rtnData.toString();
	}
}
