package shcem.logistics.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * 物流配送费率价格表
 * @author zhangnan
 */
public class LogisticsRatePrice extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 	ID								ID										
		费率分类ID								RateID										
		始发地ID								StartAreaID										
		始发名称								StartAreaName										
		目的地ID								EndAreaID										
		目的地名称								EndAreaName										
		区间最小重量								MinWeight										
		区间最大重量								MaxWeight										
		单价								Price										
		默认为 0：显示，1：不显示								DISABLED										
		创建人								REC_CREATEBY										
		创建时间								REC_CREATETIME										
		最后修改人								REC_MODIFYBY										
		最后修改时间								REC_MODIFYTIME										
	 */
	
	/**/
	private Integer id;

	/*费率分类ID*/
	private Integer rateID;
	
	/*始发地ID*/
	private Integer startAreaID;
	
	/*始发名称*/
	private String startAreaName;
	
	/*目的地ID*/
	private Integer endAreaID;
	
	/*目的地名称*/
	private String endAreaName;
	
	/*区间最小重量*/
	private BigDecimal minWeight;
	
	/*区间最大重量*/
	private BigDecimal maxWeight;
	
	/*单价*/
	private BigDecimal price;
	
	/*默认为 0：显示，1：不显示*/
	private Integer dISABLED;
	
	/*创建人*/
	private String rEC_CREATEBY;

	/*创建时间*/
	private Date  rEC_CREATETIME;
	
	/*最后修改人*/
	private String rEC_MODIFYBY;
	
	/*最后时间*/
	private Date  rEC_MODIFYTIME;
	
	/*分类-牌号*/
	private String goodName;
	
	/*产地*/
	private Integer sourcePlaceID;
	
	/*产地*/
	private String sourcePlaceName;
	
	/*费率明细*/
	private String rateDetailName;
	
	/*区域代码*/
	private String areaNo;
	

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
