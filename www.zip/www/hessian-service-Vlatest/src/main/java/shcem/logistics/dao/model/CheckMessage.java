package shcem.logistics.dao.model;

import java.io.Serializable;

import shcem.base.dao.model.BaseObject;

/**
 * 校验信息
 * @author zhangnan
 *
 */
public class CheckMessage extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String message;
	
	private String url;
	
	private Boolean importBoolean;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Boolean getImportBoolean() {
		return importBoolean;
	}

	public void setImportBoolean(Boolean importBoolean) {
		this.importBoolean = importBoolean;
	}

}
