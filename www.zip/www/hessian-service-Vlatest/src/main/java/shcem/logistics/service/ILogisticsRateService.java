package shcem.logistics.service;
/**
 * 交收配送:物流运费相关
 * @author zhangnan
 *
 */
public interface ILogisticsRateService {
	/**
	 * 费率细分列表
	 * @param params
	 * @return
	 */
	public String getLogisticsRateCategoryList(String params);
	
	/**
	 * 新增 费率细分
	 * @param params
	 * @return
	 */
	public String addLogisticsRate(String params);
	
	/**
	 * 验证  "产品分类"+"产品牌号" 不能重复
	 * @param params
	 * @return
	 */
	public String disRepeat(String params);
	
	/**
	 * 牌号列表
	 * @param params
	 * @return
	 */
	public String getBrandList(String params);
	
	/**
	 * 某个牌号关联的产地
	 * @param params
	 * @return
	 */
	public String getSourcePlaceListByBrandID(String params);
	
	/**
	 * 更新 费率细分
	 * @param params
	 * @return
	 */
	public String updateLogisticsRate(String params);
	
	/**
	 * 删除物流运费模板表产品
	 * @param params
	 * @return
	 */
	public String deleteLogisticsRateCategory(String params);
	
	/**
	 * 导入 费率细分
	 * @param params
	 * @return
	 */
	public String importLogisticsRate(String params);
	
	/**
	 * 校验费率导入模板
	 * @param params
	 * @return
	 */
	public String checkLogisticsTemplatePrice_File(String params);
	/**
	 * 导入 物流运费模板价格
	 * @param params
	 * @return
	 */
	public String importLogisticsTemplatePrice(String params);
	
	/**
	 * 导入 物流配送区域
	 * @param params
	 * @return
	 */
	public String importLogisticsArea(String params);
	
	/**
	 * 物流配送区域列表
	 * @param params
	 * @return
	 */
	public String getLogisticsAreaList(String params);
	
	/**
	 * 运费管理列表
	 * @param params
	 * @return
	 */
	public String getLogisticsAreaPriceList(String params);
	
	/**
	 * 物流省份
	 * @param params
	 * @return
	 */
	public String getProvinceList(String params);
	
	/**
	 * 物流省区
	 * @param params
	 * @return
	 */
	public String getProvinceAreaList(String params);
	
	/**
	 * 物流地级市
	 * @param params
	 * @return
	 */
	public String getCityList(String params);
	
	/**
	 * 删除配送区域运费(批量删除)
	 * @param params
	 * @return
	 */
	public String deleteLogisticsTemplatePrice(String params);
	
	/**
	 * 物流配送区域：子节点查询上级区域
	 * @param params
	 * @return
	 */
	public String getParentAreaByJuniorID(String params);
}
