package shcem.logistics.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.CannotGetJdbcConnectionException;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.service.model.ValueTxtView;
import shcem.logistics.dao.ILogisticsRateDao;
import shcem.logistics.dao.model.LogisticsArea;
import shcem.logistics.dao.model.LogisticsRate;
import shcem.logistics.dao.model.LogisticsRateCategory;
import shcem.logistics.dao.model.LogisticsRatePrice;
import shcem.logistics.dao.model.LogisticsTemplatePrice;
import shcem.util.CommonRowMapper;

public class LogisticsRateDaoImpl extends BaseDAOImpl implements
		ILogisticsRateDao {

	@Override
	public List<LogisticsRate> getLogisticsRateCategoryList(QueryConditions qc,
			PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("LogisticsRateDao_004");
		List<LogisticsRate> list = this.queryBySQL(sql, qc, pageInfo,
				new CommonRowMapper(new LogisticsRate()));
		return list;
	}

	@Override
	public int addLogisticsRate(LogisticsRate logisticsRate, String userName) {
		String sql = this.sqlProperty.getProperty("LogisticsRateDao_001");
		Object[] params = { 1,// 物流公司ID，暂时设置中石化：1
				logisticsRate.getTemplateBigName(),// 费率大类
				logisticsRate.getTemplateName(),// 费率细分
				0,// 可见
				userName,// 创建人
				userName // 修改人
		};
		int logisticsRateID;
		try {
			logisticsRateID = this.queryForIntID(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			logisticsRateID = -1;
		}
		return logisticsRateID;
	}

	@Override
	public int addLogisticsRateCategory(int logisticsRateID,
			LogisticsRate logisticsRate, String userName) {
		String sql = this.sqlProperty.getProperty("LogisticsRateDao_002");
		Object[] params = { logisticsRateID,// 费率分类ID
				logisticsRate.getCategoryLeafID(),// 产品分类
				logisticsRate.getBrandID(),// 产品牌号
				logisticsRate.getSourcePlaceID(),// 产地
				0,// 默认为 0：显示，1：不显示
				userName,// 创建人
				userName // 最后修改人
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}

	@Override
	public LogisticsRate getLogisticsRate(String rateDetailName) {
		String sql = "select * from T_LogisticsTemplate where TemplateName='" + rateDetailName + "'";
		Object[] params = {};
		LogisticsRate logisticsRate = (LogisticsRate) this.queryForObject(sql, params, new CommonRowMapper(new LogisticsRate()));
		return logisticsRate;
	}

	@Override
	public List<ValueTxtView> getBrandList(String brandName) {
		String sql = "SELECT TOP 30 ID as tagID,BrandName as text FROM VW_Crm_Brand WHERE BrandName like '%"
				+ brandName + "%'";
		Object[] params = {};
		List<ValueTxtView> list = this.queryBySQL(sql, params, null,
				new CommonRowMapper(new ValueTxtView()));
		return list;
	}

	@Override
	public List<ValueTxtView> getSourcePlaceListByBrandID(int brandID) {
		String sql = this.sqlProperty.getProperty("LogisticsRateDao_003");
		Object[] params = { brandID };
		List<ValueTxtView> list = this.queryBySQL(sql, params, null,
				new CommonRowMapper(new ValueTxtView()));
		return list;
	}

	@Override
	public int deleteLogisticsRateCategory(String logisticsRateCategoryIDs) {
		String sql = "DELETE FROM T_LogisticsTemplateCategory   where  ID in("
				+ logisticsRateCategoryIDs + ")";
		Object[] params = {

		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}

	@Override
	public int getLogisticsRateCategoryCount(Integer categoryLeafID, Integer brandID, Integer sourcePlaceID) {
		String sql = "select * from T_LogisticsTemplateCategory where  CategoryLeafID="
				+ categoryLeafID + " and BrandID = " + brandID
				+ " and SourcePlaceID=" + sourcePlaceID;
		Object[] params = {};
		List<LogisticsRateCategory> list = this.queryBySQL(sql, params, null,
				new CommonRowMapper(new LogisticsRateCategory()));
		if (list != null && list.size() > 0) {
			return list.size();
		} else {
			return 0;
		}
	}

	@Override
	public int getCategoryLeafID(String categoryLeafName) {
		String sql = "select ID as tagID from VW_Crm_CategorySpecial  WHERE Type = 1  and CategoryName='"
				+ categoryLeafName + "'";
		Object[] params = {};
		ValueTxtView valueTxtView = (ValueTxtView) this.queryForObject(sql,
				params, new CommonRowMapper(new ValueTxtView()));
		if (valueTxtView.getTagID() != null) {
			return valueTxtView.getTagID();
		} else {
			return -1;
		}
	}

	@Override
	public int getBrandID(int categoryLeafID, String brandName) {
		String sql = "SELECT vw1.ID as tagID from VW_Crm_Brand  vw1 INNER JOIN VW_Crm_CategorySpecial  vw2 "
				+ "ON vw1.CategoryLeafID = vw2.ID WHERE vw2.ID = "
				+ categoryLeafID + " AND vw1.BrandName = '" + brandName + "'";
		Object[] params = {};
		ValueTxtView valueTxtView;
		try {
			valueTxtView = (ValueTxtView) this.queryForObject(sql,
					params, new CommonRowMapper(new ValueTxtView()));
		} catch (Exception e) {
			e.printStackTrace();
			valueTxtView =null;
		}
		
		if (valueTxtView != null) {
			return valueTxtView.getTagID();
		} else {
			return -1;
		}
	}

	@Override
	public int getSourcePlaceID(String sourcePlaceName) {
		String sql = "SELECT ID as tagID from VW_Crm_SourcePlace  WHERE Name = '"
				+ sourcePlaceName + "'";
		Object[] params = {};
		ValueTxtView valueTxtView = (ValueTxtView) this.queryForObject(sql,
				params, new CommonRowMapper(new ValueTxtView()));
		if (valueTxtView.getTagID() != null) {
			return valueTxtView.getTagID();
		} else {
			return -1;
		}
	}

	@Override
	public int updateLogisticsRateCategory(int templateID,
			Integer categoryLeafID, Integer brandID, Integer sourcePlaceID,
			String userName) {
		String sql = this.sqlProperty.getProperty("LogisticsRateDao_005");
		Object[] params = {
				templateID,// 费率分类ID
				categoryLeafID,// 产品分类
				brandID,// 产品牌号
				sourcePlaceID,// 产地
				userName,// 最后修改人
				templateID,// 费率分类ID
				categoryLeafID,// 产品分类
				brandID,// 产品牌号
				sourcePlaceID // 产地
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}

	@Override
	public LogisticsArea getLogisticsAreaByProvinceName(String provinceName) {
		String sql = "select * from T_LogisticsArea where Name='"+provinceName+"' and AreaLevel = 1";
		Object [] params = {};
		LogisticsArea logisticsArea = (LogisticsArea) this.queryForObject(sql, params, new CommonRowMapper(new LogisticsArea()));
		return logisticsArea;
	}
	
	@Override
	public int addLogisticsArea(LogisticsArea logisticsArea, String userName) {
		String sql = this.sqlProperty.getProperty("LogisticsRateDao_006");
		if(logisticsArea.getAreaLevel() != 3){
			logisticsArea.setAreaNo(null);
		}
		Object [] params ={
					logisticsArea.getLogisticsID(),//* 物流公司ID								LogisticsID										
				logisticsArea.getAreaNo(),//区域代码								AreaNo										
				logisticsArea.getName(),//区域名称								Name										
				logisticsArea.getParentID(),//上级ID								ParentID										
				logisticsArea.getAreaLevel(),//级别								AreaLevel										
				logisticsArea.getSort(),//排序								Sort										
				logisticsArea.getIsLeaf(),//是否叶子节点								IsLeaf										
				0,//默认为 0：显示，1：不显示								DISABLED										
				userName,//创建人								REC_CREATEBY										
				userName//最后修改人								REC_MODIFYBY										
		};
		int logisticsAreaID;
		try {
			logisticsAreaID = this.queryForIntID(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			logisticsAreaID = -1;
		}
		return logisticsAreaID;
	}
	
	@Override
	public int updateLogisticsAreaPath(String path, String userName,
			int provinceID) {
		String sql = this.sqlProperty.getProperty("LogisticsRateDao_007");
		Object [] params = {
				path,userName,provinceID
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode=-1;
		}
		return returnCode;
	}
	
	@Override
	public int getLogisticsAreaID(int parentID, int areaLevel,
			String logisticsAreaName) {
		String sql = this.sqlProperty.getProperty("LogisticsRateDao_008");
		Object [] params = {
				parentID,
				areaLevel,
				logisticsAreaName
		};
		LogisticsArea logisticsArea = (LogisticsArea) this.queryForObject(sql, params, new CommonRowMapper(new LogisticsArea()));
		if(logisticsArea == null ){
			return -1;
		}else {
			return logisticsArea.getId();
		}
	}
	
	@Override
	public int updateLogisticsArea(LogisticsArea logisticsArea, int provinceID,
			String userName, String path_area) {
		String sql = this.sqlProperty.getProperty("LogisticsRateDao_009");
		if(logisticsArea.getAreaLevel() != 3){
			logisticsArea.setAreaNo(null);
		}
		Object [] params = {
				path_area,
				logisticsArea.getAreaNo(),//区域代码				
				logisticsArea.getName(),//区域名称				
				logisticsArea.getParentID(),//上级ID								ParentID										
				logisticsArea.getAreaLevel(),//级别								AreaLevel										
				logisticsArea.getSort(),//排序								Sort										
				logisticsArea.getIsLeaf(),//是否叶子节点								IsLeaf										
				userName,//最后修改人								REC_MODIFYBY	
				provinceID
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode =-1;
		}
		return returnCode;
	}
	
	
	@Override
	public List<LogisticsArea> getLogisticsAreaList(QueryConditions qc,
			PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("LogisticsRateDao_010");
		List<LogisticsArea> list = this.queryBySQL(sql, qc, pageInfo,
				new CommonRowMapper(new LogisticsArea()));
		return list;
	}
	
	@Override
	public List<LogisticsRate> getLogisticsRateByTemplateBigName(
			String templateBigName) {
		String sql = "select * from T_LogisticsTemplate where TemplateBigName='" + templateBigName + "'";
		Object[] params = {};
		List<LogisticsRate> list = this.queryBySQL(sql, params, null, new CommonRowMapper(new LogisticsRate()));
		return list;
	}
	
	@Override
	public LogisticsArea getLogisticsAreaByAreaNo(String endAreaNo) {
		String sql = "select * from T_LogisticsArea where AreaNo='" + endAreaNo + "'";
		Object [] params = {};
		LogisticsArea logisticsArea = (LogisticsArea) this.queryForObject(sql, params, new CommonRowMapper(new LogisticsArea()));
		return logisticsArea;
	}
	
	@Override
	public int getLogisticsTemplate(String templateBigName, String templateName) {
		String sql = "select * from T_LogisticsTemplate where TemplateBigName='"+templateBigName+"' and TemplateName ='"+templateName+"'";
		Object []  params = {};
		LogisticsRate logisticsRate = (LogisticsRate) this.queryForObject(sql, params, new CommonRowMapper(new LogisticsRate())); 
		if(logisticsRate == null){
			return -1;
		}else {
			return logisticsRate.getId();
		}
	}
	
	@Override
	public int getLogisticsAreaIDByAreaNo(String endAreaNo) {
		String sql = "select * from T_LogisticsArea where AreaNo='"+endAreaNo+"'";
		Object []  params = {};
		LogisticsArea logisticsArea = (LogisticsArea) this.queryForObject(sql, params, new CommonRowMapper(new LogisticsArea())); 
		if(logisticsArea == null){
			return -1;
		}else {
			return logisticsArea.getId();
		}
	}
	
	@Override
	public int getLogisticsAreaIDByAreaNo(int parentID_provinceAreaID, int areaLevel,
			String areaNo) {
		String sql = this.sqlProperty.getProperty("LogisticsRateDao_014");
		Object [] params = {
				parentID_provinceAreaID,
				areaLevel,
				areaNo
		};
		LogisticsArea logisticsArea = (LogisticsArea) this.queryForObject(sql, params, new CommonRowMapper(new LogisticsArea()));
		if(logisticsArea == null ){
			return -1;
		}else {
			return logisticsArea.getId();
		}
	}
	
	@Override
	public int getLeafLogisticsAreaIDByAreaNo(int parentID_provinceAreaID,
			int areaLevel, String areaNo) {
		String sql = this.sqlProperty.getProperty("LogisticsRateDao_017");
		Object [] params = {
				areaLevel,
				areaNo
		};
		LogisticsArea logisticsArea = (LogisticsArea) this.queryForObject(sql, params, new CommonRowMapper(new LogisticsArea()));
		if(logisticsArea == null ){
			return -1;
		}else {
			return logisticsArea.getId();
		}
	}
	
	@Override
	public LogisticsArea getLogisticsAreaByAreaNoAndName(String endAreaNo,
			String endAreaName) {
		String sql = this.sqlProperty.getProperty("LogisticsRateDao_015");
		Object [] params = {
				endAreaNo,
				endAreaName
		};
		LogisticsArea logisticsArea = (LogisticsArea) this.queryForObject(sql, params, new CommonRowMapper(new LogisticsArea()));
		return logisticsArea;
	}
	
	/**
	 * 费率大类+产品(费率细分) 确定一条记录
	 */
	@Override
	public LogisticsRate getlogisticsRateBytemplateBigNameAndtemplateName(
			String templateBigName, String templateName) {
		String sql = this.sqlProperty.getProperty("LogisticsRateDao_016");
		Object [] params = {
				templateBigName,
				templateName
		};
		LogisticsRate logisticsRate = (LogisticsRate) this.queryForObject(sql, params, new CommonRowMapper(new LogisticsRate()));
		return logisticsRate;
	}
	
	@Override
	public String getEndAreaName(int areaID) {
		String sql = "SELECT CAST(t3.Name AS VARCHAR)+'-'+CAST(t2.Name AS VARCHAR)+'-'+CAST(t1.Name AS VARCHAR) as endAreaName FROM T_LogisticsArea t1"
				+ " LEFT JOIN T_LogisticsArea t2 ON t1.ParentID = t2.ID "
				+ " LEFT JOIN T_LogisticsArea t3 ON t2.ParentID = t3.ID WHERE t1.AreaLevel = 3 and t1.ID ="+areaID;
		Object []  params = {};
		LogisticsTemplatePrice logisticsTemplatePrice = (LogisticsTemplatePrice) this.queryForObject(sql, params, new CommonRowMapper(new LogisticsTemplatePrice())); 
		if(logisticsTemplatePrice == null){
			return "-1";
		}else {
			return logisticsTemplatePrice.getEndAreaName();
		}
	}
	
	@Override
	public int addLogisticsTemplatePrice(LogisticsTemplatePrice logisticsTemplatePrice, String userName) {
		String sql = this.sqlProperty.getProperty("LogisticsRateDao_011");
		Object [] params = {
				logisticsTemplatePrice.getTemplateID(),//运费模板ID
				logisticsTemplatePrice.getEndAreaID(),//目的地ID
				logisticsTemplatePrice.getEndAreaName(),//目的地名称
				0,//区间最小重量							
				0,//区间最大重量
				logisticsTemplatePrice.getPrice(),//运费(元/吨)
				0,//disabled
				userName,//创建人
				userName//最后修改人
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public int getlogisticsTemplatePriceIDByTemplateIDAndendArEaID(
			int templateID, int endAreaID) {
		String sql = "select * from T_LogisticsTemplatePrice where TemplateID="+templateID+" and  EndAreaID="+endAreaID;
		Object []  params = {};
		LogisticsTemplatePrice logisticsTemplatePrice = (LogisticsTemplatePrice) this.queryForObject(sql, params, new CommonRowMapper(new LogisticsTemplatePrice())); 
		if(logisticsTemplatePrice == null){
			return -1;
		}else {
			return logisticsTemplatePrice.getId();
		}
	}
	
	@Override
	public int updateLogisticsTemplatePrice(
			LogisticsTemplatePrice logisticsTemplatePrice, String userName,int logisticsTemplatePriceID) {
		String sql = this.sqlProperty.getProperty("LogisticsRateDao_012");
		Object [] params = {
				logisticsTemplatePrice.getTemplateID(),//运费模板ID
				logisticsTemplatePrice.getEndAreaID(),//目的地ID
				logisticsTemplatePrice.getEndAreaName(),//目的地名称
				0,//区间最小重量							
				0,//区间最大重量
				logisticsTemplatePrice.getPrice(),//运费(元/吨)
				0,//disabled
				userName,//最后修改人
				logisticsTemplatePriceID
		};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode = -1;
		}
		return returnCode;
	}
	
	@Override
	public List<ValueTxtView> getProvinceList(String leadsID) {
		String sql = "SELECT ID as tagID,Name as text  FROM T_LogisticsArea WHERE AreaLevel = 1 ";
		if(!leadsID.equals("-1"))sql = "SELECT t1.ID as tagID,t1.Name as text  from T_LogisticsArea t1 INNER JOIN T_Leads_TemplatePrice "
				+ "t2 ON t2.FirstAreaID = t1.ID WHERE t2.LeadsID = "+leadsID+" GROUP BY t1.ID,t1.Name";
		Object[] params = {};
		List<ValueTxtView> list = this.queryBySQL(sql, params, null,
				new CommonRowMapper(new ValueTxtView()));
		return list;
	}
	@Override
	public List<ValueTxtView> getProvinceAreaList(int proviceID,String queryType,int leadsID) {
		String sql = "SELECT ID as tagID,Name as text  FROM T_LogisticsArea WHERE AreaLevel = 2 and ParentID ="+proviceID;
		if(!queryType.equals("query"))sql = "SELECT t1.ID as tagID,t1.Name as text  FROM T_LogisticsArea t1 "
				+ "INNER JOIN T_Leads_TemplatePrice t2 ON t2.SecondAreaID = t1.ID"
				+ " WHERE t1.AreaLevel = 2 AND t2.LeadsID = "+leadsID+" and t1.ParentID="+proviceID+" GROUP BY t1.ID,t1.Name";
		Object[] params = {};
		List<ValueTxtView> list = this.queryBySQL(sql, params, null,
				new CommonRowMapper(new ValueTxtView()));
		return list;
	}
	
	@Override
	public List<ValueTxtView> getCityList(int proviceAreaID,String queryType, int leadsID) {
		String sql = "SELECT ID as tagID,Name as text  FROM T_LogisticsArea WHERE AreaLevel = 3 and ParentID ="+proviceAreaID;
		if(!queryType.equals("query"))sql = "SELECT t1.ID as tagID,t1.Name as text  FROM T_LogisticsArea t1 "
				+ "INNER JOIN T_Leads_TemplatePrice t2 ON t2.LastAreaID = t1.ID"
				+ " WHERE t1.AreaLevel = 3 AND t2.LeadsID = "+leadsID+"and t1.ParentID="+proviceAreaID+" GROUP BY t1.ID,t1.Name";
		Object[] params = {};
		List<ValueTxtView> list = this.queryBySQL(sql, params, null,
				new CommonRowMapper(new ValueTxtView()));
		return list;
	}
	
	@Override
	public List<LogisticsTemplatePrice> getLogisticsTemplatePriceList(
			QueryConditions qc, PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("LogisticsRateDao_013");
		Object[] params = {};
		List<LogisticsTemplatePrice> list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new LogisticsTemplatePrice()));
		return list;
	}
	
	@Override
	public int deleteLogisticsTemplatePrice(String logisticsTemplatePriceID) {
		String sql = "delete from T_LogisticsTemplatePrice where ID in("+logisticsTemplatePriceID+")";
		Object[] params = {};
		int returnCode;
		try {
			returnCode = this.updateBySQL(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			returnCode =-1;
		}
		return returnCode;
	}
	
	@Override
	public ValueTxtView getParentAreaByJuniorID(int juniorID) {
		String sql = "SELECT t2.ID as tagID,t2.Name as text  FROM T_LogisticsArea  t1 INNER JOIN T_LogisticsArea t2 "
				+ "ON t1.ParentID = t2.ID WHERE t1.ID ="+juniorID;
		Object[] params = {};
		ValueTxtView valueTxtView = (ValueTxtView)this.queryForObject(sql, params, new CommonRowMapper(new ValueTxtView()));
		return valueTxtView;
	}
	
	
	
	@Override
	public void rollBack() {
		try {
			getConnection().setAutoCommit(false);// 事务设置为手动
			getConnection().rollback();
		} catch (CannotGetJdbcConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
