package shcem.logistics.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * 物流配送费率产品分类表
 * @author zhangnan
 *
 */
public class LogisticsRateCategory extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 	ID									ID										
		费率分类ID							RateID										
		产品分类								CategoryLeafID										
		产品牌号								BrandID										
		产地								    SourcePlaceID										
		默认为 0：显示，1：不显示					DISABLED										
		创建人								REC_CREATEBY										
		创建时间								REC_CREATETIME										
		最后修改人								REC_MODIFYBY										
		最后修改时间							REC_MODIFYTIME										

	 */
	/*ID*/
	private Integer id;
	
	/*费率分类ID*/
	private Integer rateID;
	
	/*费率分类*/
	private Integer rate;
	
	/*运费金额（吨/元）*/
	private BigDecimal ratePrice;
	
	/*产品分类*/
	private Integer categoryLeafID;
	
	/*产品分类名称*/
	private Integer categoryLeafName;
	
	/*产品牌号*/
	private Integer brandID;
	
	/*产品牌号名称*/
	private Integer brandName;
	
	/*产地*/
	private Integer sourcePlaceID;
	
	/*产地*/
	private String sourcePlaceName;
	
	/*默认为 0：显示，1：不显示*/
	private Integer dISABLED;
	
	/*创建人*/
	private String rEC_CREATEBY;

	/*创建时间*/
	private Date  rEC_CREATETIME;
	
	/*最后修改人*/
	private String rEC_MODIFYBY;
	
	/*最后时间*/
	private Date  rEC_MODIFYTIME;
	
	/*分类-牌号*/
	private String goodName;
	
	
	
	
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getRateID() {
		return rateID;
	}

	public void setRateID(Integer rateID) {
		this.rateID = rateID;
	}

	public Integer getRate() {
		return rate;
	}

	public void setRate(Integer rate) {
		this.rate = rate;
	}

	public BigDecimal getRatePrice() {
		return ratePrice;
	}

	public void setRatePrice(BigDecimal ratePrice) {
		this.ratePrice = ratePrice;
	}

	public Integer getCategoryLeafID() {
		return categoryLeafID;
	}

	public void setCategoryLeafID(Integer categoryLeafID) {
		this.categoryLeafID = categoryLeafID;
	}

	public Integer getCategoryLeafName() {
		return categoryLeafName;
	}

	public void setCategoryLeafName(Integer categoryLeafName) {
		this.categoryLeafName = categoryLeafName;
	}

	public Integer getBrandID() {
		return brandID;
	}

	public void setBrandID(Integer brandID) {
		this.brandID = brandID;
	}

	public Integer getBrandName() {
		return brandName;
	}

	public void setBrandName(Integer brandName) {
		this.brandName = brandName;
	}

	public Integer getSourcePlaceID() {
		return sourcePlaceID;
	}

	public void setSourcePlaceID(Integer sourcePlaceID) {
		this.sourcePlaceID = sourcePlaceID;
	}

	public String getSourcePlaceName() {
		return sourcePlaceName;
	}

	public void setSourcePlaceName(String sourcePlaceName) {
		this.sourcePlaceName = sourcePlaceName;
	}

	public Integer getDISABLED() {
		return dISABLED;
	}

	public void setDISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	public String getGoodName() {
		return goodName;
	}

	public void setGoodName(String goodName) {
		this.goodName = goodName;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
