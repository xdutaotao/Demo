package shcem.logistics.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.Bidi;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * 物流运费模板价格
 * @author zhangnan
 *
 */
public class LogisticsTemplatePrice extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8668008959481855636L;

	/**/
	private Integer id;
	
	/*运费模板ID*/
	private Integer templateID;
	
	/*始发地ID*/
	private Integer startAreaID;
	
	/*始发名称*/
	private String startAreaName;
	
	/*目的地ID*/
	private Integer endAreaID;
	
	/*目的地名称*/
	private String endAreaName;
	
	/*区间最小重量*/
	private BigDecimal minWeight;
	
	/*区间最大重量*/
	private BigDecimal maxWeight;
	
	/*单价(运费 元/吨)*/
	private BigDecimal price;
	
	/*默认为 0：显示，1：不显示*/
	private Integer dISABLED;
	
	/*创建人*/
	private String rEC_CREATEBY;

	/*创建时间*/
	private Date  rEC_CREATETIME;
	
	/*最后修改人*/
	private String rEC_MODIFYBY;
	
	/*最后时间*/
	private Date  rEC_MODIFYTIME;
	
	/*费率大类*/
	private String templateBigName;
	
	/*费率细分*/
	private String templateName;
	
	/*目的地区域代码*/
	private String endAreaNo;
	
	/*excel每条记录流水号*/
	private Integer excelTemplateNum;
	
	/*该记录是否能入库*/
	private boolean logistics;
	
	/*品牌-牌号*/
	private String goodName;
	
	/*产地*/
	private String sourcePlaceName;
	
	/*物流区域路径*/
	private String path;
	
	/*序号*/
	private Integer sequenceNum;
	
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getTemplateID() {
		return templateID;
	}

	public void setTemplateID(Integer templateID) {
		this.templateID = templateID;
	}

	public Integer getStartAreaID() {
		return startAreaID;
	}

	public void setStartAreaID(Integer startAreaID) {
		this.startAreaID = startAreaID;
	}

	public String getStartAreaName() {
		return startAreaName;
	}

	public void setStartAreaName(String startAreaName) {
		this.startAreaName = startAreaName;
	}

	public Integer getEndAreaID() {
		return endAreaID;
	}

	public void setEndAreaID(Integer endAreaID) {
		this.endAreaID = endAreaID;
	}

	public String getEndAreaName() {
		return endAreaName;
	}

	public void setEndAreaName(String endAreaName) {
		this.endAreaName = endAreaName;
	}

	public BigDecimal getMinWeight() {
		return minWeight;
	}

	public void setMinWeight(BigDecimal minWeight) {
		this.minWeight = minWeight;
	}

	public BigDecimal getMaxWeight() {
		return maxWeight;
	}

	public void setMaxWeight(BigDecimal maxWeight) {
		this.maxWeight = maxWeight;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Integer getDISABLED() {
		return dISABLED;
	}

	public void setDISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getTemplateBigName() {
		return templateBigName;
	}

	public void setTemplateBigName(String templateBigName) {
		this.templateBigName = templateBigName;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getEndAreaNo() {
		return endAreaNo;
	}

	public void setEndAreaNo(String endAreaNo) {
		this.endAreaNo = endAreaNo;
	}

	public Integer getExcelTemplateNum() {
		return excelTemplateNum;
	}

	public void setExcelTemplateNum(Integer excelTemplateNum) {
		this.excelTemplateNum = excelTemplateNum;
	}

	public boolean isLogistics() {
		return logistics;
	}

	public void setLogistics(boolean logistics) {
		this.logistics = logistics;
	}

	public String getGoodName() {
		return goodName;
	}

	public void setGoodName(String goodName) {
		this.goodName = goodName;
	}

	public String getSourcePlaceName() {
		return sourcePlaceName;
	}

	public void setSourcePlaceName(String sourcePlaceName) {
		this.sourcePlaceName = sourcePlaceName;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public Integer getSequenceNum() {
		return sequenceNum;
	}

	public void setSequenceNum(Integer sequenceNum) {
		this.sequenceNum = sequenceNum;
	}

}
