package shcem.logistics.dao.model;

import java.io.Serializable;
import java.util.Date;

import shcem.base.dao.model.BaseObject;
/**
 * 物流配送费率表
 * @author zhangnan
 *
 */
public class LogisticsRate extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	/**/
	private Integer id;
	
	/*物流公司ID*/
	private Integer logisticsID;
	
	/*费率大类*/
	private String templateBigName;
	
	/*费率细分*/
	private String templateName;
	
	/*默认为 0：显示，1：不显示*/
	private Integer dISABLED;
	
	/*创建人*/
	private String rEC_CREATEBY;

	/*创建时间*/
	private Date  rEC_CREATETIME;
	
	/*最后修改人*/
	private String rEC_MODIFYBY;
	
	/*最后时间*/
	private Date  rEC_MODIFYTIME;
	
	/*产品分类*/
	private Integer categoryLeafID;
	
	/*产品牌号*/
	private Integer brandID;
	
	/*产地*/
	private Integer sourcePlaceID;
	
	/*产地名称*/
	private String sourcePlaceName;
	
	/*分类-牌号*/
	private String goodName;
	
	/*分类名*/
	private String categoryLeafName;
	
	/*牌号*/
	private String brandName;
	
	
	public Integer getCategoryLeafID() {
		return categoryLeafID;
	}

	public void setCategoryLeafID(Integer categoryLeafID) {
		this.categoryLeafID = categoryLeafID;
	}

	public Integer getBrandID() {
		return brandID;
	}

	public void setBrandID(Integer brandID) {
		this.brandID = brandID;
	}

	public Integer getSourcePlaceID() {
		return sourcePlaceID;
	}

	public void setSourcePlaceID(Integer sourcePlaceID) {
		this.sourcePlaceID = sourcePlaceID;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getLogisticsID() {
		return logisticsID;
	}

	public void setLogisticsID(Integer logisticsID) {
		this.logisticsID = logisticsID;
	}


	public Integer getDISABLED() {
		return dISABLED;
	}

	public void setDISABLED(Integer dISABLED) {
		this.dISABLED = dISABLED;
	}

	public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setrEC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getSourcePlaceName() {
		return sourcePlaceName;
	}

	public void setSourcePlaceName(String sourcePlaceName) {
		this.sourcePlaceName = sourcePlaceName;
	}

	public String getGoodName() {
		return goodName;
	}

	public void setGoodName(String goodName) {
		this.goodName = goodName;
	}

	public String getCategoryLeafName() {
		return categoryLeafName;
	}

	public void setCategoryLeafName(String categoryLeafName) {
		this.categoryLeafName = categoryLeafName;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getTemplateBigName() {
		return templateBigName;
	}

	public void setTemplateBigName(String templateBigName) {
		this.templateBigName = templateBigName;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

}
