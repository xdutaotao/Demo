package shcem.logistics.component;

import java.util.List;

import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.service.model.ValueTxtView;
import shcem.logistics.dao.model.CheckMessage;
import shcem.logistics.dao.model.LogisticsArea;
import shcem.logistics.dao.model.LogisticsRate;
import shcem.logistics.dao.model.LogisticsTemplatePrice;

public interface ILogisticsRateMgr {

	List<LogisticsRate> getLogisticsRateCategoryList(
			QueryConditions qc, PageInfo pageInfo);

	int addLogisticsRate(LogisticsRate logisticsRate, String userName);

	int disRepeat(String rateDetailName);

	List<ValueTxtView> getBrandList(String brandName);

	List<ValueTxtView> getSourcePlaceListByBrandID(int brandID);

	int updateLogisticsRate(LogisticsRate logisticsRate, String userName);

	int deleteLogisticsRateCategory(int[] logisticsRateCategoryIDArray);

	int importLogisticsRate(List<LogisticsRate> list, String userName);

	int importLogisticsArea(List<LogisticsArea> list, String userName);

	List<LogisticsArea> getLogisticsAreaList(QueryConditions qc,
			PageInfo pageInfo);

	CheckMessage checkLogisticsPriceTemplate(String url);

	List<LogisticsTemplatePrice> readLogisticsTemplatePriceToList(String url);

	int importLogisticsTemplatePrice(List<LogisticsTemplatePrice> list,
			String userName);

	List<ValueTxtView> getProvinceList(String leadsID);

	List<ValueTxtView> getProvinceAreaList(int proviceID, String queryType,int leadsID);

	List<ValueTxtView> getCityList(int proviceAreaID, String queryType, int leadsID);

	List<LogisticsTemplatePrice> getLogisticsTemplatePriceList(
			QueryConditions qc, PageInfo pageInfo);

	int deleteLogisticsTemplatePrice(long[] logisticsTemplatePriceIDs);

	ValueTxtView getParentAreaByJuniorID(int juniorID);

}
