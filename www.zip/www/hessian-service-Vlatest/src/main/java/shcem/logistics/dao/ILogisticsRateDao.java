package shcem.logistics.dao;

import java.util.List;

import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.common.service.model.ValueTxtView;
import shcem.logistics.dao.model.LogisticsArea;
import shcem.logistics.dao.model.LogisticsRate;
import shcem.logistics.dao.model.LogisticsRatePrice;
import shcem.logistics.dao.model.LogisticsTemplatePrice;

public interface ILogisticsRateDao {

	List<LogisticsRate> getLogisticsRateCategoryList(
			QueryConditions qc, PageInfo pageInfo);

	int addLogisticsRate(LogisticsRate logisticsRate, String userName);
	
	void rollBack();

	int addLogisticsRateCategory(int logisticsRateID,
			LogisticsRate logisticsRate, String userName);

	LogisticsRate getLogisticsRate(String rateDetailName);

	List<ValueTxtView> getBrandList(String brandName);

	List<ValueTxtView> getSourcePlaceListByBrandID(int brandID);

	int deleteLogisticsRateCategory(String logisticsRateCategoryIDs);

	int getLogisticsRateCategoryCount(Integer categoryLeafID, Integer brandID,Integer sourcePlaceID);

	int getCategoryLeafID(String categoryLeafName);

	int getBrandID(int categoryLeafID, String brandName);

	int getSourcePlaceID(String sourcePlaceName);

	int updateLogisticsRateCategory(int templateID, Integer categoryLeafID,
			Integer brandID, Integer sourcePlaceID, String userName);

	LogisticsArea getLogisticsAreaByProvinceName(String provinceName);

	int addLogisticsArea(LogisticsArea logisticsArea, String userName);

	int updateLogisticsAreaPath(String path, String userName, int provinceID);

	int getLogisticsAreaID(int parentID, int areaLevel, String logisticsAreaName);

	int updateLogisticsArea(LogisticsArea logisticsArea, int provinceID, String userName, String path_area);

	List<LogisticsArea> getLogisticsAreaList(QueryConditions qc,
			PageInfo pageInfo);

	List<LogisticsRate> getLogisticsRateByTemplateBigName(String templateBigName);

	LogisticsArea getLogisticsAreaByAreaNo(String endAreaNo);

	int getLogisticsTemplate(String templateBigName, String templateName);

	int getLogisticsAreaIDByAreaNo(String endAreaNo);

	String getEndAreaName(int areaID);

	int addLogisticsTemplatePrice(
			LogisticsTemplatePrice logisticsTemplatePrice, String userName);

	int getlogisticsTemplatePriceIDByTemplateIDAndendArEaID(int templateID,
			int endAreaID);

	int updateLogisticsTemplatePrice(
			LogisticsTemplatePrice logisticsTemplatePrice, String userName,int logisticsTemplatePriceID);

	List<ValueTxtView> getProvinceList(String leadsID);

	List<ValueTxtView> getProvinceAreaList(int proviceID, String queryType,int leadsID);

	List<ValueTxtView> getCityList(int proviceAreaID, String queryType, int leadsID);

	List<LogisticsTemplatePrice> getLogisticsTemplatePriceList(
			QueryConditions qc, PageInfo pageInfo);

	int deleteLogisticsTemplatePrice(String logisticsTemplatePriceID);

	ValueTxtView getParentAreaByJuniorID(int juniorID);

	int getLogisticsAreaIDByAreaNo(int parentID_provinceAreaID, int areaLevel,
			String areaNo);

	LogisticsArea getLogisticsAreaByAreaNoAndName(String endAreaNo,
			String endAreaName);

	LogisticsRate getlogisticsRateBytemplateBigNameAndtemplateName(
			String templateBigName, String templateName);

	int getLeafLogisticsAreaIDByAreaNo(int parentID_provinceAreaID, int i,
			String areaNo);
}
