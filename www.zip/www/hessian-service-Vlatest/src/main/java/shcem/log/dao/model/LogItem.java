/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: LogItem
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.log.dao.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import shcem.base.dao.model.BaseObject;
import shcem.base.service.model.Header;

/**
 * LogItem
 * 
 * @author chiyong
 * @version 1.0
 */
public class LogItem extends BaseObject implements Serializable {
	private static final long serialVersionUID = 1L;
	private String logid;
	private String logmsg;
	private String logexception;
	private String loglevel;
	private String loguser;
	private String logdiff;
	private Header header;

	public LogItem(String msg, Header header) {
		this.logmsg = header.getRequestId() + "</br>" + msg;
		this.logid = "";
		this.loguser = "";
		this.header = header;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof LogItem))
			return false;

		LogItem m = (LogItem) o;

		return this.logid != null ? this.logid.equals(m.logid) : m.logid == null;
	}

	public int hashCode() {
		return this.logid != null ? this.logid.hashCode() : 0;
	}

	public String getLogid() {
		return logid;
	}

	public void setLogid(String logid) {
		this.logid = logid;
	}

	public String getLogmsg() {
		return logmsg;
	}

	public void setLogmsg(String logmsg) {
		this.logmsg = logmsg;
	}

	public String getLoglevel() {
		return loglevel;
	}

	public void setLoglevel(String loglevel) {
		this.loglevel = loglevel;
	}

	public String getLoguser() {
		return loguser;
	}

	public void setLoguser(String loguser) {
		this.loguser = loguser;
	}

	public String getLogdiff() {
		return logdiff;
	}

	public void setLogdiff(String logdiff) {
		this.logdiff = logdiff;
	}

	public String getLogexception() {
		return logexception;
	}

	public void setLogexception(String logexception) {
		this.logexception = logexception;
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

}
