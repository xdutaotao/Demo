/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: LogServiceImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 05/19/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.log.service.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;

import shcem.base.service.model.Header;
import shcem.base.service.model.ResponseData;
import shcem.constant.Constants;
import shcem.constant.ResultCode;
import shcem.constant.ResultInfo;
import shcem.hessian.HessianHeaderContext;
import shcem.log.component.LogManager;
import shcem.log.dao.model.BusinessLogItem;
import shcem.log.dao.model.LogItem;
import shcem.log.dao.model.ServiceOpeLog;
import shcem.log.service.ILogService;
import shcem.log.util.LogSysData;

/**
 * LogServiceImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class LogServiceImpl implements ILogService {

	private ResponseData rtnData = new ResponseData();
	private Log log = null;
	private LogManager mgr = (LogManager) LogSysData.getBean(Constants.BEAN_LOG_MGR);
	private String logdif = "";
	private Header header = null;

	public LogServiceImpl() {
		// Default to service log level.
		this.logdif = "Servicelog";
		this.log = LogFactory.getLog(logdif);
	}

	public LogServiceImpl(String logdif) {
		this.logdif = logdif;
		this.log = LogFactory.getLog(logdif);
	}

	private void setHeader() {
		HessianHeaderContext context = HessianHeaderContext.getContext();
		this.header = new Header(context);
	}

	/**
	 * debug
	 * 
	 * @param msg
	 *            message
	 */
	public void debug(String msg) {
		this.log.debug(msg);

//		if (this.header == null) {
			setHeader();
//		}

		LogItem item = new LogItem(msg, this.header);

		try {
			item.setLoglevel(Constants.LOG_DEBUG);
			item.setLogdiff(this.logdif);

			mgr.insertLog(item);
		} catch (Exception err) {
			this.log.error("log debug error:" + err.getMessage());
		}
	}

	/**
	 * info
	 * 
	 * @param msg
	 *            message
	 */
	public void info(String msg) {
		this.log.info(msg);

//		if (this.header == null) {
			setHeader();
//		}

		LogItem item = new LogItem(msg, this.header);

		try {
			item.setLoglevel(Constants.LOG_INFO);
			item.setLogdiff(this.logdif);

			mgr.insertLog(item);
		} catch (Exception err) {
			this.log.error("log info error:" + err.getMessage());
		}
	}

	/**
	 * warn
	 * 
	 * @param msg
	 *            message
	 */
	public void warn(String msg) {
		this.log.warn(msg);

//		if (this.header == null) {
			setHeader();
//		}

		LogItem item = new LogItem(msg, this.header);

		try {
			item.setLoglevel(Constants.LOG_WARN);
			item.setLogdiff(this.logdif);

			mgr.insertLog(item);
		} catch (Exception err) {
			this.log.error("log warn error:" + err.getMessage());
		}
	}

	/**
	 * error
	 * 
	 * @param msg
	 *            message
	 */
	public void error(String msg) {
		this.log.error(msg);

//		if (this.header == null) {
			setHeader();
//		}

		LogItem item = new LogItem(msg, this.header);

		try {
			item.setLoglevel(Constants.LOG_ERROR);
			item.setLogdiff(this.logdif);

			mgr.insertLog(item);
		} catch (Exception err) {
			this.log.error("log err error:" + err.getMessage());
		}
	}

	/**
	 * business
	 * 
	 * @param msg
	 *            message
	 * @param mode
	 *            operation type
	 */
	public void businesslog(String msg, String mode, int status) {
		this.log.info(msg);

//		if (this.header == null) {
			setHeader();
//		}

		BusinessLogItem item = new BusinessLogItem(msg, this.header);

		try {
			item.setLogmode(mode);
			item.setLogdiff(this.logdif);
			item.setStatus(status);

			mgr.insertBusinessLog(item);
		} catch (Exception err) {
			this.log.error("business log error:" + err.getMessage());
		}
	}

	/**
	 * Service ope log
	 * 
	 * @param params
	 *            params
	 */
	public String recordSrvOpe(String params) {

		this.log.info(this.getClass().getName() + " recordSrvOpe() Start");

		JSONObject JOParams = new JSONObject(params);
		String serviceName = JOParams.getString("ServiceName");
		String methodName = JOParams.getString("MethodName");
		String appName = JOParams.getString("AppName");
		String result = JOParams.getString("Result");
		String comment = JOParams.getString("Comment");

		boolean ret = false;
		ServiceOpeLog item = new ServiceOpeLog();
		item.setServiceName(serviceName);
		item.setMethodName(methodName);
		item.setAppName(appName);
		item.setResult(result);
		item.setComment(comment);
		
		try {
			mgr.insertSvcOpeLog(item);
			ret = true;
		} catch (Exception err) {
			this.log.error("更新服务操作表出错" + err.getMessage());
			setResultData("10106", err.getMessage());
		}

		if (ret) {
			setResultData("00000");
		}

		this.log.info(this.getClass().getName() + " recordSrvOpe() End");

		return this.rtnData.toString();
	}

	protected void setResultData(String code, String... args) {

		ResultCode rstCd = Enum.valueOf(ResultCode.class, "CODE" + code);
		ResultInfo rstInfo = Enum.valueOf(ResultInfo.class, "CODE" + code);
		StringBuffer sbInfo = new StringBuffer(args.length + 1);

		sbInfo.append(rstInfo.getValue());
		for (int i = 0; i < args.length; i++) {
			sbInfo.append(args[i]);
		}

		this.rtnData.setCODE(rstCd.getValue());
		this.rtnData.setINFO(sbInfo.toString());
		this.rtnData.setDATA(null);
	}
}