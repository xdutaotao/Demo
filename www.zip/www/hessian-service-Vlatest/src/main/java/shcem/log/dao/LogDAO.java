/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: LogDAO
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.log.dao;

import shcem.log.dao.model.BusinessLogItem;
import shcem.log.dao.model.LogItem;
import shcem.log.dao.model.ServiceOpeLog;

/**
 * LogDAO
 * 
 * @author chiyong
 * @version 1.0
 */
public abstract interface LogDAO {

	/**
	 * 更新日志表
	 * 
	 * @param paramLogItem
	 *            logItem
	 */
	public abstract void insertLog(LogItem paramLogItem);
	
	/**
	 * 更新业务日志表
	 * 
	 * @param paramLogItem
	 *            logItem
	 */
	public abstract void insertBusinessLog(BusinessLogItem paramLogItem);
	
	/**
	 * 更新服务操作日志表
	 * 
	 * @param paramLogItem
	 *            logItem
	 */
	public abstract void insertSvcOpeLog(ServiceOpeLog paramLogItem);
}
