/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: LogManagerImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.log.component.impl;

import shcem.log.component.LogManager;
import shcem.log.dao.LogDAO;
import shcem.log.dao.model.BusinessLogItem;
import shcem.log.dao.model.LogItem;
import shcem.log.dao.model.ServiceOpeLog;

/**
 * LogManagerImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class LogManagerImpl implements LogManager {

	private LogDAO dao;

	public void setLogDAO(LogDAO dao) {
		this.dao = dao;
	}

	/**
	 * 更新日志表
	 * 
	 * @param paramLogItem
	 *            logItem
	 */
	public void insertLog(LogItem paramLogItem) {
		this.dao.insertLog(paramLogItem);
	}

	/**
	 * 更新业务日志表
	 * 
	 * @param paramLogItem
	 *            logItem
	 */
	public void insertBusinessLog(BusinessLogItem paramLogItem) {
		this.dao.insertBusinessLog(paramLogItem);
	}
	
	/**
	 * 更新服务操作日志表
	 * 
	 * @param paramLogItem
	 *            logItem
	 */
	public void insertSvcOpeLog(ServiceOpeLog paramLogItem) {
		this.dao.insertSvcOpeLog(paramLogItem);
	}
}
