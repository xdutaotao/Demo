/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: ILogService
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 05/19/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.log.service;

/**
 * ILogService
 * 
 * @author chiyong
 * @version 1.0
 */
public interface ILogService {

	/**
	 * debug
	 * 
	 * @param msg
	 *            message
	 */
	public void debug(String msg);

	/**
	 * info
	 * 
	 * @param msg
	 *            message
	 */
	public void info(String msg);

	/**
	 * warn
	 * 
	 * @param msg
	 *            message
	 */
	public void warn(String msg);

	/**
	 * error
	 * 
	 * @param msg
	 *            message
	 */
	public void error(String msg);

	/**
	 * business
	 * 
	 * @param msg
	 *            message
	 * @param mode
	 *            operation type
	 */
	public void businesslog(String msg, String mode, int status);
	
	/**
	 * Service ope log
	 * 
	 * @param params
	 *            params
	 */
	public String recordSrvOpe(String params);
}