/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: LogDAOImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.log.dao.impl;

import java.util.Properties;

import netty.NettyLogClient;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import shcem.constant.Constants;
import shcem.log.dao.LogDAO;
import shcem.log.dao.model.BusinessLogItem;
import shcem.log.dao.model.LogItem;
import shcem.log.dao.model.ServiceOpeLog;
import shcem.util.PropertyUtil;

/**
 * LogDAOImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class LogDAOImpl extends JdbcDaoSupport implements LogDAO {

	private Log log = null;
	private Properties sqlProperty;
	private PropertyUtil propUtil = new PropertyUtil();
	
	/**
	 * 更新日志表
	 * 
	 * @param paramLogItem
	 *            logItem
	 */
	public void insertLog(LogItem paramLogItem) {

//		this.log = LogFactory.getLog(paramLogItem.getLogdiff());
//
//		sqlProperty = propUtil.getProperties(Constants.SQL_PROPERTY);
//
//		String sql = sqlProperty.getProperty("LogDAO_001");
//
//		Object[] params = { paramLogItem.getLoglevel(), paramLogItem.getLogmsg(), "",
//				paramLogItem.getHeader().getMemberID(), paramLogItem.getHeader().getAppName(),
//				paramLogItem.getHeader().getClientIP() };
//
//		try {
//			// 日志表更新
//			getJdbcTemplate().update(sql, params);
//		} catch (Exception e) {
//			e.printStackTrace();
//			this.log.error(e.getMessage());
//			throw new RuntimeException("更新日志失败！");
//		}
		
		NettyLogClient.sendMsg(paramLogItem.getHeader().getMode(), paramLogItem);
	}

	/**
	 * 更新业务日志表
	 * 
	 * @param paramLogItem
	 *            logItem
	 */
	public void insertBusinessLog(BusinessLogItem paramLogItem) {

//		this.log = LogFactory.getLog(paramLogItem.getLogdiff());
//
//		sqlProperty = propUtil.getProperties(Constants.SQL_PROPERTY);
//
//		String sql = sqlProperty.getProperty("LogDAO_002");
//
//		Object[] params = { paramLogItem.getLogmode(), paramLogItem.getLogmsg(), paramLogItem.getHeader().getMemberID(),
//				paramLogItem.getHeader().getAppName(), paramLogItem.getHeader().getClientIP(),
//				paramLogItem.getStatus() };
//
//		try {
//			// 业务日志表更新
//			getJdbcTemplate().update(sql, params);
//		} catch (Exception e) {
//			e.printStackTrace();
//			this.log.error(e.getMessage());
//			throw new RuntimeException("更新业务日志失败！");
//		}
		
		NettyLogClient.sendBusinessMsg(paramLogItem.getHeader().getMode(), paramLogItem);
	}

	/**
	 * 更新服务操作日志表
	 * 
	 * @param paramLogItem
	 *            logItem
	 */
	public void insertSvcOpeLog(ServiceOpeLog paramLogItem) {

		sqlProperty = propUtil.getProperties(Constants.SQL_PROPERTY);

		String sql = sqlProperty.getProperty("LogDAO_003");

		Object[] params = { paramLogItem.getServiceName(), paramLogItem.getMethodName(), paramLogItem.getAppName(),
				paramLogItem.getResult(), paramLogItem.getComment() };

		try {
			// 服务操作日志表更新
			getJdbcTemplate().update(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error(e.getMessage());
			throw new RuntimeException("服务操作日志表失败！");
		}
	}
}
