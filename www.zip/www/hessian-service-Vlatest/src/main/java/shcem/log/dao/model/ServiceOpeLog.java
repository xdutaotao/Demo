/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: ServiceOpeLog
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 06/15/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.log.dao.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import shcem.base.dao.model.BaseObject;

/**
 * ServiceOpeLog
 * 
 * @author chiyong
 * @version 1.0
 */
public class ServiceOpeLog extends BaseObject implements Serializable {

	private static final long serialVersionUID = 1L;

	private String id;
	private String opeDate;
	private String serviceName;
	private String methodName;
	private String appName;
	private String result;
	private String comment;

	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof ServiceOpeLog))
			return false;

		ServiceOpeLog m = (ServiceOpeLog) o;

		return this.id != null ? this.id.equals(m.id) : m.id == null;
	}

	public int hashCode() {
		return this.id != null ? this.id.hashCode() : 0;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOpeDate() {
		return opeDate;
	}

	public void setOpeDate(String opeDate) {
		this.opeDate = opeDate;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getMethodName() {
		return methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

}
