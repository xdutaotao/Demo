/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IPdClassifyManager
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.product.component;

import java.util.List;
import java.util.Map;

import shcem.base.component.Manager;
import shcem.product.dao.PdClassifyDAO;

/**
 * IPdClassifyManager
 * 
 * @author chiyong
 * @version 1.0
 */
public abstract interface IPdClassifyManager extends Manager{
	
	public abstract void setPdClassifyDAO(PdClassifyDAO paramPdClassifyDAO);

	/**
	 * ȡ�ò�Ʒ������
	 * 
	 * @return ȡ�ò�Ʒ������
	 */
	public abstract List<Map<String, Object>> getPdClassifyTree();

	/**
	 * �趨ר���Ĳ�Ʒ��������
	 * 
	 * @param params
	 *            params
	 * @return �趨��� true:�ɹ�,false:ʧ��
	 */
	public abstract String updatePdClassify(String params);
}
