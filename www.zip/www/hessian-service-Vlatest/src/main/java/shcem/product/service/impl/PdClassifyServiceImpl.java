/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: PdClassifyServiceImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.product.service.impl;

import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.product.component.IPdClassifyManager;
import shcem.product.service.IPdClassifyService;
import shcem.product.util.ProductSysData;

/**
 * PdClassifyServiceImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class PdClassifyServiceImpl extends BaseServiceImpl implements IPdClassifyService {

	/**
	 * ȡ�ò�Ʒ������
	 * 
	 * @return ȡ�ò�Ʒ������
	 */
	public String getPdClassifyTree() {

		this.log.info(this.getClass().getName() + " getPdClassifyTree() Start");

		IPdClassifyManager mgr = (IPdClassifyManager) ProductSysData.getBean(Constants.BEAN_PDCLASSIFY_MGR);

		// TODO

		this.log.info(this.getClass().getName() + " getPdClassifyTree() End");
		return rtnData.toString();
	}

	/**
	 * �趨ר���Ĳ�Ʒ�������
	 * 
	 * @param params
	 *            params
	 * @return �趨��� true:�ɹ�,false:ʧ��
	 */
	public String setPdClassifyAlias(String params) {
		this.log.info(this.getClass().getName() + " setPdClassifyAlias() Start");

		// TODO

		this.log.info(this.getClass().getName() + " setPdClassifyAlias() End");
		return this.rtnData.toString();
	}

	/**
	 * �趨ר���Ĳ�Ʒ�����Ƿ���ʾ
	 * 
	 * @param params
	 *            params
	 * @return �趨��� true:�ɹ�,false:ʧ��
	 */
	public String setPdClassifyDisp(String params) {
		this.log.info(this.getClass().getName() + " setPdClassifyDisp() Start");

		// TODO

		this.log.info(this.getClass().getName() + " setPdClassifyDisp() End");
		return this.rtnData.toString();
	}

}