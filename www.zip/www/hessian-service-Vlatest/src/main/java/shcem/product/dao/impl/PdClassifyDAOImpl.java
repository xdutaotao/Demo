/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: PdClassifyDAOImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.product.dao.impl;

import java.util.List;
import java.util.Map;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.product.dao.PdClassifyDAO;

/**
 * PdClassifyDAOImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class PdClassifyDAOImpl extends BaseDAOImpl implements PdClassifyDAO {

	/**
	 * ȡ�ò�Ʒ������
	 * 
	 * @return ȡ�ò�Ʒ������
	 */
	public List<Map<String, Object>> getPdClassifyTree() {
		this.log.debug("getPdClassifyTree DAO Start");
		// TODO
		
		return null;
	}

	/**
	 * �趨ר���Ĳ�Ʒ��������
	 * 
	 * @param params
	 *            params
	 * @return �趨��� true:�ɹ�,false:ʧ��
	 */
	public String updatePdClassify(String params) {
		// TODO
		return null;
	}

}
