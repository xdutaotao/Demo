/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: PdClassifyServiceModel
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.product.service.model;

import java.io.Serializable;
import java.util.Hashtable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.json.JSONObject;

import shcem.base.service.model.BaseServiceObject;

/**
 * PdClassifyServiceModel
 * 
 * @author chiyong
 * @version 1.0
 */
public class PdClassifyServiceModel extends BaseServiceObject implements Serializable {

	private static final long serialVersionUID = 3690197650654049810L;

	// ����A�����keyCode
	private String id;

	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof PdClassifyServiceModel))
			return false;

		PdClassifyServiceModel m = (PdClassifyServiceModel) o;

		return this.id != null ? this.id.equals(m.id) : m.id == null;
	}

	public int hashCode() {
		return this.id != null ? this.id.hashCode() : 0;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public JSONObject toJSONObject() {

		Hashtable<String, Object> tb = new Hashtable<String, Object>();
		tb.put("id", this.id == null ? "" : this.id);

		return new JSONObject(tb);
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
