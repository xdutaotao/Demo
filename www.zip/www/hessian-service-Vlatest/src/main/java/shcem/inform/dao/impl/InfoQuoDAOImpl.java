/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: InfoQuoDAOImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永     Create
 * 06/02/16 　刘洪波  Real 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.dao.impl;

import java.util.Date;
import java.util.List;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.inform.dao.InfoQuoDAO;
import shcem.inform.dao.model.MarketQuo;
import shcem.inform.dao.model.ScemQuo;
import shcem.util.CommonRowMapper;

/**
 * InfoQuoDAOImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class InfoQuoDAOImpl extends BaseDAOImpl implements InfoQuoDAO {

	/**
	 * 
	 */
	public List<MarketQuo> getMarketQuoList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getMarketQuoList DAO Start");
		String sql = sqlProperty.getProperty("QueDAO_001");
		return queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new MarketQuo()));
	}
	
	/**
	 * 
	 */
	public MarketQuo getMarketQuoById(String strId) {
		this.log.debug("getMarketQuoById DAO Start");
		String sql = sqlProperty.getProperty("QueDAO_002");
		this.log.debug("QueDAO_002_Sql: " + sql);
		Object[] params = new Object[] {Integer.parseInt(strId)};
		this.log.debug("params: " + strId);
		return (MarketQuo) queryForObject(sql, params, new CommonRowMapper(new MarketQuo()));
	}
	
	/**
	 * 
	 */
	public List<MarketQuo> getStartEndDateMarketQuoList(Date startDate, Date endDate) {
		this.log.debug("getStartEndDateMarketQuoList DAO Start");
		String sql = sqlProperty.getProperty("QueDAO_003");
		this.log.debug("QueDAO_003_Sql: " + sql);
		Object[] params = new Object[] {startDate, endDate};
		return queryBySQL(sql, params, null, new CommonRowMapper(new MarketQuo()));
	}

	/**
	 * 
	 */
	public int insertMarketQuo(MarketQuo mQuo) {
		this.log.debug("insertMarketQuo DAO Start");
		String sql = sqlProperty.getProperty("QueDAO_004");
		Object[] params = { mQuo.getMqType(), mQuo.getMqDeliverydate() == null ? 0 : mQuo.getMqDeliverydate(),
				mQuo.getMqPrice(),mQuo.getMqWave(),
				mQuo.getREC_CREATEBY(),
				mQuo.getREC_MODIFYBY() };

		this.log.debug("QueDAO_004_Sql: " + sql);
		for (int i = 0; i < params.length; i++) {
			this.log.debug("params[" + i + "]: " + params[i]);
		}
		try {
			return getJdbcTemplate().update(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error(e.getMessage());
			throw new RuntimeException("市场行情添加失败！");
		}
	}

	/**
	 * 
	 */
	public int updateMarketQuo(MarketQuo mQuo) {
		this.log.debug("updateMarketQuo DAO Start");
		String sql = sqlProperty.getProperty("QueDAO_005");
		Object[] params = { mQuo.getMqType(), mQuo.getMqDeliverydate() == null ? 0 : mQuo.getMqDeliverydate(), 
				mQuo.getMqPrice(), mQuo.getMqWave(), mQuo.getREC_MODIFYBY(), mQuo.getId() };
		this.log.debug("QueDAO_005_SQL: " + sql);
		for (int i = 0; i < params.length; i++) {
			this.log.debug("params[" + i + "]: " + params[i]);
		}
		try {
			return getJdbcTemplate().update(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error(e.getMessage());
			throw new RuntimeException("市场行情更新失败！");
		}
	}

	/**
	 *
	 */
	public int deleteMarketQuo(String strId) {
		this.log.debug("deleteMarketQuo DAO Start");
		String sql = sqlProperty.getProperty("QueDAO_006");
		Object[] params = { strId };
		this.log.debug("QueDAO_006_Sql: " + sql);
		
		try {
			return getJdbcTemplate().update(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error(e.getMessage());
			throw new RuntimeException("市场行情删除失败！");
		}
	}

	/**
	 * 
	 */
	public List<ScemQuo> getScemQuo(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getScemQuo DAO Start");
		String sql = sqlProperty.getProperty("ScemQuoDAO_001");
		return queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new ScemQuo()));
	}
	
	/**
	 * 
	 */
	public List<ScemQuo> getScemQuoHistory(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getScemQuoHistory DAO Start");
		String sql = sqlProperty.getProperty("ScemQuoHistoryDAO_001");
		return queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new ScemQuo()));
	}
	
	/**
	 * 
	 */
	public int isHaveScemQuoByDate(Date date, Integer sqTag) {
		this.log.debug("isHaveScemQuoByDate DAO Start");
		String sql = sqlProperty.getProperty("ScemQuoDAO_002");
		this.log.debug("ScemQuoDAO_002_Sql: " + sql);
		Object[] params = new Object[] { date,sqTag };
		return queryForInt(sql, params);
	}
	
	/**
	 *
	 */
	public int delScemQuo(Date date, Integer sqTag) {
		this.log.debug("delScemQuo DAO Start");
		String sql = sqlProperty.getProperty("ScemQuoDAO_003");
		Object[] params =  new Object[] { date,sqTag };
		for (int i = 0; i < params.length; i++) {
			this.log.debug("params[" + i + "]: " + params[i]);
		}
		try {
			return getJdbcTemplate().update(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error(e.getMessage());
			throw new RuntimeException("化交价格删除失败！");
		}
	}
	
	/**
	 *
	 */
	public int delScemQuoHistory(Date date, Integer sqTag) {
		this.log.debug("delScemQuoHistory DAO Start");
		String sql = sqlProperty.getProperty("ScemQuoDAO_004");
		Object[] params =  new Object[] { date,sqTag };
		for (int i = 0; i < params.length; i++) {
			this.log.debug("params[" + i + "]: " + params[i]);
		}
		try {
			return getJdbcTemplate().update(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error(e.getMessage());
			throw new RuntimeException("化交价格历史表删除失败！");
		}
	}
	
	/**
	 * 
	 */
	public int insertScemQuo(List<ScemQuo> scemQuoList) {
		this.log.debug("insertScemQuo DAO Start");
		String sql = sqlProperty.getProperty("ScemQuoDAO_005");
		this.log.debug("ScemQuoDAO_005_Sql: " + sql);
		int rtn = 0;
		for (ScemQuo sq: scemQuoList) {
			Object[] params = {
					sq.getSqDate(), sq.getSqProduct(), sq.getSqRank(), sq.getSqNo(), sq.getSqType(), 
					sq.getSqFactory(),sq.getSqTag(), sq.getSqArea(), sq.getSqMinPrice(),sq.getSqMaxPrice(), sq.getSqDropRange(), sq.getSqUpRange(),sq.getREC_CREATEBY()};
			for (int i = 0; i < params.length; i++) {
				this.log.debug("params[" + i + "]: " + params[i]);
			}
			try {
				rtn = rtn + getJdbcTemplate().update(sql, params);
			} catch (Exception e) {
				e.printStackTrace();
				this.log.error(e.getMessage());
				throw new RuntimeException("化交价格添加失败！");
			}
		}
		return rtn;
	}
	
	/**
	 * 
	 */
	public int insertScemQuoHistory(List<ScemQuo> scemQuoList) {
		this.log.debug("insertScemQuoHistory DAO Start");
		String sql = sqlProperty.getProperty("ScemQuoDAO_006");
		this.log.debug("ScemQuoDAO_006_Sql: " + sql);
		int rtn = 0;
		for (ScemQuo sq: scemQuoList) {
			Object[] params = {
					sq.getSqDate(), sq.getSqProduct(), sq.getSqRank(), sq.getSqNo(), sq.getSqType(), 
					sq.getSqFactory(),sq.getSqTag(), sq.getSqArea(), sq.getSqMinPrice(),sq.getSqMaxPrice(), sq.getSqDropRange(), sq.getSqUpRange(),sq.getREC_CREATEBY()};
			for (int i = 0; i < params.length; i++) {
				this.log.debug("params[" + i + "]: " + params[i]);
			}
			try {
				rtn = rtn + getJdbcTemplate().update(sql, params);
			} catch (Exception e) {
				e.printStackTrace();
				this.log.error(e.getMessage());
				throw new RuntimeException("化交价格历史表添加失败！");
			}
		}
		return rtn;
	}
	
	/**
	 * 
	 */
	public int isScemQuoNull(Integer sqTag) {
		this.log.debug("isScemQuoNull DAO Start");
		String sql = sqlProperty.getProperty("ScemQuoDAO_007");
		this.log.debug("ScemQuoDAO_002_Sql: " + sql);
		Object[] params =  new Object[] { sqTag };
		return queryForInt(sql, params);
	}
	
	/**
	 * 
	 */
	public ScemQuo getScemQuoById(String strId) {
		this.log.debug("getScemQuoById DAO Start");
		String sql = sqlProperty.getProperty("ScemQuoDAO_008");
		this.log.debug("ScemQuoDAO_008_Sql: " + sql);
		Object[] params = new Object[] {Integer.parseInt(strId)};
		this.log.debug("params: " + strId);
		return (ScemQuo) queryForObject(sql, params, new CommonRowMapper(new ScemQuo()));
	}
	
	/**
	 * 
	 */
	public int updateScemQuo(ScemQuo sq) {
		this.log.debug("updateScemQuo DAO Start");
		String sql = sqlProperty.getProperty("ScemQuoDAO_009");
		Object[] params = { sq.getSqMinPrice() == null ? 0 : sq.getSqMinPrice(), 
				sq.getSqMaxPrice() == null ? 0 : sq.getSqMaxPrice(), 
				sq.getSqDropRange() == null ? 0 : sq.getSqDropRange(), 
				sq.getSqUpRange() == null ? 0 : sq.getSqUpRange(), 
				sq.getREC_CREATEBY(), sq.getId() };
		this.log.debug("ScemQuoDAO_009_SQL: " + sql);
		for (int i = 0; i < params.length; i++) {
			this.log.debug("params[" + i + "]: " + params[i]);
		}
		try {
			return getJdbcTemplate().update(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error(e.getMessage());
			throw new RuntimeException("化交价格行情失败！");
		}
	}

	/**
	 * 
	 */
	public ScemQuo getScemQuoHistoryById(String strId) {
		this.log.debug("getScemQuoHistoryById DAO Start");
		String sql = sqlProperty.getProperty("ScemQuoHistoryDAO_002");
		this.log.debug("ScemQuoHistoryDAO_002_Sql: " + sql);
		Object[] params = new Object[] {Integer.parseInt(strId)};
		this.log.debug("params: " + strId);
		return (ScemQuo) queryForObject(sql, params, new CommonRowMapper(new ScemQuo()));
	}
	
	/**
	 * 
	 */
	public int updateScemQuoHistory(ScemQuo sq) {
		this.log.debug("updateScemQuoHistory DAO Start");
		String sql = sqlProperty.getProperty("ScemQuoHistoryDAO_003");
		Object[] params = { sq.getSqMinPrice() == null ? 0 : sq.getSqMinPrice(), 
				sq.getSqMaxPrice() == null ? 0 : sq.getSqMaxPrice(), 
				sq.getSqDropRange() == null ? 0 : sq.getSqDropRange(), 
				sq.getSqUpRange() == null ? 0 : sq.getSqUpRange(), 
				sq.getREC_CREATEBY(), sq.getId() };
		this.log.debug("ScemQuoHistoryDAO_003_SQL: " + sql);
		for (int i = 0; i < params.length; i++) {
			this.log.debug("params[" + i + "]: " + params[i]);
		}
		try {
			return getJdbcTemplate().update(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error(e.getMessage());
			throw new RuntimeException("化交价格行情历史失败！");
		}
	}

	/**
	 * 
	 */
	public List<ScemQuo> getScemQuoByHistoryId(String strId) {
		this.log.debug("getScemQuoByHistoryId DAO Start");
		String sql = sqlProperty.getProperty("ScemQuoDAO_010");
		this.log.debug("ScemQuoDAO_010_Sql: " + sql);
		Object[] params = new Object[] {Integer.parseInt(strId)};
		this.log.debug("params: " + strId);
		return queryBySQL(sql, params, null, new CommonRowMapper(new ScemQuo()));
	}
}
