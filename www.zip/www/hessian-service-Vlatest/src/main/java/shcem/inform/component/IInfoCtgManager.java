/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IInfoCtgManager
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 06/06/16 　刘洪波   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.component;

import java.util.List;

import shcem.base.component.Manager;
import shcem.inform.dao.InfoCtgDAO;
import shcem.inform.dao.model.InfoCatogory;

/**
 * IInfoCtgManager
 * 
 * @author liuhongbo
 * @version 1.0
 */
public abstract interface IInfoCtgManager extends Manager {

	public abstract void setInfoCtgDAO(InfoCtgDAO paramInfoCtgDAO);

	/**
	 * 
	 */
	public abstract List<InfoCatogory> getAllInfoCatogoryList();
	
	/**
	 * 
	 */
	public abstract InfoCatogory getInfoCatogoryById(String strId);

	/**
	 * 
	 */
	public abstract int addInfoCatogory(InfoCatogory params);

	/**
	 * 
	 */
	public abstract int updInfoCatogory(InfoCatogory params);

	/**
	 * 
	 */
	public abstract int delInfoCatogory(InfoCatogory iCtg);

}
