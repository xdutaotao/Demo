/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: InfoOraDAOImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.dao.impl;

import java.util.List;

import shcem.base.dao.DaoHelperForOra;
import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.inform.dao.InfoOraDAO;
import shcem.inform.dao.model.HqOra;
import shcem.inform.util.InformOraSysData;
import shcem.util.CommonRowMapper;

/**
 * @author wlpod
 *
 */
public class InfoOraDAOImpl extends BaseDAOImpl implements InfoOraDAO {

	@Override
	public List<HqOra> getHqList(QueryConditions qc, PageInfo pageInfo) {
		this.log.debug("getHqList DAO Start");
		String sql = sqlProperty.getProperty("InfoOraDAO_001");
		Object[] params = new Object[] {};

		DaoHelperForOra dbhelper = (DaoHelperForOra) InformOraSysData.getBean("daoHelperForOra");
		return dbhelper.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new HqOra()));
	}

}
