/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: Quotation
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.dao.model;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import shcem.base.dao.model.BaseObject;

/**
 * Quotation
 * @author chiyong
 * @version 1.0
 */
public class Quotation extends BaseObject implements Serializable {
    /** 版本号 */
    private static final long serialVersionUID = -8736134629117137485L;
    
    /**  */
    private String id;
    
    /**  */
    private String title;
    
    /**  */
    private String infoKeyword;
    
    /**  */
    private String infoLinkId;
    
    /**  */
    private Integer infoStatus;
    
    /**  */
    private Date postTime;
    
    /**  */
    private String rECCREATEBY;
    
    /**  */
    private Date rECCREATETIME;
    
    /**  */
    private String rECMODIFYBY;
    
    /**  */
    private Date rECMODIFYTIME;
    
    //拓展属性
    
    
    
    


	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getInfoKeyword() {
		return infoKeyword;
	}

	public void setInfoKeyword(String infoKeyword) {
		this.infoKeyword = infoKeyword;
	}

	public String getInfoLinkId() {
		return infoLinkId;
	}

	public void setInfoLinkId(String infoLinkId) {
		this.infoLinkId = infoLinkId;
	}

	public Integer getInfoStatus() {
		return infoStatus;
	}

	public void setInfoStatus(Integer infoStatus) {
		this.infoStatus = infoStatus;
	}

	public Date getPostTime() {
		return postTime;
	}

	public void setPostTime(Date postTime) {
		this.postTime = postTime;
	}

	public String getrECCREATEBY() {
		return rECCREATEBY;
	}

	public void setrECCREATEBY(String rECCREATEBY) {
		this.rECCREATEBY = rECCREATEBY;
	}

	public Date getrECCREATETIME() {
		return rECCREATETIME;
	}

	public void setrECCREATETIME(Date rECCREATETIME) {
		this.rECCREATETIME = rECCREATETIME;
	}

	public String getrECMODIFYBY() {
		return rECMODIFYBY;
	}

	public void setrECMODIFYBY(String rECMODIFYBY) {
		this.rECMODIFYBY = rECMODIFYBY;
	}

	public Date getrECMODIFYTIME() {
		return rECMODIFYTIME;
	}

	public void setrECMODIFYTIME(Date rECMODIFYTIME) {
		this.rECMODIFYTIME = rECMODIFYTIME;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof Quotation))
			return false;

		Quotation m = (Quotation) o;

		return this.id != null ? this.id.equals(m.id) : m.id == null;
	}

	public int hashCode() {
		return this.id != null ? this.id.hashCode() : 0;
	}
}
