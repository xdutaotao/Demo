/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: InfoQuoServiceModel
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 05/17/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.service.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Hashtable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.json.JSONObject;

import shcem.base.service.model.BaseServiceObject;

/**
 * InfoQuoServiceModel
 * 
 * @author chiyong
 * @version 1.0
 */
public class InfoQuoServiceModel extends BaseServiceObject implements Serializable {

	private static final long serialVersionUID = 1L;

    /**  */
    private String id;
    
    /**  */
    private String mqType;
    
    /**  */
    private Integer mqDeliverydate;
    
    /**  */
    private BigDecimal mqPrice;
    
    /**  */
    private BigDecimal mqWave;
    
    /**  */
    private String REC_CREATEBY;
    
    /**  */
    private Date REC_CREATETIME;
    
    /**  */
    private String REC_MODIFYBY;
    
    /**  */
    private Date REC_MODIFYTIME;
    
    /**
     * 获取id
     * 
     * @return id
     */
     public String getId() {
        return this.id;
     }
     
    /**
     * 设置id
     * 
     * @param id
     *          id
     */
     public void setId(String id) {
        this.id = id;
     }
    
	public String getMqType() {
		return mqType;
	}

	public void setMqType(String mqType) {
		this.mqType = mqType;
	}

	public Integer getMqDeliverydate() {
		return mqDeliverydate;
	}

	public void setMqDeliverydate(Integer mqDeliverydate) {
		this.mqDeliverydate = mqDeliverydate;
	}

	public BigDecimal getMqPrice() {
		return mqPrice;
	}

	public void setMqPrice(BigDecimal mqPrice) {
		this.mqPrice = mqPrice;
	}

	public BigDecimal getMqWave() {
		return mqWave;
	}

	public void setMqWave(BigDecimal mqWave) {
		this.mqWave = mqWave;
	}

	public String getREC_CREATEBY() {
		return REC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		REC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return REC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		REC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return REC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		REC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return REC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		REC_MODIFYTIME = rEC_MODIFYTIME;
	}

	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof InfoQuoServiceModel))
			return false;

		InfoQuoServiceModel m = (InfoQuoServiceModel) o;

		return this.id != null ? this.id.equals(m.id) : m.id == null;
	}
	
	public int hashCode() {
		return this.id != null ? this.id.hashCode() : 0;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public JSONObject toJSONObject() {

		Hashtable<String, Object> tb = new Hashtable<String, Object>();
		tb.put("ID", this.id == null ? "" : this.id);

		return new JSONObject(tb);
	}

}
