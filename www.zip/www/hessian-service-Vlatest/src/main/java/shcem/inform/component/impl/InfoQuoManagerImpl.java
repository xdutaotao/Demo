/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: InfoQuoManagerImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永     Create
 * 06/02/16 　刘洪波  Real
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.component.impl;

import java.util.Date;
import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.inform.component.IInfoQuoManager;
import shcem.inform.dao.InfoQuoDAO;
import shcem.inform.dao.model.MarketQuo;
import shcem.inform.dao.model.ScemQuo;

/**
 * InfoQuoManagerImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class InfoQuoManagerImpl extends BaseManager implements IInfoQuoManager {
	private InfoQuoDAO dao;
	private InfoQuoDAO infoQuoDAO_read;
	public void setInfoQuoDAO(InfoQuoDAO dao) {
		this.dao = dao;
	}

	public void setInfoQuoDAO_read(InfoQuoDAO infoQuoDAO_read) {
		this.infoQuoDAO_read = infoQuoDAO_read;
	}

	/**
	 * 
	 */
	public List<MarketQuo> getMarketQuoList(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getMarketQuoList component Start");
		return this.infoQuoDAO_read.getMarketQuoList(qc,pageInfo);
	}
	
	/**
	 * 
	 */
	public MarketQuo getMarketQuoById(String strId) {
		this.log.debug("getMarketQuoById component Start");
		return this.infoQuoDAO_read.getMarketQuoById(strId);
	}
	
	/**
	 * 
	 */
	public List<MarketQuo> getStartEndDateMarketQuoList(Date startDate, Date endDate) {
		this.log.debug("getStartEndDateMarketQuoList component Start");
		return this.infoQuoDAO_read.getStartEndDateMarketQuoList(startDate, endDate);
	}

	/**
	 * 
	 */
	public int insertMarketQuo(MarketQuo params) {
		this.log.debug("insertMarketQuo component Start");
		return this.dao.insertMarketQuo(params);
	}

	/**
	 * 
	 */
	public int updateMarketQuo(MarketQuo params) {
		this.log.debug("updateMarketQuo component Start");
		return this.dao.updateMarketQuo(params);
	}

	/**
	 * 
	 */
	public int deleteMarketQuo(String strId) {
		this.log.debug("deleteMarketQuo component Start");
		return this.dao.deleteMarketQuo(strId);
	}

	/**
	 * 
	 */
	public List<ScemQuo> getScemQuo(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getScemQuo component Start");
		return this.infoQuoDAO_read.getScemQuo(qc, pageInfo);
	}
	
	/**
	 * 
	 */
	public List<ScemQuo> getScemQuoHistory(QueryConditions qc,PageInfo pageInfo) {
		this.log.debug("getScemQuoHistory component Start");
		return this.infoQuoDAO_read.getScemQuoHistory(qc, pageInfo);
	}

	/**
	 * 
	 */
	public int insertScemQuo(List<ScemQuo> scemQuoList) {
		this.log.debug("insertScemQuo component Start");
		int rtn = 0;
		Date sqDate = scemQuoList.get(0).getSqDate();
		Integer sqTag = scemQuoList.get(0).getSqTag();
		int isHave = dao.isHaveScemQuoByDate(sqDate,sqTag);
		this.log.debug("isHave:" + isHave);
		int isNull = dao.isScemQuoNull(sqTag);
		this.log.debug("isNull:" + isNull);
		if (isHave > 0 || isNull == 0) {
			this.dao.delScemQuo(sqDate,sqTag);
			rtn = rtn + this.dao.insertScemQuo(scemQuoList);
			this.dao.delScemQuoHistory(sqDate,sqTag);
			rtn = rtn + this.dao.insertScemQuoHistory(scemQuoList);
		} else {
			this.dao.delScemQuoHistory(sqDate,sqTag);
			rtn = rtn + this.dao.insertScemQuoHistory(scemQuoList);
		}
		this.log.debug("insertScemQuo component End");
		return rtn;
	}
	
	/**
	 * 
	 */
	public int updateScemQuoBoth(ScemQuo sq) {
		this.log.debug("updateScemQuoBoth component Start");
		int rtn = 0;
		String hId = sq.getId();
		String sId = "";
		List<ScemQuo> sl = dao.getScemQuoByHistoryId(hId);
		if (null != sl && sl.size() > 0) {
			sId = sl.get(0).getId();
		}
		this.log.debug("scemQuoId:" + sId);
		if (null != sId && !sId.isEmpty()) {
			sq.setId(sId);
			rtn = rtn + this.dao.updateScemQuo(sq);
		}
		sq.setId(hId);
		rtn = this.dao.updateScemQuoHistory(sq);
		this.log.debug("updateScemQuoBoth component End");
		return rtn;
	}
	
	/**
	 * 
	 */
	public ScemQuo getScemQuoById(String strId) {
		this.log.debug("getScemQuoById component Start");
		return this.infoQuoDAO_read.getScemQuoById(strId);
	}
	
	/**
	 * 
	 */
	public ScemQuo getScemQuoHistoryById(String strId) {
		this.log.debug("getScemQuoHistoryById component Start");
		return this.infoQuoDAO_read.getScemQuoHistoryById(strId);
	}
	
	/**
	 * 
	 */
	public List<ScemQuo> getScemQuoByHistoryId(String strId) {
		this.log.debug("getScemQuoByHistoryId component Start");
		return this.infoQuoDAO_read.getScemQuoByHistoryId(strId);
	}
}
