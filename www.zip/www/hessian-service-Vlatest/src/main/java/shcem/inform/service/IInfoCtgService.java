/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IInfoCtgService
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 06/06/16 　刘洪波   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.service;

/**
 * IInfoCtgService
 * 
 * @author liuhongbo
 * @version 1.0
 */
public interface IInfoCtgService {

	/**
	 *
	 */
	public String getInfoCatogory();
	
	public String getInfoCatogoryWithPm(String params);
	
	/**
	 *
	 */
	public String getInfoCatogoryById(String params);
	
	/**
	 *
	 */
	public String insertInfoCatogory(String params);

	/**
	 * 
	 */
	public String updateInfoCatogory(String params);

	/**
	 *
	 */
	public String deleteInfoCatogory(String params);
}