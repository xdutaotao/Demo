/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: InfoMgrManagerImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.component.impl;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.inform.component.IInfoMgrManager;
import shcem.inform.dao.InfoMgrDAO;
import shcem.inform.dao.model.InfoCatogory;
import shcem.inform.dao.model.InfoCatogorys;
import shcem.inform.dao.model.InfoTagModel;
import shcem.inform.dao.model.QtRelation;
import shcem.inform.dao.model.QuotationServiceModel;

/**
 * InfoMgrManagerImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class InfoMgrManagerImpl extends BaseManager implements IInfoMgrManager {
	private InfoMgrDAO dao;
	private InfoMgrDAO infoMgrDAO_read;
	public void setInfoMgrDAO(InfoMgrDAO dao) {
		this.dao = dao;
	}

	public void setInfoMgrDAO_read(InfoMgrDAO infoMgrDAO_read) {
		this.infoMgrDAO_read = infoMgrDAO_read;
	}

	/**
	 * 
	 */
	public List<QuotationServiceModel> getInfoList(QueryConditions qc,PageInfo pageInfo,int catogoryID) {
		//查询资讯数据（1767）最底层一级分类
		List<InfoCatogorys> returnList = new ArrayList<InfoCatogorys>();
		List<InfoCatogorys> childInfoCatogorys = this.getChildQtRelation(catogoryID,returnList);
		String childrenIds = "";
		if (childInfoCatogorys != null && childInfoCatogorys.size() > 0) {
			for (int i = 0; i < childInfoCatogorys.size(); i++) {
				if(i>0) childrenIds +=",";
				childrenIds +=childInfoCatogorys.get(i).getId();
			}
			
		}
		List<QuotationServiceModel> list = this.infoMgrDAO_read.getInfoList(qc,pageInfo,childrenIds);
		if (list != null && list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				String infoTags="";
				//tag类型区分  tagTypeDiff 0:PP/PE/PVC/...，1:Web/APP/…
				List<InfoTagModel> infoTagList = this.infoMgrDAO_read.getInfoTaglist(list.get(i).getId(),0);
				if (infoTagList != null && infoTagList.size() > 0) {
					for (int j = 0; j < infoTagList.size(); j++) {
						if(j>0) infoTags +=",";
						infoTags +=infoTagList.get(j).getTagValues();
					}
					list.get(i).setInfoTags(infoTags);
				}else {
					list.get(i).setInfoTags("");
				}
				
				//显示属性
				String views ="";
				List<InfoTagModel> viewList = this.infoMgrDAO_read.getInfoTaglist(list.get(i).getId(), 1); 
				if (viewList != null && viewList.size() > 0) {
					for (int j = 0; j < viewList.size(); j++) {
						if(j>0)views +=",";
						views += viewList.get(j).getTagValues();
					}
					list.get(i).setViews(views);
				}else {
					list.get(i).setViews("");
				}
				
				String infoCatogorys ="";
				List<InfoCatogorys> infoCatogorysList = this.infoMgrDAO_read.getInfoCatogorysList(list.get(i).getId());
				if (infoCatogorysList != null && infoCatogorysList.size() > 0) {
					for (int j = 0; j < infoCatogorysList.size(); j++) {
						if(j>0) infoCatogorys +=",";
						infoCatogorys += infoCatogorysList.get(j).getCatogoryName();
					}
					list.get(i).setInfoCatogorys(infoCatogorys);
				}else {
					list.get(i).setInfoCatogorys("");
				}
			}
		}
		return list;
	}

	//递归查询资讯数据最底层
	private List<InfoCatogorys> getChildQtRelation(int infoCatogoryPID,List<InfoCatogorys> returnList) {
		List<InfoCatogorys> childInfoCatogorysList = this.infoMgrDAO_read.getChildQtRelation(infoCatogoryPID);
		if (childInfoCatogorysList != null && childInfoCatogorysList.size() > 0) {
			for (int i = 0; i < childInfoCatogorysList.size(); i++) {
				this.getChildQtRelation(childInfoCatogorysList.get(i).getId(),returnList);
			}
		}else {
			InfoCatogorys infoCatogorys = this.infoMgrDAO_read.getInfoCatogoryById(infoCatogoryPID);
			returnList.add(infoCatogorys);
		}
		return returnList;
	}

	@Override
	public QuotationServiceModel getInfoDetail(int quotationId) {
		QuotationServiceModel quotationServiceModel = this.infoMgrDAO_read.getInfoDetail(quotationId);
		//编码
		try {
			String stContent = quotationServiceModel.getInfoContent() == null ? ""
					: quotationServiceModel.getInfoContent();
			byte[] btContent = stContent.getBytes("UTF-8");
			quotationServiceModel.setInfoContent(new String(btContent,"UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			quotationServiceModel = null;
		}
		String infoTags="";
		List<InfoTagModel> infoTagList = this.infoMgrDAO_read.getInfoTaglist(quotationId,0);
		if (infoTagList != null && infoTagList.size() > 0) {
			for (int j = 0; j < infoTagList.size(); j++) {
				if(j>0) infoTags +=",";
				infoTags +=infoTagList.get(j).getTagValues();
			}
			quotationServiceModel.setInfoTags(infoTags);
			//分类属性
			//tag类型区分  tagTypeDiff 0:PP/PE/PVC/...，1:Web/APP/…
			List<QtRelation> qtRelation_infoTagssArrayList = this.infoMgrDAO_read.getQtRelationList(quotationId,2,0);
			if (qtRelation_infoTagssArrayList != null && qtRelation_infoTagssArrayList.size() > 0) {
				int[] infoTagssArray = new int[qtRelation_infoTagssArrayList.size()];
				for (int i = 0; i < infoTagssArray.length; i++) {
					infoTagssArray[i] = qtRelation_infoTagssArrayList.get(i).getRelationId();
				}
				quotationServiceModel.setInfoTagssArray(infoTagssArray);
			}
		}else {
			quotationServiceModel.setInfoTags("");
		}
		//显示属性
		String views ="";
		List<InfoTagModel> viewList = this.infoMgrDAO_read.getInfoTaglist(quotationId, 1); 
		if (viewList != null && viewList.size() > 0) {
			for (int j = 0; j < viewList.size(); j++) {
				if(j>0)views +=",";
				views += viewList.get(j).getTagValues();
			}
			quotationServiceModel.setViews(views);
			List<QtRelation> qtRelation_viewList = this.infoMgrDAO_read.getQtRelationList(quotationId,2,1);
			if (qtRelation_viewList !=null && qtRelation_viewList.size() > 0) {
				int[] viewTags = new int[qtRelation_viewList.size()];
				for (int i = 0; i < viewTags.length; i++) {
					viewTags[i] = qtRelation_viewList.get(i).getRelationId();
				}
				quotationServiceModel.setViewTags(viewTags);
			}
		}else {
			quotationServiceModel.setViews("");
		}
		
		String infoCatogorys ="";
		List<InfoCatogorys> infoCatogorysList = this.infoMgrDAO_read.getInfoCatogorysList(quotationId);
		if (infoCatogorysList != null && infoCatogorysList.size() > 0) {
			for (int j = 0; j < infoCatogorysList.size(); j++) {
				if(j>0) infoCatogorys +=",";
				infoCatogorys += infoCatogorysList.get(j).getCatogoryName();
			}
			quotationServiceModel.setInfoCatogorys(infoCatogorys);
			//产品分类
			List<QtRelation> qtRelation_infoCatogorysArrayList = this.infoMgrDAO_read.getQtRelationLists(quotationId,3);
			if (qtRelation_infoCatogorysArrayList != null && qtRelation_infoCatogorysArrayList.size() > 0) {
				int[] infoCatogorysArray = new int[qtRelation_infoCatogorysArrayList.size()];
				for (int i = 0; i < infoCatogorysArray.length; i++) {
					infoCatogorysArray[i] = qtRelation_infoCatogorysArrayList.get(i).getRelationId();
				}
				quotationServiceModel.setInfoCatogorysArray(infoCatogorysArray);
			}
		}else {
			quotationServiceModel.setInfoCatogorys("");
		}
		//老专场咨询数据 附带附件
		List<QtRelation> qtRelation_attachment  = this.infoMgrDAO_read.getQtRelationLists(quotationId, 1);
		if (qtRelation_attachment != null && qtRelation_attachment.size() > 0) {
			quotationServiceModel.setAttachmentID(qtRelation_attachment.get(0).getRelationId());
		}
		
		
		return quotationServiceModel;
	}

	/**
	 * 
	 */
	public String insertInfo(QuotationServiceModel quotationServiceModel)throws RuntimeException{
		String result="";

		try {
			int row = this.dao.insertInfo(quotationServiceModel);
			quotationServiceModel.setId(row);
			//解码
			String decodeContent = quotationServiceModel.getInfoContent();
			quotationServiceModel.setInfoContent(decodeContent);
			this.dao.insertInfoQtContent(quotationServiceModel);
			if (row > 0) {
				//分类属性（tag属性）
				if (quotationServiceModel.getInfoTagssArray() != null) {
					int[] infoTagssArray = quotationServiceModel.getInfoTagssArray();
					if (infoTagssArray != null && infoTagssArray.length > 0) {
						for (int i = 0; i < infoTagssArray.length; i++) {
							row = this.dao.insertQtRelation(infoTagssArray[i],quotationServiceModel.getId(),2);
						}
					}
				}
				if (quotationServiceModel.getViewTags() != null) {
					//显示属性
					int[] viewTags = quotationServiceModel.getViewTags();
					if (viewTags != null && viewTags.length > 0) {
						for (int i = 0; i < viewTags.length; i++) {
							row = this.dao.insertQtRelation(viewTags[i], quotationServiceModel.getId(),2);
						}
					}
				}
				
				if (quotationServiceModel.getInfoCatogorysArray() != null) {
					int[] infoCatogorysArray = quotationServiceModel.getInfoCatogorysArray();
					if (infoCatogorysArray !=null && infoCatogorysArray.length > 0) {
						for (int i = 0; i < infoCatogorysArray.length; i++) {
							row = this.dao.insertQtRelation(infoCatogorysArray[i],quotationServiceModel.getId(),3);
						}
					}
				}
				
				//老专场咨询数据 附带附件
				if (quotationServiceModel.getAttachmentID() != null) {
					int attachmentID = quotationServiceModel.getAttachmentID();
					this.dao.insertQtRelation(attachmentID,quotationServiceModel.getId(),1);
				}
				result = "success";
			}
			//显示属性暂时未知
		} catch (Exception e) {
			e.printStackTrace();
			this.rollBack();
			this.log.error("新增咨询失败"+e.getMessage());
			result ="fail";
		}
		return result;
	}

	/**
	 * 
	 */
	public String updateInfo(QuotationServiceModel quotationServiceModel)throws RuntimeException{
		
		String result="";
		
		try {
			int row = this.dao.updateInfo(quotationServiceModel);
			//解码
			String decodeContent = quotationServiceModel.getInfoContent();
			quotationServiceModel.setInfoContent(decodeContent);
			this.dao.updateInfoQtContent(quotationServiceModel);
			
			//分类属性（tag属性）
			this.dao.deleteInfoQtRelation(quotationServiceModel.getId(),2);
			if (quotationServiceModel.getInfoTagssArray() != null) {
				int[] infoTagssArray = quotationServiceModel.getInfoTagssArray();
				
				for (int i = 0; i < infoTagssArray.length; i++) {
					row = this.dao.insertQtRelation(infoTagssArray[i],quotationServiceModel.getId(),2);
				}
			}
			//显示属性
			if (quotationServiceModel.getViewTags() != null) {
				int[] viewTags = quotationServiceModel.getViewTags();
				if (viewTags != null && viewTags.length > 0) {
					for (int i = 0; i < viewTags.length; i++) {
						row = this.dao.insertQtRelation(viewTags[i], quotationServiceModel.getId(),2);
					}
				}
			}
			if (quotationServiceModel.getInfoCatogorysArray() != null) {
				int[] infoCatogorysArray = quotationServiceModel.getInfoCatogorysArray();
				this.dao.deleteInfoQtRelation(quotationServiceModel.getId(),3);
				for (int i = 0; i < infoCatogorysArray.length; i++) {
					row = this.dao.insertQtRelation(infoCatogorysArray[i],quotationServiceModel.getId(),3);
				}
			}
			
			//老专场咨询数据 附带附件
			if (quotationServiceModel.getAttachmentID() != null) {
				int attachmentID = quotationServiceModel.getAttachmentID();
				this.dao.deleteInfoQtRelation(quotationServiceModel.getId(),1);
				this.dao.insertQtRelation(attachmentID,quotationServiceModel.getId(),1);
			}
			result = "success";
		} catch (Exception e) {
			e.printStackTrace();
			this.rollBack();
			this.log.error("新增咨询失败"+e.getMessage());
			result ="fail";
		}
		
		
		return result;
	}

	@Override
	public String deleteInfo(int[] quotationIds)throws RuntimeException {
		String result="";
		try {
			for (int i = 0; i < quotationIds.length; i++) {
				this.dao.deleteInfo(quotationIds[i]);
			}
			result ="success";
		} catch (Exception e) {
			this.log.error("删除咨询消息"+e.getMessage());
			this.rollBack();
			result = "fail";
		}
		return result;
	}

	@Override
	public List<QuotationServiceModel> getAdvertList(PageInfo pageInfo, int catogoryID) {
		List<QuotationServiceModel> list = this.infoMgrDAO_read.getAdvertList(pageInfo,catogoryID);
		return list;
	}
	
	@Override
	public List<InfoCatogorys> getAdverClass(int catogoryID) {
		//查询广告模块（1800）最底层一级分类
		List<InfoCatogorys> returnList = new ArrayList<InfoCatogorys>();
		List<InfoCatogorys> childInfoCatogorys = this.getChildQtRelation(catogoryID,returnList);
		String childrenIds = "";
		List<InfoCatogorys> list = null;
		if (childInfoCatogorys != null && childInfoCatogorys.size() > 0) {
			for (int i = 0; i < childInfoCatogorys.size(); i++) {
				if(i>0) childrenIds +=",";
				childrenIds +=childInfoCatogorys.get(i).getId();
			}
			list= this.infoMgrDAO_read.getAdverClass(childrenIds);
		}
		return list;
	}
	
	
	@Override
	public void insertAdvert(QuotationServiceModel quotationServiceModel)throws RuntimeException {
		int advertID;
		advertID = this.dao.insertAdvert(quotationServiceModel);
		//广告分类
		this.dao.insertQtRelation(quotationServiceModel.getAdverCatogoryID(),advertID,3);
		//广告图片
		this.dao.insertQtRelation(quotationServiceModel.getAdvertPicID(), advertID,1);
		
	}
	
	@Override
	public void updateAdvert(QuotationServiceModel quotationServiceModel) {
		this.dao.updateAdvert(quotationServiceModel);
		//广告分类
		this.dao.deleteInfoQtRelation(quotationServiceModel.getId(), 3);
		this.dao.insertQtRelation(quotationServiceModel.getAdverCatogoryID(),quotationServiceModel.getId(),3);
		//广告图片
		this.dao.deleteInfoQtRelation(quotationServiceModel.getId(), 1);
		this.dao.insertQtRelation(quotationServiceModel.getAdvertPicID(), quotationServiceModel.getId(),1);
		
	}
	@Override
	public QuotationServiceModel getAdvertDetailByID(int quotationID) {
		QuotationServiceModel quotationServiceModel = this.infoMgrDAO_read.getAdvertDetailByID(quotationID);
		if (quotationServiceModel != null) {
			//图片ID
			List<QtRelation> list = this.infoMgrDAO_read.getQtRelationLists(quotationID, 1);
			if (list != null && list.size() > 0) {
				for (int i = 0; i < list.size(); i++) {
					quotationServiceModel.setAdvertPicID(list.get(i).getRelationId());
				}
				
			}
		}
		return quotationServiceModel;
	}
	
	/**
	 * 老专场资讯数据     剔除咨询管理（1767）和  广告模块（1849）下的资讯信息
	 */
	@Override
	public List<QuotationServiceModel> getOldInfoList(int[] catogoryID,
			QueryConditions qc, PageInfo pageInfo) {
		//咨询管理ID
		List<InfoCatogorys> returnList = new ArrayList<InfoCatogorys>();
		List<InfoCatogorys> childInfoCatogorys = this.getChildQtRelation(catogoryID[0],returnList);
		String childrenIds = "";
		if (childInfoCatogorys != null && childInfoCatogorys.size() > 0) {
			for (int i = 0; i < childInfoCatogorys.size(); i++) {
				if(i>0) childrenIds +=",";
				childrenIds +=childInfoCatogorys.get(i).getId();
			}
			
		}
		
		//查询广告模块（1800）最底层一级分类
		List<InfoCatogorys> returnList_Advert = new ArrayList<InfoCatogorys>();
		List<InfoCatogorys> childInfoCatogorys_Advert= this.getChildQtRelation(catogoryID[1],returnList_Advert);
		String childrenIds_Advert = "";
		if (childInfoCatogorys_Advert != null && childInfoCatogorys_Advert.size() > 0) {
			for (int i = 0; i < childInfoCatogorys_Advert.size(); i++) {
				if(i>0) childrenIds_Advert +=",";
				childrenIds_Advert +=childInfoCatogorys_Advert.get(i).getId();
			}
		}
		List<QuotationServiceModel> list = this.infoMgrDAO_read.getOldInfoList(childrenIds,childrenIds_Advert,qc,pageInfo);
		if (list != null && list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				String infoCatogorys ="";
				List<InfoCatogorys> infoCatogorysList = this.infoMgrDAO_read.getInfoCatogorysList(list.get(i).getId());
				if (infoCatogorysList != null && infoCatogorysList.size() > 0) {
					for (int j = 0; j < infoCatogorysList.size(); j++) {
						if(j>0) infoCatogorys +=",";
						infoCatogorys += infoCatogorysList.get(j).getCatogoryName();
					}
					list.get(i).setInfoCatogorys(infoCatogorys);
				}else {
					list.get(i).setInfoCatogorys("");
				}
			}
		}

		return list;
	}
	
	/**
	 * 首页专题查询记录
	 */
	@Override
	public List<QuotationServiceModel> getHomeTopicInfoList(QueryConditions qc, PageInfo pageInfo) {
		// TODO Auto-generated method stub
		return this.infoMgrDAO_read.getHomeTopicInfoList(qc, pageInfo);
	}

	
	@Override
	public List<InfoCatogory> getOldInfoCatogory(int[] catogoryID) {
		//资讯管理
		int catogoryPID = catogoryID[0];
		String catogoryPIDs = catogoryID[0]+"";
		catogoryPIDs = this.getAllcatogoryID(catogoryPIDs,catogoryPID);
		
		//广告管理
		int catogoryPID_advert = catogoryID[1];
		String catogoryPIDs_advert = catogoryID[1]+"";
		catogoryPIDs_advert = this.getAllcatogoryID(catogoryPIDs_advert,catogoryPID_advert);
		
		List<InfoCatogory> list = this.infoMgrDAO_read.getOldInfoCatogory(catogoryPIDs,catogoryPIDs_advert);
		return list;
	}
	
	/**获取咨询分类所有的子节点
	 * @param catogoryPID
	 * @return
	 */
	private String getAllcatogoryID(String catogoryPIDs,int catogoryPID) {
		List<InfoCatogorys> list = this.infoMgrDAO_read.getChildQtRelation(catogoryPID);
		if (list != null && list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				catogoryPIDs += ","+list.get(i).getId();
				this.getAllcatogoryID(catogoryPIDs,list.get(i).getId());
			}
		}
		// TODO Auto-generated method stub
		return catogoryPIDs;
	}

	private void rollBack() {
		this.dao.rollBack();
	}
	private QuotationServiceModel setInfoProperty(QuotationServiceModel quotationServiceModel) {
		
		return null;
	}
}
