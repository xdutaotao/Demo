/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IInfoQuoManager
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永     Create
 * 06/02/16 　刘洪波  Real
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.component;

import java.util.Date;
import java.util.List;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.inform.dao.InfoQuoDAO;
import shcem.inform.dao.model.MarketQuo;
import shcem.inform.dao.model.ScemQuo;

/**
 * IInfoQuoManager
 * 
 * @author chiyong
 * @version 1.0
 */
public abstract interface IInfoQuoManager extends Manager {

	public abstract void setInfoQuoDAO(InfoQuoDAO paramInfoQuoDAO);

	/**
	 * 
	 */
	public abstract List<MarketQuo> getMarketQuoList(QueryConditions qc,PageInfo pageInfo);
	
	/**
	 * 
	 */
	public abstract MarketQuo getMarketQuoById(String strId);
	
	/**
	 * 
	 */
	public abstract List<MarketQuo> getStartEndDateMarketQuoList(Date startDate, Date endDate);

	/**
	 * 
	 */
	public abstract int insertMarketQuo(MarketQuo params);

	/**
	 * 
	 */
	public abstract int updateMarketQuo(MarketQuo params);

	/**
	 * 
	 */
	public abstract int deleteMarketQuo(String strId);

	/**
	 * 
	 */
	public abstract List<ScemQuo> getScemQuo(QueryConditions qc,PageInfo pageInfo);
	
	/**
	 * 
	 */
	public abstract List<ScemQuo> getScemQuoHistory(QueryConditions qc,PageInfo pageInfo);

	/**
	 * 
	 */
	public abstract int insertScemQuo(List<ScemQuo> scemQuoList);
	
	/**
	 * 
	 */
	public abstract int updateScemQuoBoth(ScemQuo sq);
	
	/**
	 * 
	 */
	public abstract ScemQuo getScemQuoById(String strId);
	
	/**
	 * 
	 */
	public abstract ScemQuo getScemQuoHistoryById(String strId);
	
	/**
	 * 
	 */
	public abstract List<ScemQuo> getScemQuoByHistoryId(String strId);
}
