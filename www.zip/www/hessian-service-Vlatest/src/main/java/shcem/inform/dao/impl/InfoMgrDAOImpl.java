/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: InfoMgrDAOImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.dao.impl;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.jdbc.CannotGetJdbcConnectionException;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.inform.dao.InfoMgrDAO;
import shcem.inform.dao.model.InfoCatogory;
import shcem.inform.dao.model.InfoCatogorys;
import shcem.inform.dao.model.InfoTagModel;
import shcem.inform.dao.model.QtRelation;
import shcem.inform.dao.model.QuotationServiceModel;
import shcem.util.CommonRowMapper;

/**
 * InfoMgrDAOImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class InfoMgrDAOImpl extends BaseDAOImpl implements InfoMgrDAO {
	/**
	 *
	 */
	public List<QuotationServiceModel> getInfoList(QueryConditions qc,PageInfo pageInfo, String childrenIds) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_001");
		List<QuotationServiceModel> retList = null;
		retList = queryBySQL(sql+" and relationId  IN ("+childrenIds+"))", qc, pageInfo,  new CommonRowMapper(new QuotationServiceModel()));
		return retList;
	}

	/**
	 * 
	 */
	public QuotationServiceModel getInfoDetail(int quotationId) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_002");
		Object[] params = new Object[]{quotationId};
		QuotationServiceModel quotationServiceModel = (QuotationServiceModel) this.queryForObject(sql, params,new CommonRowMapper(new QuotationServiceModel()));
		return quotationServiceModel;
	}

	
	
	@Override
	public List<InfoTagModel> getInfoTaglist(int quotationId,int tagTypeDiff) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_003");
		List<InfoTagModel> retList = null;
		Object[] params = new Object[]{tagTypeDiff,quotationId};
		retList = queryBySQL(sql, params, null, new CommonRowMapper(new InfoTagModel()));
		return retList;
	}

	
	
	@Override
	public List<InfoCatogorys> getInfoCatogorysList(int quotationId) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_004");
		List<InfoCatogorys> retList = null;
		Object[] params = new Object[]{quotationId};
		retList = queryBySQL(sql, params, null, new CommonRowMapper(new InfoCatogorys()));
		return retList;
	}

	/**
	 
	 */
	public int insertInfo(QuotationServiceModel quotationServiceModel){
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_005");
		Object[] params = new Object[]{
				quotationServiceModel.getTitle(),quotationServiceModel.getInfoKeyword(),
			quotationServiceModel.getInfoLinkId(),quotationServiceModel.getInfoStatus(),quotationServiceModel.getPostTime(),
			quotationServiceModel.getREC_CREATEBY(),quotationServiceModel.getREC_MODIFYBY()
		};
		int id = this.queryForIntID(sql, params);
		return id;
		
	}

	
	
	public int insertQtRelation(int tagID, int quotationId,int relationType) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_006");
		// 1:文件关联,2:Tag关联,3:分类关联
		Object[] params = new Object[]{
				quotationId,tagID,relationType
		};
		return this.updateBySQL(sql, params);
	}

	
	@Override
	public int insertInfoQtContent(QuotationServiceModel quotationServiceModel) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_008");
		Object[] params = new Object[]{
				quotationServiceModel.getId(),quotationServiceModel.getInfoContent(),
			quotationServiceModel.getREC_CREATEBY(),quotationServiceModel.getREC_MODIFYBY()
		};
		try {
			return this.updateBySQL(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	/**
	 * 
	 */
	public int updateInfo(QuotationServiceModel quotationServiceModel) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_007");
		Object[] params = new Object[]{
				quotationServiceModel.getTitle(),quotationServiceModel.getInfoKeyword(),
			quotationServiceModel.getInfoLinkId(),quotationServiceModel.getInfoStatus(),quotationServiceModel.getPostTime(),
			quotationServiceModel.getREC_MODIFYBY(),quotationServiceModel.getId()
		};
		return this.updateBySQL(sql, params);
	}

	

	@Override
	public int updateInfoQtContent(QuotationServiceModel quotationServiceModel) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_009");
		Object[] params = new Object[]{
				quotationServiceModel.getInfoContent(),quotationServiceModel.getREC_MODIFYBY(),quotationServiceModel.getId()
		};
		return this.updateBySQL(sql, params);
	}

	
	@Override
	public int updateQtRelation(int tagID, int quotationId, int relationType) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_010");
		Object[] params = new Object[]{
				tagID,quotationId,relationType
		};
		return this.updateBySQL(sql, params);
	}

	@Override
	public int deleteInfo(int quotationIds) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_011");
		Object[] params = new Object[]{
				quotationIds
		};
		return this.updateBySQL(sql, params);
	}

	@Override
	public List<QtRelation> getQtRelationList(int quotationId, int relationType, int tagTypeDiff) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_012");
		List<QtRelation> retList = null;
		Object[] params = new Object[]{quotationId,relationType,tagTypeDiff};
		retList = queryBySQL(sql, params, null, new CommonRowMapper(new QtRelation()));
		return retList;
	}

	@Override
	public int  deleteInfoQtRelation(int quotationId, int relationType) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_013");
		Object[] params = new Object[]{
				quotationId,relationType
		};
		return this.updateBySQL(sql, params);
	}
	
	/**
	 * 查询  资讯分类子类
	 */
	@Override
	public List<InfoCatogorys> getChildQtRelation(int infoCatogoryPID) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_014");
		Object[] params = {infoCatogoryPID};
		List<InfoCatogorys> list = this.queryBySQL(sql, params, null, null, new CommonRowMapper(new InfoCatogorys()));
		return list;
	}
	@Override
	public InfoCatogorys getInfoCatogoryById(int infoCatogoryPID) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_015");
		Object[] params = {infoCatogoryPID};
		return (InfoCatogorys) this.queryForObject(sql, params, new CommonRowMapper(new InfoCatogorys()));
	}
	@Override
	public List<QuotationServiceModel> getAdvertList(PageInfo pageInfo,int catogoryID) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_017");
		List<QuotationServiceModel> retList = null;//sql+" and relationId  IN ("+catogoryID+"))"
		Object[] param = {};
		retList = queryBySQL(sql+" and relationId  IN ("+catogoryID+")", param, pageInfo, new CommonRowMapper(new QuotationServiceModel()));
		return retList;
	}
	@Override
	public List<InfoCatogorys> getAdverClass(String childrenIds) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_016");
		List<InfoCatogorys> retList = null;
		retList = query(sql+"("+childrenIds+") and catogorySts=1", null, null, new CommonRowMapper(new InfoCatogorys()));
		return retList;
	}
	@Override
	public int insertAdvert(QuotationServiceModel quotationServiceModel) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_018");
		quotationServiceModel.setInfoStatus(1);
		//广告描述就是title
		// 标题    关键字  广告链接  状态  发布时间 创建人  创建时间  最后修改人  最后修改时间
		Object[] params = new Object[]{
				quotationServiceModel.getTitle(),"",quotationServiceModel.getInfoLinkId(),quotationServiceModel.getInfoStatus(),
			new Date(),"",new Date(),"",new Date(),quotationServiceModel.getInfoOrder()
		};
		int id = this.queryForIntID(sql, params);
		return id;
	}
	
	@Override
	public void updateAdvert(QuotationServiceModel quotationServiceModel) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_019");
		//广告描述就是title
		// 标题    广告链接  状态    最后修改人  最后修改时间
		Object[] params = new Object[]{
				quotationServiceModel.getTitle(),quotationServiceModel.getInfoLinkId(),quotationServiceModel.getInfoStatus(),
			"",new Date(),quotationServiceModel.getInfoOrder(),quotationServiceModel.getId()
		};
		this.updateBySQL(sql, params);
	}
	
	@Override
	public QuotationServiceModel getAdvertDetailByID(int quotationID) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_020");
		Object[] params = {quotationID};
		QuotationServiceModel rtnData = (QuotationServiceModel) this.queryForObject(sql, params, new CommonRowMapper(new QuotationServiceModel()));
		return rtnData;
	}
	
	@Override
	public List<QtRelation> getQtRelationLists(int quotationId, int i) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_021");
		List<QtRelation> retList = null;
		Object[] params = new Object[]{quotationId,i};
		retList = queryBySQL(sql, params, null, new CommonRowMapper(new QtRelation()));
		return retList;
	}
	
	@Override
	public List<QuotationServiceModel> getOldInfoList(String childrenIds,
			String childrenIds_Advert, QueryConditions qc, PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_001")+" and relationId  NOT IN ("+childrenIds+") and relationId NOT IN ("+childrenIds_Advert+"))";
		List<QuotationServiceModel> retList = null;
			
		retList = queryBySQL(sql, qc, pageInfo,  new CommonRowMapper(new QuotationServiceModel()));
		
		return retList;
	}
	
	/**
	 * 查询首页专题记录
	 */
	@Override
	public List<QuotationServiceModel> getHomeTopicInfoList(QueryConditions qc, PageInfo pageInfo) {
		// TODO Auto-generated method stub
		this.log.debug("getHomeTopicInfoList DAO Start");
		String sql=sqlProperty.getProperty("InfoMgrDAO_023");
		return this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new QuotationServiceModel()));
	}
	
	@Override
	public List<InfoCatogory> getOldInfoCatogory(String catogoryPIDs,
			String catogoryPIDs_advert) {
		String sql = this.sqlProperty.getProperty("InfoMgrDAO_022")+" and id  NOT IN ("+catogoryPIDs+") and id NOT IN ("+catogoryPIDs_advert+")";
		List<InfoCatogory> retList = null;
		Object [] params ={};
		retList = queryBySQL(sql, params, null, new CommonRowMapper(new InfoCatogory()));
		return retList;
	}
	
	@Override
	public void rollBack(){
		try {
			getConnection().setAutoCommit(false);//事务设置为手动
			getConnection().rollback();
		} catch (CannotGetJdbcConnectionException e) {
			e.printStackTrace();
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}	
}
