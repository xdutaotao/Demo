/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: InfoOraDAO.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.dao;

import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.inform.dao.model.HqOra;

/**
 * @author wlpod
 *
 */
public abstract interface InfoOraDAO extends DAO {
	public abstract List<HqOra> getHqList(QueryConditions qc, PageInfo pageInfo);
}
