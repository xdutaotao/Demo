/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: InfoCatogory
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 06/06/16 　刘洪波   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.dao.model;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import shcem.base.dao.model.BaseObject;

/**
 * InfoCatogory
 * @author liuhongbo
 * @version 1.0
 */
public class InfoCatogory extends BaseObject implements Serializable {
    /** 版本号 */
    private static final long serialVersionUID = 437436245174322171L;
    
    /**  */
    private String id;
    
    /**  */
    private Integer parentId;
    
    /**  */
    private String catogoryName;
    
    /**  */
    private Integer catogorySts;
    
    /**  */
    private String REC_CREATEBY;
    
    /**  */
    private Date REC_CREATETIME;
    
    /**  */
    private String REC_MODIFYBY;
    
    /**  */
    private Date REC_MODIFYTIME;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public String getCatogoryName() {
		return catogoryName;
	}

	public void setCatogoryName(String catogoryName) {
		this.catogoryName = catogoryName;
	}

	public Integer getCatogorySts() {
		return catogorySts;
	}

	public void setCatogorySts(Integer catogorySts) {
		this.catogorySts = catogorySts;
	}

	public String getREC_CREATEBY() {
		return REC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		REC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return REC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		REC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return REC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		REC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return REC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		REC_MODIFYTIME = rEC_MODIFYTIME;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof InfoCatogory))
			return false;

		InfoCatogory m = (InfoCatogory) o;

		return this.id != null ? this.id.equals(m.id) : m.id == null;
	}

	public int hashCode() {
		return this.id != null ? this.id.hashCode() : 0;
	}
}
