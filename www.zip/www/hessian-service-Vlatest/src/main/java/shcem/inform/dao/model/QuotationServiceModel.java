/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: Quotation
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.dao.model;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import shcem.base.dao.model.BaseObject;

/**
 * Quotation
 * @author chiyong
 * @version 1.0
 */
public class QuotationServiceModel extends BaseObject implements Serializable {
    /** 版本号 */
    private static final long serialVersionUID = -8736134629117137485L;
    
    /**  */
    private int id;
    
    /**  */
    private String title;
    
    /**  */
    private String infoKeyword;
    
    /**  */
    private String infoLinkId;
    
    /**  */
    private Integer infoStatus;
    
    /**  */
    private Date postTime;
    
    /**  */
    private String rEC_CREATEBY;
    
	/**  */
    private Date rEC_CREATETIME;
    
    /**  */
    private String rEC_MODIFYBY;
    
    /**  */
    private Date rEC_MODIFYTIME;
    
    //咨询属性
    private String infoTags;
    //咨询分类
    private String infoCatogorys;
    //显示属性
    private String views;
    
    //分类属性（tag属性）
    private int[] infoTagssArray;
    //咨询分类 数组
    private int[] infoCatogorysArray;
    //显示类型
    private int[] viewTags;
    
    //咨询内容
    private String infoContent;
    
    //广告图片ID
    private Integer advertPicID;
    //广告排序
    private Integer infoOrder;
    //广告分类ID
    private Integer adverCatogoryID;
    //广告分类名称
    private String adverName;
    
    //附件ID
    private Integer attachmentID;
    
    
    public String getREC_CREATEBY() {
		return rEC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		this.rEC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return rEC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		this.rEC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return rEC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		this.rEC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return rEC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		this.rEC_MODIFYTIME = rEC_MODIFYTIME;
	}
    
	public int[] getInfoTagssArray() {
		return infoTagssArray;
	}

	public void setInfoTagssArray(int[] infoTagssArray) {
		this.infoTagssArray = infoTagssArray;
	}

	public int[] getInfoCatogorysArray() {
		return infoCatogorysArray;
	}

	public void setInfoCatogorysArray(int[] infoCatogorysArray) {
		this.infoCatogorysArray = infoCatogorysArray;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getInfoKeyword() {
		return infoKeyword;
	}

	public void setInfoKeyword(String infoKeyword) {
		this.infoKeyword = infoKeyword;
	}

	public String getInfoLinkId() {
		return infoLinkId;
	}

	public void setInfoLinkId(String infoLinkId) {
		this.infoLinkId = infoLinkId;
	}

	public Integer getInfoStatus() {
		return infoStatus;
	}

	public void setInfoStatus(Integer infoStatus) {
		this.infoStatus = infoStatus;
	}

	public Date getPostTime() {
		return postTime;
	}

	public void setPostTime(Date postTime) {
		this.postTime = postTime;
	}

	
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}


	public String getInfoTags() {
		return infoTags;
	}

	public void setInfoTags(String infoTags) {
		this.infoTags = infoTags;
	}

	public String getInfoCatogorys() {
		return infoCatogorys;
	}

	public void setInfoCatogorys(String infoCatogorys) {
		this.infoCatogorys = infoCatogorys;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getInfoContent() {
		return infoContent;
	}

	public void setInfoContent(String infoContent) {
		this.infoContent = infoContent;
	}

	public int[] getViewTags() {
		return viewTags;
	}

	public void setViewTags(int[] viewTags) {
		this.viewTags = viewTags;
	}

	public Integer getAdvertPicID() {
		return advertPicID;
	}

	public void setAdvertPicID(Integer advertPicID) {
		this.advertPicID = advertPicID;
	}

	public Integer getInfoOrder() {
		return infoOrder;
	}

	public void setInfoOrder(Integer infoOrder) {
		this.infoOrder = infoOrder;
	}

	public Integer getAdverCatogoryID() {
		return adverCatogoryID;
	}

	public void setAdverCatogoryID(Integer adverCatogoryID) {
		this.adverCatogoryID = adverCatogoryID;
	}

	public String getAdverName() {
		return adverName;
	}

	public void setAdverName(String adverName) {
		this.adverName = adverName;
	}

	public String getViews() {
		return views;
	}

	public void setViews(String views) {
		this.views = views;
	}

	public Integer getAttachmentID() {
		return attachmentID;
	}

	public void setAttachmentID(Integer attachmentID) {
		this.attachmentID = attachmentID;
	}
}
