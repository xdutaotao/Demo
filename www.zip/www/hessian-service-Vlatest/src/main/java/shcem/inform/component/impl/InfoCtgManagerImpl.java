/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: InfoCtgManagerImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 06/06/16 　刘洪波   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.component.impl;

import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.inform.component.IInfoCtgManager;
import shcem.inform.dao.InfoCtgDAO;
import shcem.inform.dao.model.InfoCatogory;

/**
 * InfoCtgManagerImpl
 * 
 * @author liuhongbo
 * @version 1.0
 */
public class InfoCtgManagerImpl extends BaseManager implements IInfoCtgManager {
	private InfoCtgDAO dao;
	private InfoCtgDAO infoCtgDAO_read;
	public void setInfoCtgDAO(InfoCtgDAO dao) {
		this.dao = dao;
	}

	public void setInfoCtgDAO_read(InfoCtgDAO infoCtgDAO_read) {
		this.infoCtgDAO_read = infoCtgDAO_read;
	}

	/**
	 * 
	 */
	public List<InfoCatogory> getAllInfoCatogoryList() {
		this.log.debug("getAllInfoCatogoryList component Start");
		return this.infoCtgDAO_read.getAllInfoCatogoryList();
	}
	
	/**
	 * 
	 */
	public InfoCatogory getInfoCatogoryById(String strId) {
		this.log.debug("getInfoCatogoryById component Start");
		return this.infoCtgDAO_read.getInfoCatogoryById(strId);
	}

	/**
	 * 
	 */
	public int addInfoCatogory(InfoCatogory params) {
		this.log.debug("addInfoCatogory component Start");
		return this.dao.addInfoCatogory(params);
	}

	/**
	 * 
	 */
	public int updInfoCatogory(InfoCatogory params) {
		this.log.debug("updInfoCatogory component Start");
		return this.dao.updInfoCatogory(params);
	}

	/**
	 * 
	 */
	public int delInfoCatogory(InfoCatogory iCtg) {
		this.log.debug("delInfoCatogory component Start");
		return this.dao.delInfoCatogory(iCtg);
	}
}
