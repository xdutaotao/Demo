/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: HqOraServiceModel.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.service.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.json.JSONObject;

import shcem.base.service.model.BaseServiceObject;

/**
 * @author wlpod
 *
 */
public class HqOraServiceModel extends BaseServiceObject implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3713216955055352564L;
	private Date tradeTime;
	private String commodityID;
	private String commodityName;
	private BigDecimal price;
	private BigDecimal totalQuantity;
	/**
	 * 生产企业
	 */
	private String manufacturers;
	/**
	 * 交货地
	 */
	private String propertiesorigin;
	/**
	 * 专场名称
	 */
	private String breedName;

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toString()
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#toJSONObject()
	 */
	@Override
	public JSONObject toJSONObject() {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see shcem.base.service.model.BaseServiceObject#hashCode()
	 */
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @return the tradeTime
	 */
	public Date getTradeTime() {
		return tradeTime;
	}

	/**
	 * @param tradeTime
	 *            the tradeTime to set
	 */
	public void setTradeTime(Date tradeTime) {
		this.tradeTime = tradeTime;
	}

	/**
	 * @return the commodityID
	 */
	public String getCommodityID() {
		return commodityID;
	}

	/**
	 * @param commodityID
	 *            the commodityID to set
	 */
	public void setCommodityID(String commodityID) {
		this.commodityID = commodityID;
	}

	/**
	 * @return the commodityName
	 */
	public String getCommodityName() {
		return commodityName;
	}

	/**
	 * @param commodityName
	 *            the commodityName to set
	 */
	public void setCommodityName(String commodityName) {
		this.commodityName = commodityName;
	}

	/**
	 * @return the price
	 */
	public BigDecimal getPrice() {
		return price;
	}

	/**
	 * @param price
	 *            the price to set
	 */
	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	/**
	 * @return the totalQuantity
	 */
	public BigDecimal getTotalQuantity() {
		return totalQuantity;
	}

	/**
	 * @param totalQuantity
	 *            the totalQuantity to set
	 */
	public void setTotalQuantity(BigDecimal totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	/**
	 * @return the manufacturers
	 */
	public String getManufacturers() {
		return manufacturers;
	}

	/**
	 * @param manufacturers
	 *            the manufacturers to set
	 */
	public void setManufacturers(String manufacturers) {
		this.manufacturers = manufacturers;
	}

	/**
	 * @return the propertiesorigin
	 */
	public String getPropertiesorigin() {
		return propertiesorigin;
	}

	/**
	 * @param propertiesorigin
	 *            the propertiesorigin to set
	 */
	public void setPropertiesorigin(String propertiesorigin) {
		this.propertiesorigin = propertiesorigin;
	}

	/**
	 * @return the breedName
	 */
	public String getBreedName() {
		return breedName;
	}

	/**
	 * @param breedName
	 *            the breedName to set
	 */
	public void setBreedName(String breedName) {
		this.breedName = breedName;
	}

}
