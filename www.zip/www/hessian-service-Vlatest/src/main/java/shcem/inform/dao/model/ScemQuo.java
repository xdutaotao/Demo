/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: ScemQuo
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永     Create
 * 06/12/16 　刘洪波  Real
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import shcem.base.dao.model.BaseObject;

/**
 * ScemQuo
 * @author chiyong
 * @version 1.0
 */
public class ScemQuo extends BaseObject implements Serializable {
	/** 版本号 */
	private static final long serialVersionUID = -3550853638247840844L;

    /**  */
    private String id;
    
    /**  */
    private Date sqDate;
    
    /**  */
    private String sqProduct;
    
    /**  */
    private String sqRank;
    
    /**  */
    private String sqNo;
    
    /**  */
    private String sqType;
    
    /**  */
    private String sqFactory;
    
    /**  */
    private Integer sqTag;
    
    /**  */
    private String sqArea;
    
    /**  */
    private BigDecimal sqMinPrice;
    
    /**  */
    private BigDecimal sqMaxPrice;
    
    /**  */
    private BigDecimal sqDropRange;
    
    /**  */
    private BigDecimal sqUpRange;
    
    /**  */
    private String REC_CREATEBY;
    
    /**  */
    private Date REC_CREATETIME;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	public Date getSqDate() {
		return sqDate;
	}

	public void setSqDate(Date sqDate) {
		this.sqDate = sqDate;
	}

	public String getSqProduct() {
		return sqProduct;
	}

	public void setSqProduct(String sqProduct) {
		this.sqProduct = sqProduct;
	}

	public String getSqRank() {
		return sqRank;
	}

	public void setSqRank(String sqRank) {
		this.sqRank = sqRank;
	}

	public String getSqNo() {
		return sqNo;
	}

	public void setSqNo(String sqNo) {
		this.sqNo = sqNo;
	}

	public String getSqType() {
		return sqType;
	}

	public void setSqType(String sqType) {
		this.sqType = sqType;
	}

	public String getSqFactory() {
		return sqFactory;
	}

	public void setSqFactory(String sqFactory) {
		this.sqFactory = sqFactory;
	}

	public Integer getSqTag() {
		return sqTag;
	}

	public void setSqTag(Integer sqTag) {
		this.sqTag = sqTag;
	}

	public String getSqArea() {
		return sqArea;
	}

	public void setSqArea(String sqArea) {
		this.sqArea = sqArea;
	}

	public BigDecimal getSqMinPrice() {
		return sqMinPrice;
	}

	public void setSqMinPrice(BigDecimal sqMinPrice) {
		this.sqMinPrice = sqMinPrice;
	}

	public BigDecimal getSqMaxPrice() {
		return sqMaxPrice;
	}

	public void setSqMaxPrice(BigDecimal sqMaxPrice) {
		this.sqMaxPrice = sqMaxPrice;
	}

	public BigDecimal getSqDropRange() {
		return sqDropRange;
	}

	public void setSqDropRange(BigDecimal sqDropRange) {
		this.sqDropRange = sqDropRange;
	}

	public BigDecimal getSqUpRange() {
		return sqUpRange;
	}

	public void setSqUpRange(BigDecimal sqUpRange) {
		this.sqUpRange = sqUpRange;
	}

	public String getREC_CREATEBY() {
		return REC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		REC_CREATEBY = rEC_CREATEBY;
	}

	public Date getREC_CREATETIME() {
		return REC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		REC_CREATETIME = rEC_CREATETIME;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public boolean equals(Object o) {
		return false;
	}

	public int hashCode() {
		return 0;
	}
}
