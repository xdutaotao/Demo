/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: MarketQuo
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永     Create
 * 06/02/16 　刘洪波  Real
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.dao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import shcem.base.dao.model.BaseObject;

/**
 * MarktetQuo
 * @author chiyong
 * @version 1.0
 */
public class MarketQuo extends BaseObject implements Serializable {
	/** 版本号 */
	private static final long serialVersionUID = -2728079010038263957L;

    /**  */
    private String id;
    
    /**  */
    private String mqType;
    
    /**  */
    private Integer mqDeliverydate;
    
    /**  */
    private BigDecimal mqPrice;
    
    /**  */
    private BigDecimal mqWave;
    
    /**  */
    private String REC_CREATEBY;
    
    /**  */
    private Date REC_CREATETIME;
    
    /**  */
    private String REC_MODIFYBY;
    
    /**  */
    private Date REC_MODIFYTIME;
    
    /**
     * 获取id
     * 
     * @return id
     */
     public String getId() {
        return this.id;
     }
     
    /**
     * 设置id
     * 
     * @param id
     *          id
     */
     public void setId(String id) {
        this.id = id;
     }
    
    /**
     * 获取mqType
     * 
     * @return mqType
     */
     public String getMqType() {
        return this.mqType;
     }
     
    /**
     * 设置mqType
     * 
     * @param mqType
     *          mqType
     */
     public void setMqType(String mqType) {
        this.mqType = mqType;
     }
    
    /**
     * 获取mqDeliverydate
     * 
     * @return mqDeliverydate
     */
     public Integer getMqDeliverydate() {
        return this.mqDeliverydate;
     }
     
    /**
     * 设置mqDeliverydate
     * 
     * @param mqDeliverydate
     *          mqDeliverydate
     */
     public void setMqDeliverydate(Integer mqDeliverydate) {
        this.mqDeliverydate = mqDeliverydate;
     }
    
    /**
     * 获取mqPrice
     * 
     * @return mqPrice
     */
     public BigDecimal getMqPrice() {
        return this.mqPrice;
     }
     
    /**
     * 设置mqPrice
     * 
     * @param mqPrice
     *          mqPrice
     */
     public void setMqPrice(BigDecimal mqPrice) {
        this.mqPrice = mqPrice;
     }
    
    /**
     * 获取mqWave
     * 
     * @return mqWave
     */
     public BigDecimal getMqWave() {
        return this.mqWave;
     }
     
    /**
     * 设置mqWave
     * 
     * @param mqWave
     *          mqWave
     */
     public void setMqWave(BigDecimal mqWave) {
        this.mqWave = mqWave;
     }

	public Date getREC_CREATETIME() {
		return REC_CREATETIME;
	}

	public void setREC_CREATETIME(Date rEC_CREATETIME) {
		REC_CREATETIME = rEC_CREATETIME;
	}

	public String getREC_MODIFYBY() {
		return REC_MODIFYBY;
	}

	public void setREC_MODIFYBY(String rEC_MODIFYBY) {
		REC_MODIFYBY = rEC_MODIFYBY;
	}

	public Date getREC_MODIFYTIME() {
		return REC_MODIFYTIME;
	}

	public void setREC_MODIFYTIME(Date rEC_MODIFYTIME) {
		REC_MODIFYTIME = rEC_MODIFYTIME;
	}

	public String getREC_CREATEBY() {
		return REC_CREATEBY;
	}

	public void setREC_CREATEBY(String rEC_CREATEBY) {
		REC_CREATEBY = rEC_CREATEBY;
	}


	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof MarketQuo))
			return false;

		MarketQuo m = (MarketQuo) o;

		return this.id != null ? this.id.equals(m.id) : m.id == null;
	}

	public int hashCode() {
		return this.id != null ? this.id.hashCode() : 0;
	}
}
