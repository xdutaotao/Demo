package shcem.inform.dao.model;

import java.io.Serializable;

import shcem.base.dao.model.BaseObject;

/**咨询信息 属性
 * @author zhangnan
 *
 */
public class InfoTagModel  extends BaseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int id;
	
	private String tagType;
	
	private String tagValues;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTagType() {
		return tagType;
	}

	public void setTagType(String tagType) {
		this.tagType = tagType;
	}

	public String getTagValues() {
		return tagValues;
	}

	public void setTagValues(String tagValues) {
		this.tagValues = tagValues;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
