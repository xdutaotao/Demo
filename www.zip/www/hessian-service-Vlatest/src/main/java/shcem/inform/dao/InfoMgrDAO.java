/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: InfoMgrDAO
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.dao;

import java.sql.SQLException;
import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.inform.dao.model.InfoCatogory;
import shcem.inform.dao.model.InfoCatogorys;
import shcem.inform.dao.model.InfoTagModel;
import shcem.inform.dao.model.QtRelation;
import shcem.inform.dao.model.QuotationServiceModel;

/**
 * InfoMgrDAO
 * 
 * @author chiyong
 * @version 1.0
 */
public abstract interface InfoMgrDAO extends DAO {

	/**
	 * @param childrenIds 
	 *
	 */
	public abstract List<QuotationServiceModel> getInfoList(QueryConditions qc,PageInfo pageInfo, String childrenIds);
	
	/**
	 * 
	 */
	public abstract QuotationServiceModel getInfoDetail(int quotationId);

	/**
	 *
	 */
	public abstract int insertInfo(QuotationServiceModel quotationServiceModel);

	/**
	 * 
	 */
	public abstract int updateInfo(QuotationServiceModel quotationServiceModel);

	/**
	 * 
	 */
	public abstract int deleteInfo(int quotationIds);

	public abstract List<InfoTagModel> getInfoTaglist(int quotationId,int tagTypeDiff);

	public abstract List<InfoCatogorys> getInfoCatogorysList(int quotationId);

	public abstract int insertQtRelation(int tagID, int quotationId, int relationType);

	public abstract int insertInfoQtContent(
			QuotationServiceModel quotationServiceModel);

	public abstract int updateInfoQtContent(
			QuotationServiceModel quotationServiceModel);

	public abstract int updateQtRelation(int tagID, int quotationId, int relationType);

	public abstract List<QtRelation> getQtRelationList(int quotationId, int relationType, int tagTypeDiff);

	public abstract int deleteInfoQtRelation(int quotationId, int relationType);

	public abstract List<InfoCatogorys> getChildQtRelation(int infoCatogoryPID);

	public abstract InfoCatogorys getInfoCatogoryById(int infoCatogoryPID);

	/**
	 * 广告列表
	 * @param qc
	 * @param pageInfo
	 * @param catogoryID
	 * @return
	 */
	public abstract List<QuotationServiceModel> getAdvertList(PageInfo pageInfo, int catogoryID);

	/**
	 * 广告分类
	 * @param childrenIds
	 * @return
	 */
	public abstract List<InfoCatogorys> getAdverClass(String childrenIds);

	public abstract int insertAdvert(QuotationServiceModel quotationServiceModel);

	public abstract void updateAdvert(
			QuotationServiceModel quotationServiceModel);

	public abstract QuotationServiceModel getAdvertDetailByID(int quotationID);

	public abstract List<QtRelation> getQtRelationLists(int quotationId, int i);

	public abstract List<QuotationServiceModel> getOldInfoList(String childrenIds,
			String childrenIds_Advert, QueryConditions qc, PageInfo pageInfo);

	/**
	 * 首页专题查询列表
	 */
	public abstract List<QuotationServiceModel> getHomeTopicInfoList(QueryConditions qc, PageInfo pageInfo);
	
	public abstract List<InfoCatogory> getOldInfoCatogory(String catogoryPIDs,
			String catogoryPIDs_advert);

	public abstract void rollBack();
}
