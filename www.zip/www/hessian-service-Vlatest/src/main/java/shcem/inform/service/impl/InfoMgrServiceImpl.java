/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: LogManagerImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.finance.util.JSONArrayUtil;
import shcem.inform.component.IInfoMgrManager;
import shcem.inform.dao.model.InfoCatogory;
import shcem.inform.dao.model.InfoCatogorys;
import shcem.inform.dao.model.QuotationServiceModel;
import shcem.inform.service.IInfoMgrService;
import shcem.inform.util.InformSysData;
import shcem.util.JsonUtil;

/**
 * InfoMgrServiceImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class InfoMgrServiceImpl extends BaseServiceImpl implements IInfoMgrService {
	
	private IInfoMgrManager mgr = (IInfoMgrManager) InformSysData.getBean(Constants.BEAN_INFOMGR_MGR);

	/**
	 *咨询信息列表
	 */
	public String getInfoList(String params) {
		this.log.info(this.getClass().getName() + " getInfoList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<QuotationServiceModel> list = null;
		//资讯分类   只查询分类为资讯数据（1767）下的资讯信息
//		int catogoryID = JOParams.getInt("catogoryID");
		int catogoryID = 1767;
		boolean bolRst = false;
		List<Condition> conditionList = new ArrayList<Condition>(); //允许的查询参数列表，定义字段，操作符及类型,查询json固定模型queryModel
		conditionList.add(new Condition("iqt.title","like","","String","title")); 
		conditionList.add(new Condition("iqt.infoStatus","=","","String","infoStatus")); 
		
		conditionList.add(new Condition("convert(char(10),iqt.postTime,120)", " >= ", "", "String", "startDate"));
		conditionList.add(new Condition("convert(char(10),iqt.postTime,120)", " <= ", "", "String", "endDate"));
		
		
		JSONObject queryModel =JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			list = this.mgr.getInfoList(qc,pageInfo,catogoryID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询咨询信息列表数据出错"+e.getMessage());
			setResultData("10105",null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			if (list != null && list.size() > 0) {
				try {
					retData = JsonUtil.coverModelToJSONArray(list);
					jsonObj.put("total", pageInfo.getTotalRecords());
					jsonObj.put("result", retData);
					setResultData("00000", jsonObj);
				} catch (Exception e) {
					this.log.error("咨询信息列表数据转换失败：" + e.getMessage());
					setResultData("28000", null, e.getMessage());
				}
			}else {
				setResultData("10101",null);
			}
			

		}
		this.log.info(this.getClass().getName() + " getInfoList() End");
		return rtnData.toString();
	}

	/**
	 * 
	 */
	public String getInfoDetail(String params) {
		this.log.info(this.getClass().getName() + " getInfoDetail() Start");
		boolean bolRst = false;
		JSONObject JOParams = new JSONObject(params);
		int quotationId = Integer.parseInt(JOParams.getString("quotationId"));
		QuotationServiceModel quotationServiceModel = null;
		try {
			quotationServiceModel = this.mgr.getInfoDetail(quotationId);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询资讯详细信息出错"+e.getMessage());
			setResultData("10105", null, e.getMessage());
		}
		if (bolRst) {
			JSONObject retData;			
			try {
				retData = JsonUtil.coverModelToJSONObject(quotationServiceModel);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error("资讯详细转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		
		this.log.info(this.getClass().getName() + " getInfoDetail() End");
		return rtnData.toString();
	}

	/**
	 * 
	 */
	public String insertInfo(String params) {
		this.log.info(this.getClass().getName() + " getInfoList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<QuotationServiceModel> list = null;
		
		QuotationServiceModel quotationServiceModel = (QuotationServiceModel) JsonUtil.jsonToBean(JOParams, QuotationServiceModel.class);
		//分类属性（tag属性）
		JSONArray infoTagssArrayTemp = JOParams.getJSONArray("infoTagssArray");
		int[] infoTagssArray = JSONArrayUtil.getJsonToIntArray(infoTagssArrayTemp);
	    //咨询分类 数组
	    JSONArray infoCatogorysArrayTemp = JOParams.getJSONArray("infoCatogorysArray");
		int[] infoCatogorysArray = JSONArrayUtil.getJsonToIntArray(infoCatogorysArrayTemp);
		//显示分类
		JSONArray viewTagsTemp = JOParams.getJSONArray("viewTags");
		int[] viewTags = JSONArrayUtil.getJsonToIntArray(viewTagsTemp); 
		
		
		
		quotationServiceModel.setInfoTagssArray(infoTagssArray);
		quotationServiceModel.setInfoCatogorysArray(infoCatogorysArray);
		quotationServiceModel.setViewTags(viewTags);
		
		quotationServiceModel.setREC_CREATEBY(getUserId());
		quotationServiceModel.setREC_MODIFYBY(getUserId());
		String result;
		try {
			result = this.mgr.insertInfo(quotationServiceModel);
			if (result.equals("success")) {
				setResultData("00000", null);
				this.log.businesslog("新增咨询数据成功", Constants.OPE_MODE_INFORM, Constants.OPE_SUCCESS);
			}else {
				setResultData("10105", null);
			}
		} catch (Exception e) {
			this.log.businesslog("新增咨询失败"+e.getMessage(), Constants.OPE_MODE_INFORM, Constants.OPE_FAIL);
			setResultData("10105", null, e.getMessage());
		}
		
		this.log.info(this.getClass().getName() + " insertInfo() End");
		return rtnData.toString();
	}
	
	/**
	 * 
	 */
	public String updateInfo(String params) {
		this.log.info(this.getClass().getName() + " updateInfo() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<QuotationServiceModel> list = null;
		QuotationServiceModel quotationServiceModel = (QuotationServiceModel) JsonUtil.jsonToBean(JOParams, QuotationServiceModel.class);
		//分类属性（tag属性）
		JSONArray infoTagssArrayTemp = JOParams.getJSONArray("infoTagssArray");
		int[] infoTagssArray = JSONArrayUtil.getJsonToIntArray(infoTagssArrayTemp);
	    //咨询分类 数组
	    JSONArray infoCatogorysArrayTemp = JOParams.getJSONArray("infoCatogorysArray");
		int[] infoCatogorysArray = JSONArrayUtil.getJsonToIntArray(infoCatogorysArrayTemp);
		//显示分类
		JSONArray viewTagsTemp = JOParams.getJSONArray("viewTags");
		int[] viewTags = JSONArrayUtil.getJsonToIntArray(viewTagsTemp); 
		
		quotationServiceModel.setInfoTagssArray(infoTagssArray);
		quotationServiceModel.setInfoCatogorysArray(infoCatogorysArray);
		quotationServiceModel.setViewTags(viewTags);
		quotationServiceModel.setREC_MODIFYBY(getUserId());
		String result;
		try {
			result = this.mgr.updateInfo(quotationServiceModel);
			if (result.equals("success")) {
				setResultData("00000", null);
				this.log.businesslog("修改咨询信息成功", Constants.OPE_MODE_INFORM, Constants.OPE_SUCCESS);
			}else {
				setResultData("10106", null);
			}
			
		} catch (Exception e) {
			this.log.businesslog("修改咨询失败"+e.getMessage(), Constants.OPE_MODE_INFORM, Constants.OPE_FAIL);
			setResultData("10106", null, e.getMessage());
		}
		return rtnData.toString();
	}
	
	/**
	 * 
	 */
	public String deleteInfo(String params) {
		
		this.log.info(this.getClass().getName() + " deleteVoucher() Start");
		JSONObject JOParams = new JSONObject(params);
		JSONArray quotationIdsTemp = JOParams.getJSONArray("quotationIds");
		int[] quotationIds = JSONArrayUtil.getJsonToIntArray(quotationIdsTemp);
		String result = null;
		try {
			result = this.mgr.deleteInfo(quotationIds);
			if (result.equals("success")) {
				setResultData("00000",null,result);
				this.log.businesslog("删除咨询消息成功", Constants.OPE_MODE_INFORM, Constants.OPE_SUCCESS);
			}else {
				setResultData("10106", null);
			}
		} catch (Exception e) {
			this.log.error("删除咨询消息出错"+e.getMessage());
			this.log.businesslog("删除咨询消息出错"+e.getMessage(), Constants.OPE_MODE_INFORM, Constants.OPE_FAIL);
			setResultData("00000", "删除凭证失败");
		}
		this.log.info(this.getClass().getName() + " deleteVoucher() End");
		return rtnData.toString();
	}

	/**
	 * 广告相关
	 */
	@Override
	public String getAdvertList(String params) {
		this.log.info(this.getClass().getName() + " getInfoList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<QuotationServiceModel> list = null;
		//广告分类
		int catogoryID = JOParams.getInt("catogoryID");
		boolean bolRst = false;
		
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			list = this.mgr.getAdvertList(pageInfo,catogoryID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询广告列表失败"+e.getMessage());
			setResultData("10105", null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			if (list != null && list.size() > 0) {
				try {
					retData = JsonUtil.coverModelToJSONArray(list);
					jsonObj.put("result", retData);
					setResultData("00000", jsonObj);
				} catch (Exception e) {
					this.log.error("咨询信息列表数据转换失败：" + e.getMessage());
					setResultData("10105", null, e.getMessage());
				}
			}else {
				setResultData("00000", null);
			}
		}
		return rtnData.toString();
	}

	@Override
	public String insertAdvert(String params) {
		this.log.info(this.getClass().getName() + " getInfoList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		QuotationServiceModel quotationServiceModel = (QuotationServiceModel) JsonUtil.jsonToBean(JOParams, QuotationServiceModel.class);
		quotationServiceModel.setREC_CREATEBY(getUserId());
		quotationServiceModel.setREC_MODIFYBY(getUserId());
		try {
			this.mgr.insertAdvert(quotationServiceModel);
			setResultData("00000",null);
			this.log.businesslog("新增广告成功", Constants.OPE_MODE_INFORM, Constants.OPE_SUCCESS);
		} catch (Exception e) {
			setResultData("10106",null);
			this.log.businesslog("新增广告出错"+e.getMessage(), Constants.OPE_MODE_INFORM, Constants.OPE_FAIL);
		}
		return rtnData.toString();
	}

	@Override
	public String updateAdvert(String params) {
		this.log.info(this.getClass().getName() + " getInfoList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		QuotationServiceModel quotationServiceModel = (QuotationServiceModel) JsonUtil.jsonToBean(JOParams, QuotationServiceModel.class);
		quotationServiceModel.setREC_MODIFYBY(getUserId());

		try {
			this.mgr.updateAdvert(quotationServiceModel);
			setResultData("00000",null);
			this.log.businesslog("更新广告成功", Constants.OPE_MODE_INFORM, Constants.OPE_SUCCESS);
		} catch (Exception e) {
			setResultData("10106",null);
			this.log.businesslog("更新广告出错"+e.getMessage(), Constants.OPE_MODE_INFORM, Constants.OPE_FAIL);
		}
		return rtnData.toString();
	}

	@Override
	public String deleteAdvert(String params) {
		return null;
	}

	@Override
	public String getAdvertDetail(String params) {	
		this.log.info(this.getClass().getName() + " getInfoList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		QuotationServiceModel quotationServiceModel= null;
		int quotationID = JOParams.getInt("quotationID");
		boolean bolRst = false;
		
		try {
			quotationServiceModel = this.mgr.getAdvertDetailByID(quotationID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询广告列表失败"+e.getMessage());
			setResultData("10107", null);
		}
		if (bolRst) {
			JSONObject retData;			
			try {
				retData = JsonUtil.coverModelToJSONObject(quotationServiceModel);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error("广告信息转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		return rtnData.toString();
	}
	@Override
	public String getAdverClass(String params) {
		this.log.info(this.getClass().getName() + " getInfoList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<InfoCatogorys> list = null;
		boolean bolRst = false;
		// 只查询分类为广告模块（1849）下的资讯信息
		int catogoryID = 1849;
		try {
			list = this.mgr.getAdverClass(catogoryID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询广告分类失败"+e.getMessage());
			setResultData("10105",null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			if (list!=null && list.size() > 0) {
				try {
					retData = JsonUtil.coverModelToJSONArray(list);
					jsonObj.put("result", retData);
					setResultData("00000", jsonObj);
				} catch (Exception e) {
					this.log.error("咨询信息列表数据转换失败：" + e.getMessage());
					setResultData("28000", null, e.getMessage());
				}
			}else {
				setResultData("10101",null);
			}
			
		}
		return rtnData.toString();
	}

	
	
	/**++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 * 咨询数据（老专场） Start
	 */
	@Override
	public String getOldInfoList(String params) {
		this.log.info(this.getClass().getName() + " getOldInfoList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<QuotationServiceModel> list = null;
		JSONObject authkeyid = JOParams.optJSONObject("authkeyid");
		//老专场资讯数据     剔除咨询管理（1767）和  广告模块（1849）下的资讯信息
		int[] catogoryID = {1767,1849};
		boolean bolRst = false;
		List<Condition> conditionList = new ArrayList<Condition>(); //允许的查询参数列表，定义字段，操作符及类型,查询json固定模型queryModel
		conditionList.add(new Condition("iqt.title","like","","String","title")); 
		conditionList.add(new Condition("iqt.infoStatus","=","","String","infoStatus")); 
		
		conditionList.add(new Condition("convert(char(10),iqt.postTime,120)", " >= ", "", "String", "startDate"));
		conditionList.add(new Condition("convert(char(10),iqt.postTime,120)", " <= ", "", "String", "endDate"));
		
		JSONObject queryModel =JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			list = this.mgr.getOldInfoList(catogoryID,qc,pageInfo);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询咨询信息列表数据出错"+e.getMessage());
			setResultData("10105",null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			if (list != null && list.size() > 0) {
				try {
					retData = JsonUtil.coverModelToJSONArray(list);
					jsonObj.put("total", pageInfo.getTotalRecords());
					jsonObj.put("result", retData);
					setResultData("00000", jsonObj);
				} catch (Exception e) {
					this.log.error("咨询信息列表数据转换失败：" + e.getMessage());
					setResultData("28000", null, e.getMessage());
				}
			}else {
				setResultData("10101",null);
			}
		}
		this.log.info(this.getClass().getName() + " getOldInfoList() End");
		return rtnData.toString();
	}
	
	/**
	 * 首页专题数据列表
	 */
	@Override
	public String getHomeTopicInfoList(String params) {
		this.log.info(this.getClass().getName() + " getHomeTopicInfoList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<QuotationServiceModel> list = null;
		JSONObject authkeyid = JOParams.optJSONObject("authkeyid");
		//老专场资讯数据     剔除咨询管理（1767）和  广告模块（1849）下的资讯信息
		int[] catogoryID = {1767,1849};
		boolean bolRst = false;
		List<Condition> conditionList = new ArrayList<Condition>(); //允许的查询参数列表，定义字段，操作符及类型,查询json固定模型queryModel
		conditionList.add(new Condition("info.title","like","","String","title")); 
		conditionList.add(new Condition("info.infoStatus","=","","String","infoStatus")); 
		conditionList.add(new Condition("info.infoCatogorys","=","","String","infoCatogorys")); //首页专题
		
		conditionList.add(new Condition("convert(char(10),info.postTime,120)", " >= ", "", "String", "startDate"));
		conditionList.add(new Condition("convert(char(10),info.postTime,120)", " <= ", "", "String", "endDate"));
		
		JSONObject queryModel =JOParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		try {
			list = this.mgr.getHomeTopicInfoList(qc,pageInfo);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询首页专题列表数据出错"+e.getMessage());
			setResultData("10105",null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			if (list != null && list.size() > 0) {
				try {
					retData = JsonUtil.coverModelToJSONArray(list);
					jsonObj.put("total", pageInfo.getTotalRecords());
					jsonObj.put("result", retData);
					setResultData("00000", jsonObj);
				} catch (Exception e) {
					this.log.error("首页专题列表数据转换失败：" + e.getMessage());
					setResultData("28000", null, e.getMessage());
				}
			}else {
				setResultData("10101",null);
			}
		}
		this.log.info(this.getClass().getName() + " getHomeTopicInfoList() End");
		return rtnData.toString();
	}
	
	@Override
	public String getOldInfoCatogory(String params) {
		this.log.info(this.getClass().getName() + " getOldInfoList() Start");
		boolean bolRst = false;
		List<InfoCatogory> list = null;
		//老专场资讯分类     剔除咨询管理（1767）和  广告模块（1849）下的资讯信息
		int[] catogoryID = {1767,1849};
		try {
			list = this.mgr.getOldInfoCatogory(catogoryID);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("咨询信息列表数据转换失败：" + e.getMessage());
			setResultData("10105", null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			if (list != null && list.size() > 0) {
				try {
					retData = JsonUtil.coverModelToJSONArray(list);
					jsonObj.put("result", retData);
					setResultData("00000", jsonObj);
				} catch (Exception e) {
					this.log.error("咨询信息列表数据转换失败：" + e.getMessage());
					setResultData("28000", null, e.getMessage());
				}
			}else {
				setResultData("10105",null);
			}
		}
		return rtnData.toString();
	}
	/**
	 * 老专场详情
	 */
	@Override
	public String getOldInfoDetail(String params) {
		this.log.info(this.getClass().getName() + " getInfoDetail() Start");
		boolean bolRst = false;
		JSONObject JOParams = new JSONObject(params);
		int quotationId = Integer.parseInt(JOParams.getString("quotationId"));
		QuotationServiceModel quotationServiceModel = null;
		try {
			quotationServiceModel = this.mgr.getInfoDetail(quotationId);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("查询资讯详细信息出错"+e.getMessage());
			setResultData("10105", null, e.getMessage());
		}
		if (bolRst) {
			JSONObject retData;			
			try {
				retData = JsonUtil.coverModelToJSONObject(quotationServiceModel);
				setResultData("00000", retData);
			} catch (Exception e) {
				this.log.error("资讯详细转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		
		this.log.info(this.getClass().getName() + " getInfoDetail() End");
		return rtnData.toString();
	}

	@Override
	public String addOldInfo(String params) {
		this.log.info(this.getClass().getName() + " addOldInfo() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		QuotationServiceModel quotationServiceModel = (QuotationServiceModel) JsonUtil.jsonToBean(JOParams, QuotationServiceModel.class);
		
	    //咨询分类 数组
	    JSONArray infoCatogorysArrayTemp = JOParams.getJSONArray("infoCatogorysArray");
		int[] infoCatogorysArray = JSONArrayUtil.getJsonToIntArray(infoCatogorysArrayTemp);

		quotationServiceModel.setInfoCatogorysArray(infoCatogorysArray);
		quotationServiceModel.setREC_CREATEBY(getUserId());
		quotationServiceModel.setREC_MODIFYBY(getUserId());
		String result;
		try {
			result = this.mgr.insertInfo(quotationServiceModel);
			if (result.equals("success")) {
				setResultData("00000", null);
				this.log.businesslog("新增咨询数据成功", Constants.OPE_MODE_INFORM, Constants.OPE_SUCCESS);
			}else {
				setResultData("10105", null);
			}
		} catch (Exception e) {
			this.log.businesslog("新增咨询失败"+e.getMessage(), Constants.OPE_MODE_INFORM, Constants.OPE_FAIL);
			setResultData("10105", null, e.getMessage());
		}
		
		this.log.info(this.getClass().getName() + " addOldInfo() End");
		return rtnData.toString();
	}

	@Override
	public String updateOldInfo(String params) {
		this.log.info(this.getClass().getName() + " updateOldInfo() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		QuotationServiceModel quotationServiceModel = (QuotationServiceModel) JsonUtil.jsonToBean(JOParams, QuotationServiceModel.class);
		
	    //咨询分类 数组
	    JSONArray infoCatogorysArrayTemp = JOParams.getJSONArray("infoCatogorysArray");
		int[] infoCatogorysArray = JSONArrayUtil.getJsonToIntArray(infoCatogorysArrayTemp);
		
		quotationServiceModel.setInfoCatogorysArray(infoCatogorysArray);
		quotationServiceModel.setREC_MODIFYBY(getUserId());
		String result;
		try {
			result = this.mgr.updateInfo(quotationServiceModel);
			if (!result.equals("fail")) {
				setResultData("00000", null);
				this.log.businesslog("修改咨询数据成功", Constants.OPE_MODE_INFORM, Constants.OPE_SUCCESS);
			}else {
				setResultData("10106", null);
			}
		} catch (Exception e) {
			this.log.businesslog("修改咨询失败"+e.getMessage(), Constants.OPE_MODE_INFORM, Constants.OPE_FAIL);
			setResultData("10106", null, e.getMessage());
		}
		this.log.info(this.getClass().getName() + " updateOldInfo() End");
		return rtnData.toString();
	}

	@Override
	public String deleteoOldInfo(String params) {
		this.log.info(this.getClass().getName() + " deleteVoucher() Start");
		JSONObject JOParams = new JSONObject(params);
		JSONArray quotationIdsTemp = JOParams.getJSONArray("quotationIds");
		int[] quotationIds = JSONArrayUtil.getJsonToIntArray(quotationIdsTemp);
		String result = null;
		try {
			result = this.mgr.deleteInfo(quotationIds);
			setResultData("00000",null,result);
			this.log.businesslog("删除咨询消息成功", Constants.OPE_MODE_INFORM, Constants.OPE_SUCCESS);
		} catch (Exception e) {
			this.log.error("删除咨询消息出错"+e.getMessage());
			this.log.businesslog("删除咨询消息出错"+e.getMessage(), Constants.OPE_MODE_INFORM, Constants.OPE_FAIL);
			setResultData("00000", "删除凭证失败");
		}
		this.log.info(this.getClass().getName() + " deleteVoucher() End");
		return rtnData.toString();
	}
	
	/**
	 * 咨询数据（老专场） End
	 * ------------------------------------------------------------------
	 */
}