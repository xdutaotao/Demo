/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IInfoMgrService
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.service;

/**
 * IInfoMgrService
 * 
 * @author chiyong
 * @version 1.0
 */
public interface IInfoMgrService {

	/**
	 * 
	 */
	public String getInfoList(String params);
	
	/**
	 * 
	 */
	public String getInfoDetail(String params);

	/**
	 * 
	 */
	public String insertInfo(String params);

	/**
	 *
	 */
	public String updateInfo(String params);

	/**
	 * 
	 */
	public String deleteInfo(String params);
	/**
	 * 广告列表
	 */
	public String getAdvertList(String params);
	/**
	 * 新增广告
	 */
	public String insertAdvert(String params);
	/**
	 * 修改广告
	 */
	public String updateAdvert(String params);
	/**
	 * 删除广告
	 */
	public String deleteAdvert(String params);
	/**
	 * 获取广告详情
	 */
	public String getAdvertDetail(String params);
	/**
	 * 获取广告分类
	 */
	public String getAdverClass(String params);
	
	/**++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 * 咨询数据（老专场） Start
	 */
	
	public String getOldInfoList(String params);
	
	public String getOldInfoCatogory(String params);
	
	public String getOldInfoDetail(String params);
	
	public String addOldInfo(String params);
	
	public String updateOldInfo(String params);
	
	public String deleteoOldInfo(String params);

	/**
	 * 首页专题查询列表
	 */
	public String getHomeTopicInfoList(String params);
	
	/**
	 * 咨询数据（老专场） End
	 * ------------------------------------------------------------------
	 */
	
}