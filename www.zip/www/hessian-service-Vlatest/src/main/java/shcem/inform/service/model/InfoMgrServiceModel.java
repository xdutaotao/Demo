/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: InfoMgrServiceModel
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 05/17/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.service.model;

import java.io.Serializable;
import java.util.Hashtable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.json.JSONObject;

import shcem.base.service.model.BaseServiceObject;

/**
 * InfoMgrServiceModel
 * 
 * @author chiyong
 * @version 1.0
 */
public class InfoMgrServiceModel extends BaseServiceObject implements Serializable {

	private static final long serialVersionUID = 1L;

	// 服务A对象的keyCode
	private String ID;

	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof InfoMgrServiceModel))
			return false;

		InfoMgrServiceModel m = (InfoMgrServiceModel) o;

		return this.ID != null ? this.ID.equals(m.ID) : m.ID == null;
	}
	
	public int hashCode() {
		return this.ID != null ? this.ID.hashCode() : 0;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public JSONObject toJSONObject() {

		Hashtable<String, Object> tb = new Hashtable<String, Object>();
		tb.put("ID", this.ID == null ? "" : this.ID);

		return new JSONObject(tb);
	}

	/**
	 * @return the bankID
	 */
	public String getID() {
		return ID;
	}

	/**
	 * @param bankID
	 *            the bankID to set
	 */
	public void setID(String ID) {
		this.ID = ID;
	}

}
