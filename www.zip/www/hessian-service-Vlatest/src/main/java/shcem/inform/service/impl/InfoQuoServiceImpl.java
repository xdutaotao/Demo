/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: InfoQuoServiceImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永     Create
 * 06/02/16 　刘洪波  Real
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.service.impl;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.constant.ResultCode;
import shcem.inform.component.IInfoQuoManager;
import shcem.inform.dao.model.MarketQuo;
import shcem.inform.dao.model.ScemQuo;
import shcem.inform.service.IInfoQuoService;
import shcem.inform.service.model.InfoQuoServiceModel;
import shcem.inform.util.InformSysData;
import shcem.util.Common;
import shcem.util.CopyProperties;
import shcem.util.ImportHttpExecl;
import shcem.util.JsonUtil;

/**
 * InfoQuoServiceImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class InfoQuoServiceImpl extends BaseServiceImpl implements IInfoQuoService {

	/**
	 * 
	 */
	public String getMarketQuoList(String params) {

		this.log.info(this.getClass().getName() + " getMarketQuoList() Start");
		this.log.debug("JSONParams=" + params);
		IInfoQuoManager mgr = (IInfoQuoManager) InformSysData.getBean(Constants.BEAN_INFOQUO_MGR);

		boolean bolRst = false;
		List<MarketQuo> list = null;
		JSONObject JSONParams = new JSONObject(params);
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JSONParams);
		try {
			list = mgr.getMarketQuoList(null, pageInfo);
			if (null != list && list.size()>0) {
				bolRst = true;
			} else {
				this.log.error("取得市场行情列表信息失败");
				setResultData(ResultCode.CODE10101.getValue(), null, "取得市场行情列表信息失败");
			}
		} catch (Exception e) {
			this.log.error("取得市场行情列表信息失败：" + e.getMessage());
			setResultData(ResultCode.CODE10104.getValue(), null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData(ResultCode.CODE00000.getValue(), jsonObj);
			} catch (Exception e) {
				this.log.error("市场行情信息转换失败：" + e.getMessage());
				setResultData(ResultCode.CODE10104.getValue(), null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getMarketQuoList() End");

		return rtnData.toString();
	}

	/**
	 * 
	 */
	public String getMarketQuoById(String params) {

		this.log.info(this.getClass().getName() + " getMarketQuoById() Start");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		IInfoQuoManager mgr = (IInfoQuoManager) InformSysData.getBean(Constants.BEAN_INFOQUO_MGR);

		boolean bolRst = false;
		MarketQuo marketQuo = null;
		InfoQuoServiceModel iQSM = new InfoQuoServiceModel();

		try {
			marketQuo = mgr.getMarketQuoById(JOParams.getString("id"));
			if (null != marketQuo) {
				bolRst = true;
			} else {
				this.log.error("取得市场行情信息失败");
				setResultData(ResultCode.CODE10101.getValue(), null, "取得市场行情信息失败");
			}
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error("取得市场行情信息失败：" + e.getMessage());
			setResultData(ResultCode.CODE10105.getValue(), null, e.getMessage());
		}
		if (bolRst) {
			JSONObject retData;
			try {
				CopyProperties.copyProperties(marketQuo, iQSM);
				retData = JsonUtil.coverModelToJSONObject(iQSM);
				setResultData(ResultCode.CODE00000.getValue(), retData);
			} catch (Exception e) {
				this.log.error("市场行情信息转换失败：" + e.getMessage());
				setResultData(ResultCode.CODE10105.getValue(), null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getMarketQuoById() End");

		return rtnData.toString();
	}

	/**
	 * 
	 */
	public String getStartEndDateMarketQuoList(String params) {

		this.log.info(this.getClass().getName() + " getStartEndDateMarketQuoList() Start");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);

		String strStartDate = JOParams.getString("startDate");
		String strEndDate = JOParams.getString("endDate");
		this.log.debug("startDate" + strStartDate);
		this.log.debug("endDate" + strEndDate);
		IInfoQuoManager mgr = (IInfoQuoManager) InformSysData.getBean(Constants.BEAN_INFOQUO_MGR);

		boolean bolRst = false;
		List<MarketQuo> list = null;

		try {
			java.util.Date startDate = Common.df5.parse(strStartDate + " 00:00:00");
			java.util.Date endDate = Common.df5.parse(strEndDate + " 23:59:59");
			list = mgr.getStartEndDateMarketQuoList(startDate, endDate);
			if (null != list && list.size()>0) {
				bolRst = true;
			} else {
				this.log.error("取得市场行情列表信息失败");
				setResultData(ResultCode.CODE10101.getValue(), null, "取得市场行情列表信息失败");
			}
		} catch (Exception e) {
			this.log.error("取得市场行情列表信息失败：" + e.getMessage());
			setResultData(ResultCode.CODE10104.getValue(), null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", "10");
				jsonObj.put("result", retData);
				setResultData(ResultCode.CODE00000.getValue(), jsonObj);
			} catch (Exception e) {
				this.log.error("市场行情信息转换失败：" + e.getMessage());
				setResultData(ResultCode.CODE10104.getValue(), null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getStartEndDateMarketQuoList() End");

		return rtnData.toString();
	}

	/**
	 * 
	 */
	public String insertMarketQuo(String params) {
		this.log.info(this.getClass().getName() + " insertMarketQuo() Start");

		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		MarketQuo marketQuo = null;
		marketQuo = (MarketQuo) JsonUtil.jsonToBean(JOParams, MarketQuo.class);
		IInfoQuoManager mgr = (IInfoQuoManager) InformSysData.getBean(Constants.BEAN_INFOQUO_MGR);

		try {
			// 用户信息
			marketQuo.setREC_CREATEBY(this.getUserId());
			marketQuo.setREC_MODIFYBY(this.getUserId());
			mgr.insertMarketQuo(marketQuo);
			this.log.businesslog("新增市场行情成功", Constants.OPE_MODE_INFORM, Constants.OPE_SUCCESS);
			setResultData(ResultCode.CODE00000.getValue(), null);
		} catch (Exception e) {
			this.log.error("新增市场行情出错" + e.getMessage());
			setResultData(ResultCode.CODE10106.getValue(), null, e.getMessage());
			this.log.businesslog("新增市场行情出错", Constants.OPE_MODE_INFORM, Constants.OPE_FAIL);
		}

		this.log.info(this.getClass().getName() + " insertMarketQuo() End");
		return rtnData.toString();
	}

	/**
	 *
	 */
	public String updateMarketQuo(String params) {
		this.log.info(this.getClass().getName() + " updateMarketQuo() Start");

		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		MarketQuo marketQuo = null;
		marketQuo = (MarketQuo) JsonUtil.jsonToBean(JOParams, MarketQuo.class);
		IInfoQuoManager mgr = (IInfoQuoManager) InformSysData.getBean(Constants.BEAN_INFOQUO_MGR);

		try {
			// 用户信息
			marketQuo.setREC_MODIFYBY(this.getUserId());
			int chgNum = mgr.updateMarketQuo(marketQuo);
			if (chgNum == 0) {
				this.log.error("更新市场行情出错，无对应数据。");
				setResultData(ResultCode.CODE10106.getValue(), null, "更新市场行情出错，无对应数据。");
				this.log.businesslog("更新市场行情出错，无对应数据。", Constants.OPE_MODE_TRADE, Constants.OPE_FAIL);
			} else {
				this.log.businesslog("更新市场行情成功", Constants.OPE_MODE_INFORM, Constants.OPE_SUCCESS);
				setResultData(ResultCode.CODE00000.getValue(), null);
			}
		} catch (Exception e) {
			this.log.error("更新市场行情出错" + e.getMessage());
			setResultData(ResultCode.CODE10106.getValue(), null, e.getMessage());
			this.log.businesslog("更新市场行情出错", Constants.OPE_MODE_INFORM, Constants.OPE_FAIL);
		}

		this.log.info(this.getClass().getName() + " updateMarketQuo() End");
		return rtnData.toString();
	}

	/**
	 * 
	 */
	public String deleteMarketQuo(String params) {
		this.log.info(this.getClass().getName() + " deleteMarketQuo() Start");

		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		IInfoQuoManager mgr = (IInfoQuoManager) InformSysData.getBean(Constants.BEAN_INFOQUO_MGR);

		try {
			int chgNum = mgr.deleteMarketQuo(JOParams.getString("id"));
			if (chgNum == 0) {
				this.log.error("删除市场行情出错，无对应数据。");
				setResultData(ResultCode.CODE10107.getValue(), null, "删除市场行情出错，无对应数据。");
				this.log.businesslog("删除市场行情出错，无对应数据。", Constants.OPE_MODE_TRADE, Constants.OPE_FAIL);
			} else {
				this.log.businesslog("删除市场行情成功", Constants.OPE_MODE_INFORM, Constants.OPE_SUCCESS);
				setResultData(ResultCode.CODE00000.getValue(), null);
			}
		} catch (Exception e) {
			this.log.error("删除市场行情出错" + e.getMessage());
			setResultData(ResultCode.CODE10107.getValue(), null, e.getMessage());
			this.log.businesslog("删除市场行情出错", Constants.OPE_MODE_INFORM, Constants.OPE_FAIL);
		}

		this.log.info(this.getClass().getName() + " deleteMarketQuo() End");
		return rtnData.toString();
	}

	/**
	 *
	 */
	public String getScemQuo(String params) {

		this.log.info(this.getClass().getName() + " getScemQuo() Start");
		this.log.debug("JSONParams=" + params);
		IInfoQuoManager mgr = (IInfoQuoManager) InformSysData.getBean(Constants.BEAN_INFOQUO_MGR);

		boolean bolRst = false;
		List<ScemQuo> list = null;
		JSONObject JSONParams = new JSONObject(params);
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JSONParams);
		try {
			list = mgr.getScemQuo(null, pageInfo);
			if (null != list && list.size()>0) {
				bolRst = true;
			} else {
				this.log.error("取得化交价格列表信息失败");
				setResultData(ResultCode.CODE10101.getValue(), null, "取得化交价格列表信息失败");
			}
		} catch (Exception e) {
			this.log.error("取得化交价格列表信息失败：" + e.getMessage());
			setResultData(ResultCode.CODE10104.getValue(), null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData(ResultCode.CODE00000.getValue(), jsonObj);
			} catch (Exception e) {
				this.log.error("化交价格转换失败：" + e.getMessage());
				setResultData(ResultCode.CODE10104.getValue(), null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getScemQuo() End");
		return rtnData.toString();
	}
	
	/**
	 *
	 */
	public String getScemQuoHistory(String params) {

		this.log.info(this.getClass().getName() + " getScemQuoHistory() Start");
		this.log.debug("JSONParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		JSONObject queryModel = JOParams.optJSONObject("queryModel");
		List<Condition> conditionList = new ArrayList<Condition>();

		conditionList.add(new Condition("convert(char(10),t.sqDate,120)", ">=", "", "String", "startDate"));
		conditionList.add(new Condition("convert(char(10),t.sqDate,120)", "<=", "", "String", "endDate"));

		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		IInfoQuoManager mgr = (IInfoQuoManager) InformSysData.getBean(Constants.BEAN_INFOQUO_MGR);

		boolean bolRst = false;
		List<ScemQuo> list = null;
		try {
			list = mgr.getScemQuoHistory(qc, pageInfo);
			if (null != list && list.size()>0) {
				bolRst = true;
			} else {
				this.log.error("历史取得化交价格列表信息失败");
				setResultData(ResultCode.CODE10101.getValue(), null, "历史取得化交价格列表信息失败");
			}
		} catch (Exception e) {
			this.log.error("历史取得化交价格列表信息失败：" + e.getMessage());
			setResultData(ResultCode.CODE10104.getValue(), null, e.getMessage());
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData(ResultCode.CODE00000.getValue(), jsonObj);
			} catch (Exception e) {
				this.log.error("历史化交价格转换失败：" + e.getMessage());
				setResultData(ResultCode.CODE10104.getValue(), null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getScemQuoHistory() End");
		return rtnData.toString();
	}

	
	/**
	 *化交价格从Excel导入
	 */
	public String insertScemQuo(String params) {
		this.log.info(this.getClass().getName() + " insertScemQuo() Start");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		List<ScemQuo> scemQuoPEList = null;
		List<ScemQuo> scemQuoPPList = null;
		List<ScemQuo> scemQuoPVCList = null;
		String url = JOParams.getString("url");
		IInfoQuoManager mgr = (IInfoQuoManager) InformSysData.getBean(Constants.BEAN_INFOQUO_MGR);

		try {
			scemQuoPEList = setSheetPE(url);
			if (null != scemQuoPEList) {
				scemQuoPPList = setSheetPP(url);
				if (null != scemQuoPPList) {
					scemQuoPVCList = setSheetPVC(url);
				}
			}

			if (null != scemQuoPEList && null != scemQuoPPList && null != scemQuoPVCList) {
				if (scemQuoPEList.size() > 0) {
					mgr.insertScemQuo(scemQuoPEList);
				}
				if (scemQuoPPList.size() > 0) {
					mgr.insertScemQuo(scemQuoPPList);
				}
				if (scemQuoPVCList.size() > 0) {
					mgr.insertScemQuo(scemQuoPVCList);
				}
				this.log.businesslog("新增化交价格成功", Constants.OPE_MODE_INFORM, Constants.OPE_SUCCESS);
				setResultData(ResultCode.CODE00000.getValue(), null);
			}
		} catch (Exception e) {
			this.log.error("新增化交价格出错" + e.getMessage());
			setResultData(ResultCode.CODE10106.getValue(), null, e.getMessage());
			this.log.businesslog("新增化交价格出错", Constants.OPE_MODE_INFORM, Constants.OPE_FAIL);
		}

		this.log.info(this.getClass().getName() + " insertScemQuo() End");
		return rtnData.toString();
	}
	
	/**
	 *
	 */
	public String updateScemQuoBoth(String params) {
		this.log.info(this.getClass().getName() + " updateScemQuoBoth() Start");

		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		ScemQuo scemQuo = null;
		scemQuo = (ScemQuo) JsonUtil.jsonToBean(JOParams, ScemQuo.class);
		IInfoQuoManager mgr = (IInfoQuoManager) InformSysData.getBean(Constants.BEAN_INFOQUO_MGR);

		try {
			// 创建用户信息
			scemQuo.setREC_CREATEBY(this.getUserId());
			int chgNum = mgr.updateScemQuoBoth(scemQuo);
			if (chgNum == 0) {
				this.log.error("更新化交价格行情出错，无对应数据。");
				this.log.businesslog("更新化交价格行情出错，无对应数据。", Constants.OPE_MODE_TRADE, Constants.OPE_FAIL);
				setResultData(ResultCode.CODE10106.getValue(), null, "更新化交价格行情出错，无对应数据。");
			} else {
				this.log.businesslog("更新化交价格行情成功", Constants.OPE_MODE_INFORM, Constants.OPE_SUCCESS);
				setResultData(ResultCode.CODE00000.getValue(), null);
			}
		} catch (Exception e) {
			this.log.error("更新化交价格行情出错" + e.getMessage());
			setResultData(ResultCode.CODE10106.getValue(), null, e.getMessage());
			this.log.businesslog("更新化交价格行情出错", Constants.OPE_MODE_INFORM, Constants.OPE_FAIL);
		}

		this.log.info(this.getClass().getName() + " updateScemQuoBoth() End");
		return rtnData.toString();
	}
	
	/**
	 * 
	 */
	public String getScemQuoById(String params) {

		this.log.info(this.getClass().getName() + " getScemQuoById() Start");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		IInfoQuoManager mgr = (IInfoQuoManager) InformSysData.getBean(Constants.BEAN_INFOQUO_MGR);

		boolean bolRst = false;
		ScemQuo scemQuo = null;

		try {
			scemQuo = mgr.getScemQuoById(JOParams.getString("id"));
			if (null != scemQuo) {
				bolRst = true;
			} else {
				this.log.error("取得化交价格行情失败");
				setResultData(ResultCode.CODE10101.getValue(), null, "取得化交价格行情失败");
			}
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error("取得化交价格行情失败：" + e.getMessage());
			setResultData(ResultCode.CODE10105.getValue(), null, e.getMessage());
		}
		if (bolRst) {
			JSONObject retData;
			try {
				retData = JsonUtil.coverModelToJSONObject(scemQuo);
				setResultData(ResultCode.CODE00000.getValue(), retData);
			} catch (Exception e) {
				this.log.error("化交价格行情转换失败：" + e.getMessage());
				setResultData(ResultCode.CODE10105.getValue(), null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getScemQuoById() End");
		return rtnData.toString();
	}
	
	/**
	 * 
	 */
	public String getScemQuoHistoryById(String params) {

		this.log.info(this.getClass().getName() + " getScemQuoHistoryById() Start");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		IInfoQuoManager mgr = (IInfoQuoManager) InformSysData.getBean(Constants.BEAN_INFOQUO_MGR);

		boolean bolRst = false;
		ScemQuo scemQuo = null;

		try {
			scemQuo = mgr.getScemQuoHistoryById(JOParams.getString("id"));
			if (null != scemQuo) {
				bolRst = true;
			} else {
				this.log.error("取得化交价格行情历史失败");
				setResultData(ResultCode.CODE10101.getValue(), null, "取得化交价格行情历史失败");
			}
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error("取得化交价格行情历史失败：" + e.getMessage());
			setResultData(ResultCode.CODE10105.getValue(), null, e.getMessage());
		}
		if (bolRst) {
			JSONObject retData;
			try {
				retData = JsonUtil.coverModelToJSONObject(scemQuo);
				setResultData(ResultCode.CODE00000.getValue(), retData);
			} catch (Exception e) {
				this.log.error("化交价格行情历史转换失败：" + e.getMessage());
				setResultData(ResultCode.CODE10105.getValue(), null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getScemQuoHistoryById() End");
		return rtnData.toString();
	}
	
	private List<ScemQuo> setSheetPE(String filePath) {
		this.log.debug("setSheetPE() Start");
		List<ScemQuo> rtnLst = new ArrayList<ScemQuo>();
		ScemQuo scemQuo = null;
		ImportHttpExecl ihe = new ImportHttpExecl();

		// 读取Excel2007
        List<List<String>> list = ihe.read(filePath,0,true);

        String err = ihe.getErrorInfo();
        if (null != err && !err.isEmpty()) {
        	// Excel2007失败，再次尝试读取Excel2003
        	ihe = new ImportHttpExecl();
        	list = ihe.read(filePath,0,false);
        }
        err = null;
        err = ihe.getErrorInfo();
        if (null != err && !err.isEmpty()) {
        	this.log.error(err);
			setResultData(ResultCode.CODE10103.getValue(), null, err);
			return null;
        }
        
        if (list == null || list.isEmpty()) {
        	this.log.error("PE模板读取失败");
			setResultData(ResultCode.CODE10104.getValue(), null, "PE模板读取失败");
        	return null;
        }
        if (!chkOneDay(list)) {
			this.log.error("PE模板日期必須是同一天");
			setResultData(ResultCode.CODE10103.getValue(), null, "PE模板日期必須是同一天");
			return null;
        }
 
        for (int i = 1; i < list.size(); i++) {  
        	scemQuo = new ScemQuo();
            List<String> cellList = list.get(i);  
            java.util.Date date = null;
			try {
				if (null == cellList.get(0) || "".equals(cellList.get(0))) {
					break;
				}
				date = Common.df2.parse(cellList.get(0));
                scemQuo.setSqDate(date);
                scemQuo.setSqProduct(ihe.getSheetName());
                scemQuo.setSqRank(cellList.get(1));
                String strSqNo = cellList.get(2);
                if (ImportHttpExecl.isNumber2(strSqNo)) {
                	strSqNo = strSqNo.substring(0, strSqNo.length()-2);
                }
                scemQuo.setSqNo(strSqNo);
                scemQuo.setSqType(cellList.get(3));
                scemQuo.setSqFactory("");
                scemQuo.setSqTag(Constants.I_INFOTAG_PE);
                scemQuo.setSqArea(cellList.get(4));
                scemQuo.setSqMinPrice(new BigDecimal(cellList.get(5)));
                scemQuo.setSqMaxPrice(new BigDecimal(cellList.get(6)));
                scemQuo.setSqDropRange(new BigDecimal(cellList.get(7)));
                scemQuo.setSqUpRange(new BigDecimal(cellList.get(8)));
                scemQuo.setREC_CREATEBY(this.getUserId());
                rtnLst.add(scemQuo);
			} catch (ParseException e) {
				this.log.error("PE模板实体类设定失败");
				e.printStackTrace();
			}
        }  
        this.log.debug("setSheetPE() End");
		return rtnLst;
	}
	
	private List<ScemQuo> setSheetPP(String filePath) {
		this.log.debug("setSheetPP() Start");
		List<ScemQuo> rtnLst = new ArrayList<ScemQuo>();
		ScemQuo scemQuo = null;
		ImportHttpExecl ihe = new ImportHttpExecl();

        List<List<String>> list = ihe.read(filePath,1,true);
        String err = ihe.getErrorInfo();
        if (null != err && !err.isEmpty()) {
        	// Excel2007失败，再次尝试读取Excel2003
        	ihe = new ImportHttpExecl();
        	list = ihe.read(filePath,0,false);
        }
        err = null;
        err = ihe.getErrorInfo();
        if (null != err && !err.isEmpty()) {
        	this.log.error(err);
			setResultData(ResultCode.CODE10103.getValue(), null, err);
			return null;
        }
        if (list == null || list.isEmpty()) {
        	this.log.error("PP模板读取失败");
			setResultData(ResultCode.CODE10104.getValue(), null, "PP模板读取失败");
        	return null;
        }
        if (!chkOneDay(list)) {
			this.log.error("PP模板日期必須是同一天");
			setResultData(ResultCode.CODE10103.getValue(), null, "PP模板日期必須是同一天");
			return null;
        }
        for (int i = 1; i < list.size(); i++) {  
        	scemQuo = new ScemQuo();
            List<String> cellList = list.get(i);  
            java.util.Date date = null;
			try {
				if (null == cellList.get(0) || "".equals(cellList.get(0))) {
					break;
				}
				date = Common.df2.parse(cellList.get(0));
                scemQuo.setSqDate(date);
                scemQuo.setSqProduct(ihe.getSheetName());
                scemQuo.setSqRank(cellList.get(1));
                scemQuo.setSqNo("-");
                scemQuo.setSqType(cellList.get(2));
                scemQuo.setSqFactory("");
                scemQuo.setSqTag(Constants.I_INFOTAG_PP);
                scemQuo.setSqArea(cellList.get(3));
                scemQuo.setSqMinPrice(new BigDecimal(cellList.get(4)));
                scemQuo.setSqMaxPrice(new BigDecimal(cellList.get(5)));
                scemQuo.setSqDropRange(new BigDecimal(cellList.get(6)));
                scemQuo.setSqUpRange(new BigDecimal(cellList.get(7)));
                scemQuo.setREC_CREATEBY(this.getUserId());
                rtnLst.add(scemQuo);
			} catch (ParseException e) {
				this.log.error("PP模板实体类设定失败");
				e.printStackTrace();
			}
        }
        this.log.debug("setSheetPP() End");
		return rtnLst;
	}
	
	private List<ScemQuo> setSheetPVC(String filePath) {
		this.log.debug("setSheetPVC() Start");
		List<ScemQuo> rtnLst = new ArrayList<ScemQuo>();
		ScemQuo scemQuo = null;
		ImportHttpExecl ihe = new ImportHttpExecl();

        List<List<String>> list = ihe.read(filePath,2,true);
        String err = ihe.getErrorInfo();
        if (null != err && !err.isEmpty()) {
        	// Excel2007失败，再次尝试读取Excel2003
        	ihe = new ImportHttpExecl();
        	list = ihe.read(filePath,0,false);
        }
        err = null;
        err = ihe.getErrorInfo();
        if (null != err && !err.isEmpty()) {
        	this.log.error(err);
			setResultData(ResultCode.CODE10103.getValue(), null, err);
			return null;
        }
        if (list == null || list.isEmpty()) {
        	this.log.error("PVC模板读取失败");
			setResultData(ResultCode.CODE10104.getValue(), null, "PVC模板读取失败");
        	return null;
        }
        if (!chkOneDay(list)) {
			this.log.error("PVC模板日期必須是同一天");
			setResultData(ResultCode.CODE10103.getValue(), null, "PVC模板日期必須是同一天");
			return null;
        }

        for (int i = 1; i < list.size(); i++) {  
        	scemQuo = new ScemQuo();
            List<String> cellList = list.get(i);  
            java.util.Date date = null;
			try {
				if (null == cellList.get(0) || "".equals(cellList.get(0))) {
					break;
				}
				date = Common.df2.parse(cellList.get(0));
				scemQuo.setSqDate(date);
                scemQuo.setSqProduct(ihe.getSheetName());
                scemQuo.setSqRank(cellList.get(1));
                scemQuo.setSqNo("-");
                scemQuo.setSqType(cellList.get(2));
                scemQuo.setSqFactory("");
                scemQuo.setSqTag(Constants.I_INFOTAG_PVC);
                scemQuo.setSqArea(cellList.get(3));
                scemQuo.setSqMinPrice(new BigDecimal(cellList.get(4)));
                scemQuo.setSqMaxPrice(new BigDecimal(cellList.get(5)));
                scemQuo.setSqDropRange(new BigDecimal(cellList.get(6)));
                scemQuo.setSqUpRange(new BigDecimal(cellList.get(7)));
                scemQuo.setREC_CREATEBY(this.getUserId());
                rtnLst.add(scemQuo);
			} catch (ParseException e) {
				this.log.error("PVC模板实体类设定失败");
				e.printStackTrace();
			}
        }
        this.log.debug("setSheetPVC() End");
		return rtnLst;
	}
	
	private boolean chkOneDay(List<List<String>> list) {
		boolean rtn = true;
		if (list != null) {
			List<String> cellList1 = list.get(1);
			String date1 = cellList1.get(0);
			for (int i = 2; i < list.size(); i++) {
				List<String> cellList2 = list.get(i);
				String date2 = cellList2.get(0);
				if (!"".equals(date2) && date1.compareTo(date2) != 0) {
					rtn = false;
					break;
				}
			}
		}
		return rtn;
	}
}