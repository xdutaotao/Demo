/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: InfoCtgServiceImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 06/06/16 　刘洪波   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.service.impl;

import java.util.HashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.constant.ResultCode;
import shcem.inform.component.IInfoCtgManager;
import shcem.inform.dao.model.InfoCatogory;
import shcem.inform.service.IInfoCtgService;
import shcem.inform.service.model.InfoCtgServiceModel;
import shcem.inform.util.InformSysData;
import shcem.util.CopyProperties;
import shcem.util.JsonUtil;

/**
 * InfoCtgServiceImpl
 * 
 * @author chiyong
 * @version 1.0
 */
public class InfoCtgServiceImpl extends BaseServiceImpl implements IInfoCtgService {

	/**
	 * 
	 */
	public String getInfoCatogory() {

		this.log.info(this.getClass().getName() + " getInfoCatogory() Start");

		IInfoCtgManager mgr = (IInfoCtgManager) InformSysData.getBean(Constants.BEAN_INFOCTG_MGR);

		boolean bolRst = false;
		List<InfoCatogory> list = null;
		try {
			list = mgr.getAllInfoCatogoryList();
			if (null != list && list.size()>0) {
				bolRst = true;
			} else {
				this.log.error("取得资讯分类列表信息失败");
				setResultData(ResultCode.CODE10101.getValue(), null, "取得资讯分类列表信息失败");
			}
		} catch (Exception e) {
			this.log.error("取得资讯分类列表信息失败：" + e.getMessage());
			setResultData(ResultCode.CODE10104.getValue(), null, e.getMessage());
		}

		if (bolRst) {
			try {
				JSONObject strTree = createMenuTree(list, null);
				setResultData(ResultCode.CODE00000.getValue(), strTree);
			} catch (Exception e) {
				this.log.error("资讯分类列表转换失败：" + e.getMessage());
				setResultData(ResultCode.CODE10104.getValue(), null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getInfoCatogory() End");
		return rtnData.toString();
	}
	
	public String getInfoCatogoryWithPm(String params) {

		this.log.info(this.getClass().getName() + " getInfoCatogoryWithPm() Start");
		JSONObject JOParams = new JSONObject(params);
		String id = JOParams.getString("id");
		this.log.debug("id:" + id);
		IInfoCtgManager mgr = (IInfoCtgManager) InformSysData.getBean(Constants.BEAN_INFOCTG_MGR);

		boolean bolRst = false;
		List<InfoCatogory> list = null;
		try {
			list = mgr.getAllInfoCatogoryList();
			if (null != list && list.size()>0) {
				bolRst = true;
			} else {
				this.log.error("取得资讯分类列表信息失败");
				setResultData(ResultCode.CODE10101.getValue(), null, "取得资讯分类列表信息列表失败");
			}
		} catch (Exception e) {
			this.log.error("取得资讯分类列表信息失败：" + e.getMessage());
			setResultData(ResultCode.CODE10104.getValue(), null, e.getMessage());
		}

		if (bolRst) {
			try {
				JSONObject strTree = createMenuTree(list, id);
				setResultData(ResultCode.CODE00000.getValue(), strTree);
			} catch (Exception e) {
				this.log.error("资讯分类列表转换失败：" + e.getMessage());
				setResultData(ResultCode.CODE10104.getValue(), null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getInfoCatogoryWithPm() End");
		return rtnData.toString();
	}

	private JSONObject createMenuTree(List<InfoCatogory> dataList, String inputId) {
		this.log.debug("createMenuTree() Start");
		// 节点列表（散列表，用于临时存储节点对象）
		HashMap<String, JSONArray> parentList = new HashMap<String, JSONArray>();
		int rootId = 0;
		if (inputId != null && !"".equals(inputId)) {
			rootId = Integer.parseInt(inputId);
		}
		
		JSONObject rootModel = new JSONObject();
		rootModel.put("label", "资讯数据");
		rootModel.put("data",(new JSONObject().put("id", rootId)));

		// 根据结果集构造节点列表（存入散列表）
		JSONObject infoCtgPageModel;
		JSONArray parentModelList;
		for (InfoCatogory icsm : dataList) {
			infoCtgPageModel = new JSONObject();
			infoCtgPageModel.put("label", icsm.getCatogoryName());
			infoCtgPageModel.put("data",(new JSONObject().put("id", Integer.parseInt(icsm.getId()))));

			parentModelList = (JSONArray) parentList.get(String.valueOf(icsm.getParentId()));
			if (parentModelList == null) {
				parentModelList = new JSONArray();
			}
			parentModelList.put(infoCtgPageModel);
			parentList.put(String.valueOf(icsm.getParentId()), parentModelList);
		}

		JSONObject root = setModel(rootModel, parentList);
		this.log.debug("createMenuTree() End");
		return root;
	}

	private JSONObject setModel(JSONObject model, HashMap<String, JSONArray> parentList) {
		JSONObject data = (JSONObject) model.get("data");
		int id = data.getInt("id");
		JSONArray child = parentList.get(Integer.toString(id));

		if (child != null) {
			model.put("children", child);

			JSONObject node;
			for (int i = 0; i < child.length(); i++) {
				node = (JSONObject) child.get(i);
				setModel(node, parentList);
			}
		}
		return model;
	}

	/**
	 * 
	 */
	public String getInfoCatogoryById(String params) {

		this.log.info(this.getClass().getName() + " getInfoCatogoryById() Start");
		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		IInfoCtgManager mgr = (IInfoCtgManager) InformSysData.getBean(Constants.BEAN_INFOCTG_MGR);

		boolean bolRst = false;
		InfoCatogory infoCatogory = null;
		InfoCtgServiceModel icSM = new InfoCtgServiceModel();

		try {
			infoCatogory = mgr.getInfoCatogoryById(JOParams.getString("id"));
			if (null != infoCatogory) {
				bolRst = true;
			} else {
				this.log.error("取得资讯分类失败");
				setResultData(ResultCode.CODE10101.getValue(), null, "取得资讯分类失败");
			}
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error("取得资讯分类失败：" + e.getMessage());
			setResultData(ResultCode.CODE10104.getValue(), null, e.getMessage());
		}
		if (bolRst) {
			JSONObject retData;
			try {
				CopyProperties.copyProperties(infoCatogory, icSM);
				retData = JsonUtil.coverModelToJSONObject(icSM);
				setResultData(ResultCode.CODE00000.getValue(), retData);
			} catch (Exception e) {
				this.log.error("取得资讯分类的转换失败：" + e.getMessage());
				setResultData(ResultCode.CODE10104.getValue(), null, e.getMessage());
			}
		}

		this.log.info(this.getClass().getName() + " getInfoCatogoryById() End");
		return rtnData.toString();
	}

	/**
	 * 
	 */
	public String insertInfoCatogory(String params) {
		this.log.info(this.getClass().getName() + " insertInfoCatogory() Start");

		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		InfoCatogory infoCatogory = null;
		infoCatogory = (InfoCatogory) JsonUtil.jsonToBean(JOParams, InfoCatogory.class);
		IInfoCtgManager mgr = (IInfoCtgManager) InformSysData.getBean(Constants.BEAN_INFOCTG_MGR);

		try {
			// 用户信息
			infoCatogory.setREC_CREATEBY(this.getUserId());
			infoCatogory.setREC_MODIFYBY(this.getUserId());
			int id = mgr.addInfoCatogory(infoCatogory);
			this.log.businesslog("新增资讯分类成功", Constants.OPE_MODE_INFORM, Constants.OPE_SUCCESS);
			setResultData(ResultCode.CODE00000.getValue(), String.valueOf(id));
		} catch (Exception e) {
			this.log.error("新增资讯分类出错" + e.getMessage());
			setResultData(ResultCode.CODE10106.getValue(), null, e.getMessage());
			this.log.businesslog("新增资讯分类出错", Constants.OPE_MODE_INFORM, Constants.OPE_FAIL);
		}

		this.log.info(this.getClass().getName() + " insertInfoCatogory() End");
		return rtnData.toString();
	}

	/**
	 *
	 */
	public String updateInfoCatogory(String params) {
		this.log.info(this.getClass().getName() + " updateInfoCatogory() Start");

		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		InfoCatogory infoCatogory = null;
		infoCatogory = (InfoCatogory) JsonUtil.jsonToBean(JOParams, InfoCatogory.class);
		IInfoCtgManager mgr = (IInfoCtgManager) InformSysData.getBean(Constants.BEAN_INFOCTG_MGR);

		try {
			// 用户信息
			infoCatogory.setREC_MODIFYBY(this.getUserId());
			int chgNum = mgr.updInfoCatogory(infoCatogory);
			if (chgNum == 0) {
				this.log.error("更新资讯分类出错，无对应数据。");
				setResultData(ResultCode.CODE10106.getValue(), null, "更新资讯分类出错，无对应数据。");
				this.log.businesslog("更新资讯分类出错，无对应数据。", Constants.OPE_MODE_TRADE, Constants.OPE_FAIL);
			} else {
				this.log.businesslog("更新资讯分类成功", Constants.OPE_MODE_INFORM, Constants.OPE_SUCCESS);
				setResultData(ResultCode.CODE00000.getValue(), null);
			}
		} catch (Exception e) {
			this.log.error("更新资讯分类出错" + e.getMessage());
			setResultData(ResultCode.CODE10106.getValue(), null, e.getMessage());
			this.log.businesslog("更新资讯分类出错", Constants.OPE_MODE_INFORM, Constants.OPE_FAIL);
		}

		this.log.info(this.getClass().getName() + " updateInfoCatogory() End");
		return rtnData.toString();
	}

	/**
	 * 
	 */
	public String deleteInfoCatogory(String params) {
		this.log.info(this.getClass().getName() + " deleteInfoCatogory() Start");

		JSONObject JOParams = new JSONObject(params);
		this.log.debug(params);
		InfoCatogory infoCatogory = null;
		infoCatogory = (InfoCatogory) JsonUtil.jsonToBean(JOParams, InfoCatogory.class);
		IInfoCtgManager mgr = (IInfoCtgManager) InformSysData.getBean(Constants.BEAN_INFOCTG_MGR);

		try {
			// 用户信息
			infoCatogory.setREC_MODIFYBY(this.getUserId());
			int chgNum = mgr.delInfoCatogory(infoCatogory);
			if (chgNum == 0) {
				this.log.error("删除资讯分类出错，无对应数据。");
				setResultData(ResultCode.CODE10107.getValue(), null, "删除资讯分类出错，无对应数据。");
				this.log.businesslog("删除资讯分类出错，无对应数据。", Constants.OPE_MODE_TRADE, Constants.OPE_FAIL);
			} else {
				this.log.businesslog("删除资讯分类成功", Constants.OPE_MODE_INFORM, Constants.OPE_SUCCESS);
				setResultData(ResultCode.CODE00000.getValue(), null);
			}
		} catch (Exception e) {
			this.log.error("删除资讯分类出错" + e.getMessage());
			setResultData(ResultCode.CODE10107.getValue(), null, e.getMessage());
			this.log.businesslog("删除资讯分类出错", Constants.OPE_MODE_INFORM, Constants.OPE_FAIL);
		}

		this.log.info(this.getClass().getName() + " deleteInfoCatogory() End");
		return rtnData.toString();
	}
}