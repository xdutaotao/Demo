/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IInfoMgrManager
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.component;

import java.util.List;

import shcem.base.component.Manager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.inform.dao.InfoMgrDAO;
import shcem.inform.dao.model.InfoCatogory;
import shcem.inform.dao.model.InfoCatogorys;
import shcem.inform.dao.model.QuotationServiceModel;

/**
 * IInfoMgrManager
 * 
 * @author chiyong
 * @version 1.0
 */
public abstract interface IInfoMgrManager extends Manager {

	public abstract void setInfoMgrDAO(InfoMgrDAO paramInfoMgrDAO);

	/**
	 * @param catogoryID 
	 * 
	 */
	public abstract List<QuotationServiceModel> getInfoList(QueryConditions qc,PageInfo pageInfo, int catogoryID);
	
	/**
	 * 
	 */
	public String insertInfo(QuotationServiceModel quotationServiceModel);

	/**
	 * 
	 */
	public String updateInfo(QuotationServiceModel quotationServiceModel);

	/**
	 * 
	 */
	public String deleteInfo(int[] quotationIds);

	public abstract QuotationServiceModel getInfoDetail(int quotationId);
	/**
	 * 广告列表
	 * @param pageInfo
	 * @param catogoryID
	 * @return
	 */
	public abstract List<QuotationServiceModel> getAdvertList(
			PageInfo pageInfo, int catogoryID);

	/**广告分类
	 * @param catogoryID
	 * @return
	 */
	public abstract List<InfoCatogorys> getAdverClass(int catogoryID);

	public abstract void insertAdvert(QuotationServiceModel quotationServiceModel);

	public abstract void updateAdvert(QuotationServiceModel quotationServiceModel);

	public abstract QuotationServiceModel getAdvertDetailByID(int quotationID);

	/**
	 * 老专场资讯数据     剔除咨询管理（1767）和  广告模块（1849）下的资讯信息
	 * @param catogoryID
	 * @param qc
	 * @param pageInfo
	 * @return
	 */
	public abstract List<QuotationServiceModel> getOldInfoList(
			int[] catogoryID, QueryConditions qc, PageInfo pageInfo);

	public abstract List<InfoCatogory> getOldInfoCatogory(int[] catogoryID);
	
	/**
	 * 首页专题
	 */
	public abstract List<QuotationServiceModel> getHomeTopicInfoList(QueryConditions qc, PageInfo pageInfo);
}
