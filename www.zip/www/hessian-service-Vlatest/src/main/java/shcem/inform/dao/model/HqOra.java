/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: HqOra.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.dao.model;

import java.math.BigDecimal;
import java.util.Date;

import shcem.base.dao.model.BaseObject;

/**
 * @author wlpod
 *
 */
public class HqOra extends BaseObject implements java.io.Serializable,Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8606051211319684131L;
	private Date tradeTime; 
	private String commodityID;
	private String commodityName;
	private BigDecimal price;
	private BigDecimal quantity;
	private BigDecimal contractfactor;
	private BigDecimal totalQuantity;
	/**
	 * 生产企业
	 */
	private String manufacturers;
	/**
	 * 交货地
	 */
	private String propertiesorigin;
	/**
	 * 专场名称
	 */
	private String breedName;
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @return the tradeTime
	 */
	public Date getTradeTime() {
		return tradeTime;
	}

	/**
	 * @param tradeTime the tradeTime to set
	 */
	public void setTradeTime(Date tradeTime) {
		this.tradeTime = tradeTime;
	}

	/**
	 * @return the commodityID
	 */
	public String getCommodityID() {
		return commodityID;
	}

	/**
	 * @param commodityID the commodityID to set
	 */
	public void setCommodityID(String commodityID) {
		this.commodityID = commodityID;
	}

	/**
	 * @return the commodityName
	 */
	public String getCommodityName() {
		return commodityName;
	}

	/**
	 * @param commodityName the commodityName to set
	 */
	public void setCommodityName(String commodityName) {
		this.commodityName = commodityName;
	}

	/**
	 * @return the price
	 */
	public BigDecimal getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	/**
	 * @return the quantity
	 */
	public BigDecimal getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the contractfactor
	 */
	public BigDecimal getContractfactor() {
		return contractfactor;
	}

	/**
	 * @param contractfactor the contractfactor to set
	 */
	public void setContractfactor(BigDecimal contractfactor) {
		this.contractfactor = contractfactor;
	}
	
	/**
	 * @return the manufacturers
	 */
	public String getManufacturers() {
		return manufacturers;
	}

	/**
	 * @param manufacturers the manufacturers to set
	 */
	public void setManufacturers(String manufacturers) {
		this.manufacturers = manufacturers;
	}

	/**
	 * @return the propertiesorigin
	 */
	public String getPropertiesorigin() {
		return propertiesorigin;
	}

	/**
	 * @param propertiesorigin the propertiesorigin to set
	 */
	public void setPropertiesorigin(String propertiesorigin) {
		this.propertiesorigin = propertiesorigin;
	}

	/**
	 * @return the breedName
	 */
	public String getBreedName() {
		return breedName;
	}

	/**
	 * @param breedName the breedName to set
	 */
	public void setBreedName(String breedName) {
		this.breedName = breedName;
	}

	/**
	 * @return the totalQuantity
	 */
	public BigDecimal getTotalQuantity() {
		return totalQuantity;
	}

	/**
	 * @param totalQuantity the totalQuantity to set
	 */
	public void setTotalQuantity(BigDecimal totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

}
