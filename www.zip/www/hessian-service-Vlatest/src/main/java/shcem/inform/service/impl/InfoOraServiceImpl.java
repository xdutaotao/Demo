/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: InfoOraServiceImpl.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.inform.component.IInfoOraManager;
import shcem.inform.dao.model.HqOra;
import shcem.inform.service.IInfoOraService;
import shcem.inform.service.model.HqOraServiceModel;
import shcem.inform.util.InformOraSysData;
import shcem.util.JsonUtil;

/**
 * @author wlpod
 *
 */
public class InfoOraServiceImpl extends BaseServiceImpl implements IInfoOraService {

	private IInfoOraManager mgr = (IInfoOraManager) InformOraSysData.getBean(Constants.BEAN_INFOORAMGR_MGR);

	@Override
	public String getHqList(String params) {
		this.log.info(this.getClass().getName() + " getHqList() Start");
		this.log.debug("JOParams=" + params);
		JSONObject JOParams = new JSONObject(params);
		List<HqOra> list = null;
		List<HqOraServiceModel> desList = null;
		boolean bolRst = false;
		List<Condition> conditionList = new ArrayList<Condition>(); 		
		//JSONObject queryModel = JOParams.optJSONObject("queryModel");
		//QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionList, "");
				
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JOParams);
		pageInfo.setPageNo(1);
		try {
			list = mgr.getHqList(null, pageInfo);			
			bolRst = true;
		} catch (Exception err) {
			this.log.error("取得行情失败：" + err.getMessage());
			setResultData("10104", null, err.getMessage());
		}

		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);

				jsonObj.put("total", list.size());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("数据转换失败：" + e.getMessage());
				setResultData("10104", null, e.getMessage());
			}

		}

		this.log.info(this.getClass().getName() + " getHqList() End");
		return rtnData.toString();
	}

}
