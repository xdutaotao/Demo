/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: InfoCtgDAOImpl
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 06/06/16 　	刘洪波   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.dao.impl;

import java.util.List;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.inform.dao.InfoCtgDAO;
import shcem.inform.dao.model.InfoCatogory;
import shcem.util.CommonRowMapper;

/**
 * InfoCtgDAOImpl
 * 
 * @author liuhongbo
 * @version 1.0
 */
public class InfoCtgDAOImpl extends BaseDAOImpl implements InfoCtgDAO {

	/**
	 * 
	 */
	public List<InfoCatogory> getAllInfoCatogoryList() {
		this.log.debug("getAllInfoCatogoryList DAO Start");
		String sql = sqlProperty.getProperty("CtgDAO_001");
		Object[] params = new Object[] {};
		return queryBySQL(sql, params, null, new CommonRowMapper(new InfoCatogory()));
	}
	
	/**
	 * 
	 */
	public InfoCatogory getInfoCatogoryById(String strId) {
		this.log.debug("getInfoCatogoryById DAO Start");
		String sql = sqlProperty.getProperty("CtgDAO_002");
		this.log.debug("CtgDAO_002_Sql: " + sql);
		Object[] params = new Object[] {Integer.parseInt(strId)};
		this.log.debug("params: " + strId);
		return (InfoCatogory) queryForObject(sql, params, new CommonRowMapper(new InfoCatogory()));
	}

	/**
	 * 
	 */
	public int addInfoCatogory(InfoCatogory iCtg) {
		this.log.debug("addInfoCatogory DAO Start");
		String sql = sqlProperty.getProperty("CtgDAO_003");
		Object[] params = { iCtg.getParentId(), iCtg.getCatogoryName(),
				1,														//状态:有效
				iCtg.getREC_CREATEBY(),
				iCtg.getREC_MODIFYBY() };

		this.log.debug("CtgDAO_003_Sql: " + sql);
		for (int i = 0; i < params.length; i++) {
			this.log.debug("params[" + i + "]: " + params[i]);
		}
		try {
			return this.queryForIntID(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error(e.getMessage());
			throw new RuntimeException("资讯分类添加失败！");
		}
	}

	/**
	 * 
	 */
	public int updInfoCatogory(InfoCatogory iCtg) {
		this.log.debug("updInfoCatogory DAO Start");
		String sql = sqlProperty.getProperty("CtgDAO_004");
		Object[] params = { iCtg.getParentId(), iCtg.getCatogoryName(), iCtg.getREC_MODIFYBY(), iCtg.getId() };
		this.log.debug("CtgDAO_004_SQL: " + sql);
		for (int i = 0; i < params.length; i++) {
			this.log.debug("params[" + i + "]: " + params[i]);
		}
		try {
			return getJdbcTemplate().update(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error(e.getMessage());
			throw new RuntimeException("资讯分类更新失败！");
		}
	}

	/**
	 *
	 */
	public int delInfoCatogory(InfoCatogory iCtg) {
		this.log.debug("delInfoCatogory DAO Start");
		String sql = sqlProperty.getProperty("CtgDAO_005");
		Object[] params = { 0,								//状态:禁用
				iCtg.getREC_MODIFYBY(), iCtg.getId() };

		this.log.debug("QueDAO_005_Sql: " + sql);
		for (int i = 0; i < params.length; i++) {
			this.log.debug("params[" + i + "]: " + params[i]);
		}
		try {
			return getJdbcTemplate().update(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
			this.log.error(e.getMessage());
			throw new RuntimeException("资讯分类删除失败！");
		}
	}
}
