/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: InfoOraManager.java
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 2016年6月24日 　吴凌   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.component.impl;

import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.inform.component.IInfoOraManager;
import shcem.inform.dao.InfoOraDAO;
import shcem.inform.dao.model.HqOra;

/**
 * @author wlpod
 *
 */
public class InfoOraManagerImpl extends BaseManager  implements IInfoOraManager {
	private InfoOraDAO dao;

	public void setInfoOraDAO(InfoOraDAO dao) {
		this.dao = dao;
	}
	@Override
	public List<HqOra> getHqList(QueryConditions qc, PageInfo pageInfo) {
		return this.dao.getHqList(qc, pageInfo);
	}
}
