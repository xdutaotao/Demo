package shcem.inform.dao.model;

import java.io.Serializable;

import shcem.base.dao.model.BaseObject;

/**咨询分类
 * @author zhangnan
 *
 */
public class InfoCatogorys  extends BaseObject implements Serializable  {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int id;
	
	private int parentId;
	
	private String catogoryName;
	
	private String catogorySts;
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getParentId() {
		return parentId;
	}

	public void setParentId(int parentId) {
		this.parentId = parentId;
	}

	public String getCatogoryName() {
		return catogoryName;
	}

	public void setCatogoryName(String catogoryName) {
		this.catogoryName = catogoryName;
	}

	public String getCatogorySts() {
		return catogorySts;
	}

	public void setCatogorySts(String catogorySts) {
		this.catogorySts = catogorySts;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean equals(Object paramObject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
