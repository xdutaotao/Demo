/* ========================================
 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: InfoCtgDAO
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 06/06/16 　刘洪波   Create
 * 
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.dao;

import java.util.List;

import shcem.base.dao.DAO;
import shcem.inform.dao.model.InfoCatogory;

/**
 * InfoCtgDAO
 * 
 * @author liuhongbo
 * @version 1.0
 */
public abstract interface InfoCtgDAO extends DAO {

	/**
	 *
	 */
	public abstract List<InfoCatogory> getAllInfoCatogoryList();

	/**
	 *
	 */
	public InfoCatogory getInfoCatogoryById(String strId);
	
	/**
	 *
	 */
	public abstract int addInfoCatogory(InfoCatogory params);

	/**
	 *
	 */
	public abstract int updInfoCatogory(InfoCatogory params);

	/**
	 * 
	 */
	public abstract int delInfoCatogory(InfoCatogory params);


}
