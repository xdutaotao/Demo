/* ========================================

 * System Name　　：SHCEM 线上平台
 * SubSystem Name ：后台管理
 * File Name: IInfoQuoService
 * ----------------------------------------
 * Create Date/Change History 
 * ----------------------------------------
 * 04/29/16 　池 永     Create
 * 06/02/16 　刘洪波  Real
 * 
 * ----------------------------------------
 * Copyright (c) SCEM . All rights reserved.
 */
package shcem.inform.service;

/**
 * IInfoQuoService
 * 
 * @author chiyong
 * @version 1.0
 */
public interface IInfoQuoService {

	/**
	 *
	 */
	public String getMarketQuoList(String params);
	
	/**
	 *
	 */
	public String getMarketQuoById(String params);
	
	/**
	 *
	 */
	public String getStartEndDateMarketQuoList(String params);
	
	/**
	 *
	 */
	public String insertMarketQuo(String params);

	/**
	 * 
	 */
	public String updateMarketQuo(String params);

	/**
	 *
	 */
	public String deleteMarketQuo(String params);

	/**
	 * 
	 */
	public String getScemQuo(String params);
	
	/**
	 * 
	 */
	public String getScemQuoHistory(String params);

	/**
	 * 
	 */
	public String insertScemQuo(String params);
	
	/**
	 * 
	 */
	public String updateScemQuoBoth(String params);
	
	/**
	 * 
	 */
	public String getScemQuoById(String params);
	
	/**
	 * 
	 */
	public String getScemQuoHistoryById(String params);
}