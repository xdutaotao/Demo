package shcem.message.component;

import java.util.List;

import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.message.dao.IMessageDao;
import shcem.message.service.model.NotificationService;

public abstract interface IMessageManager {
	
	public abstract void setMessageDao(IMessageDao messageDao);
		
	List<NotificationService> getMessageList(QueryConditions qc,PageInfo pageInfo);

	public abstract void updateMessage(int messageID);

}
