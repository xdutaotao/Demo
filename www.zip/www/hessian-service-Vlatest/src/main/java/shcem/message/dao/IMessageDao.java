package shcem.message.dao;

import java.util.List;

import shcem.base.dao.DAO;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.message.service.model.NotificationService;

public abstract interface IMessageDao  extends DAO {

	List<NotificationService> getMessageList(QueryConditions qc,
			PageInfo pageInfo);

	void updateMessage(int messageID);

}
