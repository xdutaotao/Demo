package shcem.message.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import shcem.base.query.Condition;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.base.query.QueryHelper;
import shcem.base.service.impl.BaseServiceImpl;
import shcem.constant.Constants;
import shcem.message.component.IMessageManager;
import shcem.message.service.IMessageService;
import shcem.message.service.model.NotificationService;
import shcem.message.util.MessageSysData;
import shcem.util.JsonUtil;

public class MessageServiceImpl extends BaseServiceImpl implements IMessageService {
	
	private IMessageManager messageMgr =  (IMessageManager) MessageSysData.getBean(Constants.BEAN_MESSAGE_MGR);

	@Override
	public String getMessageList(String params) {
		this.log.info(this.getClass().getName() + " getMessageList() Start");
		this.log.debug("JSONParams=" + params);
		List<NotificationService> list = null;
		boolean bolRst = false;
		//表头查询条件
		JSONObject JSONParams = new JSONObject(params);
		List<Condition> conditionsList = new ArrayList<Condition>();
		
		conditionsList.add(new Condition("t1.Message", "like", "", "string","message"));
		conditionsList.add(new Condition("t1.MsgStatus", "=", "", "string","msgStatus"));
		conditionsList.add(new Condition("t2.UserId", "=", "", "String","userId"));
		conditionsList.add(new Condition("convert(char(10),t1.rEC_CREATETIME,120)", ">=", "", "string","startDate"));
		conditionsList.add(new Condition("convert(char(10),t1.rEC_CREATETIME,120)", "<=", "", "string","endDate"));
		
		JSONObject queryModel =JSONParams.optJSONObject("queryModel");
		QueryConditions qc = QueryHelper.getQueryConditionsFromJson(queryModel, conditionsList, "");
		
		this.log.debug("qc=" + qc.toString());
		PageInfo pageInfo = QueryHelper.getPageInfoFromJsonReq(JSONParams);
		try {
			list = this.messageMgr.getMessageList(qc,pageInfo);
			bolRst = true;
		} catch (Exception e) {
			this.log.error("消息列表查询失败"+e.getMessage());
			setResultData("10105",null);
		}
		if (bolRst) {
			JSONArray retData;
			JSONObject jsonObj = new JSONObject();
			try {
				retData = JsonUtil.coverModelToJSONArray(list);
				jsonObj.put("total", pageInfo.getTotalRecords());
				jsonObj.put("result", retData);
				setResultData("00000", jsonObj);
			} catch (Exception e) {
				this.log.error("消息列表数据转换失败：" + e.getMessage());
				setResultData("10105", null, e.getMessage());
			}
		}
		this.log.info(this.getClass().getName() + " getMessageList() End");
		return rtnData.toString();
	}

	@Override
	public String updateMessage(String params) {
		this.log.info(this.getClass().getName() + " updateMessage() Start");
		this.log.debug("JSONParams=" + params);
		JSONObject JSONParams = new JSONObject(params);
		int messageID = JSONParams.getInt("messageID");
		try {
			this.messageMgr.updateMessage(messageID);
			setResultData("00000",null);
		} catch (Exception e) {
			this.log.error("消息设置为已读失败"+e.getMessage());
			setResultData("10106",null);
		}
		this.log.info(this.getClass().getName() + " updateMessage() End");
		return rtnData.toString();
	}
}
