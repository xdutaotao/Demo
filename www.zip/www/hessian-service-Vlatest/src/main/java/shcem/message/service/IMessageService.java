package shcem.message.service;

/**
 * 消息服务
 * @author zhangnan
 *
 */
public interface IMessageService {
	/**
	 * 消息列表
	 * @param params
	 * @return
	 */
	public String getMessageList(String params);
	/**
	 * 消息已读
	 * @param params
	 * @return
	 */
	public String updateMessage(String params);

}
