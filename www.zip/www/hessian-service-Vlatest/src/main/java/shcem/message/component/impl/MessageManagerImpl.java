package shcem.message.component.impl;

import java.util.List;

import shcem.base.component.impl.BaseManager;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.message.component.IMessageManager;
import shcem.message.dao.IMessageDao;
import shcem.message.service.model.NotificationService;

public class MessageManagerImpl extends BaseManager implements IMessageManager {

	private IMessageDao  messageDao;
	private IMessageDao  messageDao_read;
	public void setMessageDao(IMessageDao messageDao) {
		this.messageDao = messageDao;
	}

	public void setMessageDao_read(IMessageDao messageDao_read) {
		this.messageDao_read = messageDao_read;
	}

	@Override
	public List<NotificationService> getMessageList(QueryConditions qc,
			PageInfo pageInfo) {
		this.log.info(MessageManagerImpl.class+"  Component  getMessageList Start");
		return this.messageDao_read.getMessageList(qc,pageInfo);
	}
	
	@Override
	public void updateMessage(int messageID) {
		this.messageDao.updateMessage(messageID);
	}
}
