package shcem.message.dao.impl;

import java.util.Date;
import java.util.List;

import shcem.base.dao.impl.BaseDAOImpl;
import shcem.base.query.PageInfo;
import shcem.base.query.QueryConditions;
import shcem.message.dao.IMessageDao;
import shcem.message.service.model.NotificationService;
import shcem.util.CommonRowMapper;

public class MessageDaoImpl extends BaseDAOImpl implements IMessageDao {

	@Override
	public List<NotificationService> getMessageList(QueryConditions qc,
			PageInfo pageInfo) {
		String sql = this.sqlProperty.getProperty("MessageDao_001");
		List<NotificationService> list = null;
		list = this.queryBySQL(sql, qc, pageInfo, new CommonRowMapper(new NotificationService()));
		return list;
	}

	@Override
	public void updateMessage(int messageID) {
		String sql = this.sqlProperty.getProperty("MessageDao_002");
		Object[] params = {
				new Date(),//消息读阅时间
				new Date(),//最后更新时间
				"",//最后修改人
				messageID
		};
		this.updateBySQL(sql, params);
	}
}
