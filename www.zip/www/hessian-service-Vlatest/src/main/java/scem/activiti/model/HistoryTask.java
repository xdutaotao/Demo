package scem.activiti.model;

import org.json.JSONObject;

public class HistoryTask extends HistoryTaskURL {
	private String taskId = "";
	private String variableName = "";
	private HistoryTaskParams params = new HistoryTaskParams();

	public JSONObject getJsonObject() {
		JSONObject jsonObject = new JSONObject();
		JSONObject jsonParams = params.getJsonParams();
		JSONObject jsonURL = getJsonURL();
		if (!"".equals(taskId))
			jsonObject.put("taskId", taskId);
		if (!"".equals(variableName))
			jsonObject.put("variableName", variableName);

		jsonObject.put("url", jsonURL);
		jsonObject.put("params", jsonParams);
		return jsonObject;

	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getVariableName() {
		return variableName;
	}

	public void setVariableName(String variableName) {
		this.variableName = variableName;
	}

	public HistoryTaskParams getParams() {
		return params;
	}

	public void setParams(HistoryTaskParams params) {
		this.params = params;
	}

}
