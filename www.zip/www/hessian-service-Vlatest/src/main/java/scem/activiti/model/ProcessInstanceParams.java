package scem.activiti.model;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class ProcessInstanceParams {
	private String processDefinitionKey = "";
	private String businessKey = "";
	private List<VariableParams> variables = new ArrayList<VariableParams>();

	public JSONObject getJsonParams() {
		JSONObject jObj = new JSONObject();
		JSONArray jArray = new JSONArray();

		for (VariableParams vars : variables) {
			jArray.put(vars.getJsonObject());
		}
		if(jArray.length()>0){
			jObj.put("variables", jArray);
		}

		jObj.put("processDefinitionKey", processDefinitionKey);
		jObj.put("businessKey", businessKey);
	

		return jObj;

	}

	public String getProcessDefinitionKey() {
		return processDefinitionKey;
	}

	public void setProcessDefinitionKey(String processDefinitionKey) {
		this.processDefinitionKey = processDefinitionKey;
	}

	public String getBusinessKey() {
		return businessKey;
	}

	public void setBusinessKey(String businessKey) {
		this.businessKey = businessKey;
	}

	public List<VariableParams> getVariables() {
		return variables;
	}

	public void setVariables(List<VariableParams> variables) {
		this.variables = variables;
	}

}
