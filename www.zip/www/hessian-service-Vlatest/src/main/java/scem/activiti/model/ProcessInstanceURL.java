package scem.activiti.model;

import org.json.JSONObject;

public class ProcessInstanceURL extends Page {
	private String id = "";
	private String processDefinitionKey = "";
	private String processDefinitionId = "";
	private String businessKey = "";
	private String involvedUser = "";
	private String suspended = "";
	private String superProcessInstanceId = "";
	private String subProcessInstanceId = "";
	private String excludeSubprocesses = "";
	private String includeProcessVariables = "";
	private String tenantId = "";
	private String tenantIdLike = "";
	private String withoutTenantId = "";

	public JSONObject getJsonURL() {

		JSONObject getJsonURL = getJsonPage();

		if (!"".equals(id))
			getJsonURL.put("id", id);
		if (!"".equals(processDefinitionKey))
			getJsonURL.put("processDefinitionKey", processDefinitionKey);
		if (!"".equals(processDefinitionId))
			getJsonURL.put("processDefinitionId", processDefinitionId);
		if (!"".equals(businessKey))
			getJsonURL.put("businessKey", businessKey);
		if (!"".equals(involvedUser))
			getJsonURL.put("involvedUser", involvedUser);
		if (!"".equals(suspended))
			getJsonURL.put("suspended", suspended);
		if (!"".equals(superProcessInstanceId))
			getJsonURL.put("superProcessInstanceId", superProcessInstanceId);
		if (!"".equals(subProcessInstanceId))
			getJsonURL.put("subProcessInstanceId", subProcessInstanceId);
		if (!"".equals(excludeSubprocesses))
			getJsonURL.put("excludeSubprocesses", excludeSubprocesses);
		if (!"".equals(includeProcessVariables))
			getJsonURL.put("includeProcessVariables", includeProcessVariables);
		if (!"".equals(tenantId))
			getJsonURL.put("tenantId", tenantId);
		if (!"".equals(tenantIdLike))
			getJsonURL.put("tenantIdLike", tenantIdLike);
		if (!"".equals(withoutTenantId))
			getJsonURL.put("withoutTenantId", withoutTenantId);

		return getJsonURL;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProcessDefinitionKey() {
		return processDefinitionKey;
	}

	public void setProcessDefinitionKey(String processDefinitionKey) {
		this.processDefinitionKey = processDefinitionKey;
	}

	public String getProcessDefinitionId() {
		return processDefinitionId;
	}

	public void setProcessDefinitionId(String processDefinitionId) {
		this.processDefinitionId = processDefinitionId;
	}

	public String getBusinessKey() {
		return businessKey;
	}

	public void setBusinessKey(String businessKey) {
		this.businessKey = businessKey;
	}

	public String getInvolvedUser() {
		return involvedUser;
	}

	public void setInvolvedUser(String involvedUser) {
		this.involvedUser = involvedUser;
	}

	public String getSuspended() {
		return suspended;
	}

	public void setSuspended(String suspended) {
		this.suspended = suspended;
	}

	public String getSuperProcessInstanceId() {
		return superProcessInstanceId;
	}

	public void setSuperProcessInstanceId(String superProcessInstanceId) {
		this.superProcessInstanceId = superProcessInstanceId;
	}

	public String getSubProcessInstanceId() {
		return subProcessInstanceId;
	}

	public void setSubProcessInstanceId(String subProcessInstanceId) {
		this.subProcessInstanceId = subProcessInstanceId;
	}

	public String getExcludeSubprocesses() {
		return excludeSubprocesses;
	}

	public void setExcludeSubprocesses(String excludeSubprocesses) {
		this.excludeSubprocesses = excludeSubprocesses;
	}

	public String getIncludeProcessVariables() {
		return includeProcessVariables;
	}

	public void setIncludeProcessVariables(String includeProcessVariables) {
		this.includeProcessVariables = includeProcessVariables;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getTenantIdLike() {
		return tenantIdLike;
	}

	public void setTenantIdLike(String tenantIdLike) {
		this.tenantIdLike = tenantIdLike;
	}

	public String getWithoutTenantId() {
		return withoutTenantId;
	}

	public void setWithoutTenantId(String withoutTenantId) {
		this.withoutTenantId = withoutTenantId;
	}

}
