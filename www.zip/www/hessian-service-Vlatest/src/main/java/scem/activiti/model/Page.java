package scem.activiti.model;

import org.json.JSONObject;

public class Page {
	private String sort = "";
	private String order = "";
	private String start = "";
	private String size = "";

	public JSONObject getJsonPage() {

		JSONObject jsonPage = new JSONObject();
		if (!"".equals(sort))
			jsonPage.put("sort", sort);
		if (!"".equals(order))
			jsonPage.put("order", order);
		if (!"".equals(start))
			jsonPage.put("start", start);
		if (!"".equals(size))
			jsonPage.put("size", size);

		return jsonPage;
	}

	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

}
