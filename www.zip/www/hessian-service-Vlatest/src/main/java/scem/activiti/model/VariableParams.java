package scem.activiti.model;

import org.json.JSONObject;

/**
 * 流程变量
 * 
 * @author sunf
 *
 */
public class VariableParams {
	private String name = "";
	private Object value = "";
	 

	public JSONObject getJsonObject() {
		JSONObject jObj = new JSONObject();

		jObj.put("name", name);
		jObj.put("value", value);

		return jObj;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

}
