package scem.activiti.model;

import org.json.JSONObject;

public class User extends UserURL {

	private String userId = "";
	private String key = "";
	private UserParams params = new UserParams();

	public JSONObject getJsonObject() {

		JSONObject jsonObj = new JSONObject();
		JSONObject jsonParm = params.getJsonParams();
		JSONObject jsonURL = getJsonURL();
		jsonObj.put("userId", userId);
		jsonObj.put("key", key);
		
		jsonObj.put("params", jsonParm);
		jsonObj.put("url", jsonURL);

		return jsonObj;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public UserParams getParams() {
		return params;
	}

	public void setParams(UserParams params) {
		this.params = params;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

}
