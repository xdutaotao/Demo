package scem.drools;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 交收费用算法，调用规则引擎，传入参数
 * @author zhangnan
 *
 */
public class DeliveryInParams  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/*申请交收量*/
	private int deliveryQuantity;
	
	/*订单量*/
	private int orderQuantity = 1;
	
	/*交收处理完成的量(包含履约/违约)*/
	private int completeDeliveryQuantity;
	
	/*成交状态*/
	private int orderTradeStatus;
	
	/*付卖家货款状态   0：待付款  5：待审核 10：已付款 15: 已拒绝*/
	private int orderPaymentStatus;
	
	/*卖方交易已收保证金*/
	private BigDecimal sellTakenTradeDeposit;
	
	/*卖方交易应收保证金*/
	private BigDecimal sellTradeDeposit;
	
	/*卖方交易保证金授信*/
	private BigDecimal  sellCreditDeposit;
	
	/*买方交易已收手续费*/
	private BigDecimal  buyTakenTradeFee;
	
	/*买方交易已收保证金*/
	private BigDecimal buyTakenTradeDeposit;
	
	/*卖方交易应收手续费*/
	private BigDecimal sellTradeFee;
	
	/*买方交易应收手续费*/
	private BigDecimal buyTradeFee;
	
	/*买方交易应收保证金*/
	private BigDecimal buyTradeDeposit;
	
	/*卖方交易已收手续费*/
	private BigDecimal sellTakenTradeFee;
	
	/*卖方交易手续费授信*/
	private BigDecimal sellCreditFee;
	
	/*买方手续费授信金额*/
	private BigDecimal buyCreditFee;
	
	/*买方保证金授信金额*/
	private BigDecimal buyCreditDeposit;
	
	/*成交金额*/
	private BigDecimal amount;
	
	/*已付卖方金额*/
	private BigDecimal paidSellAmount;

	public int getDeliveryQuantity() {
		return deliveryQuantity;
	}

	public void setDeliveryQuantity(int deliveryQuantity) {
		this.deliveryQuantity = deliveryQuantity;
	}

	public int getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public int getCompleteDeliveryQuantity() {
		return completeDeliveryQuantity;
	}

	public void setCompleteDeliveryQuantity(int completeDeliveryQuantity) {
		this.completeDeliveryQuantity = completeDeliveryQuantity;
	}

	public int getOrderTradeStatus() {
		return orderTradeStatus;
	}

	public void setOrderTradeStatus(int orderTradeStatus) {
		this.orderTradeStatus = orderTradeStatus;
	}

	public int getOrderPaymentStatus() {
		return orderPaymentStatus;
	}

	public void setOrderPaymentStatus(int orderPaymentStatus) {
		this.orderPaymentStatus = orderPaymentStatus;
	}

	public BigDecimal getSellTakenTradeDeposit() {
		return sellTakenTradeDeposit;
	}

	public void setSellTakenTradeDeposit(BigDecimal sellTakenTradeDeposit) {
		this.sellTakenTradeDeposit = sellTakenTradeDeposit;
	}

	public BigDecimal getSellTradeDeposit() {
		return sellTradeDeposit;
	}

	public void setSellTradeDeposit(BigDecimal sellTradeDeposit) {
		this.sellTradeDeposit = sellTradeDeposit;
	}

	public BigDecimal getSellCreditDeposit() {
		return sellCreditDeposit;
	}

	public void setSellCreditDeposit(BigDecimal sellCreditDeposit) {
		this.sellCreditDeposit = sellCreditDeposit;
	}

	public BigDecimal getBuyTakenTradeFee() {
		return buyTakenTradeFee;
	}

	public void setBuyTakenTradeFee(BigDecimal buyTakenTradeFee) {
		this.buyTakenTradeFee = buyTakenTradeFee;
	}

	public BigDecimal getBuyTakenTradeDeposit() {
		return buyTakenTradeDeposit;
	}

	public void setBuyTakenTradeDeposit(BigDecimal buyTakenTradeDeposit) {
		this.buyTakenTradeDeposit = buyTakenTradeDeposit;
	}

	public BigDecimal getSellTradeFee() {
		return sellTradeFee;
	}

	public void setSellTradeFee(BigDecimal sellTradeFee) {
		this.sellTradeFee = sellTradeFee;
	}

	public BigDecimal getBuyTradeFee() {
		return buyTradeFee;
	}

	public void setBuyTradeFee(BigDecimal buyTradeFee) {
		this.buyTradeFee = buyTradeFee;
	}

	public BigDecimal getBuyTradeDeposit() {
		return buyTradeDeposit;
	}

	public void setBuyTradeDeposit(BigDecimal buyTradeDeposit) {
		this.buyTradeDeposit = buyTradeDeposit;
	}

	public BigDecimal getSellTakenTradeFee() {
		return sellTakenTradeFee;
	}

	public void setSellTakenTradeFee(BigDecimal sellTakenTradeFee) {
		this.sellTakenTradeFee = sellTakenTradeFee;
	}

	public BigDecimal getSellCreditFee() {
		return sellCreditFee;
	}

	public void setSellCreditFee(BigDecimal sellCreditFee) {
		this.sellCreditFee = sellCreditFee;
	}

	public BigDecimal getBuyCreditFee() {
		return buyCreditFee;
	}

	public void setBuyCreditFee(BigDecimal buyCreditFee) {
		this.buyCreditFee = buyCreditFee;
	}

	public BigDecimal getBuyCreditDeposit() {
		return buyCreditDeposit;
	}

	public void setBuyCreditDeposit(BigDecimal buyCreditDeposit) {
		this.buyCreditDeposit = buyCreditDeposit;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getPaidSellAmount() {
		return paidSellAmount;
	}

	public void setPaidSellAmount(BigDecimal paidSellAmount) {
		this.paidSellAmount = paidSellAmount;
	}
	

}
