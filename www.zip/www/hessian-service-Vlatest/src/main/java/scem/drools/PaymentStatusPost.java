package scem.drools;

import java.math.BigDecimal;

import org.json.JSONObject;

public class PaymentStatusPost {

	public JSONObject postPaymentStatusDrools(PaymentStatus bean, String mode) {
		DroolUtil util = new DroolUtil();
		
		String postData;
		
		postData = util.generateDroolsApiData("CheckPaymentStatus", "PaymentStatus", bean);
		
		JSONObject jsoRtn;
		
		jsoRtn = util.postDroolsApi(postData, mode);
		
		return jsoRtn;
	}
	
	public static void main(String[] args) {
		PaymentStatus paymentStatus = new PaymentStatus();
		paymentStatus.setTradeStatus(5);
		paymentStatus.setPaymentType(1);
		paymentStatus.setPaymentStatus(0);
		paymentStatus.setPaidSellAmount(new BigDecimal(0));
		paymentStatus.setViolationWeight(new BigDecimal(19.00));
		paymentStatus.setTotalQuantity(new BigDecimal(20.00));
		
		paymentStatus.setSettlementMethod(21);
		paymentStatus.setTradeType(1);
		paymentStatus.setIsGoodsController(1);
		PaymentStatusPost post = new PaymentStatusPost();
		JSONObject rtn = post.postPaymentStatusDrools(paymentStatus, "local");
		System.out.println(rtn.toString());
		System.out.println("backendCode"+rtn.get("backendCode"));
	}

}
