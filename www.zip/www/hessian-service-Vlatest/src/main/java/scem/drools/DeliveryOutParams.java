package scem.drools;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 交收费用算法，调用规则引擎，传入参数
 * @author zhangnan
 *
 */
public class DeliveryOutParams implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	/*卖方交收已收保证金	*/
	private BigDecimal sellTakenSSDeposit;
	
	/*卖方交收应收保证金*/
	private BigDecimal sellSettleDeposit;
	
	/*卖方交收保证金授信金额*/
	private BigDecimal sellCreditDeposit;
	
	/*买方交收已扣手续费*/
	private BigDecimal takenBSFee;
	
	/*买方交收已扣保证金*/
	private BigDecimal takenBSDeposit;
	
	/*卖方交收应收手续费*/
	private BigDecimal sellSettleFee;
	
	/*买方交收应付手续费	*/
	private BigDecimal buySettleFee;
	
	/*买方交收应付保证金*/
	private BigDecimal buySettleDeposit;
	
	/*卖方交收已扣手续费*/
	private BigDecimal takenSSFee;
	
	/*卖方交收手续费授信金额*/
	private BigDecimal sellCreditFee;
	
	/*买方手续费授信金额*/
	private BigDecimal buyCreditFee;
	
	/*买方保证金授信金额*/
	private BigDecimal buyCreditDeposit;
	
	/*应收货款*/
	private BigDecimal takenMoney;
	
	/*已付卖家货款 */
	private BigDecimal payedMoney;
	
	/* 应收货款 */
	private BigDecimal money;

	public BigDecimal getMoney() {
		return money;
	}

	public void setMoney(BigDecimal money) {
		this.money = money;
	}

	public BigDecimal getSellTakenSSDeposit() {
		return sellTakenSSDeposit;
	}

	public void setSellTakenSSDeposit(BigDecimal sellTakenSSDeposit) {
		this.sellTakenSSDeposit = sellTakenSSDeposit;
	}

	public BigDecimal getSellSettleDeposit() {
		return sellSettleDeposit;
	}

	public void setSellSettleDeposit(BigDecimal sellSettleDeposit) {
		this.sellSettleDeposit = sellSettleDeposit;
	}

	public BigDecimal getSellCreditDeposit() {
		return sellCreditDeposit;
	}

	public void setSellCreditDeposit(BigDecimal sellCreditDeposit) {
		this.sellCreditDeposit = sellCreditDeposit;
	}

	public BigDecimal getTakenBSFee() {
		return takenBSFee;
	}

	public void setTakenBSFee(BigDecimal takenBSFee) {
		this.takenBSFee = takenBSFee;
	}

	public BigDecimal getTakenBSDeposit() {
		return takenBSDeposit;
	}

	public void setTakenBSDeposit(BigDecimal takenBSDeposit) {
		this.takenBSDeposit = takenBSDeposit;
	}

	public BigDecimal getSellSettleFee() {
		return sellSettleFee;
	}

	public void setSellSettleFee(BigDecimal sellSettleFee) {
		this.sellSettleFee = sellSettleFee;
	}

	public BigDecimal getBuySettleFee() {
		return buySettleFee;
	}

	public void setBuySettleFee(BigDecimal buySettleFee) {
		this.buySettleFee = buySettleFee;
	}

	public BigDecimal getBuySettleDeposit() {
		return buySettleDeposit;
	}

	public void setBuySettleDeposit(BigDecimal buySettleDeposit) {
		this.buySettleDeposit = buySettleDeposit;
	}

	public BigDecimal getTakenSSFee() {
		return takenSSFee;
	}

	public void setTakenSSFee(BigDecimal takenSSFee) {
		this.takenSSFee = takenSSFee;
	}

	public BigDecimal getSellCreditFee() {
		return sellCreditFee;
	}

	public void setSellCreditFee(BigDecimal sellCreditFee) {
		this.sellCreditFee = sellCreditFee;
	}

	public BigDecimal getBuyCreditFee() {
		return buyCreditFee;
	}

	public void setBuyCreditFee(BigDecimal buyCreditFee) {
		this.buyCreditFee = buyCreditFee;
	}

	public BigDecimal getBuyCreditDeposit() {
		return buyCreditDeposit;
	}

	public void setBuyCreditDeposit(BigDecimal buyCreditDeposit) {
		this.buyCreditDeposit = buyCreditDeposit;
	}

	public BigDecimal getTakenMoney() {
		return takenMoney;
	}

	public void setTakenMoney(BigDecimal takenMoney) {
		this.takenMoney = takenMoney;
	}

	public BigDecimal getPayedMoney() {
		return payedMoney;
	}

	public void setPayedMoney(BigDecimal payedMoney) {
		this.payedMoney = payedMoney;
	}
	
	
	/**
	 * 返回结果转成json格式的数据
	 */
	@Override
	public String toString() {
		String deliverOutParamsJson =
				" {"
					+ "\"sellTakenSSDeposit\":\"" + sellTakenSSDeposit
					+ "\",\" sellSettleDeposit\":\"" + sellSettleDeposit
					+ "\",\" sellCreditDeposit\":\"" + sellCreditDeposit 
					+ "\",\" takenBSFee\":\""+ takenBSFee
					+ "\",\" takenBSDeposit\":\"" + takenBSDeposit
					+ "\",\" sellSettleFee\":\"" + sellSettleFee 
					+"\",\" buySettleFee\":\""+ buySettleFee 
					+"\",\" buySettleDeposit\":\"" + buySettleDeposit
					+ "\",\" takenSSFee\":\"" + takenSSFee 
					+ "\",\" sellCreditFee\":\""+ sellCreditFee 
					+"\",\" buyCreditFee\":\"" + buyCreditFee
					+ "\",\" buyCreditDeposit\":\"" + buyCreditDeposit
					+ "\",\" takenMoney\":\""+ takenMoney 
					+ "\",\" payedMoney\":\"" + payedMoney 
					+ "\",\" money\":\""+ money + "\""
				+ "}";
		return deliverOutParamsJson;
	}
	
}
