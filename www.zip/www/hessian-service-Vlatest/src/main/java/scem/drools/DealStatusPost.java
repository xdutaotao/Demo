package scem.drools;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;

public class DealStatusPost {

	public JSONObject postDealStatusDrools(DealStatus bean, String mode) {
		DroolUtil util = new DroolUtil();
		
		String postData;
		
		postData = util.generateDroolsApiData("DealStatus", "DealStatus", bean);
		
		JSONObject jsoRtn;
		
		jsoRtn = util.postDroolsApi(postData, mode);
		
		return jsoRtn;
	}
	
	public JSONObject postDeliveryExpenseDrools(DeliveryExpense requestbean, String mode) {
		DroolUtil util = new DroolUtil();
		
		String postData;
		
		postData = util.generateDroolsApiData("DeliveryExpense", "DeliveryExpense", requestbean);
		
		JSONObject jsoRtn = null;
		try {
			jsoRtn = util.postDroolsApi(postData, mode);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return jsoRtn;
	}

	public static void main(String[] args) {
		
		DealStatus bean = new DealStatus();
		List<String> deliveryStatus = new ArrayList<String>();
		deliveryStatus.add("45");
		deliveryStatus.add("50");
		deliveryStatus.add("20");
		
		bean.setOrderQuantity(99);
		bean.setDelieveryQuantity(60);
		
		bean.setLsDeliveryStatus(deliveryStatus);
		
		DealStatusPost post = new DealStatusPost();
		JSONObject rtn = post.postDealStatusDrools(bean, "local");
		
		System.out.println(rtn.toString());
	}

}
