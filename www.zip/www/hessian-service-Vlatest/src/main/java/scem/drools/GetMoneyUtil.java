package scem.drools;

import java.math.BigDecimal;


public class GetMoneyUtil {
	
	/**
	 * 交收各项费用，根据订单分摊
	 * @param orderMoney
	 * @param orderQuantity
	 * @param deliveryQuantity
	 * @return
	 */
	public static BigDecimal getDeliveryMoney(BigDecimal orderMoney,int orderQuantity,int deliveryQuantity){
		BigDecimal money = new BigDecimal(0);
		if(orderQuantity > 0){
			money = orderMoney.multiply(new BigDecimal(deliveryQuantity)).divide(new BigDecimal(orderQuantity),2,BigDecimal.ROUND_CEILING);
		}
		return money;
	}

}
