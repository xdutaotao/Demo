package scem.drools;

public class PaymentStatus implements java.io.Serializable {
	static final long serialVersionUID = 1L;

	public PaymentStatus() {
	}

	private int processPoint = 0;
	private int backendCode = 0;
	// 1：申请付款 2：审核通过
	private Integer paymentType;
	// 成交单的状态
	private Integer tradeStatus;
	// 交收方式 1自提 11自提或转货权 21中石化配送
	private Integer settlementMethod;
	// 付款状态 0：待付款 5：待审核 10：已付款 15: 已拒绝
	private Integer paymentStatus;
	// 交收单违约数量（吨）
	private java.math.BigDecimal violationWeight;
	// 成交单的总数量(吨)
	private java.math.BigDecimal totalQuantity;
	// 交易场类型，0：现货 1：预售 2：期现
	private Integer tradeType;
	// 化交是否取得货物控制权:0:化交未取得货物控制权 1:化交已取得货物控制权
	private Integer isGoodsController;
	// 所有交收单的总重量
	private java.math.BigDecimal allDeliveryWeight;
	// 正常交收的交收数量
	private java.math.BigDecimal normalDeliveryWeight;
	// 物流标记过交收的交收数量
	private java.math.BigDecimal logisticsMarkDeliveryWeight;
	// 已付卖方金额(化交给卖家)
	private java.math.BigDecimal paidSellAmount;
	// 成交已付金额(化交给卖家)
	private java.math.BigDecimal paidAmount;

	public Integer getTradeStatus() {
		return tradeStatus;
	}

	public void setTradeStatus(Integer tradeStatus) {
		this.tradeStatus = tradeStatus;
	}

	public Integer getSettlementMethod() {
		return settlementMethod;
	}

	public void setSettlementMethod(Integer settlementMethod) {
		this.settlementMethod = settlementMethod;
	}

	public Integer getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(Integer paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public java.math.BigDecimal getViolationWeight() {
		return violationWeight;
	}

	public void setViolationWeight(java.math.BigDecimal violationWeight) {
		this.violationWeight = violationWeight;
	}

	public java.math.BigDecimal getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(java.math.BigDecimal totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	public Integer getTradeType() {
		return tradeType;
	}

	public void setTradeType(Integer tradeType) {
		this.tradeType = tradeType;
	}

	public Integer getIsGoodsController() {
		return isGoodsController;
	}

	public void setIsGoodsController(Integer isGoodsController) {
		this.isGoodsController = isGoodsController;
	}

	public java.math.BigDecimal getAllDeliveryWeight() {
		return allDeliveryWeight;
	}

	public void setAllDeliveryWeight(java.math.BigDecimal allDeliveryWeight) {
		this.allDeliveryWeight = allDeliveryWeight;
	}

	public java.math.BigDecimal getNormalDeliveryWeight() {
		return normalDeliveryWeight;
	}

	public void setNormalDeliveryWeight(
			java.math.BigDecimal normalDeliveryWeight) {
		this.normalDeliveryWeight = normalDeliveryWeight;
	}

	public java.math.BigDecimal getLogisticsMarkDeliveryWeight() {
		return logisticsMarkDeliveryWeight;
	}

	public void setLogisticsMarkDeliveryWeight(
			java.math.BigDecimal logisticsMarkDeliveryWeight) {
		this.logisticsMarkDeliveryWeight = logisticsMarkDeliveryWeight;
	}

	public java.math.BigDecimal getPaidSellAmount() {
		return paidSellAmount;
	}

	public void setPaidSellAmount(java.math.BigDecimal paidSellAmount) {
		this.paidSellAmount = paidSellAmount;
	}

	public java.math.BigDecimal getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(java.math.BigDecimal paidAmount) {
		this.paidAmount = paidAmount;
	}

	public int getProcessPoint() {
		return processPoint;
	}

	public void setProcessPoint(int processPoint) {
		this.processPoint = processPoint;
	}

	public int getBackendCode() {
		return backendCode;
	}

	public void setBackendCode(int backendCode) {
		this.backendCode = backendCode;
	}

	public Integer getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(Integer paymentType) {
		this.paymentType = paymentType;
	}
}
