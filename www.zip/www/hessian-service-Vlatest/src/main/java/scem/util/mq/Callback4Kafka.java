package scem.util.mq;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.log4j.Logger;

public class Callback4Kafka implements Callback {

	Logger logger = Logger.getLogger("Clientlog");
	private long startTime;
	private int key;
	private String message;

	public Callback4Kafka(long startTime, int key, String message) {
		this.startTime = startTime;
		this.key = key;
		this.message = message;
	}

	/**
	 * 当异步发送完成后需要进行的处理
	 **/
	public void onCompletion(RecordMetadata metadata, Exception exception) {
		long elapsedTime = System.currentTimeMillis() - startTime;
		if (metadata != null) {
			logger.debug("message(" + key + ", " + message + ") sent to topic(" + metadata.topic()
					+ "), partition(" + metadata.partition() + "), " + "offset(" + metadata.offset() + ") in "
					+ elapsedTime + " ms");
		} else {
			logger.debug(exception.getMessage());
		}
	}
}
