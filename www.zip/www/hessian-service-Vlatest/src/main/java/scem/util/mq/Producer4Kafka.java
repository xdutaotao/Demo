package scem.util.mq;

import java.util.Properties;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.log4j.Logger;

import shcem.constant.Constants;
import shcem.util.PropertyUtil;

public class Producer4Kafka extends Thread {

	Logger logger = Logger.getLogger("Clientlog");
	private final KafkaProducer<Integer, String> producer;
	private final String topic;
	private final boolean isAsync;
	private final String msg;
	private final int intSendCount;

	public Producer4Kafka(String mode, boolean isAsync, String topic, String msg, int intSendCount) {

		// 设置配置属性
		PropertyUtil propUtil = new PropertyUtil();
		Properties property = propUtil.getProperties(Constants.KAFKA_PROPERITES_PFILE);

		Properties props = new Properties();
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,
				property.getProperty(mode + "_" + ProducerConfig.BOOTSTRAP_SERVERS_CONFIG));
		props.put(ProducerConfig.CLIENT_ID_CONFIG, "ScemProducer");
		props.put(ProducerConfig.ACKS_CONFIG, property.getProperty(ProducerConfig.ACKS_CONFIG));
		props.put(ProducerConfig.RETRIES_CONFIG, Integer.parseInt(property.getProperty(ProducerConfig.RETRIES_CONFIG)));
		props.put(ProducerConfig.BATCH_SIZE_CONFIG,
				Integer.parseInt(property.getProperty(ProducerConfig.BATCH_SIZE_CONFIG)));
		props.put(ProducerConfig.LINGER_MS_CONFIG,
				Integer.parseInt(property.getProperty(ProducerConfig.LINGER_MS_CONFIG)));
		props.put(ProducerConfig.BUFFER_MEMORY_CONFIG,
				Integer.parseInt(property.getProperty(ProducerConfig.BUFFER_MEMORY_CONFIG)));
		props.put(ProducerConfig.PARTITIONER_CLASS_CONFIG,
				property.getProperty(ProducerConfig.PARTITIONER_CLASS_CONFIG));
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
				property.getProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG));
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
				property.getProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG));

		// 创建Producer
		producer = new KafkaProducer<Integer, String>(props);
		// 指定数据进入的的队列名称
		if (topic != null && !"".equals(topic)) {
			this.topic = topic;
		} else {
			// 设定为默认值
			this.topic = property.getProperty("topic_name");
		}

		// 发送的时候是否使用回调函数
		this.isAsync = isAsync;

		this.msg = msg;
		this.intSendCount = intSendCount;
	}

	public void run() {
		long startTime = System.currentTimeMillis();
		ProducerRecord<Integer, String> record = new ProducerRecord<Integer, String>(topic, intSendCount, msg);
		if (isAsync) {
			// Send asynchronously
			producer.send(record, new Callback4Kafka(startTime, intSendCount, msg));
		} else {
			// Send synchronously
			try {
				producer.send(record).get();
			} catch (InterruptedException e) {
				logger.debug(e.getMessage());
			} catch (ExecutionException e) {
				logger.debug(e.getMessage());
			}
		}
		try {
			Thread.sleep(1000);
			producer.close();
		} catch (InterruptedException e1) {
			logger.debug(e1.getMessage());
		}
	}

	public static void main(String[] args) {
		// test
		Producer4Kafka test = new Producer4Kafka("dev", true, "scem_topic", "hello consumer,13", 1);
		test.run();
	}

}