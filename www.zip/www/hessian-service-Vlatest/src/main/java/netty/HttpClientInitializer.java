package netty;

import java.util.Map;

import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.http.HttpRequestEncoder;
import io.netty.handler.codec.http.HttpResponseDecoder;

public class HttpClientInitializer extends ChannelInitializer<SocketChannel> {
	private Map<String, String> m;

	public HttpClientInitializer(Map<String, String> m) {
		this.m = m;
	}

	@Override
	public void initChannel(SocketChannel ch) {
		ChannelPipeline p = ch.pipeline();
		p.addLast(new HttpResponseDecoder());
		p.addLast(new HttpRequestEncoder());
		p.addLast(new HttpClientHandler(m));
	}
}